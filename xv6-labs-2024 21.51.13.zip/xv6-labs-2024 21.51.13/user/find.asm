
user/_find:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <find>:
#include "user/user.h"
#include "kernel/fs.h"

// 比较文件名是否匹配
void find(char *path, char *target)
{
   0:	d9010113          	addi	sp,sp,-624
   4:	26113423          	sd	ra,616(sp)
   8:	26813023          	sd	s0,608(sp)
   c:	25313423          	sd	s3,584(sp)
  10:	23513c23          	sd	s5,568(sp)
  14:	1c80                	addi	s0,sp,624
  16:	8aaa                	mv	s5,a0
  18:	89ae                	mv	s3,a1
    int fd;
    struct dirent de;
    struct stat st;

    // 打开目录
    if((fd = open(path, 0)) < 0){
  1a:	4581                	li	a1,0
  1c:	498000ef          	jal	4b4 <open>
  20:	06054e63          	bltz	a0,9c <find+0x9c>
  24:	24913c23          	sd	s1,600(sp)
  28:	84aa                	mv	s1,a0
        fprintf(2, "find: cannot open %s\n", path);
        return;
    }

    // 获取文件状态
    if(fstat(fd, &st) < 0){
  2a:	d9840593          	addi	a1,s0,-616
  2e:	49e000ef          	jal	4cc <fstat>
  32:	06054e63          	bltz	a0,ae <find+0xae>
        close(fd);
        return;
    }

    // 处理不同类型的文件
    switch(st.type){
  36:	da041783          	lh	a5,-608(s0)
  3a:	4705                	li	a4,1
  3c:	0ce78163          	beq	a5,a4,fe <find+0xfe>
  40:	4709                	li	a4,2
  42:	02e79d63          	bne	a5,a4,7c <find+0x7c>
  46:	25213823          	sd	s2,592(sp)
  4a:	25413023          	sd	s4,576(sp)
        case T_FILE:
            // 如果是文件，检查文件名是否匹配
            if(strcmp(path + strlen(path) - strlen(target), target) == 0 &&
  4e:	8556                	mv	a0,s5
  50:	1fa000ef          	jal	24a <strlen>
  54:	8a2a                	mv	s4,a0
  56:	854e                	mv	a0,s3
  58:	1f2000ef          	jal	24a <strlen>
  5c:	020a1793          	slli	a5,s4,0x20
  60:	9381                	srli	a5,a5,0x20
  62:	1502                	slli	a0,a0,0x20
  64:	9101                	srli	a0,a0,0x20
  66:	40a78533          	sub	a0,a5,a0
  6a:	85ce                	mv	a1,s3
  6c:	9556                	add	a0,a0,s5
  6e:	1ac000ef          	jal	21a <strcmp>
  72:	cd21                	beqz	a0,ca <find+0xca>
  74:	25013903          	ld	s2,592(sp)
  78:	24013a03          	ld	s4,576(sp)
                // 递归查找
                find(buf, target);
            }
            break;
    }
    close(fd);
  7c:	8526                	mv	a0,s1
  7e:	41e000ef          	jal	49c <close>
  82:	25813483          	ld	s1,600(sp)
}
  86:	26813083          	ld	ra,616(sp)
  8a:	26013403          	ld	s0,608(sp)
  8e:	24813983          	ld	s3,584(sp)
  92:	23813a83          	ld	s5,568(sp)
  96:	27010113          	addi	sp,sp,624
  9a:	8082                	ret
        fprintf(2, "find: cannot open %s\n", path);
  9c:	8656                	mv	a2,s5
  9e:	00001597          	auipc	a1,0x1
  a2:	9b258593          	addi	a1,a1,-1614 # a50 <malloc+0xf4>
  a6:	4509                	li	a0,2
  a8:	7d2000ef          	jal	87a <fprintf>
        return;
  ac:	bfe9                	j	86 <find+0x86>
        fprintf(2, "find: cannot stat %s\n", path);
  ae:	8656                	mv	a2,s5
  b0:	00001597          	auipc	a1,0x1
  b4:	9c058593          	addi	a1,a1,-1600 # a70 <malloc+0x114>
  b8:	4509                	li	a0,2
  ba:	7c0000ef          	jal	87a <fprintf>
        close(fd);
  be:	8526                	mv	a0,s1
  c0:	3dc000ef          	jal	49c <close>
        return;
  c4:	25813483          	ld	s1,600(sp)
  c8:	bf7d                	j	86 <find+0x86>
               strlen(path) >= strlen(target)){
  ca:	8556                	mv	a0,s5
  cc:	17e000ef          	jal	24a <strlen>
  d0:	892a                	mv	s2,a0
  d2:	854e                	mv	a0,s3
  d4:	176000ef          	jal	24a <strlen>
            if(strcmp(path + strlen(path) - strlen(target), target) == 0 &&
  d8:	00a97763          	bgeu	s2,a0,e6 <find+0xe6>
  dc:	25013903          	ld	s2,592(sp)
  e0:	24013a03          	ld	s4,576(sp)
  e4:	bf61                	j	7c <find+0x7c>
                printf("%s\n", path);
  e6:	85d6                	mv	a1,s5
  e8:	00001517          	auipc	a0,0x1
  ec:	9a050513          	addi	a0,a0,-1632 # a88 <malloc+0x12c>
  f0:	7b4000ef          	jal	8a4 <printf>
  f4:	25013903          	ld	s2,592(sp)
  f8:	24013a03          	ld	s4,576(sp)
  fc:	b741                	j	7c <find+0x7c>
            if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
  fe:	8556                	mv	a0,s5
 100:	14a000ef          	jal	24a <strlen>
 104:	2541                	addiw	a0,a0,16
 106:	20000793          	li	a5,512
 10a:	00a7fa63          	bgeu	a5,a0,11e <find+0x11e>
                fprintf(2, "find: path too long\n");
 10e:	00001597          	auipc	a1,0x1
 112:	98258593          	addi	a1,a1,-1662 # a90 <malloc+0x134>
 116:	4509                	li	a0,2
 118:	762000ef          	jal	87a <fprintf>
                break;
 11c:	b785                	j	7c <find+0x7c>
 11e:	25213823          	sd	s2,592(sp)
 122:	25413023          	sd	s4,576(sp)
            strcpy(buf, path);
 126:	85d6                	mv	a1,s5
 128:	dc040513          	addi	a0,s0,-576
 12c:	0ce000ef          	jal	1fa <strcpy>
            p = buf + strlen(buf);
 130:	dc040513          	addi	a0,s0,-576
 134:	116000ef          	jal	24a <strlen>
 138:	1502                	slli	a0,a0,0x20
 13a:	9101                	srli	a0,a0,0x20
 13c:	dc040793          	addi	a5,s0,-576
 140:	00a78733          	add	a4,a5,a0
 144:	893a                	mv	s2,a4
            *p++ = '/';
 146:	00170793          	addi	a5,a4,1
 14a:	8a3e                	mv	s4,a5
 14c:	02f00793          	li	a5,47
 150:	00f70023          	sb	a5,0(a4)
            while(read(fd, &de, sizeof(de)) == sizeof(de)){
 154:	4641                	li	a2,16
 156:	db040593          	addi	a1,s0,-592
 15a:	8526                	mv	a0,s1
 15c:	330000ef          	jal	48c <read>
 160:	47c1                	li	a5,16
 162:	04f51563          	bne	a0,a5,1ac <find+0x1ac>
                if(de.inum == 0)
 166:	db045783          	lhu	a5,-592(s0)
 16a:	d7ed                	beqz	a5,154 <find+0x154>
                if(strcmp(de.name, ".") == 0 || strcmp(de.name, "..") == 0)
 16c:	00001597          	auipc	a1,0x1
 170:	93c58593          	addi	a1,a1,-1732 # aa8 <malloc+0x14c>
 174:	db240513          	addi	a0,s0,-590
 178:	0a2000ef          	jal	21a <strcmp>
 17c:	dd61                	beqz	a0,154 <find+0x154>
 17e:	00001597          	auipc	a1,0x1
 182:	93258593          	addi	a1,a1,-1742 # ab0 <malloc+0x154>
 186:	db240513          	addi	a0,s0,-590
 18a:	090000ef          	jal	21a <strcmp>
 18e:	d179                	beqz	a0,154 <find+0x154>
                memmove(p, de.name, DIRSIZ);
 190:	4639                	li	a2,14
 192:	db240593          	addi	a1,s0,-590
 196:	8552                	mv	a0,s4
 198:	22a000ef          	jal	3c2 <memmove>
                p[DIRSIZ] = 0;
 19c:	000907a3          	sb	zero,15(s2)
                find(buf, target);
 1a0:	85ce                	mv	a1,s3
 1a2:	dc040513          	addi	a0,s0,-576
 1a6:	e5bff0ef          	jal	0 <find>
 1aa:	b76d                	j	154 <find+0x154>
 1ac:	25013903          	ld	s2,592(sp)
 1b0:	24013a03          	ld	s4,576(sp)
 1b4:	b5e1                	j	7c <find+0x7c>

00000000000001b6 <main>:

int main(int argc, char *argv[])
{
 1b6:	1141                	addi	sp,sp,-16
 1b8:	e406                	sd	ra,8(sp)
 1ba:	e022                	sd	s0,0(sp)
 1bc:	0800                	addi	s0,sp,16
    if(argc != 3){
 1be:	470d                	li	a4,3
 1c0:	00e50c63          	beq	a0,a4,1d8 <main+0x22>
        fprintf(2, "Usage: find <directory> <filename>\n");
 1c4:	00001597          	auipc	a1,0x1
 1c8:	8f458593          	addi	a1,a1,-1804 # ab8 <malloc+0x15c>
 1cc:	4509                	li	a0,2
 1ce:	6ac000ef          	jal	87a <fprintf>
        exit(1);
 1d2:	4505                	li	a0,1
 1d4:	2a0000ef          	jal	474 <exit>
 1d8:	87ae                	mv	a5,a1
    }

    find(argv[1], argv[2]);
 1da:	698c                	ld	a1,16(a1)
 1dc:	6788                	ld	a0,8(a5)
 1de:	e23ff0ef          	jal	0 <find>
    exit(0);
 1e2:	4501                	li	a0,0
 1e4:	290000ef          	jal	474 <exit>

00000000000001e8 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 1e8:	1141                	addi	sp,sp,-16
 1ea:	e406                	sd	ra,8(sp)
 1ec:	e022                	sd	s0,0(sp)
 1ee:	0800                	addi	s0,sp,16
  extern int main();
  main();
 1f0:	fc7ff0ef          	jal	1b6 <main>
  exit(0);
 1f4:	4501                	li	a0,0
 1f6:	27e000ef          	jal	474 <exit>

00000000000001fa <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 1fa:	1141                	addi	sp,sp,-16
 1fc:	e406                	sd	ra,8(sp)
 1fe:	e022                	sd	s0,0(sp)
 200:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 202:	87aa                	mv	a5,a0
 204:	0585                	addi	a1,a1,1
 206:	0785                	addi	a5,a5,1
 208:	fff5c703          	lbu	a4,-1(a1)
 20c:	fee78fa3          	sb	a4,-1(a5)
 210:	fb75                	bnez	a4,204 <strcpy+0xa>
    ;
  return os;
}
 212:	60a2                	ld	ra,8(sp)
 214:	6402                	ld	s0,0(sp)
 216:	0141                	addi	sp,sp,16
 218:	8082                	ret

000000000000021a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 21a:	1141                	addi	sp,sp,-16
 21c:	e406                	sd	ra,8(sp)
 21e:	e022                	sd	s0,0(sp)
 220:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 222:	00054783          	lbu	a5,0(a0)
 226:	cb91                	beqz	a5,23a <strcmp+0x20>
 228:	0005c703          	lbu	a4,0(a1)
 22c:	00f71763          	bne	a4,a5,23a <strcmp+0x20>
    p++, q++;
 230:	0505                	addi	a0,a0,1
 232:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 234:	00054783          	lbu	a5,0(a0)
 238:	fbe5                	bnez	a5,228 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 23a:	0005c503          	lbu	a0,0(a1)
}
 23e:	40a7853b          	subw	a0,a5,a0
 242:	60a2                	ld	ra,8(sp)
 244:	6402                	ld	s0,0(sp)
 246:	0141                	addi	sp,sp,16
 248:	8082                	ret

000000000000024a <strlen>:

uint
strlen(const char *s)
{
 24a:	1141                	addi	sp,sp,-16
 24c:	e406                	sd	ra,8(sp)
 24e:	e022                	sd	s0,0(sp)
 250:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 252:	00054783          	lbu	a5,0(a0)
 256:	cf91                	beqz	a5,272 <strlen+0x28>
 258:	00150793          	addi	a5,a0,1
 25c:	86be                	mv	a3,a5
 25e:	0785                	addi	a5,a5,1
 260:	fff7c703          	lbu	a4,-1(a5)
 264:	ff65                	bnez	a4,25c <strlen+0x12>
 266:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 26a:	60a2                	ld	ra,8(sp)
 26c:	6402                	ld	s0,0(sp)
 26e:	0141                	addi	sp,sp,16
 270:	8082                	ret
  for(n = 0; s[n]; n++)
 272:	4501                	li	a0,0
 274:	bfdd                	j	26a <strlen+0x20>

0000000000000276 <memset>:

void*
memset(void *dst, int c, uint n)
{
 276:	1141                	addi	sp,sp,-16
 278:	e406                	sd	ra,8(sp)
 27a:	e022                	sd	s0,0(sp)
 27c:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 27e:	ca19                	beqz	a2,294 <memset+0x1e>
 280:	87aa                	mv	a5,a0
 282:	1602                	slli	a2,a2,0x20
 284:	9201                	srli	a2,a2,0x20
 286:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 28a:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 28e:	0785                	addi	a5,a5,1
 290:	fee79de3          	bne	a5,a4,28a <memset+0x14>
  }
  return dst;
}
 294:	60a2                	ld	ra,8(sp)
 296:	6402                	ld	s0,0(sp)
 298:	0141                	addi	sp,sp,16
 29a:	8082                	ret

000000000000029c <strchr>:

char*
strchr(const char *s, char c)
{
 29c:	1141                	addi	sp,sp,-16
 29e:	e406                	sd	ra,8(sp)
 2a0:	e022                	sd	s0,0(sp)
 2a2:	0800                	addi	s0,sp,16
  for(; *s; s++)
 2a4:	00054783          	lbu	a5,0(a0)
 2a8:	cf81                	beqz	a5,2c0 <strchr+0x24>
    if(*s == c)
 2aa:	00f58763          	beq	a1,a5,2b8 <strchr+0x1c>
  for(; *s; s++)
 2ae:	0505                	addi	a0,a0,1
 2b0:	00054783          	lbu	a5,0(a0)
 2b4:	fbfd                	bnez	a5,2aa <strchr+0xe>
      return (char*)s;
  return 0;
 2b6:	4501                	li	a0,0
}
 2b8:	60a2                	ld	ra,8(sp)
 2ba:	6402                	ld	s0,0(sp)
 2bc:	0141                	addi	sp,sp,16
 2be:	8082                	ret
  return 0;
 2c0:	4501                	li	a0,0
 2c2:	bfdd                	j	2b8 <strchr+0x1c>

00000000000002c4 <gets>:

char*
gets(char *buf, int max)
{
 2c4:	711d                	addi	sp,sp,-96
 2c6:	ec86                	sd	ra,88(sp)
 2c8:	e8a2                	sd	s0,80(sp)
 2ca:	e4a6                	sd	s1,72(sp)
 2cc:	e0ca                	sd	s2,64(sp)
 2ce:	fc4e                	sd	s3,56(sp)
 2d0:	f852                	sd	s4,48(sp)
 2d2:	f456                	sd	s5,40(sp)
 2d4:	f05a                	sd	s6,32(sp)
 2d6:	ec5e                	sd	s7,24(sp)
 2d8:	e862                	sd	s8,16(sp)
 2da:	1080                	addi	s0,sp,96
 2dc:	8baa                	mv	s7,a0
 2de:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 2e0:	892a                	mv	s2,a0
 2e2:	4481                	li	s1,0
    cc = read(0, &c, 1);
 2e4:	faf40b13          	addi	s6,s0,-81
 2e8:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 2ea:	8c26                	mv	s8,s1
 2ec:	0014899b          	addiw	s3,s1,1
 2f0:	84ce                	mv	s1,s3
 2f2:	0349d463          	bge	s3,s4,31a <gets+0x56>
    cc = read(0, &c, 1);
 2f6:	8656                	mv	a2,s5
 2f8:	85da                	mv	a1,s6
 2fa:	4501                	li	a0,0
 2fc:	190000ef          	jal	48c <read>
    if(cc < 1)
 300:	00a05d63          	blez	a0,31a <gets+0x56>
      break;
    buf[i++] = c;
 304:	faf44783          	lbu	a5,-81(s0)
 308:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 30c:	0905                	addi	s2,s2,1
 30e:	ff678713          	addi	a4,a5,-10
 312:	c319                	beqz	a4,318 <gets+0x54>
 314:	17cd                	addi	a5,a5,-13
 316:	fbf1                	bnez	a5,2ea <gets+0x26>
    buf[i++] = c;
 318:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 31a:	9c5e                	add	s8,s8,s7
 31c:	000c0023          	sb	zero,0(s8)
  return buf;
}
 320:	855e                	mv	a0,s7
 322:	60e6                	ld	ra,88(sp)
 324:	6446                	ld	s0,80(sp)
 326:	64a6                	ld	s1,72(sp)
 328:	6906                	ld	s2,64(sp)
 32a:	79e2                	ld	s3,56(sp)
 32c:	7a42                	ld	s4,48(sp)
 32e:	7aa2                	ld	s5,40(sp)
 330:	7b02                	ld	s6,32(sp)
 332:	6be2                	ld	s7,24(sp)
 334:	6c42                	ld	s8,16(sp)
 336:	6125                	addi	sp,sp,96
 338:	8082                	ret

000000000000033a <stat>:

int
stat(const char *n, struct stat *st)
{
 33a:	1101                	addi	sp,sp,-32
 33c:	ec06                	sd	ra,24(sp)
 33e:	e822                	sd	s0,16(sp)
 340:	e04a                	sd	s2,0(sp)
 342:	1000                	addi	s0,sp,32
 344:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 346:	4581                	li	a1,0
 348:	16c000ef          	jal	4b4 <open>
  if(fd < 0)
 34c:	02054263          	bltz	a0,370 <stat+0x36>
 350:	e426                	sd	s1,8(sp)
 352:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 354:	85ca                	mv	a1,s2
 356:	176000ef          	jal	4cc <fstat>
 35a:	892a                	mv	s2,a0
  close(fd);
 35c:	8526                	mv	a0,s1
 35e:	13e000ef          	jal	49c <close>
  return r;
 362:	64a2                	ld	s1,8(sp)
}
 364:	854a                	mv	a0,s2
 366:	60e2                	ld	ra,24(sp)
 368:	6442                	ld	s0,16(sp)
 36a:	6902                	ld	s2,0(sp)
 36c:	6105                	addi	sp,sp,32
 36e:	8082                	ret
    return -1;
 370:	57fd                	li	a5,-1
 372:	893e                	mv	s2,a5
 374:	bfc5                	j	364 <stat+0x2a>

0000000000000376 <atoi>:

int
atoi(const char *s)
{
 376:	1141                	addi	sp,sp,-16
 378:	e406                	sd	ra,8(sp)
 37a:	e022                	sd	s0,0(sp)
 37c:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 37e:	00054683          	lbu	a3,0(a0)
 382:	fd06879b          	addiw	a5,a3,-48
 386:	0ff7f793          	zext.b	a5,a5
 38a:	4625                	li	a2,9
 38c:	02f66963          	bltu	a2,a5,3be <atoi+0x48>
 390:	872a                	mv	a4,a0
  n = 0;
 392:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 394:	0705                	addi	a4,a4,1
 396:	0025179b          	slliw	a5,a0,0x2
 39a:	9fa9                	addw	a5,a5,a0
 39c:	0017979b          	slliw	a5,a5,0x1
 3a0:	9fb5                	addw	a5,a5,a3
 3a2:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 3a6:	00074683          	lbu	a3,0(a4)
 3aa:	fd06879b          	addiw	a5,a3,-48
 3ae:	0ff7f793          	zext.b	a5,a5
 3b2:	fef671e3          	bgeu	a2,a5,394 <atoi+0x1e>
  return n;
}
 3b6:	60a2                	ld	ra,8(sp)
 3b8:	6402                	ld	s0,0(sp)
 3ba:	0141                	addi	sp,sp,16
 3bc:	8082                	ret
  n = 0;
 3be:	4501                	li	a0,0
 3c0:	bfdd                	j	3b6 <atoi+0x40>

00000000000003c2 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3c2:	1141                	addi	sp,sp,-16
 3c4:	e406                	sd	ra,8(sp)
 3c6:	e022                	sd	s0,0(sp)
 3c8:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 3ca:	02b57563          	bgeu	a0,a1,3f4 <memmove+0x32>
    while(n-- > 0)
 3ce:	00c05f63          	blez	a2,3ec <memmove+0x2a>
 3d2:	1602                	slli	a2,a2,0x20
 3d4:	9201                	srli	a2,a2,0x20
 3d6:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 3da:	872a                	mv	a4,a0
      *dst++ = *src++;
 3dc:	0585                	addi	a1,a1,1
 3de:	0705                	addi	a4,a4,1
 3e0:	fff5c683          	lbu	a3,-1(a1)
 3e4:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 3e8:	fee79ae3          	bne	a5,a4,3dc <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 3ec:	60a2                	ld	ra,8(sp)
 3ee:	6402                	ld	s0,0(sp)
 3f0:	0141                	addi	sp,sp,16
 3f2:	8082                	ret
    while(n-- > 0)
 3f4:	fec05ce3          	blez	a2,3ec <memmove+0x2a>
    dst += n;
 3f8:	00c50733          	add	a4,a0,a2
    src += n;
 3fc:	95b2                	add	a1,a1,a2
 3fe:	fff6079b          	addiw	a5,a2,-1
 402:	1782                	slli	a5,a5,0x20
 404:	9381                	srli	a5,a5,0x20
 406:	fff7c793          	not	a5,a5
 40a:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 40c:	15fd                	addi	a1,a1,-1
 40e:	177d                	addi	a4,a4,-1
 410:	0005c683          	lbu	a3,0(a1)
 414:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 418:	fef71ae3          	bne	a4,a5,40c <memmove+0x4a>
 41c:	bfc1                	j	3ec <memmove+0x2a>

000000000000041e <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 41e:	1141                	addi	sp,sp,-16
 420:	e406                	sd	ra,8(sp)
 422:	e022                	sd	s0,0(sp)
 424:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 426:	c61d                	beqz	a2,454 <memcmp+0x36>
 428:	1602                	slli	a2,a2,0x20
 42a:	9201                	srli	a2,a2,0x20
 42c:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 430:	00054783          	lbu	a5,0(a0)
 434:	0005c703          	lbu	a4,0(a1)
 438:	00e79863          	bne	a5,a4,448 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 43c:	0505                	addi	a0,a0,1
    p2++;
 43e:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 440:	fed518e3          	bne	a0,a3,430 <memcmp+0x12>
  }
  return 0;
 444:	4501                	li	a0,0
 446:	a019                	j	44c <memcmp+0x2e>
      return *p1 - *p2;
 448:	40e7853b          	subw	a0,a5,a4
}
 44c:	60a2                	ld	ra,8(sp)
 44e:	6402                	ld	s0,0(sp)
 450:	0141                	addi	sp,sp,16
 452:	8082                	ret
  return 0;
 454:	4501                	li	a0,0
 456:	bfdd                	j	44c <memcmp+0x2e>

0000000000000458 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 458:	1141                	addi	sp,sp,-16
 45a:	e406                	sd	ra,8(sp)
 45c:	e022                	sd	s0,0(sp)
 45e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 460:	f63ff0ef          	jal	3c2 <memmove>
}
 464:	60a2                	ld	ra,8(sp)
 466:	6402                	ld	s0,0(sp)
 468:	0141                	addi	sp,sp,16
 46a:	8082                	ret

000000000000046c <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 46c:	4885                	li	a7,1
 ecall
 46e:	00000073          	ecall
 ret
 472:	8082                	ret

0000000000000474 <exit>:
.global exit
exit:
 li a7, SYS_exit
 474:	4889                	li	a7,2
 ecall
 476:	00000073          	ecall
 ret
 47a:	8082                	ret

000000000000047c <wait>:
.global wait
wait:
 li a7, SYS_wait
 47c:	488d                	li	a7,3
 ecall
 47e:	00000073          	ecall
 ret
 482:	8082                	ret

0000000000000484 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 484:	4891                	li	a7,4
 ecall
 486:	00000073          	ecall
 ret
 48a:	8082                	ret

000000000000048c <read>:
.global read
read:
 li a7, SYS_read
 48c:	4895                	li	a7,5
 ecall
 48e:	00000073          	ecall
 ret
 492:	8082                	ret

0000000000000494 <write>:
.global write
write:
 li a7, SYS_write
 494:	48c1                	li	a7,16
 ecall
 496:	00000073          	ecall
 ret
 49a:	8082                	ret

000000000000049c <close>:
.global close
close:
 li a7, SYS_close
 49c:	48d5                	li	a7,21
 ecall
 49e:	00000073          	ecall
 ret
 4a2:	8082                	ret

00000000000004a4 <kill>:
.global kill
kill:
 li a7, SYS_kill
 4a4:	4899                	li	a7,6
 ecall
 4a6:	00000073          	ecall
 ret
 4aa:	8082                	ret

00000000000004ac <exec>:
.global exec
exec:
 li a7, SYS_exec
 4ac:	489d                	li	a7,7
 ecall
 4ae:	00000073          	ecall
 ret
 4b2:	8082                	ret

00000000000004b4 <open>:
.global open
open:
 li a7, SYS_open
 4b4:	48bd                	li	a7,15
 ecall
 4b6:	00000073          	ecall
 ret
 4ba:	8082                	ret

00000000000004bc <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 4bc:	48c5                	li	a7,17
 ecall
 4be:	00000073          	ecall
 ret
 4c2:	8082                	ret

00000000000004c4 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4c4:	48c9                	li	a7,18
 ecall
 4c6:	00000073          	ecall
 ret
 4ca:	8082                	ret

00000000000004cc <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4cc:	48a1                	li	a7,8
 ecall
 4ce:	00000073          	ecall
 ret
 4d2:	8082                	ret

00000000000004d4 <link>:
.global link
link:
 li a7, SYS_link
 4d4:	48cd                	li	a7,19
 ecall
 4d6:	00000073          	ecall
 ret
 4da:	8082                	ret

00000000000004dc <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4dc:	48d1                	li	a7,20
 ecall
 4de:	00000073          	ecall
 ret
 4e2:	8082                	ret

00000000000004e4 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4e4:	48a5                	li	a7,9
 ecall
 4e6:	00000073          	ecall
 ret
 4ea:	8082                	ret

00000000000004ec <dup>:
.global dup
dup:
 li a7, SYS_dup
 4ec:	48a9                	li	a7,10
 ecall
 4ee:	00000073          	ecall
 ret
 4f2:	8082                	ret

00000000000004f4 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 4f4:	48ad                	li	a7,11
 ecall
 4f6:	00000073          	ecall
 ret
 4fa:	8082                	ret

00000000000004fc <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 4fc:	48b1                	li	a7,12
 ecall
 4fe:	00000073          	ecall
 ret
 502:	8082                	ret

0000000000000504 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 504:	48b5                	li	a7,13
 ecall
 506:	00000073          	ecall
 ret
 50a:	8082                	ret

000000000000050c <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 50c:	48b9                	li	a7,14
 ecall
 50e:	00000073          	ecall
 ret
 512:	8082                	ret

0000000000000514 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 514:	1101                	addi	sp,sp,-32
 516:	ec06                	sd	ra,24(sp)
 518:	e822                	sd	s0,16(sp)
 51a:	1000                	addi	s0,sp,32
 51c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 520:	4605                	li	a2,1
 522:	fef40593          	addi	a1,s0,-17
 526:	f6fff0ef          	jal	494 <write>
}
 52a:	60e2                	ld	ra,24(sp)
 52c:	6442                	ld	s0,16(sp)
 52e:	6105                	addi	sp,sp,32
 530:	8082                	ret

0000000000000532 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 532:	7139                	addi	sp,sp,-64
 534:	fc06                	sd	ra,56(sp)
 536:	f822                	sd	s0,48(sp)
 538:	f04a                	sd	s2,32(sp)
 53a:	ec4e                	sd	s3,24(sp)
 53c:	0080                	addi	s0,sp,64
 53e:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 540:	cac9                	beqz	a3,5d2 <printint+0xa0>
 542:	01f5d79b          	srliw	a5,a1,0x1f
 546:	c7d1                	beqz	a5,5d2 <printint+0xa0>
    neg = 1;
    x = -xx;
 548:	40b005bb          	negw	a1,a1
    neg = 1;
 54c:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 54e:	fc040993          	addi	s3,s0,-64
  neg = 0;
 552:	86ce                	mv	a3,s3
  i = 0;
 554:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 556:	00000817          	auipc	a6,0x0
 55a:	59280813          	addi	a6,a6,1426 # ae8 <digits>
 55e:	88ba                	mv	a7,a4
 560:	0017051b          	addiw	a0,a4,1
 564:	872a                	mv	a4,a0
 566:	02c5f7bb          	remuw	a5,a1,a2
 56a:	1782                	slli	a5,a5,0x20
 56c:	9381                	srli	a5,a5,0x20
 56e:	97c2                	add	a5,a5,a6
 570:	0007c783          	lbu	a5,0(a5)
 574:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 578:	87ae                	mv	a5,a1
 57a:	02c5d5bb          	divuw	a1,a1,a2
 57e:	0685                	addi	a3,a3,1
 580:	fcc7ffe3          	bgeu	a5,a2,55e <printint+0x2c>
  if(neg)
 584:	00030c63          	beqz	t1,59c <printint+0x6a>
    buf[i++] = '-';
 588:	fd050793          	addi	a5,a0,-48
 58c:	00878533          	add	a0,a5,s0
 590:	02d00793          	li	a5,45
 594:	fef50823          	sb	a5,-16(a0)
 598:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 59c:	02e05563          	blez	a4,5c6 <printint+0x94>
 5a0:	f426                	sd	s1,40(sp)
 5a2:	377d                	addiw	a4,a4,-1
 5a4:	00e984b3          	add	s1,s3,a4
 5a8:	19fd                	addi	s3,s3,-1
 5aa:	99ba                	add	s3,s3,a4
 5ac:	1702                	slli	a4,a4,0x20
 5ae:	9301                	srli	a4,a4,0x20
 5b0:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 5b4:	0004c583          	lbu	a1,0(s1)
 5b8:	854a                	mv	a0,s2
 5ba:	f5bff0ef          	jal	514 <putc>
  while(--i >= 0)
 5be:	14fd                	addi	s1,s1,-1
 5c0:	ff349ae3          	bne	s1,s3,5b4 <printint+0x82>
 5c4:	74a2                	ld	s1,40(sp)
}
 5c6:	70e2                	ld	ra,56(sp)
 5c8:	7442                	ld	s0,48(sp)
 5ca:	7902                	ld	s2,32(sp)
 5cc:	69e2                	ld	s3,24(sp)
 5ce:	6121                	addi	sp,sp,64
 5d0:	8082                	ret
  neg = 0;
 5d2:	4301                	li	t1,0
 5d4:	bfad                	j	54e <printint+0x1c>

00000000000005d6 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5d6:	711d                	addi	sp,sp,-96
 5d8:	ec86                	sd	ra,88(sp)
 5da:	e8a2                	sd	s0,80(sp)
 5dc:	e4a6                	sd	s1,72(sp)
 5de:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5e0:	0005c483          	lbu	s1,0(a1)
 5e4:	20048963          	beqz	s1,7f6 <vprintf+0x220>
 5e8:	e0ca                	sd	s2,64(sp)
 5ea:	fc4e                	sd	s3,56(sp)
 5ec:	f852                	sd	s4,48(sp)
 5ee:	f456                	sd	s5,40(sp)
 5f0:	f05a                	sd	s6,32(sp)
 5f2:	ec5e                	sd	s7,24(sp)
 5f4:	e862                	sd	s8,16(sp)
 5f6:	8b2a                	mv	s6,a0
 5f8:	8a2e                	mv	s4,a1
 5fa:	8bb2                	mv	s7,a2
  state = 0;
 5fc:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 5fe:	4901                	li	s2,0
 600:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 602:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 606:	06400c13          	li	s8,100
 60a:	a00d                	j	62c <vprintf+0x56>
        putc(fd, c0);
 60c:	85a6                	mv	a1,s1
 60e:	855a                	mv	a0,s6
 610:	f05ff0ef          	jal	514 <putc>
 614:	a019                	j	61a <vprintf+0x44>
    } else if(state == '%'){
 616:	03598363          	beq	s3,s5,63c <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 61a:	0019079b          	addiw	a5,s2,1
 61e:	893e                	mv	s2,a5
 620:	873e                	mv	a4,a5
 622:	97d2                	add	a5,a5,s4
 624:	0007c483          	lbu	s1,0(a5)
 628:	1c048063          	beqz	s1,7e8 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 62c:	0004879b          	sext.w	a5,s1
    if(state == 0){
 630:	fe0993e3          	bnez	s3,616 <vprintf+0x40>
      if(c0 == '%'){
 634:	fd579ce3          	bne	a5,s5,60c <vprintf+0x36>
        state = '%';
 638:	89be                	mv	s3,a5
 63a:	b7c5                	j	61a <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 63c:	00ea06b3          	add	a3,s4,a4
 640:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 644:	1a060e63          	beqz	a2,800 <vprintf+0x22a>
      if(c0 == 'd'){
 648:	03878763          	beq	a5,s8,676 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 64c:	f9478693          	addi	a3,a5,-108
 650:	0016b693          	seqz	a3,a3
 654:	f9c60593          	addi	a1,a2,-100
 658:	e99d                	bnez	a1,68e <vprintf+0xb8>
 65a:	ca95                	beqz	a3,68e <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 65c:	008b8493          	addi	s1,s7,8
 660:	4685                	li	a3,1
 662:	4629                	li	a2,10
 664:	000ba583          	lw	a1,0(s7)
 668:	855a                	mv	a0,s6
 66a:	ec9ff0ef          	jal	532 <printint>
        i += 1;
 66e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 670:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 672:	4981                	li	s3,0
 674:	b75d                	j	61a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 676:	008b8493          	addi	s1,s7,8
 67a:	4685                	li	a3,1
 67c:	4629                	li	a2,10
 67e:	000ba583          	lw	a1,0(s7)
 682:	855a                	mv	a0,s6
 684:	eafff0ef          	jal	532 <printint>
 688:	8ba6                	mv	s7,s1
      state = 0;
 68a:	4981                	li	s3,0
 68c:	b779                	j	61a <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 68e:	9752                	add	a4,a4,s4
 690:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 694:	f9460713          	addi	a4,a2,-108
 698:	00173713          	seqz	a4,a4
 69c:	8f75                	and	a4,a4,a3
 69e:	f9c58513          	addi	a0,a1,-100
 6a2:	16051963          	bnez	a0,814 <vprintf+0x23e>
 6a6:	16070763          	beqz	a4,814 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6aa:	008b8493          	addi	s1,s7,8
 6ae:	4685                	li	a3,1
 6b0:	4629                	li	a2,10
 6b2:	000ba583          	lw	a1,0(s7)
 6b6:	855a                	mv	a0,s6
 6b8:	e7bff0ef          	jal	532 <printint>
        i += 2;
 6bc:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 6be:	8ba6                	mv	s7,s1
      state = 0;
 6c0:	4981                	li	s3,0
        i += 2;
 6c2:	bfa1                	j	61a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 6c4:	008b8493          	addi	s1,s7,8
 6c8:	4681                	li	a3,0
 6ca:	4629                	li	a2,10
 6cc:	000ba583          	lw	a1,0(s7)
 6d0:	855a                	mv	a0,s6
 6d2:	e61ff0ef          	jal	532 <printint>
 6d6:	8ba6                	mv	s7,s1
      state = 0;
 6d8:	4981                	li	s3,0
 6da:	b781                	j	61a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6dc:	008b8493          	addi	s1,s7,8
 6e0:	4681                	li	a3,0
 6e2:	4629                	li	a2,10
 6e4:	000ba583          	lw	a1,0(s7)
 6e8:	855a                	mv	a0,s6
 6ea:	e49ff0ef          	jal	532 <printint>
        i += 1;
 6ee:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 6f0:	8ba6                	mv	s7,s1
      state = 0;
 6f2:	4981                	li	s3,0
 6f4:	b71d                	j	61a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6f6:	008b8493          	addi	s1,s7,8
 6fa:	4681                	li	a3,0
 6fc:	4629                	li	a2,10
 6fe:	000ba583          	lw	a1,0(s7)
 702:	855a                	mv	a0,s6
 704:	e2fff0ef          	jal	532 <printint>
        i += 2;
 708:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 70a:	8ba6                	mv	s7,s1
      state = 0;
 70c:	4981                	li	s3,0
        i += 2;
 70e:	b731                	j	61a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 710:	008b8493          	addi	s1,s7,8
 714:	4681                	li	a3,0
 716:	4641                	li	a2,16
 718:	000ba583          	lw	a1,0(s7)
 71c:	855a                	mv	a0,s6
 71e:	e15ff0ef          	jal	532 <printint>
 722:	8ba6                	mv	s7,s1
      state = 0;
 724:	4981                	li	s3,0
 726:	bdd5                	j	61a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 728:	008b8493          	addi	s1,s7,8
 72c:	4681                	li	a3,0
 72e:	4641                	li	a2,16
 730:	000ba583          	lw	a1,0(s7)
 734:	855a                	mv	a0,s6
 736:	dfdff0ef          	jal	532 <printint>
        i += 1;
 73a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 73c:	8ba6                	mv	s7,s1
      state = 0;
 73e:	4981                	li	s3,0
 740:	bde9                	j	61a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 742:	008b8493          	addi	s1,s7,8
 746:	4681                	li	a3,0
 748:	4641                	li	a2,16
 74a:	000ba583          	lw	a1,0(s7)
 74e:	855a                	mv	a0,s6
 750:	de3ff0ef          	jal	532 <printint>
        i += 2;
 754:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 756:	8ba6                	mv	s7,s1
      state = 0;
 758:	4981                	li	s3,0
        i += 2;
 75a:	b5c1                	j	61a <vprintf+0x44>
 75c:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 75e:	008b8793          	addi	a5,s7,8
 762:	8cbe                	mv	s9,a5
 764:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 768:	03000593          	li	a1,48
 76c:	855a                	mv	a0,s6
 76e:	da7ff0ef          	jal	514 <putc>
  putc(fd, 'x');
 772:	07800593          	li	a1,120
 776:	855a                	mv	a0,s6
 778:	d9dff0ef          	jal	514 <putc>
 77c:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 77e:	00000b97          	auipc	s7,0x0
 782:	36ab8b93          	addi	s7,s7,874 # ae8 <digits>
 786:	03c9d793          	srli	a5,s3,0x3c
 78a:	97de                	add	a5,a5,s7
 78c:	0007c583          	lbu	a1,0(a5)
 790:	855a                	mv	a0,s6
 792:	d83ff0ef          	jal	514 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 796:	0992                	slli	s3,s3,0x4
 798:	34fd                	addiw	s1,s1,-1
 79a:	f4f5                	bnez	s1,786 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 79c:	8be6                	mv	s7,s9
      state = 0;
 79e:	4981                	li	s3,0
 7a0:	6ca2                	ld	s9,8(sp)
 7a2:	bda5                	j	61a <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 7a4:	008b8993          	addi	s3,s7,8
 7a8:	000bb483          	ld	s1,0(s7)
 7ac:	cc91                	beqz	s1,7c8 <vprintf+0x1f2>
        for(; *s; s++)
 7ae:	0004c583          	lbu	a1,0(s1)
 7b2:	c985                	beqz	a1,7e2 <vprintf+0x20c>
          putc(fd, *s);
 7b4:	855a                	mv	a0,s6
 7b6:	d5fff0ef          	jal	514 <putc>
        for(; *s; s++)
 7ba:	0485                	addi	s1,s1,1
 7bc:	0004c583          	lbu	a1,0(s1)
 7c0:	f9f5                	bnez	a1,7b4 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 7c2:	8bce                	mv	s7,s3
      state = 0;
 7c4:	4981                	li	s3,0
 7c6:	bd91                	j	61a <vprintf+0x44>
          s = "(null)";
 7c8:	00000497          	auipc	s1,0x0
 7cc:	31848493          	addi	s1,s1,792 # ae0 <malloc+0x184>
        for(; *s; s++)
 7d0:	02800593          	li	a1,40
 7d4:	b7c5                	j	7b4 <vprintf+0x1de>
        putc(fd, '%');
 7d6:	85be                	mv	a1,a5
 7d8:	855a                	mv	a0,s6
 7da:	d3bff0ef          	jal	514 <putc>
      state = 0;
 7de:	4981                	li	s3,0
 7e0:	bd2d                	j	61a <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 7e2:	8bce                	mv	s7,s3
      state = 0;
 7e4:	4981                	li	s3,0
 7e6:	bd15                	j	61a <vprintf+0x44>
 7e8:	6906                	ld	s2,64(sp)
 7ea:	79e2                	ld	s3,56(sp)
 7ec:	7a42                	ld	s4,48(sp)
 7ee:	7aa2                	ld	s5,40(sp)
 7f0:	7b02                	ld	s6,32(sp)
 7f2:	6be2                	ld	s7,24(sp)
 7f4:	6c42                	ld	s8,16(sp)
    }
  }
}
 7f6:	60e6                	ld	ra,88(sp)
 7f8:	6446                	ld	s0,80(sp)
 7fa:	64a6                	ld	s1,72(sp)
 7fc:	6125                	addi	sp,sp,96
 7fe:	8082                	ret
      if(c0 == 'd'){
 800:	06400713          	li	a4,100
 804:	e6e789e3          	beq	a5,a4,676 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 808:	f9478693          	addi	a3,a5,-108
 80c:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 810:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 812:	4701                	li	a4,0
      } else if(c0 == 'u'){
 814:	07500513          	li	a0,117
 818:	eaa786e3          	beq	a5,a0,6c4 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 81c:	f8b60513          	addi	a0,a2,-117
 820:	e119                	bnez	a0,826 <vprintf+0x250>
 822:	ea069de3          	bnez	a3,6dc <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 826:	f8b58513          	addi	a0,a1,-117
 82a:	e119                	bnez	a0,830 <vprintf+0x25a>
 82c:	ec0715e3          	bnez	a4,6f6 <vprintf+0x120>
      } else if(c0 == 'x'){
 830:	07800513          	li	a0,120
 834:	eca78ee3          	beq	a5,a0,710 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 838:	f8860613          	addi	a2,a2,-120
 83c:	e219                	bnez	a2,842 <vprintf+0x26c>
 83e:	ee0695e3          	bnez	a3,728 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 842:	f8858593          	addi	a1,a1,-120
 846:	e199                	bnez	a1,84c <vprintf+0x276>
 848:	ee071de3          	bnez	a4,742 <vprintf+0x16c>
      } else if(c0 == 'p'){
 84c:	07000713          	li	a4,112
 850:	f0e786e3          	beq	a5,a4,75c <vprintf+0x186>
      } else if(c0 == 's'){
 854:	07300713          	li	a4,115
 858:	f4e786e3          	beq	a5,a4,7a4 <vprintf+0x1ce>
      } else if(c0 == '%'){
 85c:	02500713          	li	a4,37
 860:	f6e78be3          	beq	a5,a4,7d6 <vprintf+0x200>
        putc(fd, '%');
 864:	02500593          	li	a1,37
 868:	855a                	mv	a0,s6
 86a:	cabff0ef          	jal	514 <putc>
        putc(fd, c0);
 86e:	85a6                	mv	a1,s1
 870:	855a                	mv	a0,s6
 872:	ca3ff0ef          	jal	514 <putc>
      state = 0;
 876:	4981                	li	s3,0
 878:	b34d                	j	61a <vprintf+0x44>

000000000000087a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 87a:	715d                	addi	sp,sp,-80
 87c:	ec06                	sd	ra,24(sp)
 87e:	e822                	sd	s0,16(sp)
 880:	1000                	addi	s0,sp,32
 882:	e010                	sd	a2,0(s0)
 884:	e414                	sd	a3,8(s0)
 886:	e818                	sd	a4,16(s0)
 888:	ec1c                	sd	a5,24(s0)
 88a:	03043023          	sd	a6,32(s0)
 88e:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 892:	8622                	mv	a2,s0
 894:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 898:	d3fff0ef          	jal	5d6 <vprintf>
}
 89c:	60e2                	ld	ra,24(sp)
 89e:	6442                	ld	s0,16(sp)
 8a0:	6161                	addi	sp,sp,80
 8a2:	8082                	ret

00000000000008a4 <printf>:

void
printf(const char *fmt, ...)
{
 8a4:	711d                	addi	sp,sp,-96
 8a6:	ec06                	sd	ra,24(sp)
 8a8:	e822                	sd	s0,16(sp)
 8aa:	1000                	addi	s0,sp,32
 8ac:	e40c                	sd	a1,8(s0)
 8ae:	e810                	sd	a2,16(s0)
 8b0:	ec14                	sd	a3,24(s0)
 8b2:	f018                	sd	a4,32(s0)
 8b4:	f41c                	sd	a5,40(s0)
 8b6:	03043823          	sd	a6,48(s0)
 8ba:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 8be:	00840613          	addi	a2,s0,8
 8c2:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8c6:	85aa                	mv	a1,a0
 8c8:	4505                	li	a0,1
 8ca:	d0dff0ef          	jal	5d6 <vprintf>
}
 8ce:	60e2                	ld	ra,24(sp)
 8d0:	6442                	ld	s0,16(sp)
 8d2:	6125                	addi	sp,sp,96
 8d4:	8082                	ret

00000000000008d6 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8d6:	1141                	addi	sp,sp,-16
 8d8:	e406                	sd	ra,8(sp)
 8da:	e022                	sd	s0,0(sp)
 8dc:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 8de:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8e2:	00000797          	auipc	a5,0x0
 8e6:	71e7b783          	ld	a5,1822(a5) # 1000 <freep>
 8ea:	a039                	j	8f8 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8ec:	6398                	ld	a4,0(a5)
 8ee:	00e7e463          	bltu	a5,a4,8f6 <free+0x20>
 8f2:	00e6ea63          	bltu	a3,a4,906 <free+0x30>
{
 8f6:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8f8:	fed7fae3          	bgeu	a5,a3,8ec <free+0x16>
 8fc:	6398                	ld	a4,0(a5)
 8fe:	00e6e463          	bltu	a3,a4,906 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 902:	fee7eae3          	bltu	a5,a4,8f6 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 906:	ff852583          	lw	a1,-8(a0)
 90a:	6390                	ld	a2,0(a5)
 90c:	02059813          	slli	a6,a1,0x20
 910:	01c85713          	srli	a4,a6,0x1c
 914:	9736                	add	a4,a4,a3
 916:	02e60563          	beq	a2,a4,940 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 91a:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 91e:	4790                	lw	a2,8(a5)
 920:	02061593          	slli	a1,a2,0x20
 924:	01c5d713          	srli	a4,a1,0x1c
 928:	973e                	add	a4,a4,a5
 92a:	02e68263          	beq	a3,a4,94e <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 92e:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 930:	00000717          	auipc	a4,0x0
 934:	6cf73823          	sd	a5,1744(a4) # 1000 <freep>
}
 938:	60a2                	ld	ra,8(sp)
 93a:	6402                	ld	s0,0(sp)
 93c:	0141                	addi	sp,sp,16
 93e:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 940:	4618                	lw	a4,8(a2)
 942:	9f2d                	addw	a4,a4,a1
 944:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 948:	6398                	ld	a4,0(a5)
 94a:	6310                	ld	a2,0(a4)
 94c:	b7f9                	j	91a <free+0x44>
    p->s.size += bp->s.size;
 94e:	ff852703          	lw	a4,-8(a0)
 952:	9f31                	addw	a4,a4,a2
 954:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 956:	ff053683          	ld	a3,-16(a0)
 95a:	bfd1                	j	92e <free+0x58>

000000000000095c <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 95c:	7139                	addi	sp,sp,-64
 95e:	fc06                	sd	ra,56(sp)
 960:	f822                	sd	s0,48(sp)
 962:	f04a                	sd	s2,32(sp)
 964:	ec4e                	sd	s3,24(sp)
 966:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 968:	02051993          	slli	s3,a0,0x20
 96c:	0209d993          	srli	s3,s3,0x20
 970:	09bd                	addi	s3,s3,15
 972:	0049d993          	srli	s3,s3,0x4
 976:	2985                	addiw	s3,s3,1
 978:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 97a:	00000517          	auipc	a0,0x0
 97e:	68653503          	ld	a0,1670(a0) # 1000 <freep>
 982:	c905                	beqz	a0,9b2 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 984:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 986:	4798                	lw	a4,8(a5)
 988:	09377663          	bgeu	a4,s3,a14 <malloc+0xb8>
 98c:	f426                	sd	s1,40(sp)
 98e:	e852                	sd	s4,16(sp)
 990:	e456                	sd	s5,8(sp)
 992:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 994:	8a4e                	mv	s4,s3
 996:	6705                	lui	a4,0x1
 998:	00e9f363          	bgeu	s3,a4,99e <malloc+0x42>
 99c:	6a05                	lui	s4,0x1
 99e:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 9a2:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 9a6:	00000497          	auipc	s1,0x0
 9aa:	65a48493          	addi	s1,s1,1626 # 1000 <freep>
  if(p == (char*)-1)
 9ae:	5afd                	li	s5,-1
 9b0:	a83d                	j	9ee <malloc+0x92>
 9b2:	f426                	sd	s1,40(sp)
 9b4:	e852                	sd	s4,16(sp)
 9b6:	e456                	sd	s5,8(sp)
 9b8:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 9ba:	00000797          	auipc	a5,0x0
 9be:	65678793          	addi	a5,a5,1622 # 1010 <base>
 9c2:	00000717          	auipc	a4,0x0
 9c6:	62f73f23          	sd	a5,1598(a4) # 1000 <freep>
 9ca:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9cc:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 9d0:	b7d1                	j	994 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 9d2:	6398                	ld	a4,0(a5)
 9d4:	e118                	sd	a4,0(a0)
 9d6:	a899                	j	a2c <malloc+0xd0>
  hp->s.size = nu;
 9d8:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9dc:	0541                	addi	a0,a0,16
 9de:	ef9ff0ef          	jal	8d6 <free>
  return freep;
 9e2:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 9e4:	c125                	beqz	a0,a44 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9e6:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9e8:	4798                	lw	a4,8(a5)
 9ea:	03277163          	bgeu	a4,s2,a0c <malloc+0xb0>
    if(p == freep)
 9ee:	6098                	ld	a4,0(s1)
 9f0:	853e                	mv	a0,a5
 9f2:	fef71ae3          	bne	a4,a5,9e6 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 9f6:	8552                	mv	a0,s4
 9f8:	b05ff0ef          	jal	4fc <sbrk>
  if(p == (char*)-1)
 9fc:	fd551ee3          	bne	a0,s5,9d8 <malloc+0x7c>
        return 0;
 a00:	4501                	li	a0,0
 a02:	74a2                	ld	s1,40(sp)
 a04:	6a42                	ld	s4,16(sp)
 a06:	6aa2                	ld	s5,8(sp)
 a08:	6b02                	ld	s6,0(sp)
 a0a:	a03d                	j	a38 <malloc+0xdc>
 a0c:	74a2                	ld	s1,40(sp)
 a0e:	6a42                	ld	s4,16(sp)
 a10:	6aa2                	ld	s5,8(sp)
 a12:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a14:	fae90fe3          	beq	s2,a4,9d2 <malloc+0x76>
        p->s.size -= nunits;
 a18:	4137073b          	subw	a4,a4,s3
 a1c:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a1e:	02071693          	slli	a3,a4,0x20
 a22:	01c6d713          	srli	a4,a3,0x1c
 a26:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a28:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a2c:	00000717          	auipc	a4,0x0
 a30:	5ca73a23          	sd	a0,1492(a4) # 1000 <freep>
      return (void*)(p + 1);
 a34:	01078513          	addi	a0,a5,16
  }
}
 a38:	70e2                	ld	ra,56(sp)
 a3a:	7442                	ld	s0,48(sp)
 a3c:	7902                	ld	s2,32(sp)
 a3e:	69e2                	ld	s3,24(sp)
 a40:	6121                	addi	sp,sp,64
 a42:	8082                	ret
 a44:	74a2                	ld	s1,40(sp)
 a46:	6a42                	ld	s4,16(sp)
 a48:	6aa2                	ld	s5,8(sp)
 a4a:	6b02                	ld	s6,0(sp)
 a4c:	b7f5                	j	a38 <malloc+0xdc>
