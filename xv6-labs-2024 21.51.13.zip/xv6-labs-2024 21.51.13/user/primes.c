#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void sieve(int fd) __attribute__((noreturn));

void sieve(int fd)
{
    int prime;
    if(read(fd, &prime, sizeof(int)) != sizeof(int)){
        close(fd);
        exit(0);
    }

    printf("prime %d\n", prime);

    int p[2];
    if(pipe(p) < 0){
        fprintf(2, "pipe failed\n");
        close(fd);
        exit(1);
    }

    int pid = fork();
    if(pid < 0){
        fprintf(2, "fork failed\n");
        close(fd);
        close(p[0]);
        close(p[1]);
        exit(1);
    }

    if(pid == 0){ // 子进程
        close(p[1]); // 关闭写端
        close(fd);   // 关闭父进程传入的管道
        sieve(p[0]); // 递归筛
        // noreturn 属性确保不会执行到这里
    } else { // 父进程
        close(p[0]); // 关闭读端

        int num;
        while(read(fd, &num, sizeof(int)) == sizeof(int)){
            if(num % prime != 0){
                if(write(p[1], &num, sizeof(int)) != sizeof(int)){
                    fprintf(2, "write error\n");
                    close(fd);
                    close(p[1]);
                    exit(1);
                }
            }
        }

        close(fd);    // 关闭输入管道
        close(p[1]);  // 关闭输出管道
        wait(0);      // 等待子进程结束
        exit(0);
    }
}

int main(int argc, char *argv[])
{
    int p[2];

    if(pipe(p) < 0){
        fprintf(2, "pipe failed\n");
        exit(1);
    }

    int pid = fork();
    if(pid < 0){
        fprintf(2, "fork failed\n");
        close(p[0]);
        close(p[1]);
        exit(1);
    }

    if(pid == 0){ // 子进程
        close(p[1]); // 关闭写端
        sieve(p[0]); // 开始筛
        // noreturn 属性确保不会执行到这里
    } else { // 父进程
        close(p[0]); // 关闭读端

        for(int i = 2; i <= 280; i++){
            if(write(p[1], &i, sizeof(int)) != sizeof(int)){
                fprintf(2, "write error\n");
                close(p[1]);
                exit(1);
            }
        }

        close(p[1]); // 关闭写端
        wait(0);     // 等待子进程结束
        exit(0);
    }
}