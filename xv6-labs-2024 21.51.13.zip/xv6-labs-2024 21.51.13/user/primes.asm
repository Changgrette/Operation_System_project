
user/_primes:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <sieve>:
#include "user/user.h"

void sieve(int fd) __attribute__((noreturn));

void sieve(int fd)
{
   0:	715d                	addi	sp,sp,-80
   2:	e486                	sd	ra,72(sp)
   4:	e0a2                	sd	s0,64(sp)
   6:	fc26                	sd	s1,56(sp)
   8:	0880                	addi	s0,sp,80
   a:	84aa                	mv	s1,a0
    int prime;
    if(read(fd, &prime, sizeof(int)) != sizeof(int)){
   c:	4611                	li	a2,4
   e:	fcc40593          	addi	a1,s0,-52
  12:	496000ef          	jal	4a8 <read>
  16:	4791                	li	a5,4
  18:	00f50a63          	beq	a0,a5,2c <sieve+0x2c>
  1c:	f84a                	sd	s2,48(sp)
  1e:	f44e                	sd	s3,40(sp)
        close(fd);
  20:	8526                	mv	a0,s1
  22:	496000ef          	jal	4b8 <close>
        exit(0);
  26:	4501                	li	a0,0
  28:	468000ef          	jal	490 <exit>
    }

    printf("prime %d\n", prime);
  2c:	fcc42583          	lw	a1,-52(s0)
  30:	00001517          	auipc	a0,0x1
  34:	a4050513          	addi	a0,a0,-1472 # a70 <malloc+0xf8>
  38:	089000ef          	jal	8c0 <printf>

    int p[2];
    if(pipe(p) < 0){
  3c:	fc040513          	addi	a0,s0,-64
  40:	460000ef          	jal	4a0 <pipe>
  44:	02054463          	bltz	a0,6c <sieve+0x6c>
        fprintf(2, "pipe failed\n");
        close(fd);
        exit(1);
    }

    int pid = fork();
  48:	440000ef          	jal	488 <fork>
    if(pid < 0){
  4c:	02054f63          	bltz	a0,8a <sieve+0x8a>
  50:	f84a                	sd	s2,48(sp)
  52:	f44e                	sd	s3,40(sp)
        close(p[0]);
        close(p[1]);
        exit(1);
    }

    if(pid == 0){ // 子进程
  54:	e135                	bnez	a0,b8 <sieve+0xb8>
        close(p[1]); // 关闭写端
  56:	fc442503          	lw	a0,-60(s0)
  5a:	45e000ef          	jal	4b8 <close>
        close(fd);   // 关闭父进程传入的管道
  5e:	8526                	mv	a0,s1
  60:	458000ef          	jal	4b8 <close>
        sieve(p[0]); // 递归筛
  64:	fc042503          	lw	a0,-64(s0)
  68:	f99ff0ef          	jal	0 <sieve>
  6c:	f84a                	sd	s2,48(sp)
  6e:	f44e                	sd	s3,40(sp)
        fprintf(2, "pipe failed\n");
  70:	00001597          	auipc	a1,0x1
  74:	a1058593          	addi	a1,a1,-1520 # a80 <malloc+0x108>
  78:	4509                	li	a0,2
  7a:	01d000ef          	jal	896 <fprintf>
        close(fd);
  7e:	8526                	mv	a0,s1
  80:	438000ef          	jal	4b8 <close>
        exit(1);
  84:	4505                	li	a0,1
  86:	40a000ef          	jal	490 <exit>
  8a:	f84a                	sd	s2,48(sp)
  8c:	f44e                	sd	s3,40(sp)
        fprintf(2, "fork failed\n");
  8e:	00001597          	auipc	a1,0x1
  92:	a0258593          	addi	a1,a1,-1534 # a90 <malloc+0x118>
  96:	4509                	li	a0,2
  98:	7fe000ef          	jal	896 <fprintf>
        close(fd);
  9c:	8526                	mv	a0,s1
  9e:	41a000ef          	jal	4b8 <close>
        close(p[0]);
  a2:	fc042503          	lw	a0,-64(s0)
  a6:	412000ef          	jal	4b8 <close>
        close(p[1]);
  aa:	fc442503          	lw	a0,-60(s0)
  ae:	40a000ef          	jal	4b8 <close>
        exit(1);
  b2:	4505                	li	a0,1
  b4:	3dc000ef          	jal	490 <exit>
        // noreturn 属性确保不会执行到这里
    } else { // 父进程
        close(p[0]); // 关闭读端
  b8:	fc042503          	lw	a0,-64(s0)
  bc:	3fc000ef          	jal	4b8 <close>

        int num;
        while(read(fd, &num, sizeof(int)) == sizeof(int)){
  c0:	fbc40993          	addi	s3,s0,-68
  c4:	4911                	li	s2,4
  c6:	864a                	mv	a2,s2
  c8:	85ce                	mv	a1,s3
  ca:	8526                	mv	a0,s1
  cc:	3dc000ef          	jal	4a8 <read>
  d0:	05251463          	bne	a0,s2,118 <sieve+0x118>
            if(num % prime != 0){
  d4:	fbc42783          	lw	a5,-68(s0)
  d8:	fcc42703          	lw	a4,-52(s0)
  dc:	02e7e7bb          	remw	a5,a5,a4
  e0:	d3fd                	beqz	a5,c6 <sieve+0xc6>
                if(write(p[1], &num, sizeof(int)) != sizeof(int)){
  e2:	4611                	li	a2,4
  e4:	fbc40593          	addi	a1,s0,-68
  e8:	fc442503          	lw	a0,-60(s0)
  ec:	3c4000ef          	jal	4b0 <write>
  f0:	4791                	li	a5,4
  f2:	fcf50ae3          	beq	a0,a5,c6 <sieve+0xc6>
                    fprintf(2, "write error\n");
  f6:	00001597          	auipc	a1,0x1
  fa:	9aa58593          	addi	a1,a1,-1622 # aa0 <malloc+0x128>
  fe:	4509                	li	a0,2
 100:	796000ef          	jal	896 <fprintf>
                    close(fd);
 104:	8526                	mv	a0,s1
 106:	3b2000ef          	jal	4b8 <close>
                    close(p[1]);
 10a:	fc442503          	lw	a0,-60(s0)
 10e:	3aa000ef          	jal	4b8 <close>
                    exit(1);
 112:	4505                	li	a0,1
 114:	37c000ef          	jal	490 <exit>
                }
            }
        }

        close(fd);    // 关闭输入管道
 118:	8526                	mv	a0,s1
 11a:	39e000ef          	jal	4b8 <close>
        close(p[1]);  // 关闭输出管道
 11e:	fc442503          	lw	a0,-60(s0)
 122:	396000ef          	jal	4b8 <close>
        wait(0);      // 等待子进程结束
 126:	4501                	li	a0,0
 128:	370000ef          	jal	498 <wait>
        exit(0);
 12c:	4501                	li	a0,0
 12e:	362000ef          	jal	490 <exit>

0000000000000132 <main>:
    }
}

int main(int argc, char *argv[])
{
 132:	7139                	addi	sp,sp,-64
 134:	fc06                	sd	ra,56(sp)
 136:	f822                	sd	s0,48(sp)
 138:	f426                	sd	s1,40(sp)
 13a:	f04a                	sd	s2,32(sp)
 13c:	ec4e                	sd	s3,24(sp)
 13e:	0080                	addi	s0,sp,64
    int p[2];

    if(pipe(p) < 0){
 140:	fc840513          	addi	a0,s0,-56
 144:	35c000ef          	jal	4a0 <pipe>
 148:	00054f63          	bltz	a0,166 <main+0x34>
        fprintf(2, "pipe failed\n");
        exit(1);
    }

    int pid = fork();
 14c:	33c000ef          	jal	488 <fork>
    if(pid < 0){
 150:	02054563          	bltz	a0,17a <main+0x48>
        close(p[0]);
        close(p[1]);
        exit(1);
    }

    if(pid == 0){ // 子进程
 154:	e529                	bnez	a0,19e <main+0x6c>
        close(p[1]); // 关闭写端
 156:	fcc42503          	lw	a0,-52(s0)
 15a:	35e000ef          	jal	4b8 <close>
        sieve(p[0]); // 开始筛
 15e:	fc842503          	lw	a0,-56(s0)
 162:	e9fff0ef          	jal	0 <sieve>
        fprintf(2, "pipe failed\n");
 166:	00001597          	auipc	a1,0x1
 16a:	91a58593          	addi	a1,a1,-1766 # a80 <malloc+0x108>
 16e:	4509                	li	a0,2
 170:	726000ef          	jal	896 <fprintf>
        exit(1);
 174:	4505                	li	a0,1
 176:	31a000ef          	jal	490 <exit>
        fprintf(2, "fork failed\n");
 17a:	00001597          	auipc	a1,0x1
 17e:	91658593          	addi	a1,a1,-1770 # a90 <malloc+0x118>
 182:	4509                	li	a0,2
 184:	712000ef          	jal	896 <fprintf>
        close(p[0]);
 188:	fc842503          	lw	a0,-56(s0)
 18c:	32c000ef          	jal	4b8 <close>
        close(p[1]);
 190:	fcc42503          	lw	a0,-52(s0)
 194:	324000ef          	jal	4b8 <close>
        exit(1);
 198:	4505                	li	a0,1
 19a:	2f6000ef          	jal	490 <exit>
        // noreturn 属性确保不会执行到这里
    } else { // 父进程
        close(p[0]); // 关闭读端
 19e:	fc842503          	lw	a0,-56(s0)
 1a2:	316000ef          	jal	4b8 <close>

        for(int i = 2; i <= 280; i++){
 1a6:	4789                	li	a5,2
 1a8:	fcf42223          	sw	a5,-60(s0)
            if(write(p[1], &i, sizeof(int)) != sizeof(int)){
 1ac:	fc440913          	addi	s2,s0,-60
 1b0:	4491                	li	s1,4
        for(int i = 2; i <= 280; i++){
 1b2:	11800993          	li	s3,280
            if(write(p[1], &i, sizeof(int)) != sizeof(int)){
 1b6:	8626                	mv	a2,s1
 1b8:	85ca                	mv	a1,s2
 1ba:	fcc42503          	lw	a0,-52(s0)
 1be:	2f2000ef          	jal	4b0 <write>
 1c2:	02951363          	bne	a0,s1,1e8 <main+0xb6>
        for(int i = 2; i <= 280; i++){
 1c6:	fc442783          	lw	a5,-60(s0)
 1ca:	2785                	addiw	a5,a5,1
 1cc:	fcf42223          	sw	a5,-60(s0)
 1d0:	fef9d3e3          	bge	s3,a5,1b6 <main+0x84>
                close(p[1]);
                exit(1);
            }
        }

        close(p[1]); // 关闭写端
 1d4:	fcc42503          	lw	a0,-52(s0)
 1d8:	2e0000ef          	jal	4b8 <close>
        wait(0);     // 等待子进程结束
 1dc:	4501                	li	a0,0
 1de:	2ba000ef          	jal	498 <wait>
        exit(0);
 1e2:	4501                	li	a0,0
 1e4:	2ac000ef          	jal	490 <exit>
                fprintf(2, "write error\n");
 1e8:	00001597          	auipc	a1,0x1
 1ec:	8b858593          	addi	a1,a1,-1864 # aa0 <malloc+0x128>
 1f0:	4509                	li	a0,2
 1f2:	6a4000ef          	jal	896 <fprintf>
                close(p[1]);
 1f6:	fcc42503          	lw	a0,-52(s0)
 1fa:	2be000ef          	jal	4b8 <close>
                exit(1);
 1fe:	4505                	li	a0,1
 200:	290000ef          	jal	490 <exit>

0000000000000204 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 204:	1141                	addi	sp,sp,-16
 206:	e406                	sd	ra,8(sp)
 208:	e022                	sd	s0,0(sp)
 20a:	0800                	addi	s0,sp,16
  extern int main();
  main();
 20c:	f27ff0ef          	jal	132 <main>
  exit(0);
 210:	4501                	li	a0,0
 212:	27e000ef          	jal	490 <exit>

0000000000000216 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 216:	1141                	addi	sp,sp,-16
 218:	e406                	sd	ra,8(sp)
 21a:	e022                	sd	s0,0(sp)
 21c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 21e:	87aa                	mv	a5,a0
 220:	0585                	addi	a1,a1,1
 222:	0785                	addi	a5,a5,1
 224:	fff5c703          	lbu	a4,-1(a1)
 228:	fee78fa3          	sb	a4,-1(a5)
 22c:	fb75                	bnez	a4,220 <strcpy+0xa>
    ;
  return os;
}
 22e:	60a2                	ld	ra,8(sp)
 230:	6402                	ld	s0,0(sp)
 232:	0141                	addi	sp,sp,16
 234:	8082                	ret

0000000000000236 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 236:	1141                	addi	sp,sp,-16
 238:	e406                	sd	ra,8(sp)
 23a:	e022                	sd	s0,0(sp)
 23c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 23e:	00054783          	lbu	a5,0(a0)
 242:	cb91                	beqz	a5,256 <strcmp+0x20>
 244:	0005c703          	lbu	a4,0(a1)
 248:	00f71763          	bne	a4,a5,256 <strcmp+0x20>
    p++, q++;
 24c:	0505                	addi	a0,a0,1
 24e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 250:	00054783          	lbu	a5,0(a0)
 254:	fbe5                	bnez	a5,244 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 256:	0005c503          	lbu	a0,0(a1)
}
 25a:	40a7853b          	subw	a0,a5,a0
 25e:	60a2                	ld	ra,8(sp)
 260:	6402                	ld	s0,0(sp)
 262:	0141                	addi	sp,sp,16
 264:	8082                	ret

0000000000000266 <strlen>:

uint
strlen(const char *s)
{
 266:	1141                	addi	sp,sp,-16
 268:	e406                	sd	ra,8(sp)
 26a:	e022                	sd	s0,0(sp)
 26c:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 26e:	00054783          	lbu	a5,0(a0)
 272:	cf91                	beqz	a5,28e <strlen+0x28>
 274:	00150793          	addi	a5,a0,1
 278:	86be                	mv	a3,a5
 27a:	0785                	addi	a5,a5,1
 27c:	fff7c703          	lbu	a4,-1(a5)
 280:	ff65                	bnez	a4,278 <strlen+0x12>
 282:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 286:	60a2                	ld	ra,8(sp)
 288:	6402                	ld	s0,0(sp)
 28a:	0141                	addi	sp,sp,16
 28c:	8082                	ret
  for(n = 0; s[n]; n++)
 28e:	4501                	li	a0,0
 290:	bfdd                	j	286 <strlen+0x20>

0000000000000292 <memset>:

void*
memset(void *dst, int c, uint n)
{
 292:	1141                	addi	sp,sp,-16
 294:	e406                	sd	ra,8(sp)
 296:	e022                	sd	s0,0(sp)
 298:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 29a:	ca19                	beqz	a2,2b0 <memset+0x1e>
 29c:	87aa                	mv	a5,a0
 29e:	1602                	slli	a2,a2,0x20
 2a0:	9201                	srli	a2,a2,0x20
 2a2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2a6:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2aa:	0785                	addi	a5,a5,1
 2ac:	fee79de3          	bne	a5,a4,2a6 <memset+0x14>
  }
  return dst;
}
 2b0:	60a2                	ld	ra,8(sp)
 2b2:	6402                	ld	s0,0(sp)
 2b4:	0141                	addi	sp,sp,16
 2b6:	8082                	ret

00000000000002b8 <strchr>:

char*
strchr(const char *s, char c)
{
 2b8:	1141                	addi	sp,sp,-16
 2ba:	e406                	sd	ra,8(sp)
 2bc:	e022                	sd	s0,0(sp)
 2be:	0800                	addi	s0,sp,16
  for(; *s; s++)
 2c0:	00054783          	lbu	a5,0(a0)
 2c4:	cf81                	beqz	a5,2dc <strchr+0x24>
    if(*s == c)
 2c6:	00f58763          	beq	a1,a5,2d4 <strchr+0x1c>
  for(; *s; s++)
 2ca:	0505                	addi	a0,a0,1
 2cc:	00054783          	lbu	a5,0(a0)
 2d0:	fbfd                	bnez	a5,2c6 <strchr+0xe>
      return (char*)s;
  return 0;
 2d2:	4501                	li	a0,0
}
 2d4:	60a2                	ld	ra,8(sp)
 2d6:	6402                	ld	s0,0(sp)
 2d8:	0141                	addi	sp,sp,16
 2da:	8082                	ret
  return 0;
 2dc:	4501                	li	a0,0
 2de:	bfdd                	j	2d4 <strchr+0x1c>

00000000000002e0 <gets>:

char*
gets(char *buf, int max)
{
 2e0:	711d                	addi	sp,sp,-96
 2e2:	ec86                	sd	ra,88(sp)
 2e4:	e8a2                	sd	s0,80(sp)
 2e6:	e4a6                	sd	s1,72(sp)
 2e8:	e0ca                	sd	s2,64(sp)
 2ea:	fc4e                	sd	s3,56(sp)
 2ec:	f852                	sd	s4,48(sp)
 2ee:	f456                	sd	s5,40(sp)
 2f0:	f05a                	sd	s6,32(sp)
 2f2:	ec5e                	sd	s7,24(sp)
 2f4:	e862                	sd	s8,16(sp)
 2f6:	1080                	addi	s0,sp,96
 2f8:	8baa                	mv	s7,a0
 2fa:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 2fc:	892a                	mv	s2,a0
 2fe:	4481                	li	s1,0
    cc = read(0, &c, 1);
 300:	faf40b13          	addi	s6,s0,-81
 304:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 306:	8c26                	mv	s8,s1
 308:	0014899b          	addiw	s3,s1,1
 30c:	84ce                	mv	s1,s3
 30e:	0349d463          	bge	s3,s4,336 <gets+0x56>
    cc = read(0, &c, 1);
 312:	8656                	mv	a2,s5
 314:	85da                	mv	a1,s6
 316:	4501                	li	a0,0
 318:	190000ef          	jal	4a8 <read>
    if(cc < 1)
 31c:	00a05d63          	blez	a0,336 <gets+0x56>
      break;
    buf[i++] = c;
 320:	faf44783          	lbu	a5,-81(s0)
 324:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 328:	0905                	addi	s2,s2,1
 32a:	ff678713          	addi	a4,a5,-10
 32e:	c319                	beqz	a4,334 <gets+0x54>
 330:	17cd                	addi	a5,a5,-13
 332:	fbf1                	bnez	a5,306 <gets+0x26>
    buf[i++] = c;
 334:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 336:	9c5e                	add	s8,s8,s7
 338:	000c0023          	sb	zero,0(s8)
  return buf;
}
 33c:	855e                	mv	a0,s7
 33e:	60e6                	ld	ra,88(sp)
 340:	6446                	ld	s0,80(sp)
 342:	64a6                	ld	s1,72(sp)
 344:	6906                	ld	s2,64(sp)
 346:	79e2                	ld	s3,56(sp)
 348:	7a42                	ld	s4,48(sp)
 34a:	7aa2                	ld	s5,40(sp)
 34c:	7b02                	ld	s6,32(sp)
 34e:	6be2                	ld	s7,24(sp)
 350:	6c42                	ld	s8,16(sp)
 352:	6125                	addi	sp,sp,96
 354:	8082                	ret

0000000000000356 <stat>:

int
stat(const char *n, struct stat *st)
{
 356:	1101                	addi	sp,sp,-32
 358:	ec06                	sd	ra,24(sp)
 35a:	e822                	sd	s0,16(sp)
 35c:	e04a                	sd	s2,0(sp)
 35e:	1000                	addi	s0,sp,32
 360:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 362:	4581                	li	a1,0
 364:	16c000ef          	jal	4d0 <open>
  if(fd < 0)
 368:	02054263          	bltz	a0,38c <stat+0x36>
 36c:	e426                	sd	s1,8(sp)
 36e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 370:	85ca                	mv	a1,s2
 372:	176000ef          	jal	4e8 <fstat>
 376:	892a                	mv	s2,a0
  close(fd);
 378:	8526                	mv	a0,s1
 37a:	13e000ef          	jal	4b8 <close>
  return r;
 37e:	64a2                	ld	s1,8(sp)
}
 380:	854a                	mv	a0,s2
 382:	60e2                	ld	ra,24(sp)
 384:	6442                	ld	s0,16(sp)
 386:	6902                	ld	s2,0(sp)
 388:	6105                	addi	sp,sp,32
 38a:	8082                	ret
    return -1;
 38c:	57fd                	li	a5,-1
 38e:	893e                	mv	s2,a5
 390:	bfc5                	j	380 <stat+0x2a>

0000000000000392 <atoi>:

int
atoi(const char *s)
{
 392:	1141                	addi	sp,sp,-16
 394:	e406                	sd	ra,8(sp)
 396:	e022                	sd	s0,0(sp)
 398:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 39a:	00054683          	lbu	a3,0(a0)
 39e:	fd06879b          	addiw	a5,a3,-48
 3a2:	0ff7f793          	zext.b	a5,a5
 3a6:	4625                	li	a2,9
 3a8:	02f66963          	bltu	a2,a5,3da <atoi+0x48>
 3ac:	872a                	mv	a4,a0
  n = 0;
 3ae:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 3b0:	0705                	addi	a4,a4,1
 3b2:	0025179b          	slliw	a5,a0,0x2
 3b6:	9fa9                	addw	a5,a5,a0
 3b8:	0017979b          	slliw	a5,a5,0x1
 3bc:	9fb5                	addw	a5,a5,a3
 3be:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 3c2:	00074683          	lbu	a3,0(a4)
 3c6:	fd06879b          	addiw	a5,a3,-48
 3ca:	0ff7f793          	zext.b	a5,a5
 3ce:	fef671e3          	bgeu	a2,a5,3b0 <atoi+0x1e>
  return n;
}
 3d2:	60a2                	ld	ra,8(sp)
 3d4:	6402                	ld	s0,0(sp)
 3d6:	0141                	addi	sp,sp,16
 3d8:	8082                	ret
  n = 0;
 3da:	4501                	li	a0,0
 3dc:	bfdd                	j	3d2 <atoi+0x40>

00000000000003de <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3de:	1141                	addi	sp,sp,-16
 3e0:	e406                	sd	ra,8(sp)
 3e2:	e022                	sd	s0,0(sp)
 3e4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 3e6:	02b57563          	bgeu	a0,a1,410 <memmove+0x32>
    while(n-- > 0)
 3ea:	00c05f63          	blez	a2,408 <memmove+0x2a>
 3ee:	1602                	slli	a2,a2,0x20
 3f0:	9201                	srli	a2,a2,0x20
 3f2:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 3f6:	872a                	mv	a4,a0
      *dst++ = *src++;
 3f8:	0585                	addi	a1,a1,1
 3fa:	0705                	addi	a4,a4,1
 3fc:	fff5c683          	lbu	a3,-1(a1)
 400:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 404:	fee79ae3          	bne	a5,a4,3f8 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 408:	60a2                	ld	ra,8(sp)
 40a:	6402                	ld	s0,0(sp)
 40c:	0141                	addi	sp,sp,16
 40e:	8082                	ret
    while(n-- > 0)
 410:	fec05ce3          	blez	a2,408 <memmove+0x2a>
    dst += n;
 414:	00c50733          	add	a4,a0,a2
    src += n;
 418:	95b2                	add	a1,a1,a2
 41a:	fff6079b          	addiw	a5,a2,-1
 41e:	1782                	slli	a5,a5,0x20
 420:	9381                	srli	a5,a5,0x20
 422:	fff7c793          	not	a5,a5
 426:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 428:	15fd                	addi	a1,a1,-1
 42a:	177d                	addi	a4,a4,-1
 42c:	0005c683          	lbu	a3,0(a1)
 430:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 434:	fef71ae3          	bne	a4,a5,428 <memmove+0x4a>
 438:	bfc1                	j	408 <memmove+0x2a>

000000000000043a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 43a:	1141                	addi	sp,sp,-16
 43c:	e406                	sd	ra,8(sp)
 43e:	e022                	sd	s0,0(sp)
 440:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 442:	c61d                	beqz	a2,470 <memcmp+0x36>
 444:	1602                	slli	a2,a2,0x20
 446:	9201                	srli	a2,a2,0x20
 448:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 44c:	00054783          	lbu	a5,0(a0)
 450:	0005c703          	lbu	a4,0(a1)
 454:	00e79863          	bne	a5,a4,464 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 458:	0505                	addi	a0,a0,1
    p2++;
 45a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 45c:	fed518e3          	bne	a0,a3,44c <memcmp+0x12>
  }
  return 0;
 460:	4501                	li	a0,0
 462:	a019                	j	468 <memcmp+0x2e>
      return *p1 - *p2;
 464:	40e7853b          	subw	a0,a5,a4
}
 468:	60a2                	ld	ra,8(sp)
 46a:	6402                	ld	s0,0(sp)
 46c:	0141                	addi	sp,sp,16
 46e:	8082                	ret
  return 0;
 470:	4501                	li	a0,0
 472:	bfdd                	j	468 <memcmp+0x2e>

0000000000000474 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 474:	1141                	addi	sp,sp,-16
 476:	e406                	sd	ra,8(sp)
 478:	e022                	sd	s0,0(sp)
 47a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 47c:	f63ff0ef          	jal	3de <memmove>
}
 480:	60a2                	ld	ra,8(sp)
 482:	6402                	ld	s0,0(sp)
 484:	0141                	addi	sp,sp,16
 486:	8082                	ret

0000000000000488 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 488:	4885                	li	a7,1
 ecall
 48a:	00000073          	ecall
 ret
 48e:	8082                	ret

0000000000000490 <exit>:
.global exit
exit:
 li a7, SYS_exit
 490:	4889                	li	a7,2
 ecall
 492:	00000073          	ecall
 ret
 496:	8082                	ret

0000000000000498 <wait>:
.global wait
wait:
 li a7, SYS_wait
 498:	488d                	li	a7,3
 ecall
 49a:	00000073          	ecall
 ret
 49e:	8082                	ret

00000000000004a0 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4a0:	4891                	li	a7,4
 ecall
 4a2:	00000073          	ecall
 ret
 4a6:	8082                	ret

00000000000004a8 <read>:
.global read
read:
 li a7, SYS_read
 4a8:	4895                	li	a7,5
 ecall
 4aa:	00000073          	ecall
 ret
 4ae:	8082                	ret

00000000000004b0 <write>:
.global write
write:
 li a7, SYS_write
 4b0:	48c1                	li	a7,16
 ecall
 4b2:	00000073          	ecall
 ret
 4b6:	8082                	ret

00000000000004b8 <close>:
.global close
close:
 li a7, SYS_close
 4b8:	48d5                	li	a7,21
 ecall
 4ba:	00000073          	ecall
 ret
 4be:	8082                	ret

00000000000004c0 <kill>:
.global kill
kill:
 li a7, SYS_kill
 4c0:	4899                	li	a7,6
 ecall
 4c2:	00000073          	ecall
 ret
 4c6:	8082                	ret

00000000000004c8 <exec>:
.global exec
exec:
 li a7, SYS_exec
 4c8:	489d                	li	a7,7
 ecall
 4ca:	00000073          	ecall
 ret
 4ce:	8082                	ret

00000000000004d0 <open>:
.global open
open:
 li a7, SYS_open
 4d0:	48bd                	li	a7,15
 ecall
 4d2:	00000073          	ecall
 ret
 4d6:	8082                	ret

00000000000004d8 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 4d8:	48c5                	li	a7,17
 ecall
 4da:	00000073          	ecall
 ret
 4de:	8082                	ret

00000000000004e0 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4e0:	48c9                	li	a7,18
 ecall
 4e2:	00000073          	ecall
 ret
 4e6:	8082                	ret

00000000000004e8 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4e8:	48a1                	li	a7,8
 ecall
 4ea:	00000073          	ecall
 ret
 4ee:	8082                	ret

00000000000004f0 <link>:
.global link
link:
 li a7, SYS_link
 4f0:	48cd                	li	a7,19
 ecall
 4f2:	00000073          	ecall
 ret
 4f6:	8082                	ret

00000000000004f8 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4f8:	48d1                	li	a7,20
 ecall
 4fa:	00000073          	ecall
 ret
 4fe:	8082                	ret

0000000000000500 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 500:	48a5                	li	a7,9
 ecall
 502:	00000073          	ecall
 ret
 506:	8082                	ret

0000000000000508 <dup>:
.global dup
dup:
 li a7, SYS_dup
 508:	48a9                	li	a7,10
 ecall
 50a:	00000073          	ecall
 ret
 50e:	8082                	ret

0000000000000510 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 510:	48ad                	li	a7,11
 ecall
 512:	00000073          	ecall
 ret
 516:	8082                	ret

0000000000000518 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 518:	48b1                	li	a7,12
 ecall
 51a:	00000073          	ecall
 ret
 51e:	8082                	ret

0000000000000520 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 520:	48b5                	li	a7,13
 ecall
 522:	00000073          	ecall
 ret
 526:	8082                	ret

0000000000000528 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 528:	48b9                	li	a7,14
 ecall
 52a:	00000073          	ecall
 ret
 52e:	8082                	ret

0000000000000530 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 530:	1101                	addi	sp,sp,-32
 532:	ec06                	sd	ra,24(sp)
 534:	e822                	sd	s0,16(sp)
 536:	1000                	addi	s0,sp,32
 538:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 53c:	4605                	li	a2,1
 53e:	fef40593          	addi	a1,s0,-17
 542:	f6fff0ef          	jal	4b0 <write>
}
 546:	60e2                	ld	ra,24(sp)
 548:	6442                	ld	s0,16(sp)
 54a:	6105                	addi	sp,sp,32
 54c:	8082                	ret

000000000000054e <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 54e:	7139                	addi	sp,sp,-64
 550:	fc06                	sd	ra,56(sp)
 552:	f822                	sd	s0,48(sp)
 554:	f04a                	sd	s2,32(sp)
 556:	ec4e                	sd	s3,24(sp)
 558:	0080                	addi	s0,sp,64
 55a:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 55c:	cac9                	beqz	a3,5ee <printint+0xa0>
 55e:	01f5d79b          	srliw	a5,a1,0x1f
 562:	c7d1                	beqz	a5,5ee <printint+0xa0>
    neg = 1;
    x = -xx;
 564:	40b005bb          	negw	a1,a1
    neg = 1;
 568:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 56a:	fc040993          	addi	s3,s0,-64
  neg = 0;
 56e:	86ce                	mv	a3,s3
  i = 0;
 570:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 572:	00000817          	auipc	a6,0x0
 576:	54680813          	addi	a6,a6,1350 # ab8 <digits>
 57a:	88ba                	mv	a7,a4
 57c:	0017051b          	addiw	a0,a4,1
 580:	872a                	mv	a4,a0
 582:	02c5f7bb          	remuw	a5,a1,a2
 586:	1782                	slli	a5,a5,0x20
 588:	9381                	srli	a5,a5,0x20
 58a:	97c2                	add	a5,a5,a6
 58c:	0007c783          	lbu	a5,0(a5)
 590:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 594:	87ae                	mv	a5,a1
 596:	02c5d5bb          	divuw	a1,a1,a2
 59a:	0685                	addi	a3,a3,1
 59c:	fcc7ffe3          	bgeu	a5,a2,57a <printint+0x2c>
  if(neg)
 5a0:	00030c63          	beqz	t1,5b8 <printint+0x6a>
    buf[i++] = '-';
 5a4:	fd050793          	addi	a5,a0,-48
 5a8:	00878533          	add	a0,a5,s0
 5ac:	02d00793          	li	a5,45
 5b0:	fef50823          	sb	a5,-16(a0)
 5b4:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 5b8:	02e05563          	blez	a4,5e2 <printint+0x94>
 5bc:	f426                	sd	s1,40(sp)
 5be:	377d                	addiw	a4,a4,-1
 5c0:	00e984b3          	add	s1,s3,a4
 5c4:	19fd                	addi	s3,s3,-1
 5c6:	99ba                	add	s3,s3,a4
 5c8:	1702                	slli	a4,a4,0x20
 5ca:	9301                	srli	a4,a4,0x20
 5cc:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 5d0:	0004c583          	lbu	a1,0(s1)
 5d4:	854a                	mv	a0,s2
 5d6:	f5bff0ef          	jal	530 <putc>
  while(--i >= 0)
 5da:	14fd                	addi	s1,s1,-1
 5dc:	ff349ae3          	bne	s1,s3,5d0 <printint+0x82>
 5e0:	74a2                	ld	s1,40(sp)
}
 5e2:	70e2                	ld	ra,56(sp)
 5e4:	7442                	ld	s0,48(sp)
 5e6:	7902                	ld	s2,32(sp)
 5e8:	69e2                	ld	s3,24(sp)
 5ea:	6121                	addi	sp,sp,64
 5ec:	8082                	ret
  neg = 0;
 5ee:	4301                	li	t1,0
 5f0:	bfad                	j	56a <printint+0x1c>

00000000000005f2 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5f2:	711d                	addi	sp,sp,-96
 5f4:	ec86                	sd	ra,88(sp)
 5f6:	e8a2                	sd	s0,80(sp)
 5f8:	e4a6                	sd	s1,72(sp)
 5fa:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5fc:	0005c483          	lbu	s1,0(a1)
 600:	20048963          	beqz	s1,812 <vprintf+0x220>
 604:	e0ca                	sd	s2,64(sp)
 606:	fc4e                	sd	s3,56(sp)
 608:	f852                	sd	s4,48(sp)
 60a:	f456                	sd	s5,40(sp)
 60c:	f05a                	sd	s6,32(sp)
 60e:	ec5e                	sd	s7,24(sp)
 610:	e862                	sd	s8,16(sp)
 612:	8b2a                	mv	s6,a0
 614:	8a2e                	mv	s4,a1
 616:	8bb2                	mv	s7,a2
  state = 0;
 618:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 61a:	4901                	li	s2,0
 61c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 61e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 622:	06400c13          	li	s8,100
 626:	a00d                	j	648 <vprintf+0x56>
        putc(fd, c0);
 628:	85a6                	mv	a1,s1
 62a:	855a                	mv	a0,s6
 62c:	f05ff0ef          	jal	530 <putc>
 630:	a019                	j	636 <vprintf+0x44>
    } else if(state == '%'){
 632:	03598363          	beq	s3,s5,658 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 636:	0019079b          	addiw	a5,s2,1
 63a:	893e                	mv	s2,a5
 63c:	873e                	mv	a4,a5
 63e:	97d2                	add	a5,a5,s4
 640:	0007c483          	lbu	s1,0(a5)
 644:	1c048063          	beqz	s1,804 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 648:	0004879b          	sext.w	a5,s1
    if(state == 0){
 64c:	fe0993e3          	bnez	s3,632 <vprintf+0x40>
      if(c0 == '%'){
 650:	fd579ce3          	bne	a5,s5,628 <vprintf+0x36>
        state = '%';
 654:	89be                	mv	s3,a5
 656:	b7c5                	j	636 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 658:	00ea06b3          	add	a3,s4,a4
 65c:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 660:	1a060e63          	beqz	a2,81c <vprintf+0x22a>
      if(c0 == 'd'){
 664:	03878763          	beq	a5,s8,692 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 668:	f9478693          	addi	a3,a5,-108
 66c:	0016b693          	seqz	a3,a3
 670:	f9c60593          	addi	a1,a2,-100
 674:	e99d                	bnez	a1,6aa <vprintf+0xb8>
 676:	ca95                	beqz	a3,6aa <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 678:	008b8493          	addi	s1,s7,8
 67c:	4685                	li	a3,1
 67e:	4629                	li	a2,10
 680:	000ba583          	lw	a1,0(s7)
 684:	855a                	mv	a0,s6
 686:	ec9ff0ef          	jal	54e <printint>
        i += 1;
 68a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 68c:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 68e:	4981                	li	s3,0
 690:	b75d                	j	636 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 692:	008b8493          	addi	s1,s7,8
 696:	4685                	li	a3,1
 698:	4629                	li	a2,10
 69a:	000ba583          	lw	a1,0(s7)
 69e:	855a                	mv	a0,s6
 6a0:	eafff0ef          	jal	54e <printint>
 6a4:	8ba6                	mv	s7,s1
      state = 0;
 6a6:	4981                	li	s3,0
 6a8:	b779                	j	636 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 6aa:	9752                	add	a4,a4,s4
 6ac:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6b0:	f9460713          	addi	a4,a2,-108
 6b4:	00173713          	seqz	a4,a4
 6b8:	8f75                	and	a4,a4,a3
 6ba:	f9c58513          	addi	a0,a1,-100
 6be:	16051963          	bnez	a0,830 <vprintf+0x23e>
 6c2:	16070763          	beqz	a4,830 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6c6:	008b8493          	addi	s1,s7,8
 6ca:	4685                	li	a3,1
 6cc:	4629                	li	a2,10
 6ce:	000ba583          	lw	a1,0(s7)
 6d2:	855a                	mv	a0,s6
 6d4:	e7bff0ef          	jal	54e <printint>
        i += 2;
 6d8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 6da:	8ba6                	mv	s7,s1
      state = 0;
 6dc:	4981                	li	s3,0
        i += 2;
 6de:	bfa1                	j	636 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 6e0:	008b8493          	addi	s1,s7,8
 6e4:	4681                	li	a3,0
 6e6:	4629                	li	a2,10
 6e8:	000ba583          	lw	a1,0(s7)
 6ec:	855a                	mv	a0,s6
 6ee:	e61ff0ef          	jal	54e <printint>
 6f2:	8ba6                	mv	s7,s1
      state = 0;
 6f4:	4981                	li	s3,0
 6f6:	b781                	j	636 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6f8:	008b8493          	addi	s1,s7,8
 6fc:	4681                	li	a3,0
 6fe:	4629                	li	a2,10
 700:	000ba583          	lw	a1,0(s7)
 704:	855a                	mv	a0,s6
 706:	e49ff0ef          	jal	54e <printint>
        i += 1;
 70a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 70c:	8ba6                	mv	s7,s1
      state = 0;
 70e:	4981                	li	s3,0
 710:	b71d                	j	636 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 712:	008b8493          	addi	s1,s7,8
 716:	4681                	li	a3,0
 718:	4629                	li	a2,10
 71a:	000ba583          	lw	a1,0(s7)
 71e:	855a                	mv	a0,s6
 720:	e2fff0ef          	jal	54e <printint>
        i += 2;
 724:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 726:	8ba6                	mv	s7,s1
      state = 0;
 728:	4981                	li	s3,0
        i += 2;
 72a:	b731                	j	636 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 72c:	008b8493          	addi	s1,s7,8
 730:	4681                	li	a3,0
 732:	4641                	li	a2,16
 734:	000ba583          	lw	a1,0(s7)
 738:	855a                	mv	a0,s6
 73a:	e15ff0ef          	jal	54e <printint>
 73e:	8ba6                	mv	s7,s1
      state = 0;
 740:	4981                	li	s3,0
 742:	bdd5                	j	636 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 744:	008b8493          	addi	s1,s7,8
 748:	4681                	li	a3,0
 74a:	4641                	li	a2,16
 74c:	000ba583          	lw	a1,0(s7)
 750:	855a                	mv	a0,s6
 752:	dfdff0ef          	jal	54e <printint>
        i += 1;
 756:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 758:	8ba6                	mv	s7,s1
      state = 0;
 75a:	4981                	li	s3,0
 75c:	bde9                	j	636 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 75e:	008b8493          	addi	s1,s7,8
 762:	4681                	li	a3,0
 764:	4641                	li	a2,16
 766:	000ba583          	lw	a1,0(s7)
 76a:	855a                	mv	a0,s6
 76c:	de3ff0ef          	jal	54e <printint>
        i += 2;
 770:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 772:	8ba6                	mv	s7,s1
      state = 0;
 774:	4981                	li	s3,0
        i += 2;
 776:	b5c1                	j	636 <vprintf+0x44>
 778:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 77a:	008b8793          	addi	a5,s7,8
 77e:	8cbe                	mv	s9,a5
 780:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 784:	03000593          	li	a1,48
 788:	855a                	mv	a0,s6
 78a:	da7ff0ef          	jal	530 <putc>
  putc(fd, 'x');
 78e:	07800593          	li	a1,120
 792:	855a                	mv	a0,s6
 794:	d9dff0ef          	jal	530 <putc>
 798:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 79a:	00000b97          	auipc	s7,0x0
 79e:	31eb8b93          	addi	s7,s7,798 # ab8 <digits>
 7a2:	03c9d793          	srli	a5,s3,0x3c
 7a6:	97de                	add	a5,a5,s7
 7a8:	0007c583          	lbu	a1,0(a5)
 7ac:	855a                	mv	a0,s6
 7ae:	d83ff0ef          	jal	530 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7b2:	0992                	slli	s3,s3,0x4
 7b4:	34fd                	addiw	s1,s1,-1
 7b6:	f4f5                	bnez	s1,7a2 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 7b8:	8be6                	mv	s7,s9
      state = 0;
 7ba:	4981                	li	s3,0
 7bc:	6ca2                	ld	s9,8(sp)
 7be:	bda5                	j	636 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 7c0:	008b8993          	addi	s3,s7,8
 7c4:	000bb483          	ld	s1,0(s7)
 7c8:	cc91                	beqz	s1,7e4 <vprintf+0x1f2>
        for(; *s; s++)
 7ca:	0004c583          	lbu	a1,0(s1)
 7ce:	c985                	beqz	a1,7fe <vprintf+0x20c>
          putc(fd, *s);
 7d0:	855a                	mv	a0,s6
 7d2:	d5fff0ef          	jal	530 <putc>
        for(; *s; s++)
 7d6:	0485                	addi	s1,s1,1
 7d8:	0004c583          	lbu	a1,0(s1)
 7dc:	f9f5                	bnez	a1,7d0 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 7de:	8bce                	mv	s7,s3
      state = 0;
 7e0:	4981                	li	s3,0
 7e2:	bd91                	j	636 <vprintf+0x44>
          s = "(null)";
 7e4:	00000497          	auipc	s1,0x0
 7e8:	2cc48493          	addi	s1,s1,716 # ab0 <malloc+0x138>
        for(; *s; s++)
 7ec:	02800593          	li	a1,40
 7f0:	b7c5                	j	7d0 <vprintf+0x1de>
        putc(fd, '%');
 7f2:	85be                	mv	a1,a5
 7f4:	855a                	mv	a0,s6
 7f6:	d3bff0ef          	jal	530 <putc>
      state = 0;
 7fa:	4981                	li	s3,0
 7fc:	bd2d                	j	636 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 7fe:	8bce                	mv	s7,s3
      state = 0;
 800:	4981                	li	s3,0
 802:	bd15                	j	636 <vprintf+0x44>
 804:	6906                	ld	s2,64(sp)
 806:	79e2                	ld	s3,56(sp)
 808:	7a42                	ld	s4,48(sp)
 80a:	7aa2                	ld	s5,40(sp)
 80c:	7b02                	ld	s6,32(sp)
 80e:	6be2                	ld	s7,24(sp)
 810:	6c42                	ld	s8,16(sp)
    }
  }
}
 812:	60e6                	ld	ra,88(sp)
 814:	6446                	ld	s0,80(sp)
 816:	64a6                	ld	s1,72(sp)
 818:	6125                	addi	sp,sp,96
 81a:	8082                	ret
      if(c0 == 'd'){
 81c:	06400713          	li	a4,100
 820:	e6e789e3          	beq	a5,a4,692 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 824:	f9478693          	addi	a3,a5,-108
 828:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 82c:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 82e:	4701                	li	a4,0
      } else if(c0 == 'u'){
 830:	07500513          	li	a0,117
 834:	eaa786e3          	beq	a5,a0,6e0 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 838:	f8b60513          	addi	a0,a2,-117
 83c:	e119                	bnez	a0,842 <vprintf+0x250>
 83e:	ea069de3          	bnez	a3,6f8 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 842:	f8b58513          	addi	a0,a1,-117
 846:	e119                	bnez	a0,84c <vprintf+0x25a>
 848:	ec0715e3          	bnez	a4,712 <vprintf+0x120>
      } else if(c0 == 'x'){
 84c:	07800513          	li	a0,120
 850:	eca78ee3          	beq	a5,a0,72c <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 854:	f8860613          	addi	a2,a2,-120
 858:	e219                	bnez	a2,85e <vprintf+0x26c>
 85a:	ee0695e3          	bnez	a3,744 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 85e:	f8858593          	addi	a1,a1,-120
 862:	e199                	bnez	a1,868 <vprintf+0x276>
 864:	ee071de3          	bnez	a4,75e <vprintf+0x16c>
      } else if(c0 == 'p'){
 868:	07000713          	li	a4,112
 86c:	f0e786e3          	beq	a5,a4,778 <vprintf+0x186>
      } else if(c0 == 's'){
 870:	07300713          	li	a4,115
 874:	f4e786e3          	beq	a5,a4,7c0 <vprintf+0x1ce>
      } else if(c0 == '%'){
 878:	02500713          	li	a4,37
 87c:	f6e78be3          	beq	a5,a4,7f2 <vprintf+0x200>
        putc(fd, '%');
 880:	02500593          	li	a1,37
 884:	855a                	mv	a0,s6
 886:	cabff0ef          	jal	530 <putc>
        putc(fd, c0);
 88a:	85a6                	mv	a1,s1
 88c:	855a                	mv	a0,s6
 88e:	ca3ff0ef          	jal	530 <putc>
      state = 0;
 892:	4981                	li	s3,0
 894:	b34d                	j	636 <vprintf+0x44>

0000000000000896 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 896:	715d                	addi	sp,sp,-80
 898:	ec06                	sd	ra,24(sp)
 89a:	e822                	sd	s0,16(sp)
 89c:	1000                	addi	s0,sp,32
 89e:	e010                	sd	a2,0(s0)
 8a0:	e414                	sd	a3,8(s0)
 8a2:	e818                	sd	a4,16(s0)
 8a4:	ec1c                	sd	a5,24(s0)
 8a6:	03043023          	sd	a6,32(s0)
 8aa:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 8ae:	8622                	mv	a2,s0
 8b0:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 8b4:	d3fff0ef          	jal	5f2 <vprintf>
}
 8b8:	60e2                	ld	ra,24(sp)
 8ba:	6442                	ld	s0,16(sp)
 8bc:	6161                	addi	sp,sp,80
 8be:	8082                	ret

00000000000008c0 <printf>:

void
printf(const char *fmt, ...)
{
 8c0:	711d                	addi	sp,sp,-96
 8c2:	ec06                	sd	ra,24(sp)
 8c4:	e822                	sd	s0,16(sp)
 8c6:	1000                	addi	s0,sp,32
 8c8:	e40c                	sd	a1,8(s0)
 8ca:	e810                	sd	a2,16(s0)
 8cc:	ec14                	sd	a3,24(s0)
 8ce:	f018                	sd	a4,32(s0)
 8d0:	f41c                	sd	a5,40(s0)
 8d2:	03043823          	sd	a6,48(s0)
 8d6:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 8da:	00840613          	addi	a2,s0,8
 8de:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8e2:	85aa                	mv	a1,a0
 8e4:	4505                	li	a0,1
 8e6:	d0dff0ef          	jal	5f2 <vprintf>
}
 8ea:	60e2                	ld	ra,24(sp)
 8ec:	6442                	ld	s0,16(sp)
 8ee:	6125                	addi	sp,sp,96
 8f0:	8082                	ret

00000000000008f2 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8f2:	1141                	addi	sp,sp,-16
 8f4:	e406                	sd	ra,8(sp)
 8f6:	e022                	sd	s0,0(sp)
 8f8:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 8fa:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8fe:	00000797          	auipc	a5,0x0
 902:	7027b783          	ld	a5,1794(a5) # 1000 <freep>
 906:	a039                	j	914 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 908:	6398                	ld	a4,0(a5)
 90a:	00e7e463          	bltu	a5,a4,912 <free+0x20>
 90e:	00e6ea63          	bltu	a3,a4,922 <free+0x30>
{
 912:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 914:	fed7fae3          	bgeu	a5,a3,908 <free+0x16>
 918:	6398                	ld	a4,0(a5)
 91a:	00e6e463          	bltu	a3,a4,922 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 91e:	fee7eae3          	bltu	a5,a4,912 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 922:	ff852583          	lw	a1,-8(a0)
 926:	6390                	ld	a2,0(a5)
 928:	02059813          	slli	a6,a1,0x20
 92c:	01c85713          	srli	a4,a6,0x1c
 930:	9736                	add	a4,a4,a3
 932:	02e60563          	beq	a2,a4,95c <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 936:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 93a:	4790                	lw	a2,8(a5)
 93c:	02061593          	slli	a1,a2,0x20
 940:	01c5d713          	srli	a4,a1,0x1c
 944:	973e                	add	a4,a4,a5
 946:	02e68263          	beq	a3,a4,96a <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 94a:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 94c:	00000717          	auipc	a4,0x0
 950:	6af73a23          	sd	a5,1716(a4) # 1000 <freep>
}
 954:	60a2                	ld	ra,8(sp)
 956:	6402                	ld	s0,0(sp)
 958:	0141                	addi	sp,sp,16
 95a:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 95c:	4618                	lw	a4,8(a2)
 95e:	9f2d                	addw	a4,a4,a1
 960:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 964:	6398                	ld	a4,0(a5)
 966:	6310                	ld	a2,0(a4)
 968:	b7f9                	j	936 <free+0x44>
    p->s.size += bp->s.size;
 96a:	ff852703          	lw	a4,-8(a0)
 96e:	9f31                	addw	a4,a4,a2
 970:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 972:	ff053683          	ld	a3,-16(a0)
 976:	bfd1                	j	94a <free+0x58>

0000000000000978 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 978:	7139                	addi	sp,sp,-64
 97a:	fc06                	sd	ra,56(sp)
 97c:	f822                	sd	s0,48(sp)
 97e:	f04a                	sd	s2,32(sp)
 980:	ec4e                	sd	s3,24(sp)
 982:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 984:	02051993          	slli	s3,a0,0x20
 988:	0209d993          	srli	s3,s3,0x20
 98c:	09bd                	addi	s3,s3,15
 98e:	0049d993          	srli	s3,s3,0x4
 992:	2985                	addiw	s3,s3,1
 994:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 996:	00000517          	auipc	a0,0x0
 99a:	66a53503          	ld	a0,1642(a0) # 1000 <freep>
 99e:	c905                	beqz	a0,9ce <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9a0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9a2:	4798                	lw	a4,8(a5)
 9a4:	09377663          	bgeu	a4,s3,a30 <malloc+0xb8>
 9a8:	f426                	sd	s1,40(sp)
 9aa:	e852                	sd	s4,16(sp)
 9ac:	e456                	sd	s5,8(sp)
 9ae:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 9b0:	8a4e                	mv	s4,s3
 9b2:	6705                	lui	a4,0x1
 9b4:	00e9f363          	bgeu	s3,a4,9ba <malloc+0x42>
 9b8:	6a05                	lui	s4,0x1
 9ba:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 9be:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 9c2:	00000497          	auipc	s1,0x0
 9c6:	63e48493          	addi	s1,s1,1598 # 1000 <freep>
  if(p == (char*)-1)
 9ca:	5afd                	li	s5,-1
 9cc:	a83d                	j	a0a <malloc+0x92>
 9ce:	f426                	sd	s1,40(sp)
 9d0:	e852                	sd	s4,16(sp)
 9d2:	e456                	sd	s5,8(sp)
 9d4:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 9d6:	00000797          	auipc	a5,0x0
 9da:	63a78793          	addi	a5,a5,1594 # 1010 <base>
 9de:	00000717          	auipc	a4,0x0
 9e2:	62f73123          	sd	a5,1570(a4) # 1000 <freep>
 9e6:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9e8:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 9ec:	b7d1                	j	9b0 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 9ee:	6398                	ld	a4,0(a5)
 9f0:	e118                	sd	a4,0(a0)
 9f2:	a899                	j	a48 <malloc+0xd0>
  hp->s.size = nu;
 9f4:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9f8:	0541                	addi	a0,a0,16
 9fa:	ef9ff0ef          	jal	8f2 <free>
  return freep;
 9fe:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 a00:	c125                	beqz	a0,a60 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a02:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a04:	4798                	lw	a4,8(a5)
 a06:	03277163          	bgeu	a4,s2,a28 <malloc+0xb0>
    if(p == freep)
 a0a:	6098                	ld	a4,0(s1)
 a0c:	853e                	mv	a0,a5
 a0e:	fef71ae3          	bne	a4,a5,a02 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a12:	8552                	mv	a0,s4
 a14:	b05ff0ef          	jal	518 <sbrk>
  if(p == (char*)-1)
 a18:	fd551ee3          	bne	a0,s5,9f4 <malloc+0x7c>
        return 0;
 a1c:	4501                	li	a0,0
 a1e:	74a2                	ld	s1,40(sp)
 a20:	6a42                	ld	s4,16(sp)
 a22:	6aa2                	ld	s5,8(sp)
 a24:	6b02                	ld	s6,0(sp)
 a26:	a03d                	j	a54 <malloc+0xdc>
 a28:	74a2                	ld	s1,40(sp)
 a2a:	6a42                	ld	s4,16(sp)
 a2c:	6aa2                	ld	s5,8(sp)
 a2e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a30:	fae90fe3          	beq	s2,a4,9ee <malloc+0x76>
        p->s.size -= nunits;
 a34:	4137073b          	subw	a4,a4,s3
 a38:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a3a:	02071693          	slli	a3,a4,0x20
 a3e:	01c6d713          	srli	a4,a3,0x1c
 a42:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a44:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a48:	00000717          	auipc	a4,0x0
 a4c:	5aa73c23          	sd	a0,1464(a4) # 1000 <freep>
      return (void*)(p + 1);
 a50:	01078513          	addi	a0,a5,16
  }
}
 a54:	70e2                	ld	ra,56(sp)
 a56:	7442                	ld	s0,48(sp)
 a58:	7902                	ld	s2,32(sp)
 a5a:	69e2                	ld	s3,24(sp)
 a5c:	6121                	addi	sp,sp,64
 a5e:	8082                	ret
 a60:	74a2                	ld	s1,40(sp)
 a62:	6a42                	ld	s4,16(sp)
 a64:	6aa2                	ld	s5,8(sp)
 a66:	6b02                	ld	s6,0(sp)
 a68:	b7f5                	j	a54 <malloc+0xdc>
