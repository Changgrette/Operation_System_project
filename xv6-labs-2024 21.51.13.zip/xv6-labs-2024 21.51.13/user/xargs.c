#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"

int main(int argc, char *argv[])
{
    char buf[512];
    char *xargv[MAXARG];
    int i, j;
    char ch;

    if(argc < 2){
        fprintf(2, "Usage: xargs <command> [args...]\n");
        exit(1);
    }

    // 设置初始参数（跳过xargs本身）
    for(i = 1; i < argc; i++){
        xargv[i-1] = argv[i];
    }

    j = 0;
    while(read(0, &ch, 1) > 0){
        if(ch == '\n'){
            buf[j] = 0; // 字符串结束符
            xargv[argc-1] = buf; // 添加输入行作为最后一个参数

            // 确保参数列表以NULL结尾
            xargv[argc] = 0;

            // 创建子进程执行命令
            int pid = fork();
            if(pid < 0){
                fprintf(2, "xargs: fork failed\n");
                exit(1);
            }

            if(pid == 0){ // 子进程
                exec(xargv[0], xargv);
                fprintf(2, "xargs: exec %s failed\n", xargv[0]);
                exit(1);
            } else { // 父进程
                wait(0);
            }

            j = 0; // 重置缓冲区索引
        } else if(j < sizeof(buf) - 1){
            buf[j++] = ch;
        } else {
            fprintf(2, "xargs: input line too long\n");
            exit(1);
        }
    }

    exit(0);
}