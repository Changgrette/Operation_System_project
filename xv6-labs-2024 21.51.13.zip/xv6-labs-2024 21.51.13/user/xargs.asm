
user/_xargs:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"

int main(int argc, char *argv[])
{
   0:	cc010113          	addi	sp,sp,-832
   4:	32113c23          	sd	ra,824(sp)
   8:	32813823          	sd	s0,816(sp)
   c:	0680                	addi	s0,sp,832
    char buf[512];
    char *xargv[MAXARG];
    int i, j;
    char ch;

    if(argc < 2){
   e:	4785                	li	a5,1
  10:	04a7da63          	bge	a5,a0,64 <main+0x64>
  14:	32913423          	sd	s1,808(sp)
  18:	33213023          	sd	s2,800(sp)
  1c:	31313c23          	sd	s3,792(sp)
  20:	31413823          	sd	s4,784(sp)
  24:	00858713          	addi	a4,a1,8
  28:	cd040793          	addi	a5,s0,-816
  2c:	ffe5061b          	addiw	a2,a0,-2
  30:	02061693          	slli	a3,a2,0x20
  34:	01d6d613          	srli	a2,a3,0x1d
  38:	cd840693          	addi	a3,s0,-808
  3c:	9636                	add	a2,a2,a3
        exit(1);
    }

    // 设置初始参数（跳过xargs本身）
    for(i = 1; i < argc; i++){
        xargv[i-1] = argv[i];
  3e:	6314                	ld	a3,0(a4)
  40:	e394                	sd	a3,0(a5)
    for(i = 1; i < argc; i++){
  42:	0721                	addi	a4,a4,8
  44:	07a1                	addi	a5,a5,8
  46:	fec79ce3          	bne	a5,a2,3e <main+0x3e>
    }

    j = 0;
  4a:	4481                	li	s1,0
    while(read(0, &ch, 1) > 0){
  4c:	ccf40913          	addi	s2,s0,-817
        if(ch == '\n'){
            buf[j] = 0; // 字符串结束符
            xargv[argc-1] = buf; // 添加输入行作为最后一个参数
  50:	fff5099b          	addiw	s3,a0,-1
  54:	cd040793          	addi	a5,s0,-816
  58:	098e                	slli	s3,s3,0x3
  5a:	99be                	add	s3,s3,a5

            // 确保参数列表以NULL结尾
            xargv[argc] = 0;
  5c:	050e                	slli	a0,a0,0x3
  5e:	00f50a33          	add	s4,a0,a5
  62:	a881                	j	b2 <main+0xb2>
  64:	32913423          	sd	s1,808(sp)
  68:	33213023          	sd	s2,800(sp)
  6c:	31313c23          	sd	s3,792(sp)
  70:	31413823          	sd	s4,784(sp)
        fprintf(2, "Usage: xargs <command> [args...]\n");
  74:	00001597          	auipc	a1,0x1
  78:	92c58593          	addi	a1,a1,-1748 # 9a0 <malloc+0xfa>
  7c:	4509                	li	a0,2
  7e:	746000ef          	jal	7c4 <fprintf>
        exit(1);
  82:	4505                	li	a0,1
  84:	33a000ef          	jal	3be <exit>
            buf[j] = 0; // 字符串结束符
  88:	fd048793          	addi	a5,s1,-48
  8c:	008784b3          	add	s1,a5,s0
  90:	e0048023          	sb	zero,-512(s1)
            xargv[argc-1] = buf; // 添加输入行作为最后一个参数
  94:	dd040793          	addi	a5,s0,-560
  98:	00f9b023          	sd	a5,0(s3)
            xargv[argc] = 0;
  9c:	000a3023          	sd	zero,0(s4)

            // 创建子进程执行命令
            int pid = fork();
  a0:	316000ef          	jal	3b6 <fork>
            if(pid < 0){
  a4:	02054e63          	bltz	a0,e0 <main+0xe0>
                fprintf(2, "xargs: fork failed\n");
                exit(1);
            }

            if(pid == 0){ // 子进程
  a8:	c531                	beqz	a0,f4 <main+0xf4>
                exec(xargv[0], xargv);
                fprintf(2, "xargs: exec %s failed\n", xargv[0]);
                exit(1);
            } else { // 父进程
                wait(0);
  aa:	4501                	li	a0,0
  ac:	31a000ef          	jal	3c6 <wait>
            }

            j = 0; // 重置缓冲区索引
  b0:	4481                	li	s1,0
    while(read(0, &ch, 1) > 0){
  b2:	4605                	li	a2,1
  b4:	85ca                	mv	a1,s2
  b6:	4501                	li	a0,0
  b8:	31e000ef          	jal	3d6 <read>
  bc:	06a05863          	blez	a0,12c <main+0x12c>
        if(ch == '\n'){
  c0:	ccf44783          	lbu	a5,-817(s0)
  c4:	4729                	li	a4,10
  c6:	fce781e3          	beq	a5,a4,88 <main+0x88>
        } else if(j < sizeof(buf) - 1){
  ca:	1fe00713          	li	a4,510
  ce:	04976563          	bltu	a4,s1,118 <main+0x118>
            buf[j++] = ch;
  d2:	fd048713          	addi	a4,s1,-48
  d6:	9722                	add	a4,a4,s0
  d8:	e0f70023          	sb	a5,-512(a4)
  dc:	2485                	addiw	s1,s1,1
  de:	bfd1                	j	b2 <main+0xb2>
                fprintf(2, "xargs: fork failed\n");
  e0:	00001597          	auipc	a1,0x1
  e4:	8e858593          	addi	a1,a1,-1816 # 9c8 <malloc+0x122>
  e8:	4509                	li	a0,2
  ea:	6da000ef          	jal	7c4 <fprintf>
                exit(1);
  ee:	4505                	li	a0,1
  f0:	2ce000ef          	jal	3be <exit>
                exec(xargv[0], xargv);
  f4:	cd040593          	addi	a1,s0,-816
  f8:	cd043503          	ld	a0,-816(s0)
  fc:	2fa000ef          	jal	3f6 <exec>
                fprintf(2, "xargs: exec %s failed\n", xargv[0]);
 100:	cd043603          	ld	a2,-816(s0)
 104:	00001597          	auipc	a1,0x1
 108:	8dc58593          	addi	a1,a1,-1828 # 9e0 <malloc+0x13a>
 10c:	4509                	li	a0,2
 10e:	6b6000ef          	jal	7c4 <fprintf>
                exit(1);
 112:	4505                	li	a0,1
 114:	2aa000ef          	jal	3be <exit>
        } else {
            fprintf(2, "xargs: input line too long\n");
 118:	00001597          	auipc	a1,0x1
 11c:	8e058593          	addi	a1,a1,-1824 # 9f8 <malloc+0x152>
 120:	4509                	li	a0,2
 122:	6a2000ef          	jal	7c4 <fprintf>
            exit(1);
 126:	4505                	li	a0,1
 128:	296000ef          	jal	3be <exit>
        }
    }

    exit(0);
 12c:	4501                	li	a0,0
 12e:	290000ef          	jal	3be <exit>

0000000000000132 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 132:	1141                	addi	sp,sp,-16
 134:	e406                	sd	ra,8(sp)
 136:	e022                	sd	s0,0(sp)
 138:	0800                	addi	s0,sp,16
  extern int main();
  main();
 13a:	ec7ff0ef          	jal	0 <main>
  exit(0);
 13e:	4501                	li	a0,0
 140:	27e000ef          	jal	3be <exit>

0000000000000144 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 144:	1141                	addi	sp,sp,-16
 146:	e406                	sd	ra,8(sp)
 148:	e022                	sd	s0,0(sp)
 14a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 14c:	87aa                	mv	a5,a0
 14e:	0585                	addi	a1,a1,1
 150:	0785                	addi	a5,a5,1
 152:	fff5c703          	lbu	a4,-1(a1)
 156:	fee78fa3          	sb	a4,-1(a5)
 15a:	fb75                	bnez	a4,14e <strcpy+0xa>
    ;
  return os;
}
 15c:	60a2                	ld	ra,8(sp)
 15e:	6402                	ld	s0,0(sp)
 160:	0141                	addi	sp,sp,16
 162:	8082                	ret

0000000000000164 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 164:	1141                	addi	sp,sp,-16
 166:	e406                	sd	ra,8(sp)
 168:	e022                	sd	s0,0(sp)
 16a:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 16c:	00054783          	lbu	a5,0(a0)
 170:	cb91                	beqz	a5,184 <strcmp+0x20>
 172:	0005c703          	lbu	a4,0(a1)
 176:	00f71763          	bne	a4,a5,184 <strcmp+0x20>
    p++, q++;
 17a:	0505                	addi	a0,a0,1
 17c:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 17e:	00054783          	lbu	a5,0(a0)
 182:	fbe5                	bnez	a5,172 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 184:	0005c503          	lbu	a0,0(a1)
}
 188:	40a7853b          	subw	a0,a5,a0
 18c:	60a2                	ld	ra,8(sp)
 18e:	6402                	ld	s0,0(sp)
 190:	0141                	addi	sp,sp,16
 192:	8082                	ret

0000000000000194 <strlen>:

uint
strlen(const char *s)
{
 194:	1141                	addi	sp,sp,-16
 196:	e406                	sd	ra,8(sp)
 198:	e022                	sd	s0,0(sp)
 19a:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 19c:	00054783          	lbu	a5,0(a0)
 1a0:	cf91                	beqz	a5,1bc <strlen+0x28>
 1a2:	00150793          	addi	a5,a0,1
 1a6:	86be                	mv	a3,a5
 1a8:	0785                	addi	a5,a5,1
 1aa:	fff7c703          	lbu	a4,-1(a5)
 1ae:	ff65                	bnez	a4,1a6 <strlen+0x12>
 1b0:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 1b4:	60a2                	ld	ra,8(sp)
 1b6:	6402                	ld	s0,0(sp)
 1b8:	0141                	addi	sp,sp,16
 1ba:	8082                	ret
  for(n = 0; s[n]; n++)
 1bc:	4501                	li	a0,0
 1be:	bfdd                	j	1b4 <strlen+0x20>

00000000000001c0 <memset>:

void*
memset(void *dst, int c, uint n)
{
 1c0:	1141                	addi	sp,sp,-16
 1c2:	e406                	sd	ra,8(sp)
 1c4:	e022                	sd	s0,0(sp)
 1c6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1c8:	ca19                	beqz	a2,1de <memset+0x1e>
 1ca:	87aa                	mv	a5,a0
 1cc:	1602                	slli	a2,a2,0x20
 1ce:	9201                	srli	a2,a2,0x20
 1d0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 1d4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 1d8:	0785                	addi	a5,a5,1
 1da:	fee79de3          	bne	a5,a4,1d4 <memset+0x14>
  }
  return dst;
}
 1de:	60a2                	ld	ra,8(sp)
 1e0:	6402                	ld	s0,0(sp)
 1e2:	0141                	addi	sp,sp,16
 1e4:	8082                	ret

00000000000001e6 <strchr>:

char*
strchr(const char *s, char c)
{
 1e6:	1141                	addi	sp,sp,-16
 1e8:	e406                	sd	ra,8(sp)
 1ea:	e022                	sd	s0,0(sp)
 1ec:	0800                	addi	s0,sp,16
  for(; *s; s++)
 1ee:	00054783          	lbu	a5,0(a0)
 1f2:	cf81                	beqz	a5,20a <strchr+0x24>
    if(*s == c)
 1f4:	00f58763          	beq	a1,a5,202 <strchr+0x1c>
  for(; *s; s++)
 1f8:	0505                	addi	a0,a0,1
 1fa:	00054783          	lbu	a5,0(a0)
 1fe:	fbfd                	bnez	a5,1f4 <strchr+0xe>
      return (char*)s;
  return 0;
 200:	4501                	li	a0,0
}
 202:	60a2                	ld	ra,8(sp)
 204:	6402                	ld	s0,0(sp)
 206:	0141                	addi	sp,sp,16
 208:	8082                	ret
  return 0;
 20a:	4501                	li	a0,0
 20c:	bfdd                	j	202 <strchr+0x1c>

000000000000020e <gets>:

char*
gets(char *buf, int max)
{
 20e:	711d                	addi	sp,sp,-96
 210:	ec86                	sd	ra,88(sp)
 212:	e8a2                	sd	s0,80(sp)
 214:	e4a6                	sd	s1,72(sp)
 216:	e0ca                	sd	s2,64(sp)
 218:	fc4e                	sd	s3,56(sp)
 21a:	f852                	sd	s4,48(sp)
 21c:	f456                	sd	s5,40(sp)
 21e:	f05a                	sd	s6,32(sp)
 220:	ec5e                	sd	s7,24(sp)
 222:	e862                	sd	s8,16(sp)
 224:	1080                	addi	s0,sp,96
 226:	8baa                	mv	s7,a0
 228:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 22a:	892a                	mv	s2,a0
 22c:	4481                	li	s1,0
    cc = read(0, &c, 1);
 22e:	faf40b13          	addi	s6,s0,-81
 232:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 234:	8c26                	mv	s8,s1
 236:	0014899b          	addiw	s3,s1,1
 23a:	84ce                	mv	s1,s3
 23c:	0349d463          	bge	s3,s4,264 <gets+0x56>
    cc = read(0, &c, 1);
 240:	8656                	mv	a2,s5
 242:	85da                	mv	a1,s6
 244:	4501                	li	a0,0
 246:	190000ef          	jal	3d6 <read>
    if(cc < 1)
 24a:	00a05d63          	blez	a0,264 <gets+0x56>
      break;
    buf[i++] = c;
 24e:	faf44783          	lbu	a5,-81(s0)
 252:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 256:	0905                	addi	s2,s2,1
 258:	ff678713          	addi	a4,a5,-10
 25c:	c319                	beqz	a4,262 <gets+0x54>
 25e:	17cd                	addi	a5,a5,-13
 260:	fbf1                	bnez	a5,234 <gets+0x26>
    buf[i++] = c;
 262:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 264:	9c5e                	add	s8,s8,s7
 266:	000c0023          	sb	zero,0(s8)
  return buf;
}
 26a:	855e                	mv	a0,s7
 26c:	60e6                	ld	ra,88(sp)
 26e:	6446                	ld	s0,80(sp)
 270:	64a6                	ld	s1,72(sp)
 272:	6906                	ld	s2,64(sp)
 274:	79e2                	ld	s3,56(sp)
 276:	7a42                	ld	s4,48(sp)
 278:	7aa2                	ld	s5,40(sp)
 27a:	7b02                	ld	s6,32(sp)
 27c:	6be2                	ld	s7,24(sp)
 27e:	6c42                	ld	s8,16(sp)
 280:	6125                	addi	sp,sp,96
 282:	8082                	ret

0000000000000284 <stat>:

int
stat(const char *n, struct stat *st)
{
 284:	1101                	addi	sp,sp,-32
 286:	ec06                	sd	ra,24(sp)
 288:	e822                	sd	s0,16(sp)
 28a:	e04a                	sd	s2,0(sp)
 28c:	1000                	addi	s0,sp,32
 28e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 290:	4581                	li	a1,0
 292:	16c000ef          	jal	3fe <open>
  if(fd < 0)
 296:	02054263          	bltz	a0,2ba <stat+0x36>
 29a:	e426                	sd	s1,8(sp)
 29c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 29e:	85ca                	mv	a1,s2
 2a0:	176000ef          	jal	416 <fstat>
 2a4:	892a                	mv	s2,a0
  close(fd);
 2a6:	8526                	mv	a0,s1
 2a8:	13e000ef          	jal	3e6 <close>
  return r;
 2ac:	64a2                	ld	s1,8(sp)
}
 2ae:	854a                	mv	a0,s2
 2b0:	60e2                	ld	ra,24(sp)
 2b2:	6442                	ld	s0,16(sp)
 2b4:	6902                	ld	s2,0(sp)
 2b6:	6105                	addi	sp,sp,32
 2b8:	8082                	ret
    return -1;
 2ba:	57fd                	li	a5,-1
 2bc:	893e                	mv	s2,a5
 2be:	bfc5                	j	2ae <stat+0x2a>

00000000000002c0 <atoi>:

int
atoi(const char *s)
{
 2c0:	1141                	addi	sp,sp,-16
 2c2:	e406                	sd	ra,8(sp)
 2c4:	e022                	sd	s0,0(sp)
 2c6:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2c8:	00054683          	lbu	a3,0(a0)
 2cc:	fd06879b          	addiw	a5,a3,-48
 2d0:	0ff7f793          	zext.b	a5,a5
 2d4:	4625                	li	a2,9
 2d6:	02f66963          	bltu	a2,a5,308 <atoi+0x48>
 2da:	872a                	mv	a4,a0
  n = 0;
 2dc:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 2de:	0705                	addi	a4,a4,1
 2e0:	0025179b          	slliw	a5,a0,0x2
 2e4:	9fa9                	addw	a5,a5,a0
 2e6:	0017979b          	slliw	a5,a5,0x1
 2ea:	9fb5                	addw	a5,a5,a3
 2ec:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 2f0:	00074683          	lbu	a3,0(a4)
 2f4:	fd06879b          	addiw	a5,a3,-48
 2f8:	0ff7f793          	zext.b	a5,a5
 2fc:	fef671e3          	bgeu	a2,a5,2de <atoi+0x1e>
  return n;
}
 300:	60a2                	ld	ra,8(sp)
 302:	6402                	ld	s0,0(sp)
 304:	0141                	addi	sp,sp,16
 306:	8082                	ret
  n = 0;
 308:	4501                	li	a0,0
 30a:	bfdd                	j	300 <atoi+0x40>

000000000000030c <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 30c:	1141                	addi	sp,sp,-16
 30e:	e406                	sd	ra,8(sp)
 310:	e022                	sd	s0,0(sp)
 312:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 314:	02b57563          	bgeu	a0,a1,33e <memmove+0x32>
    while(n-- > 0)
 318:	00c05f63          	blez	a2,336 <memmove+0x2a>
 31c:	1602                	slli	a2,a2,0x20
 31e:	9201                	srli	a2,a2,0x20
 320:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 324:	872a                	mv	a4,a0
      *dst++ = *src++;
 326:	0585                	addi	a1,a1,1
 328:	0705                	addi	a4,a4,1
 32a:	fff5c683          	lbu	a3,-1(a1)
 32e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 332:	fee79ae3          	bne	a5,a4,326 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 336:	60a2                	ld	ra,8(sp)
 338:	6402                	ld	s0,0(sp)
 33a:	0141                	addi	sp,sp,16
 33c:	8082                	ret
    while(n-- > 0)
 33e:	fec05ce3          	blez	a2,336 <memmove+0x2a>
    dst += n;
 342:	00c50733          	add	a4,a0,a2
    src += n;
 346:	95b2                	add	a1,a1,a2
 348:	fff6079b          	addiw	a5,a2,-1
 34c:	1782                	slli	a5,a5,0x20
 34e:	9381                	srli	a5,a5,0x20
 350:	fff7c793          	not	a5,a5
 354:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 356:	15fd                	addi	a1,a1,-1
 358:	177d                	addi	a4,a4,-1
 35a:	0005c683          	lbu	a3,0(a1)
 35e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 362:	fef71ae3          	bne	a4,a5,356 <memmove+0x4a>
 366:	bfc1                	j	336 <memmove+0x2a>

0000000000000368 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 368:	1141                	addi	sp,sp,-16
 36a:	e406                	sd	ra,8(sp)
 36c:	e022                	sd	s0,0(sp)
 36e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 370:	c61d                	beqz	a2,39e <memcmp+0x36>
 372:	1602                	slli	a2,a2,0x20
 374:	9201                	srli	a2,a2,0x20
 376:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 37a:	00054783          	lbu	a5,0(a0)
 37e:	0005c703          	lbu	a4,0(a1)
 382:	00e79863          	bne	a5,a4,392 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 386:	0505                	addi	a0,a0,1
    p2++;
 388:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 38a:	fed518e3          	bne	a0,a3,37a <memcmp+0x12>
  }
  return 0;
 38e:	4501                	li	a0,0
 390:	a019                	j	396 <memcmp+0x2e>
      return *p1 - *p2;
 392:	40e7853b          	subw	a0,a5,a4
}
 396:	60a2                	ld	ra,8(sp)
 398:	6402                	ld	s0,0(sp)
 39a:	0141                	addi	sp,sp,16
 39c:	8082                	ret
  return 0;
 39e:	4501                	li	a0,0
 3a0:	bfdd                	j	396 <memcmp+0x2e>

00000000000003a2 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3a2:	1141                	addi	sp,sp,-16
 3a4:	e406                	sd	ra,8(sp)
 3a6:	e022                	sd	s0,0(sp)
 3a8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3aa:	f63ff0ef          	jal	30c <memmove>
}
 3ae:	60a2                	ld	ra,8(sp)
 3b0:	6402                	ld	s0,0(sp)
 3b2:	0141                	addi	sp,sp,16
 3b4:	8082                	ret

00000000000003b6 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3b6:	4885                	li	a7,1
 ecall
 3b8:	00000073          	ecall
 ret
 3bc:	8082                	ret

00000000000003be <exit>:
.global exit
exit:
 li a7, SYS_exit
 3be:	4889                	li	a7,2
 ecall
 3c0:	00000073          	ecall
 ret
 3c4:	8082                	ret

00000000000003c6 <wait>:
.global wait
wait:
 li a7, SYS_wait
 3c6:	488d                	li	a7,3
 ecall
 3c8:	00000073          	ecall
 ret
 3cc:	8082                	ret

00000000000003ce <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3ce:	4891                	li	a7,4
 ecall
 3d0:	00000073          	ecall
 ret
 3d4:	8082                	ret

00000000000003d6 <read>:
.global read
read:
 li a7, SYS_read
 3d6:	4895                	li	a7,5
 ecall
 3d8:	00000073          	ecall
 ret
 3dc:	8082                	ret

00000000000003de <write>:
.global write
write:
 li a7, SYS_write
 3de:	48c1                	li	a7,16
 ecall
 3e0:	00000073          	ecall
 ret
 3e4:	8082                	ret

00000000000003e6 <close>:
.global close
close:
 li a7, SYS_close
 3e6:	48d5                	li	a7,21
 ecall
 3e8:	00000073          	ecall
 ret
 3ec:	8082                	ret

00000000000003ee <kill>:
.global kill
kill:
 li a7, SYS_kill
 3ee:	4899                	li	a7,6
 ecall
 3f0:	00000073          	ecall
 ret
 3f4:	8082                	ret

00000000000003f6 <exec>:
.global exec
exec:
 li a7, SYS_exec
 3f6:	489d                	li	a7,7
 ecall
 3f8:	00000073          	ecall
 ret
 3fc:	8082                	ret

00000000000003fe <open>:
.global open
open:
 li a7, SYS_open
 3fe:	48bd                	li	a7,15
 ecall
 400:	00000073          	ecall
 ret
 404:	8082                	ret

0000000000000406 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 406:	48c5                	li	a7,17
 ecall
 408:	00000073          	ecall
 ret
 40c:	8082                	ret

000000000000040e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 40e:	48c9                	li	a7,18
 ecall
 410:	00000073          	ecall
 ret
 414:	8082                	ret

0000000000000416 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 416:	48a1                	li	a7,8
 ecall
 418:	00000073          	ecall
 ret
 41c:	8082                	ret

000000000000041e <link>:
.global link
link:
 li a7, SYS_link
 41e:	48cd                	li	a7,19
 ecall
 420:	00000073          	ecall
 ret
 424:	8082                	ret

0000000000000426 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 426:	48d1                	li	a7,20
 ecall
 428:	00000073          	ecall
 ret
 42c:	8082                	ret

000000000000042e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 42e:	48a5                	li	a7,9
 ecall
 430:	00000073          	ecall
 ret
 434:	8082                	ret

0000000000000436 <dup>:
.global dup
dup:
 li a7, SYS_dup
 436:	48a9                	li	a7,10
 ecall
 438:	00000073          	ecall
 ret
 43c:	8082                	ret

000000000000043e <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 43e:	48ad                	li	a7,11
 ecall
 440:	00000073          	ecall
 ret
 444:	8082                	ret

0000000000000446 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 446:	48b1                	li	a7,12
 ecall
 448:	00000073          	ecall
 ret
 44c:	8082                	ret

000000000000044e <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 44e:	48b5                	li	a7,13
 ecall
 450:	00000073          	ecall
 ret
 454:	8082                	ret

0000000000000456 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 456:	48b9                	li	a7,14
 ecall
 458:	00000073          	ecall
 ret
 45c:	8082                	ret

000000000000045e <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 45e:	1101                	addi	sp,sp,-32
 460:	ec06                	sd	ra,24(sp)
 462:	e822                	sd	s0,16(sp)
 464:	1000                	addi	s0,sp,32
 466:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 46a:	4605                	li	a2,1
 46c:	fef40593          	addi	a1,s0,-17
 470:	f6fff0ef          	jal	3de <write>
}
 474:	60e2                	ld	ra,24(sp)
 476:	6442                	ld	s0,16(sp)
 478:	6105                	addi	sp,sp,32
 47a:	8082                	ret

000000000000047c <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 47c:	7139                	addi	sp,sp,-64
 47e:	fc06                	sd	ra,56(sp)
 480:	f822                	sd	s0,48(sp)
 482:	f04a                	sd	s2,32(sp)
 484:	ec4e                	sd	s3,24(sp)
 486:	0080                	addi	s0,sp,64
 488:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 48a:	cac9                	beqz	a3,51c <printint+0xa0>
 48c:	01f5d79b          	srliw	a5,a1,0x1f
 490:	c7d1                	beqz	a5,51c <printint+0xa0>
    neg = 1;
    x = -xx;
 492:	40b005bb          	negw	a1,a1
    neg = 1;
 496:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 498:	fc040993          	addi	s3,s0,-64
  neg = 0;
 49c:	86ce                	mv	a3,s3
  i = 0;
 49e:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 4a0:	00000817          	auipc	a6,0x0
 4a4:	58080813          	addi	a6,a6,1408 # a20 <digits>
 4a8:	88ba                	mv	a7,a4
 4aa:	0017051b          	addiw	a0,a4,1
 4ae:	872a                	mv	a4,a0
 4b0:	02c5f7bb          	remuw	a5,a1,a2
 4b4:	1782                	slli	a5,a5,0x20
 4b6:	9381                	srli	a5,a5,0x20
 4b8:	97c2                	add	a5,a5,a6
 4ba:	0007c783          	lbu	a5,0(a5)
 4be:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 4c2:	87ae                	mv	a5,a1
 4c4:	02c5d5bb          	divuw	a1,a1,a2
 4c8:	0685                	addi	a3,a3,1
 4ca:	fcc7ffe3          	bgeu	a5,a2,4a8 <printint+0x2c>
  if(neg)
 4ce:	00030c63          	beqz	t1,4e6 <printint+0x6a>
    buf[i++] = '-';
 4d2:	fd050793          	addi	a5,a0,-48
 4d6:	00878533          	add	a0,a5,s0
 4da:	02d00793          	li	a5,45
 4de:	fef50823          	sb	a5,-16(a0)
 4e2:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 4e6:	02e05563          	blez	a4,510 <printint+0x94>
 4ea:	f426                	sd	s1,40(sp)
 4ec:	377d                	addiw	a4,a4,-1
 4ee:	00e984b3          	add	s1,s3,a4
 4f2:	19fd                	addi	s3,s3,-1
 4f4:	99ba                	add	s3,s3,a4
 4f6:	1702                	slli	a4,a4,0x20
 4f8:	9301                	srli	a4,a4,0x20
 4fa:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 4fe:	0004c583          	lbu	a1,0(s1)
 502:	854a                	mv	a0,s2
 504:	f5bff0ef          	jal	45e <putc>
  while(--i >= 0)
 508:	14fd                	addi	s1,s1,-1
 50a:	ff349ae3          	bne	s1,s3,4fe <printint+0x82>
 50e:	74a2                	ld	s1,40(sp)
}
 510:	70e2                	ld	ra,56(sp)
 512:	7442                	ld	s0,48(sp)
 514:	7902                	ld	s2,32(sp)
 516:	69e2                	ld	s3,24(sp)
 518:	6121                	addi	sp,sp,64
 51a:	8082                	ret
  neg = 0;
 51c:	4301                	li	t1,0
 51e:	bfad                	j	498 <printint+0x1c>

0000000000000520 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 520:	711d                	addi	sp,sp,-96
 522:	ec86                	sd	ra,88(sp)
 524:	e8a2                	sd	s0,80(sp)
 526:	e4a6                	sd	s1,72(sp)
 528:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 52a:	0005c483          	lbu	s1,0(a1)
 52e:	20048963          	beqz	s1,740 <vprintf+0x220>
 532:	e0ca                	sd	s2,64(sp)
 534:	fc4e                	sd	s3,56(sp)
 536:	f852                	sd	s4,48(sp)
 538:	f456                	sd	s5,40(sp)
 53a:	f05a                	sd	s6,32(sp)
 53c:	ec5e                	sd	s7,24(sp)
 53e:	e862                	sd	s8,16(sp)
 540:	8b2a                	mv	s6,a0
 542:	8a2e                	mv	s4,a1
 544:	8bb2                	mv	s7,a2
  state = 0;
 546:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 548:	4901                	li	s2,0
 54a:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 54c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 550:	06400c13          	li	s8,100
 554:	a00d                	j	576 <vprintf+0x56>
        putc(fd, c0);
 556:	85a6                	mv	a1,s1
 558:	855a                	mv	a0,s6
 55a:	f05ff0ef          	jal	45e <putc>
 55e:	a019                	j	564 <vprintf+0x44>
    } else if(state == '%'){
 560:	03598363          	beq	s3,s5,586 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 564:	0019079b          	addiw	a5,s2,1
 568:	893e                	mv	s2,a5
 56a:	873e                	mv	a4,a5
 56c:	97d2                	add	a5,a5,s4
 56e:	0007c483          	lbu	s1,0(a5)
 572:	1c048063          	beqz	s1,732 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 576:	0004879b          	sext.w	a5,s1
    if(state == 0){
 57a:	fe0993e3          	bnez	s3,560 <vprintf+0x40>
      if(c0 == '%'){
 57e:	fd579ce3          	bne	a5,s5,556 <vprintf+0x36>
        state = '%';
 582:	89be                	mv	s3,a5
 584:	b7c5                	j	564 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 586:	00ea06b3          	add	a3,s4,a4
 58a:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 58e:	1a060e63          	beqz	a2,74a <vprintf+0x22a>
      if(c0 == 'd'){
 592:	03878763          	beq	a5,s8,5c0 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 596:	f9478693          	addi	a3,a5,-108
 59a:	0016b693          	seqz	a3,a3
 59e:	f9c60593          	addi	a1,a2,-100
 5a2:	e99d                	bnez	a1,5d8 <vprintf+0xb8>
 5a4:	ca95                	beqz	a3,5d8 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5a6:	008b8493          	addi	s1,s7,8
 5aa:	4685                	li	a3,1
 5ac:	4629                	li	a2,10
 5ae:	000ba583          	lw	a1,0(s7)
 5b2:	855a                	mv	a0,s6
 5b4:	ec9ff0ef          	jal	47c <printint>
        i += 1;
 5b8:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5ba:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 5bc:	4981                	li	s3,0
 5be:	b75d                	j	564 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5c0:	008b8493          	addi	s1,s7,8
 5c4:	4685                	li	a3,1
 5c6:	4629                	li	a2,10
 5c8:	000ba583          	lw	a1,0(s7)
 5cc:	855a                	mv	a0,s6
 5ce:	eafff0ef          	jal	47c <printint>
 5d2:	8ba6                	mv	s7,s1
      state = 0;
 5d4:	4981                	li	s3,0
 5d6:	b779                	j	564 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 5d8:	9752                	add	a4,a4,s4
 5da:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 5de:	f9460713          	addi	a4,a2,-108
 5e2:	00173713          	seqz	a4,a4
 5e6:	8f75                	and	a4,a4,a3
 5e8:	f9c58513          	addi	a0,a1,-100
 5ec:	16051963          	bnez	a0,75e <vprintf+0x23e>
 5f0:	16070763          	beqz	a4,75e <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5f4:	008b8493          	addi	s1,s7,8
 5f8:	4685                	li	a3,1
 5fa:	4629                	li	a2,10
 5fc:	000ba583          	lw	a1,0(s7)
 600:	855a                	mv	a0,s6
 602:	e7bff0ef          	jal	47c <printint>
        i += 2;
 606:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 608:	8ba6                	mv	s7,s1
      state = 0;
 60a:	4981                	li	s3,0
        i += 2;
 60c:	bfa1                	j	564 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 60e:	008b8493          	addi	s1,s7,8
 612:	4681                	li	a3,0
 614:	4629                	li	a2,10
 616:	000ba583          	lw	a1,0(s7)
 61a:	855a                	mv	a0,s6
 61c:	e61ff0ef          	jal	47c <printint>
 620:	8ba6                	mv	s7,s1
      state = 0;
 622:	4981                	li	s3,0
 624:	b781                	j	564 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 626:	008b8493          	addi	s1,s7,8
 62a:	4681                	li	a3,0
 62c:	4629                	li	a2,10
 62e:	000ba583          	lw	a1,0(s7)
 632:	855a                	mv	a0,s6
 634:	e49ff0ef          	jal	47c <printint>
        i += 1;
 638:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 63a:	8ba6                	mv	s7,s1
      state = 0;
 63c:	4981                	li	s3,0
 63e:	b71d                	j	564 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 640:	008b8493          	addi	s1,s7,8
 644:	4681                	li	a3,0
 646:	4629                	li	a2,10
 648:	000ba583          	lw	a1,0(s7)
 64c:	855a                	mv	a0,s6
 64e:	e2fff0ef          	jal	47c <printint>
        i += 2;
 652:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 654:	8ba6                	mv	s7,s1
      state = 0;
 656:	4981                	li	s3,0
        i += 2;
 658:	b731                	j	564 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 65a:	008b8493          	addi	s1,s7,8
 65e:	4681                	li	a3,0
 660:	4641                	li	a2,16
 662:	000ba583          	lw	a1,0(s7)
 666:	855a                	mv	a0,s6
 668:	e15ff0ef          	jal	47c <printint>
 66c:	8ba6                	mv	s7,s1
      state = 0;
 66e:	4981                	li	s3,0
 670:	bdd5                	j	564 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 672:	008b8493          	addi	s1,s7,8
 676:	4681                	li	a3,0
 678:	4641                	li	a2,16
 67a:	000ba583          	lw	a1,0(s7)
 67e:	855a                	mv	a0,s6
 680:	dfdff0ef          	jal	47c <printint>
        i += 1;
 684:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 686:	8ba6                	mv	s7,s1
      state = 0;
 688:	4981                	li	s3,0
 68a:	bde9                	j	564 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 68c:	008b8493          	addi	s1,s7,8
 690:	4681                	li	a3,0
 692:	4641                	li	a2,16
 694:	000ba583          	lw	a1,0(s7)
 698:	855a                	mv	a0,s6
 69a:	de3ff0ef          	jal	47c <printint>
        i += 2;
 69e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6a0:	8ba6                	mv	s7,s1
      state = 0;
 6a2:	4981                	li	s3,0
        i += 2;
 6a4:	b5c1                	j	564 <vprintf+0x44>
 6a6:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6a8:	008b8793          	addi	a5,s7,8
 6ac:	8cbe                	mv	s9,a5
 6ae:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6b2:	03000593          	li	a1,48
 6b6:	855a                	mv	a0,s6
 6b8:	da7ff0ef          	jal	45e <putc>
  putc(fd, 'x');
 6bc:	07800593          	li	a1,120
 6c0:	855a                	mv	a0,s6
 6c2:	d9dff0ef          	jal	45e <putc>
 6c6:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6c8:	00000b97          	auipc	s7,0x0
 6cc:	358b8b93          	addi	s7,s7,856 # a20 <digits>
 6d0:	03c9d793          	srli	a5,s3,0x3c
 6d4:	97de                	add	a5,a5,s7
 6d6:	0007c583          	lbu	a1,0(a5)
 6da:	855a                	mv	a0,s6
 6dc:	d83ff0ef          	jal	45e <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6e0:	0992                	slli	s3,s3,0x4
 6e2:	34fd                	addiw	s1,s1,-1
 6e4:	f4f5                	bnez	s1,6d0 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 6e6:	8be6                	mv	s7,s9
      state = 0;
 6e8:	4981                	li	s3,0
 6ea:	6ca2                	ld	s9,8(sp)
 6ec:	bda5                	j	564 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6ee:	008b8993          	addi	s3,s7,8
 6f2:	000bb483          	ld	s1,0(s7)
 6f6:	cc91                	beqz	s1,712 <vprintf+0x1f2>
        for(; *s; s++)
 6f8:	0004c583          	lbu	a1,0(s1)
 6fc:	c985                	beqz	a1,72c <vprintf+0x20c>
          putc(fd, *s);
 6fe:	855a                	mv	a0,s6
 700:	d5fff0ef          	jal	45e <putc>
        for(; *s; s++)
 704:	0485                	addi	s1,s1,1
 706:	0004c583          	lbu	a1,0(s1)
 70a:	f9f5                	bnez	a1,6fe <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 70c:	8bce                	mv	s7,s3
      state = 0;
 70e:	4981                	li	s3,0
 710:	bd91                	j	564 <vprintf+0x44>
          s = "(null)";
 712:	00000497          	auipc	s1,0x0
 716:	30648493          	addi	s1,s1,774 # a18 <malloc+0x172>
        for(; *s; s++)
 71a:	02800593          	li	a1,40
 71e:	b7c5                	j	6fe <vprintf+0x1de>
        putc(fd, '%');
 720:	85be                	mv	a1,a5
 722:	855a                	mv	a0,s6
 724:	d3bff0ef          	jal	45e <putc>
      state = 0;
 728:	4981                	li	s3,0
 72a:	bd2d                	j	564 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 72c:	8bce                	mv	s7,s3
      state = 0;
 72e:	4981                	li	s3,0
 730:	bd15                	j	564 <vprintf+0x44>
 732:	6906                	ld	s2,64(sp)
 734:	79e2                	ld	s3,56(sp)
 736:	7a42                	ld	s4,48(sp)
 738:	7aa2                	ld	s5,40(sp)
 73a:	7b02                	ld	s6,32(sp)
 73c:	6be2                	ld	s7,24(sp)
 73e:	6c42                	ld	s8,16(sp)
    }
  }
}
 740:	60e6                	ld	ra,88(sp)
 742:	6446                	ld	s0,80(sp)
 744:	64a6                	ld	s1,72(sp)
 746:	6125                	addi	sp,sp,96
 748:	8082                	ret
      if(c0 == 'd'){
 74a:	06400713          	li	a4,100
 74e:	e6e789e3          	beq	a5,a4,5c0 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 752:	f9478693          	addi	a3,a5,-108
 756:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 75a:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 75c:	4701                	li	a4,0
      } else if(c0 == 'u'){
 75e:	07500513          	li	a0,117
 762:	eaa786e3          	beq	a5,a0,60e <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 766:	f8b60513          	addi	a0,a2,-117
 76a:	e119                	bnez	a0,770 <vprintf+0x250>
 76c:	ea069de3          	bnez	a3,626 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 770:	f8b58513          	addi	a0,a1,-117
 774:	e119                	bnez	a0,77a <vprintf+0x25a>
 776:	ec0715e3          	bnez	a4,640 <vprintf+0x120>
      } else if(c0 == 'x'){
 77a:	07800513          	li	a0,120
 77e:	eca78ee3          	beq	a5,a0,65a <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 782:	f8860613          	addi	a2,a2,-120
 786:	e219                	bnez	a2,78c <vprintf+0x26c>
 788:	ee0695e3          	bnez	a3,672 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 78c:	f8858593          	addi	a1,a1,-120
 790:	e199                	bnez	a1,796 <vprintf+0x276>
 792:	ee071de3          	bnez	a4,68c <vprintf+0x16c>
      } else if(c0 == 'p'){
 796:	07000713          	li	a4,112
 79a:	f0e786e3          	beq	a5,a4,6a6 <vprintf+0x186>
      } else if(c0 == 's'){
 79e:	07300713          	li	a4,115
 7a2:	f4e786e3          	beq	a5,a4,6ee <vprintf+0x1ce>
      } else if(c0 == '%'){
 7a6:	02500713          	li	a4,37
 7aa:	f6e78be3          	beq	a5,a4,720 <vprintf+0x200>
        putc(fd, '%');
 7ae:	02500593          	li	a1,37
 7b2:	855a                	mv	a0,s6
 7b4:	cabff0ef          	jal	45e <putc>
        putc(fd, c0);
 7b8:	85a6                	mv	a1,s1
 7ba:	855a                	mv	a0,s6
 7bc:	ca3ff0ef          	jal	45e <putc>
      state = 0;
 7c0:	4981                	li	s3,0
 7c2:	b34d                	j	564 <vprintf+0x44>

00000000000007c4 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7c4:	715d                	addi	sp,sp,-80
 7c6:	ec06                	sd	ra,24(sp)
 7c8:	e822                	sd	s0,16(sp)
 7ca:	1000                	addi	s0,sp,32
 7cc:	e010                	sd	a2,0(s0)
 7ce:	e414                	sd	a3,8(s0)
 7d0:	e818                	sd	a4,16(s0)
 7d2:	ec1c                	sd	a5,24(s0)
 7d4:	03043023          	sd	a6,32(s0)
 7d8:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7dc:	8622                	mv	a2,s0
 7de:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7e2:	d3fff0ef          	jal	520 <vprintf>
}
 7e6:	60e2                	ld	ra,24(sp)
 7e8:	6442                	ld	s0,16(sp)
 7ea:	6161                	addi	sp,sp,80
 7ec:	8082                	ret

00000000000007ee <printf>:

void
printf(const char *fmt, ...)
{
 7ee:	711d                	addi	sp,sp,-96
 7f0:	ec06                	sd	ra,24(sp)
 7f2:	e822                	sd	s0,16(sp)
 7f4:	1000                	addi	s0,sp,32
 7f6:	e40c                	sd	a1,8(s0)
 7f8:	e810                	sd	a2,16(s0)
 7fa:	ec14                	sd	a3,24(s0)
 7fc:	f018                	sd	a4,32(s0)
 7fe:	f41c                	sd	a5,40(s0)
 800:	03043823          	sd	a6,48(s0)
 804:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 808:	00840613          	addi	a2,s0,8
 80c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 810:	85aa                	mv	a1,a0
 812:	4505                	li	a0,1
 814:	d0dff0ef          	jal	520 <vprintf>
}
 818:	60e2                	ld	ra,24(sp)
 81a:	6442                	ld	s0,16(sp)
 81c:	6125                	addi	sp,sp,96
 81e:	8082                	ret

0000000000000820 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 820:	1141                	addi	sp,sp,-16
 822:	e406                	sd	ra,8(sp)
 824:	e022                	sd	s0,0(sp)
 826:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 828:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 82c:	00000797          	auipc	a5,0x0
 830:	7d47b783          	ld	a5,2004(a5) # 1000 <freep>
 834:	a039                	j	842 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 836:	6398                	ld	a4,0(a5)
 838:	00e7e463          	bltu	a5,a4,840 <free+0x20>
 83c:	00e6ea63          	bltu	a3,a4,850 <free+0x30>
{
 840:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 842:	fed7fae3          	bgeu	a5,a3,836 <free+0x16>
 846:	6398                	ld	a4,0(a5)
 848:	00e6e463          	bltu	a3,a4,850 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 84c:	fee7eae3          	bltu	a5,a4,840 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 850:	ff852583          	lw	a1,-8(a0)
 854:	6390                	ld	a2,0(a5)
 856:	02059813          	slli	a6,a1,0x20
 85a:	01c85713          	srli	a4,a6,0x1c
 85e:	9736                	add	a4,a4,a3
 860:	02e60563          	beq	a2,a4,88a <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 864:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 868:	4790                	lw	a2,8(a5)
 86a:	02061593          	slli	a1,a2,0x20
 86e:	01c5d713          	srli	a4,a1,0x1c
 872:	973e                	add	a4,a4,a5
 874:	02e68263          	beq	a3,a4,898 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 878:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 87a:	00000717          	auipc	a4,0x0
 87e:	78f73323          	sd	a5,1926(a4) # 1000 <freep>
}
 882:	60a2                	ld	ra,8(sp)
 884:	6402                	ld	s0,0(sp)
 886:	0141                	addi	sp,sp,16
 888:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 88a:	4618                	lw	a4,8(a2)
 88c:	9f2d                	addw	a4,a4,a1
 88e:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 892:	6398                	ld	a4,0(a5)
 894:	6310                	ld	a2,0(a4)
 896:	b7f9                	j	864 <free+0x44>
    p->s.size += bp->s.size;
 898:	ff852703          	lw	a4,-8(a0)
 89c:	9f31                	addw	a4,a4,a2
 89e:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8a0:	ff053683          	ld	a3,-16(a0)
 8a4:	bfd1                	j	878 <free+0x58>

00000000000008a6 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8a6:	7139                	addi	sp,sp,-64
 8a8:	fc06                	sd	ra,56(sp)
 8aa:	f822                	sd	s0,48(sp)
 8ac:	f04a                	sd	s2,32(sp)
 8ae:	ec4e                	sd	s3,24(sp)
 8b0:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8b2:	02051993          	slli	s3,a0,0x20
 8b6:	0209d993          	srli	s3,s3,0x20
 8ba:	09bd                	addi	s3,s3,15
 8bc:	0049d993          	srli	s3,s3,0x4
 8c0:	2985                	addiw	s3,s3,1
 8c2:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 8c4:	00000517          	auipc	a0,0x0
 8c8:	73c53503          	ld	a0,1852(a0) # 1000 <freep>
 8cc:	c905                	beqz	a0,8fc <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8ce:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8d0:	4798                	lw	a4,8(a5)
 8d2:	09377663          	bgeu	a4,s3,95e <malloc+0xb8>
 8d6:	f426                	sd	s1,40(sp)
 8d8:	e852                	sd	s4,16(sp)
 8da:	e456                	sd	s5,8(sp)
 8dc:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 8de:	8a4e                	mv	s4,s3
 8e0:	6705                	lui	a4,0x1
 8e2:	00e9f363          	bgeu	s3,a4,8e8 <malloc+0x42>
 8e6:	6a05                	lui	s4,0x1
 8e8:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8ec:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 8f0:	00000497          	auipc	s1,0x0
 8f4:	71048493          	addi	s1,s1,1808 # 1000 <freep>
  if(p == (char*)-1)
 8f8:	5afd                	li	s5,-1
 8fa:	a83d                	j	938 <malloc+0x92>
 8fc:	f426                	sd	s1,40(sp)
 8fe:	e852                	sd	s4,16(sp)
 900:	e456                	sd	s5,8(sp)
 902:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 904:	00000797          	auipc	a5,0x0
 908:	70c78793          	addi	a5,a5,1804 # 1010 <base>
 90c:	00000717          	auipc	a4,0x0
 910:	6ef73a23          	sd	a5,1780(a4) # 1000 <freep>
 914:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 916:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 91a:	b7d1                	j	8de <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 91c:	6398                	ld	a4,0(a5)
 91e:	e118                	sd	a4,0(a0)
 920:	a899                	j	976 <malloc+0xd0>
  hp->s.size = nu;
 922:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 926:	0541                	addi	a0,a0,16
 928:	ef9ff0ef          	jal	820 <free>
  return freep;
 92c:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 92e:	c125                	beqz	a0,98e <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 930:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 932:	4798                	lw	a4,8(a5)
 934:	03277163          	bgeu	a4,s2,956 <malloc+0xb0>
    if(p == freep)
 938:	6098                	ld	a4,0(s1)
 93a:	853e                	mv	a0,a5
 93c:	fef71ae3          	bne	a4,a5,930 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 940:	8552                	mv	a0,s4
 942:	b05ff0ef          	jal	446 <sbrk>
  if(p == (char*)-1)
 946:	fd551ee3          	bne	a0,s5,922 <malloc+0x7c>
        return 0;
 94a:	4501                	li	a0,0
 94c:	74a2                	ld	s1,40(sp)
 94e:	6a42                	ld	s4,16(sp)
 950:	6aa2                	ld	s5,8(sp)
 952:	6b02                	ld	s6,0(sp)
 954:	a03d                	j	982 <malloc+0xdc>
 956:	74a2                	ld	s1,40(sp)
 958:	6a42                	ld	s4,16(sp)
 95a:	6aa2                	ld	s5,8(sp)
 95c:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 95e:	fae90fe3          	beq	s2,a4,91c <malloc+0x76>
        p->s.size -= nunits;
 962:	4137073b          	subw	a4,a4,s3
 966:	c798                	sw	a4,8(a5)
        p += p->s.size;
 968:	02071693          	slli	a3,a4,0x20
 96c:	01c6d713          	srli	a4,a3,0x1c
 970:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 972:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 976:	00000717          	auipc	a4,0x0
 97a:	68a73523          	sd	a0,1674(a4) # 1000 <freep>
      return (void*)(p + 1);
 97e:	01078513          	addi	a0,a5,16
  }
}
 982:	70e2                	ld	ra,56(sp)
 984:	7442                	ld	s0,48(sp)
 986:	7902                	ld	s2,32(sp)
 988:	69e2                	ld	s3,24(sp)
 98a:	6121                	addi	sp,sp,64
 98c:	8082                	ret
 98e:	74a2                	ld	s1,40(sp)
 990:	6a42                	ld	s4,16(sp)
 992:	6aa2                	ld	s5,8(sp)
 994:	6b02                	ld	s6,0(sp)
 996:	b7f5                	j	982 <malloc+0xdc>
