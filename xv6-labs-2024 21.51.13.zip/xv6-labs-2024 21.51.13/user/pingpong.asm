
user/_pingpong:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	1800                	addi	s0,sp,48
    int p1[2]; // 父进程写，子进程读
    int p2[2]; // 子进程写，父进程读
    char buf[1];

    // 创建两个管道
    if(pipe(p1) < 0 || pipe(p2) < 0){
   8:	fe840513          	addi	a0,s0,-24
   c:	3fc000ef          	jal	408 <pipe>
  10:	00054863          	bltz	a0,20 <main+0x20>
  14:	fe040513          	addi	a0,s0,-32
  18:	3f0000ef          	jal	408 <pipe>
  1c:	00055c63          	bgez	a0,34 <main+0x34>
        fprintf(2, "pipe failed\n");
  20:	00001597          	auipc	a1,0x1
  24:	9c058593          	addi	a1,a1,-1600 # 9e0 <malloc+0x100>
  28:	4509                	li	a0,2
  2a:	7d4000ef          	jal	7fe <fprintf>
        exit(1);
  2e:	4505                	li	a0,1
  30:	3c8000ef          	jal	3f8 <exit>
    }

    // 创建子进程
    int pid = fork();
  34:	3bc000ef          	jal	3f0 <fork>
    if(pid < 0){
  38:	02054f63          	bltz	a0,76 <main+0x76>
        fprintf(2, "fork failed\n");
        exit(1);
    }

    if(pid == 0){ // 子进程
  3c:	ed59                	bnez	a0,da <main+0xda>
        close(p1[1]); // 关闭父进程的写端
  3e:	fec42503          	lw	a0,-20(s0)
  42:	3de000ef          	jal	420 <close>
        close(p2[0]); // 关闭父进程的读端
  46:	fe042503          	lw	a0,-32(s0)
  4a:	3d6000ef          	jal	420 <close>

        // 从父进程读取数据
        if(read(p1[0], buf, 1) != 1){
  4e:	4605                	li	a2,1
  50:	fd840593          	addi	a1,s0,-40
  54:	fe842503          	lw	a0,-24(s0)
  58:	3b8000ef          	jal	410 <read>
  5c:	4785                	li	a5,1
  5e:	02f50663          	beq	a0,a5,8a <main+0x8a>
            fprintf(2, "child read error\n");
  62:	00001597          	auipc	a1,0x1
  66:	99e58593          	addi	a1,a1,-1634 # a00 <malloc+0x120>
  6a:	4509                	li	a0,2
  6c:	792000ef          	jal	7fe <fprintf>
            exit(1);
  70:	4505                	li	a0,1
  72:	386000ef          	jal	3f8 <exit>
        fprintf(2, "fork failed\n");
  76:	00001597          	auipc	a1,0x1
  7a:	97a58593          	addi	a1,a1,-1670 # 9f0 <malloc+0x110>
  7e:	4509                	li	a0,2
  80:	77e000ef          	jal	7fe <fprintf>
        exit(1);
  84:	4505                	li	a0,1
  86:	372000ef          	jal	3f8 <exit>
        }
        close(p1[0]);
  8a:	fe842503          	lw	a0,-24(s0)
  8e:	392000ef          	jal	420 <close>

        printf("%d: received ping\n", getpid());
  92:	3e6000ef          	jal	478 <getpid>
  96:	85aa                	mv	a1,a0
  98:	00001517          	auipc	a0,0x1
  9c:	98050513          	addi	a0,a0,-1664 # a18 <malloc+0x138>
  a0:	788000ef          	jal	828 <printf>

        // 向父进程写入数据
        if(write(p2[1], buf, 1) != 1){
  a4:	4605                	li	a2,1
  a6:	fd840593          	addi	a1,s0,-40
  aa:	fe442503          	lw	a0,-28(s0)
  ae:	36a000ef          	jal	418 <write>
  b2:	4785                	li	a5,1
  b4:	00f50c63          	beq	a0,a5,cc <main+0xcc>
            fprintf(2, "child write error\n");
  b8:	00001597          	auipc	a1,0x1
  bc:	97858593          	addi	a1,a1,-1672 # a30 <malloc+0x150>
  c0:	4509                	li	a0,2
  c2:	73c000ef          	jal	7fe <fprintf>
            exit(1);
  c6:	4505                	li	a0,1
  c8:	330000ef          	jal	3f8 <exit>
        }
        close(p2[1]);
  cc:	fe442503          	lw	a0,-28(s0)
  d0:	350000ef          	jal	420 <close>

        exit(0);
  d4:	4501                	li	a0,0
  d6:	322000ef          	jal	3f8 <exit>
    } else { // 父进程
        close(p1[0]); // 关闭子进程的读端
  da:	fe842503          	lw	a0,-24(s0)
  de:	342000ef          	jal	420 <close>
        close(p2[1]); // 关闭子进程的写端
  e2:	fe442503          	lw	a0,-28(s0)
  e6:	33a000ef          	jal	420 <close>

        // 向子进程写入数据
        if(write(p1[1], "a", 1) != 1){
  ea:	4605                	li	a2,1
  ec:	00001597          	auipc	a1,0x1
  f0:	95c58593          	addi	a1,a1,-1700 # a48 <malloc+0x168>
  f4:	fec42503          	lw	a0,-20(s0)
  f8:	320000ef          	jal	418 <write>
  fc:	4785                	li	a5,1
  fe:	00f50c63          	beq	a0,a5,116 <main+0x116>
            fprintf(2, "parent write error\n");
 102:	00001597          	auipc	a1,0x1
 106:	94e58593          	addi	a1,a1,-1714 # a50 <malloc+0x170>
 10a:	4509                	li	a0,2
 10c:	6f2000ef          	jal	7fe <fprintf>
            exit(1);
 110:	4505                	li	a0,1
 112:	2e6000ef          	jal	3f8 <exit>
        }
        close(p1[1]);
 116:	fec42503          	lw	a0,-20(s0)
 11a:	306000ef          	jal	420 <close>

        // 从子进程读取数据
        if(read(p2[0], buf, 1) != 1){
 11e:	4605                	li	a2,1
 120:	fd840593          	addi	a1,s0,-40
 124:	fe042503          	lw	a0,-32(s0)
 128:	2e8000ef          	jal	410 <read>
 12c:	4785                	li	a5,1
 12e:	00f50c63          	beq	a0,a5,146 <main+0x146>
            fprintf(2, "parent read error\n");
 132:	00001597          	auipc	a1,0x1
 136:	93658593          	addi	a1,a1,-1738 # a68 <malloc+0x188>
 13a:	4509                	li	a0,2
 13c:	6c2000ef          	jal	7fe <fprintf>
            exit(1);
 140:	4505                	li	a0,1
 142:	2b6000ef          	jal	3f8 <exit>
        }
        close(p2[0]);
 146:	fe042503          	lw	a0,-32(s0)
 14a:	2d6000ef          	jal	420 <close>

        printf("%d: received pong\n", getpid());
 14e:	32a000ef          	jal	478 <getpid>
 152:	85aa                	mv	a1,a0
 154:	00001517          	auipc	a0,0x1
 158:	92c50513          	addi	a0,a0,-1748 # a80 <malloc+0x1a0>
 15c:	6cc000ef          	jal	828 <printf>

        wait(0); // 等待子进程结束
 160:	4501                	li	a0,0
 162:	29e000ef          	jal	400 <wait>
        exit(0);
 166:	4501                	li	a0,0
 168:	290000ef          	jal	3f8 <exit>

000000000000016c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 16c:	1141                	addi	sp,sp,-16
 16e:	e406                	sd	ra,8(sp)
 170:	e022                	sd	s0,0(sp)
 172:	0800                	addi	s0,sp,16
  extern int main();
  main();
 174:	e8dff0ef          	jal	0 <main>
  exit(0);
 178:	4501                	li	a0,0
 17a:	27e000ef          	jal	3f8 <exit>

000000000000017e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 17e:	1141                	addi	sp,sp,-16
 180:	e406                	sd	ra,8(sp)
 182:	e022                	sd	s0,0(sp)
 184:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 186:	87aa                	mv	a5,a0
 188:	0585                	addi	a1,a1,1
 18a:	0785                	addi	a5,a5,1
 18c:	fff5c703          	lbu	a4,-1(a1)
 190:	fee78fa3          	sb	a4,-1(a5)
 194:	fb75                	bnez	a4,188 <strcpy+0xa>
    ;
  return os;
}
 196:	60a2                	ld	ra,8(sp)
 198:	6402                	ld	s0,0(sp)
 19a:	0141                	addi	sp,sp,16
 19c:	8082                	ret

000000000000019e <strcmp>:

int
strcmp(const char *p, const char *q)
{
 19e:	1141                	addi	sp,sp,-16
 1a0:	e406                	sd	ra,8(sp)
 1a2:	e022                	sd	s0,0(sp)
 1a4:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 1a6:	00054783          	lbu	a5,0(a0)
 1aa:	cb91                	beqz	a5,1be <strcmp+0x20>
 1ac:	0005c703          	lbu	a4,0(a1)
 1b0:	00f71763          	bne	a4,a5,1be <strcmp+0x20>
    p++, q++;
 1b4:	0505                	addi	a0,a0,1
 1b6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1b8:	00054783          	lbu	a5,0(a0)
 1bc:	fbe5                	bnez	a5,1ac <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 1be:	0005c503          	lbu	a0,0(a1)
}
 1c2:	40a7853b          	subw	a0,a5,a0
 1c6:	60a2                	ld	ra,8(sp)
 1c8:	6402                	ld	s0,0(sp)
 1ca:	0141                	addi	sp,sp,16
 1cc:	8082                	ret

00000000000001ce <strlen>:

uint
strlen(const char *s)
{
 1ce:	1141                	addi	sp,sp,-16
 1d0:	e406                	sd	ra,8(sp)
 1d2:	e022                	sd	s0,0(sp)
 1d4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 1d6:	00054783          	lbu	a5,0(a0)
 1da:	cf91                	beqz	a5,1f6 <strlen+0x28>
 1dc:	00150793          	addi	a5,a0,1
 1e0:	86be                	mv	a3,a5
 1e2:	0785                	addi	a5,a5,1
 1e4:	fff7c703          	lbu	a4,-1(a5)
 1e8:	ff65                	bnez	a4,1e0 <strlen+0x12>
 1ea:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 1ee:	60a2                	ld	ra,8(sp)
 1f0:	6402                	ld	s0,0(sp)
 1f2:	0141                	addi	sp,sp,16
 1f4:	8082                	ret
  for(n = 0; s[n]; n++)
 1f6:	4501                	li	a0,0
 1f8:	bfdd                	j	1ee <strlen+0x20>

00000000000001fa <memset>:

void*
memset(void *dst, int c, uint n)
{
 1fa:	1141                	addi	sp,sp,-16
 1fc:	e406                	sd	ra,8(sp)
 1fe:	e022                	sd	s0,0(sp)
 200:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 202:	ca19                	beqz	a2,218 <memset+0x1e>
 204:	87aa                	mv	a5,a0
 206:	1602                	slli	a2,a2,0x20
 208:	9201                	srli	a2,a2,0x20
 20a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 20e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 212:	0785                	addi	a5,a5,1
 214:	fee79de3          	bne	a5,a4,20e <memset+0x14>
  }
  return dst;
}
 218:	60a2                	ld	ra,8(sp)
 21a:	6402                	ld	s0,0(sp)
 21c:	0141                	addi	sp,sp,16
 21e:	8082                	ret

0000000000000220 <strchr>:

char*
strchr(const char *s, char c)
{
 220:	1141                	addi	sp,sp,-16
 222:	e406                	sd	ra,8(sp)
 224:	e022                	sd	s0,0(sp)
 226:	0800                	addi	s0,sp,16
  for(; *s; s++)
 228:	00054783          	lbu	a5,0(a0)
 22c:	cf81                	beqz	a5,244 <strchr+0x24>
    if(*s == c)
 22e:	00f58763          	beq	a1,a5,23c <strchr+0x1c>
  for(; *s; s++)
 232:	0505                	addi	a0,a0,1
 234:	00054783          	lbu	a5,0(a0)
 238:	fbfd                	bnez	a5,22e <strchr+0xe>
      return (char*)s;
  return 0;
 23a:	4501                	li	a0,0
}
 23c:	60a2                	ld	ra,8(sp)
 23e:	6402                	ld	s0,0(sp)
 240:	0141                	addi	sp,sp,16
 242:	8082                	ret
  return 0;
 244:	4501                	li	a0,0
 246:	bfdd                	j	23c <strchr+0x1c>

0000000000000248 <gets>:

char*
gets(char *buf, int max)
{
 248:	711d                	addi	sp,sp,-96
 24a:	ec86                	sd	ra,88(sp)
 24c:	e8a2                	sd	s0,80(sp)
 24e:	e4a6                	sd	s1,72(sp)
 250:	e0ca                	sd	s2,64(sp)
 252:	fc4e                	sd	s3,56(sp)
 254:	f852                	sd	s4,48(sp)
 256:	f456                	sd	s5,40(sp)
 258:	f05a                	sd	s6,32(sp)
 25a:	ec5e                	sd	s7,24(sp)
 25c:	e862                	sd	s8,16(sp)
 25e:	1080                	addi	s0,sp,96
 260:	8baa                	mv	s7,a0
 262:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 264:	892a                	mv	s2,a0
 266:	4481                	li	s1,0
    cc = read(0, &c, 1);
 268:	faf40b13          	addi	s6,s0,-81
 26c:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 26e:	8c26                	mv	s8,s1
 270:	0014899b          	addiw	s3,s1,1
 274:	84ce                	mv	s1,s3
 276:	0349d463          	bge	s3,s4,29e <gets+0x56>
    cc = read(0, &c, 1);
 27a:	8656                	mv	a2,s5
 27c:	85da                	mv	a1,s6
 27e:	4501                	li	a0,0
 280:	190000ef          	jal	410 <read>
    if(cc < 1)
 284:	00a05d63          	blez	a0,29e <gets+0x56>
      break;
    buf[i++] = c;
 288:	faf44783          	lbu	a5,-81(s0)
 28c:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 290:	0905                	addi	s2,s2,1
 292:	ff678713          	addi	a4,a5,-10
 296:	c319                	beqz	a4,29c <gets+0x54>
 298:	17cd                	addi	a5,a5,-13
 29a:	fbf1                	bnez	a5,26e <gets+0x26>
    buf[i++] = c;
 29c:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 29e:	9c5e                	add	s8,s8,s7
 2a0:	000c0023          	sb	zero,0(s8)
  return buf;
}
 2a4:	855e                	mv	a0,s7
 2a6:	60e6                	ld	ra,88(sp)
 2a8:	6446                	ld	s0,80(sp)
 2aa:	64a6                	ld	s1,72(sp)
 2ac:	6906                	ld	s2,64(sp)
 2ae:	79e2                	ld	s3,56(sp)
 2b0:	7a42                	ld	s4,48(sp)
 2b2:	7aa2                	ld	s5,40(sp)
 2b4:	7b02                	ld	s6,32(sp)
 2b6:	6be2                	ld	s7,24(sp)
 2b8:	6c42                	ld	s8,16(sp)
 2ba:	6125                	addi	sp,sp,96
 2bc:	8082                	ret

00000000000002be <stat>:

int
stat(const char *n, struct stat *st)
{
 2be:	1101                	addi	sp,sp,-32
 2c0:	ec06                	sd	ra,24(sp)
 2c2:	e822                	sd	s0,16(sp)
 2c4:	e04a                	sd	s2,0(sp)
 2c6:	1000                	addi	s0,sp,32
 2c8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2ca:	4581                	li	a1,0
 2cc:	16c000ef          	jal	438 <open>
  if(fd < 0)
 2d0:	02054263          	bltz	a0,2f4 <stat+0x36>
 2d4:	e426                	sd	s1,8(sp)
 2d6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2d8:	85ca                	mv	a1,s2
 2da:	176000ef          	jal	450 <fstat>
 2de:	892a                	mv	s2,a0
  close(fd);
 2e0:	8526                	mv	a0,s1
 2e2:	13e000ef          	jal	420 <close>
  return r;
 2e6:	64a2                	ld	s1,8(sp)
}
 2e8:	854a                	mv	a0,s2
 2ea:	60e2                	ld	ra,24(sp)
 2ec:	6442                	ld	s0,16(sp)
 2ee:	6902                	ld	s2,0(sp)
 2f0:	6105                	addi	sp,sp,32
 2f2:	8082                	ret
    return -1;
 2f4:	57fd                	li	a5,-1
 2f6:	893e                	mv	s2,a5
 2f8:	bfc5                	j	2e8 <stat+0x2a>

00000000000002fa <atoi>:

int
atoi(const char *s)
{
 2fa:	1141                	addi	sp,sp,-16
 2fc:	e406                	sd	ra,8(sp)
 2fe:	e022                	sd	s0,0(sp)
 300:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 302:	00054683          	lbu	a3,0(a0)
 306:	fd06879b          	addiw	a5,a3,-48
 30a:	0ff7f793          	zext.b	a5,a5
 30e:	4625                	li	a2,9
 310:	02f66963          	bltu	a2,a5,342 <atoi+0x48>
 314:	872a                	mv	a4,a0
  n = 0;
 316:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 318:	0705                	addi	a4,a4,1
 31a:	0025179b          	slliw	a5,a0,0x2
 31e:	9fa9                	addw	a5,a5,a0
 320:	0017979b          	slliw	a5,a5,0x1
 324:	9fb5                	addw	a5,a5,a3
 326:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 32a:	00074683          	lbu	a3,0(a4)
 32e:	fd06879b          	addiw	a5,a3,-48
 332:	0ff7f793          	zext.b	a5,a5
 336:	fef671e3          	bgeu	a2,a5,318 <atoi+0x1e>
  return n;
}
 33a:	60a2                	ld	ra,8(sp)
 33c:	6402                	ld	s0,0(sp)
 33e:	0141                	addi	sp,sp,16
 340:	8082                	ret
  n = 0;
 342:	4501                	li	a0,0
 344:	bfdd                	j	33a <atoi+0x40>

0000000000000346 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 346:	1141                	addi	sp,sp,-16
 348:	e406                	sd	ra,8(sp)
 34a:	e022                	sd	s0,0(sp)
 34c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 34e:	02b57563          	bgeu	a0,a1,378 <memmove+0x32>
    while(n-- > 0)
 352:	00c05f63          	blez	a2,370 <memmove+0x2a>
 356:	1602                	slli	a2,a2,0x20
 358:	9201                	srli	a2,a2,0x20
 35a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 35e:	872a                	mv	a4,a0
      *dst++ = *src++;
 360:	0585                	addi	a1,a1,1
 362:	0705                	addi	a4,a4,1
 364:	fff5c683          	lbu	a3,-1(a1)
 368:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 36c:	fee79ae3          	bne	a5,a4,360 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 370:	60a2                	ld	ra,8(sp)
 372:	6402                	ld	s0,0(sp)
 374:	0141                	addi	sp,sp,16
 376:	8082                	ret
    while(n-- > 0)
 378:	fec05ce3          	blez	a2,370 <memmove+0x2a>
    dst += n;
 37c:	00c50733          	add	a4,a0,a2
    src += n;
 380:	95b2                	add	a1,a1,a2
 382:	fff6079b          	addiw	a5,a2,-1
 386:	1782                	slli	a5,a5,0x20
 388:	9381                	srli	a5,a5,0x20
 38a:	fff7c793          	not	a5,a5
 38e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 390:	15fd                	addi	a1,a1,-1
 392:	177d                	addi	a4,a4,-1
 394:	0005c683          	lbu	a3,0(a1)
 398:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 39c:	fef71ae3          	bne	a4,a5,390 <memmove+0x4a>
 3a0:	bfc1                	j	370 <memmove+0x2a>

00000000000003a2 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 3a2:	1141                	addi	sp,sp,-16
 3a4:	e406                	sd	ra,8(sp)
 3a6:	e022                	sd	s0,0(sp)
 3a8:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3aa:	c61d                	beqz	a2,3d8 <memcmp+0x36>
 3ac:	1602                	slli	a2,a2,0x20
 3ae:	9201                	srli	a2,a2,0x20
 3b0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 3b4:	00054783          	lbu	a5,0(a0)
 3b8:	0005c703          	lbu	a4,0(a1)
 3bc:	00e79863          	bne	a5,a4,3cc <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 3c0:	0505                	addi	a0,a0,1
    p2++;
 3c2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3c4:	fed518e3          	bne	a0,a3,3b4 <memcmp+0x12>
  }
  return 0;
 3c8:	4501                	li	a0,0
 3ca:	a019                	j	3d0 <memcmp+0x2e>
      return *p1 - *p2;
 3cc:	40e7853b          	subw	a0,a5,a4
}
 3d0:	60a2                	ld	ra,8(sp)
 3d2:	6402                	ld	s0,0(sp)
 3d4:	0141                	addi	sp,sp,16
 3d6:	8082                	ret
  return 0;
 3d8:	4501                	li	a0,0
 3da:	bfdd                	j	3d0 <memcmp+0x2e>

00000000000003dc <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3dc:	1141                	addi	sp,sp,-16
 3de:	e406                	sd	ra,8(sp)
 3e0:	e022                	sd	s0,0(sp)
 3e2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3e4:	f63ff0ef          	jal	346 <memmove>
}
 3e8:	60a2                	ld	ra,8(sp)
 3ea:	6402                	ld	s0,0(sp)
 3ec:	0141                	addi	sp,sp,16
 3ee:	8082                	ret

00000000000003f0 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3f0:	4885                	li	a7,1
 ecall
 3f2:	00000073          	ecall
 ret
 3f6:	8082                	ret

00000000000003f8 <exit>:
.global exit
exit:
 li a7, SYS_exit
 3f8:	4889                	li	a7,2
 ecall
 3fa:	00000073          	ecall
 ret
 3fe:	8082                	ret

0000000000000400 <wait>:
.global wait
wait:
 li a7, SYS_wait
 400:	488d                	li	a7,3
 ecall
 402:	00000073          	ecall
 ret
 406:	8082                	ret

0000000000000408 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 408:	4891                	li	a7,4
 ecall
 40a:	00000073          	ecall
 ret
 40e:	8082                	ret

0000000000000410 <read>:
.global read
read:
 li a7, SYS_read
 410:	4895                	li	a7,5
 ecall
 412:	00000073          	ecall
 ret
 416:	8082                	ret

0000000000000418 <write>:
.global write
write:
 li a7, SYS_write
 418:	48c1                	li	a7,16
 ecall
 41a:	00000073          	ecall
 ret
 41e:	8082                	ret

0000000000000420 <close>:
.global close
close:
 li a7, SYS_close
 420:	48d5                	li	a7,21
 ecall
 422:	00000073          	ecall
 ret
 426:	8082                	ret

0000000000000428 <kill>:
.global kill
kill:
 li a7, SYS_kill
 428:	4899                	li	a7,6
 ecall
 42a:	00000073          	ecall
 ret
 42e:	8082                	ret

0000000000000430 <exec>:
.global exec
exec:
 li a7, SYS_exec
 430:	489d                	li	a7,7
 ecall
 432:	00000073          	ecall
 ret
 436:	8082                	ret

0000000000000438 <open>:
.global open
open:
 li a7, SYS_open
 438:	48bd                	li	a7,15
 ecall
 43a:	00000073          	ecall
 ret
 43e:	8082                	ret

0000000000000440 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 440:	48c5                	li	a7,17
 ecall
 442:	00000073          	ecall
 ret
 446:	8082                	ret

0000000000000448 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 448:	48c9                	li	a7,18
 ecall
 44a:	00000073          	ecall
 ret
 44e:	8082                	ret

0000000000000450 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 450:	48a1                	li	a7,8
 ecall
 452:	00000073          	ecall
 ret
 456:	8082                	ret

0000000000000458 <link>:
.global link
link:
 li a7, SYS_link
 458:	48cd                	li	a7,19
 ecall
 45a:	00000073          	ecall
 ret
 45e:	8082                	ret

0000000000000460 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 460:	48d1                	li	a7,20
 ecall
 462:	00000073          	ecall
 ret
 466:	8082                	ret

0000000000000468 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 468:	48a5                	li	a7,9
 ecall
 46a:	00000073          	ecall
 ret
 46e:	8082                	ret

0000000000000470 <dup>:
.global dup
dup:
 li a7, SYS_dup
 470:	48a9                	li	a7,10
 ecall
 472:	00000073          	ecall
 ret
 476:	8082                	ret

0000000000000478 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 478:	48ad                	li	a7,11
 ecall
 47a:	00000073          	ecall
 ret
 47e:	8082                	ret

0000000000000480 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 480:	48b1                	li	a7,12
 ecall
 482:	00000073          	ecall
 ret
 486:	8082                	ret

0000000000000488 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 488:	48b5                	li	a7,13
 ecall
 48a:	00000073          	ecall
 ret
 48e:	8082                	ret

0000000000000490 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 490:	48b9                	li	a7,14
 ecall
 492:	00000073          	ecall
 ret
 496:	8082                	ret

0000000000000498 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 498:	1101                	addi	sp,sp,-32
 49a:	ec06                	sd	ra,24(sp)
 49c:	e822                	sd	s0,16(sp)
 49e:	1000                	addi	s0,sp,32
 4a0:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4a4:	4605                	li	a2,1
 4a6:	fef40593          	addi	a1,s0,-17
 4aa:	f6fff0ef          	jal	418 <write>
}
 4ae:	60e2                	ld	ra,24(sp)
 4b0:	6442                	ld	s0,16(sp)
 4b2:	6105                	addi	sp,sp,32
 4b4:	8082                	ret

00000000000004b6 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 4b6:	7139                	addi	sp,sp,-64
 4b8:	fc06                	sd	ra,56(sp)
 4ba:	f822                	sd	s0,48(sp)
 4bc:	f04a                	sd	s2,32(sp)
 4be:	ec4e                	sd	s3,24(sp)
 4c0:	0080                	addi	s0,sp,64
 4c2:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4c4:	cac9                	beqz	a3,556 <printint+0xa0>
 4c6:	01f5d79b          	srliw	a5,a1,0x1f
 4ca:	c7d1                	beqz	a5,556 <printint+0xa0>
    neg = 1;
    x = -xx;
 4cc:	40b005bb          	negw	a1,a1
    neg = 1;
 4d0:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 4d2:	fc040993          	addi	s3,s0,-64
  neg = 0;
 4d6:	86ce                	mv	a3,s3
  i = 0;
 4d8:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 4da:	00000817          	auipc	a6,0x0
 4de:	5c680813          	addi	a6,a6,1478 # aa0 <digits>
 4e2:	88ba                	mv	a7,a4
 4e4:	0017051b          	addiw	a0,a4,1
 4e8:	872a                	mv	a4,a0
 4ea:	02c5f7bb          	remuw	a5,a1,a2
 4ee:	1782                	slli	a5,a5,0x20
 4f0:	9381                	srli	a5,a5,0x20
 4f2:	97c2                	add	a5,a5,a6
 4f4:	0007c783          	lbu	a5,0(a5)
 4f8:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 4fc:	87ae                	mv	a5,a1
 4fe:	02c5d5bb          	divuw	a1,a1,a2
 502:	0685                	addi	a3,a3,1
 504:	fcc7ffe3          	bgeu	a5,a2,4e2 <printint+0x2c>
  if(neg)
 508:	00030c63          	beqz	t1,520 <printint+0x6a>
    buf[i++] = '-';
 50c:	fd050793          	addi	a5,a0,-48
 510:	00878533          	add	a0,a5,s0
 514:	02d00793          	li	a5,45
 518:	fef50823          	sb	a5,-16(a0)
 51c:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 520:	02e05563          	blez	a4,54a <printint+0x94>
 524:	f426                	sd	s1,40(sp)
 526:	377d                	addiw	a4,a4,-1
 528:	00e984b3          	add	s1,s3,a4
 52c:	19fd                	addi	s3,s3,-1
 52e:	99ba                	add	s3,s3,a4
 530:	1702                	slli	a4,a4,0x20
 532:	9301                	srli	a4,a4,0x20
 534:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 538:	0004c583          	lbu	a1,0(s1)
 53c:	854a                	mv	a0,s2
 53e:	f5bff0ef          	jal	498 <putc>
  while(--i >= 0)
 542:	14fd                	addi	s1,s1,-1
 544:	ff349ae3          	bne	s1,s3,538 <printint+0x82>
 548:	74a2                	ld	s1,40(sp)
}
 54a:	70e2                	ld	ra,56(sp)
 54c:	7442                	ld	s0,48(sp)
 54e:	7902                	ld	s2,32(sp)
 550:	69e2                	ld	s3,24(sp)
 552:	6121                	addi	sp,sp,64
 554:	8082                	ret
  neg = 0;
 556:	4301                	li	t1,0
 558:	bfad                	j	4d2 <printint+0x1c>

000000000000055a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 55a:	711d                	addi	sp,sp,-96
 55c:	ec86                	sd	ra,88(sp)
 55e:	e8a2                	sd	s0,80(sp)
 560:	e4a6                	sd	s1,72(sp)
 562:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 564:	0005c483          	lbu	s1,0(a1)
 568:	20048963          	beqz	s1,77a <vprintf+0x220>
 56c:	e0ca                	sd	s2,64(sp)
 56e:	fc4e                	sd	s3,56(sp)
 570:	f852                	sd	s4,48(sp)
 572:	f456                	sd	s5,40(sp)
 574:	f05a                	sd	s6,32(sp)
 576:	ec5e                	sd	s7,24(sp)
 578:	e862                	sd	s8,16(sp)
 57a:	8b2a                	mv	s6,a0
 57c:	8a2e                	mv	s4,a1
 57e:	8bb2                	mv	s7,a2
  state = 0;
 580:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 582:	4901                	li	s2,0
 584:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 586:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 58a:	06400c13          	li	s8,100
 58e:	a00d                	j	5b0 <vprintf+0x56>
        putc(fd, c0);
 590:	85a6                	mv	a1,s1
 592:	855a                	mv	a0,s6
 594:	f05ff0ef          	jal	498 <putc>
 598:	a019                	j	59e <vprintf+0x44>
    } else if(state == '%'){
 59a:	03598363          	beq	s3,s5,5c0 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 59e:	0019079b          	addiw	a5,s2,1
 5a2:	893e                	mv	s2,a5
 5a4:	873e                	mv	a4,a5
 5a6:	97d2                	add	a5,a5,s4
 5a8:	0007c483          	lbu	s1,0(a5)
 5ac:	1c048063          	beqz	s1,76c <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 5b0:	0004879b          	sext.w	a5,s1
    if(state == 0){
 5b4:	fe0993e3          	bnez	s3,59a <vprintf+0x40>
      if(c0 == '%'){
 5b8:	fd579ce3          	bne	a5,s5,590 <vprintf+0x36>
        state = '%';
 5bc:	89be                	mv	s3,a5
 5be:	b7c5                	j	59e <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 5c0:	00ea06b3          	add	a3,s4,a4
 5c4:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 5c8:	1a060e63          	beqz	a2,784 <vprintf+0x22a>
      if(c0 == 'd'){
 5cc:	03878763          	beq	a5,s8,5fa <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5d0:	f9478693          	addi	a3,a5,-108
 5d4:	0016b693          	seqz	a3,a3
 5d8:	f9c60593          	addi	a1,a2,-100
 5dc:	e99d                	bnez	a1,612 <vprintf+0xb8>
 5de:	ca95                	beqz	a3,612 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5e0:	008b8493          	addi	s1,s7,8
 5e4:	4685                	li	a3,1
 5e6:	4629                	li	a2,10
 5e8:	000ba583          	lw	a1,0(s7)
 5ec:	855a                	mv	a0,s6
 5ee:	ec9ff0ef          	jal	4b6 <printint>
        i += 1;
 5f2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5f4:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 5f6:	4981                	li	s3,0
 5f8:	b75d                	j	59e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5fa:	008b8493          	addi	s1,s7,8
 5fe:	4685                	li	a3,1
 600:	4629                	li	a2,10
 602:	000ba583          	lw	a1,0(s7)
 606:	855a                	mv	a0,s6
 608:	eafff0ef          	jal	4b6 <printint>
 60c:	8ba6                	mv	s7,s1
      state = 0;
 60e:	4981                	li	s3,0
 610:	b779                	j	59e <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 612:	9752                	add	a4,a4,s4
 614:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 618:	f9460713          	addi	a4,a2,-108
 61c:	00173713          	seqz	a4,a4
 620:	8f75                	and	a4,a4,a3
 622:	f9c58513          	addi	a0,a1,-100
 626:	16051963          	bnez	a0,798 <vprintf+0x23e>
 62a:	16070763          	beqz	a4,798 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 62e:	008b8493          	addi	s1,s7,8
 632:	4685                	li	a3,1
 634:	4629                	li	a2,10
 636:	000ba583          	lw	a1,0(s7)
 63a:	855a                	mv	a0,s6
 63c:	e7bff0ef          	jal	4b6 <printint>
        i += 2;
 640:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 642:	8ba6                	mv	s7,s1
      state = 0;
 644:	4981                	li	s3,0
        i += 2;
 646:	bfa1                	j	59e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 648:	008b8493          	addi	s1,s7,8
 64c:	4681                	li	a3,0
 64e:	4629                	li	a2,10
 650:	000ba583          	lw	a1,0(s7)
 654:	855a                	mv	a0,s6
 656:	e61ff0ef          	jal	4b6 <printint>
 65a:	8ba6                	mv	s7,s1
      state = 0;
 65c:	4981                	li	s3,0
 65e:	b781                	j	59e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 660:	008b8493          	addi	s1,s7,8
 664:	4681                	li	a3,0
 666:	4629                	li	a2,10
 668:	000ba583          	lw	a1,0(s7)
 66c:	855a                	mv	a0,s6
 66e:	e49ff0ef          	jal	4b6 <printint>
        i += 1;
 672:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 674:	8ba6                	mv	s7,s1
      state = 0;
 676:	4981                	li	s3,0
 678:	b71d                	j	59e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 67a:	008b8493          	addi	s1,s7,8
 67e:	4681                	li	a3,0
 680:	4629                	li	a2,10
 682:	000ba583          	lw	a1,0(s7)
 686:	855a                	mv	a0,s6
 688:	e2fff0ef          	jal	4b6 <printint>
        i += 2;
 68c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 68e:	8ba6                	mv	s7,s1
      state = 0;
 690:	4981                	li	s3,0
        i += 2;
 692:	b731                	j	59e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 694:	008b8493          	addi	s1,s7,8
 698:	4681                	li	a3,0
 69a:	4641                	li	a2,16
 69c:	000ba583          	lw	a1,0(s7)
 6a0:	855a                	mv	a0,s6
 6a2:	e15ff0ef          	jal	4b6 <printint>
 6a6:	8ba6                	mv	s7,s1
      state = 0;
 6a8:	4981                	li	s3,0
 6aa:	bdd5                	j	59e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ac:	008b8493          	addi	s1,s7,8
 6b0:	4681                	li	a3,0
 6b2:	4641                	li	a2,16
 6b4:	000ba583          	lw	a1,0(s7)
 6b8:	855a                	mv	a0,s6
 6ba:	dfdff0ef          	jal	4b6 <printint>
        i += 1;
 6be:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6c0:	8ba6                	mv	s7,s1
      state = 0;
 6c2:	4981                	li	s3,0
 6c4:	bde9                	j	59e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6c6:	008b8493          	addi	s1,s7,8
 6ca:	4681                	li	a3,0
 6cc:	4641                	li	a2,16
 6ce:	000ba583          	lw	a1,0(s7)
 6d2:	855a                	mv	a0,s6
 6d4:	de3ff0ef          	jal	4b6 <printint>
        i += 2;
 6d8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6da:	8ba6                	mv	s7,s1
      state = 0;
 6dc:	4981                	li	s3,0
        i += 2;
 6de:	b5c1                	j	59e <vprintf+0x44>
 6e0:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6e2:	008b8793          	addi	a5,s7,8
 6e6:	8cbe                	mv	s9,a5
 6e8:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6ec:	03000593          	li	a1,48
 6f0:	855a                	mv	a0,s6
 6f2:	da7ff0ef          	jal	498 <putc>
  putc(fd, 'x');
 6f6:	07800593          	li	a1,120
 6fa:	855a                	mv	a0,s6
 6fc:	d9dff0ef          	jal	498 <putc>
 700:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 702:	00000b97          	auipc	s7,0x0
 706:	39eb8b93          	addi	s7,s7,926 # aa0 <digits>
 70a:	03c9d793          	srli	a5,s3,0x3c
 70e:	97de                	add	a5,a5,s7
 710:	0007c583          	lbu	a1,0(a5)
 714:	855a                	mv	a0,s6
 716:	d83ff0ef          	jal	498 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 71a:	0992                	slli	s3,s3,0x4
 71c:	34fd                	addiw	s1,s1,-1
 71e:	f4f5                	bnez	s1,70a <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 720:	8be6                	mv	s7,s9
      state = 0;
 722:	4981                	li	s3,0
 724:	6ca2                	ld	s9,8(sp)
 726:	bda5                	j	59e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 728:	008b8993          	addi	s3,s7,8
 72c:	000bb483          	ld	s1,0(s7)
 730:	cc91                	beqz	s1,74c <vprintf+0x1f2>
        for(; *s; s++)
 732:	0004c583          	lbu	a1,0(s1)
 736:	c985                	beqz	a1,766 <vprintf+0x20c>
          putc(fd, *s);
 738:	855a                	mv	a0,s6
 73a:	d5fff0ef          	jal	498 <putc>
        for(; *s; s++)
 73e:	0485                	addi	s1,s1,1
 740:	0004c583          	lbu	a1,0(s1)
 744:	f9f5                	bnez	a1,738 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 746:	8bce                	mv	s7,s3
      state = 0;
 748:	4981                	li	s3,0
 74a:	bd91                	j	59e <vprintf+0x44>
          s = "(null)";
 74c:	00000497          	auipc	s1,0x0
 750:	34c48493          	addi	s1,s1,844 # a98 <malloc+0x1b8>
        for(; *s; s++)
 754:	02800593          	li	a1,40
 758:	b7c5                	j	738 <vprintf+0x1de>
        putc(fd, '%');
 75a:	85be                	mv	a1,a5
 75c:	855a                	mv	a0,s6
 75e:	d3bff0ef          	jal	498 <putc>
      state = 0;
 762:	4981                	li	s3,0
 764:	bd2d                	j	59e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 766:	8bce                	mv	s7,s3
      state = 0;
 768:	4981                	li	s3,0
 76a:	bd15                	j	59e <vprintf+0x44>
 76c:	6906                	ld	s2,64(sp)
 76e:	79e2                	ld	s3,56(sp)
 770:	7a42                	ld	s4,48(sp)
 772:	7aa2                	ld	s5,40(sp)
 774:	7b02                	ld	s6,32(sp)
 776:	6be2                	ld	s7,24(sp)
 778:	6c42                	ld	s8,16(sp)
    }
  }
}
 77a:	60e6                	ld	ra,88(sp)
 77c:	6446                	ld	s0,80(sp)
 77e:	64a6                	ld	s1,72(sp)
 780:	6125                	addi	sp,sp,96
 782:	8082                	ret
      if(c0 == 'd'){
 784:	06400713          	li	a4,100
 788:	e6e789e3          	beq	a5,a4,5fa <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 78c:	f9478693          	addi	a3,a5,-108
 790:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 794:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 796:	4701                	li	a4,0
      } else if(c0 == 'u'){
 798:	07500513          	li	a0,117
 79c:	eaa786e3          	beq	a5,a0,648 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 7a0:	f8b60513          	addi	a0,a2,-117
 7a4:	e119                	bnez	a0,7aa <vprintf+0x250>
 7a6:	ea069de3          	bnez	a3,660 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 7aa:	f8b58513          	addi	a0,a1,-117
 7ae:	e119                	bnez	a0,7b4 <vprintf+0x25a>
 7b0:	ec0715e3          	bnez	a4,67a <vprintf+0x120>
      } else if(c0 == 'x'){
 7b4:	07800513          	li	a0,120
 7b8:	eca78ee3          	beq	a5,a0,694 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 7bc:	f8860613          	addi	a2,a2,-120
 7c0:	e219                	bnez	a2,7c6 <vprintf+0x26c>
 7c2:	ee0695e3          	bnez	a3,6ac <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 7c6:	f8858593          	addi	a1,a1,-120
 7ca:	e199                	bnez	a1,7d0 <vprintf+0x276>
 7cc:	ee071de3          	bnez	a4,6c6 <vprintf+0x16c>
      } else if(c0 == 'p'){
 7d0:	07000713          	li	a4,112
 7d4:	f0e786e3          	beq	a5,a4,6e0 <vprintf+0x186>
      } else if(c0 == 's'){
 7d8:	07300713          	li	a4,115
 7dc:	f4e786e3          	beq	a5,a4,728 <vprintf+0x1ce>
      } else if(c0 == '%'){
 7e0:	02500713          	li	a4,37
 7e4:	f6e78be3          	beq	a5,a4,75a <vprintf+0x200>
        putc(fd, '%');
 7e8:	02500593          	li	a1,37
 7ec:	855a                	mv	a0,s6
 7ee:	cabff0ef          	jal	498 <putc>
        putc(fd, c0);
 7f2:	85a6                	mv	a1,s1
 7f4:	855a                	mv	a0,s6
 7f6:	ca3ff0ef          	jal	498 <putc>
      state = 0;
 7fa:	4981                	li	s3,0
 7fc:	b34d                	j	59e <vprintf+0x44>

00000000000007fe <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7fe:	715d                	addi	sp,sp,-80
 800:	ec06                	sd	ra,24(sp)
 802:	e822                	sd	s0,16(sp)
 804:	1000                	addi	s0,sp,32
 806:	e010                	sd	a2,0(s0)
 808:	e414                	sd	a3,8(s0)
 80a:	e818                	sd	a4,16(s0)
 80c:	ec1c                	sd	a5,24(s0)
 80e:	03043023          	sd	a6,32(s0)
 812:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 816:	8622                	mv	a2,s0
 818:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 81c:	d3fff0ef          	jal	55a <vprintf>
}
 820:	60e2                	ld	ra,24(sp)
 822:	6442                	ld	s0,16(sp)
 824:	6161                	addi	sp,sp,80
 826:	8082                	ret

0000000000000828 <printf>:

void
printf(const char *fmt, ...)
{
 828:	711d                	addi	sp,sp,-96
 82a:	ec06                	sd	ra,24(sp)
 82c:	e822                	sd	s0,16(sp)
 82e:	1000                	addi	s0,sp,32
 830:	e40c                	sd	a1,8(s0)
 832:	e810                	sd	a2,16(s0)
 834:	ec14                	sd	a3,24(s0)
 836:	f018                	sd	a4,32(s0)
 838:	f41c                	sd	a5,40(s0)
 83a:	03043823          	sd	a6,48(s0)
 83e:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 842:	00840613          	addi	a2,s0,8
 846:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 84a:	85aa                	mv	a1,a0
 84c:	4505                	li	a0,1
 84e:	d0dff0ef          	jal	55a <vprintf>
}
 852:	60e2                	ld	ra,24(sp)
 854:	6442                	ld	s0,16(sp)
 856:	6125                	addi	sp,sp,96
 858:	8082                	ret

000000000000085a <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 85a:	1141                	addi	sp,sp,-16
 85c:	e406                	sd	ra,8(sp)
 85e:	e022                	sd	s0,0(sp)
 860:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 862:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 866:	00000797          	auipc	a5,0x0
 86a:	79a7b783          	ld	a5,1946(a5) # 1000 <freep>
 86e:	a039                	j	87c <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 870:	6398                	ld	a4,0(a5)
 872:	00e7e463          	bltu	a5,a4,87a <free+0x20>
 876:	00e6ea63          	bltu	a3,a4,88a <free+0x30>
{
 87a:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 87c:	fed7fae3          	bgeu	a5,a3,870 <free+0x16>
 880:	6398                	ld	a4,0(a5)
 882:	00e6e463          	bltu	a3,a4,88a <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 886:	fee7eae3          	bltu	a5,a4,87a <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 88a:	ff852583          	lw	a1,-8(a0)
 88e:	6390                	ld	a2,0(a5)
 890:	02059813          	slli	a6,a1,0x20
 894:	01c85713          	srli	a4,a6,0x1c
 898:	9736                	add	a4,a4,a3
 89a:	02e60563          	beq	a2,a4,8c4 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 89e:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 8a2:	4790                	lw	a2,8(a5)
 8a4:	02061593          	slli	a1,a2,0x20
 8a8:	01c5d713          	srli	a4,a1,0x1c
 8ac:	973e                	add	a4,a4,a5
 8ae:	02e68263          	beq	a3,a4,8d2 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8b2:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 8b4:	00000717          	auipc	a4,0x0
 8b8:	74f73623          	sd	a5,1868(a4) # 1000 <freep>
}
 8bc:	60a2                	ld	ra,8(sp)
 8be:	6402                	ld	s0,0(sp)
 8c0:	0141                	addi	sp,sp,16
 8c2:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 8c4:	4618                	lw	a4,8(a2)
 8c6:	9f2d                	addw	a4,a4,a1
 8c8:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8cc:	6398                	ld	a4,0(a5)
 8ce:	6310                	ld	a2,0(a4)
 8d0:	b7f9                	j	89e <free+0x44>
    p->s.size += bp->s.size;
 8d2:	ff852703          	lw	a4,-8(a0)
 8d6:	9f31                	addw	a4,a4,a2
 8d8:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8da:	ff053683          	ld	a3,-16(a0)
 8de:	bfd1                	j	8b2 <free+0x58>

00000000000008e0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8e0:	7139                	addi	sp,sp,-64
 8e2:	fc06                	sd	ra,56(sp)
 8e4:	f822                	sd	s0,48(sp)
 8e6:	f04a                	sd	s2,32(sp)
 8e8:	ec4e                	sd	s3,24(sp)
 8ea:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8ec:	02051993          	slli	s3,a0,0x20
 8f0:	0209d993          	srli	s3,s3,0x20
 8f4:	09bd                	addi	s3,s3,15
 8f6:	0049d993          	srli	s3,s3,0x4
 8fa:	2985                	addiw	s3,s3,1
 8fc:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 8fe:	00000517          	auipc	a0,0x0
 902:	70253503          	ld	a0,1794(a0) # 1000 <freep>
 906:	c905                	beqz	a0,936 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 908:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 90a:	4798                	lw	a4,8(a5)
 90c:	09377663          	bgeu	a4,s3,998 <malloc+0xb8>
 910:	f426                	sd	s1,40(sp)
 912:	e852                	sd	s4,16(sp)
 914:	e456                	sd	s5,8(sp)
 916:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 918:	8a4e                	mv	s4,s3
 91a:	6705                	lui	a4,0x1
 91c:	00e9f363          	bgeu	s3,a4,922 <malloc+0x42>
 920:	6a05                	lui	s4,0x1
 922:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 926:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 92a:	00000497          	auipc	s1,0x0
 92e:	6d648493          	addi	s1,s1,1750 # 1000 <freep>
  if(p == (char*)-1)
 932:	5afd                	li	s5,-1
 934:	a83d                	j	972 <malloc+0x92>
 936:	f426                	sd	s1,40(sp)
 938:	e852                	sd	s4,16(sp)
 93a:	e456                	sd	s5,8(sp)
 93c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 93e:	00000797          	auipc	a5,0x0
 942:	6d278793          	addi	a5,a5,1746 # 1010 <base>
 946:	00000717          	auipc	a4,0x0
 94a:	6af73d23          	sd	a5,1722(a4) # 1000 <freep>
 94e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 950:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 954:	b7d1                	j	918 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 956:	6398                	ld	a4,0(a5)
 958:	e118                	sd	a4,0(a0)
 95a:	a899                	j	9b0 <malloc+0xd0>
  hp->s.size = nu;
 95c:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 960:	0541                	addi	a0,a0,16
 962:	ef9ff0ef          	jal	85a <free>
  return freep;
 966:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 968:	c125                	beqz	a0,9c8 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 96a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 96c:	4798                	lw	a4,8(a5)
 96e:	03277163          	bgeu	a4,s2,990 <malloc+0xb0>
    if(p == freep)
 972:	6098                	ld	a4,0(s1)
 974:	853e                	mv	a0,a5
 976:	fef71ae3          	bne	a4,a5,96a <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 97a:	8552                	mv	a0,s4
 97c:	b05ff0ef          	jal	480 <sbrk>
  if(p == (char*)-1)
 980:	fd551ee3          	bne	a0,s5,95c <malloc+0x7c>
        return 0;
 984:	4501                	li	a0,0
 986:	74a2                	ld	s1,40(sp)
 988:	6a42                	ld	s4,16(sp)
 98a:	6aa2                	ld	s5,8(sp)
 98c:	6b02                	ld	s6,0(sp)
 98e:	a03d                	j	9bc <malloc+0xdc>
 990:	74a2                	ld	s1,40(sp)
 992:	6a42                	ld	s4,16(sp)
 994:	6aa2                	ld	s5,8(sp)
 996:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 998:	fae90fe3          	beq	s2,a4,956 <malloc+0x76>
        p->s.size -= nunits;
 99c:	4137073b          	subw	a4,a4,s3
 9a0:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9a2:	02071693          	slli	a3,a4,0x20
 9a6:	01c6d713          	srli	a4,a3,0x1c
 9aa:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9ac:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9b0:	00000717          	auipc	a4,0x0
 9b4:	64a73823          	sd	a0,1616(a4) # 1000 <freep>
      return (void*)(p + 1);
 9b8:	01078513          	addi	a0,a5,16
  }
}
 9bc:	70e2                	ld	ra,56(sp)
 9be:	7442                	ld	s0,48(sp)
 9c0:	7902                	ld	s2,32(sp)
 9c2:	69e2                	ld	s3,24(sp)
 9c4:	6121                	addi	sp,sp,64
 9c6:	8082                	ret
 9c8:	74a2                	ld	s1,40(sp)
 9ca:	6a42                	ld	s4,16(sp)
 9cc:	6aa2                	ld	s5,8(sp)
 9ce:	6b02                	ld	s6,0(sp)
 9d0:	b7f5                	j	9bc <malloc+0xdc>
