
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00019117          	auipc	sp,0x19
    80000004:	b3010113          	addi	sp,sp,-1232 # 80018b30 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	501040ef          	jal	80004d16 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	00021797          	auipc	a5,0x21
    8000002c:	c0878793          	addi	a5,a5,-1016 # 80020c30 <end>
    80000030:	00f53733          	sltu	a4,a0,a5
    80000034:	47c5                	li	a5,17
    80000036:	07ee                	slli	a5,a5,0x1b
    80000038:	17fd                	addi	a5,a5,-1
    8000003a:	00a7b7b3          	sltu	a5,a5,a0
    8000003e:	8fd9                	or	a5,a5,a4
    80000040:	ef95                	bnez	a5,8000007c <kfree+0x60>
    80000042:	84aa                	mv	s1,a0
    80000044:	03451793          	slli	a5,a0,0x34
    80000048:	eb95                	bnez	a5,8000007c <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    8000004a:	6605                	lui	a2,0x1
    8000004c:	4585                	li	a1,1
    8000004e:	110000ef          	jal	8000015e <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000052:	00008917          	auipc	s2,0x8
    80000056:	8ae90913          	addi	s2,s2,-1874 # 80007900 <kmem>
    8000005a:	854a                	mv	a0,s2
    8000005c:	770050ef          	jal	800057cc <acquire>
  r->next = kmem.freelist;
    80000060:	01893783          	ld	a5,24(s2)
    80000064:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000066:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    8000006a:	854a                	mv	a0,s2
    8000006c:	7f4050ef          	jal	80005860 <release>
}
    80000070:	60e2                	ld	ra,24(sp)
    80000072:	6442                	ld	s0,16(sp)
    80000074:	64a2                	ld	s1,8(sp)
    80000076:	6902                	ld	s2,0(sp)
    80000078:	6105                	addi	sp,sp,32
    8000007a:	8082                	ret
    panic("kfree");
    8000007c:	00007517          	auipc	a0,0x7
    80000080:	f8450513          	addi	a0,a0,-124 # 80007000 <etext>
    80000084:	40a050ef          	jal	8000548e <panic>

0000000080000088 <freerange>:
{
    80000088:	7179                	addi	sp,sp,-48
    8000008a:	f406                	sd	ra,40(sp)
    8000008c:	f022                	sd	s0,32(sp)
    8000008e:	ec26                	sd	s1,24(sp)
    80000090:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000092:	6785                	lui	a5,0x1
    80000094:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000098:	00e504b3          	add	s1,a0,a4
    8000009c:	777d                	lui	a4,0xfffff
    8000009e:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000a0:	94be                	add	s1,s1,a5
    800000a2:	0295e263          	bltu	a1,s1,800000c6 <freerange+0x3e>
    800000a6:	e84a                	sd	s2,16(sp)
    800000a8:	e44e                	sd	s3,8(sp)
    800000aa:	e052                	sd	s4,0(sp)
    800000ac:	892e                	mv	s2,a1
    kfree(p);
    800000ae:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000b0:	89be                	mv	s3,a5
    kfree(p);
    800000b2:	01448533          	add	a0,s1,s4
    800000b6:	f67ff0ef          	jal	8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000ba:	94ce                	add	s1,s1,s3
    800000bc:	fe997be3          	bgeu	s2,s1,800000b2 <freerange+0x2a>
    800000c0:	6942                	ld	s2,16(sp)
    800000c2:	69a2                	ld	s3,8(sp)
    800000c4:	6a02                	ld	s4,0(sp)
}
    800000c6:	70a2                	ld	ra,40(sp)
    800000c8:	7402                	ld	s0,32(sp)
    800000ca:	64e2                	ld	s1,24(sp)
    800000cc:	6145                	addi	sp,sp,48
    800000ce:	8082                	ret

00000000800000d0 <kinit>:
{
    800000d0:	1141                	addi	sp,sp,-16
    800000d2:	e406                	sd	ra,8(sp)
    800000d4:	e022                	sd	s0,0(sp)
    800000d6:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d8:	00007597          	auipc	a1,0x7
    800000dc:	f3858593          	addi	a1,a1,-200 # 80007010 <etext+0x10>
    800000e0:	00008517          	auipc	a0,0x8
    800000e4:	82050513          	addi	a0,a0,-2016 # 80007900 <kmem>
    800000e8:	65a050ef          	jal	80005742 <initlock>
  freerange(end, (void*)PHYSTOP);
    800000ec:	45c5                	li	a1,17
    800000ee:	05ee                	slli	a1,a1,0x1b
    800000f0:	00021517          	auipc	a0,0x21
    800000f4:	b4050513          	addi	a0,a0,-1216 # 80020c30 <end>
    800000f8:	f91ff0ef          	jal	80000088 <freerange>
}
    800000fc:	60a2                	ld	ra,8(sp)
    800000fe:	6402                	ld	s0,0(sp)
    80000100:	0141                	addi	sp,sp,16
    80000102:	8082                	ret

0000000080000104 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000104:	1101                	addi	sp,sp,-32
    80000106:	ec06                	sd	ra,24(sp)
    80000108:	e822                	sd	s0,16(sp)
    8000010a:	e426                	sd	s1,8(sp)
    8000010c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    8000010e:	00007517          	auipc	a0,0x7
    80000112:	7f250513          	addi	a0,a0,2034 # 80007900 <kmem>
    80000116:	6b6050ef          	jal	800057cc <acquire>
  r = kmem.freelist;
    8000011a:	00007497          	auipc	s1,0x7
    8000011e:	7fe4b483          	ld	s1,2046(s1) # 80007918 <kmem+0x18>
  if(r)
    80000122:	c49d                	beqz	s1,80000150 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000124:	609c                	ld	a5,0(s1)
    80000126:	00007717          	auipc	a4,0x7
    8000012a:	7ef73923          	sd	a5,2034(a4) # 80007918 <kmem+0x18>
  release(&kmem.lock);
    8000012e:	00007517          	auipc	a0,0x7
    80000132:	7d250513          	addi	a0,a0,2002 # 80007900 <kmem>
    80000136:	72a050ef          	jal	80005860 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    8000013a:	6605                	lui	a2,0x1
    8000013c:	4595                	li	a1,5
    8000013e:	8526                	mv	a0,s1
    80000140:	01e000ef          	jal	8000015e <memset>
  return (void*)r;
}
    80000144:	8526                	mv	a0,s1
    80000146:	60e2                	ld	ra,24(sp)
    80000148:	6442                	ld	s0,16(sp)
    8000014a:	64a2                	ld	s1,8(sp)
    8000014c:	6105                	addi	sp,sp,32
    8000014e:	8082                	ret
  release(&kmem.lock);
    80000150:	00007517          	auipc	a0,0x7
    80000154:	7b050513          	addi	a0,a0,1968 # 80007900 <kmem>
    80000158:	708050ef          	jal	80005860 <release>
  if(r)
    8000015c:	b7e5                	j	80000144 <kalloc+0x40>

000000008000015e <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000015e:	1141                	addi	sp,sp,-16
    80000160:	e406                	sd	ra,8(sp)
    80000162:	e022                	sd	s0,0(sp)
    80000164:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000166:	ca19                	beqz	a2,8000017c <memset+0x1e>
    80000168:	87aa                	mv	a5,a0
    8000016a:	1602                	slli	a2,a2,0x20
    8000016c:	9201                	srli	a2,a2,0x20
    8000016e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000172:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000176:	0785                	addi	a5,a5,1
    80000178:	fee79de3          	bne	a5,a4,80000172 <memset+0x14>
  }
  return dst;
}
    8000017c:	60a2                	ld	ra,8(sp)
    8000017e:	6402                	ld	s0,0(sp)
    80000180:	0141                	addi	sp,sp,16
    80000182:	8082                	ret

0000000080000184 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000184:	1141                	addi	sp,sp,-16
    80000186:	e406                	sd	ra,8(sp)
    80000188:	e022                	sd	s0,0(sp)
    8000018a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    8000018c:	c61d                	beqz	a2,800001ba <memcmp+0x36>
    8000018e:	1602                	slli	a2,a2,0x20
    80000190:	9201                	srli	a2,a2,0x20
    80000192:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000196:	00054783          	lbu	a5,0(a0)
    8000019a:	0005c703          	lbu	a4,0(a1)
    8000019e:	00e79863          	bne	a5,a4,800001ae <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    800001a2:	0505                	addi	a0,a0,1
    800001a4:	0585                	addi	a1,a1,1
  while(n-- > 0){
    800001a6:	fed518e3          	bne	a0,a3,80000196 <memcmp+0x12>
  }

  return 0;
    800001aa:	4501                	li	a0,0
    800001ac:	a019                	j	800001b2 <memcmp+0x2e>
      return *s1 - *s2;
    800001ae:	40e7853b          	subw	a0,a5,a4
}
    800001b2:	60a2                	ld	ra,8(sp)
    800001b4:	6402                	ld	s0,0(sp)
    800001b6:	0141                	addi	sp,sp,16
    800001b8:	8082                	ret
  return 0;
    800001ba:	4501                	li	a0,0
    800001bc:	bfdd                	j	800001b2 <memcmp+0x2e>

00000000800001be <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001be:	1141                	addi	sp,sp,-16
    800001c0:	e406                	sd	ra,8(sp)
    800001c2:	e022                	sd	s0,0(sp)
    800001c4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001c6:	c205                	beqz	a2,800001e6 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001c8:	02a5e363          	bltu	a1,a0,800001ee <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001cc:	1602                	slli	a2,a2,0x20
    800001ce:	9201                	srli	a2,a2,0x20
    800001d0:	00c587b3          	add	a5,a1,a2
{
    800001d4:	872a                	mv	a4,a0
      *d++ = *s++;
    800001d6:	0585                	addi	a1,a1,1
    800001d8:	0705                	addi	a4,a4,1
    800001da:	fff5c683          	lbu	a3,-1(a1)
    800001de:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001e2:	feb79ae3          	bne	a5,a1,800001d6 <memmove+0x18>

  return dst;
}
    800001e6:	60a2                	ld	ra,8(sp)
    800001e8:	6402                	ld	s0,0(sp)
    800001ea:	0141                	addi	sp,sp,16
    800001ec:	8082                	ret
  if(s < d && s + n > d){
    800001ee:	02061693          	slli	a3,a2,0x20
    800001f2:	9281                	srli	a3,a3,0x20
    800001f4:	00d58733          	add	a4,a1,a3
    800001f8:	fce57ae3          	bgeu	a0,a4,800001cc <memmove+0xe>
    d += n;
    800001fc:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001fe:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000202:	1782                	slli	a5,a5,0x20
    80000204:	9381                	srli	a5,a5,0x20
    80000206:	fff7c793          	not	a5,a5
    8000020a:	97ba                	add	a5,a5,a4
      *--d = *--s;
    8000020c:	177d                	addi	a4,a4,-1
    8000020e:	16fd                	addi	a3,a3,-1
    80000210:	00074603          	lbu	a2,0(a4)
    80000214:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000218:	fee79ae3          	bne	a5,a4,8000020c <memmove+0x4e>
    8000021c:	b7e9                	j	800001e6 <memmove+0x28>

000000008000021e <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    8000021e:	1141                	addi	sp,sp,-16
    80000220:	e406                	sd	ra,8(sp)
    80000222:	e022                	sd	s0,0(sp)
    80000224:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000226:	f99ff0ef          	jal	800001be <memmove>
}
    8000022a:	60a2                	ld	ra,8(sp)
    8000022c:	6402                	ld	s0,0(sp)
    8000022e:	0141                	addi	sp,sp,16
    80000230:	8082                	ret

0000000080000232 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000232:	1141                	addi	sp,sp,-16
    80000234:	e406                	sd	ra,8(sp)
    80000236:	e022                	sd	s0,0(sp)
    80000238:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000023a:	ce11                	beqz	a2,80000256 <strncmp+0x24>
    8000023c:	00054783          	lbu	a5,0(a0)
    80000240:	cf89                	beqz	a5,8000025a <strncmp+0x28>
    80000242:	0005c703          	lbu	a4,0(a1)
    80000246:	00f71a63          	bne	a4,a5,8000025a <strncmp+0x28>
    n--, p++, q++;
    8000024a:	367d                	addiw	a2,a2,-1
    8000024c:	0505                	addi	a0,a0,1
    8000024e:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000250:	f675                	bnez	a2,8000023c <strncmp+0xa>
  if(n == 0)
    return 0;
    80000252:	4501                	li	a0,0
    80000254:	a801                	j	80000264 <strncmp+0x32>
    80000256:	4501                	li	a0,0
    80000258:	a031                	j	80000264 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    8000025a:	00054503          	lbu	a0,0(a0)
    8000025e:	0005c783          	lbu	a5,0(a1)
    80000262:	9d1d                	subw	a0,a0,a5
}
    80000264:	60a2                	ld	ra,8(sp)
    80000266:	6402                	ld	s0,0(sp)
    80000268:	0141                	addi	sp,sp,16
    8000026a:	8082                	ret

000000008000026c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    8000026c:	1141                	addi	sp,sp,-16
    8000026e:	e406                	sd	ra,8(sp)
    80000270:	e022                	sd	s0,0(sp)
    80000272:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000274:	87aa                	mv	a5,a0
    80000276:	a011                	j	8000027a <strncpy+0xe>
    80000278:	8636                	mv	a2,a3
    8000027a:	02c05863          	blez	a2,800002aa <strncpy+0x3e>
    8000027e:	fff6069b          	addiw	a3,a2,-1
    80000282:	8836                	mv	a6,a3
    80000284:	0785                	addi	a5,a5,1
    80000286:	0005c703          	lbu	a4,0(a1)
    8000028a:	fee78fa3          	sb	a4,-1(a5)
    8000028e:	0585                	addi	a1,a1,1
    80000290:	f765                	bnez	a4,80000278 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000292:	873e                	mv	a4,a5
    80000294:	01005b63          	blez	a6,800002aa <strncpy+0x3e>
    80000298:	9fb1                	addw	a5,a5,a2
    8000029a:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    8000029c:	0705                	addi	a4,a4,1
    8000029e:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    800002a2:	40e786bb          	subw	a3,a5,a4
    800002a6:	fed04be3          	bgtz	a3,8000029c <strncpy+0x30>
  return os;
}
    800002aa:	60a2                	ld	ra,8(sp)
    800002ac:	6402                	ld	s0,0(sp)
    800002ae:	0141                	addi	sp,sp,16
    800002b0:	8082                	ret

00000000800002b2 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    800002b2:	1141                	addi	sp,sp,-16
    800002b4:	e406                	sd	ra,8(sp)
    800002b6:	e022                	sd	s0,0(sp)
    800002b8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    800002ba:	02c05363          	blez	a2,800002e0 <safestrcpy+0x2e>
    800002be:	fff6069b          	addiw	a3,a2,-1
    800002c2:	1682                	slli	a3,a3,0x20
    800002c4:	9281                	srli	a3,a3,0x20
    800002c6:	96ae                	add	a3,a3,a1
    800002c8:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002ca:	00d58963          	beq	a1,a3,800002dc <safestrcpy+0x2a>
    800002ce:	0585                	addi	a1,a1,1
    800002d0:	0785                	addi	a5,a5,1
    800002d2:	fff5c703          	lbu	a4,-1(a1)
    800002d6:	fee78fa3          	sb	a4,-1(a5)
    800002da:	fb65                	bnez	a4,800002ca <safestrcpy+0x18>
    ;
  *s = 0;
    800002dc:	00078023          	sb	zero,0(a5)
  return os;
}
    800002e0:	60a2                	ld	ra,8(sp)
    800002e2:	6402                	ld	s0,0(sp)
    800002e4:	0141                	addi	sp,sp,16
    800002e6:	8082                	ret

00000000800002e8 <strlen>:

int
strlen(const char *s)
{
    800002e8:	1141                	addi	sp,sp,-16
    800002ea:	e406                	sd	ra,8(sp)
    800002ec:	e022                	sd	s0,0(sp)
    800002ee:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002f0:	00054783          	lbu	a5,0(a0)
    800002f4:	cf91                	beqz	a5,80000310 <strlen+0x28>
    800002f6:	00150793          	addi	a5,a0,1
    800002fa:	86be                	mv	a3,a5
    800002fc:	0785                	addi	a5,a5,1
    800002fe:	fff7c703          	lbu	a4,-1(a5)
    80000302:	ff65                	bnez	a4,800002fa <strlen+0x12>
    80000304:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000308:	60a2                	ld	ra,8(sp)
    8000030a:	6402                	ld	s0,0(sp)
    8000030c:	0141                	addi	sp,sp,16
    8000030e:	8082                	ret
  for(n = 0; s[n]; n++)
    80000310:	4501                	li	a0,0
    80000312:	bfdd                	j	80000308 <strlen+0x20>

0000000080000314 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000314:	1141                	addi	sp,sp,-16
    80000316:	e406                	sd	ra,8(sp)
    80000318:	e022                	sd	s0,0(sp)
    8000031a:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    8000031c:	233000ef          	jal	80000d4e <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000320:	00007717          	auipc	a4,0x7
    80000324:	5b070713          	addi	a4,a4,1456 # 800078d0 <started>
  if(cpuid() == 0){
    80000328:	c51d                	beqz	a0,80000356 <main+0x42>
    while(started == 0)
    8000032a:	431c                	lw	a5,0(a4)
    8000032c:	2781                	sext.w	a5,a5
    8000032e:	dff5                	beqz	a5,8000032a <main+0x16>
      ;
    __sync_synchronize();
    80000330:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000334:	21b000ef          	jal	80000d4e <cpuid>
    80000338:	85aa                	mv	a1,a0
    8000033a:	00007517          	auipc	a0,0x7
    8000033e:	cfe50513          	addi	a0,a0,-770 # 80007038 <etext+0x38>
    80000342:	63d040ef          	jal	8000517e <printf>
    kvminithart();    // turn on paging
    80000346:	080000ef          	jal	800003c6 <kvminithart>
    trapinithart();   // install kernel trap vector
    8000034a:	52a010ef          	jal	80001874 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    8000034e:	40a040ef          	jal	80004758 <plicinithart>
  }

  scheduler();        
    80000352:	667000ef          	jal	800011b8 <scheduler>
    consoleinit();
    80000356:	54f040ef          	jal	800050a4 <consoleinit>
    printfinit();
    8000035a:	16e050ef          	jal	800054c8 <printfinit>
    printf("\n");
    8000035e:	00007517          	auipc	a0,0x7
    80000362:	cba50513          	addi	a0,a0,-838 # 80007018 <etext+0x18>
    80000366:	619040ef          	jal	8000517e <printf>
    printf("xv6 kernel is booting\n");
    8000036a:	00007517          	auipc	a0,0x7
    8000036e:	cb650513          	addi	a0,a0,-842 # 80007020 <etext+0x20>
    80000372:	60d040ef          	jal	8000517e <printf>
    printf("\n");
    80000376:	00007517          	auipc	a0,0x7
    8000037a:	ca250513          	addi	a0,a0,-862 # 80007018 <etext+0x18>
    8000037e:	601040ef          	jal	8000517e <printf>
    kinit();         // physical page allocator
    80000382:	d4fff0ef          	jal	800000d0 <kinit>
    kvminit();       // create kernel page table
    80000386:	2cc000ef          	jal	80000652 <kvminit>
    kvminithart();   // turn on paging
    8000038a:	03c000ef          	jal	800003c6 <kvminithart>
    procinit();      // process table
    8000038e:	10b000ef          	jal	80000c98 <procinit>
    trapinit();      // trap vectors
    80000392:	4be010ef          	jal	80001850 <trapinit>
    trapinithart();  // install kernel trap vector
    80000396:	4de010ef          	jal	80001874 <trapinithart>
    plicinit();      // set up interrupt controller
    8000039a:	3a4040ef          	jal	8000473e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    8000039e:	3ba040ef          	jal	80004758 <plicinithart>
    binit();         // buffer cache
    800003a2:	30f010ef          	jal	80001eb0 <binit>
    iinit();         // inode table
    800003a6:	0ca020ef          	jal	80002470 <iinit>
    fileinit();      // file table
    800003aa:	6b1020ef          	jal	8000325a <fileinit>
    virtio_disk_init(); // emulated hard disk
    800003ae:	49a040ef          	jal	80004848 <virtio_disk_init>
    userinit();      // first user process
    800003b2:	43b000ef          	jal	80000fec <userinit>
    __sync_synchronize();
    800003b6:	0330000f          	fence	rw,rw
    started = 1;
    800003ba:	4785                	li	a5,1
    800003bc:	00007717          	auipc	a4,0x7
    800003c0:	50f72a23          	sw	a5,1300(a4) # 800078d0 <started>
    800003c4:	b779                	j	80000352 <main+0x3e>

00000000800003c6 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    800003c6:	1141                	addi	sp,sp,-16
    800003c8:	e406                	sd	ra,8(sp)
    800003ca:	e022                	sd	s0,0(sp)
    800003cc:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800003ce:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    800003d2:	00007797          	auipc	a5,0x7
    800003d6:	5067b783          	ld	a5,1286(a5) # 800078d8 <kernel_pagetable>
    800003da:	83b1                	srli	a5,a5,0xc
    800003dc:	577d                	li	a4,-1
    800003de:	177e                	slli	a4,a4,0x3f
    800003e0:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800003e2:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800003e6:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    800003ea:	60a2                	ld	ra,8(sp)
    800003ec:	6402                	ld	s0,0(sp)
    800003ee:	0141                	addi	sp,sp,16
    800003f0:	8082                	ret

00000000800003f2 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800003f2:	7139                	addi	sp,sp,-64
    800003f4:	fc06                	sd	ra,56(sp)
    800003f6:	f822                	sd	s0,48(sp)
    800003f8:	f426                	sd	s1,40(sp)
    800003fa:	f04a                	sd	s2,32(sp)
    800003fc:	ec4e                	sd	s3,24(sp)
    800003fe:	e852                	sd	s4,16(sp)
    80000400:	e456                	sd	s5,8(sp)
    80000402:	e05a                	sd	s6,0(sp)
    80000404:	0080                	addi	s0,sp,64
    80000406:	84aa                	mv	s1,a0
    80000408:	89ae                	mv	s3,a1
    8000040a:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    8000040c:	57fd                	li	a5,-1
    8000040e:	83e9                	srli	a5,a5,0x1a
    80000410:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000412:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000414:	04b7e263          	bltu	a5,a1,80000458 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000418:	0149d933          	srl	s2,s3,s4
    8000041c:	1ff97913          	andi	s2,s2,511
    80000420:	090e                	slli	s2,s2,0x3
    80000422:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000424:	00093483          	ld	s1,0(s2)
    80000428:	0014f793          	andi	a5,s1,1
    8000042c:	cf85                	beqz	a5,80000464 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    8000042e:	80a9                	srli	s1,s1,0xa
    80000430:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80000432:	3a5d                	addiw	s4,s4,-9
    80000434:	ff5a12e3          	bne	s4,s5,80000418 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000438:	00c9d513          	srli	a0,s3,0xc
    8000043c:	1ff57513          	andi	a0,a0,511
    80000440:	050e                	slli	a0,a0,0x3
    80000442:	9526                	add	a0,a0,s1
}
    80000444:	70e2                	ld	ra,56(sp)
    80000446:	7442                	ld	s0,48(sp)
    80000448:	74a2                	ld	s1,40(sp)
    8000044a:	7902                	ld	s2,32(sp)
    8000044c:	69e2                	ld	s3,24(sp)
    8000044e:	6a42                	ld	s4,16(sp)
    80000450:	6aa2                	ld	s5,8(sp)
    80000452:	6b02                	ld	s6,0(sp)
    80000454:	6121                	addi	sp,sp,64
    80000456:	8082                	ret
    panic("walk");
    80000458:	00007517          	auipc	a0,0x7
    8000045c:	bf850513          	addi	a0,a0,-1032 # 80007050 <etext+0x50>
    80000460:	02e050ef          	jal	8000548e <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000464:	020b0263          	beqz	s6,80000488 <walk+0x96>
    80000468:	c9dff0ef          	jal	80000104 <kalloc>
    8000046c:	84aa                	mv	s1,a0
    8000046e:	d979                	beqz	a0,80000444 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80000470:	6605                	lui	a2,0x1
    80000472:	4581                	li	a1,0
    80000474:	cebff0ef          	jal	8000015e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000478:	00c4d793          	srli	a5,s1,0xc
    8000047c:	07aa                	slli	a5,a5,0xa
    8000047e:	0017e793          	ori	a5,a5,1
    80000482:	00f93023          	sd	a5,0(s2)
    80000486:	b775                	j	80000432 <walk+0x40>
        return 0;
    80000488:	4501                	li	a0,0
    8000048a:	bf6d                	j	80000444 <walk+0x52>

000000008000048c <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000048c:	57fd                	li	a5,-1
    8000048e:	83e9                	srli	a5,a5,0x1a
    80000490:	00b7f463          	bgeu	a5,a1,80000498 <walkaddr+0xc>
    return 0;
    80000494:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000496:	8082                	ret
{
    80000498:	1141                	addi	sp,sp,-16
    8000049a:	e406                	sd	ra,8(sp)
    8000049c:	e022                	sd	s0,0(sp)
    8000049e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    800004a0:	4601                	li	a2,0
    800004a2:	f51ff0ef          	jal	800003f2 <walk>
  if(pte == 0)
    800004a6:	c901                	beqz	a0,800004b6 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    800004a8:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    800004aa:	0117f693          	andi	a3,a5,17
    800004ae:	4745                	li	a4,17
    return 0;
    800004b0:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    800004b2:	00e68663          	beq	a3,a4,800004be <walkaddr+0x32>
}
    800004b6:	60a2                	ld	ra,8(sp)
    800004b8:	6402                	ld	s0,0(sp)
    800004ba:	0141                	addi	sp,sp,16
    800004bc:	8082                	ret
  pa = PTE2PA(*pte);
    800004be:	83a9                	srli	a5,a5,0xa
    800004c0:	00c79513          	slli	a0,a5,0xc
  return pa;
    800004c4:	bfcd                	j	800004b6 <walkaddr+0x2a>

00000000800004c6 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800004c6:	715d                	addi	sp,sp,-80
    800004c8:	e486                	sd	ra,72(sp)
    800004ca:	e0a2                	sd	s0,64(sp)
    800004cc:	fc26                	sd	s1,56(sp)
    800004ce:	f84a                	sd	s2,48(sp)
    800004d0:	f44e                	sd	s3,40(sp)
    800004d2:	f052                	sd	s4,32(sp)
    800004d4:	ec56                	sd	s5,24(sp)
    800004d6:	e85a                	sd	s6,16(sp)
    800004d8:	e45e                	sd	s7,8(sp)
    800004da:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800004dc:	03459793          	slli	a5,a1,0x34
    800004e0:	eba1                	bnez	a5,80000530 <mappages+0x6a>
    800004e2:	8a2a                	mv	s4,a0
    800004e4:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800004e6:	03461793          	slli	a5,a2,0x34
    800004ea:	eba9                	bnez	a5,8000053c <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    800004ec:	ce31                	beqz	a2,80000548 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800004ee:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    800004f2:	80060613          	addi	a2,a2,-2048
    800004f6:	00b60933          	add	s2,a2,a1
  a = va;
    800004fa:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800004fc:	4b05                	li	s6,1
    800004fe:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80000502:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    80000504:	865a                	mv	a2,s6
    80000506:	85a6                	mv	a1,s1
    80000508:	8552                	mv	a0,s4
    8000050a:	ee9ff0ef          	jal	800003f2 <walk>
    8000050e:	c929                	beqz	a0,80000560 <mappages+0x9a>
    if(*pte & PTE_V)
    80000510:	611c                	ld	a5,0(a0)
    80000512:	8b85                	andi	a5,a5,1
    80000514:	e3a1                	bnez	a5,80000554 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000516:	013487b3          	add	a5,s1,s3
    8000051a:	83b1                	srli	a5,a5,0xc
    8000051c:	07aa                	slli	a5,a5,0xa
    8000051e:	0157e7b3          	or	a5,a5,s5
    80000522:	0017e793          	ori	a5,a5,1
    80000526:	e11c                	sd	a5,0(a0)
    if(a == last)
    80000528:	05248863          	beq	s1,s2,80000578 <mappages+0xb2>
    a += PGSIZE;
    8000052c:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    8000052e:	bfd9                	j	80000504 <mappages+0x3e>
    panic("mappages: va not aligned");
    80000530:	00007517          	auipc	a0,0x7
    80000534:	b2850513          	addi	a0,a0,-1240 # 80007058 <etext+0x58>
    80000538:	757040ef          	jal	8000548e <panic>
    panic("mappages: size not aligned");
    8000053c:	00007517          	auipc	a0,0x7
    80000540:	b3c50513          	addi	a0,a0,-1220 # 80007078 <etext+0x78>
    80000544:	74b040ef          	jal	8000548e <panic>
    panic("mappages: size");
    80000548:	00007517          	auipc	a0,0x7
    8000054c:	b5050513          	addi	a0,a0,-1200 # 80007098 <etext+0x98>
    80000550:	73f040ef          	jal	8000548e <panic>
      panic("mappages: remap");
    80000554:	00007517          	auipc	a0,0x7
    80000558:	b5450513          	addi	a0,a0,-1196 # 800070a8 <etext+0xa8>
    8000055c:	733040ef          	jal	8000548e <panic>
      return -1;
    80000560:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80000562:	60a6                	ld	ra,72(sp)
    80000564:	6406                	ld	s0,64(sp)
    80000566:	74e2                	ld	s1,56(sp)
    80000568:	7942                	ld	s2,48(sp)
    8000056a:	79a2                	ld	s3,40(sp)
    8000056c:	7a02                	ld	s4,32(sp)
    8000056e:	6ae2                	ld	s5,24(sp)
    80000570:	6b42                	ld	s6,16(sp)
    80000572:	6ba2                	ld	s7,8(sp)
    80000574:	6161                	addi	sp,sp,80
    80000576:	8082                	ret
  return 0;
    80000578:	4501                	li	a0,0
    8000057a:	b7e5                	j	80000562 <mappages+0x9c>

000000008000057c <kvmmap>:
{
    8000057c:	1141                	addi	sp,sp,-16
    8000057e:	e406                	sd	ra,8(sp)
    80000580:	e022                	sd	s0,0(sp)
    80000582:	0800                	addi	s0,sp,16
    80000584:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000586:	86b2                	mv	a3,a2
    80000588:	863e                	mv	a2,a5
    8000058a:	f3dff0ef          	jal	800004c6 <mappages>
    8000058e:	e509                	bnez	a0,80000598 <kvmmap+0x1c>
}
    80000590:	60a2                	ld	ra,8(sp)
    80000592:	6402                	ld	s0,0(sp)
    80000594:	0141                	addi	sp,sp,16
    80000596:	8082                	ret
    panic("kvmmap");
    80000598:	00007517          	auipc	a0,0x7
    8000059c:	b2050513          	addi	a0,a0,-1248 # 800070b8 <etext+0xb8>
    800005a0:	6ef040ef          	jal	8000548e <panic>

00000000800005a4 <kvmmake>:
{
    800005a4:	1101                	addi	sp,sp,-32
    800005a6:	ec06                	sd	ra,24(sp)
    800005a8:	e822                	sd	s0,16(sp)
    800005aa:	e426                	sd	s1,8(sp)
    800005ac:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800005ae:	b57ff0ef          	jal	80000104 <kalloc>
    800005b2:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800005b4:	6605                	lui	a2,0x1
    800005b6:	4581                	li	a1,0
    800005b8:	ba7ff0ef          	jal	8000015e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800005bc:	4719                	li	a4,6
    800005be:	6685                	lui	a3,0x1
    800005c0:	10000637          	lui	a2,0x10000
    800005c4:	85b2                	mv	a1,a2
    800005c6:	8526                	mv	a0,s1
    800005c8:	fb5ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800005cc:	4719                	li	a4,6
    800005ce:	6685                	lui	a3,0x1
    800005d0:	10001637          	lui	a2,0x10001
    800005d4:	85b2                	mv	a1,a2
    800005d6:	8526                	mv	a0,s1
    800005d8:	fa5ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800005dc:	4719                	li	a4,6
    800005de:	040006b7          	lui	a3,0x4000
    800005e2:	0c000637          	lui	a2,0xc000
    800005e6:	85b2                	mv	a1,a2
    800005e8:	8526                	mv	a0,s1
    800005ea:	f93ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800005ee:	4729                	li	a4,10
    800005f0:	80007697          	auipc	a3,0x80007
    800005f4:	a1068693          	addi	a3,a3,-1520 # 7000 <_entry-0x7fff9000>
    800005f8:	4605                	li	a2,1
    800005fa:	067e                	slli	a2,a2,0x1f
    800005fc:	85b2                	mv	a1,a2
    800005fe:	8526                	mv	a0,s1
    80000600:	f7dff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80000604:	4719                	li	a4,6
    80000606:	00007697          	auipc	a3,0x7
    8000060a:	9fa68693          	addi	a3,a3,-1542 # 80007000 <etext>
    8000060e:	47c5                	li	a5,17
    80000610:	07ee                	slli	a5,a5,0x1b
    80000612:	40d786b3          	sub	a3,a5,a3
    80000616:	00007617          	auipc	a2,0x7
    8000061a:	9ea60613          	addi	a2,a2,-1558 # 80007000 <etext>
    8000061e:	85b2                	mv	a1,a2
    80000620:	8526                	mv	a0,s1
    80000622:	f5bff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80000626:	4729                	li	a4,10
    80000628:	6685                	lui	a3,0x1
    8000062a:	00006617          	auipc	a2,0x6
    8000062e:	9d660613          	addi	a2,a2,-1578 # 80006000 <_trampoline>
    80000632:	040005b7          	lui	a1,0x4000
    80000636:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000638:	05b2                	slli	a1,a1,0xc
    8000063a:	8526                	mv	a0,s1
    8000063c:	f41ff0ef          	jal	8000057c <kvmmap>
  proc_mapstacks(kpgtbl);
    80000640:	8526                	mv	a0,s1
    80000642:	5b2000ef          	jal	80000bf4 <proc_mapstacks>
}
    80000646:	8526                	mv	a0,s1
    80000648:	60e2                	ld	ra,24(sp)
    8000064a:	6442                	ld	s0,16(sp)
    8000064c:	64a2                	ld	s1,8(sp)
    8000064e:	6105                	addi	sp,sp,32
    80000650:	8082                	ret

0000000080000652 <kvminit>:
{
    80000652:	1141                	addi	sp,sp,-16
    80000654:	e406                	sd	ra,8(sp)
    80000656:	e022                	sd	s0,0(sp)
    80000658:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000065a:	f4bff0ef          	jal	800005a4 <kvmmake>
    8000065e:	00007797          	auipc	a5,0x7
    80000662:	26a7bd23          	sd	a0,634(a5) # 800078d8 <kernel_pagetable>
}
    80000666:	60a2                	ld	ra,8(sp)
    80000668:	6402                	ld	s0,0(sp)
    8000066a:	0141                	addi	sp,sp,16
    8000066c:	8082                	ret

000000008000066e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000066e:	715d                	addi	sp,sp,-80
    80000670:	e486                	sd	ra,72(sp)
    80000672:	e0a2                	sd	s0,64(sp)
    80000674:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80000676:	03459793          	slli	a5,a1,0x34
    8000067a:	e39d                	bnez	a5,800006a0 <uvmunmap+0x32>
    8000067c:	f84a                	sd	s2,48(sp)
    8000067e:	f44e                	sd	s3,40(sp)
    80000680:	f052                	sd	s4,32(sp)
    80000682:	ec56                	sd	s5,24(sp)
    80000684:	e85a                	sd	s6,16(sp)
    80000686:	e45e                	sd	s7,8(sp)
    80000688:	8a2a                	mv	s4,a0
    8000068a:	892e                	mv	s2,a1
    8000068c:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000068e:	0632                	slli	a2,a2,0xc
    80000690:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    80000694:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80000696:	6b05                	lui	s6,0x1
    80000698:	0735ff63          	bgeu	a1,s3,80000716 <uvmunmap+0xa8>
    8000069c:	fc26                	sd	s1,56(sp)
    8000069e:	a0a9                	j	800006e8 <uvmunmap+0x7a>
    800006a0:	fc26                	sd	s1,56(sp)
    800006a2:	f84a                	sd	s2,48(sp)
    800006a4:	f44e                	sd	s3,40(sp)
    800006a6:	f052                	sd	s4,32(sp)
    800006a8:	ec56                	sd	s5,24(sp)
    800006aa:	e85a                	sd	s6,16(sp)
    800006ac:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    800006ae:	00007517          	auipc	a0,0x7
    800006b2:	a1250513          	addi	a0,a0,-1518 # 800070c0 <etext+0xc0>
    800006b6:	5d9040ef          	jal	8000548e <panic>
      panic("uvmunmap: walk");
    800006ba:	00007517          	auipc	a0,0x7
    800006be:	a1e50513          	addi	a0,a0,-1506 # 800070d8 <etext+0xd8>
    800006c2:	5cd040ef          	jal	8000548e <panic>
      panic("uvmunmap: not mapped");
    800006c6:	00007517          	auipc	a0,0x7
    800006ca:	a2250513          	addi	a0,a0,-1502 # 800070e8 <etext+0xe8>
    800006ce:	5c1040ef          	jal	8000548e <panic>
      panic("uvmunmap: not a leaf");
    800006d2:	00007517          	auipc	a0,0x7
    800006d6:	a2e50513          	addi	a0,a0,-1490 # 80007100 <etext+0x100>
    800006da:	5b5040ef          	jal	8000548e <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    800006de:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800006e2:	995a                	add	s2,s2,s6
    800006e4:	03397863          	bgeu	s2,s3,80000714 <uvmunmap+0xa6>
    if((pte = walk(pagetable, a, 0)) == 0)
    800006e8:	4601                	li	a2,0
    800006ea:	85ca                	mv	a1,s2
    800006ec:	8552                	mv	a0,s4
    800006ee:	d05ff0ef          	jal	800003f2 <walk>
    800006f2:	84aa                	mv	s1,a0
    800006f4:	d179                	beqz	a0,800006ba <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0)
    800006f6:	6108                	ld	a0,0(a0)
    800006f8:	00157793          	andi	a5,a0,1
    800006fc:	d7e9                	beqz	a5,800006c6 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    800006fe:	3ff57793          	andi	a5,a0,1023
    80000702:	fd7788e3          	beq	a5,s7,800006d2 <uvmunmap+0x64>
    if(do_free){
    80000706:	fc0a8ce3          	beqz	s5,800006de <uvmunmap+0x70>
      uint64 pa = PTE2PA(*pte);
    8000070a:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    8000070c:	0532                	slli	a0,a0,0xc
    8000070e:	90fff0ef          	jal	8000001c <kfree>
    80000712:	b7f1                	j	800006de <uvmunmap+0x70>
    80000714:	74e2                	ld	s1,56(sp)
    80000716:	7942                	ld	s2,48(sp)
    80000718:	79a2                	ld	s3,40(sp)
    8000071a:	7a02                	ld	s4,32(sp)
    8000071c:	6ae2                	ld	s5,24(sp)
    8000071e:	6b42                	ld	s6,16(sp)
    80000720:	6ba2                	ld	s7,8(sp)
  }
}
    80000722:	60a6                	ld	ra,72(sp)
    80000724:	6406                	ld	s0,64(sp)
    80000726:	6161                	addi	sp,sp,80
    80000728:	8082                	ret

000000008000072a <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000072a:	1101                	addi	sp,sp,-32
    8000072c:	ec06                	sd	ra,24(sp)
    8000072e:	e822                	sd	s0,16(sp)
    80000730:	e426                	sd	s1,8(sp)
    80000732:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80000734:	9d1ff0ef          	jal	80000104 <kalloc>
    80000738:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000073a:	c509                	beqz	a0,80000744 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000073c:	6605                	lui	a2,0x1
    8000073e:	4581                	li	a1,0
    80000740:	a1fff0ef          	jal	8000015e <memset>
  return pagetable;
}
    80000744:	8526                	mv	a0,s1
    80000746:	60e2                	ld	ra,24(sp)
    80000748:	6442                	ld	s0,16(sp)
    8000074a:	64a2                	ld	s1,8(sp)
    8000074c:	6105                	addi	sp,sp,32
    8000074e:	8082                	ret

0000000080000750 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80000750:	7179                	addi	sp,sp,-48
    80000752:	f406                	sd	ra,40(sp)
    80000754:	f022                	sd	s0,32(sp)
    80000756:	ec26                	sd	s1,24(sp)
    80000758:	e84a                	sd	s2,16(sp)
    8000075a:	e44e                	sd	s3,8(sp)
    8000075c:	e052                	sd	s4,0(sp)
    8000075e:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80000760:	6785                	lui	a5,0x1
    80000762:	04f67063          	bgeu	a2,a5,800007a2 <uvmfirst+0x52>
    80000766:	89aa                	mv	s3,a0
    80000768:	8a2e                	mv	s4,a1
    8000076a:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    8000076c:	999ff0ef          	jal	80000104 <kalloc>
    80000770:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000772:	6605                	lui	a2,0x1
    80000774:	4581                	li	a1,0
    80000776:	9e9ff0ef          	jal	8000015e <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    8000077a:	4779                	li	a4,30
    8000077c:	86ca                	mv	a3,s2
    8000077e:	6605                	lui	a2,0x1
    80000780:	4581                	li	a1,0
    80000782:	854e                	mv	a0,s3
    80000784:	d43ff0ef          	jal	800004c6 <mappages>
  memmove(mem, src, sz);
    80000788:	8626                	mv	a2,s1
    8000078a:	85d2                	mv	a1,s4
    8000078c:	854a                	mv	a0,s2
    8000078e:	a31ff0ef          	jal	800001be <memmove>
}
    80000792:	70a2                	ld	ra,40(sp)
    80000794:	7402                	ld	s0,32(sp)
    80000796:	64e2                	ld	s1,24(sp)
    80000798:	6942                	ld	s2,16(sp)
    8000079a:	69a2                	ld	s3,8(sp)
    8000079c:	6a02                	ld	s4,0(sp)
    8000079e:	6145                	addi	sp,sp,48
    800007a0:	8082                	ret
    panic("uvmfirst: more than a page");
    800007a2:	00007517          	auipc	a0,0x7
    800007a6:	97650513          	addi	a0,a0,-1674 # 80007118 <etext+0x118>
    800007aa:	4e5040ef          	jal	8000548e <panic>

00000000800007ae <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800007ae:	1101                	addi	sp,sp,-32
    800007b0:	ec06                	sd	ra,24(sp)
    800007b2:	e822                	sd	s0,16(sp)
    800007b4:	e426                	sd	s1,8(sp)
    800007b6:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800007b8:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800007ba:	00b67d63          	bgeu	a2,a1,800007d4 <uvmdealloc+0x26>
    800007be:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800007c0:	6785                	lui	a5,0x1
    800007c2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800007c4:	00f60733          	add	a4,a2,a5
    800007c8:	76fd                	lui	a3,0xfffff
    800007ca:	8f75                	and	a4,a4,a3
    800007cc:	97ae                	add	a5,a5,a1
    800007ce:	8ff5                	and	a5,a5,a3
    800007d0:	00f76863          	bltu	a4,a5,800007e0 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800007d4:	8526                	mv	a0,s1
    800007d6:	60e2                	ld	ra,24(sp)
    800007d8:	6442                	ld	s0,16(sp)
    800007da:	64a2                	ld	s1,8(sp)
    800007dc:	6105                	addi	sp,sp,32
    800007de:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800007e0:	8f99                	sub	a5,a5,a4
    800007e2:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800007e4:	4685                	li	a3,1
    800007e6:	0007861b          	sext.w	a2,a5
    800007ea:	85ba                	mv	a1,a4
    800007ec:	e83ff0ef          	jal	8000066e <uvmunmap>
    800007f0:	b7d5                	j	800007d4 <uvmdealloc+0x26>

00000000800007f2 <uvmalloc>:
  if(newsz < oldsz)
    800007f2:	0ab66163          	bltu	a2,a1,80000894 <uvmalloc+0xa2>
{
    800007f6:	715d                	addi	sp,sp,-80
    800007f8:	e486                	sd	ra,72(sp)
    800007fa:	e0a2                	sd	s0,64(sp)
    800007fc:	f84a                	sd	s2,48(sp)
    800007fe:	f052                	sd	s4,32(sp)
    80000800:	ec56                	sd	s5,24(sp)
    80000802:	e45e                	sd	s7,8(sp)
    80000804:	0880                	addi	s0,sp,80
    80000806:	8aaa                	mv	s5,a0
    80000808:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000080a:	6785                	lui	a5,0x1
    8000080c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000080e:	95be                	add	a1,a1,a5
    80000810:	77fd                	lui	a5,0xfffff
    80000812:	00f5f933          	and	s2,a1,a5
    80000816:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000818:	08c97063          	bgeu	s2,a2,80000898 <uvmalloc+0xa6>
    8000081c:	fc26                	sd	s1,56(sp)
    8000081e:	f44e                	sd	s3,40(sp)
    80000820:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    80000822:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000824:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80000828:	8ddff0ef          	jal	80000104 <kalloc>
    8000082c:	84aa                	mv	s1,a0
    if(mem == 0){
    8000082e:	c50d                	beqz	a0,80000858 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    80000830:	864e                	mv	a2,s3
    80000832:	4581                	li	a1,0
    80000834:	92bff0ef          	jal	8000015e <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000838:	875a                	mv	a4,s6
    8000083a:	86a6                	mv	a3,s1
    8000083c:	864e                	mv	a2,s3
    8000083e:	85ca                	mv	a1,s2
    80000840:	8556                	mv	a0,s5
    80000842:	c85ff0ef          	jal	800004c6 <mappages>
    80000846:	e915                	bnez	a0,8000087a <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000848:	994e                	add	s2,s2,s3
    8000084a:	fd496fe3          	bltu	s2,s4,80000828 <uvmalloc+0x36>
  return newsz;
    8000084e:	8552                	mv	a0,s4
    80000850:	74e2                	ld	s1,56(sp)
    80000852:	79a2                	ld	s3,40(sp)
    80000854:	6b42                	ld	s6,16(sp)
    80000856:	a811                	j	8000086a <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80000858:	865e                	mv	a2,s7
    8000085a:	85ca                	mv	a1,s2
    8000085c:	8556                	mv	a0,s5
    8000085e:	f51ff0ef          	jal	800007ae <uvmdealloc>
      return 0;
    80000862:	4501                	li	a0,0
    80000864:	74e2                	ld	s1,56(sp)
    80000866:	79a2                	ld	s3,40(sp)
    80000868:	6b42                	ld	s6,16(sp)
}
    8000086a:	60a6                	ld	ra,72(sp)
    8000086c:	6406                	ld	s0,64(sp)
    8000086e:	7942                	ld	s2,48(sp)
    80000870:	7a02                	ld	s4,32(sp)
    80000872:	6ae2                	ld	s5,24(sp)
    80000874:	6ba2                	ld	s7,8(sp)
    80000876:	6161                	addi	sp,sp,80
    80000878:	8082                	ret
      kfree(mem);
    8000087a:	8526                	mv	a0,s1
    8000087c:	fa0ff0ef          	jal	8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80000880:	865e                	mv	a2,s7
    80000882:	85ca                	mv	a1,s2
    80000884:	8556                	mv	a0,s5
    80000886:	f29ff0ef          	jal	800007ae <uvmdealloc>
      return 0;
    8000088a:	4501                	li	a0,0
    8000088c:	74e2                	ld	s1,56(sp)
    8000088e:	79a2                	ld	s3,40(sp)
    80000890:	6b42                	ld	s6,16(sp)
    80000892:	bfe1                	j	8000086a <uvmalloc+0x78>
    return oldsz;
    80000894:	852e                	mv	a0,a1
}
    80000896:	8082                	ret
  return newsz;
    80000898:	8532                	mv	a0,a2
    8000089a:	bfc1                	j	8000086a <uvmalloc+0x78>

000000008000089c <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000089c:	7179                	addi	sp,sp,-48
    8000089e:	f406                	sd	ra,40(sp)
    800008a0:	f022                	sd	s0,32(sp)
    800008a2:	ec26                	sd	s1,24(sp)
    800008a4:	e84a                	sd	s2,16(sp)
    800008a6:	e44e                	sd	s3,8(sp)
    800008a8:	1800                	addi	s0,sp,48
    800008aa:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800008ac:	84aa                	mv	s1,a0
    800008ae:	6905                	lui	s2,0x1
    800008b0:	992a                	add	s2,s2,a0
    800008b2:	a811                	j	800008c6 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    800008b4:	00007517          	auipc	a0,0x7
    800008b8:	88450513          	addi	a0,a0,-1916 # 80007138 <etext+0x138>
    800008bc:	3d3040ef          	jal	8000548e <panic>
  for(int i = 0; i < 512; i++){
    800008c0:	04a1                	addi	s1,s1,8
    800008c2:	03248163          	beq	s1,s2,800008e4 <freewalk+0x48>
    pte_t pte = pagetable[i];
    800008c6:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800008c8:	0017f713          	andi	a4,a5,1
    800008cc:	db75                	beqz	a4,800008c0 <freewalk+0x24>
    800008ce:	00e7f713          	andi	a4,a5,14
    800008d2:	f36d                	bnez	a4,800008b4 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800008d4:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800008d6:	00c79513          	slli	a0,a5,0xc
    800008da:	fc3ff0ef          	jal	8000089c <freewalk>
      pagetable[i] = 0;
    800008de:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800008e2:	bff9                	j	800008c0 <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800008e4:	854e                	mv	a0,s3
    800008e6:	f36ff0ef          	jal	8000001c <kfree>
}
    800008ea:	70a2                	ld	ra,40(sp)
    800008ec:	7402                	ld	s0,32(sp)
    800008ee:	64e2                	ld	s1,24(sp)
    800008f0:	6942                	ld	s2,16(sp)
    800008f2:	69a2                	ld	s3,8(sp)
    800008f4:	6145                	addi	sp,sp,48
    800008f6:	8082                	ret

00000000800008f8 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800008f8:	1101                	addi	sp,sp,-32
    800008fa:	ec06                	sd	ra,24(sp)
    800008fc:	e822                	sd	s0,16(sp)
    800008fe:	e426                	sd	s1,8(sp)
    80000900:	1000                	addi	s0,sp,32
    80000902:	84aa                	mv	s1,a0
  if(sz > 0)
    80000904:	e989                	bnez	a1,80000916 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80000906:	8526                	mv	a0,s1
    80000908:	f95ff0ef          	jal	8000089c <freewalk>
}
    8000090c:	60e2                	ld	ra,24(sp)
    8000090e:	6442                	ld	s0,16(sp)
    80000910:	64a2                	ld	s1,8(sp)
    80000912:	6105                	addi	sp,sp,32
    80000914:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80000916:	6785                	lui	a5,0x1
    80000918:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000091a:	95be                	add	a1,a1,a5
    8000091c:	4685                	li	a3,1
    8000091e:	00c5d613          	srli	a2,a1,0xc
    80000922:	4581                	li	a1,0
    80000924:	d4bff0ef          	jal	8000066e <uvmunmap>
    80000928:	bff9                	j	80000906 <uvmfree+0xe>

000000008000092a <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    8000092a:	c64d                	beqz	a2,800009d4 <uvmcopy+0xaa>
{
    8000092c:	715d                	addi	sp,sp,-80
    8000092e:	e486                	sd	ra,72(sp)
    80000930:	e0a2                	sd	s0,64(sp)
    80000932:	fc26                	sd	s1,56(sp)
    80000934:	f84a                	sd	s2,48(sp)
    80000936:	f44e                	sd	s3,40(sp)
    80000938:	f052                	sd	s4,32(sp)
    8000093a:	ec56                	sd	s5,24(sp)
    8000093c:	e85a                	sd	s6,16(sp)
    8000093e:	e45e                	sd	s7,8(sp)
    80000940:	0880                	addi	s0,sp,80
    80000942:	8b2a                	mv	s6,a0
    80000944:	8aae                	mv	s5,a1
    80000946:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80000948:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    8000094a:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    8000094c:	4601                	li	a2,0
    8000094e:	85ca                	mv	a1,s2
    80000950:	855a                	mv	a0,s6
    80000952:	aa1ff0ef          	jal	800003f2 <walk>
    80000956:	cd0d                	beqz	a0,80000990 <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    80000958:	00053b83          	ld	s7,0(a0)
    8000095c:	001bf793          	andi	a5,s7,1
    80000960:	cf95                	beqz	a5,8000099c <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    80000962:	fa2ff0ef          	jal	80000104 <kalloc>
    80000966:	84aa                	mv	s1,a0
    80000968:	c139                	beqz	a0,800009ae <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    8000096a:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    8000096e:	864e                	mv	a2,s3
    80000970:	05b2                	slli	a1,a1,0xc
    80000972:	84dff0ef          	jal	800001be <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80000976:	3ffbf713          	andi	a4,s7,1023
    8000097a:	86a6                	mv	a3,s1
    8000097c:	864e                	mv	a2,s3
    8000097e:	85ca                	mv	a1,s2
    80000980:	8556                	mv	a0,s5
    80000982:	b45ff0ef          	jal	800004c6 <mappages>
    80000986:	e10d                	bnez	a0,800009a8 <uvmcopy+0x7e>
  for(i = 0; i < sz; i += PGSIZE){
    80000988:	994e                	add	s2,s2,s3
    8000098a:	fd4961e3          	bltu	s2,s4,8000094c <uvmcopy+0x22>
    8000098e:	a805                	j	800009be <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    80000990:	00006517          	auipc	a0,0x6
    80000994:	7b850513          	addi	a0,a0,1976 # 80007148 <etext+0x148>
    80000998:	2f7040ef          	jal	8000548e <panic>
      panic("uvmcopy: page not present");
    8000099c:	00006517          	auipc	a0,0x6
    800009a0:	7cc50513          	addi	a0,a0,1996 # 80007168 <etext+0x168>
    800009a4:	2eb040ef          	jal	8000548e <panic>
      kfree(mem);
    800009a8:	8526                	mv	a0,s1
    800009aa:	e72ff0ef          	jal	8000001c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800009ae:	4685                	li	a3,1
    800009b0:	00c95613          	srli	a2,s2,0xc
    800009b4:	4581                	li	a1,0
    800009b6:	8556                	mv	a0,s5
    800009b8:	cb7ff0ef          	jal	8000066e <uvmunmap>
  return -1;
    800009bc:	557d                	li	a0,-1
}
    800009be:	60a6                	ld	ra,72(sp)
    800009c0:	6406                	ld	s0,64(sp)
    800009c2:	74e2                	ld	s1,56(sp)
    800009c4:	7942                	ld	s2,48(sp)
    800009c6:	79a2                	ld	s3,40(sp)
    800009c8:	7a02                	ld	s4,32(sp)
    800009ca:	6ae2                	ld	s5,24(sp)
    800009cc:	6b42                	ld	s6,16(sp)
    800009ce:	6ba2                	ld	s7,8(sp)
    800009d0:	6161                	addi	sp,sp,80
    800009d2:	8082                	ret
  return 0;
    800009d4:	4501                	li	a0,0
}
    800009d6:	8082                	ret

00000000800009d8 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800009d8:	1141                	addi	sp,sp,-16
    800009da:	e406                	sd	ra,8(sp)
    800009dc:	e022                	sd	s0,0(sp)
    800009de:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800009e0:	4601                	li	a2,0
    800009e2:	a11ff0ef          	jal	800003f2 <walk>
  if(pte == 0)
    800009e6:	c901                	beqz	a0,800009f6 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800009e8:	611c                	ld	a5,0(a0)
    800009ea:	9bbd                	andi	a5,a5,-17
    800009ec:	e11c                	sd	a5,0(a0)
}
    800009ee:	60a2                	ld	ra,8(sp)
    800009f0:	6402                	ld	s0,0(sp)
    800009f2:	0141                	addi	sp,sp,16
    800009f4:	8082                	ret
    panic("uvmclear");
    800009f6:	00006517          	auipc	a0,0x6
    800009fa:	79250513          	addi	a0,a0,1938 # 80007188 <etext+0x188>
    800009fe:	291040ef          	jal	8000548e <panic>

0000000080000a02 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    80000a02:	c2d9                	beqz	a3,80000a88 <copyout+0x86>
{
    80000a04:	711d                	addi	sp,sp,-96
    80000a06:	ec86                	sd	ra,88(sp)
    80000a08:	e8a2                	sd	s0,80(sp)
    80000a0a:	e4a6                	sd	s1,72(sp)
    80000a0c:	e0ca                	sd	s2,64(sp)
    80000a0e:	fc4e                	sd	s3,56(sp)
    80000a10:	f852                	sd	s4,48(sp)
    80000a12:	f456                	sd	s5,40(sp)
    80000a14:	f05a                	sd	s6,32(sp)
    80000a16:	ec5e                	sd	s7,24(sp)
    80000a18:	e862                	sd	s8,16(sp)
    80000a1a:	e466                	sd	s9,8(sp)
    80000a1c:	e06a                	sd	s10,0(sp)
    80000a1e:	1080                	addi	s0,sp,96
    80000a20:	8c2a                	mv	s8,a0
    80000a22:	892e                	mv	s2,a1
    80000a24:	8ab2                	mv	s5,a2
    80000a26:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80000a28:	7cfd                	lui	s9,0xfffff
    if(va0 >= MAXVA)
    80000a2a:	5bfd                	li	s7,-1
    80000a2c:	01abdb93          	srli	s7,s7,0x1a
      return -1;
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000a30:	4d55                	li	s10,21
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    n = PGSIZE - (dstva - va0);
    80000a32:	6b05                	lui	s6,0x1
    80000a34:	a015                	j	80000a58 <copyout+0x56>
    pa0 = PTE2PA(*pte);
    80000a36:	83a9                	srli	a5,a5,0xa
    80000a38:	07b2                	slli	a5,a5,0xc
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000a3a:	41390533          	sub	a0,s2,s3
    80000a3e:	0004861b          	sext.w	a2,s1
    80000a42:	85d6                	mv	a1,s5
    80000a44:	953e                	add	a0,a0,a5
    80000a46:	f78ff0ef          	jal	800001be <memmove>

    len -= n;
    80000a4a:	409a0a33          	sub	s4,s4,s1
    src += n;
    80000a4e:	9aa6                	add	s5,s5,s1
    dstva = va0 + PGSIZE;
    80000a50:	01698933          	add	s2,s3,s6
  while(len > 0){
    80000a54:	020a0863          	beqz	s4,80000a84 <copyout+0x82>
    va0 = PGROUNDDOWN(dstva);
    80000a58:	019979b3          	and	s3,s2,s9
    if(va0 >= MAXVA)
    80000a5c:	033be863          	bltu	s7,s3,80000a8c <copyout+0x8a>
    pte = walk(pagetable, va0, 0);
    80000a60:	4601                	li	a2,0
    80000a62:	85ce                	mv	a1,s3
    80000a64:	8562                	mv	a0,s8
    80000a66:	98dff0ef          	jal	800003f2 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000a6a:	c11d                	beqz	a0,80000a90 <copyout+0x8e>
    80000a6c:	611c                	ld	a5,0(a0)
    80000a6e:	0157f713          	andi	a4,a5,21
    80000a72:	03a71163          	bne	a4,s10,80000a94 <copyout+0x92>
    n = PGSIZE - (dstva - va0);
    80000a76:	412984b3          	sub	s1,s3,s2
    80000a7a:	94da                	add	s1,s1,s6
    if(n > len)
    80000a7c:	fa9a7de3          	bgeu	s4,s1,80000a36 <copyout+0x34>
    80000a80:	84d2                	mv	s1,s4
    80000a82:	bf55                	j	80000a36 <copyout+0x34>
  }
  return 0;
    80000a84:	4501                	li	a0,0
    80000a86:	a801                	j	80000a96 <copyout+0x94>
    80000a88:	4501                	li	a0,0
}
    80000a8a:	8082                	ret
      return -1;
    80000a8c:	557d                	li	a0,-1
    80000a8e:	a021                	j	80000a96 <copyout+0x94>
      return -1;
    80000a90:	557d                	li	a0,-1
    80000a92:	a011                	j	80000a96 <copyout+0x94>
    80000a94:	557d                	li	a0,-1
}
    80000a96:	60e6                	ld	ra,88(sp)
    80000a98:	6446                	ld	s0,80(sp)
    80000a9a:	64a6                	ld	s1,72(sp)
    80000a9c:	6906                	ld	s2,64(sp)
    80000a9e:	79e2                	ld	s3,56(sp)
    80000aa0:	7a42                	ld	s4,48(sp)
    80000aa2:	7aa2                	ld	s5,40(sp)
    80000aa4:	7b02                	ld	s6,32(sp)
    80000aa6:	6be2                	ld	s7,24(sp)
    80000aa8:	6c42                	ld	s8,16(sp)
    80000aaa:	6ca2                	ld	s9,8(sp)
    80000aac:	6d02                	ld	s10,0(sp)
    80000aae:	6125                	addi	sp,sp,96
    80000ab0:	8082                	ret

0000000080000ab2 <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80000ab2:	c6a5                	beqz	a3,80000b1a <copyin+0x68>
{
    80000ab4:	715d                	addi	sp,sp,-80
    80000ab6:	e486                	sd	ra,72(sp)
    80000ab8:	e0a2                	sd	s0,64(sp)
    80000aba:	fc26                	sd	s1,56(sp)
    80000abc:	f84a                	sd	s2,48(sp)
    80000abe:	f44e                	sd	s3,40(sp)
    80000ac0:	f052                	sd	s4,32(sp)
    80000ac2:	ec56                	sd	s5,24(sp)
    80000ac4:	e85a                	sd	s6,16(sp)
    80000ac6:	e45e                	sd	s7,8(sp)
    80000ac8:	e062                	sd	s8,0(sp)
    80000aca:	0880                	addi	s0,sp,80
    80000acc:	8b2a                	mv	s6,a0
    80000ace:	8a2e                	mv	s4,a1
    80000ad0:	8c32                	mv	s8,a2
    80000ad2:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000ad4:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000ad6:	6a85                	lui	s5,0x1
    80000ad8:	a00d                	j	80000afa <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000ada:	018505b3          	add	a1,a0,s8
    80000ade:	0004861b          	sext.w	a2,s1
    80000ae2:	412585b3          	sub	a1,a1,s2
    80000ae6:	8552                	mv	a0,s4
    80000ae8:	ed6ff0ef          	jal	800001be <memmove>

    len -= n;
    80000aec:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000af0:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000af2:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000af6:	02098063          	beqz	s3,80000b16 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000afa:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000afe:	85ca                	mv	a1,s2
    80000b00:	855a                	mv	a0,s6
    80000b02:	98bff0ef          	jal	8000048c <walkaddr>
    if(pa0 == 0)
    80000b06:	cd01                	beqz	a0,80000b1e <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000b08:	418904b3          	sub	s1,s2,s8
    80000b0c:	94d6                	add	s1,s1,s5
    if(n > len)
    80000b0e:	fc99f6e3          	bgeu	s3,s1,80000ada <copyin+0x28>
    80000b12:	84ce                	mv	s1,s3
    80000b14:	b7d9                	j	80000ada <copyin+0x28>
  }
  return 0;
    80000b16:	4501                	li	a0,0
    80000b18:	a021                	j	80000b20 <copyin+0x6e>
    80000b1a:	4501                	li	a0,0
}
    80000b1c:	8082                	ret
      return -1;
    80000b1e:	557d                	li	a0,-1
}
    80000b20:	60a6                	ld	ra,72(sp)
    80000b22:	6406                	ld	s0,64(sp)
    80000b24:	74e2                	ld	s1,56(sp)
    80000b26:	7942                	ld	s2,48(sp)
    80000b28:	79a2                	ld	s3,40(sp)
    80000b2a:	7a02                	ld	s4,32(sp)
    80000b2c:	6ae2                	ld	s5,24(sp)
    80000b2e:	6b42                	ld	s6,16(sp)
    80000b30:	6ba2                	ld	s7,8(sp)
    80000b32:	6c02                	ld	s8,0(sp)
    80000b34:	6161                	addi	sp,sp,80
    80000b36:	8082                	ret

0000000080000b38 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000b38:	cac5                	beqz	a3,80000be8 <copyinstr+0xb0>
{
    80000b3a:	715d                	addi	sp,sp,-80
    80000b3c:	e486                	sd	ra,72(sp)
    80000b3e:	e0a2                	sd	s0,64(sp)
    80000b40:	fc26                	sd	s1,56(sp)
    80000b42:	f84a                	sd	s2,48(sp)
    80000b44:	f44e                	sd	s3,40(sp)
    80000b46:	f052                	sd	s4,32(sp)
    80000b48:	ec56                	sd	s5,24(sp)
    80000b4a:	e85a                	sd	s6,16(sp)
    80000b4c:	e45e                	sd	s7,8(sp)
    80000b4e:	0880                	addi	s0,sp,80
    80000b50:	8aaa                	mv	s5,a0
    80000b52:	84ae                	mv	s1,a1
    80000b54:	8bb2                	mv	s7,a2
    80000b56:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000b58:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000b5a:	6a05                	lui	s4,0x1
    80000b5c:	a82d                	j	80000b96 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000b5e:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80000b62:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000b64:	0017c793          	xori	a5,a5,1
    80000b68:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000b6c:	60a6                	ld	ra,72(sp)
    80000b6e:	6406                	ld	s0,64(sp)
    80000b70:	74e2                	ld	s1,56(sp)
    80000b72:	7942                	ld	s2,48(sp)
    80000b74:	79a2                	ld	s3,40(sp)
    80000b76:	7a02                	ld	s4,32(sp)
    80000b78:	6ae2                	ld	s5,24(sp)
    80000b7a:	6b42                	ld	s6,16(sp)
    80000b7c:	6ba2                	ld	s7,8(sp)
    80000b7e:	6161                	addi	sp,sp,80
    80000b80:	8082                	ret
    80000b82:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80000b86:	9726                	add	a4,a4,s1
      --max;
    80000b88:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80000b8c:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80000b90:	04e58463          	beq	a1,a4,80000bd8 <copyinstr+0xa0>
{
    80000b94:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80000b96:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80000b9a:	85ca                	mv	a1,s2
    80000b9c:	8556                	mv	a0,s5
    80000b9e:	8efff0ef          	jal	8000048c <walkaddr>
    if(pa0 == 0)
    80000ba2:	cd0d                	beqz	a0,80000bdc <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80000ba4:	417906b3          	sub	a3,s2,s7
    80000ba8:	96d2                	add	a3,a3,s4
    if(n > max)
    80000baa:	00d9f363          	bgeu	s3,a3,80000bb0 <copyinstr+0x78>
    80000bae:	86ce                	mv	a3,s3
    while(n > 0){
    80000bb0:	ca85                	beqz	a3,80000be0 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80000bb2:	01750633          	add	a2,a0,s7
    80000bb6:	41260633          	sub	a2,a2,s2
    80000bba:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80000bbc:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80000bbe:	96a6                	add	a3,a3,s1
    80000bc0:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000bc2:	00f60733          	add	a4,a2,a5
    80000bc6:	00074703          	lbu	a4,0(a4)
    80000bca:	db51                	beqz	a4,80000b5e <copyinstr+0x26>
        *dst = *p;
    80000bcc:	00e78023          	sb	a4,0(a5)
      dst++;
    80000bd0:	0785                	addi	a5,a5,1
    while(n > 0){
    80000bd2:	fed797e3          	bne	a5,a3,80000bc0 <copyinstr+0x88>
    80000bd6:	b775                	j	80000b82 <copyinstr+0x4a>
    80000bd8:	4781                	li	a5,0
    80000bda:	b769                	j	80000b64 <copyinstr+0x2c>
      return -1;
    80000bdc:	557d                	li	a0,-1
    80000bde:	b779                	j	80000b6c <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80000be0:	6b85                	lui	s7,0x1
    80000be2:	9bca                	add	s7,s7,s2
    80000be4:	87a6                	mv	a5,s1
    80000be6:	b77d                	j	80000b94 <copyinstr+0x5c>
  int got_null = 0;
    80000be8:	4781                	li	a5,0
  if(got_null){
    80000bea:	0017c793          	xori	a5,a5,1
    80000bee:	40f0053b          	negw	a0,a5
}
    80000bf2:	8082                	ret

0000000080000bf4 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000bf4:	715d                	addi	sp,sp,-80
    80000bf6:	e486                	sd	ra,72(sp)
    80000bf8:	e0a2                	sd	s0,64(sp)
    80000bfa:	fc26                	sd	s1,56(sp)
    80000bfc:	f84a                	sd	s2,48(sp)
    80000bfe:	f44e                	sd	s3,40(sp)
    80000c00:	f052                	sd	s4,32(sp)
    80000c02:	ec56                	sd	s5,24(sp)
    80000c04:	e85a                	sd	s6,16(sp)
    80000c06:	e45e                	sd	s7,8(sp)
    80000c08:	e062                	sd	s8,0(sp)
    80000c0a:	0880                	addi	s0,sp,80
    80000c0c:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c0e:	00007497          	auipc	s1,0x7
    80000c12:	14248493          	addi	s1,s1,322 # 80007d50 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000c16:	8c26                	mv	s8,s1
    80000c18:	000a57b7          	lui	a5,0xa5
    80000c1c:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80000c20:	07b2                	slli	a5,a5,0xc
    80000c22:	fa578793          	addi	a5,a5,-91
    80000c26:	4fa50937          	lui	s2,0x4fa50
    80000c2a:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80000c2e:	1902                	slli	s2,s2,0x20
    80000c30:	993e                	add	s2,s2,a5
    80000c32:	040009b7          	lui	s3,0x4000
    80000c36:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000c38:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c3a:	4b99                	li	s7,6
    80000c3c:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c3e:	0000da97          	auipc	s5,0xd
    80000c42:	b12a8a93          	addi	s5,s5,-1262 # 8000d750 <tickslock>
    char *pa = kalloc();
    80000c46:	cbeff0ef          	jal	80000104 <kalloc>
    80000c4a:	862a                	mv	a2,a0
    if(pa == 0)
    80000c4c:	c121                	beqz	a0,80000c8c <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    80000c4e:	418485b3          	sub	a1,s1,s8
    80000c52:	858d                	srai	a1,a1,0x3
    80000c54:	032585b3          	mul	a1,a1,s2
    80000c58:	05b6                	slli	a1,a1,0xd
    80000c5a:	6789                	lui	a5,0x2
    80000c5c:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c5e:	875e                	mv	a4,s7
    80000c60:	86da                	mv	a3,s6
    80000c62:	40b985b3          	sub	a1,s3,a1
    80000c66:	8552                	mv	a0,s4
    80000c68:	915ff0ef          	jal	8000057c <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c6c:	16848493          	addi	s1,s1,360
    80000c70:	fd549be3          	bne	s1,s5,80000c46 <proc_mapstacks+0x52>
  }
}
    80000c74:	60a6                	ld	ra,72(sp)
    80000c76:	6406                	ld	s0,64(sp)
    80000c78:	74e2                	ld	s1,56(sp)
    80000c7a:	7942                	ld	s2,48(sp)
    80000c7c:	79a2                	ld	s3,40(sp)
    80000c7e:	7a02                	ld	s4,32(sp)
    80000c80:	6ae2                	ld	s5,24(sp)
    80000c82:	6b42                	ld	s6,16(sp)
    80000c84:	6ba2                	ld	s7,8(sp)
    80000c86:	6c02                	ld	s8,0(sp)
    80000c88:	6161                	addi	sp,sp,80
    80000c8a:	8082                	ret
      panic("kalloc");
    80000c8c:	00006517          	auipc	a0,0x6
    80000c90:	50c50513          	addi	a0,a0,1292 # 80007198 <etext+0x198>
    80000c94:	7fa040ef          	jal	8000548e <panic>

0000000080000c98 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000c98:	7139                	addi	sp,sp,-64
    80000c9a:	fc06                	sd	ra,56(sp)
    80000c9c:	f822                	sd	s0,48(sp)
    80000c9e:	f426                	sd	s1,40(sp)
    80000ca0:	f04a                	sd	s2,32(sp)
    80000ca2:	ec4e                	sd	s3,24(sp)
    80000ca4:	e852                	sd	s4,16(sp)
    80000ca6:	e456                	sd	s5,8(sp)
    80000ca8:	e05a                	sd	s6,0(sp)
    80000caa:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000cac:	00006597          	auipc	a1,0x6
    80000cb0:	4f458593          	addi	a1,a1,1268 # 800071a0 <etext+0x1a0>
    80000cb4:	00007517          	auipc	a0,0x7
    80000cb8:	c6c50513          	addi	a0,a0,-916 # 80007920 <pid_lock>
    80000cbc:	287040ef          	jal	80005742 <initlock>
  initlock(&wait_lock, "wait_lock");
    80000cc0:	00006597          	auipc	a1,0x6
    80000cc4:	4e858593          	addi	a1,a1,1256 # 800071a8 <etext+0x1a8>
    80000cc8:	00007517          	auipc	a0,0x7
    80000ccc:	c7050513          	addi	a0,a0,-912 # 80007938 <wait_lock>
    80000cd0:	273040ef          	jal	80005742 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cd4:	00007497          	auipc	s1,0x7
    80000cd8:	07c48493          	addi	s1,s1,124 # 80007d50 <proc>
      initlock(&p->lock, "proc");
    80000cdc:	00006b17          	auipc	s6,0x6
    80000ce0:	4dcb0b13          	addi	s6,s6,1244 # 800071b8 <etext+0x1b8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000ce4:	8aa6                	mv	s5,s1
    80000ce6:	000a57b7          	lui	a5,0xa5
    80000cea:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80000cee:	07b2                	slli	a5,a5,0xc
    80000cf0:	fa578793          	addi	a5,a5,-91
    80000cf4:	4fa50937          	lui	s2,0x4fa50
    80000cf8:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80000cfc:	1902                	slli	s2,s2,0x20
    80000cfe:	993e                	add	s2,s2,a5
    80000d00:	040009b7          	lui	s3,0x4000
    80000d04:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000d06:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d08:	0000da17          	auipc	s4,0xd
    80000d0c:	a48a0a13          	addi	s4,s4,-1464 # 8000d750 <tickslock>
      initlock(&p->lock, "proc");
    80000d10:	85da                	mv	a1,s6
    80000d12:	8526                	mv	a0,s1
    80000d14:	22f040ef          	jal	80005742 <initlock>
      p->state = UNUSED;
    80000d18:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000d1c:	415487b3          	sub	a5,s1,s5
    80000d20:	878d                	srai	a5,a5,0x3
    80000d22:	032787b3          	mul	a5,a5,s2
    80000d26:	07b6                	slli	a5,a5,0xd
    80000d28:	6709                	lui	a4,0x2
    80000d2a:	9fb9                	addw	a5,a5,a4
    80000d2c:	40f987b3          	sub	a5,s3,a5
    80000d30:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d32:	16848493          	addi	s1,s1,360
    80000d36:	fd449de3          	bne	s1,s4,80000d10 <procinit+0x78>
  }
}
    80000d3a:	70e2                	ld	ra,56(sp)
    80000d3c:	7442                	ld	s0,48(sp)
    80000d3e:	74a2                	ld	s1,40(sp)
    80000d40:	7902                	ld	s2,32(sp)
    80000d42:	69e2                	ld	s3,24(sp)
    80000d44:	6a42                	ld	s4,16(sp)
    80000d46:	6aa2                	ld	s5,8(sp)
    80000d48:	6b02                	ld	s6,0(sp)
    80000d4a:	6121                	addi	sp,sp,64
    80000d4c:	8082                	ret

0000000080000d4e <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000d4e:	1141                	addi	sp,sp,-16
    80000d50:	e406                	sd	ra,8(sp)
    80000d52:	e022                	sd	s0,0(sp)
    80000d54:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000d56:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000d58:	2501                	sext.w	a0,a0
    80000d5a:	60a2                	ld	ra,8(sp)
    80000d5c:	6402                	ld	s0,0(sp)
    80000d5e:	0141                	addi	sp,sp,16
    80000d60:	8082                	ret

0000000080000d62 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000d62:	1141                	addi	sp,sp,-16
    80000d64:	e406                	sd	ra,8(sp)
    80000d66:	e022                	sd	s0,0(sp)
    80000d68:	0800                	addi	s0,sp,16
    80000d6a:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000d6c:	2781                	sext.w	a5,a5
    80000d6e:	079e                	slli	a5,a5,0x7
  return c;
}
    80000d70:	00007517          	auipc	a0,0x7
    80000d74:	be050513          	addi	a0,a0,-1056 # 80007950 <cpus>
    80000d78:	953e                	add	a0,a0,a5
    80000d7a:	60a2                	ld	ra,8(sp)
    80000d7c:	6402                	ld	s0,0(sp)
    80000d7e:	0141                	addi	sp,sp,16
    80000d80:	8082                	ret

0000000080000d82 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000d82:	1101                	addi	sp,sp,-32
    80000d84:	ec06                	sd	ra,24(sp)
    80000d86:	e822                	sd	s0,16(sp)
    80000d88:	e426                	sd	s1,8(sp)
    80000d8a:	1000                	addi	s0,sp,32
  push_off();
    80000d8c:	1fd040ef          	jal	80005788 <push_off>
    80000d90:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000d92:	2781                	sext.w	a5,a5
    80000d94:	079e                	slli	a5,a5,0x7
    80000d96:	00007717          	auipc	a4,0x7
    80000d9a:	b8a70713          	addi	a4,a4,-1142 # 80007920 <pid_lock>
    80000d9e:	97ba                	add	a5,a5,a4
    80000da0:	7b9c                	ld	a5,48(a5)
    80000da2:	84be                	mv	s1,a5
  pop_off();
    80000da4:	26d040ef          	jal	80005810 <pop_off>
  return p;
}
    80000da8:	8526                	mv	a0,s1
    80000daa:	60e2                	ld	ra,24(sp)
    80000dac:	6442                	ld	s0,16(sp)
    80000dae:	64a2                	ld	s1,8(sp)
    80000db0:	6105                	addi	sp,sp,32
    80000db2:	8082                	ret

0000000080000db4 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000db4:	1141                	addi	sp,sp,-16
    80000db6:	e406                	sd	ra,8(sp)
    80000db8:	e022                	sd	s0,0(sp)
    80000dba:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000dbc:	fc7ff0ef          	jal	80000d82 <myproc>
    80000dc0:	2a1040ef          	jal	80005860 <release>

  if (first) {
    80000dc4:	00007797          	auipc	a5,0x7
    80000dc8:	abc7a783          	lw	a5,-1348(a5) # 80007880 <first.1>
    80000dcc:	e799                	bnez	a5,80000dda <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000dce:	2c3000ef          	jal	80001890 <usertrapret>
}
    80000dd2:	60a2                	ld	ra,8(sp)
    80000dd4:	6402                	ld	s0,0(sp)
    80000dd6:	0141                	addi	sp,sp,16
    80000dd8:	8082                	ret
    fsinit(ROOTDEV);
    80000dda:	4505                	li	a0,1
    80000ddc:	62a010ef          	jal	80002406 <fsinit>
    first = 0;
    80000de0:	00007797          	auipc	a5,0x7
    80000de4:	aa07a023          	sw	zero,-1376(a5) # 80007880 <first.1>
    __sync_synchronize();
    80000de8:	0330000f          	fence	rw,rw
    80000dec:	b7cd                	j	80000dce <forkret+0x1a>

0000000080000dee <allocpid>:
{
    80000dee:	1101                	addi	sp,sp,-32
    80000df0:	ec06                	sd	ra,24(sp)
    80000df2:	e822                	sd	s0,16(sp)
    80000df4:	e426                	sd	s1,8(sp)
    80000df6:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000df8:	00007517          	auipc	a0,0x7
    80000dfc:	b2850513          	addi	a0,a0,-1240 # 80007920 <pid_lock>
    80000e00:	1cd040ef          	jal	800057cc <acquire>
  pid = nextpid;
    80000e04:	00007797          	auipc	a5,0x7
    80000e08:	a8078793          	addi	a5,a5,-1408 # 80007884 <nextpid>
    80000e0c:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000e0e:	0014871b          	addiw	a4,s1,1
    80000e12:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000e14:	00007517          	auipc	a0,0x7
    80000e18:	b0c50513          	addi	a0,a0,-1268 # 80007920 <pid_lock>
    80000e1c:	245040ef          	jal	80005860 <release>
}
    80000e20:	8526                	mv	a0,s1
    80000e22:	60e2                	ld	ra,24(sp)
    80000e24:	6442                	ld	s0,16(sp)
    80000e26:	64a2                	ld	s1,8(sp)
    80000e28:	6105                	addi	sp,sp,32
    80000e2a:	8082                	ret

0000000080000e2c <proc_pagetable>:
{
    80000e2c:	1101                	addi	sp,sp,-32
    80000e2e:	ec06                	sd	ra,24(sp)
    80000e30:	e822                	sd	s0,16(sp)
    80000e32:	e426                	sd	s1,8(sp)
    80000e34:	e04a                	sd	s2,0(sp)
    80000e36:	1000                	addi	s0,sp,32
    80000e38:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000e3a:	8f1ff0ef          	jal	8000072a <uvmcreate>
    80000e3e:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000e40:	cd05                	beqz	a0,80000e78 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000e42:	4729                	li	a4,10
    80000e44:	00005697          	auipc	a3,0x5
    80000e48:	1bc68693          	addi	a3,a3,444 # 80006000 <_trampoline>
    80000e4c:	6605                	lui	a2,0x1
    80000e4e:	040005b7          	lui	a1,0x4000
    80000e52:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e54:	05b2                	slli	a1,a1,0xc
    80000e56:	e70ff0ef          	jal	800004c6 <mappages>
    80000e5a:	02054663          	bltz	a0,80000e86 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000e5e:	4719                	li	a4,6
    80000e60:	05893683          	ld	a3,88(s2)
    80000e64:	6605                	lui	a2,0x1
    80000e66:	020005b7          	lui	a1,0x2000
    80000e6a:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000e6c:	05b6                	slli	a1,a1,0xd
    80000e6e:	8526                	mv	a0,s1
    80000e70:	e56ff0ef          	jal	800004c6 <mappages>
    80000e74:	00054f63          	bltz	a0,80000e92 <proc_pagetable+0x66>
}
    80000e78:	8526                	mv	a0,s1
    80000e7a:	60e2                	ld	ra,24(sp)
    80000e7c:	6442                	ld	s0,16(sp)
    80000e7e:	64a2                	ld	s1,8(sp)
    80000e80:	6902                	ld	s2,0(sp)
    80000e82:	6105                	addi	sp,sp,32
    80000e84:	8082                	ret
    uvmfree(pagetable, 0);
    80000e86:	4581                	li	a1,0
    80000e88:	8526                	mv	a0,s1
    80000e8a:	a6fff0ef          	jal	800008f8 <uvmfree>
    return 0;
    80000e8e:	4481                	li	s1,0
    80000e90:	b7e5                	j	80000e78 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000e92:	4681                	li	a3,0
    80000e94:	4605                	li	a2,1
    80000e96:	040005b7          	lui	a1,0x4000
    80000e9a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e9c:	05b2                	slli	a1,a1,0xc
    80000e9e:	8526                	mv	a0,s1
    80000ea0:	fceff0ef          	jal	8000066e <uvmunmap>
    uvmfree(pagetable, 0);
    80000ea4:	4581                	li	a1,0
    80000ea6:	8526                	mv	a0,s1
    80000ea8:	a51ff0ef          	jal	800008f8 <uvmfree>
    return 0;
    80000eac:	4481                	li	s1,0
    80000eae:	b7e9                	j	80000e78 <proc_pagetable+0x4c>

0000000080000eb0 <proc_freepagetable>:
{
    80000eb0:	1101                	addi	sp,sp,-32
    80000eb2:	ec06                	sd	ra,24(sp)
    80000eb4:	e822                	sd	s0,16(sp)
    80000eb6:	e426                	sd	s1,8(sp)
    80000eb8:	e04a                	sd	s2,0(sp)
    80000eba:	1000                	addi	s0,sp,32
    80000ebc:	84aa                	mv	s1,a0
    80000ebe:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000ec0:	4681                	li	a3,0
    80000ec2:	4605                	li	a2,1
    80000ec4:	040005b7          	lui	a1,0x4000
    80000ec8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000eca:	05b2                	slli	a1,a1,0xc
    80000ecc:	fa2ff0ef          	jal	8000066e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000ed0:	4681                	li	a3,0
    80000ed2:	4605                	li	a2,1
    80000ed4:	020005b7          	lui	a1,0x2000
    80000ed8:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000eda:	05b6                	slli	a1,a1,0xd
    80000edc:	8526                	mv	a0,s1
    80000ede:	f90ff0ef          	jal	8000066e <uvmunmap>
  uvmfree(pagetable, sz);
    80000ee2:	85ca                	mv	a1,s2
    80000ee4:	8526                	mv	a0,s1
    80000ee6:	a13ff0ef          	jal	800008f8 <uvmfree>
}
    80000eea:	60e2                	ld	ra,24(sp)
    80000eec:	6442                	ld	s0,16(sp)
    80000eee:	64a2                	ld	s1,8(sp)
    80000ef0:	6902                	ld	s2,0(sp)
    80000ef2:	6105                	addi	sp,sp,32
    80000ef4:	8082                	ret

0000000080000ef6 <freeproc>:
{
    80000ef6:	1101                	addi	sp,sp,-32
    80000ef8:	ec06                	sd	ra,24(sp)
    80000efa:	e822                	sd	s0,16(sp)
    80000efc:	e426                	sd	s1,8(sp)
    80000efe:	1000                	addi	s0,sp,32
    80000f00:	84aa                	mv	s1,a0
  if(p->trapframe)
    80000f02:	6d28                	ld	a0,88(a0)
    80000f04:	c119                	beqz	a0,80000f0a <freeproc+0x14>
    kfree((void*)p->trapframe);
    80000f06:	916ff0ef          	jal	8000001c <kfree>
  p->trapframe = 0;
    80000f0a:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80000f0e:	68a8                	ld	a0,80(s1)
    80000f10:	c501                	beqz	a0,80000f18 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80000f12:	64ac                	ld	a1,72(s1)
    80000f14:	f9dff0ef          	jal	80000eb0 <proc_freepagetable>
  p->pagetable = 0;
    80000f18:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80000f1c:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80000f20:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80000f24:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80000f28:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80000f2c:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80000f30:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80000f34:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80000f38:	0004ac23          	sw	zero,24(s1)
}
    80000f3c:	60e2                	ld	ra,24(sp)
    80000f3e:	6442                	ld	s0,16(sp)
    80000f40:	64a2                	ld	s1,8(sp)
    80000f42:	6105                	addi	sp,sp,32
    80000f44:	8082                	ret

0000000080000f46 <allocproc>:
{
    80000f46:	1101                	addi	sp,sp,-32
    80000f48:	ec06                	sd	ra,24(sp)
    80000f4a:	e822                	sd	s0,16(sp)
    80000f4c:	e426                	sd	s1,8(sp)
    80000f4e:	e04a                	sd	s2,0(sp)
    80000f50:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f52:	00007497          	auipc	s1,0x7
    80000f56:	dfe48493          	addi	s1,s1,-514 # 80007d50 <proc>
    80000f5a:	0000c917          	auipc	s2,0xc
    80000f5e:	7f690913          	addi	s2,s2,2038 # 8000d750 <tickslock>
    acquire(&p->lock);
    80000f62:	8526                	mv	a0,s1
    80000f64:	069040ef          	jal	800057cc <acquire>
    if(p->state == UNUSED) {
    80000f68:	4c9c                	lw	a5,24(s1)
    80000f6a:	cb91                	beqz	a5,80000f7e <allocproc+0x38>
      release(&p->lock);
    80000f6c:	8526                	mv	a0,s1
    80000f6e:	0f3040ef          	jal	80005860 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f72:	16848493          	addi	s1,s1,360
    80000f76:	ff2496e3          	bne	s1,s2,80000f62 <allocproc+0x1c>
  return 0;
    80000f7a:	4481                	li	s1,0
    80000f7c:	a089                	j	80000fbe <allocproc+0x78>
  p->pid = allocpid();
    80000f7e:	e71ff0ef          	jal	80000dee <allocpid>
    80000f82:	d888                	sw	a0,48(s1)
  p->state = USED;
    80000f84:	4785                	li	a5,1
    80000f86:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80000f88:	97cff0ef          	jal	80000104 <kalloc>
    80000f8c:	892a                	mv	s2,a0
    80000f8e:	eca8                	sd	a0,88(s1)
    80000f90:	cd15                	beqz	a0,80000fcc <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80000f92:	8526                	mv	a0,s1
    80000f94:	e99ff0ef          	jal	80000e2c <proc_pagetable>
    80000f98:	892a                	mv	s2,a0
    80000f9a:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80000f9c:	c121                	beqz	a0,80000fdc <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80000f9e:	07000613          	li	a2,112
    80000fa2:	4581                	li	a1,0
    80000fa4:	06048513          	addi	a0,s1,96
    80000fa8:	9b6ff0ef          	jal	8000015e <memset>
  p->context.ra = (uint64)forkret;
    80000fac:	00000797          	auipc	a5,0x0
    80000fb0:	e0878793          	addi	a5,a5,-504 # 80000db4 <forkret>
    80000fb4:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80000fb6:	60bc                	ld	a5,64(s1)
    80000fb8:	6705                	lui	a4,0x1
    80000fba:	97ba                	add	a5,a5,a4
    80000fbc:	f4bc                	sd	a5,104(s1)
}
    80000fbe:	8526                	mv	a0,s1
    80000fc0:	60e2                	ld	ra,24(sp)
    80000fc2:	6442                	ld	s0,16(sp)
    80000fc4:	64a2                	ld	s1,8(sp)
    80000fc6:	6902                	ld	s2,0(sp)
    80000fc8:	6105                	addi	sp,sp,32
    80000fca:	8082                	ret
    freeproc(p);
    80000fcc:	8526                	mv	a0,s1
    80000fce:	f29ff0ef          	jal	80000ef6 <freeproc>
    release(&p->lock);
    80000fd2:	8526                	mv	a0,s1
    80000fd4:	08d040ef          	jal	80005860 <release>
    return 0;
    80000fd8:	84ca                	mv	s1,s2
    80000fda:	b7d5                	j	80000fbe <allocproc+0x78>
    freeproc(p);
    80000fdc:	8526                	mv	a0,s1
    80000fde:	f19ff0ef          	jal	80000ef6 <freeproc>
    release(&p->lock);
    80000fe2:	8526                	mv	a0,s1
    80000fe4:	07d040ef          	jal	80005860 <release>
    return 0;
    80000fe8:	84ca                	mv	s1,s2
    80000fea:	bfd1                	j	80000fbe <allocproc+0x78>

0000000080000fec <userinit>:
{
    80000fec:	1101                	addi	sp,sp,-32
    80000fee:	ec06                	sd	ra,24(sp)
    80000ff0:	e822                	sd	s0,16(sp)
    80000ff2:	e426                	sd	s1,8(sp)
    80000ff4:	1000                	addi	s0,sp,32
  p = allocproc();
    80000ff6:	f51ff0ef          	jal	80000f46 <allocproc>
    80000ffa:	84aa                	mv	s1,a0
  initproc = p;
    80000ffc:	00007797          	auipc	a5,0x7
    80001000:	8ea7b223          	sd	a0,-1820(a5) # 800078e0 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001004:	03400613          	li	a2,52
    80001008:	00007597          	auipc	a1,0x7
    8000100c:	88858593          	addi	a1,a1,-1912 # 80007890 <initcode>
    80001010:	6928                	ld	a0,80(a0)
    80001012:	f3eff0ef          	jal	80000750 <uvmfirst>
  p->sz = PGSIZE;
    80001016:	6785                	lui	a5,0x1
    80001018:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    8000101a:	6cb8                	ld	a4,88(s1)
    8000101c:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001020:	6cb8                	ld	a4,88(s1)
    80001022:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001024:	4641                	li	a2,16
    80001026:	00006597          	auipc	a1,0x6
    8000102a:	19a58593          	addi	a1,a1,410 # 800071c0 <etext+0x1c0>
    8000102e:	15848513          	addi	a0,s1,344
    80001032:	a80ff0ef          	jal	800002b2 <safestrcpy>
  p->cwd = namei("/");
    80001036:	00006517          	auipc	a0,0x6
    8000103a:	19a50513          	addi	a0,a0,410 # 800071d0 <etext+0x1d0>
    8000103e:	4f1010ef          	jal	80002d2e <namei>
    80001042:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001046:	478d                	li	a5,3
    80001048:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    8000104a:	8526                	mv	a0,s1
    8000104c:	015040ef          	jal	80005860 <release>
}
    80001050:	60e2                	ld	ra,24(sp)
    80001052:	6442                	ld	s0,16(sp)
    80001054:	64a2                	ld	s1,8(sp)
    80001056:	6105                	addi	sp,sp,32
    80001058:	8082                	ret

000000008000105a <growproc>:
{
    8000105a:	1101                	addi	sp,sp,-32
    8000105c:	ec06                	sd	ra,24(sp)
    8000105e:	e822                	sd	s0,16(sp)
    80001060:	e426                	sd	s1,8(sp)
    80001062:	e04a                	sd	s2,0(sp)
    80001064:	1000                	addi	s0,sp,32
    80001066:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001068:	d1bff0ef          	jal	80000d82 <myproc>
    8000106c:	84aa                	mv	s1,a0
  sz = p->sz;
    8000106e:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001070:	01204c63          	bgtz	s2,80001088 <growproc+0x2e>
  } else if(n < 0){
    80001074:	02094463          	bltz	s2,8000109c <growproc+0x42>
  p->sz = sz;
    80001078:	e4ac                	sd	a1,72(s1)
  return 0;
    8000107a:	4501                	li	a0,0
}
    8000107c:	60e2                	ld	ra,24(sp)
    8000107e:	6442                	ld	s0,16(sp)
    80001080:	64a2                	ld	s1,8(sp)
    80001082:	6902                	ld	s2,0(sp)
    80001084:	6105                	addi	sp,sp,32
    80001086:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001088:	4691                	li	a3,4
    8000108a:	00b90633          	add	a2,s2,a1
    8000108e:	6928                	ld	a0,80(a0)
    80001090:	f62ff0ef          	jal	800007f2 <uvmalloc>
    80001094:	85aa                	mv	a1,a0
    80001096:	f16d                	bnez	a0,80001078 <growproc+0x1e>
      return -1;
    80001098:	557d                	li	a0,-1
    8000109a:	b7cd                	j	8000107c <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    8000109c:	00b90633          	add	a2,s2,a1
    800010a0:	6928                	ld	a0,80(a0)
    800010a2:	f0cff0ef          	jal	800007ae <uvmdealloc>
    800010a6:	85aa                	mv	a1,a0
    800010a8:	bfc1                	j	80001078 <growproc+0x1e>

00000000800010aa <fork>:
{
    800010aa:	7139                	addi	sp,sp,-64
    800010ac:	fc06                	sd	ra,56(sp)
    800010ae:	f822                	sd	s0,48(sp)
    800010b0:	f426                	sd	s1,40(sp)
    800010b2:	e456                	sd	s5,8(sp)
    800010b4:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    800010b6:	ccdff0ef          	jal	80000d82 <myproc>
    800010ba:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    800010bc:	e8bff0ef          	jal	80000f46 <allocproc>
    800010c0:	0e050a63          	beqz	a0,800011b4 <fork+0x10a>
    800010c4:	e852                	sd	s4,16(sp)
    800010c6:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    800010c8:	048ab603          	ld	a2,72(s5)
    800010cc:	692c                	ld	a1,80(a0)
    800010ce:	050ab503          	ld	a0,80(s5)
    800010d2:	859ff0ef          	jal	8000092a <uvmcopy>
    800010d6:	04054863          	bltz	a0,80001126 <fork+0x7c>
    800010da:	f04a                	sd	s2,32(sp)
    800010dc:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    800010de:	048ab783          	ld	a5,72(s5)
    800010e2:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    800010e6:	058ab683          	ld	a3,88(s5)
    800010ea:	87b6                	mv	a5,a3
    800010ec:	058a3703          	ld	a4,88(s4)
    800010f0:	12068693          	addi	a3,a3,288
    800010f4:	6388                	ld	a0,0(a5)
    800010f6:	678c                	ld	a1,8(a5)
    800010f8:	6b90                	ld	a2,16(a5)
    800010fa:	e308                	sd	a0,0(a4)
    800010fc:	e70c                	sd	a1,8(a4)
    800010fe:	eb10                	sd	a2,16(a4)
    80001100:	6f90                	ld	a2,24(a5)
    80001102:	ef10                	sd	a2,24(a4)
    80001104:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    80001108:	02070713          	addi	a4,a4,32
    8000110c:	fed794e3          	bne	a5,a3,800010f4 <fork+0x4a>
  np->trapframe->a0 = 0;
    80001110:	058a3783          	ld	a5,88(s4)
    80001114:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001118:	0d0a8493          	addi	s1,s5,208
    8000111c:	0d0a0913          	addi	s2,s4,208
    80001120:	150a8993          	addi	s3,s5,336
    80001124:	a831                	j	80001140 <fork+0x96>
    freeproc(np);
    80001126:	8552                	mv	a0,s4
    80001128:	dcfff0ef          	jal	80000ef6 <freeproc>
    release(&np->lock);
    8000112c:	8552                	mv	a0,s4
    8000112e:	732040ef          	jal	80005860 <release>
    return -1;
    80001132:	54fd                	li	s1,-1
    80001134:	6a42                	ld	s4,16(sp)
    80001136:	a885                	j	800011a6 <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001138:	04a1                	addi	s1,s1,8
    8000113a:	0921                	addi	s2,s2,8
    8000113c:	01348963          	beq	s1,s3,8000114e <fork+0xa4>
    if(p->ofile[i])
    80001140:	6088                	ld	a0,0(s1)
    80001142:	d97d                	beqz	a0,80001138 <fork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001144:	198020ef          	jal	800032dc <filedup>
    80001148:	00a93023          	sd	a0,0(s2)
    8000114c:	b7f5                	j	80001138 <fork+0x8e>
  np->cwd = idup(p->cwd);
    8000114e:	150ab503          	ld	a0,336(s5)
    80001152:	4b0010ef          	jal	80002602 <idup>
    80001156:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    8000115a:	4641                	li	a2,16
    8000115c:	158a8593          	addi	a1,s5,344
    80001160:	158a0513          	addi	a0,s4,344
    80001164:	94eff0ef          	jal	800002b2 <safestrcpy>
  pid = np->pid;
    80001168:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    8000116c:	8552                	mv	a0,s4
    8000116e:	6f2040ef          	jal	80005860 <release>
  acquire(&wait_lock);
    80001172:	00006517          	auipc	a0,0x6
    80001176:	7c650513          	addi	a0,a0,1990 # 80007938 <wait_lock>
    8000117a:	652040ef          	jal	800057cc <acquire>
  np->parent = p;
    8000117e:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001182:	00006517          	auipc	a0,0x6
    80001186:	7b650513          	addi	a0,a0,1974 # 80007938 <wait_lock>
    8000118a:	6d6040ef          	jal	80005860 <release>
  acquire(&np->lock);
    8000118e:	8552                	mv	a0,s4
    80001190:	63c040ef          	jal	800057cc <acquire>
  np->state = RUNNABLE;
    80001194:	478d                	li	a5,3
    80001196:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    8000119a:	8552                	mv	a0,s4
    8000119c:	6c4040ef          	jal	80005860 <release>
  return pid;
    800011a0:	7902                	ld	s2,32(sp)
    800011a2:	69e2                	ld	s3,24(sp)
    800011a4:	6a42                	ld	s4,16(sp)
}
    800011a6:	8526                	mv	a0,s1
    800011a8:	70e2                	ld	ra,56(sp)
    800011aa:	7442                	ld	s0,48(sp)
    800011ac:	74a2                	ld	s1,40(sp)
    800011ae:	6aa2                	ld	s5,8(sp)
    800011b0:	6121                	addi	sp,sp,64
    800011b2:	8082                	ret
    return -1;
    800011b4:	54fd                	li	s1,-1
    800011b6:	bfc5                	j	800011a6 <fork+0xfc>

00000000800011b8 <scheduler>:
{
    800011b8:	715d                	addi	sp,sp,-80
    800011ba:	e486                	sd	ra,72(sp)
    800011bc:	e0a2                	sd	s0,64(sp)
    800011be:	fc26                	sd	s1,56(sp)
    800011c0:	f84a                	sd	s2,48(sp)
    800011c2:	f44e                	sd	s3,40(sp)
    800011c4:	f052                	sd	s4,32(sp)
    800011c6:	ec56                	sd	s5,24(sp)
    800011c8:	e85a                	sd	s6,16(sp)
    800011ca:	e45e                	sd	s7,8(sp)
    800011cc:	e062                	sd	s8,0(sp)
    800011ce:	0880                	addi	s0,sp,80
    800011d0:	8792                	mv	a5,tp
  int id = r_tp();
    800011d2:	2781                	sext.w	a5,a5
  c->proc = 0;
    800011d4:	00779b13          	slli	s6,a5,0x7
    800011d8:	00006717          	auipc	a4,0x6
    800011dc:	74870713          	addi	a4,a4,1864 # 80007920 <pid_lock>
    800011e0:	975a                	add	a4,a4,s6
    800011e2:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    800011e6:	00006717          	auipc	a4,0x6
    800011ea:	77270713          	addi	a4,a4,1906 # 80007958 <cpus+0x8>
    800011ee:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    800011f0:	4c11                	li	s8,4
        c->proc = p;
    800011f2:	079e                	slli	a5,a5,0x7
    800011f4:	00006a17          	auipc	s4,0x6
    800011f8:	72ca0a13          	addi	s4,s4,1836 # 80007920 <pid_lock>
    800011fc:	9a3e                	add	s4,s4,a5
        found = 1;
    800011fe:	4b85                	li	s7,1
    80001200:	a0a9                	j	8000124a <scheduler+0x92>
      release(&p->lock);
    80001202:	8526                	mv	a0,s1
    80001204:	65c040ef          	jal	80005860 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001208:	16848493          	addi	s1,s1,360
    8000120c:	03248563          	beq	s1,s2,80001236 <scheduler+0x7e>
      acquire(&p->lock);
    80001210:	8526                	mv	a0,s1
    80001212:	5ba040ef          	jal	800057cc <acquire>
      if(p->state == RUNNABLE) {
    80001216:	4c9c                	lw	a5,24(s1)
    80001218:	ff3795e3          	bne	a5,s3,80001202 <scheduler+0x4a>
        p->state = RUNNING;
    8000121c:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001220:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001224:	06048593          	addi	a1,s1,96
    80001228:	855a                	mv	a0,s6
    8000122a:	5bc000ef          	jal	800017e6 <swtch>
        c->proc = 0;
    8000122e:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001232:	8ade                	mv	s5,s7
    80001234:	b7f9                	j	80001202 <scheduler+0x4a>
    if(found == 0) {
    80001236:	000a9a63          	bnez	s5,8000124a <scheduler+0x92>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000123a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000123e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001242:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    80001246:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000124a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000124e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001252:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001256:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001258:	00007497          	auipc	s1,0x7
    8000125c:	af848493          	addi	s1,s1,-1288 # 80007d50 <proc>
      if(p->state == RUNNABLE) {
    80001260:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    80001262:	0000c917          	auipc	s2,0xc
    80001266:	4ee90913          	addi	s2,s2,1262 # 8000d750 <tickslock>
    8000126a:	b75d                	j	80001210 <scheduler+0x58>

000000008000126c <sched>:
{
    8000126c:	7179                	addi	sp,sp,-48
    8000126e:	f406                	sd	ra,40(sp)
    80001270:	f022                	sd	s0,32(sp)
    80001272:	ec26                	sd	s1,24(sp)
    80001274:	e84a                	sd	s2,16(sp)
    80001276:	e44e                	sd	s3,8(sp)
    80001278:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    8000127a:	b09ff0ef          	jal	80000d82 <myproc>
    8000127e:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001280:	4dc040ef          	jal	8000575c <holding>
    80001284:	c935                	beqz	a0,800012f8 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001286:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001288:	2781                	sext.w	a5,a5
    8000128a:	079e                	slli	a5,a5,0x7
    8000128c:	00006717          	auipc	a4,0x6
    80001290:	69470713          	addi	a4,a4,1684 # 80007920 <pid_lock>
    80001294:	97ba                	add	a5,a5,a4
    80001296:	0a87a703          	lw	a4,168(a5)
    8000129a:	4785                	li	a5,1
    8000129c:	06f71463          	bne	a4,a5,80001304 <sched+0x98>
  if(p->state == RUNNING)
    800012a0:	4c98                	lw	a4,24(s1)
    800012a2:	4791                	li	a5,4
    800012a4:	06f70663          	beq	a4,a5,80001310 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800012a8:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800012ac:	8b89                	andi	a5,a5,2
  if(intr_get())
    800012ae:	e7bd                	bnez	a5,8000131c <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    800012b0:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    800012b2:	00006917          	auipc	s2,0x6
    800012b6:	66e90913          	addi	s2,s2,1646 # 80007920 <pid_lock>
    800012ba:	2781                	sext.w	a5,a5
    800012bc:	079e                	slli	a5,a5,0x7
    800012be:	97ca                	add	a5,a5,s2
    800012c0:	0ac7a983          	lw	s3,172(a5)
    800012c4:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800012c6:	2781                	sext.w	a5,a5
    800012c8:	079e                	slli	a5,a5,0x7
    800012ca:	07a1                	addi	a5,a5,8
    800012cc:	00006597          	auipc	a1,0x6
    800012d0:	68458593          	addi	a1,a1,1668 # 80007950 <cpus>
    800012d4:	95be                	add	a1,a1,a5
    800012d6:	06048513          	addi	a0,s1,96
    800012da:	50c000ef          	jal	800017e6 <swtch>
    800012de:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    800012e0:	2781                	sext.w	a5,a5
    800012e2:	079e                	slli	a5,a5,0x7
    800012e4:	993e                	add	s2,s2,a5
    800012e6:	0b392623          	sw	s3,172(s2)
}
    800012ea:	70a2                	ld	ra,40(sp)
    800012ec:	7402                	ld	s0,32(sp)
    800012ee:	64e2                	ld	s1,24(sp)
    800012f0:	6942                	ld	s2,16(sp)
    800012f2:	69a2                	ld	s3,8(sp)
    800012f4:	6145                	addi	sp,sp,48
    800012f6:	8082                	ret
    panic("sched p->lock");
    800012f8:	00006517          	auipc	a0,0x6
    800012fc:	ee050513          	addi	a0,a0,-288 # 800071d8 <etext+0x1d8>
    80001300:	18e040ef          	jal	8000548e <panic>
    panic("sched locks");
    80001304:	00006517          	auipc	a0,0x6
    80001308:	ee450513          	addi	a0,a0,-284 # 800071e8 <etext+0x1e8>
    8000130c:	182040ef          	jal	8000548e <panic>
    panic("sched running");
    80001310:	00006517          	auipc	a0,0x6
    80001314:	ee850513          	addi	a0,a0,-280 # 800071f8 <etext+0x1f8>
    80001318:	176040ef          	jal	8000548e <panic>
    panic("sched interruptible");
    8000131c:	00006517          	auipc	a0,0x6
    80001320:	eec50513          	addi	a0,a0,-276 # 80007208 <etext+0x208>
    80001324:	16a040ef          	jal	8000548e <panic>

0000000080001328 <yield>:
{
    80001328:	1101                	addi	sp,sp,-32
    8000132a:	ec06                	sd	ra,24(sp)
    8000132c:	e822                	sd	s0,16(sp)
    8000132e:	e426                	sd	s1,8(sp)
    80001330:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001332:	a51ff0ef          	jal	80000d82 <myproc>
    80001336:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001338:	494040ef          	jal	800057cc <acquire>
  p->state = RUNNABLE;
    8000133c:	478d                	li	a5,3
    8000133e:	cc9c                	sw	a5,24(s1)
  sched();
    80001340:	f2dff0ef          	jal	8000126c <sched>
  release(&p->lock);
    80001344:	8526                	mv	a0,s1
    80001346:	51a040ef          	jal	80005860 <release>
}
    8000134a:	60e2                	ld	ra,24(sp)
    8000134c:	6442                	ld	s0,16(sp)
    8000134e:	64a2                	ld	s1,8(sp)
    80001350:	6105                	addi	sp,sp,32
    80001352:	8082                	ret

0000000080001354 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001354:	7179                	addi	sp,sp,-48
    80001356:	f406                	sd	ra,40(sp)
    80001358:	f022                	sd	s0,32(sp)
    8000135a:	ec26                	sd	s1,24(sp)
    8000135c:	e84a                	sd	s2,16(sp)
    8000135e:	e44e                	sd	s3,8(sp)
    80001360:	1800                	addi	s0,sp,48
    80001362:	89aa                	mv	s3,a0
    80001364:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001366:	a1dff0ef          	jal	80000d82 <myproc>
    8000136a:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    8000136c:	460040ef          	jal	800057cc <acquire>
  release(lk);
    80001370:	854a                	mv	a0,s2
    80001372:	4ee040ef          	jal	80005860 <release>

  // Go to sleep.
  p->chan = chan;
    80001376:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    8000137a:	4789                	li	a5,2
    8000137c:	cc9c                	sw	a5,24(s1)

  sched();
    8000137e:	eefff0ef          	jal	8000126c <sched>

  // Tidy up.
  p->chan = 0;
    80001382:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001386:	8526                	mv	a0,s1
    80001388:	4d8040ef          	jal	80005860 <release>
  acquire(lk);
    8000138c:	854a                	mv	a0,s2
    8000138e:	43e040ef          	jal	800057cc <acquire>
}
    80001392:	70a2                	ld	ra,40(sp)
    80001394:	7402                	ld	s0,32(sp)
    80001396:	64e2                	ld	s1,24(sp)
    80001398:	6942                	ld	s2,16(sp)
    8000139a:	69a2                	ld	s3,8(sp)
    8000139c:	6145                	addi	sp,sp,48
    8000139e:	8082                	ret

00000000800013a0 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800013a0:	7139                	addi	sp,sp,-64
    800013a2:	fc06                	sd	ra,56(sp)
    800013a4:	f822                	sd	s0,48(sp)
    800013a6:	f426                	sd	s1,40(sp)
    800013a8:	f04a                	sd	s2,32(sp)
    800013aa:	ec4e                	sd	s3,24(sp)
    800013ac:	e852                	sd	s4,16(sp)
    800013ae:	e456                	sd	s5,8(sp)
    800013b0:	0080                	addi	s0,sp,64
    800013b2:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800013b4:	00007497          	auipc	s1,0x7
    800013b8:	99c48493          	addi	s1,s1,-1636 # 80007d50 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800013bc:	4989                	li	s3,2
        p->state = RUNNABLE;
    800013be:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800013c0:	0000c917          	auipc	s2,0xc
    800013c4:	39090913          	addi	s2,s2,912 # 8000d750 <tickslock>
    800013c8:	a801                	j	800013d8 <wakeup+0x38>
      }
      release(&p->lock);
    800013ca:	8526                	mv	a0,s1
    800013cc:	494040ef          	jal	80005860 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800013d0:	16848493          	addi	s1,s1,360
    800013d4:	03248263          	beq	s1,s2,800013f8 <wakeup+0x58>
    if(p != myproc()){
    800013d8:	9abff0ef          	jal	80000d82 <myproc>
    800013dc:	fe950ae3          	beq	a0,s1,800013d0 <wakeup+0x30>
      acquire(&p->lock);
    800013e0:	8526                	mv	a0,s1
    800013e2:	3ea040ef          	jal	800057cc <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800013e6:	4c9c                	lw	a5,24(s1)
    800013e8:	ff3791e3          	bne	a5,s3,800013ca <wakeup+0x2a>
    800013ec:	709c                	ld	a5,32(s1)
    800013ee:	fd479ee3          	bne	a5,s4,800013ca <wakeup+0x2a>
        p->state = RUNNABLE;
    800013f2:	0154ac23          	sw	s5,24(s1)
    800013f6:	bfd1                	j	800013ca <wakeup+0x2a>
    }
  }
}
    800013f8:	70e2                	ld	ra,56(sp)
    800013fa:	7442                	ld	s0,48(sp)
    800013fc:	74a2                	ld	s1,40(sp)
    800013fe:	7902                	ld	s2,32(sp)
    80001400:	69e2                	ld	s3,24(sp)
    80001402:	6a42                	ld	s4,16(sp)
    80001404:	6aa2                	ld	s5,8(sp)
    80001406:	6121                	addi	sp,sp,64
    80001408:	8082                	ret

000000008000140a <reparent>:
{
    8000140a:	7179                	addi	sp,sp,-48
    8000140c:	f406                	sd	ra,40(sp)
    8000140e:	f022                	sd	s0,32(sp)
    80001410:	ec26                	sd	s1,24(sp)
    80001412:	e84a                	sd	s2,16(sp)
    80001414:	e44e                	sd	s3,8(sp)
    80001416:	e052                	sd	s4,0(sp)
    80001418:	1800                	addi	s0,sp,48
    8000141a:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000141c:	00007497          	auipc	s1,0x7
    80001420:	93448493          	addi	s1,s1,-1740 # 80007d50 <proc>
      pp->parent = initproc;
    80001424:	00006a17          	auipc	s4,0x6
    80001428:	4bca0a13          	addi	s4,s4,1212 # 800078e0 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000142c:	0000c997          	auipc	s3,0xc
    80001430:	32498993          	addi	s3,s3,804 # 8000d750 <tickslock>
    80001434:	a029                	j	8000143e <reparent+0x34>
    80001436:	16848493          	addi	s1,s1,360
    8000143a:	01348b63          	beq	s1,s3,80001450 <reparent+0x46>
    if(pp->parent == p){
    8000143e:	7c9c                	ld	a5,56(s1)
    80001440:	ff279be3          	bne	a5,s2,80001436 <reparent+0x2c>
      pp->parent = initproc;
    80001444:	000a3503          	ld	a0,0(s4)
    80001448:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000144a:	f57ff0ef          	jal	800013a0 <wakeup>
    8000144e:	b7e5                	j	80001436 <reparent+0x2c>
}
    80001450:	70a2                	ld	ra,40(sp)
    80001452:	7402                	ld	s0,32(sp)
    80001454:	64e2                	ld	s1,24(sp)
    80001456:	6942                	ld	s2,16(sp)
    80001458:	69a2                	ld	s3,8(sp)
    8000145a:	6a02                	ld	s4,0(sp)
    8000145c:	6145                	addi	sp,sp,48
    8000145e:	8082                	ret

0000000080001460 <exit>:
{
    80001460:	7179                	addi	sp,sp,-48
    80001462:	f406                	sd	ra,40(sp)
    80001464:	f022                	sd	s0,32(sp)
    80001466:	ec26                	sd	s1,24(sp)
    80001468:	e84a                	sd	s2,16(sp)
    8000146a:	e44e                	sd	s3,8(sp)
    8000146c:	e052                	sd	s4,0(sp)
    8000146e:	1800                	addi	s0,sp,48
    80001470:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001472:	911ff0ef          	jal	80000d82 <myproc>
    80001476:	89aa                	mv	s3,a0
  if(p == initproc)
    80001478:	00006797          	auipc	a5,0x6
    8000147c:	4687b783          	ld	a5,1128(a5) # 800078e0 <initproc>
    80001480:	0d050493          	addi	s1,a0,208
    80001484:	15050913          	addi	s2,a0,336
    80001488:	00a79b63          	bne	a5,a0,8000149e <exit+0x3e>
    panic("init exiting");
    8000148c:	00006517          	auipc	a0,0x6
    80001490:	d9450513          	addi	a0,a0,-620 # 80007220 <etext+0x220>
    80001494:	7fb030ef          	jal	8000548e <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80001498:	04a1                	addi	s1,s1,8
    8000149a:	01248963          	beq	s1,s2,800014ac <exit+0x4c>
    if(p->ofile[fd]){
    8000149e:	6088                	ld	a0,0(s1)
    800014a0:	dd65                	beqz	a0,80001498 <exit+0x38>
      fileclose(f);
    800014a2:	681010ef          	jal	80003322 <fileclose>
      p->ofile[fd] = 0;
    800014a6:	0004b023          	sd	zero,0(s1)
    800014aa:	b7fd                	j	80001498 <exit+0x38>
  begin_op();
    800014ac:	245010ef          	jal	80002ef0 <begin_op>
  iput(p->cwd);
    800014b0:	1509b503          	ld	a0,336(s3)
    800014b4:	306010ef          	jal	800027ba <iput>
  end_op();
    800014b8:	2a9010ef          	jal	80002f60 <end_op>
  p->cwd = 0;
    800014bc:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800014c0:	00006517          	auipc	a0,0x6
    800014c4:	47850513          	addi	a0,a0,1144 # 80007938 <wait_lock>
    800014c8:	304040ef          	jal	800057cc <acquire>
  reparent(p);
    800014cc:	854e                	mv	a0,s3
    800014ce:	f3dff0ef          	jal	8000140a <reparent>
  wakeup(p->parent);
    800014d2:	0389b503          	ld	a0,56(s3)
    800014d6:	ecbff0ef          	jal	800013a0 <wakeup>
  acquire(&p->lock);
    800014da:	854e                	mv	a0,s3
    800014dc:	2f0040ef          	jal	800057cc <acquire>
  p->xstate = status;
    800014e0:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800014e4:	4795                	li	a5,5
    800014e6:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800014ea:	00006517          	auipc	a0,0x6
    800014ee:	44e50513          	addi	a0,a0,1102 # 80007938 <wait_lock>
    800014f2:	36e040ef          	jal	80005860 <release>
  sched();
    800014f6:	d77ff0ef          	jal	8000126c <sched>
  panic("zombie exit");
    800014fa:	00006517          	auipc	a0,0x6
    800014fe:	d3650513          	addi	a0,a0,-714 # 80007230 <etext+0x230>
    80001502:	78d030ef          	jal	8000548e <panic>

0000000080001506 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80001506:	7179                	addi	sp,sp,-48
    80001508:	f406                	sd	ra,40(sp)
    8000150a:	f022                	sd	s0,32(sp)
    8000150c:	ec26                	sd	s1,24(sp)
    8000150e:	e84a                	sd	s2,16(sp)
    80001510:	e44e                	sd	s3,8(sp)
    80001512:	1800                	addi	s0,sp,48
    80001514:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80001516:	00007497          	auipc	s1,0x7
    8000151a:	83a48493          	addi	s1,s1,-1990 # 80007d50 <proc>
    8000151e:	0000c997          	auipc	s3,0xc
    80001522:	23298993          	addi	s3,s3,562 # 8000d750 <tickslock>
    acquire(&p->lock);
    80001526:	8526                	mv	a0,s1
    80001528:	2a4040ef          	jal	800057cc <acquire>
    if(p->pid == pid){
    8000152c:	589c                	lw	a5,48(s1)
    8000152e:	01278b63          	beq	a5,s2,80001544 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80001532:	8526                	mv	a0,s1
    80001534:	32c040ef          	jal	80005860 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80001538:	16848493          	addi	s1,s1,360
    8000153c:	ff3495e3          	bne	s1,s3,80001526 <kill+0x20>
  }
  return -1;
    80001540:	557d                	li	a0,-1
    80001542:	a819                	j	80001558 <kill+0x52>
      p->killed = 1;
    80001544:	4785                	li	a5,1
    80001546:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80001548:	4c98                	lw	a4,24(s1)
    8000154a:	4789                	li	a5,2
    8000154c:	00f70d63          	beq	a4,a5,80001566 <kill+0x60>
      release(&p->lock);
    80001550:	8526                	mv	a0,s1
    80001552:	30e040ef          	jal	80005860 <release>
      return 0;
    80001556:	4501                	li	a0,0
}
    80001558:	70a2                	ld	ra,40(sp)
    8000155a:	7402                	ld	s0,32(sp)
    8000155c:	64e2                	ld	s1,24(sp)
    8000155e:	6942                	ld	s2,16(sp)
    80001560:	69a2                	ld	s3,8(sp)
    80001562:	6145                	addi	sp,sp,48
    80001564:	8082                	ret
        p->state = RUNNABLE;
    80001566:	478d                	li	a5,3
    80001568:	cc9c                	sw	a5,24(s1)
    8000156a:	b7dd                	j	80001550 <kill+0x4a>

000000008000156c <setkilled>:

void
setkilled(struct proc *p)
{
    8000156c:	1101                	addi	sp,sp,-32
    8000156e:	ec06                	sd	ra,24(sp)
    80001570:	e822                	sd	s0,16(sp)
    80001572:	e426                	sd	s1,8(sp)
    80001574:	1000                	addi	s0,sp,32
    80001576:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001578:	254040ef          	jal	800057cc <acquire>
  p->killed = 1;
    8000157c:	4785                	li	a5,1
    8000157e:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80001580:	8526                	mv	a0,s1
    80001582:	2de040ef          	jal	80005860 <release>
}
    80001586:	60e2                	ld	ra,24(sp)
    80001588:	6442                	ld	s0,16(sp)
    8000158a:	64a2                	ld	s1,8(sp)
    8000158c:	6105                	addi	sp,sp,32
    8000158e:	8082                	ret

0000000080001590 <killed>:

int
killed(struct proc *p)
{
    80001590:	1101                	addi	sp,sp,-32
    80001592:	ec06                	sd	ra,24(sp)
    80001594:	e822                	sd	s0,16(sp)
    80001596:	e426                	sd	s1,8(sp)
    80001598:	e04a                	sd	s2,0(sp)
    8000159a:	1000                	addi	s0,sp,32
    8000159c:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000159e:	22e040ef          	jal	800057cc <acquire>
  k = p->killed;
    800015a2:	549c                	lw	a5,40(s1)
    800015a4:	893e                	mv	s2,a5
  release(&p->lock);
    800015a6:	8526                	mv	a0,s1
    800015a8:	2b8040ef          	jal	80005860 <release>
  return k;
}
    800015ac:	854a                	mv	a0,s2
    800015ae:	60e2                	ld	ra,24(sp)
    800015b0:	6442                	ld	s0,16(sp)
    800015b2:	64a2                	ld	s1,8(sp)
    800015b4:	6902                	ld	s2,0(sp)
    800015b6:	6105                	addi	sp,sp,32
    800015b8:	8082                	ret

00000000800015ba <wait>:
{
    800015ba:	715d                	addi	sp,sp,-80
    800015bc:	e486                	sd	ra,72(sp)
    800015be:	e0a2                	sd	s0,64(sp)
    800015c0:	fc26                	sd	s1,56(sp)
    800015c2:	f84a                	sd	s2,48(sp)
    800015c4:	f44e                	sd	s3,40(sp)
    800015c6:	f052                	sd	s4,32(sp)
    800015c8:	ec56                	sd	s5,24(sp)
    800015ca:	e85a                	sd	s6,16(sp)
    800015cc:	e45e                	sd	s7,8(sp)
    800015ce:	0880                	addi	s0,sp,80
    800015d0:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800015d2:	fb0ff0ef          	jal	80000d82 <myproc>
    800015d6:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800015d8:	00006517          	auipc	a0,0x6
    800015dc:	36050513          	addi	a0,a0,864 # 80007938 <wait_lock>
    800015e0:	1ec040ef          	jal	800057cc <acquire>
        if(pp->state == ZOMBIE){
    800015e4:	4a15                	li	s4,5
        havekids = 1;
    800015e6:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800015e8:	0000c997          	auipc	s3,0xc
    800015ec:	16898993          	addi	s3,s3,360 # 8000d750 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800015f0:	00006b17          	auipc	s6,0x6
    800015f4:	348b0b13          	addi	s6,s6,840 # 80007938 <wait_lock>
    800015f8:	a869                	j	80001692 <wait+0xd8>
          pid = pp->pid;
    800015fa:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800015fe:	000b8c63          	beqz	s7,80001616 <wait+0x5c>
    80001602:	4691                	li	a3,4
    80001604:	02c48613          	addi	a2,s1,44
    80001608:	85de                	mv	a1,s7
    8000160a:	05093503          	ld	a0,80(s2)
    8000160e:	bf4ff0ef          	jal	80000a02 <copyout>
    80001612:	02054a63          	bltz	a0,80001646 <wait+0x8c>
          freeproc(pp);
    80001616:	8526                	mv	a0,s1
    80001618:	8dfff0ef          	jal	80000ef6 <freeproc>
          release(&pp->lock);
    8000161c:	8526                	mv	a0,s1
    8000161e:	242040ef          	jal	80005860 <release>
          release(&wait_lock);
    80001622:	00006517          	auipc	a0,0x6
    80001626:	31650513          	addi	a0,a0,790 # 80007938 <wait_lock>
    8000162a:	236040ef          	jal	80005860 <release>
}
    8000162e:	854e                	mv	a0,s3
    80001630:	60a6                	ld	ra,72(sp)
    80001632:	6406                	ld	s0,64(sp)
    80001634:	74e2                	ld	s1,56(sp)
    80001636:	7942                	ld	s2,48(sp)
    80001638:	79a2                	ld	s3,40(sp)
    8000163a:	7a02                	ld	s4,32(sp)
    8000163c:	6ae2                	ld	s5,24(sp)
    8000163e:	6b42                	ld	s6,16(sp)
    80001640:	6ba2                	ld	s7,8(sp)
    80001642:	6161                	addi	sp,sp,80
    80001644:	8082                	ret
            release(&pp->lock);
    80001646:	8526                	mv	a0,s1
    80001648:	218040ef          	jal	80005860 <release>
            release(&wait_lock);
    8000164c:	00006517          	auipc	a0,0x6
    80001650:	2ec50513          	addi	a0,a0,748 # 80007938 <wait_lock>
    80001654:	20c040ef          	jal	80005860 <release>
            return -1;
    80001658:	59fd                	li	s3,-1
    8000165a:	bfd1                	j	8000162e <wait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000165c:	16848493          	addi	s1,s1,360
    80001660:	03348063          	beq	s1,s3,80001680 <wait+0xc6>
      if(pp->parent == p){
    80001664:	7c9c                	ld	a5,56(s1)
    80001666:	ff279be3          	bne	a5,s2,8000165c <wait+0xa2>
        acquire(&pp->lock);
    8000166a:	8526                	mv	a0,s1
    8000166c:	160040ef          	jal	800057cc <acquire>
        if(pp->state == ZOMBIE){
    80001670:	4c9c                	lw	a5,24(s1)
    80001672:	f94784e3          	beq	a5,s4,800015fa <wait+0x40>
        release(&pp->lock);
    80001676:	8526                	mv	a0,s1
    80001678:	1e8040ef          	jal	80005860 <release>
        havekids = 1;
    8000167c:	8756                	mv	a4,s5
    8000167e:	bff9                	j	8000165c <wait+0xa2>
    if(!havekids || killed(p)){
    80001680:	cf19                	beqz	a4,8000169e <wait+0xe4>
    80001682:	854a                	mv	a0,s2
    80001684:	f0dff0ef          	jal	80001590 <killed>
    80001688:	e919                	bnez	a0,8000169e <wait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000168a:	85da                	mv	a1,s6
    8000168c:	854a                	mv	a0,s2
    8000168e:	cc7ff0ef          	jal	80001354 <sleep>
    havekids = 0;
    80001692:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001694:	00006497          	auipc	s1,0x6
    80001698:	6bc48493          	addi	s1,s1,1724 # 80007d50 <proc>
    8000169c:	b7e1                	j	80001664 <wait+0xaa>
      release(&wait_lock);
    8000169e:	00006517          	auipc	a0,0x6
    800016a2:	29a50513          	addi	a0,a0,666 # 80007938 <wait_lock>
    800016a6:	1ba040ef          	jal	80005860 <release>
      return -1;
    800016aa:	59fd                	li	s3,-1
    800016ac:	b749                	j	8000162e <wait+0x74>

00000000800016ae <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800016ae:	7179                	addi	sp,sp,-48
    800016b0:	f406                	sd	ra,40(sp)
    800016b2:	f022                	sd	s0,32(sp)
    800016b4:	ec26                	sd	s1,24(sp)
    800016b6:	e84a                	sd	s2,16(sp)
    800016b8:	e44e                	sd	s3,8(sp)
    800016ba:	e052                	sd	s4,0(sp)
    800016bc:	1800                	addi	s0,sp,48
    800016be:	84aa                	mv	s1,a0
    800016c0:	8a2e                	mv	s4,a1
    800016c2:	89b2                	mv	s3,a2
    800016c4:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800016c6:	ebcff0ef          	jal	80000d82 <myproc>
  if(user_dst){
    800016ca:	cc99                	beqz	s1,800016e8 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800016cc:	86ca                	mv	a3,s2
    800016ce:	864e                	mv	a2,s3
    800016d0:	85d2                	mv	a1,s4
    800016d2:	6928                	ld	a0,80(a0)
    800016d4:	b2eff0ef          	jal	80000a02 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800016d8:	70a2                	ld	ra,40(sp)
    800016da:	7402                	ld	s0,32(sp)
    800016dc:	64e2                	ld	s1,24(sp)
    800016de:	6942                	ld	s2,16(sp)
    800016e0:	69a2                	ld	s3,8(sp)
    800016e2:	6a02                	ld	s4,0(sp)
    800016e4:	6145                	addi	sp,sp,48
    800016e6:	8082                	ret
    memmove((char *)dst, src, len);
    800016e8:	0009061b          	sext.w	a2,s2
    800016ec:	85ce                	mv	a1,s3
    800016ee:	8552                	mv	a0,s4
    800016f0:	acffe0ef          	jal	800001be <memmove>
    return 0;
    800016f4:	8526                	mv	a0,s1
    800016f6:	b7cd                	j	800016d8 <either_copyout+0x2a>

00000000800016f8 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800016f8:	7179                	addi	sp,sp,-48
    800016fa:	f406                	sd	ra,40(sp)
    800016fc:	f022                	sd	s0,32(sp)
    800016fe:	ec26                	sd	s1,24(sp)
    80001700:	e84a                	sd	s2,16(sp)
    80001702:	e44e                	sd	s3,8(sp)
    80001704:	e052                	sd	s4,0(sp)
    80001706:	1800                	addi	s0,sp,48
    80001708:	8a2a                	mv	s4,a0
    8000170a:	84ae                	mv	s1,a1
    8000170c:	89b2                	mv	s3,a2
    8000170e:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80001710:	e72ff0ef          	jal	80000d82 <myproc>
  if(user_src){
    80001714:	cc99                	beqz	s1,80001732 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80001716:	86ca                	mv	a3,s2
    80001718:	864e                	mv	a2,s3
    8000171a:	85d2                	mv	a1,s4
    8000171c:	6928                	ld	a0,80(a0)
    8000171e:	b94ff0ef          	jal	80000ab2 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80001722:	70a2                	ld	ra,40(sp)
    80001724:	7402                	ld	s0,32(sp)
    80001726:	64e2                	ld	s1,24(sp)
    80001728:	6942                	ld	s2,16(sp)
    8000172a:	69a2                	ld	s3,8(sp)
    8000172c:	6a02                	ld	s4,0(sp)
    8000172e:	6145                	addi	sp,sp,48
    80001730:	8082                	ret
    memmove(dst, (char*)src, len);
    80001732:	0009061b          	sext.w	a2,s2
    80001736:	85ce                	mv	a1,s3
    80001738:	8552                	mv	a0,s4
    8000173a:	a85fe0ef          	jal	800001be <memmove>
    return 0;
    8000173e:	8526                	mv	a0,s1
    80001740:	b7cd                	j	80001722 <either_copyin+0x2a>

0000000080001742 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80001742:	715d                	addi	sp,sp,-80
    80001744:	e486                	sd	ra,72(sp)
    80001746:	e0a2                	sd	s0,64(sp)
    80001748:	fc26                	sd	s1,56(sp)
    8000174a:	f84a                	sd	s2,48(sp)
    8000174c:	f44e                	sd	s3,40(sp)
    8000174e:	f052                	sd	s4,32(sp)
    80001750:	ec56                	sd	s5,24(sp)
    80001752:	e85a                	sd	s6,16(sp)
    80001754:	e45e                	sd	s7,8(sp)
    80001756:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80001758:	00006517          	auipc	a0,0x6
    8000175c:	8c050513          	addi	a0,a0,-1856 # 80007018 <etext+0x18>
    80001760:	21f030ef          	jal	8000517e <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001764:	00006497          	auipc	s1,0x6
    80001768:	74448493          	addi	s1,s1,1860 # 80007ea8 <proc+0x158>
    8000176c:	0000c917          	auipc	s2,0xc
    80001770:	13c90913          	addi	s2,s2,316 # 8000d8a8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001774:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80001776:	00006997          	auipc	s3,0x6
    8000177a:	aca98993          	addi	s3,s3,-1334 # 80007240 <etext+0x240>
    printf("%d %s %s", p->pid, state, p->name);
    8000177e:	00006a97          	auipc	s5,0x6
    80001782:	acaa8a93          	addi	s5,s5,-1334 # 80007248 <etext+0x248>
    printf("\n");
    80001786:	00006a17          	auipc	s4,0x6
    8000178a:	892a0a13          	addi	s4,s4,-1902 # 80007018 <etext+0x18>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000178e:	00006b97          	auipc	s7,0x6
    80001792:	fe2b8b93          	addi	s7,s7,-30 # 80007770 <states.0>
    80001796:	a829                	j	800017b0 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80001798:	ed86a583          	lw	a1,-296(a3)
    8000179c:	8556                	mv	a0,s5
    8000179e:	1e1030ef          	jal	8000517e <printf>
    printf("\n");
    800017a2:	8552                	mv	a0,s4
    800017a4:	1db030ef          	jal	8000517e <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800017a8:	16848493          	addi	s1,s1,360
    800017ac:	03248263          	beq	s1,s2,800017d0 <procdump+0x8e>
    if(p->state == UNUSED)
    800017b0:	86a6                	mv	a3,s1
    800017b2:	ec04a783          	lw	a5,-320(s1)
    800017b6:	dbed                	beqz	a5,800017a8 <procdump+0x66>
      state = "???";
    800017b8:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800017ba:	fcfb6fe3          	bltu	s6,a5,80001798 <procdump+0x56>
    800017be:	02079713          	slli	a4,a5,0x20
    800017c2:	01d75793          	srli	a5,a4,0x1d
    800017c6:	97de                	add	a5,a5,s7
    800017c8:	6390                	ld	a2,0(a5)
    800017ca:	f679                	bnez	a2,80001798 <procdump+0x56>
      state = "???";
    800017cc:	864e                	mv	a2,s3
    800017ce:	b7e9                	j	80001798 <procdump+0x56>
  }
}
    800017d0:	60a6                	ld	ra,72(sp)
    800017d2:	6406                	ld	s0,64(sp)
    800017d4:	74e2                	ld	s1,56(sp)
    800017d6:	7942                	ld	s2,48(sp)
    800017d8:	79a2                	ld	s3,40(sp)
    800017da:	7a02                	ld	s4,32(sp)
    800017dc:	6ae2                	ld	s5,24(sp)
    800017de:	6b42                	ld	s6,16(sp)
    800017e0:	6ba2                	ld	s7,8(sp)
    800017e2:	6161                	addi	sp,sp,80
    800017e4:	8082                	ret

00000000800017e6 <swtch>:
    800017e6:	00153023          	sd	ra,0(a0)
    800017ea:	00253423          	sd	sp,8(a0)
    800017ee:	e900                	sd	s0,16(a0)
    800017f0:	ed04                	sd	s1,24(a0)
    800017f2:	03253023          	sd	s2,32(a0)
    800017f6:	03353423          	sd	s3,40(a0)
    800017fa:	03453823          	sd	s4,48(a0)
    800017fe:	03553c23          	sd	s5,56(a0)
    80001802:	05653023          	sd	s6,64(a0)
    80001806:	05753423          	sd	s7,72(a0)
    8000180a:	05853823          	sd	s8,80(a0)
    8000180e:	05953c23          	sd	s9,88(a0)
    80001812:	07a53023          	sd	s10,96(a0)
    80001816:	07b53423          	sd	s11,104(a0)
    8000181a:	0005b083          	ld	ra,0(a1)
    8000181e:	0085b103          	ld	sp,8(a1)
    80001822:	6980                	ld	s0,16(a1)
    80001824:	6d84                	ld	s1,24(a1)
    80001826:	0205b903          	ld	s2,32(a1)
    8000182a:	0285b983          	ld	s3,40(a1)
    8000182e:	0305ba03          	ld	s4,48(a1)
    80001832:	0385ba83          	ld	s5,56(a1)
    80001836:	0405bb03          	ld	s6,64(a1)
    8000183a:	0485bb83          	ld	s7,72(a1)
    8000183e:	0505bc03          	ld	s8,80(a1)
    80001842:	0585bc83          	ld	s9,88(a1)
    80001846:	0605bd03          	ld	s10,96(a1)
    8000184a:	0685bd83          	ld	s11,104(a1)
    8000184e:	8082                	ret

0000000080001850 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001850:	1141                	addi	sp,sp,-16
    80001852:	e406                	sd	ra,8(sp)
    80001854:	e022                	sd	s0,0(sp)
    80001856:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001858:	00006597          	auipc	a1,0x6
    8000185c:	a3058593          	addi	a1,a1,-1488 # 80007288 <etext+0x288>
    80001860:	0000c517          	auipc	a0,0xc
    80001864:	ef050513          	addi	a0,a0,-272 # 8000d750 <tickslock>
    80001868:	6db030ef          	jal	80005742 <initlock>
}
    8000186c:	60a2                	ld	ra,8(sp)
    8000186e:	6402                	ld	s0,0(sp)
    80001870:	0141                	addi	sp,sp,16
    80001872:	8082                	ret

0000000080001874 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80001874:	1141                	addi	sp,sp,-16
    80001876:	e406                	sd	ra,8(sp)
    80001878:	e022                	sd	s0,0(sp)
    8000187a:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000187c:	00003797          	auipc	a5,0x3
    80001880:	e6478793          	addi	a5,a5,-412 # 800046e0 <kernelvec>
    80001884:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80001888:	60a2                	ld	ra,8(sp)
    8000188a:	6402                	ld	s0,0(sp)
    8000188c:	0141                	addi	sp,sp,16
    8000188e:	8082                	ret

0000000080001890 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80001890:	1141                	addi	sp,sp,-16
    80001892:	e406                	sd	ra,8(sp)
    80001894:	e022                	sd	s0,0(sp)
    80001896:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80001898:	ceaff0ef          	jal	80000d82 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000189c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800018a0:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800018a2:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800018a6:	00004697          	auipc	a3,0x4
    800018aa:	75a68693          	addi	a3,a3,1882 # 80006000 <_trampoline>
    800018ae:	00004717          	auipc	a4,0x4
    800018b2:	75270713          	addi	a4,a4,1874 # 80006000 <_trampoline>
    800018b6:	8f15                	sub	a4,a4,a3
    800018b8:	040007b7          	lui	a5,0x4000
    800018bc:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    800018be:	07b2                	slli	a5,a5,0xc
    800018c0:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    800018c2:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800018c6:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800018c8:	18002673          	csrr	a2,satp
    800018cc:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800018ce:	6d30                	ld	a2,88(a0)
    800018d0:	6138                	ld	a4,64(a0)
    800018d2:	6585                	lui	a1,0x1
    800018d4:	972e                	add	a4,a4,a1
    800018d6:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800018d8:	6d38                	ld	a4,88(a0)
    800018da:	00000617          	auipc	a2,0x0
    800018de:	11460613          	addi	a2,a2,276 # 800019ee <usertrap>
    800018e2:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800018e4:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800018e6:	8612                	mv	a2,tp
    800018e8:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800018ea:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800018ee:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800018f2:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800018f6:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800018fa:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800018fc:	6f18                	ld	a4,24(a4)
    800018fe:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001902:	6928                	ld	a0,80(a0)
    80001904:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001906:	00004717          	auipc	a4,0x4
    8000190a:	79670713          	addi	a4,a4,1942 # 8000609c <userret>
    8000190e:	8f15                	sub	a4,a4,a3
    80001910:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001912:	577d                	li	a4,-1
    80001914:	177e                	slli	a4,a4,0x3f
    80001916:	8d59                	or	a0,a0,a4
    80001918:	9782                	jalr	a5
}
    8000191a:	60a2                	ld	ra,8(sp)
    8000191c:	6402                	ld	s0,0(sp)
    8000191e:	0141                	addi	sp,sp,16
    80001920:	8082                	ret

0000000080001922 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001922:	1141                	addi	sp,sp,-16
    80001924:	e406                	sd	ra,8(sp)
    80001926:	e022                	sd	s0,0(sp)
    80001928:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    8000192a:	c24ff0ef          	jal	80000d4e <cpuid>
    8000192e:	cd11                	beqz	a0,8000194a <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001930:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001934:	000f4737          	lui	a4,0xf4
    80001938:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000193c:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    8000193e:	14d79073          	csrw	stimecmp,a5
}
    80001942:	60a2                	ld	ra,8(sp)
    80001944:	6402                	ld	s0,0(sp)
    80001946:	0141                	addi	sp,sp,16
    80001948:	8082                	ret
    acquire(&tickslock);
    8000194a:	0000c517          	auipc	a0,0xc
    8000194e:	e0650513          	addi	a0,a0,-506 # 8000d750 <tickslock>
    80001952:	67b030ef          	jal	800057cc <acquire>
    ticks++;
    80001956:	00006717          	auipc	a4,0x6
    8000195a:	f9270713          	addi	a4,a4,-110 # 800078e8 <ticks>
    8000195e:	431c                	lw	a5,0(a4)
    80001960:	2785                	addiw	a5,a5,1
    80001962:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80001964:	853a                	mv	a0,a4
    80001966:	a3bff0ef          	jal	800013a0 <wakeup>
    release(&tickslock);
    8000196a:	0000c517          	auipc	a0,0xc
    8000196e:	de650513          	addi	a0,a0,-538 # 8000d750 <tickslock>
    80001972:	6ef030ef          	jal	80005860 <release>
    80001976:	bf6d                	j	80001930 <clockintr+0xe>

0000000080001978 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001978:	1101                	addi	sp,sp,-32
    8000197a:	ec06                	sd	ra,24(sp)
    8000197c:	e822                	sd	s0,16(sp)
    8000197e:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001980:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001984:	57fd                	li	a5,-1
    80001986:	17fe                	slli	a5,a5,0x3f
    80001988:	07a5                	addi	a5,a5,9
    8000198a:	00f70c63          	beq	a4,a5,800019a2 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    8000198e:	57fd                	li	a5,-1
    80001990:	17fe                	slli	a5,a5,0x3f
    80001992:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001994:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001996:	04f70863          	beq	a4,a5,800019e6 <devintr+0x6e>
  }
}
    8000199a:	60e2                	ld	ra,24(sp)
    8000199c:	6442                	ld	s0,16(sp)
    8000199e:	6105                	addi	sp,sp,32
    800019a0:	8082                	ret
    800019a2:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    800019a4:	5e9020ef          	jal	8000478c <plic_claim>
    800019a8:	872a                	mv	a4,a0
    800019aa:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    800019ac:	47a9                	li	a5,10
    800019ae:	00f50963          	beq	a0,a5,800019c0 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    800019b2:	4785                	li	a5,1
    800019b4:	00f50963          	beq	a0,a5,800019c6 <devintr+0x4e>
    return 1;
    800019b8:	4505                	li	a0,1
    } else if(irq){
    800019ba:	eb09                	bnez	a4,800019cc <devintr+0x54>
    800019bc:	64a2                	ld	s1,8(sp)
    800019be:	bff1                	j	8000199a <devintr+0x22>
      uartintr();
    800019c0:	543030ef          	jal	80005702 <uartintr>
    if(irq)
    800019c4:	a819                	j	800019da <devintr+0x62>
      virtio_disk_intr();
    800019c6:	25c030ef          	jal	80004c22 <virtio_disk_intr>
    if(irq)
    800019ca:	a801                	j	800019da <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    800019cc:	85ba                	mv	a1,a4
    800019ce:	00006517          	auipc	a0,0x6
    800019d2:	8c250513          	addi	a0,a0,-1854 # 80007290 <etext+0x290>
    800019d6:	7a8030ef          	jal	8000517e <printf>
      plic_complete(irq);
    800019da:	8526                	mv	a0,s1
    800019dc:	5d1020ef          	jal	800047ac <plic_complete>
    return 1;
    800019e0:	4505                	li	a0,1
    800019e2:	64a2                	ld	s1,8(sp)
    800019e4:	bf5d                	j	8000199a <devintr+0x22>
    clockintr();
    800019e6:	f3dff0ef          	jal	80001922 <clockintr>
    return 2;
    800019ea:	4509                	li	a0,2
    800019ec:	b77d                	j	8000199a <devintr+0x22>

00000000800019ee <usertrap>:
{
    800019ee:	1101                	addi	sp,sp,-32
    800019f0:	ec06                	sd	ra,24(sp)
    800019f2:	e822                	sd	s0,16(sp)
    800019f4:	e426                	sd	s1,8(sp)
    800019f6:	e04a                	sd	s2,0(sp)
    800019f8:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800019fa:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800019fe:	1007f793          	andi	a5,a5,256
    80001a02:	ef85                	bnez	a5,80001a3a <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001a04:	00003797          	auipc	a5,0x3
    80001a08:	cdc78793          	addi	a5,a5,-804 # 800046e0 <kernelvec>
    80001a0c:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001a10:	b72ff0ef          	jal	80000d82 <myproc>
    80001a14:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001a16:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001a18:	14102773          	csrr	a4,sepc
    80001a1c:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001a1e:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001a22:	47a1                	li	a5,8
    80001a24:	02f70163          	beq	a4,a5,80001a46 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001a28:	f51ff0ef          	jal	80001978 <devintr>
    80001a2c:	892a                	mv	s2,a0
    80001a2e:	c135                	beqz	a0,80001a92 <usertrap+0xa4>
  if(killed(p))
    80001a30:	8526                	mv	a0,s1
    80001a32:	b5fff0ef          	jal	80001590 <killed>
    80001a36:	cd1d                	beqz	a0,80001a74 <usertrap+0x86>
    80001a38:	a81d                	j	80001a6e <usertrap+0x80>
    panic("usertrap: not from user mode");
    80001a3a:	00006517          	auipc	a0,0x6
    80001a3e:	87650513          	addi	a0,a0,-1930 # 800072b0 <etext+0x2b0>
    80001a42:	24d030ef          	jal	8000548e <panic>
    if(killed(p))
    80001a46:	b4bff0ef          	jal	80001590 <killed>
    80001a4a:	e121                	bnez	a0,80001a8a <usertrap+0x9c>
    p->trapframe->epc += 4;
    80001a4c:	6cb8                	ld	a4,88(s1)
    80001a4e:	6f1c                	ld	a5,24(a4)
    80001a50:	0791                	addi	a5,a5,4
    80001a52:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a54:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001a58:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001a5c:	10079073          	csrw	sstatus,a5
    syscall();
    80001a60:	242000ef          	jal	80001ca2 <syscall>
  if(killed(p))
    80001a64:	8526                	mv	a0,s1
    80001a66:	b2bff0ef          	jal	80001590 <killed>
    80001a6a:	c901                	beqz	a0,80001a7a <usertrap+0x8c>
    80001a6c:	4901                	li	s2,0
    exit(-1);
    80001a6e:	557d                	li	a0,-1
    80001a70:	9f1ff0ef          	jal	80001460 <exit>
  if(which_dev == 2)
    80001a74:	4789                	li	a5,2
    80001a76:	04f90563          	beq	s2,a5,80001ac0 <usertrap+0xd2>
  usertrapret();
    80001a7a:	e17ff0ef          	jal	80001890 <usertrapret>
}
    80001a7e:	60e2                	ld	ra,24(sp)
    80001a80:	6442                	ld	s0,16(sp)
    80001a82:	64a2                	ld	s1,8(sp)
    80001a84:	6902                	ld	s2,0(sp)
    80001a86:	6105                	addi	sp,sp,32
    80001a88:	8082                	ret
      exit(-1);
    80001a8a:	557d                	li	a0,-1
    80001a8c:	9d5ff0ef          	jal	80001460 <exit>
    80001a90:	bf75                	j	80001a4c <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001a92:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001a96:	5890                	lw	a2,48(s1)
    80001a98:	00006517          	auipc	a0,0x6
    80001a9c:	83850513          	addi	a0,a0,-1992 # 800072d0 <etext+0x2d0>
    80001aa0:	6de030ef          	jal	8000517e <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001aa4:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001aa8:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001aac:	00006517          	auipc	a0,0x6
    80001ab0:	85450513          	addi	a0,a0,-1964 # 80007300 <etext+0x300>
    80001ab4:	6ca030ef          	jal	8000517e <printf>
    setkilled(p);
    80001ab8:	8526                	mv	a0,s1
    80001aba:	ab3ff0ef          	jal	8000156c <setkilled>
    80001abe:	b75d                	j	80001a64 <usertrap+0x76>
    yield();
    80001ac0:	869ff0ef          	jal	80001328 <yield>
    80001ac4:	bf5d                	j	80001a7a <usertrap+0x8c>

0000000080001ac6 <kerneltrap>:
{
    80001ac6:	7179                	addi	sp,sp,-48
    80001ac8:	f406                	sd	ra,40(sp)
    80001aca:	f022                	sd	s0,32(sp)
    80001acc:	ec26                	sd	s1,24(sp)
    80001ace:	e84a                	sd	s2,16(sp)
    80001ad0:	e44e                	sd	s3,8(sp)
    80001ad2:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001ad4:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001ad8:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001adc:	142027f3          	csrr	a5,scause
    80001ae0:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80001ae2:	1004f793          	andi	a5,s1,256
    80001ae6:	c795                	beqz	a5,80001b12 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001ae8:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001aec:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001aee:	eb85                	bnez	a5,80001b1e <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80001af0:	e89ff0ef          	jal	80001978 <devintr>
    80001af4:	c91d                	beqz	a0,80001b2a <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80001af6:	4789                	li	a5,2
    80001af8:	04f50a63          	beq	a0,a5,80001b4c <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001afc:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001b00:	10049073          	csrw	sstatus,s1
}
    80001b04:	70a2                	ld	ra,40(sp)
    80001b06:	7402                	ld	s0,32(sp)
    80001b08:	64e2                	ld	s1,24(sp)
    80001b0a:	6942                	ld	s2,16(sp)
    80001b0c:	69a2                	ld	s3,8(sp)
    80001b0e:	6145                	addi	sp,sp,48
    80001b10:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001b12:	00006517          	auipc	a0,0x6
    80001b16:	81650513          	addi	a0,a0,-2026 # 80007328 <etext+0x328>
    80001b1a:	175030ef          	jal	8000548e <panic>
    panic("kerneltrap: interrupts enabled");
    80001b1e:	00006517          	auipc	a0,0x6
    80001b22:	83250513          	addi	a0,a0,-1998 # 80007350 <etext+0x350>
    80001b26:	169030ef          	jal	8000548e <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b2a:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001b2e:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001b32:	85ce                	mv	a1,s3
    80001b34:	00006517          	auipc	a0,0x6
    80001b38:	83c50513          	addi	a0,a0,-1988 # 80007370 <etext+0x370>
    80001b3c:	642030ef          	jal	8000517e <printf>
    panic("kerneltrap");
    80001b40:	00006517          	auipc	a0,0x6
    80001b44:	85850513          	addi	a0,a0,-1960 # 80007398 <etext+0x398>
    80001b48:	147030ef          	jal	8000548e <panic>
  if(which_dev == 2 && myproc() != 0)
    80001b4c:	a36ff0ef          	jal	80000d82 <myproc>
    80001b50:	d555                	beqz	a0,80001afc <kerneltrap+0x36>
    yield();
    80001b52:	fd6ff0ef          	jal	80001328 <yield>
    80001b56:	b75d                	j	80001afc <kerneltrap+0x36>

0000000080001b58 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001b58:	1101                	addi	sp,sp,-32
    80001b5a:	ec06                	sd	ra,24(sp)
    80001b5c:	e822                	sd	s0,16(sp)
    80001b5e:	e426                	sd	s1,8(sp)
    80001b60:	1000                	addi	s0,sp,32
    80001b62:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001b64:	a1eff0ef          	jal	80000d82 <myproc>
  switch (n) {
    80001b68:	4795                	li	a5,5
    80001b6a:	0497e163          	bltu	a5,s1,80001bac <argraw+0x54>
    80001b6e:	048a                	slli	s1,s1,0x2
    80001b70:	00006717          	auipc	a4,0x6
    80001b74:	c3070713          	addi	a4,a4,-976 # 800077a0 <states.0+0x30>
    80001b78:	94ba                	add	s1,s1,a4
    80001b7a:	409c                	lw	a5,0(s1)
    80001b7c:	97ba                	add	a5,a5,a4
    80001b7e:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001b80:	6d3c                	ld	a5,88(a0)
    80001b82:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001b84:	60e2                	ld	ra,24(sp)
    80001b86:	6442                	ld	s0,16(sp)
    80001b88:	64a2                	ld	s1,8(sp)
    80001b8a:	6105                	addi	sp,sp,32
    80001b8c:	8082                	ret
    return p->trapframe->a1;
    80001b8e:	6d3c                	ld	a5,88(a0)
    80001b90:	7fa8                	ld	a0,120(a5)
    80001b92:	bfcd                	j	80001b84 <argraw+0x2c>
    return p->trapframe->a2;
    80001b94:	6d3c                	ld	a5,88(a0)
    80001b96:	63c8                	ld	a0,128(a5)
    80001b98:	b7f5                	j	80001b84 <argraw+0x2c>
    return p->trapframe->a3;
    80001b9a:	6d3c                	ld	a5,88(a0)
    80001b9c:	67c8                	ld	a0,136(a5)
    80001b9e:	b7dd                	j	80001b84 <argraw+0x2c>
    return p->trapframe->a4;
    80001ba0:	6d3c                	ld	a5,88(a0)
    80001ba2:	6bc8                	ld	a0,144(a5)
    80001ba4:	b7c5                	j	80001b84 <argraw+0x2c>
    return p->trapframe->a5;
    80001ba6:	6d3c                	ld	a5,88(a0)
    80001ba8:	6fc8                	ld	a0,152(a5)
    80001baa:	bfe9                	j	80001b84 <argraw+0x2c>
  panic("argraw");
    80001bac:	00005517          	auipc	a0,0x5
    80001bb0:	7fc50513          	addi	a0,a0,2044 # 800073a8 <etext+0x3a8>
    80001bb4:	0db030ef          	jal	8000548e <panic>

0000000080001bb8 <fetchaddr>:
{
    80001bb8:	1101                	addi	sp,sp,-32
    80001bba:	ec06                	sd	ra,24(sp)
    80001bbc:	e822                	sd	s0,16(sp)
    80001bbe:	e426                	sd	s1,8(sp)
    80001bc0:	e04a                	sd	s2,0(sp)
    80001bc2:	1000                	addi	s0,sp,32
    80001bc4:	84aa                	mv	s1,a0
    80001bc6:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001bc8:	9baff0ef          	jal	80000d82 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001bcc:	653c                	ld	a5,72(a0)
    80001bce:	02f4f663          	bgeu	s1,a5,80001bfa <fetchaddr+0x42>
    80001bd2:	00848713          	addi	a4,s1,8
    80001bd6:	02e7e463          	bltu	a5,a4,80001bfe <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001bda:	46a1                	li	a3,8
    80001bdc:	8626                	mv	a2,s1
    80001bde:	85ca                	mv	a1,s2
    80001be0:	6928                	ld	a0,80(a0)
    80001be2:	ed1fe0ef          	jal	80000ab2 <copyin>
    80001be6:	00a03533          	snez	a0,a0
    80001bea:	40a0053b          	negw	a0,a0
}
    80001bee:	60e2                	ld	ra,24(sp)
    80001bf0:	6442                	ld	s0,16(sp)
    80001bf2:	64a2                	ld	s1,8(sp)
    80001bf4:	6902                	ld	s2,0(sp)
    80001bf6:	6105                	addi	sp,sp,32
    80001bf8:	8082                	ret
    return -1;
    80001bfa:	557d                	li	a0,-1
    80001bfc:	bfcd                	j	80001bee <fetchaddr+0x36>
    80001bfe:	557d                	li	a0,-1
    80001c00:	b7fd                	j	80001bee <fetchaddr+0x36>

0000000080001c02 <fetchstr>:
{
    80001c02:	7179                	addi	sp,sp,-48
    80001c04:	f406                	sd	ra,40(sp)
    80001c06:	f022                	sd	s0,32(sp)
    80001c08:	ec26                	sd	s1,24(sp)
    80001c0a:	e84a                	sd	s2,16(sp)
    80001c0c:	e44e                	sd	s3,8(sp)
    80001c0e:	1800                	addi	s0,sp,48
    80001c10:	89aa                	mv	s3,a0
    80001c12:	84ae                	mv	s1,a1
    80001c14:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80001c16:	96cff0ef          	jal	80000d82 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001c1a:	86ca                	mv	a3,s2
    80001c1c:	864e                	mv	a2,s3
    80001c1e:	85a6                	mv	a1,s1
    80001c20:	6928                	ld	a0,80(a0)
    80001c22:	f17fe0ef          	jal	80000b38 <copyinstr>
    80001c26:	00054c63          	bltz	a0,80001c3e <fetchstr+0x3c>
  return strlen(buf);
    80001c2a:	8526                	mv	a0,s1
    80001c2c:	ebcfe0ef          	jal	800002e8 <strlen>
}
    80001c30:	70a2                	ld	ra,40(sp)
    80001c32:	7402                	ld	s0,32(sp)
    80001c34:	64e2                	ld	s1,24(sp)
    80001c36:	6942                	ld	s2,16(sp)
    80001c38:	69a2                	ld	s3,8(sp)
    80001c3a:	6145                	addi	sp,sp,48
    80001c3c:	8082                	ret
    return -1;
    80001c3e:	557d                	li	a0,-1
    80001c40:	bfc5                	j	80001c30 <fetchstr+0x2e>

0000000080001c42 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001c42:	1101                	addi	sp,sp,-32
    80001c44:	ec06                	sd	ra,24(sp)
    80001c46:	e822                	sd	s0,16(sp)
    80001c48:	e426                	sd	s1,8(sp)
    80001c4a:	1000                	addi	s0,sp,32
    80001c4c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001c4e:	f0bff0ef          	jal	80001b58 <argraw>
    80001c52:	c088                	sw	a0,0(s1)
}
    80001c54:	60e2                	ld	ra,24(sp)
    80001c56:	6442                	ld	s0,16(sp)
    80001c58:	64a2                	ld	s1,8(sp)
    80001c5a:	6105                	addi	sp,sp,32
    80001c5c:	8082                	ret

0000000080001c5e <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001c5e:	1101                	addi	sp,sp,-32
    80001c60:	ec06                	sd	ra,24(sp)
    80001c62:	e822                	sd	s0,16(sp)
    80001c64:	e426                	sd	s1,8(sp)
    80001c66:	1000                	addi	s0,sp,32
    80001c68:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001c6a:	eefff0ef          	jal	80001b58 <argraw>
    80001c6e:	e088                	sd	a0,0(s1)
}
    80001c70:	60e2                	ld	ra,24(sp)
    80001c72:	6442                	ld	s0,16(sp)
    80001c74:	64a2                	ld	s1,8(sp)
    80001c76:	6105                	addi	sp,sp,32
    80001c78:	8082                	ret

0000000080001c7a <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001c7a:	1101                	addi	sp,sp,-32
    80001c7c:	ec06                	sd	ra,24(sp)
    80001c7e:	e822                	sd	s0,16(sp)
    80001c80:	e426                	sd	s1,8(sp)
    80001c82:	e04a                	sd	s2,0(sp)
    80001c84:	1000                	addi	s0,sp,32
    80001c86:	892e                	mv	s2,a1
    80001c88:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80001c8a:	ecfff0ef          	jal	80001b58 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80001c8e:	8626                	mv	a2,s1
    80001c90:	85ca                	mv	a1,s2
    80001c92:	f71ff0ef          	jal	80001c02 <fetchstr>
}
    80001c96:	60e2                	ld	ra,24(sp)
    80001c98:	6442                	ld	s0,16(sp)
    80001c9a:	64a2                	ld	s1,8(sp)
    80001c9c:	6902                	ld	s2,0(sp)
    80001c9e:	6105                	addi	sp,sp,32
    80001ca0:	8082                	ret

0000000080001ca2 <syscall>:
[SYS_close]   sys_close,
};

void
syscall(void)
{
    80001ca2:	1101                	addi	sp,sp,-32
    80001ca4:	ec06                	sd	ra,24(sp)
    80001ca6:	e822                	sd	s0,16(sp)
    80001ca8:	e426                	sd	s1,8(sp)
    80001caa:	e04a                	sd	s2,0(sp)
    80001cac:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001cae:	8d4ff0ef          	jal	80000d82 <myproc>
    80001cb2:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001cb4:	05853903          	ld	s2,88(a0)
    80001cb8:	0a893783          	ld	a5,168(s2)
    80001cbc:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001cc0:	37fd                	addiw	a5,a5,-1
    80001cc2:	4751                	li	a4,20
    80001cc4:	00f76f63          	bltu	a4,a5,80001ce2 <syscall+0x40>
    80001cc8:	00369713          	slli	a4,a3,0x3
    80001ccc:	00006797          	auipc	a5,0x6
    80001cd0:	aec78793          	addi	a5,a5,-1300 # 800077b8 <syscalls>
    80001cd4:	97ba                	add	a5,a5,a4
    80001cd6:	639c                	ld	a5,0(a5)
    80001cd8:	c789                	beqz	a5,80001ce2 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001cda:	9782                	jalr	a5
    80001cdc:	06a93823          	sd	a0,112(s2)
    80001ce0:	a829                	j	80001cfa <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001ce2:	15848613          	addi	a2,s1,344
    80001ce6:	588c                	lw	a1,48(s1)
    80001ce8:	00005517          	auipc	a0,0x5
    80001cec:	6c850513          	addi	a0,a0,1736 # 800073b0 <etext+0x3b0>
    80001cf0:	48e030ef          	jal	8000517e <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001cf4:	6cbc                	ld	a5,88(s1)
    80001cf6:	577d                	li	a4,-1
    80001cf8:	fbb8                	sd	a4,112(a5)
  }
}
    80001cfa:	60e2                	ld	ra,24(sp)
    80001cfc:	6442                	ld	s0,16(sp)
    80001cfe:	64a2                	ld	s1,8(sp)
    80001d00:	6902                	ld	s2,0(sp)
    80001d02:	6105                	addi	sp,sp,32
    80001d04:	8082                	ret

0000000080001d06 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001d06:	1101                	addi	sp,sp,-32
    80001d08:	ec06                	sd	ra,24(sp)
    80001d0a:	e822                	sd	s0,16(sp)
    80001d0c:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001d0e:	fec40593          	addi	a1,s0,-20
    80001d12:	4501                	li	a0,0
    80001d14:	f2fff0ef          	jal	80001c42 <argint>
  exit(n);
    80001d18:	fec42503          	lw	a0,-20(s0)
    80001d1c:	f44ff0ef          	jal	80001460 <exit>
  return 0;  // not reached
}
    80001d20:	4501                	li	a0,0
    80001d22:	60e2                	ld	ra,24(sp)
    80001d24:	6442                	ld	s0,16(sp)
    80001d26:	6105                	addi	sp,sp,32
    80001d28:	8082                	ret

0000000080001d2a <sys_getpid>:

uint64
sys_getpid(void)
{
    80001d2a:	1141                	addi	sp,sp,-16
    80001d2c:	e406                	sd	ra,8(sp)
    80001d2e:	e022                	sd	s0,0(sp)
    80001d30:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001d32:	850ff0ef          	jal	80000d82 <myproc>
}
    80001d36:	5908                	lw	a0,48(a0)
    80001d38:	60a2                	ld	ra,8(sp)
    80001d3a:	6402                	ld	s0,0(sp)
    80001d3c:	0141                	addi	sp,sp,16
    80001d3e:	8082                	ret

0000000080001d40 <sys_fork>:

uint64
sys_fork(void)
{
    80001d40:	1141                	addi	sp,sp,-16
    80001d42:	e406                	sd	ra,8(sp)
    80001d44:	e022                	sd	s0,0(sp)
    80001d46:	0800                	addi	s0,sp,16
  return fork();
    80001d48:	b62ff0ef          	jal	800010aa <fork>
}
    80001d4c:	60a2                	ld	ra,8(sp)
    80001d4e:	6402                	ld	s0,0(sp)
    80001d50:	0141                	addi	sp,sp,16
    80001d52:	8082                	ret

0000000080001d54 <sys_wait>:

uint64
sys_wait(void)
{
    80001d54:	1101                	addi	sp,sp,-32
    80001d56:	ec06                	sd	ra,24(sp)
    80001d58:	e822                	sd	s0,16(sp)
    80001d5a:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001d5c:	fe840593          	addi	a1,s0,-24
    80001d60:	4501                	li	a0,0
    80001d62:	efdff0ef          	jal	80001c5e <argaddr>
  return wait(p);
    80001d66:	fe843503          	ld	a0,-24(s0)
    80001d6a:	851ff0ef          	jal	800015ba <wait>
}
    80001d6e:	60e2                	ld	ra,24(sp)
    80001d70:	6442                	ld	s0,16(sp)
    80001d72:	6105                	addi	sp,sp,32
    80001d74:	8082                	ret

0000000080001d76 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001d76:	7179                	addi	sp,sp,-48
    80001d78:	f406                	sd	ra,40(sp)
    80001d7a:	f022                	sd	s0,32(sp)
    80001d7c:	ec26                	sd	s1,24(sp)
    80001d7e:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001d80:	fdc40593          	addi	a1,s0,-36
    80001d84:	4501                	li	a0,0
    80001d86:	ebdff0ef          	jal	80001c42 <argint>
  addr = myproc()->sz;
    80001d8a:	ff9fe0ef          	jal	80000d82 <myproc>
    80001d8e:	653c                	ld	a5,72(a0)
    80001d90:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80001d92:	fdc42503          	lw	a0,-36(s0)
    80001d96:	ac4ff0ef          	jal	8000105a <growproc>
    80001d9a:	00054863          	bltz	a0,80001daa <sys_sbrk+0x34>
    return -1;
  return addr;
}
    80001d9e:	8526                	mv	a0,s1
    80001da0:	70a2                	ld	ra,40(sp)
    80001da2:	7402                	ld	s0,32(sp)
    80001da4:	64e2                	ld	s1,24(sp)
    80001da6:	6145                	addi	sp,sp,48
    80001da8:	8082                	ret
    return -1;
    80001daa:	57fd                	li	a5,-1
    80001dac:	84be                	mv	s1,a5
    80001dae:	bfc5                	j	80001d9e <sys_sbrk+0x28>

0000000080001db0 <sys_sleep>:

uint64
sys_sleep(void)
{
    80001db0:	7139                	addi	sp,sp,-64
    80001db2:	fc06                	sd	ra,56(sp)
    80001db4:	f822                	sd	s0,48(sp)
    80001db6:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80001db8:	fcc40593          	addi	a1,s0,-52
    80001dbc:	4501                	li	a0,0
    80001dbe:	e85ff0ef          	jal	80001c42 <argint>
  if(n < 0)
    80001dc2:	fcc42783          	lw	a5,-52(s0)
    80001dc6:	0607c863          	bltz	a5,80001e36 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80001dca:	0000c517          	auipc	a0,0xc
    80001dce:	98650513          	addi	a0,a0,-1658 # 8000d750 <tickslock>
    80001dd2:	1fb030ef          	jal	800057cc <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80001dd6:	fcc42783          	lw	a5,-52(s0)
    80001dda:	c3b9                	beqz	a5,80001e20 <sys_sleep+0x70>
    80001ddc:	f426                	sd	s1,40(sp)
    80001dde:	f04a                	sd	s2,32(sp)
    80001de0:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80001de2:	00006997          	auipc	s3,0x6
    80001de6:	b069a983          	lw	s3,-1274(s3) # 800078e8 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80001dea:	0000c917          	auipc	s2,0xc
    80001dee:	96690913          	addi	s2,s2,-1690 # 8000d750 <tickslock>
    80001df2:	00006497          	auipc	s1,0x6
    80001df6:	af648493          	addi	s1,s1,-1290 # 800078e8 <ticks>
    if(killed(myproc())){
    80001dfa:	f89fe0ef          	jal	80000d82 <myproc>
    80001dfe:	f92ff0ef          	jal	80001590 <killed>
    80001e02:	ed0d                	bnez	a0,80001e3c <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80001e04:	85ca                	mv	a1,s2
    80001e06:	8526                	mv	a0,s1
    80001e08:	d4cff0ef          	jal	80001354 <sleep>
  while(ticks - ticks0 < n){
    80001e0c:	409c                	lw	a5,0(s1)
    80001e0e:	413787bb          	subw	a5,a5,s3
    80001e12:	fcc42703          	lw	a4,-52(s0)
    80001e16:	fee7e2e3          	bltu	a5,a4,80001dfa <sys_sleep+0x4a>
    80001e1a:	74a2                	ld	s1,40(sp)
    80001e1c:	7902                	ld	s2,32(sp)
    80001e1e:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80001e20:	0000c517          	auipc	a0,0xc
    80001e24:	93050513          	addi	a0,a0,-1744 # 8000d750 <tickslock>
    80001e28:	239030ef          	jal	80005860 <release>
  return 0;
    80001e2c:	4501                	li	a0,0
}
    80001e2e:	70e2                	ld	ra,56(sp)
    80001e30:	7442                	ld	s0,48(sp)
    80001e32:	6121                	addi	sp,sp,64
    80001e34:	8082                	ret
    n = 0;
    80001e36:	fc042623          	sw	zero,-52(s0)
    80001e3a:	bf41                	j	80001dca <sys_sleep+0x1a>
      release(&tickslock);
    80001e3c:	0000c517          	auipc	a0,0xc
    80001e40:	91450513          	addi	a0,a0,-1772 # 8000d750 <tickslock>
    80001e44:	21d030ef          	jal	80005860 <release>
      return -1;
    80001e48:	557d                	li	a0,-1
    80001e4a:	74a2                	ld	s1,40(sp)
    80001e4c:	7902                	ld	s2,32(sp)
    80001e4e:	69e2                	ld	s3,24(sp)
    80001e50:	bff9                	j	80001e2e <sys_sleep+0x7e>

0000000080001e52 <sys_kill>:

uint64
sys_kill(void)
{
    80001e52:	1101                	addi	sp,sp,-32
    80001e54:	ec06                	sd	ra,24(sp)
    80001e56:	e822                	sd	s0,16(sp)
    80001e58:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80001e5a:	fec40593          	addi	a1,s0,-20
    80001e5e:	4501                	li	a0,0
    80001e60:	de3ff0ef          	jal	80001c42 <argint>
  return kill(pid);
    80001e64:	fec42503          	lw	a0,-20(s0)
    80001e68:	e9eff0ef          	jal	80001506 <kill>
}
    80001e6c:	60e2                	ld	ra,24(sp)
    80001e6e:	6442                	ld	s0,16(sp)
    80001e70:	6105                	addi	sp,sp,32
    80001e72:	8082                	ret

0000000080001e74 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80001e74:	1101                	addi	sp,sp,-32
    80001e76:	ec06                	sd	ra,24(sp)
    80001e78:	e822                	sd	s0,16(sp)
    80001e7a:	e426                	sd	s1,8(sp)
    80001e7c:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80001e7e:	0000c517          	auipc	a0,0xc
    80001e82:	8d250513          	addi	a0,a0,-1838 # 8000d750 <tickslock>
    80001e86:	147030ef          	jal	800057cc <acquire>
  xticks = ticks;
    80001e8a:	00006797          	auipc	a5,0x6
    80001e8e:	a5e7a783          	lw	a5,-1442(a5) # 800078e8 <ticks>
    80001e92:	84be                	mv	s1,a5
  release(&tickslock);
    80001e94:	0000c517          	auipc	a0,0xc
    80001e98:	8bc50513          	addi	a0,a0,-1860 # 8000d750 <tickslock>
    80001e9c:	1c5030ef          	jal	80005860 <release>
  return xticks;
}
    80001ea0:	02049513          	slli	a0,s1,0x20
    80001ea4:	9101                	srli	a0,a0,0x20
    80001ea6:	60e2                	ld	ra,24(sp)
    80001ea8:	6442                	ld	s0,16(sp)
    80001eaa:	64a2                	ld	s1,8(sp)
    80001eac:	6105                	addi	sp,sp,32
    80001eae:	8082                	ret

0000000080001eb0 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80001eb0:	7179                	addi	sp,sp,-48
    80001eb2:	f406                	sd	ra,40(sp)
    80001eb4:	f022                	sd	s0,32(sp)
    80001eb6:	ec26                	sd	s1,24(sp)
    80001eb8:	e84a                	sd	s2,16(sp)
    80001eba:	e44e                	sd	s3,8(sp)
    80001ebc:	e052                	sd	s4,0(sp)
    80001ebe:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80001ec0:	00005597          	auipc	a1,0x5
    80001ec4:	51058593          	addi	a1,a1,1296 # 800073d0 <etext+0x3d0>
    80001ec8:	0000c517          	auipc	a0,0xc
    80001ecc:	8a050513          	addi	a0,a0,-1888 # 8000d768 <bcache>
    80001ed0:	073030ef          	jal	80005742 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80001ed4:	00014797          	auipc	a5,0x14
    80001ed8:	89478793          	addi	a5,a5,-1900 # 80015768 <bcache+0x8000>
    80001edc:	00014717          	auipc	a4,0x14
    80001ee0:	af470713          	addi	a4,a4,-1292 # 800159d0 <bcache+0x8268>
    80001ee4:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80001ee8:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80001eec:	0000c497          	auipc	s1,0xc
    80001ef0:	89448493          	addi	s1,s1,-1900 # 8000d780 <bcache+0x18>
    b->next = bcache.head.next;
    80001ef4:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80001ef6:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80001ef8:	00005a17          	auipc	s4,0x5
    80001efc:	4e0a0a13          	addi	s4,s4,1248 # 800073d8 <etext+0x3d8>
    b->next = bcache.head.next;
    80001f00:	2b893783          	ld	a5,696(s2)
    80001f04:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80001f06:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80001f0a:	85d2                	mv	a1,s4
    80001f0c:	01048513          	addi	a0,s1,16
    80001f10:	24c010ef          	jal	8000315c <initsleeplock>
    bcache.head.next->prev = b;
    80001f14:	2b893783          	ld	a5,696(s2)
    80001f18:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80001f1a:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80001f1e:	45848493          	addi	s1,s1,1112
    80001f22:	fd349fe3          	bne	s1,s3,80001f00 <binit+0x50>
  }
}
    80001f26:	70a2                	ld	ra,40(sp)
    80001f28:	7402                	ld	s0,32(sp)
    80001f2a:	64e2                	ld	s1,24(sp)
    80001f2c:	6942                	ld	s2,16(sp)
    80001f2e:	69a2                	ld	s3,8(sp)
    80001f30:	6a02                	ld	s4,0(sp)
    80001f32:	6145                	addi	sp,sp,48
    80001f34:	8082                	ret

0000000080001f36 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80001f36:	7179                	addi	sp,sp,-48
    80001f38:	f406                	sd	ra,40(sp)
    80001f3a:	f022                	sd	s0,32(sp)
    80001f3c:	ec26                	sd	s1,24(sp)
    80001f3e:	e84a                	sd	s2,16(sp)
    80001f40:	e44e                	sd	s3,8(sp)
    80001f42:	1800                	addi	s0,sp,48
    80001f44:	892a                	mv	s2,a0
    80001f46:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80001f48:	0000c517          	auipc	a0,0xc
    80001f4c:	82050513          	addi	a0,a0,-2016 # 8000d768 <bcache>
    80001f50:	07d030ef          	jal	800057cc <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80001f54:	00014497          	auipc	s1,0x14
    80001f58:	acc4b483          	ld	s1,-1332(s1) # 80015a20 <bcache+0x82b8>
    80001f5c:	00014797          	auipc	a5,0x14
    80001f60:	a7478793          	addi	a5,a5,-1420 # 800159d0 <bcache+0x8268>
    80001f64:	02f48b63          	beq	s1,a5,80001f9a <bread+0x64>
    80001f68:	873e                	mv	a4,a5
    80001f6a:	a021                	j	80001f72 <bread+0x3c>
    80001f6c:	68a4                	ld	s1,80(s1)
    80001f6e:	02e48663          	beq	s1,a4,80001f9a <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80001f72:	449c                	lw	a5,8(s1)
    80001f74:	ff279ce3          	bne	a5,s2,80001f6c <bread+0x36>
    80001f78:	44dc                	lw	a5,12(s1)
    80001f7a:	ff3799e3          	bne	a5,s3,80001f6c <bread+0x36>
      b->refcnt++;
    80001f7e:	40bc                	lw	a5,64(s1)
    80001f80:	2785                	addiw	a5,a5,1
    80001f82:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80001f84:	0000b517          	auipc	a0,0xb
    80001f88:	7e450513          	addi	a0,a0,2020 # 8000d768 <bcache>
    80001f8c:	0d5030ef          	jal	80005860 <release>
      acquiresleep(&b->lock);
    80001f90:	01048513          	addi	a0,s1,16
    80001f94:	1fe010ef          	jal	80003192 <acquiresleep>
      return b;
    80001f98:	a889                	j	80001fea <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80001f9a:	00014497          	auipc	s1,0x14
    80001f9e:	a7e4b483          	ld	s1,-1410(s1) # 80015a18 <bcache+0x82b0>
    80001fa2:	00014797          	auipc	a5,0x14
    80001fa6:	a2e78793          	addi	a5,a5,-1490 # 800159d0 <bcache+0x8268>
    80001faa:	00f48863          	beq	s1,a5,80001fba <bread+0x84>
    80001fae:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80001fb0:	40bc                	lw	a5,64(s1)
    80001fb2:	cb91                	beqz	a5,80001fc6 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80001fb4:	64a4                	ld	s1,72(s1)
    80001fb6:	fee49de3          	bne	s1,a4,80001fb0 <bread+0x7a>
  panic("bget: no buffers");
    80001fba:	00005517          	auipc	a0,0x5
    80001fbe:	42650513          	addi	a0,a0,1062 # 800073e0 <etext+0x3e0>
    80001fc2:	4cc030ef          	jal	8000548e <panic>
      b->dev = dev;
    80001fc6:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80001fca:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80001fce:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80001fd2:	4785                	li	a5,1
    80001fd4:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80001fd6:	0000b517          	auipc	a0,0xb
    80001fda:	79250513          	addi	a0,a0,1938 # 8000d768 <bcache>
    80001fde:	083030ef          	jal	80005860 <release>
      acquiresleep(&b->lock);
    80001fe2:	01048513          	addi	a0,s1,16
    80001fe6:	1ac010ef          	jal	80003192 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80001fea:	409c                	lw	a5,0(s1)
    80001fec:	cb89                	beqz	a5,80001ffe <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80001fee:	8526                	mv	a0,s1
    80001ff0:	70a2                	ld	ra,40(sp)
    80001ff2:	7402                	ld	s0,32(sp)
    80001ff4:	64e2                	ld	s1,24(sp)
    80001ff6:	6942                	ld	s2,16(sp)
    80001ff8:	69a2                	ld	s3,8(sp)
    80001ffa:	6145                	addi	sp,sp,48
    80001ffc:	8082                	ret
    virtio_disk_rw(b, 0);
    80001ffe:	4581                	li	a1,0
    80002000:	8526                	mv	a0,s1
    80002002:	20f020ef          	jal	80004a10 <virtio_disk_rw>
    b->valid = 1;
    80002006:	4785                	li	a5,1
    80002008:	c09c                	sw	a5,0(s1)
  return b;
    8000200a:	b7d5                	j	80001fee <bread+0xb8>

000000008000200c <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000200c:	1101                	addi	sp,sp,-32
    8000200e:	ec06                	sd	ra,24(sp)
    80002010:	e822                	sd	s0,16(sp)
    80002012:	e426                	sd	s1,8(sp)
    80002014:	1000                	addi	s0,sp,32
    80002016:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002018:	0541                	addi	a0,a0,16
    8000201a:	1f6010ef          	jal	80003210 <holdingsleep>
    8000201e:	c911                	beqz	a0,80002032 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002020:	4585                	li	a1,1
    80002022:	8526                	mv	a0,s1
    80002024:	1ed020ef          	jal	80004a10 <virtio_disk_rw>
}
    80002028:	60e2                	ld	ra,24(sp)
    8000202a:	6442                	ld	s0,16(sp)
    8000202c:	64a2                	ld	s1,8(sp)
    8000202e:	6105                	addi	sp,sp,32
    80002030:	8082                	ret
    panic("bwrite");
    80002032:	00005517          	auipc	a0,0x5
    80002036:	3c650513          	addi	a0,a0,966 # 800073f8 <etext+0x3f8>
    8000203a:	454030ef          	jal	8000548e <panic>

000000008000203e <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000203e:	1101                	addi	sp,sp,-32
    80002040:	ec06                	sd	ra,24(sp)
    80002042:	e822                	sd	s0,16(sp)
    80002044:	e426                	sd	s1,8(sp)
    80002046:	e04a                	sd	s2,0(sp)
    80002048:	1000                	addi	s0,sp,32
    8000204a:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000204c:	01050913          	addi	s2,a0,16
    80002050:	854a                	mv	a0,s2
    80002052:	1be010ef          	jal	80003210 <holdingsleep>
    80002056:	c125                	beqz	a0,800020b6 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002058:	854a                	mv	a0,s2
    8000205a:	17e010ef          	jal	800031d8 <releasesleep>

  acquire(&bcache.lock);
    8000205e:	0000b517          	auipc	a0,0xb
    80002062:	70a50513          	addi	a0,a0,1802 # 8000d768 <bcache>
    80002066:	766030ef          	jal	800057cc <acquire>
  b->refcnt--;
    8000206a:	40bc                	lw	a5,64(s1)
    8000206c:	37fd                	addiw	a5,a5,-1
    8000206e:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002070:	e79d                	bnez	a5,8000209e <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002072:	68b8                	ld	a4,80(s1)
    80002074:	64bc                	ld	a5,72(s1)
    80002076:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002078:	68b8                	ld	a4,80(s1)
    8000207a:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    8000207c:	00013797          	auipc	a5,0x13
    80002080:	6ec78793          	addi	a5,a5,1772 # 80015768 <bcache+0x8000>
    80002084:	2b87b703          	ld	a4,696(a5)
    80002088:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    8000208a:	00014717          	auipc	a4,0x14
    8000208e:	94670713          	addi	a4,a4,-1722 # 800159d0 <bcache+0x8268>
    80002092:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002094:	2b87b703          	ld	a4,696(a5)
    80002098:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    8000209a:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    8000209e:	0000b517          	auipc	a0,0xb
    800020a2:	6ca50513          	addi	a0,a0,1738 # 8000d768 <bcache>
    800020a6:	7ba030ef          	jal	80005860 <release>
}
    800020aa:	60e2                	ld	ra,24(sp)
    800020ac:	6442                	ld	s0,16(sp)
    800020ae:	64a2                	ld	s1,8(sp)
    800020b0:	6902                	ld	s2,0(sp)
    800020b2:	6105                	addi	sp,sp,32
    800020b4:	8082                	ret
    panic("brelse");
    800020b6:	00005517          	auipc	a0,0x5
    800020ba:	34a50513          	addi	a0,a0,842 # 80007400 <etext+0x400>
    800020be:	3d0030ef          	jal	8000548e <panic>

00000000800020c2 <bpin>:

void
bpin(struct buf *b) {
    800020c2:	1101                	addi	sp,sp,-32
    800020c4:	ec06                	sd	ra,24(sp)
    800020c6:	e822                	sd	s0,16(sp)
    800020c8:	e426                	sd	s1,8(sp)
    800020ca:	1000                	addi	s0,sp,32
    800020cc:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800020ce:	0000b517          	auipc	a0,0xb
    800020d2:	69a50513          	addi	a0,a0,1690 # 8000d768 <bcache>
    800020d6:	6f6030ef          	jal	800057cc <acquire>
  b->refcnt++;
    800020da:	40bc                	lw	a5,64(s1)
    800020dc:	2785                	addiw	a5,a5,1
    800020de:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800020e0:	0000b517          	auipc	a0,0xb
    800020e4:	68850513          	addi	a0,a0,1672 # 8000d768 <bcache>
    800020e8:	778030ef          	jal	80005860 <release>
}
    800020ec:	60e2                	ld	ra,24(sp)
    800020ee:	6442                	ld	s0,16(sp)
    800020f0:	64a2                	ld	s1,8(sp)
    800020f2:	6105                	addi	sp,sp,32
    800020f4:	8082                	ret

00000000800020f6 <bunpin>:

void
bunpin(struct buf *b) {
    800020f6:	1101                	addi	sp,sp,-32
    800020f8:	ec06                	sd	ra,24(sp)
    800020fa:	e822                	sd	s0,16(sp)
    800020fc:	e426                	sd	s1,8(sp)
    800020fe:	1000                	addi	s0,sp,32
    80002100:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002102:	0000b517          	auipc	a0,0xb
    80002106:	66650513          	addi	a0,a0,1638 # 8000d768 <bcache>
    8000210a:	6c2030ef          	jal	800057cc <acquire>
  b->refcnt--;
    8000210e:	40bc                	lw	a5,64(s1)
    80002110:	37fd                	addiw	a5,a5,-1
    80002112:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002114:	0000b517          	auipc	a0,0xb
    80002118:	65450513          	addi	a0,a0,1620 # 8000d768 <bcache>
    8000211c:	744030ef          	jal	80005860 <release>
}
    80002120:	60e2                	ld	ra,24(sp)
    80002122:	6442                	ld	s0,16(sp)
    80002124:	64a2                	ld	s1,8(sp)
    80002126:	6105                	addi	sp,sp,32
    80002128:	8082                	ret

000000008000212a <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    8000212a:	1101                	addi	sp,sp,-32
    8000212c:	ec06                	sd	ra,24(sp)
    8000212e:	e822                	sd	s0,16(sp)
    80002130:	e426                	sd	s1,8(sp)
    80002132:	e04a                	sd	s2,0(sp)
    80002134:	1000                	addi	s0,sp,32
    80002136:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002138:	00d5d79b          	srliw	a5,a1,0xd
    8000213c:	00014597          	auipc	a1,0x14
    80002140:	d085a583          	lw	a1,-760(a1) # 80015e44 <sb+0x1c>
    80002144:	9dbd                	addw	a1,a1,a5
    80002146:	df1ff0ef          	jal	80001f36 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    8000214a:	0074f713          	andi	a4,s1,7
    8000214e:	4785                	li	a5,1
    80002150:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002154:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002156:	90d9                	srli	s1,s1,0x36
    80002158:	00950733          	add	a4,a0,s1
    8000215c:	05874703          	lbu	a4,88(a4)
    80002160:	00e7f6b3          	and	a3,a5,a4
    80002164:	c29d                	beqz	a3,8000218a <bfree+0x60>
    80002166:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002168:	94aa                	add	s1,s1,a0
    8000216a:	fff7c793          	not	a5,a5
    8000216e:	8f7d                	and	a4,a4,a5
    80002170:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002174:	717000ef          	jal	8000308a <log_write>
  brelse(bp);
    80002178:	854a                	mv	a0,s2
    8000217a:	ec5ff0ef          	jal	8000203e <brelse>
}
    8000217e:	60e2                	ld	ra,24(sp)
    80002180:	6442                	ld	s0,16(sp)
    80002182:	64a2                	ld	s1,8(sp)
    80002184:	6902                	ld	s2,0(sp)
    80002186:	6105                	addi	sp,sp,32
    80002188:	8082                	ret
    panic("freeing free block");
    8000218a:	00005517          	auipc	a0,0x5
    8000218e:	27e50513          	addi	a0,a0,638 # 80007408 <etext+0x408>
    80002192:	2fc030ef          	jal	8000548e <panic>

0000000080002196 <balloc>:
{
    80002196:	715d                	addi	sp,sp,-80
    80002198:	e486                	sd	ra,72(sp)
    8000219a:	e0a2                	sd	s0,64(sp)
    8000219c:	fc26                	sd	s1,56(sp)
    8000219e:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    800021a0:	00014797          	auipc	a5,0x14
    800021a4:	c8c7a783          	lw	a5,-884(a5) # 80015e2c <sb+0x4>
    800021a8:	0e078263          	beqz	a5,8000228c <balloc+0xf6>
    800021ac:	f84a                	sd	s2,48(sp)
    800021ae:	f44e                	sd	s3,40(sp)
    800021b0:	f052                	sd	s4,32(sp)
    800021b2:	ec56                	sd	s5,24(sp)
    800021b4:	e85a                	sd	s6,16(sp)
    800021b6:	e45e                	sd	s7,8(sp)
    800021b8:	e062                	sd	s8,0(sp)
    800021ba:	8baa                	mv	s7,a0
    800021bc:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800021be:	00014b17          	auipc	s6,0x14
    800021c2:	c6ab0b13          	addi	s6,s6,-918 # 80015e28 <sb>
      m = 1 << (bi % 8);
    800021c6:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800021c8:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    800021ca:	6c09                	lui	s8,0x2
    800021cc:	a09d                	j	80002232 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    800021ce:	97ca                	add	a5,a5,s2
    800021d0:	8e55                	or	a2,a2,a3
    800021d2:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    800021d6:	854a                	mv	a0,s2
    800021d8:	6b3000ef          	jal	8000308a <log_write>
        brelse(bp);
    800021dc:	854a                	mv	a0,s2
    800021de:	e61ff0ef          	jal	8000203e <brelse>
  bp = bread(dev, bno);
    800021e2:	85a6                	mv	a1,s1
    800021e4:	855e                	mv	a0,s7
    800021e6:	d51ff0ef          	jal	80001f36 <bread>
    800021ea:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800021ec:	40000613          	li	a2,1024
    800021f0:	4581                	li	a1,0
    800021f2:	05850513          	addi	a0,a0,88
    800021f6:	f69fd0ef          	jal	8000015e <memset>
  log_write(bp);
    800021fa:	854a                	mv	a0,s2
    800021fc:	68f000ef          	jal	8000308a <log_write>
  brelse(bp);
    80002200:	854a                	mv	a0,s2
    80002202:	e3dff0ef          	jal	8000203e <brelse>
}
    80002206:	7942                	ld	s2,48(sp)
    80002208:	79a2                	ld	s3,40(sp)
    8000220a:	7a02                	ld	s4,32(sp)
    8000220c:	6ae2                	ld	s5,24(sp)
    8000220e:	6b42                	ld	s6,16(sp)
    80002210:	6ba2                	ld	s7,8(sp)
    80002212:	6c02                	ld	s8,0(sp)
}
    80002214:	8526                	mv	a0,s1
    80002216:	60a6                	ld	ra,72(sp)
    80002218:	6406                	ld	s0,64(sp)
    8000221a:	74e2                	ld	s1,56(sp)
    8000221c:	6161                	addi	sp,sp,80
    8000221e:	8082                	ret
    brelse(bp);
    80002220:	854a                	mv	a0,s2
    80002222:	e1dff0ef          	jal	8000203e <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002226:	015c0abb          	addw	s5,s8,s5
    8000222a:	004b2783          	lw	a5,4(s6)
    8000222e:	04faf863          	bgeu	s5,a5,8000227e <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002232:	40dad59b          	sraiw	a1,s5,0xd
    80002236:	01cb2783          	lw	a5,28(s6)
    8000223a:	9dbd                	addw	a1,a1,a5
    8000223c:	855e                	mv	a0,s7
    8000223e:	cf9ff0ef          	jal	80001f36 <bread>
    80002242:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002244:	004b2503          	lw	a0,4(s6)
    80002248:	84d6                	mv	s1,s5
    8000224a:	4701                	li	a4,0
    8000224c:	fca4fae3          	bgeu	s1,a0,80002220 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002250:	00777693          	andi	a3,a4,7
    80002254:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002258:	41f7579b          	sraiw	a5,a4,0x1f
    8000225c:	01d7d79b          	srliw	a5,a5,0x1d
    80002260:	9fb9                	addw	a5,a5,a4
    80002262:	4037d79b          	sraiw	a5,a5,0x3
    80002266:	00f90633          	add	a2,s2,a5
    8000226a:	05864603          	lbu	a2,88(a2)
    8000226e:	00c6f5b3          	and	a1,a3,a2
    80002272:	ddb1                	beqz	a1,800021ce <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002274:	2705                	addiw	a4,a4,1
    80002276:	2485                	addiw	s1,s1,1
    80002278:	fd471ae3          	bne	a4,s4,8000224c <balloc+0xb6>
    8000227c:	b755                	j	80002220 <balloc+0x8a>
    8000227e:	7942                	ld	s2,48(sp)
    80002280:	79a2                	ld	s3,40(sp)
    80002282:	7a02                	ld	s4,32(sp)
    80002284:	6ae2                	ld	s5,24(sp)
    80002286:	6b42                	ld	s6,16(sp)
    80002288:	6ba2                	ld	s7,8(sp)
    8000228a:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    8000228c:	00005517          	auipc	a0,0x5
    80002290:	19450513          	addi	a0,a0,404 # 80007420 <etext+0x420>
    80002294:	6eb020ef          	jal	8000517e <printf>
  return 0;
    80002298:	4481                	li	s1,0
    8000229a:	bfad                	j	80002214 <balloc+0x7e>

000000008000229c <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000229c:	7179                	addi	sp,sp,-48
    8000229e:	f406                	sd	ra,40(sp)
    800022a0:	f022                	sd	s0,32(sp)
    800022a2:	ec26                	sd	s1,24(sp)
    800022a4:	e84a                	sd	s2,16(sp)
    800022a6:	e44e                	sd	s3,8(sp)
    800022a8:	1800                	addi	s0,sp,48
    800022aa:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800022ac:	47ad                	li	a5,11
    800022ae:	02b7e363          	bltu	a5,a1,800022d4 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    800022b2:	02059793          	slli	a5,a1,0x20
    800022b6:	01e7d593          	srli	a1,a5,0x1e
    800022ba:	00b509b3          	add	s3,a0,a1
    800022be:	0509a483          	lw	s1,80(s3)
    800022c2:	e0b5                	bnez	s1,80002326 <bmap+0x8a>
      addr = balloc(ip->dev);
    800022c4:	4108                	lw	a0,0(a0)
    800022c6:	ed1ff0ef          	jal	80002196 <balloc>
    800022ca:	84aa                	mv	s1,a0
      if(addr == 0)
    800022cc:	cd29                	beqz	a0,80002326 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    800022ce:	04a9a823          	sw	a0,80(s3)
    800022d2:	a891                	j	80002326 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800022d4:	ff45879b          	addiw	a5,a1,-12
    800022d8:	873e                	mv	a4,a5
    800022da:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    800022dc:	0ff00793          	li	a5,255
    800022e0:	06e7e763          	bltu	a5,a4,8000234e <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800022e4:	08052483          	lw	s1,128(a0)
    800022e8:	e891                	bnez	s1,800022fc <bmap+0x60>
      addr = balloc(ip->dev);
    800022ea:	4108                	lw	a0,0(a0)
    800022ec:	eabff0ef          	jal	80002196 <balloc>
    800022f0:	84aa                	mv	s1,a0
      if(addr == 0)
    800022f2:	c915                	beqz	a0,80002326 <bmap+0x8a>
    800022f4:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    800022f6:	08a92023          	sw	a0,128(s2)
    800022fa:	a011                	j	800022fe <bmap+0x62>
    800022fc:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    800022fe:	85a6                	mv	a1,s1
    80002300:	00092503          	lw	a0,0(s2)
    80002304:	c33ff0ef          	jal	80001f36 <bread>
    80002308:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    8000230a:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000230e:	02099713          	slli	a4,s3,0x20
    80002312:	01e75593          	srli	a1,a4,0x1e
    80002316:	97ae                	add	a5,a5,a1
    80002318:	89be                	mv	s3,a5
    8000231a:	4384                	lw	s1,0(a5)
    8000231c:	cc89                	beqz	s1,80002336 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000231e:	8552                	mv	a0,s4
    80002320:	d1fff0ef          	jal	8000203e <brelse>
    return addr;
    80002324:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002326:	8526                	mv	a0,s1
    80002328:	70a2                	ld	ra,40(sp)
    8000232a:	7402                	ld	s0,32(sp)
    8000232c:	64e2                	ld	s1,24(sp)
    8000232e:	6942                	ld	s2,16(sp)
    80002330:	69a2                	ld	s3,8(sp)
    80002332:	6145                	addi	sp,sp,48
    80002334:	8082                	ret
      addr = balloc(ip->dev);
    80002336:	00092503          	lw	a0,0(s2)
    8000233a:	e5dff0ef          	jal	80002196 <balloc>
    8000233e:	84aa                	mv	s1,a0
      if(addr){
    80002340:	dd79                	beqz	a0,8000231e <bmap+0x82>
        a[bn] = addr;
    80002342:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002346:	8552                	mv	a0,s4
    80002348:	543000ef          	jal	8000308a <log_write>
    8000234c:	bfc9                	j	8000231e <bmap+0x82>
    8000234e:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80002350:	00005517          	auipc	a0,0x5
    80002354:	0e850513          	addi	a0,a0,232 # 80007438 <etext+0x438>
    80002358:	136030ef          	jal	8000548e <panic>

000000008000235c <iget>:
{
    8000235c:	7179                	addi	sp,sp,-48
    8000235e:	f406                	sd	ra,40(sp)
    80002360:	f022                	sd	s0,32(sp)
    80002362:	ec26                	sd	s1,24(sp)
    80002364:	e84a                	sd	s2,16(sp)
    80002366:	e44e                	sd	s3,8(sp)
    80002368:	e052                	sd	s4,0(sp)
    8000236a:	1800                	addi	s0,sp,48
    8000236c:	892a                	mv	s2,a0
    8000236e:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80002370:	00014517          	auipc	a0,0x14
    80002374:	ad850513          	addi	a0,a0,-1320 # 80015e48 <itable>
    80002378:	454030ef          	jal	800057cc <acquire>
  empty = 0;
    8000237c:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000237e:	00014497          	auipc	s1,0x14
    80002382:	ae248493          	addi	s1,s1,-1310 # 80015e60 <itable+0x18>
    80002386:	00015697          	auipc	a3,0x15
    8000238a:	56a68693          	addi	a3,a3,1386 # 800178f0 <log>
    8000238e:	a809                	j	800023a0 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002390:	e781                	bnez	a5,80002398 <iget+0x3c>
    80002392:	00099363          	bnez	s3,80002398 <iget+0x3c>
      empty = ip;
    80002396:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002398:	08848493          	addi	s1,s1,136
    8000239c:	02d48563          	beq	s1,a3,800023c6 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800023a0:	449c                	lw	a5,8(s1)
    800023a2:	fef057e3          	blez	a5,80002390 <iget+0x34>
    800023a6:	4098                	lw	a4,0(s1)
    800023a8:	ff2718e3          	bne	a4,s2,80002398 <iget+0x3c>
    800023ac:	40d8                	lw	a4,4(s1)
    800023ae:	ff4715e3          	bne	a4,s4,80002398 <iget+0x3c>
      ip->ref++;
    800023b2:	2785                	addiw	a5,a5,1
    800023b4:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800023b6:	00014517          	auipc	a0,0x14
    800023ba:	a9250513          	addi	a0,a0,-1390 # 80015e48 <itable>
    800023be:	4a2030ef          	jal	80005860 <release>
      return ip;
    800023c2:	89a6                	mv	s3,s1
    800023c4:	a015                	j	800023e8 <iget+0x8c>
  if(empty == 0)
    800023c6:	02098a63          	beqz	s3,800023fa <iget+0x9e>
  ip->dev = dev;
    800023ca:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    800023ce:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    800023d2:	4785                	li	a5,1
    800023d4:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    800023d8:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    800023dc:	00014517          	auipc	a0,0x14
    800023e0:	a6c50513          	addi	a0,a0,-1428 # 80015e48 <itable>
    800023e4:	47c030ef          	jal	80005860 <release>
}
    800023e8:	854e                	mv	a0,s3
    800023ea:	70a2                	ld	ra,40(sp)
    800023ec:	7402                	ld	s0,32(sp)
    800023ee:	64e2                	ld	s1,24(sp)
    800023f0:	6942                	ld	s2,16(sp)
    800023f2:	69a2                	ld	s3,8(sp)
    800023f4:	6a02                	ld	s4,0(sp)
    800023f6:	6145                	addi	sp,sp,48
    800023f8:	8082                	ret
    panic("iget: no inodes");
    800023fa:	00005517          	auipc	a0,0x5
    800023fe:	05650513          	addi	a0,a0,86 # 80007450 <etext+0x450>
    80002402:	08c030ef          	jal	8000548e <panic>

0000000080002406 <fsinit>:
fsinit(int dev) {
    80002406:	1101                	addi	sp,sp,-32
    80002408:	ec06                	sd	ra,24(sp)
    8000240a:	e822                	sd	s0,16(sp)
    8000240c:	e426                	sd	s1,8(sp)
    8000240e:	e04a                	sd	s2,0(sp)
    80002410:	1000                	addi	s0,sp,32
    80002412:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002414:	4585                	li	a1,1
    80002416:	b21ff0ef          	jal	80001f36 <bread>
    8000241a:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000241c:	02000613          	li	a2,32
    80002420:	05850593          	addi	a1,a0,88
    80002424:	00014517          	auipc	a0,0x14
    80002428:	a0450513          	addi	a0,a0,-1532 # 80015e28 <sb>
    8000242c:	d93fd0ef          	jal	800001be <memmove>
  brelse(bp);
    80002430:	8526                	mv	a0,s1
    80002432:	c0dff0ef          	jal	8000203e <brelse>
  if(sb.magic != FSMAGIC)
    80002436:	00014717          	auipc	a4,0x14
    8000243a:	9f272703          	lw	a4,-1550(a4) # 80015e28 <sb>
    8000243e:	102037b7          	lui	a5,0x10203
    80002442:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002446:	00f71f63          	bne	a4,a5,80002464 <fsinit+0x5e>
  initlog(dev, &sb);
    8000244a:	00014597          	auipc	a1,0x14
    8000244e:	9de58593          	addi	a1,a1,-1570 # 80015e28 <sb>
    80002452:	854a                	mv	a0,s2
    80002454:	219000ef          	jal	80002e6c <initlog>
}
    80002458:	60e2                	ld	ra,24(sp)
    8000245a:	6442                	ld	s0,16(sp)
    8000245c:	64a2                	ld	s1,8(sp)
    8000245e:	6902                	ld	s2,0(sp)
    80002460:	6105                	addi	sp,sp,32
    80002462:	8082                	ret
    panic("invalid file system");
    80002464:	00005517          	auipc	a0,0x5
    80002468:	ffc50513          	addi	a0,a0,-4 # 80007460 <etext+0x460>
    8000246c:	022030ef          	jal	8000548e <panic>

0000000080002470 <iinit>:
{
    80002470:	7179                	addi	sp,sp,-48
    80002472:	f406                	sd	ra,40(sp)
    80002474:	f022                	sd	s0,32(sp)
    80002476:	ec26                	sd	s1,24(sp)
    80002478:	e84a                	sd	s2,16(sp)
    8000247a:	e44e                	sd	s3,8(sp)
    8000247c:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000247e:	00005597          	auipc	a1,0x5
    80002482:	ffa58593          	addi	a1,a1,-6 # 80007478 <etext+0x478>
    80002486:	00014517          	auipc	a0,0x14
    8000248a:	9c250513          	addi	a0,a0,-1598 # 80015e48 <itable>
    8000248e:	2b4030ef          	jal	80005742 <initlock>
  for(i = 0; i < NINODE; i++) {
    80002492:	00014497          	auipc	s1,0x14
    80002496:	9de48493          	addi	s1,s1,-1570 # 80015e70 <itable+0x28>
    8000249a:	00015997          	auipc	s3,0x15
    8000249e:	46698993          	addi	s3,s3,1126 # 80017900 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800024a2:	00005917          	auipc	s2,0x5
    800024a6:	fde90913          	addi	s2,s2,-34 # 80007480 <etext+0x480>
    800024aa:	85ca                	mv	a1,s2
    800024ac:	8526                	mv	a0,s1
    800024ae:	4af000ef          	jal	8000315c <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800024b2:	08848493          	addi	s1,s1,136
    800024b6:	ff349ae3          	bne	s1,s3,800024aa <iinit+0x3a>
}
    800024ba:	70a2                	ld	ra,40(sp)
    800024bc:	7402                	ld	s0,32(sp)
    800024be:	64e2                	ld	s1,24(sp)
    800024c0:	6942                	ld	s2,16(sp)
    800024c2:	69a2                	ld	s3,8(sp)
    800024c4:	6145                	addi	sp,sp,48
    800024c6:	8082                	ret

00000000800024c8 <ialloc>:
{
    800024c8:	7139                	addi	sp,sp,-64
    800024ca:	fc06                	sd	ra,56(sp)
    800024cc:	f822                	sd	s0,48(sp)
    800024ce:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    800024d0:	00014717          	auipc	a4,0x14
    800024d4:	96472703          	lw	a4,-1692(a4) # 80015e34 <sb+0xc>
    800024d8:	4785                	li	a5,1
    800024da:	06e7f063          	bgeu	a5,a4,8000253a <ialloc+0x72>
    800024de:	f426                	sd	s1,40(sp)
    800024e0:	f04a                	sd	s2,32(sp)
    800024e2:	ec4e                	sd	s3,24(sp)
    800024e4:	e852                	sd	s4,16(sp)
    800024e6:	e456                	sd	s5,8(sp)
    800024e8:	e05a                	sd	s6,0(sp)
    800024ea:	8aaa                	mv	s5,a0
    800024ec:	8b2e                	mv	s6,a1
    800024ee:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    800024f0:	00014a17          	auipc	s4,0x14
    800024f4:	938a0a13          	addi	s4,s4,-1736 # 80015e28 <sb>
    800024f8:	00495593          	srli	a1,s2,0x4
    800024fc:	018a2783          	lw	a5,24(s4)
    80002500:	9dbd                	addw	a1,a1,a5
    80002502:	8556                	mv	a0,s5
    80002504:	a33ff0ef          	jal	80001f36 <bread>
    80002508:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    8000250a:	05850993          	addi	s3,a0,88
    8000250e:	00f97793          	andi	a5,s2,15
    80002512:	079a                	slli	a5,a5,0x6
    80002514:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002516:	00099783          	lh	a5,0(s3)
    8000251a:	cb9d                	beqz	a5,80002550 <ialloc+0x88>
    brelse(bp);
    8000251c:	b23ff0ef          	jal	8000203e <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80002520:	0905                	addi	s2,s2,1
    80002522:	00ca2703          	lw	a4,12(s4)
    80002526:	0009079b          	sext.w	a5,s2
    8000252a:	fce7e7e3          	bltu	a5,a4,800024f8 <ialloc+0x30>
    8000252e:	74a2                	ld	s1,40(sp)
    80002530:	7902                	ld	s2,32(sp)
    80002532:	69e2                	ld	s3,24(sp)
    80002534:	6a42                	ld	s4,16(sp)
    80002536:	6aa2                	ld	s5,8(sp)
    80002538:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    8000253a:	00005517          	auipc	a0,0x5
    8000253e:	f4e50513          	addi	a0,a0,-178 # 80007488 <etext+0x488>
    80002542:	43d020ef          	jal	8000517e <printf>
  return 0;
    80002546:	4501                	li	a0,0
}
    80002548:	70e2                	ld	ra,56(sp)
    8000254a:	7442                	ld	s0,48(sp)
    8000254c:	6121                	addi	sp,sp,64
    8000254e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80002550:	04000613          	li	a2,64
    80002554:	4581                	li	a1,0
    80002556:	854e                	mv	a0,s3
    80002558:	c07fd0ef          	jal	8000015e <memset>
      dip->type = type;
    8000255c:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80002560:	8526                	mv	a0,s1
    80002562:	329000ef          	jal	8000308a <log_write>
      brelse(bp);
    80002566:	8526                	mv	a0,s1
    80002568:	ad7ff0ef          	jal	8000203e <brelse>
      return iget(dev, inum);
    8000256c:	0009059b          	sext.w	a1,s2
    80002570:	8556                	mv	a0,s5
    80002572:	debff0ef          	jal	8000235c <iget>
    80002576:	74a2                	ld	s1,40(sp)
    80002578:	7902                	ld	s2,32(sp)
    8000257a:	69e2                	ld	s3,24(sp)
    8000257c:	6a42                	ld	s4,16(sp)
    8000257e:	6aa2                	ld	s5,8(sp)
    80002580:	6b02                	ld	s6,0(sp)
    80002582:	b7d9                	j	80002548 <ialloc+0x80>

0000000080002584 <iupdate>:
{
    80002584:	1101                	addi	sp,sp,-32
    80002586:	ec06                	sd	ra,24(sp)
    80002588:	e822                	sd	s0,16(sp)
    8000258a:	e426                	sd	s1,8(sp)
    8000258c:	e04a                	sd	s2,0(sp)
    8000258e:	1000                	addi	s0,sp,32
    80002590:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002592:	415c                	lw	a5,4(a0)
    80002594:	0047d79b          	srliw	a5,a5,0x4
    80002598:	00014597          	auipc	a1,0x14
    8000259c:	8a85a583          	lw	a1,-1880(a1) # 80015e40 <sb+0x18>
    800025a0:	9dbd                	addw	a1,a1,a5
    800025a2:	4108                	lw	a0,0(a0)
    800025a4:	993ff0ef          	jal	80001f36 <bread>
    800025a8:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800025aa:	05850793          	addi	a5,a0,88
    800025ae:	40d8                	lw	a4,4(s1)
    800025b0:	8b3d                	andi	a4,a4,15
    800025b2:	071a                	slli	a4,a4,0x6
    800025b4:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800025b6:	04449703          	lh	a4,68(s1)
    800025ba:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800025be:	04649703          	lh	a4,70(s1)
    800025c2:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800025c6:	04849703          	lh	a4,72(s1)
    800025ca:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800025ce:	04a49703          	lh	a4,74(s1)
    800025d2:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800025d6:	44f8                	lw	a4,76(s1)
    800025d8:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800025da:	03400613          	li	a2,52
    800025de:	05048593          	addi	a1,s1,80
    800025e2:	00c78513          	addi	a0,a5,12
    800025e6:	bd9fd0ef          	jal	800001be <memmove>
  log_write(bp);
    800025ea:	854a                	mv	a0,s2
    800025ec:	29f000ef          	jal	8000308a <log_write>
  brelse(bp);
    800025f0:	854a                	mv	a0,s2
    800025f2:	a4dff0ef          	jal	8000203e <brelse>
}
    800025f6:	60e2                	ld	ra,24(sp)
    800025f8:	6442                	ld	s0,16(sp)
    800025fa:	64a2                	ld	s1,8(sp)
    800025fc:	6902                	ld	s2,0(sp)
    800025fe:	6105                	addi	sp,sp,32
    80002600:	8082                	ret

0000000080002602 <idup>:
{
    80002602:	1101                	addi	sp,sp,-32
    80002604:	ec06                	sd	ra,24(sp)
    80002606:	e822                	sd	s0,16(sp)
    80002608:	e426                	sd	s1,8(sp)
    8000260a:	1000                	addi	s0,sp,32
    8000260c:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000260e:	00014517          	auipc	a0,0x14
    80002612:	83a50513          	addi	a0,a0,-1990 # 80015e48 <itable>
    80002616:	1b6030ef          	jal	800057cc <acquire>
  ip->ref++;
    8000261a:	449c                	lw	a5,8(s1)
    8000261c:	2785                	addiw	a5,a5,1
    8000261e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002620:	00014517          	auipc	a0,0x14
    80002624:	82850513          	addi	a0,a0,-2008 # 80015e48 <itable>
    80002628:	238030ef          	jal	80005860 <release>
}
    8000262c:	8526                	mv	a0,s1
    8000262e:	60e2                	ld	ra,24(sp)
    80002630:	6442                	ld	s0,16(sp)
    80002632:	64a2                	ld	s1,8(sp)
    80002634:	6105                	addi	sp,sp,32
    80002636:	8082                	ret

0000000080002638 <ilock>:
{
    80002638:	1101                	addi	sp,sp,-32
    8000263a:	ec06                	sd	ra,24(sp)
    8000263c:	e822                	sd	s0,16(sp)
    8000263e:	e426                	sd	s1,8(sp)
    80002640:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80002642:	cd19                	beqz	a0,80002660 <ilock+0x28>
    80002644:	84aa                	mv	s1,a0
    80002646:	451c                	lw	a5,8(a0)
    80002648:	00f05c63          	blez	a5,80002660 <ilock+0x28>
  acquiresleep(&ip->lock);
    8000264c:	0541                	addi	a0,a0,16
    8000264e:	345000ef          	jal	80003192 <acquiresleep>
  if(ip->valid == 0){
    80002652:	40bc                	lw	a5,64(s1)
    80002654:	cf89                	beqz	a5,8000266e <ilock+0x36>
}
    80002656:	60e2                	ld	ra,24(sp)
    80002658:	6442                	ld	s0,16(sp)
    8000265a:	64a2                	ld	s1,8(sp)
    8000265c:	6105                	addi	sp,sp,32
    8000265e:	8082                	ret
    80002660:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80002662:	00005517          	auipc	a0,0x5
    80002666:	e3e50513          	addi	a0,a0,-450 # 800074a0 <etext+0x4a0>
    8000266a:	625020ef          	jal	8000548e <panic>
    8000266e:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002670:	40dc                	lw	a5,4(s1)
    80002672:	0047d79b          	srliw	a5,a5,0x4
    80002676:	00013597          	auipc	a1,0x13
    8000267a:	7ca5a583          	lw	a1,1994(a1) # 80015e40 <sb+0x18>
    8000267e:	9dbd                	addw	a1,a1,a5
    80002680:	4088                	lw	a0,0(s1)
    80002682:	8b5ff0ef          	jal	80001f36 <bread>
    80002686:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80002688:	05850593          	addi	a1,a0,88
    8000268c:	40dc                	lw	a5,4(s1)
    8000268e:	8bbd                	andi	a5,a5,15
    80002690:	079a                	slli	a5,a5,0x6
    80002692:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80002694:	00059783          	lh	a5,0(a1)
    80002698:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000269c:	00259783          	lh	a5,2(a1)
    800026a0:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800026a4:	00459783          	lh	a5,4(a1)
    800026a8:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800026ac:	00659783          	lh	a5,6(a1)
    800026b0:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800026b4:	459c                	lw	a5,8(a1)
    800026b6:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800026b8:	03400613          	li	a2,52
    800026bc:	05b1                	addi	a1,a1,12
    800026be:	05048513          	addi	a0,s1,80
    800026c2:	afdfd0ef          	jal	800001be <memmove>
    brelse(bp);
    800026c6:	854a                	mv	a0,s2
    800026c8:	977ff0ef          	jal	8000203e <brelse>
    ip->valid = 1;
    800026cc:	4785                	li	a5,1
    800026ce:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800026d0:	04449783          	lh	a5,68(s1)
    800026d4:	c399                	beqz	a5,800026da <ilock+0xa2>
    800026d6:	6902                	ld	s2,0(sp)
    800026d8:	bfbd                	j	80002656 <ilock+0x1e>
      panic("ilock: no type");
    800026da:	00005517          	auipc	a0,0x5
    800026de:	dce50513          	addi	a0,a0,-562 # 800074a8 <etext+0x4a8>
    800026e2:	5ad020ef          	jal	8000548e <panic>

00000000800026e6 <iunlock>:
{
    800026e6:	1101                	addi	sp,sp,-32
    800026e8:	ec06                	sd	ra,24(sp)
    800026ea:	e822                	sd	s0,16(sp)
    800026ec:	e426                	sd	s1,8(sp)
    800026ee:	e04a                	sd	s2,0(sp)
    800026f0:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800026f2:	c505                	beqz	a0,8000271a <iunlock+0x34>
    800026f4:	84aa                	mv	s1,a0
    800026f6:	01050913          	addi	s2,a0,16
    800026fa:	854a                	mv	a0,s2
    800026fc:	315000ef          	jal	80003210 <holdingsleep>
    80002700:	cd09                	beqz	a0,8000271a <iunlock+0x34>
    80002702:	449c                	lw	a5,8(s1)
    80002704:	00f05b63          	blez	a5,8000271a <iunlock+0x34>
  releasesleep(&ip->lock);
    80002708:	854a                	mv	a0,s2
    8000270a:	2cf000ef          	jal	800031d8 <releasesleep>
}
    8000270e:	60e2                	ld	ra,24(sp)
    80002710:	6442                	ld	s0,16(sp)
    80002712:	64a2                	ld	s1,8(sp)
    80002714:	6902                	ld	s2,0(sp)
    80002716:	6105                	addi	sp,sp,32
    80002718:	8082                	ret
    panic("iunlock");
    8000271a:	00005517          	auipc	a0,0x5
    8000271e:	d9e50513          	addi	a0,a0,-610 # 800074b8 <etext+0x4b8>
    80002722:	56d020ef          	jal	8000548e <panic>

0000000080002726 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80002726:	7179                	addi	sp,sp,-48
    80002728:	f406                	sd	ra,40(sp)
    8000272a:	f022                	sd	s0,32(sp)
    8000272c:	ec26                	sd	s1,24(sp)
    8000272e:	e84a                	sd	s2,16(sp)
    80002730:	e44e                	sd	s3,8(sp)
    80002732:	1800                	addi	s0,sp,48
    80002734:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80002736:	05050493          	addi	s1,a0,80
    8000273a:	08050913          	addi	s2,a0,128
    8000273e:	a021                	j	80002746 <itrunc+0x20>
    80002740:	0491                	addi	s1,s1,4
    80002742:	01248b63          	beq	s1,s2,80002758 <itrunc+0x32>
    if(ip->addrs[i]){
    80002746:	408c                	lw	a1,0(s1)
    80002748:	dde5                	beqz	a1,80002740 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000274a:	0009a503          	lw	a0,0(s3)
    8000274e:	9ddff0ef          	jal	8000212a <bfree>
      ip->addrs[i] = 0;
    80002752:	0004a023          	sw	zero,0(s1)
    80002756:	b7ed                	j	80002740 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80002758:	0809a583          	lw	a1,128(s3)
    8000275c:	ed89                	bnez	a1,80002776 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000275e:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80002762:	854e                	mv	a0,s3
    80002764:	e21ff0ef          	jal	80002584 <iupdate>
}
    80002768:	70a2                	ld	ra,40(sp)
    8000276a:	7402                	ld	s0,32(sp)
    8000276c:	64e2                	ld	s1,24(sp)
    8000276e:	6942                	ld	s2,16(sp)
    80002770:	69a2                	ld	s3,8(sp)
    80002772:	6145                	addi	sp,sp,48
    80002774:	8082                	ret
    80002776:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80002778:	0009a503          	lw	a0,0(s3)
    8000277c:	fbaff0ef          	jal	80001f36 <bread>
    80002780:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80002782:	05850493          	addi	s1,a0,88
    80002786:	45850913          	addi	s2,a0,1112
    8000278a:	a021                	j	80002792 <itrunc+0x6c>
    8000278c:	0491                	addi	s1,s1,4
    8000278e:	01248963          	beq	s1,s2,800027a0 <itrunc+0x7a>
      if(a[j])
    80002792:	408c                	lw	a1,0(s1)
    80002794:	dde5                	beqz	a1,8000278c <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80002796:	0009a503          	lw	a0,0(s3)
    8000279a:	991ff0ef          	jal	8000212a <bfree>
    8000279e:	b7fd                	j	8000278c <itrunc+0x66>
    brelse(bp);
    800027a0:	8552                	mv	a0,s4
    800027a2:	89dff0ef          	jal	8000203e <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800027a6:	0809a583          	lw	a1,128(s3)
    800027aa:	0009a503          	lw	a0,0(s3)
    800027ae:	97dff0ef          	jal	8000212a <bfree>
    ip->addrs[NDIRECT] = 0;
    800027b2:	0809a023          	sw	zero,128(s3)
    800027b6:	6a02                	ld	s4,0(sp)
    800027b8:	b75d                	j	8000275e <itrunc+0x38>

00000000800027ba <iput>:
{
    800027ba:	1101                	addi	sp,sp,-32
    800027bc:	ec06                	sd	ra,24(sp)
    800027be:	e822                	sd	s0,16(sp)
    800027c0:	e426                	sd	s1,8(sp)
    800027c2:	1000                	addi	s0,sp,32
    800027c4:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800027c6:	00013517          	auipc	a0,0x13
    800027ca:	68250513          	addi	a0,a0,1666 # 80015e48 <itable>
    800027ce:	7ff020ef          	jal	800057cc <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800027d2:	4498                	lw	a4,8(s1)
    800027d4:	4785                	li	a5,1
    800027d6:	02f70063          	beq	a4,a5,800027f6 <iput+0x3c>
  ip->ref--;
    800027da:	449c                	lw	a5,8(s1)
    800027dc:	37fd                	addiw	a5,a5,-1
    800027de:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800027e0:	00013517          	auipc	a0,0x13
    800027e4:	66850513          	addi	a0,a0,1640 # 80015e48 <itable>
    800027e8:	078030ef          	jal	80005860 <release>
}
    800027ec:	60e2                	ld	ra,24(sp)
    800027ee:	6442                	ld	s0,16(sp)
    800027f0:	64a2                	ld	s1,8(sp)
    800027f2:	6105                	addi	sp,sp,32
    800027f4:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800027f6:	40bc                	lw	a5,64(s1)
    800027f8:	d3ed                	beqz	a5,800027da <iput+0x20>
    800027fa:	04a49783          	lh	a5,74(s1)
    800027fe:	fff1                	bnez	a5,800027da <iput+0x20>
    80002800:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80002802:	01048793          	addi	a5,s1,16
    80002806:	893e                	mv	s2,a5
    80002808:	853e                	mv	a0,a5
    8000280a:	189000ef          	jal	80003192 <acquiresleep>
    release(&itable.lock);
    8000280e:	00013517          	auipc	a0,0x13
    80002812:	63a50513          	addi	a0,a0,1594 # 80015e48 <itable>
    80002816:	04a030ef          	jal	80005860 <release>
    itrunc(ip);
    8000281a:	8526                	mv	a0,s1
    8000281c:	f0bff0ef          	jal	80002726 <itrunc>
    ip->type = 0;
    80002820:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002824:	8526                	mv	a0,s1
    80002826:	d5fff0ef          	jal	80002584 <iupdate>
    ip->valid = 0;
    8000282a:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000282e:	854a                	mv	a0,s2
    80002830:	1a9000ef          	jal	800031d8 <releasesleep>
    acquire(&itable.lock);
    80002834:	00013517          	auipc	a0,0x13
    80002838:	61450513          	addi	a0,a0,1556 # 80015e48 <itable>
    8000283c:	791020ef          	jal	800057cc <acquire>
    80002840:	6902                	ld	s2,0(sp)
    80002842:	bf61                	j	800027da <iput+0x20>

0000000080002844 <iunlockput>:
{
    80002844:	1101                	addi	sp,sp,-32
    80002846:	ec06                	sd	ra,24(sp)
    80002848:	e822                	sd	s0,16(sp)
    8000284a:	e426                	sd	s1,8(sp)
    8000284c:	1000                	addi	s0,sp,32
    8000284e:	84aa                	mv	s1,a0
  iunlock(ip);
    80002850:	e97ff0ef          	jal	800026e6 <iunlock>
  iput(ip);
    80002854:	8526                	mv	a0,s1
    80002856:	f65ff0ef          	jal	800027ba <iput>
}
    8000285a:	60e2                	ld	ra,24(sp)
    8000285c:	6442                	ld	s0,16(sp)
    8000285e:	64a2                	ld	s1,8(sp)
    80002860:	6105                	addi	sp,sp,32
    80002862:	8082                	ret

0000000080002864 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002864:	1141                	addi	sp,sp,-16
    80002866:	e406                	sd	ra,8(sp)
    80002868:	e022                	sd	s0,0(sp)
    8000286a:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    8000286c:	411c                	lw	a5,0(a0)
    8000286e:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002870:	415c                	lw	a5,4(a0)
    80002872:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002874:	04451783          	lh	a5,68(a0)
    80002878:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    8000287c:	04a51783          	lh	a5,74(a0)
    80002880:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002884:	04c56783          	lwu	a5,76(a0)
    80002888:	e99c                	sd	a5,16(a1)
}
    8000288a:	60a2                	ld	ra,8(sp)
    8000288c:	6402                	ld	s0,0(sp)
    8000288e:	0141                	addi	sp,sp,16
    80002890:	8082                	ret

0000000080002892 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002892:	457c                	lw	a5,76(a0)
    80002894:	0ed7e663          	bltu	a5,a3,80002980 <readi+0xee>
{
    80002898:	7159                	addi	sp,sp,-112
    8000289a:	f486                	sd	ra,104(sp)
    8000289c:	f0a2                	sd	s0,96(sp)
    8000289e:	eca6                	sd	s1,88(sp)
    800028a0:	e0d2                	sd	s4,64(sp)
    800028a2:	fc56                	sd	s5,56(sp)
    800028a4:	f85a                	sd	s6,48(sp)
    800028a6:	f45e                	sd	s7,40(sp)
    800028a8:	1880                	addi	s0,sp,112
    800028aa:	8b2a                	mv	s6,a0
    800028ac:	8bae                	mv	s7,a1
    800028ae:	8a32                	mv	s4,a2
    800028b0:	84b6                	mv	s1,a3
    800028b2:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800028b4:	9f35                	addw	a4,a4,a3
    return 0;
    800028b6:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800028b8:	0ad76b63          	bltu	a4,a3,8000296e <readi+0xdc>
    800028bc:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    800028be:	00e7f463          	bgeu	a5,a4,800028c6 <readi+0x34>
    n = ip->size - off;
    800028c2:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800028c6:	080a8b63          	beqz	s5,8000295c <readi+0xca>
    800028ca:	e8ca                	sd	s2,80(sp)
    800028cc:	f062                	sd	s8,32(sp)
    800028ce:	ec66                	sd	s9,24(sp)
    800028d0:	e86a                	sd	s10,16(sp)
    800028d2:	e46e                	sd	s11,8(sp)
    800028d4:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800028d6:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800028da:	5c7d                	li	s8,-1
    800028dc:	a80d                	j	8000290e <readi+0x7c>
    800028de:	020d1d93          	slli	s11,s10,0x20
    800028e2:	020ddd93          	srli	s11,s11,0x20
    800028e6:	05890613          	addi	a2,s2,88
    800028ea:	86ee                	mv	a3,s11
    800028ec:	963e                	add	a2,a2,a5
    800028ee:	85d2                	mv	a1,s4
    800028f0:	855e                	mv	a0,s7
    800028f2:	dbdfe0ef          	jal	800016ae <either_copyout>
    800028f6:	05850363          	beq	a0,s8,8000293c <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800028fa:	854a                	mv	a0,s2
    800028fc:	f42ff0ef          	jal	8000203e <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002900:	013d09bb          	addw	s3,s10,s3
    80002904:	009d04bb          	addw	s1,s10,s1
    80002908:	9a6e                	add	s4,s4,s11
    8000290a:	0559f363          	bgeu	s3,s5,80002950 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    8000290e:	00a4d59b          	srliw	a1,s1,0xa
    80002912:	855a                	mv	a0,s6
    80002914:	989ff0ef          	jal	8000229c <bmap>
    80002918:	85aa                	mv	a1,a0
    if(addr == 0)
    8000291a:	c139                	beqz	a0,80002960 <readi+0xce>
    bp = bread(ip->dev, addr);
    8000291c:	000b2503          	lw	a0,0(s6)
    80002920:	e16ff0ef          	jal	80001f36 <bread>
    80002924:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002926:	3ff4f793          	andi	a5,s1,1023
    8000292a:	40fc873b          	subw	a4,s9,a5
    8000292e:	413a86bb          	subw	a3,s5,s3
    80002932:	8d3a                	mv	s10,a4
    80002934:	fae6f5e3          	bgeu	a3,a4,800028de <readi+0x4c>
    80002938:	8d36                	mv	s10,a3
    8000293a:	b755                	j	800028de <readi+0x4c>
      brelse(bp);
    8000293c:	854a                	mv	a0,s2
    8000293e:	f00ff0ef          	jal	8000203e <brelse>
      tot = -1;
    80002942:	59fd                	li	s3,-1
      break;
    80002944:	6946                	ld	s2,80(sp)
    80002946:	7c02                	ld	s8,32(sp)
    80002948:	6ce2                	ld	s9,24(sp)
    8000294a:	6d42                	ld	s10,16(sp)
    8000294c:	6da2                	ld	s11,8(sp)
    8000294e:	a831                	j	8000296a <readi+0xd8>
    80002950:	6946                	ld	s2,80(sp)
    80002952:	7c02                	ld	s8,32(sp)
    80002954:	6ce2                	ld	s9,24(sp)
    80002956:	6d42                	ld	s10,16(sp)
    80002958:	6da2                	ld	s11,8(sp)
    8000295a:	a801                	j	8000296a <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000295c:	89d6                	mv	s3,s5
    8000295e:	a031                	j	8000296a <readi+0xd8>
    80002960:	6946                	ld	s2,80(sp)
    80002962:	7c02                	ld	s8,32(sp)
    80002964:	6ce2                	ld	s9,24(sp)
    80002966:	6d42                	ld	s10,16(sp)
    80002968:	6da2                	ld	s11,8(sp)
  }
  return tot;
    8000296a:	854e                	mv	a0,s3
    8000296c:	69a6                	ld	s3,72(sp)
}
    8000296e:	70a6                	ld	ra,104(sp)
    80002970:	7406                	ld	s0,96(sp)
    80002972:	64e6                	ld	s1,88(sp)
    80002974:	6a06                	ld	s4,64(sp)
    80002976:	7ae2                	ld	s5,56(sp)
    80002978:	7b42                	ld	s6,48(sp)
    8000297a:	7ba2                	ld	s7,40(sp)
    8000297c:	6165                	addi	sp,sp,112
    8000297e:	8082                	ret
    return 0;
    80002980:	4501                	li	a0,0
}
    80002982:	8082                	ret

0000000080002984 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002984:	457c                	lw	a5,76(a0)
    80002986:	0ed7eb63          	bltu	a5,a3,80002a7c <writei+0xf8>
{
    8000298a:	7159                	addi	sp,sp,-112
    8000298c:	f486                	sd	ra,104(sp)
    8000298e:	f0a2                	sd	s0,96(sp)
    80002990:	e8ca                	sd	s2,80(sp)
    80002992:	e0d2                	sd	s4,64(sp)
    80002994:	fc56                	sd	s5,56(sp)
    80002996:	f85a                	sd	s6,48(sp)
    80002998:	f45e                	sd	s7,40(sp)
    8000299a:	1880                	addi	s0,sp,112
    8000299c:	8aaa                	mv	s5,a0
    8000299e:	8bae                	mv	s7,a1
    800029a0:	8a32                	mv	s4,a2
    800029a2:	8936                	mv	s2,a3
    800029a4:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800029a6:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800029aa:	00043737          	lui	a4,0x43
    800029ae:	0cf76963          	bltu	a4,a5,80002a80 <writei+0xfc>
    800029b2:	0cd7e763          	bltu	a5,a3,80002a80 <writei+0xfc>
    800029b6:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800029b8:	0a0b0a63          	beqz	s6,80002a6c <writei+0xe8>
    800029bc:	eca6                	sd	s1,88(sp)
    800029be:	f062                	sd	s8,32(sp)
    800029c0:	ec66                	sd	s9,24(sp)
    800029c2:	e86a                	sd	s10,16(sp)
    800029c4:	e46e                	sd	s11,8(sp)
    800029c6:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800029c8:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800029cc:	5c7d                	li	s8,-1
    800029ce:	a825                	j	80002a06 <writei+0x82>
    800029d0:	020d1d93          	slli	s11,s10,0x20
    800029d4:	020ddd93          	srli	s11,s11,0x20
    800029d8:	05848513          	addi	a0,s1,88
    800029dc:	86ee                	mv	a3,s11
    800029de:	8652                	mv	a2,s4
    800029e0:	85de                	mv	a1,s7
    800029e2:	953e                	add	a0,a0,a5
    800029e4:	d15fe0ef          	jal	800016f8 <either_copyin>
    800029e8:	05850663          	beq	a0,s8,80002a34 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    800029ec:	8526                	mv	a0,s1
    800029ee:	69c000ef          	jal	8000308a <log_write>
    brelse(bp);
    800029f2:	8526                	mv	a0,s1
    800029f4:	e4aff0ef          	jal	8000203e <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800029f8:	013d09bb          	addw	s3,s10,s3
    800029fc:	012d093b          	addw	s2,s10,s2
    80002a00:	9a6e                	add	s4,s4,s11
    80002a02:	0369fc63          	bgeu	s3,s6,80002a3a <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80002a06:	00a9559b          	srliw	a1,s2,0xa
    80002a0a:	8556                	mv	a0,s5
    80002a0c:	891ff0ef          	jal	8000229c <bmap>
    80002a10:	85aa                	mv	a1,a0
    if(addr == 0)
    80002a12:	c505                	beqz	a0,80002a3a <writei+0xb6>
    bp = bread(ip->dev, addr);
    80002a14:	000aa503          	lw	a0,0(s5)
    80002a18:	d1eff0ef          	jal	80001f36 <bread>
    80002a1c:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002a1e:	3ff97793          	andi	a5,s2,1023
    80002a22:	40fc873b          	subw	a4,s9,a5
    80002a26:	413b06bb          	subw	a3,s6,s3
    80002a2a:	8d3a                	mv	s10,a4
    80002a2c:	fae6f2e3          	bgeu	a3,a4,800029d0 <writei+0x4c>
    80002a30:	8d36                	mv	s10,a3
    80002a32:	bf79                	j	800029d0 <writei+0x4c>
      brelse(bp);
    80002a34:	8526                	mv	a0,s1
    80002a36:	e08ff0ef          	jal	8000203e <brelse>
  }

  if(off > ip->size)
    80002a3a:	04caa783          	lw	a5,76(s5)
    80002a3e:	0327f963          	bgeu	a5,s2,80002a70 <writei+0xec>
    ip->size = off;
    80002a42:	052aa623          	sw	s2,76(s5)
    80002a46:	64e6                	ld	s1,88(sp)
    80002a48:	7c02                	ld	s8,32(sp)
    80002a4a:	6ce2                	ld	s9,24(sp)
    80002a4c:	6d42                	ld	s10,16(sp)
    80002a4e:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002a50:	8556                	mv	a0,s5
    80002a52:	b33ff0ef          	jal	80002584 <iupdate>

  return tot;
    80002a56:	854e                	mv	a0,s3
    80002a58:	69a6                	ld	s3,72(sp)
}
    80002a5a:	70a6                	ld	ra,104(sp)
    80002a5c:	7406                	ld	s0,96(sp)
    80002a5e:	6946                	ld	s2,80(sp)
    80002a60:	6a06                	ld	s4,64(sp)
    80002a62:	7ae2                	ld	s5,56(sp)
    80002a64:	7b42                	ld	s6,48(sp)
    80002a66:	7ba2                	ld	s7,40(sp)
    80002a68:	6165                	addi	sp,sp,112
    80002a6a:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002a6c:	89da                	mv	s3,s6
    80002a6e:	b7cd                	j	80002a50 <writei+0xcc>
    80002a70:	64e6                	ld	s1,88(sp)
    80002a72:	7c02                	ld	s8,32(sp)
    80002a74:	6ce2                	ld	s9,24(sp)
    80002a76:	6d42                	ld	s10,16(sp)
    80002a78:	6da2                	ld	s11,8(sp)
    80002a7a:	bfd9                	j	80002a50 <writei+0xcc>
    return -1;
    80002a7c:	557d                	li	a0,-1
}
    80002a7e:	8082                	ret
    return -1;
    80002a80:	557d                	li	a0,-1
    80002a82:	bfe1                	j	80002a5a <writei+0xd6>

0000000080002a84 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002a84:	1141                	addi	sp,sp,-16
    80002a86:	e406                	sd	ra,8(sp)
    80002a88:	e022                	sd	s0,0(sp)
    80002a8a:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002a8c:	4639                	li	a2,14
    80002a8e:	fa4fd0ef          	jal	80000232 <strncmp>
}
    80002a92:	60a2                	ld	ra,8(sp)
    80002a94:	6402                	ld	s0,0(sp)
    80002a96:	0141                	addi	sp,sp,16
    80002a98:	8082                	ret

0000000080002a9a <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002a9a:	711d                	addi	sp,sp,-96
    80002a9c:	ec86                	sd	ra,88(sp)
    80002a9e:	e8a2                	sd	s0,80(sp)
    80002aa0:	e4a6                	sd	s1,72(sp)
    80002aa2:	e0ca                	sd	s2,64(sp)
    80002aa4:	fc4e                	sd	s3,56(sp)
    80002aa6:	f852                	sd	s4,48(sp)
    80002aa8:	f456                	sd	s5,40(sp)
    80002aaa:	f05a                	sd	s6,32(sp)
    80002aac:	ec5e                	sd	s7,24(sp)
    80002aae:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002ab0:	04451703          	lh	a4,68(a0)
    80002ab4:	4785                	li	a5,1
    80002ab6:	00f71f63          	bne	a4,a5,80002ad4 <dirlookup+0x3a>
    80002aba:	892a                	mv	s2,a0
    80002abc:	8aae                	mv	s5,a1
    80002abe:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ac0:	457c                	lw	a5,76(a0)
    80002ac2:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002ac4:	fa040a13          	addi	s4,s0,-96
    80002ac8:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80002aca:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002ace:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ad0:	e39d                	bnez	a5,80002af6 <dirlookup+0x5c>
    80002ad2:	a8b9                	j	80002b30 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80002ad4:	00005517          	auipc	a0,0x5
    80002ad8:	9ec50513          	addi	a0,a0,-1556 # 800074c0 <etext+0x4c0>
    80002adc:	1b3020ef          	jal	8000548e <panic>
      panic("dirlookup read");
    80002ae0:	00005517          	auipc	a0,0x5
    80002ae4:	9f850513          	addi	a0,a0,-1544 # 800074d8 <etext+0x4d8>
    80002ae8:	1a7020ef          	jal	8000548e <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002aec:	24c1                	addiw	s1,s1,16
    80002aee:	04c92783          	lw	a5,76(s2)
    80002af2:	02f4fe63          	bgeu	s1,a5,80002b2e <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002af6:	874e                	mv	a4,s3
    80002af8:	86a6                	mv	a3,s1
    80002afa:	8652                	mv	a2,s4
    80002afc:	4581                	li	a1,0
    80002afe:	854a                	mv	a0,s2
    80002b00:	d93ff0ef          	jal	80002892 <readi>
    80002b04:	fd351ee3          	bne	a0,s3,80002ae0 <dirlookup+0x46>
    if(de.inum == 0)
    80002b08:	fa045783          	lhu	a5,-96(s0)
    80002b0c:	d3e5                	beqz	a5,80002aec <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80002b0e:	85da                	mv	a1,s6
    80002b10:	8556                	mv	a0,s5
    80002b12:	f73ff0ef          	jal	80002a84 <namecmp>
    80002b16:	f979                	bnez	a0,80002aec <dirlookup+0x52>
      if(poff)
    80002b18:	000b8463          	beqz	s7,80002b20 <dirlookup+0x86>
        *poff = off;
    80002b1c:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80002b20:	fa045583          	lhu	a1,-96(s0)
    80002b24:	00092503          	lw	a0,0(s2)
    80002b28:	835ff0ef          	jal	8000235c <iget>
    80002b2c:	a011                	j	80002b30 <dirlookup+0x96>
  return 0;
    80002b2e:	4501                	li	a0,0
}
    80002b30:	60e6                	ld	ra,88(sp)
    80002b32:	6446                	ld	s0,80(sp)
    80002b34:	64a6                	ld	s1,72(sp)
    80002b36:	6906                	ld	s2,64(sp)
    80002b38:	79e2                	ld	s3,56(sp)
    80002b3a:	7a42                	ld	s4,48(sp)
    80002b3c:	7aa2                	ld	s5,40(sp)
    80002b3e:	7b02                	ld	s6,32(sp)
    80002b40:	6be2                	ld	s7,24(sp)
    80002b42:	6125                	addi	sp,sp,96
    80002b44:	8082                	ret

0000000080002b46 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002b46:	711d                	addi	sp,sp,-96
    80002b48:	ec86                	sd	ra,88(sp)
    80002b4a:	e8a2                	sd	s0,80(sp)
    80002b4c:	e4a6                	sd	s1,72(sp)
    80002b4e:	e0ca                	sd	s2,64(sp)
    80002b50:	fc4e                	sd	s3,56(sp)
    80002b52:	f852                	sd	s4,48(sp)
    80002b54:	f456                	sd	s5,40(sp)
    80002b56:	f05a                	sd	s6,32(sp)
    80002b58:	ec5e                	sd	s7,24(sp)
    80002b5a:	e862                	sd	s8,16(sp)
    80002b5c:	e466                	sd	s9,8(sp)
    80002b5e:	e06a                	sd	s10,0(sp)
    80002b60:	1080                	addi	s0,sp,96
    80002b62:	84aa                	mv	s1,a0
    80002b64:	8b2e                	mv	s6,a1
    80002b66:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002b68:	00054703          	lbu	a4,0(a0)
    80002b6c:	02f00793          	li	a5,47
    80002b70:	00f70f63          	beq	a4,a5,80002b8e <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002b74:	a0efe0ef          	jal	80000d82 <myproc>
    80002b78:	15053503          	ld	a0,336(a0)
    80002b7c:	a87ff0ef          	jal	80002602 <idup>
    80002b80:	8a2a                	mv	s4,a0
  while(*path == '/')
    80002b82:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80002b86:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80002b88:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002b8a:	4b85                	li	s7,1
    80002b8c:	a879                	j	80002c2a <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80002b8e:	4585                	li	a1,1
    80002b90:	852e                	mv	a0,a1
    80002b92:	fcaff0ef          	jal	8000235c <iget>
    80002b96:	8a2a                	mv	s4,a0
    80002b98:	b7ed                	j	80002b82 <namex+0x3c>
      iunlockput(ip);
    80002b9a:	8552                	mv	a0,s4
    80002b9c:	ca9ff0ef          	jal	80002844 <iunlockput>
      return 0;
    80002ba0:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002ba2:	8552                	mv	a0,s4
    80002ba4:	60e6                	ld	ra,88(sp)
    80002ba6:	6446                	ld	s0,80(sp)
    80002ba8:	64a6                	ld	s1,72(sp)
    80002baa:	6906                	ld	s2,64(sp)
    80002bac:	79e2                	ld	s3,56(sp)
    80002bae:	7a42                	ld	s4,48(sp)
    80002bb0:	7aa2                	ld	s5,40(sp)
    80002bb2:	7b02                	ld	s6,32(sp)
    80002bb4:	6be2                	ld	s7,24(sp)
    80002bb6:	6c42                	ld	s8,16(sp)
    80002bb8:	6ca2                	ld	s9,8(sp)
    80002bba:	6d02                	ld	s10,0(sp)
    80002bbc:	6125                	addi	sp,sp,96
    80002bbe:	8082                	ret
      iunlock(ip);
    80002bc0:	8552                	mv	a0,s4
    80002bc2:	b25ff0ef          	jal	800026e6 <iunlock>
      return ip;
    80002bc6:	bff1                	j	80002ba2 <namex+0x5c>
      iunlockput(ip);
    80002bc8:	8552                	mv	a0,s4
    80002bca:	c7bff0ef          	jal	80002844 <iunlockput>
      return 0;
    80002bce:	8a4a                	mv	s4,s2
    80002bd0:	bfc9                	j	80002ba2 <namex+0x5c>
  len = path - s;
    80002bd2:	40990633          	sub	a2,s2,s1
    80002bd6:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80002bda:	09ac5463          	bge	s8,s10,80002c62 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80002bde:	8666                	mv	a2,s9
    80002be0:	85a6                	mv	a1,s1
    80002be2:	8556                	mv	a0,s5
    80002be4:	ddafd0ef          	jal	800001be <memmove>
    80002be8:	84ca                	mv	s1,s2
  while(*path == '/')
    80002bea:	0004c783          	lbu	a5,0(s1)
    80002bee:	01379763          	bne	a5,s3,80002bfc <namex+0xb6>
    path++;
    80002bf2:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002bf4:	0004c783          	lbu	a5,0(s1)
    80002bf8:	ff378de3          	beq	a5,s3,80002bf2 <namex+0xac>
    ilock(ip);
    80002bfc:	8552                	mv	a0,s4
    80002bfe:	a3bff0ef          	jal	80002638 <ilock>
    if(ip->type != T_DIR){
    80002c02:	044a1783          	lh	a5,68(s4)
    80002c06:	f9779ae3          	bne	a5,s7,80002b9a <namex+0x54>
    if(nameiparent && *path == '\0'){
    80002c0a:	000b0563          	beqz	s6,80002c14 <namex+0xce>
    80002c0e:	0004c783          	lbu	a5,0(s1)
    80002c12:	d7dd                	beqz	a5,80002bc0 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002c14:	4601                	li	a2,0
    80002c16:	85d6                	mv	a1,s5
    80002c18:	8552                	mv	a0,s4
    80002c1a:	e81ff0ef          	jal	80002a9a <dirlookup>
    80002c1e:	892a                	mv	s2,a0
    80002c20:	d545                	beqz	a0,80002bc8 <namex+0x82>
    iunlockput(ip);
    80002c22:	8552                	mv	a0,s4
    80002c24:	c21ff0ef          	jal	80002844 <iunlockput>
    ip = next;
    80002c28:	8a4a                	mv	s4,s2
  while(*path == '/')
    80002c2a:	0004c783          	lbu	a5,0(s1)
    80002c2e:	01379763          	bne	a5,s3,80002c3c <namex+0xf6>
    path++;
    80002c32:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002c34:	0004c783          	lbu	a5,0(s1)
    80002c38:	ff378de3          	beq	a5,s3,80002c32 <namex+0xec>
  if(*path == 0)
    80002c3c:	cf8d                	beqz	a5,80002c76 <namex+0x130>
  while(*path != '/' && *path != 0)
    80002c3e:	0004c783          	lbu	a5,0(s1)
    80002c42:	fd178713          	addi	a4,a5,-47
    80002c46:	cb19                	beqz	a4,80002c5c <namex+0x116>
    80002c48:	cb91                	beqz	a5,80002c5c <namex+0x116>
    80002c4a:	8926                	mv	s2,s1
    path++;
    80002c4c:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80002c4e:	00094783          	lbu	a5,0(s2)
    80002c52:	fd178713          	addi	a4,a5,-47
    80002c56:	df35                	beqz	a4,80002bd2 <namex+0x8c>
    80002c58:	fbf5                	bnez	a5,80002c4c <namex+0x106>
    80002c5a:	bfa5                	j	80002bd2 <namex+0x8c>
    80002c5c:	8926                	mv	s2,s1
  len = path - s;
    80002c5e:	4d01                	li	s10,0
    80002c60:	4601                	li	a2,0
    memmove(name, s, len);
    80002c62:	2601                	sext.w	a2,a2
    80002c64:	85a6                	mv	a1,s1
    80002c66:	8556                	mv	a0,s5
    80002c68:	d56fd0ef          	jal	800001be <memmove>
    name[len] = 0;
    80002c6c:	9d56                	add	s10,s10,s5
    80002c6e:	000d0023          	sb	zero,0(s10)
    80002c72:	84ca                	mv	s1,s2
    80002c74:	bf9d                	j	80002bea <namex+0xa4>
  if(nameiparent){
    80002c76:	f20b06e3          	beqz	s6,80002ba2 <namex+0x5c>
    iput(ip);
    80002c7a:	8552                	mv	a0,s4
    80002c7c:	b3fff0ef          	jal	800027ba <iput>
    return 0;
    80002c80:	4a01                	li	s4,0
    80002c82:	b705                	j	80002ba2 <namex+0x5c>

0000000080002c84 <dirlink>:
{
    80002c84:	715d                	addi	sp,sp,-80
    80002c86:	e486                	sd	ra,72(sp)
    80002c88:	e0a2                	sd	s0,64(sp)
    80002c8a:	f84a                	sd	s2,48(sp)
    80002c8c:	ec56                	sd	s5,24(sp)
    80002c8e:	e85a                	sd	s6,16(sp)
    80002c90:	0880                	addi	s0,sp,80
    80002c92:	892a                	mv	s2,a0
    80002c94:	8aae                	mv	s5,a1
    80002c96:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002c98:	4601                	li	a2,0
    80002c9a:	e01ff0ef          	jal	80002a9a <dirlookup>
    80002c9e:	ed1d                	bnez	a0,80002cdc <dirlink+0x58>
    80002ca0:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ca2:	04c92483          	lw	s1,76(s2)
    80002ca6:	c4b9                	beqz	s1,80002cf4 <dirlink+0x70>
    80002ca8:	f44e                	sd	s3,40(sp)
    80002caa:	f052                	sd	s4,32(sp)
    80002cac:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002cae:	fb040a13          	addi	s4,s0,-80
    80002cb2:	49c1                	li	s3,16
    80002cb4:	874e                	mv	a4,s3
    80002cb6:	86a6                	mv	a3,s1
    80002cb8:	8652                	mv	a2,s4
    80002cba:	4581                	li	a1,0
    80002cbc:	854a                	mv	a0,s2
    80002cbe:	bd5ff0ef          	jal	80002892 <readi>
    80002cc2:	03351163          	bne	a0,s3,80002ce4 <dirlink+0x60>
    if(de.inum == 0)
    80002cc6:	fb045783          	lhu	a5,-80(s0)
    80002cca:	c39d                	beqz	a5,80002cf0 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ccc:	24c1                	addiw	s1,s1,16
    80002cce:	04c92783          	lw	a5,76(s2)
    80002cd2:	fef4e1e3          	bltu	s1,a5,80002cb4 <dirlink+0x30>
    80002cd6:	79a2                	ld	s3,40(sp)
    80002cd8:	7a02                	ld	s4,32(sp)
    80002cda:	a829                	j	80002cf4 <dirlink+0x70>
    iput(ip);
    80002cdc:	adfff0ef          	jal	800027ba <iput>
    return -1;
    80002ce0:	557d                	li	a0,-1
    80002ce2:	a83d                	j	80002d20 <dirlink+0x9c>
      panic("dirlink read");
    80002ce4:	00005517          	auipc	a0,0x5
    80002ce8:	80450513          	addi	a0,a0,-2044 # 800074e8 <etext+0x4e8>
    80002cec:	7a2020ef          	jal	8000548e <panic>
    80002cf0:	79a2                	ld	s3,40(sp)
    80002cf2:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80002cf4:	4639                	li	a2,14
    80002cf6:	85d6                	mv	a1,s5
    80002cf8:	fb240513          	addi	a0,s0,-78
    80002cfc:	d70fd0ef          	jal	8000026c <strncpy>
  de.inum = inum;
    80002d00:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d04:	4741                	li	a4,16
    80002d06:	86a6                	mv	a3,s1
    80002d08:	fb040613          	addi	a2,s0,-80
    80002d0c:	4581                	li	a1,0
    80002d0e:	854a                	mv	a0,s2
    80002d10:	c75ff0ef          	jal	80002984 <writei>
    80002d14:	1541                	addi	a0,a0,-16
    80002d16:	00a03533          	snez	a0,a0
    80002d1a:	40a0053b          	negw	a0,a0
    80002d1e:	74e2                	ld	s1,56(sp)
}
    80002d20:	60a6                	ld	ra,72(sp)
    80002d22:	6406                	ld	s0,64(sp)
    80002d24:	7942                	ld	s2,48(sp)
    80002d26:	6ae2                	ld	s5,24(sp)
    80002d28:	6b42                	ld	s6,16(sp)
    80002d2a:	6161                	addi	sp,sp,80
    80002d2c:	8082                	ret

0000000080002d2e <namei>:

struct inode*
namei(char *path)
{
    80002d2e:	1101                	addi	sp,sp,-32
    80002d30:	ec06                	sd	ra,24(sp)
    80002d32:	e822                	sd	s0,16(sp)
    80002d34:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002d36:	fe040613          	addi	a2,s0,-32
    80002d3a:	4581                	li	a1,0
    80002d3c:	e0bff0ef          	jal	80002b46 <namex>
}
    80002d40:	60e2                	ld	ra,24(sp)
    80002d42:	6442                	ld	s0,16(sp)
    80002d44:	6105                	addi	sp,sp,32
    80002d46:	8082                	ret

0000000080002d48 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002d48:	1141                	addi	sp,sp,-16
    80002d4a:	e406                	sd	ra,8(sp)
    80002d4c:	e022                	sd	s0,0(sp)
    80002d4e:	0800                	addi	s0,sp,16
    80002d50:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002d52:	4585                	li	a1,1
    80002d54:	df3ff0ef          	jal	80002b46 <namex>
}
    80002d58:	60a2                	ld	ra,8(sp)
    80002d5a:	6402                	ld	s0,0(sp)
    80002d5c:	0141                	addi	sp,sp,16
    80002d5e:	8082                	ret

0000000080002d60 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002d60:	1101                	addi	sp,sp,-32
    80002d62:	ec06                	sd	ra,24(sp)
    80002d64:	e822                	sd	s0,16(sp)
    80002d66:	e426                	sd	s1,8(sp)
    80002d68:	e04a                	sd	s2,0(sp)
    80002d6a:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002d6c:	00015917          	auipc	s2,0x15
    80002d70:	b8490913          	addi	s2,s2,-1148 # 800178f0 <log>
    80002d74:	01892583          	lw	a1,24(s2)
    80002d78:	02892503          	lw	a0,40(s2)
    80002d7c:	9baff0ef          	jal	80001f36 <bread>
    80002d80:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002d82:	02c92603          	lw	a2,44(s2)
    80002d86:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002d88:	00c05f63          	blez	a2,80002da6 <write_head+0x46>
    80002d8c:	00015717          	auipc	a4,0x15
    80002d90:	b9470713          	addi	a4,a4,-1132 # 80017920 <log+0x30>
    80002d94:	87aa                	mv	a5,a0
    80002d96:	060a                	slli	a2,a2,0x2
    80002d98:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80002d9a:	4314                	lw	a3,0(a4)
    80002d9c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80002d9e:	0711                	addi	a4,a4,4
    80002da0:	0791                	addi	a5,a5,4
    80002da2:	fec79ce3          	bne	a5,a2,80002d9a <write_head+0x3a>
  }
  bwrite(buf);
    80002da6:	8526                	mv	a0,s1
    80002da8:	a64ff0ef          	jal	8000200c <bwrite>
  brelse(buf);
    80002dac:	8526                	mv	a0,s1
    80002dae:	a90ff0ef          	jal	8000203e <brelse>
}
    80002db2:	60e2                	ld	ra,24(sp)
    80002db4:	6442                	ld	s0,16(sp)
    80002db6:	64a2                	ld	s1,8(sp)
    80002db8:	6902                	ld	s2,0(sp)
    80002dba:	6105                	addi	sp,sp,32
    80002dbc:	8082                	ret

0000000080002dbe <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80002dbe:	00015797          	auipc	a5,0x15
    80002dc2:	b5e7a783          	lw	a5,-1186(a5) # 8001791c <log+0x2c>
    80002dc6:	0af05263          	blez	a5,80002e6a <install_trans+0xac>
{
    80002dca:	715d                	addi	sp,sp,-80
    80002dcc:	e486                	sd	ra,72(sp)
    80002dce:	e0a2                	sd	s0,64(sp)
    80002dd0:	fc26                	sd	s1,56(sp)
    80002dd2:	f84a                	sd	s2,48(sp)
    80002dd4:	f44e                	sd	s3,40(sp)
    80002dd6:	f052                	sd	s4,32(sp)
    80002dd8:	ec56                	sd	s5,24(sp)
    80002dda:	e85a                	sd	s6,16(sp)
    80002ddc:	e45e                	sd	s7,8(sp)
    80002dde:	0880                	addi	s0,sp,80
    80002de0:	8b2a                	mv	s6,a0
    80002de2:	00015a97          	auipc	s5,0x15
    80002de6:	b3ea8a93          	addi	s5,s5,-1218 # 80017920 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002dea:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002dec:	00015997          	auipc	s3,0x15
    80002df0:	b0498993          	addi	s3,s3,-1276 # 800178f0 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80002df4:	40000b93          	li	s7,1024
    80002df8:	a829                	j	80002e12 <install_trans+0x54>
    brelse(lbuf);
    80002dfa:	854a                	mv	a0,s2
    80002dfc:	a42ff0ef          	jal	8000203e <brelse>
    brelse(dbuf);
    80002e00:	8526                	mv	a0,s1
    80002e02:	a3cff0ef          	jal	8000203e <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002e06:	2a05                	addiw	s4,s4,1
    80002e08:	0a91                	addi	s5,s5,4
    80002e0a:	02c9a783          	lw	a5,44(s3)
    80002e0e:	04fa5363          	bge	s4,a5,80002e54 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002e12:	0189a583          	lw	a1,24(s3)
    80002e16:	014585bb          	addw	a1,a1,s4
    80002e1a:	2585                	addiw	a1,a1,1
    80002e1c:	0289a503          	lw	a0,40(s3)
    80002e20:	916ff0ef          	jal	80001f36 <bread>
    80002e24:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80002e26:	000aa583          	lw	a1,0(s5)
    80002e2a:	0289a503          	lw	a0,40(s3)
    80002e2e:	908ff0ef          	jal	80001f36 <bread>
    80002e32:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80002e34:	865e                	mv	a2,s7
    80002e36:	05890593          	addi	a1,s2,88
    80002e3a:	05850513          	addi	a0,a0,88
    80002e3e:	b80fd0ef          	jal	800001be <memmove>
    bwrite(dbuf);  // write dst to disk
    80002e42:	8526                	mv	a0,s1
    80002e44:	9c8ff0ef          	jal	8000200c <bwrite>
    if(recovering == 0)
    80002e48:	fa0b19e3          	bnez	s6,80002dfa <install_trans+0x3c>
      bunpin(dbuf);
    80002e4c:	8526                	mv	a0,s1
    80002e4e:	aa8ff0ef          	jal	800020f6 <bunpin>
    80002e52:	b765                	j	80002dfa <install_trans+0x3c>
}
    80002e54:	60a6                	ld	ra,72(sp)
    80002e56:	6406                	ld	s0,64(sp)
    80002e58:	74e2                	ld	s1,56(sp)
    80002e5a:	7942                	ld	s2,48(sp)
    80002e5c:	79a2                	ld	s3,40(sp)
    80002e5e:	7a02                	ld	s4,32(sp)
    80002e60:	6ae2                	ld	s5,24(sp)
    80002e62:	6b42                	ld	s6,16(sp)
    80002e64:	6ba2                	ld	s7,8(sp)
    80002e66:	6161                	addi	sp,sp,80
    80002e68:	8082                	ret
    80002e6a:	8082                	ret

0000000080002e6c <initlog>:
{
    80002e6c:	7179                	addi	sp,sp,-48
    80002e6e:	f406                	sd	ra,40(sp)
    80002e70:	f022                	sd	s0,32(sp)
    80002e72:	ec26                	sd	s1,24(sp)
    80002e74:	e84a                	sd	s2,16(sp)
    80002e76:	e44e                	sd	s3,8(sp)
    80002e78:	1800                	addi	s0,sp,48
    80002e7a:	892a                	mv	s2,a0
    80002e7c:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80002e7e:	00015497          	auipc	s1,0x15
    80002e82:	a7248493          	addi	s1,s1,-1422 # 800178f0 <log>
    80002e86:	00004597          	auipc	a1,0x4
    80002e8a:	67258593          	addi	a1,a1,1650 # 800074f8 <etext+0x4f8>
    80002e8e:	8526                	mv	a0,s1
    80002e90:	0b3020ef          	jal	80005742 <initlock>
  log.start = sb->logstart;
    80002e94:	0149a583          	lw	a1,20(s3)
    80002e98:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80002e9a:	0109a783          	lw	a5,16(s3)
    80002e9e:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80002ea0:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80002ea4:	854a                	mv	a0,s2
    80002ea6:	890ff0ef          	jal	80001f36 <bread>
  log.lh.n = lh->n;
    80002eaa:	4d30                	lw	a2,88(a0)
    80002eac:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80002eae:	00c05f63          	blez	a2,80002ecc <initlog+0x60>
    80002eb2:	87aa                	mv	a5,a0
    80002eb4:	00015717          	auipc	a4,0x15
    80002eb8:	a6c70713          	addi	a4,a4,-1428 # 80017920 <log+0x30>
    80002ebc:	060a                	slli	a2,a2,0x2
    80002ebe:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80002ec0:	4ff4                	lw	a3,92(a5)
    80002ec2:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80002ec4:	0791                	addi	a5,a5,4
    80002ec6:	0711                	addi	a4,a4,4
    80002ec8:	fec79ce3          	bne	a5,a2,80002ec0 <initlog+0x54>
  brelse(buf);
    80002ecc:	972ff0ef          	jal	8000203e <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80002ed0:	4505                	li	a0,1
    80002ed2:	eedff0ef          	jal	80002dbe <install_trans>
  log.lh.n = 0;
    80002ed6:	00015797          	auipc	a5,0x15
    80002eda:	a407a323          	sw	zero,-1466(a5) # 8001791c <log+0x2c>
  write_head(); // clear the log
    80002ede:	e83ff0ef          	jal	80002d60 <write_head>
}
    80002ee2:	70a2                	ld	ra,40(sp)
    80002ee4:	7402                	ld	s0,32(sp)
    80002ee6:	64e2                	ld	s1,24(sp)
    80002ee8:	6942                	ld	s2,16(sp)
    80002eea:	69a2                	ld	s3,8(sp)
    80002eec:	6145                	addi	sp,sp,48
    80002eee:	8082                	ret

0000000080002ef0 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80002ef0:	1101                	addi	sp,sp,-32
    80002ef2:	ec06                	sd	ra,24(sp)
    80002ef4:	e822                	sd	s0,16(sp)
    80002ef6:	e426                	sd	s1,8(sp)
    80002ef8:	e04a                	sd	s2,0(sp)
    80002efa:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80002efc:	00015517          	auipc	a0,0x15
    80002f00:	9f450513          	addi	a0,a0,-1548 # 800178f0 <log>
    80002f04:	0c9020ef          	jal	800057cc <acquire>
  while(1){
    if(log.committing){
    80002f08:	00015497          	auipc	s1,0x15
    80002f0c:	9e848493          	addi	s1,s1,-1560 # 800178f0 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80002f10:	4979                	li	s2,30
    80002f12:	a029                	j	80002f1c <begin_op+0x2c>
      sleep(&log, &log.lock);
    80002f14:	85a6                	mv	a1,s1
    80002f16:	8526                	mv	a0,s1
    80002f18:	c3cfe0ef          	jal	80001354 <sleep>
    if(log.committing){
    80002f1c:	50dc                	lw	a5,36(s1)
    80002f1e:	fbfd                	bnez	a5,80002f14 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80002f20:	5098                	lw	a4,32(s1)
    80002f22:	2705                	addiw	a4,a4,1
    80002f24:	0027179b          	slliw	a5,a4,0x2
    80002f28:	9fb9                	addw	a5,a5,a4
    80002f2a:	0017979b          	slliw	a5,a5,0x1
    80002f2e:	54d4                	lw	a3,44(s1)
    80002f30:	9fb5                	addw	a5,a5,a3
    80002f32:	00f95763          	bge	s2,a5,80002f40 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80002f36:	85a6                	mv	a1,s1
    80002f38:	8526                	mv	a0,s1
    80002f3a:	c1afe0ef          	jal	80001354 <sleep>
    80002f3e:	bff9                	j	80002f1c <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80002f40:	00015797          	auipc	a5,0x15
    80002f44:	9ce7a823          	sw	a4,-1584(a5) # 80017910 <log+0x20>
      release(&log.lock);
    80002f48:	00015517          	auipc	a0,0x15
    80002f4c:	9a850513          	addi	a0,a0,-1624 # 800178f0 <log>
    80002f50:	111020ef          	jal	80005860 <release>
      break;
    }
  }
}
    80002f54:	60e2                	ld	ra,24(sp)
    80002f56:	6442                	ld	s0,16(sp)
    80002f58:	64a2                	ld	s1,8(sp)
    80002f5a:	6902                	ld	s2,0(sp)
    80002f5c:	6105                	addi	sp,sp,32
    80002f5e:	8082                	ret

0000000080002f60 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80002f60:	7139                	addi	sp,sp,-64
    80002f62:	fc06                	sd	ra,56(sp)
    80002f64:	f822                	sd	s0,48(sp)
    80002f66:	f426                	sd	s1,40(sp)
    80002f68:	f04a                	sd	s2,32(sp)
    80002f6a:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80002f6c:	00015497          	auipc	s1,0x15
    80002f70:	98448493          	addi	s1,s1,-1660 # 800178f0 <log>
    80002f74:	8526                	mv	a0,s1
    80002f76:	057020ef          	jal	800057cc <acquire>
  log.outstanding -= 1;
    80002f7a:	509c                	lw	a5,32(s1)
    80002f7c:	37fd                	addiw	a5,a5,-1
    80002f7e:	893e                	mv	s2,a5
    80002f80:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80002f82:	50dc                	lw	a5,36(s1)
    80002f84:	e7b1                	bnez	a5,80002fd0 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80002f86:	04091e63          	bnez	s2,80002fe2 <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    80002f8a:	00015497          	auipc	s1,0x15
    80002f8e:	96648493          	addi	s1,s1,-1690 # 800178f0 <log>
    80002f92:	4785                	li	a5,1
    80002f94:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80002f96:	8526                	mv	a0,s1
    80002f98:	0c9020ef          	jal	80005860 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80002f9c:	54dc                	lw	a5,44(s1)
    80002f9e:	06f04463          	bgtz	a5,80003006 <end_op+0xa6>
    acquire(&log.lock);
    80002fa2:	00015517          	auipc	a0,0x15
    80002fa6:	94e50513          	addi	a0,a0,-1714 # 800178f0 <log>
    80002faa:	023020ef          	jal	800057cc <acquire>
    log.committing = 0;
    80002fae:	00015797          	auipc	a5,0x15
    80002fb2:	9607a323          	sw	zero,-1690(a5) # 80017914 <log+0x24>
    wakeup(&log);
    80002fb6:	00015517          	auipc	a0,0x15
    80002fba:	93a50513          	addi	a0,a0,-1734 # 800178f0 <log>
    80002fbe:	be2fe0ef          	jal	800013a0 <wakeup>
    release(&log.lock);
    80002fc2:	00015517          	auipc	a0,0x15
    80002fc6:	92e50513          	addi	a0,a0,-1746 # 800178f0 <log>
    80002fca:	097020ef          	jal	80005860 <release>
}
    80002fce:	a035                	j	80002ffa <end_op+0x9a>
    80002fd0:	ec4e                	sd	s3,24(sp)
    80002fd2:	e852                	sd	s4,16(sp)
    80002fd4:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80002fd6:	00004517          	auipc	a0,0x4
    80002fda:	52a50513          	addi	a0,a0,1322 # 80007500 <etext+0x500>
    80002fde:	4b0020ef          	jal	8000548e <panic>
    wakeup(&log);
    80002fe2:	00015517          	auipc	a0,0x15
    80002fe6:	90e50513          	addi	a0,a0,-1778 # 800178f0 <log>
    80002fea:	bb6fe0ef          	jal	800013a0 <wakeup>
  release(&log.lock);
    80002fee:	00015517          	auipc	a0,0x15
    80002ff2:	90250513          	addi	a0,a0,-1790 # 800178f0 <log>
    80002ff6:	06b020ef          	jal	80005860 <release>
}
    80002ffa:	70e2                	ld	ra,56(sp)
    80002ffc:	7442                	ld	s0,48(sp)
    80002ffe:	74a2                	ld	s1,40(sp)
    80003000:	7902                	ld	s2,32(sp)
    80003002:	6121                	addi	sp,sp,64
    80003004:	8082                	ret
    80003006:	ec4e                	sd	s3,24(sp)
    80003008:	e852                	sd	s4,16(sp)
    8000300a:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    8000300c:	00015a97          	auipc	s5,0x15
    80003010:	914a8a93          	addi	s5,s5,-1772 # 80017920 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003014:	00015a17          	auipc	s4,0x15
    80003018:	8dca0a13          	addi	s4,s4,-1828 # 800178f0 <log>
    8000301c:	018a2583          	lw	a1,24(s4)
    80003020:	012585bb          	addw	a1,a1,s2
    80003024:	2585                	addiw	a1,a1,1
    80003026:	028a2503          	lw	a0,40(s4)
    8000302a:	f0dfe0ef          	jal	80001f36 <bread>
    8000302e:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003030:	000aa583          	lw	a1,0(s5)
    80003034:	028a2503          	lw	a0,40(s4)
    80003038:	efffe0ef          	jal	80001f36 <bread>
    8000303c:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    8000303e:	40000613          	li	a2,1024
    80003042:	05850593          	addi	a1,a0,88
    80003046:	05848513          	addi	a0,s1,88
    8000304a:	974fd0ef          	jal	800001be <memmove>
    bwrite(to);  // write the log
    8000304e:	8526                	mv	a0,s1
    80003050:	fbdfe0ef          	jal	8000200c <bwrite>
    brelse(from);
    80003054:	854e                	mv	a0,s3
    80003056:	fe9fe0ef          	jal	8000203e <brelse>
    brelse(to);
    8000305a:	8526                	mv	a0,s1
    8000305c:	fe3fe0ef          	jal	8000203e <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003060:	2905                	addiw	s2,s2,1
    80003062:	0a91                	addi	s5,s5,4
    80003064:	02ca2783          	lw	a5,44(s4)
    80003068:	faf94ae3          	blt	s2,a5,8000301c <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    8000306c:	cf5ff0ef          	jal	80002d60 <write_head>
    install_trans(0); // Now install writes to home locations
    80003070:	4501                	li	a0,0
    80003072:	d4dff0ef          	jal	80002dbe <install_trans>
    log.lh.n = 0;
    80003076:	00015797          	auipc	a5,0x15
    8000307a:	8a07a323          	sw	zero,-1882(a5) # 8001791c <log+0x2c>
    write_head();    // Erase the transaction from the log
    8000307e:	ce3ff0ef          	jal	80002d60 <write_head>
    80003082:	69e2                	ld	s3,24(sp)
    80003084:	6a42                	ld	s4,16(sp)
    80003086:	6aa2                	ld	s5,8(sp)
    80003088:	bf29                	j	80002fa2 <end_op+0x42>

000000008000308a <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000308a:	1101                	addi	sp,sp,-32
    8000308c:	ec06                	sd	ra,24(sp)
    8000308e:	e822                	sd	s0,16(sp)
    80003090:	e426                	sd	s1,8(sp)
    80003092:	1000                	addi	s0,sp,32
    80003094:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003096:	00015517          	auipc	a0,0x15
    8000309a:	85a50513          	addi	a0,a0,-1958 # 800178f0 <log>
    8000309e:	72e020ef          	jal	800057cc <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800030a2:	00015617          	auipc	a2,0x15
    800030a6:	87a62603          	lw	a2,-1926(a2) # 8001791c <log+0x2c>
    800030aa:	47f5                	li	a5,29
    800030ac:	06c7c463          	blt	a5,a2,80003114 <log_write+0x8a>
    800030b0:	00015797          	auipc	a5,0x15
    800030b4:	85c7a783          	lw	a5,-1956(a5) # 8001790c <log+0x1c>
    800030b8:	37fd                	addiw	a5,a5,-1
    800030ba:	04f65d63          	bge	a2,a5,80003114 <log_write+0x8a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800030be:	00015797          	auipc	a5,0x15
    800030c2:	8527a783          	lw	a5,-1966(a5) # 80017910 <log+0x20>
    800030c6:	04f05d63          	blez	a5,80003120 <log_write+0x96>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800030ca:	4781                	li	a5,0
    800030cc:	06c05063          	blez	a2,8000312c <log_write+0xa2>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800030d0:	44cc                	lw	a1,12(s1)
    800030d2:	00015717          	auipc	a4,0x15
    800030d6:	84e70713          	addi	a4,a4,-1970 # 80017920 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800030da:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800030dc:	4314                	lw	a3,0(a4)
    800030de:	04b68763          	beq	a3,a1,8000312c <log_write+0xa2>
  for (i = 0; i < log.lh.n; i++) {
    800030e2:	2785                	addiw	a5,a5,1
    800030e4:	0711                	addi	a4,a4,4
    800030e6:	fef61be3          	bne	a2,a5,800030dc <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    800030ea:	060a                	slli	a2,a2,0x2
    800030ec:	02060613          	addi	a2,a2,32
    800030f0:	00015797          	auipc	a5,0x15
    800030f4:	80078793          	addi	a5,a5,-2048 # 800178f0 <log>
    800030f8:	97b2                	add	a5,a5,a2
    800030fa:	44d8                	lw	a4,12(s1)
    800030fc:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    800030fe:	8526                	mv	a0,s1
    80003100:	fc3fe0ef          	jal	800020c2 <bpin>
    log.lh.n++;
    80003104:	00014717          	auipc	a4,0x14
    80003108:	7ec70713          	addi	a4,a4,2028 # 800178f0 <log>
    8000310c:	575c                	lw	a5,44(a4)
    8000310e:	2785                	addiw	a5,a5,1
    80003110:	d75c                	sw	a5,44(a4)
    80003112:	a815                	j	80003146 <log_write+0xbc>
    panic("too big a transaction");
    80003114:	00004517          	auipc	a0,0x4
    80003118:	3fc50513          	addi	a0,a0,1020 # 80007510 <etext+0x510>
    8000311c:	372020ef          	jal	8000548e <panic>
    panic("log_write outside of trans");
    80003120:	00004517          	auipc	a0,0x4
    80003124:	40850513          	addi	a0,a0,1032 # 80007528 <etext+0x528>
    80003128:	366020ef          	jal	8000548e <panic>
  log.lh.block[i] = b->blockno;
    8000312c:	00279693          	slli	a3,a5,0x2
    80003130:	02068693          	addi	a3,a3,32
    80003134:	00014717          	auipc	a4,0x14
    80003138:	7bc70713          	addi	a4,a4,1980 # 800178f0 <log>
    8000313c:	9736                	add	a4,a4,a3
    8000313e:	44d4                	lw	a3,12(s1)
    80003140:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003142:	faf60ee3          	beq	a2,a5,800030fe <log_write+0x74>
  }
  release(&log.lock);
    80003146:	00014517          	auipc	a0,0x14
    8000314a:	7aa50513          	addi	a0,a0,1962 # 800178f0 <log>
    8000314e:	712020ef          	jal	80005860 <release>
}
    80003152:	60e2                	ld	ra,24(sp)
    80003154:	6442                	ld	s0,16(sp)
    80003156:	64a2                	ld	s1,8(sp)
    80003158:	6105                	addi	sp,sp,32
    8000315a:	8082                	ret

000000008000315c <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    8000315c:	1101                	addi	sp,sp,-32
    8000315e:	ec06                	sd	ra,24(sp)
    80003160:	e822                	sd	s0,16(sp)
    80003162:	e426                	sd	s1,8(sp)
    80003164:	e04a                	sd	s2,0(sp)
    80003166:	1000                	addi	s0,sp,32
    80003168:	84aa                	mv	s1,a0
    8000316a:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    8000316c:	00004597          	auipc	a1,0x4
    80003170:	3dc58593          	addi	a1,a1,988 # 80007548 <etext+0x548>
    80003174:	0521                	addi	a0,a0,8
    80003176:	5cc020ef          	jal	80005742 <initlock>
  lk->name = name;
    8000317a:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000317e:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003182:	0204a423          	sw	zero,40(s1)
}
    80003186:	60e2                	ld	ra,24(sp)
    80003188:	6442                	ld	s0,16(sp)
    8000318a:	64a2                	ld	s1,8(sp)
    8000318c:	6902                	ld	s2,0(sp)
    8000318e:	6105                	addi	sp,sp,32
    80003190:	8082                	ret

0000000080003192 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003192:	1101                	addi	sp,sp,-32
    80003194:	ec06                	sd	ra,24(sp)
    80003196:	e822                	sd	s0,16(sp)
    80003198:	e426                	sd	s1,8(sp)
    8000319a:	e04a                	sd	s2,0(sp)
    8000319c:	1000                	addi	s0,sp,32
    8000319e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800031a0:	00850913          	addi	s2,a0,8
    800031a4:	854a                	mv	a0,s2
    800031a6:	626020ef          	jal	800057cc <acquire>
  while (lk->locked) {
    800031aa:	409c                	lw	a5,0(s1)
    800031ac:	c799                	beqz	a5,800031ba <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    800031ae:	85ca                	mv	a1,s2
    800031b0:	8526                	mv	a0,s1
    800031b2:	9a2fe0ef          	jal	80001354 <sleep>
  while (lk->locked) {
    800031b6:	409c                	lw	a5,0(s1)
    800031b8:	fbfd                	bnez	a5,800031ae <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800031ba:	4785                	li	a5,1
    800031bc:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800031be:	bc5fd0ef          	jal	80000d82 <myproc>
    800031c2:	591c                	lw	a5,48(a0)
    800031c4:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800031c6:	854a                	mv	a0,s2
    800031c8:	698020ef          	jal	80005860 <release>
}
    800031cc:	60e2                	ld	ra,24(sp)
    800031ce:	6442                	ld	s0,16(sp)
    800031d0:	64a2                	ld	s1,8(sp)
    800031d2:	6902                	ld	s2,0(sp)
    800031d4:	6105                	addi	sp,sp,32
    800031d6:	8082                	ret

00000000800031d8 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800031d8:	1101                	addi	sp,sp,-32
    800031da:	ec06                	sd	ra,24(sp)
    800031dc:	e822                	sd	s0,16(sp)
    800031de:	e426                	sd	s1,8(sp)
    800031e0:	e04a                	sd	s2,0(sp)
    800031e2:	1000                	addi	s0,sp,32
    800031e4:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800031e6:	00850913          	addi	s2,a0,8
    800031ea:	854a                	mv	a0,s2
    800031ec:	5e0020ef          	jal	800057cc <acquire>
  lk->locked = 0;
    800031f0:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800031f4:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800031f8:	8526                	mv	a0,s1
    800031fa:	9a6fe0ef          	jal	800013a0 <wakeup>
  release(&lk->lk);
    800031fe:	854a                	mv	a0,s2
    80003200:	660020ef          	jal	80005860 <release>
}
    80003204:	60e2                	ld	ra,24(sp)
    80003206:	6442                	ld	s0,16(sp)
    80003208:	64a2                	ld	s1,8(sp)
    8000320a:	6902                	ld	s2,0(sp)
    8000320c:	6105                	addi	sp,sp,32
    8000320e:	8082                	ret

0000000080003210 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003210:	7179                	addi	sp,sp,-48
    80003212:	f406                	sd	ra,40(sp)
    80003214:	f022                	sd	s0,32(sp)
    80003216:	ec26                	sd	s1,24(sp)
    80003218:	e84a                	sd	s2,16(sp)
    8000321a:	1800                	addi	s0,sp,48
    8000321c:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000321e:	00850913          	addi	s2,a0,8
    80003222:	854a                	mv	a0,s2
    80003224:	5a8020ef          	jal	800057cc <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003228:	409c                	lw	a5,0(s1)
    8000322a:	ef81                	bnez	a5,80003242 <holdingsleep+0x32>
    8000322c:	4481                	li	s1,0
  release(&lk->lk);
    8000322e:	854a                	mv	a0,s2
    80003230:	630020ef          	jal	80005860 <release>
  return r;
}
    80003234:	8526                	mv	a0,s1
    80003236:	70a2                	ld	ra,40(sp)
    80003238:	7402                	ld	s0,32(sp)
    8000323a:	64e2                	ld	s1,24(sp)
    8000323c:	6942                	ld	s2,16(sp)
    8000323e:	6145                	addi	sp,sp,48
    80003240:	8082                	ret
    80003242:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003244:	0284a983          	lw	s3,40(s1)
    80003248:	b3bfd0ef          	jal	80000d82 <myproc>
    8000324c:	5904                	lw	s1,48(a0)
    8000324e:	413484b3          	sub	s1,s1,s3
    80003252:	0014b493          	seqz	s1,s1
    80003256:	69a2                	ld	s3,8(sp)
    80003258:	bfd9                	j	8000322e <holdingsleep+0x1e>

000000008000325a <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    8000325a:	1141                	addi	sp,sp,-16
    8000325c:	e406                	sd	ra,8(sp)
    8000325e:	e022                	sd	s0,0(sp)
    80003260:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003262:	00004597          	auipc	a1,0x4
    80003266:	2f658593          	addi	a1,a1,758 # 80007558 <etext+0x558>
    8000326a:	00014517          	auipc	a0,0x14
    8000326e:	7ce50513          	addi	a0,a0,1998 # 80017a38 <ftable>
    80003272:	4d0020ef          	jal	80005742 <initlock>
}
    80003276:	60a2                	ld	ra,8(sp)
    80003278:	6402                	ld	s0,0(sp)
    8000327a:	0141                	addi	sp,sp,16
    8000327c:	8082                	ret

000000008000327e <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000327e:	1101                	addi	sp,sp,-32
    80003280:	ec06                	sd	ra,24(sp)
    80003282:	e822                	sd	s0,16(sp)
    80003284:	e426                	sd	s1,8(sp)
    80003286:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003288:	00014517          	auipc	a0,0x14
    8000328c:	7b050513          	addi	a0,a0,1968 # 80017a38 <ftable>
    80003290:	53c020ef          	jal	800057cc <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003294:	00014497          	auipc	s1,0x14
    80003298:	7bc48493          	addi	s1,s1,1980 # 80017a50 <ftable+0x18>
    8000329c:	00015717          	auipc	a4,0x15
    800032a0:	75470713          	addi	a4,a4,1876 # 800189f0 <disk>
    if(f->ref == 0){
    800032a4:	40dc                	lw	a5,4(s1)
    800032a6:	cf89                	beqz	a5,800032c0 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800032a8:	02848493          	addi	s1,s1,40
    800032ac:	fee49ce3          	bne	s1,a4,800032a4 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800032b0:	00014517          	auipc	a0,0x14
    800032b4:	78850513          	addi	a0,a0,1928 # 80017a38 <ftable>
    800032b8:	5a8020ef          	jal	80005860 <release>
  return 0;
    800032bc:	4481                	li	s1,0
    800032be:	a809                	j	800032d0 <filealloc+0x52>
      f->ref = 1;
    800032c0:	4785                	li	a5,1
    800032c2:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800032c4:	00014517          	auipc	a0,0x14
    800032c8:	77450513          	addi	a0,a0,1908 # 80017a38 <ftable>
    800032cc:	594020ef          	jal	80005860 <release>
}
    800032d0:	8526                	mv	a0,s1
    800032d2:	60e2                	ld	ra,24(sp)
    800032d4:	6442                	ld	s0,16(sp)
    800032d6:	64a2                	ld	s1,8(sp)
    800032d8:	6105                	addi	sp,sp,32
    800032da:	8082                	ret

00000000800032dc <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800032dc:	1101                	addi	sp,sp,-32
    800032de:	ec06                	sd	ra,24(sp)
    800032e0:	e822                	sd	s0,16(sp)
    800032e2:	e426                	sd	s1,8(sp)
    800032e4:	1000                	addi	s0,sp,32
    800032e6:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800032e8:	00014517          	auipc	a0,0x14
    800032ec:	75050513          	addi	a0,a0,1872 # 80017a38 <ftable>
    800032f0:	4dc020ef          	jal	800057cc <acquire>
  if(f->ref < 1)
    800032f4:	40dc                	lw	a5,4(s1)
    800032f6:	02f05063          	blez	a5,80003316 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    800032fa:	2785                	addiw	a5,a5,1
    800032fc:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800032fe:	00014517          	auipc	a0,0x14
    80003302:	73a50513          	addi	a0,a0,1850 # 80017a38 <ftable>
    80003306:	55a020ef          	jal	80005860 <release>
  return f;
}
    8000330a:	8526                	mv	a0,s1
    8000330c:	60e2                	ld	ra,24(sp)
    8000330e:	6442                	ld	s0,16(sp)
    80003310:	64a2                	ld	s1,8(sp)
    80003312:	6105                	addi	sp,sp,32
    80003314:	8082                	ret
    panic("filedup");
    80003316:	00004517          	auipc	a0,0x4
    8000331a:	24a50513          	addi	a0,a0,586 # 80007560 <etext+0x560>
    8000331e:	170020ef          	jal	8000548e <panic>

0000000080003322 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003322:	7139                	addi	sp,sp,-64
    80003324:	fc06                	sd	ra,56(sp)
    80003326:	f822                	sd	s0,48(sp)
    80003328:	f426                	sd	s1,40(sp)
    8000332a:	0080                	addi	s0,sp,64
    8000332c:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    8000332e:	00014517          	auipc	a0,0x14
    80003332:	70a50513          	addi	a0,a0,1802 # 80017a38 <ftable>
    80003336:	496020ef          	jal	800057cc <acquire>
  if(f->ref < 1)
    8000333a:	40dc                	lw	a5,4(s1)
    8000333c:	04f05a63          	blez	a5,80003390 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    80003340:	37fd                	addiw	a5,a5,-1
    80003342:	c0dc                	sw	a5,4(s1)
    80003344:	06f04063          	bgtz	a5,800033a4 <fileclose+0x82>
    80003348:	f04a                	sd	s2,32(sp)
    8000334a:	ec4e                	sd	s3,24(sp)
    8000334c:	e852                	sd	s4,16(sp)
    8000334e:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003350:	0004a903          	lw	s2,0(s1)
    80003354:	0094c783          	lbu	a5,9(s1)
    80003358:	89be                	mv	s3,a5
    8000335a:	689c                	ld	a5,16(s1)
    8000335c:	8a3e                	mv	s4,a5
    8000335e:	6c9c                	ld	a5,24(s1)
    80003360:	8abe                	mv	s5,a5
  f->ref = 0;
    80003362:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003366:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000336a:	00014517          	auipc	a0,0x14
    8000336e:	6ce50513          	addi	a0,a0,1742 # 80017a38 <ftable>
    80003372:	4ee020ef          	jal	80005860 <release>

  if(ff.type == FD_PIPE){
    80003376:	4785                	li	a5,1
    80003378:	04f90163          	beq	s2,a5,800033ba <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000337c:	ffe9079b          	addiw	a5,s2,-2
    80003380:	4705                	li	a4,1
    80003382:	04f77563          	bgeu	a4,a5,800033cc <fileclose+0xaa>
    80003386:	7902                	ld	s2,32(sp)
    80003388:	69e2                	ld	s3,24(sp)
    8000338a:	6a42                	ld	s4,16(sp)
    8000338c:	6aa2                	ld	s5,8(sp)
    8000338e:	a00d                	j	800033b0 <fileclose+0x8e>
    80003390:	f04a                	sd	s2,32(sp)
    80003392:	ec4e                	sd	s3,24(sp)
    80003394:	e852                	sd	s4,16(sp)
    80003396:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80003398:	00004517          	auipc	a0,0x4
    8000339c:	1d050513          	addi	a0,a0,464 # 80007568 <etext+0x568>
    800033a0:	0ee020ef          	jal	8000548e <panic>
    release(&ftable.lock);
    800033a4:	00014517          	auipc	a0,0x14
    800033a8:	69450513          	addi	a0,a0,1684 # 80017a38 <ftable>
    800033ac:	4b4020ef          	jal	80005860 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800033b0:	70e2                	ld	ra,56(sp)
    800033b2:	7442                	ld	s0,48(sp)
    800033b4:	74a2                	ld	s1,40(sp)
    800033b6:	6121                	addi	sp,sp,64
    800033b8:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800033ba:	85ce                	mv	a1,s3
    800033bc:	8552                	mv	a0,s4
    800033be:	348000ef          	jal	80003706 <pipeclose>
    800033c2:	7902                	ld	s2,32(sp)
    800033c4:	69e2                	ld	s3,24(sp)
    800033c6:	6a42                	ld	s4,16(sp)
    800033c8:	6aa2                	ld	s5,8(sp)
    800033ca:	b7dd                	j	800033b0 <fileclose+0x8e>
    begin_op();
    800033cc:	b25ff0ef          	jal	80002ef0 <begin_op>
    iput(ff.ip);
    800033d0:	8556                	mv	a0,s5
    800033d2:	be8ff0ef          	jal	800027ba <iput>
    end_op();
    800033d6:	b8bff0ef          	jal	80002f60 <end_op>
    800033da:	7902                	ld	s2,32(sp)
    800033dc:	69e2                	ld	s3,24(sp)
    800033de:	6a42                	ld	s4,16(sp)
    800033e0:	6aa2                	ld	s5,8(sp)
    800033e2:	b7f9                	j	800033b0 <fileclose+0x8e>

00000000800033e4 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800033e4:	715d                	addi	sp,sp,-80
    800033e6:	e486                	sd	ra,72(sp)
    800033e8:	e0a2                	sd	s0,64(sp)
    800033ea:	fc26                	sd	s1,56(sp)
    800033ec:	f052                	sd	s4,32(sp)
    800033ee:	0880                	addi	s0,sp,80
    800033f0:	84aa                	mv	s1,a0
    800033f2:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    800033f4:	98ffd0ef          	jal	80000d82 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800033f8:	409c                	lw	a5,0(s1)
    800033fa:	37f9                	addiw	a5,a5,-2
    800033fc:	4705                	li	a4,1
    800033fe:	04f76263          	bltu	a4,a5,80003442 <filestat+0x5e>
    80003402:	f84a                	sd	s2,48(sp)
    80003404:	f44e                	sd	s3,40(sp)
    80003406:	89aa                	mv	s3,a0
    ilock(f->ip);
    80003408:	6c88                	ld	a0,24(s1)
    8000340a:	a2eff0ef          	jal	80002638 <ilock>
    stati(f->ip, &st);
    8000340e:	fb840913          	addi	s2,s0,-72
    80003412:	85ca                	mv	a1,s2
    80003414:	6c88                	ld	a0,24(s1)
    80003416:	c4eff0ef          	jal	80002864 <stati>
    iunlock(f->ip);
    8000341a:	6c88                	ld	a0,24(s1)
    8000341c:	acaff0ef          	jal	800026e6 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003420:	46e1                	li	a3,24
    80003422:	864a                	mv	a2,s2
    80003424:	85d2                	mv	a1,s4
    80003426:	0509b503          	ld	a0,80(s3)
    8000342a:	dd8fd0ef          	jal	80000a02 <copyout>
    8000342e:	41f5551b          	sraiw	a0,a0,0x1f
    80003432:	7942                	ld	s2,48(sp)
    80003434:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80003436:	60a6                	ld	ra,72(sp)
    80003438:	6406                	ld	s0,64(sp)
    8000343a:	74e2                	ld	s1,56(sp)
    8000343c:	7a02                	ld	s4,32(sp)
    8000343e:	6161                	addi	sp,sp,80
    80003440:	8082                	ret
  return -1;
    80003442:	557d                	li	a0,-1
    80003444:	bfcd                	j	80003436 <filestat+0x52>

0000000080003446 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003446:	7179                	addi	sp,sp,-48
    80003448:	f406                	sd	ra,40(sp)
    8000344a:	f022                	sd	s0,32(sp)
    8000344c:	e84a                	sd	s2,16(sp)
    8000344e:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003450:	00854783          	lbu	a5,8(a0)
    80003454:	cfd1                	beqz	a5,800034f0 <fileread+0xaa>
    80003456:	ec26                	sd	s1,24(sp)
    80003458:	e44e                	sd	s3,8(sp)
    8000345a:	84aa                	mv	s1,a0
    8000345c:	892e                	mv	s2,a1
    8000345e:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    80003460:	411c                	lw	a5,0(a0)
    80003462:	4705                	li	a4,1
    80003464:	04e78363          	beq	a5,a4,800034aa <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003468:	470d                	li	a4,3
    8000346a:	04e78763          	beq	a5,a4,800034b8 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    8000346e:	4709                	li	a4,2
    80003470:	06e79a63          	bne	a5,a4,800034e4 <fileread+0x9e>
    ilock(f->ip);
    80003474:	6d08                	ld	a0,24(a0)
    80003476:	9c2ff0ef          	jal	80002638 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000347a:	874e                	mv	a4,s3
    8000347c:	5094                	lw	a3,32(s1)
    8000347e:	864a                	mv	a2,s2
    80003480:	4585                	li	a1,1
    80003482:	6c88                	ld	a0,24(s1)
    80003484:	c0eff0ef          	jal	80002892 <readi>
    80003488:	892a                	mv	s2,a0
    8000348a:	00a05563          	blez	a0,80003494 <fileread+0x4e>
      f->off += r;
    8000348e:	509c                	lw	a5,32(s1)
    80003490:	9fa9                	addw	a5,a5,a0
    80003492:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80003494:	6c88                	ld	a0,24(s1)
    80003496:	a50ff0ef          	jal	800026e6 <iunlock>
    8000349a:	64e2                	ld	s1,24(sp)
    8000349c:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000349e:	854a                	mv	a0,s2
    800034a0:	70a2                	ld	ra,40(sp)
    800034a2:	7402                	ld	s0,32(sp)
    800034a4:	6942                	ld	s2,16(sp)
    800034a6:	6145                	addi	sp,sp,48
    800034a8:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800034aa:	6908                	ld	a0,16(a0)
    800034ac:	3b0000ef          	jal	8000385c <piperead>
    800034b0:	892a                	mv	s2,a0
    800034b2:	64e2                	ld	s1,24(sp)
    800034b4:	69a2                	ld	s3,8(sp)
    800034b6:	b7e5                	j	8000349e <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800034b8:	02451783          	lh	a5,36(a0)
    800034bc:	03079693          	slli	a3,a5,0x30
    800034c0:	92c1                	srli	a3,a3,0x30
    800034c2:	4725                	li	a4,9
    800034c4:	02d76963          	bltu	a4,a3,800034f6 <fileread+0xb0>
    800034c8:	0792                	slli	a5,a5,0x4
    800034ca:	00014717          	auipc	a4,0x14
    800034ce:	4ce70713          	addi	a4,a4,1230 # 80017998 <devsw>
    800034d2:	97ba                	add	a5,a5,a4
    800034d4:	639c                	ld	a5,0(a5)
    800034d6:	c78d                	beqz	a5,80003500 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    800034d8:	4505                	li	a0,1
    800034da:	9782                	jalr	a5
    800034dc:	892a                	mv	s2,a0
    800034de:	64e2                	ld	s1,24(sp)
    800034e0:	69a2                	ld	s3,8(sp)
    800034e2:	bf75                	j	8000349e <fileread+0x58>
    panic("fileread");
    800034e4:	00004517          	auipc	a0,0x4
    800034e8:	09450513          	addi	a0,a0,148 # 80007578 <etext+0x578>
    800034ec:	7a3010ef          	jal	8000548e <panic>
    return -1;
    800034f0:	57fd                	li	a5,-1
    800034f2:	893e                	mv	s2,a5
    800034f4:	b76d                	j	8000349e <fileread+0x58>
      return -1;
    800034f6:	57fd                	li	a5,-1
    800034f8:	893e                	mv	s2,a5
    800034fa:	64e2                	ld	s1,24(sp)
    800034fc:	69a2                	ld	s3,8(sp)
    800034fe:	b745                	j	8000349e <fileread+0x58>
    80003500:	57fd                	li	a5,-1
    80003502:	893e                	mv	s2,a5
    80003504:	64e2                	ld	s1,24(sp)
    80003506:	69a2                	ld	s3,8(sp)
    80003508:	bf59                	j	8000349e <fileread+0x58>

000000008000350a <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    8000350a:	00954783          	lbu	a5,9(a0)
    8000350e:	10078f63          	beqz	a5,8000362c <filewrite+0x122>
{
    80003512:	711d                	addi	sp,sp,-96
    80003514:	ec86                	sd	ra,88(sp)
    80003516:	e8a2                	sd	s0,80(sp)
    80003518:	e0ca                	sd	s2,64(sp)
    8000351a:	f456                	sd	s5,40(sp)
    8000351c:	f05a                	sd	s6,32(sp)
    8000351e:	1080                	addi	s0,sp,96
    80003520:	892a                	mv	s2,a0
    80003522:	8b2e                	mv	s6,a1
    80003524:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    80003526:	411c                	lw	a5,0(a0)
    80003528:	4705                	li	a4,1
    8000352a:	02e78a63          	beq	a5,a4,8000355e <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000352e:	470d                	li	a4,3
    80003530:	02e78b63          	beq	a5,a4,80003566 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80003534:	4709                	li	a4,2
    80003536:	0ce79f63          	bne	a5,a4,80003614 <filewrite+0x10a>
    8000353a:	f852                	sd	s4,48(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    8000353c:	0ac05a63          	blez	a2,800035f0 <filewrite+0xe6>
    80003540:	e4a6                	sd	s1,72(sp)
    80003542:	fc4e                	sd	s3,56(sp)
    80003544:	ec5e                	sd	s7,24(sp)
    80003546:	e862                	sd	s8,16(sp)
    80003548:	e466                	sd	s9,8(sp)
    int i = 0;
    8000354a:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    8000354c:	6b85                	lui	s7,0x1
    8000354e:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80003552:	6785                	lui	a5,0x1
    80003554:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80003558:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000355a:	4c05                	li	s8,1
    8000355c:	a8ad                	j	800035d6 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    8000355e:	6908                	ld	a0,16(a0)
    80003560:	204000ef          	jal	80003764 <pipewrite>
    80003564:	a04d                	j	80003606 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80003566:	02451783          	lh	a5,36(a0)
    8000356a:	03079693          	slli	a3,a5,0x30
    8000356e:	92c1                	srli	a3,a3,0x30
    80003570:	4725                	li	a4,9
    80003572:	0ad76f63          	bltu	a4,a3,80003630 <filewrite+0x126>
    80003576:	0792                	slli	a5,a5,0x4
    80003578:	00014717          	auipc	a4,0x14
    8000357c:	42070713          	addi	a4,a4,1056 # 80017998 <devsw>
    80003580:	97ba                	add	a5,a5,a4
    80003582:	679c                	ld	a5,8(a5)
    80003584:	cbc5                	beqz	a5,80003634 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    80003586:	4505                	li	a0,1
    80003588:	9782                	jalr	a5
    8000358a:	a8b5                	j	80003606 <filewrite+0xfc>
      if(n1 > max)
    8000358c:	2981                	sext.w	s3,s3
      begin_op();
    8000358e:	963ff0ef          	jal	80002ef0 <begin_op>
      ilock(f->ip);
    80003592:	01893503          	ld	a0,24(s2)
    80003596:	8a2ff0ef          	jal	80002638 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000359a:	874e                	mv	a4,s3
    8000359c:	02092683          	lw	a3,32(s2)
    800035a0:	016a0633          	add	a2,s4,s6
    800035a4:	85e2                	mv	a1,s8
    800035a6:	01893503          	ld	a0,24(s2)
    800035aa:	bdaff0ef          	jal	80002984 <writei>
    800035ae:	84aa                	mv	s1,a0
    800035b0:	00a05763          	blez	a0,800035be <filewrite+0xb4>
        f->off += r;
    800035b4:	02092783          	lw	a5,32(s2)
    800035b8:	9fa9                	addw	a5,a5,a0
    800035ba:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800035be:	01893503          	ld	a0,24(s2)
    800035c2:	924ff0ef          	jal	800026e6 <iunlock>
      end_op();
    800035c6:	99bff0ef          	jal	80002f60 <end_op>

      if(r != n1){
    800035ca:	02999563          	bne	s3,s1,800035f4 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    800035ce:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    800035d2:	015a5963          	bge	s4,s5,800035e4 <filewrite+0xda>
      int n1 = n - i;
    800035d6:	414a87bb          	subw	a5,s5,s4
    800035da:	89be                	mv	s3,a5
      if(n1 > max)
    800035dc:	fafbd8e3          	bge	s7,a5,8000358c <filewrite+0x82>
    800035e0:	89e6                	mv	s3,s9
    800035e2:	b76d                	j	8000358c <filewrite+0x82>
    800035e4:	64a6                	ld	s1,72(sp)
    800035e6:	79e2                	ld	s3,56(sp)
    800035e8:	6be2                	ld	s7,24(sp)
    800035ea:	6c42                	ld	s8,16(sp)
    800035ec:	6ca2                	ld	s9,8(sp)
    800035ee:	a801                	j	800035fe <filewrite+0xf4>
    int i = 0;
    800035f0:	4a01                	li	s4,0
    800035f2:	a031                	j	800035fe <filewrite+0xf4>
    800035f4:	64a6                	ld	s1,72(sp)
    800035f6:	79e2                	ld	s3,56(sp)
    800035f8:	6be2                	ld	s7,24(sp)
    800035fa:	6c42                	ld	s8,16(sp)
    800035fc:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    800035fe:	034a9d63          	bne	s5,s4,80003638 <filewrite+0x12e>
    80003602:	8556                	mv	a0,s5
    80003604:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80003606:	60e6                	ld	ra,88(sp)
    80003608:	6446                	ld	s0,80(sp)
    8000360a:	6906                	ld	s2,64(sp)
    8000360c:	7aa2                	ld	s5,40(sp)
    8000360e:	7b02                	ld	s6,32(sp)
    80003610:	6125                	addi	sp,sp,96
    80003612:	8082                	ret
    80003614:	e4a6                	sd	s1,72(sp)
    80003616:	fc4e                	sd	s3,56(sp)
    80003618:	f852                	sd	s4,48(sp)
    8000361a:	ec5e                	sd	s7,24(sp)
    8000361c:	e862                	sd	s8,16(sp)
    8000361e:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80003620:	00004517          	auipc	a0,0x4
    80003624:	f6850513          	addi	a0,a0,-152 # 80007588 <etext+0x588>
    80003628:	667010ef          	jal	8000548e <panic>
    return -1;
    8000362c:	557d                	li	a0,-1
}
    8000362e:	8082                	ret
      return -1;
    80003630:	557d                	li	a0,-1
    80003632:	bfd1                	j	80003606 <filewrite+0xfc>
    80003634:	557d                	li	a0,-1
    80003636:	bfc1                	j	80003606 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    80003638:	557d                	li	a0,-1
    8000363a:	7a42                	ld	s4,48(sp)
    8000363c:	b7e9                	j	80003606 <filewrite+0xfc>

000000008000363e <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    8000363e:	7179                	addi	sp,sp,-48
    80003640:	f406                	sd	ra,40(sp)
    80003642:	f022                	sd	s0,32(sp)
    80003644:	ec26                	sd	s1,24(sp)
    80003646:	e052                	sd	s4,0(sp)
    80003648:	1800                	addi	s0,sp,48
    8000364a:	84aa                	mv	s1,a0
    8000364c:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    8000364e:	0005b023          	sd	zero,0(a1)
    80003652:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80003656:	c29ff0ef          	jal	8000327e <filealloc>
    8000365a:	e088                	sd	a0,0(s1)
    8000365c:	c549                	beqz	a0,800036e6 <pipealloc+0xa8>
    8000365e:	c21ff0ef          	jal	8000327e <filealloc>
    80003662:	00aa3023          	sd	a0,0(s4)
    80003666:	cd25                	beqz	a0,800036de <pipealloc+0xa0>
    80003668:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    8000366a:	a9bfc0ef          	jal	80000104 <kalloc>
    8000366e:	892a                	mv	s2,a0
    80003670:	c12d                	beqz	a0,800036d2 <pipealloc+0x94>
    80003672:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80003674:	4985                	li	s3,1
    80003676:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000367a:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000367e:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80003682:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80003686:	00004597          	auipc	a1,0x4
    8000368a:	f1258593          	addi	a1,a1,-238 # 80007598 <etext+0x598>
    8000368e:	0b4020ef          	jal	80005742 <initlock>
  (*f0)->type = FD_PIPE;
    80003692:	609c                	ld	a5,0(s1)
    80003694:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80003698:	609c                	ld	a5,0(s1)
    8000369a:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000369e:	609c                	ld	a5,0(s1)
    800036a0:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800036a4:	609c                	ld	a5,0(s1)
    800036a6:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800036aa:	000a3783          	ld	a5,0(s4)
    800036ae:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800036b2:	000a3783          	ld	a5,0(s4)
    800036b6:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800036ba:	000a3783          	ld	a5,0(s4)
    800036be:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800036c2:	000a3783          	ld	a5,0(s4)
    800036c6:	0127b823          	sd	s2,16(a5)
  return 0;
    800036ca:	4501                	li	a0,0
    800036cc:	6942                	ld	s2,16(sp)
    800036ce:	69a2                	ld	s3,8(sp)
    800036d0:	a01d                	j	800036f6 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    800036d2:	6088                	ld	a0,0(s1)
    800036d4:	c119                	beqz	a0,800036da <pipealloc+0x9c>
    800036d6:	6942                	ld	s2,16(sp)
    800036d8:	a029                	j	800036e2 <pipealloc+0xa4>
    800036da:	6942                	ld	s2,16(sp)
    800036dc:	a029                	j	800036e6 <pipealloc+0xa8>
    800036de:	6088                	ld	a0,0(s1)
    800036e0:	c10d                	beqz	a0,80003702 <pipealloc+0xc4>
    fileclose(*f0);
    800036e2:	c41ff0ef          	jal	80003322 <fileclose>
  if(*f1)
    800036e6:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800036ea:	557d                	li	a0,-1
  if(*f1)
    800036ec:	c789                	beqz	a5,800036f6 <pipealloc+0xb8>
    fileclose(*f1);
    800036ee:	853e                	mv	a0,a5
    800036f0:	c33ff0ef          	jal	80003322 <fileclose>
  return -1;
    800036f4:	557d                	li	a0,-1
}
    800036f6:	70a2                	ld	ra,40(sp)
    800036f8:	7402                	ld	s0,32(sp)
    800036fa:	64e2                	ld	s1,24(sp)
    800036fc:	6a02                	ld	s4,0(sp)
    800036fe:	6145                	addi	sp,sp,48
    80003700:	8082                	ret
  return -1;
    80003702:	557d                	li	a0,-1
    80003704:	bfcd                	j	800036f6 <pipealloc+0xb8>

0000000080003706 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80003706:	1101                	addi	sp,sp,-32
    80003708:	ec06                	sd	ra,24(sp)
    8000370a:	e822                	sd	s0,16(sp)
    8000370c:	e426                	sd	s1,8(sp)
    8000370e:	e04a                	sd	s2,0(sp)
    80003710:	1000                	addi	s0,sp,32
    80003712:	84aa                	mv	s1,a0
    80003714:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80003716:	0b6020ef          	jal	800057cc <acquire>
  if(writable){
    8000371a:	02090763          	beqz	s2,80003748 <pipeclose+0x42>
    pi->writeopen = 0;
    8000371e:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80003722:	21848513          	addi	a0,s1,536
    80003726:	c7bfd0ef          	jal	800013a0 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    8000372a:	2204a783          	lw	a5,544(s1)
    8000372e:	e781                	bnez	a5,80003736 <pipeclose+0x30>
    80003730:	2244a783          	lw	a5,548(s1)
    80003734:	c38d                	beqz	a5,80003756 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    80003736:	8526                	mv	a0,s1
    80003738:	128020ef          	jal	80005860 <release>
}
    8000373c:	60e2                	ld	ra,24(sp)
    8000373e:	6442                	ld	s0,16(sp)
    80003740:	64a2                	ld	s1,8(sp)
    80003742:	6902                	ld	s2,0(sp)
    80003744:	6105                	addi	sp,sp,32
    80003746:	8082                	ret
    pi->readopen = 0;
    80003748:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    8000374c:	21c48513          	addi	a0,s1,540
    80003750:	c51fd0ef          	jal	800013a0 <wakeup>
    80003754:	bfd9                	j	8000372a <pipeclose+0x24>
    release(&pi->lock);
    80003756:	8526                	mv	a0,s1
    80003758:	108020ef          	jal	80005860 <release>
    kfree((char*)pi);
    8000375c:	8526                	mv	a0,s1
    8000375e:	8bffc0ef          	jal	8000001c <kfree>
    80003762:	bfe9                	j	8000373c <pipeclose+0x36>

0000000080003764 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80003764:	7159                	addi	sp,sp,-112
    80003766:	f486                	sd	ra,104(sp)
    80003768:	f0a2                	sd	s0,96(sp)
    8000376a:	eca6                	sd	s1,88(sp)
    8000376c:	e8ca                	sd	s2,80(sp)
    8000376e:	e4ce                	sd	s3,72(sp)
    80003770:	e0d2                	sd	s4,64(sp)
    80003772:	fc56                	sd	s5,56(sp)
    80003774:	1880                	addi	s0,sp,112
    80003776:	84aa                	mv	s1,a0
    80003778:	8aae                	mv	s5,a1
    8000377a:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000377c:	e06fd0ef          	jal	80000d82 <myproc>
    80003780:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80003782:	8526                	mv	a0,s1
    80003784:	048020ef          	jal	800057cc <acquire>
  while(i < n){
    80003788:	0d405263          	blez	s4,8000384c <pipewrite+0xe8>
    8000378c:	f85a                	sd	s6,48(sp)
    8000378e:	f45e                	sd	s7,40(sp)
    80003790:	f062                	sd	s8,32(sp)
    80003792:	ec66                	sd	s9,24(sp)
    80003794:	e86a                	sd	s10,16(sp)
  int i = 0;
    80003796:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003798:	f9f40c13          	addi	s8,s0,-97
    8000379c:	4b85                	li	s7,1
    8000379e:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800037a0:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    800037a4:	21c48c93          	addi	s9,s1,540
    800037a8:	a82d                	j	800037e2 <pipewrite+0x7e>
      release(&pi->lock);
    800037aa:	8526                	mv	a0,s1
    800037ac:	0b4020ef          	jal	80005860 <release>
      return -1;
    800037b0:	597d                	li	s2,-1
    800037b2:	7b42                	ld	s6,48(sp)
    800037b4:	7ba2                	ld	s7,40(sp)
    800037b6:	7c02                	ld	s8,32(sp)
    800037b8:	6ce2                	ld	s9,24(sp)
    800037ba:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800037bc:	854a                	mv	a0,s2
    800037be:	70a6                	ld	ra,104(sp)
    800037c0:	7406                	ld	s0,96(sp)
    800037c2:	64e6                	ld	s1,88(sp)
    800037c4:	6946                	ld	s2,80(sp)
    800037c6:	69a6                	ld	s3,72(sp)
    800037c8:	6a06                	ld	s4,64(sp)
    800037ca:	7ae2                	ld	s5,56(sp)
    800037cc:	6165                	addi	sp,sp,112
    800037ce:	8082                	ret
      wakeup(&pi->nread);
    800037d0:	856a                	mv	a0,s10
    800037d2:	bcffd0ef          	jal	800013a0 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    800037d6:	85a6                	mv	a1,s1
    800037d8:	8566                	mv	a0,s9
    800037da:	b7bfd0ef          	jal	80001354 <sleep>
  while(i < n){
    800037de:	05495a63          	bge	s2,s4,80003832 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    800037e2:	2204a783          	lw	a5,544(s1)
    800037e6:	d3f1                	beqz	a5,800037aa <pipewrite+0x46>
    800037e8:	854e                	mv	a0,s3
    800037ea:	da7fd0ef          	jal	80001590 <killed>
    800037ee:	fd55                	bnez	a0,800037aa <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    800037f0:	2184a783          	lw	a5,536(s1)
    800037f4:	21c4a703          	lw	a4,540(s1)
    800037f8:	2007879b          	addiw	a5,a5,512
    800037fc:	fcf70ae3          	beq	a4,a5,800037d0 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003800:	86de                	mv	a3,s7
    80003802:	01590633          	add	a2,s2,s5
    80003806:	85e2                	mv	a1,s8
    80003808:	0509b503          	ld	a0,80(s3)
    8000380c:	aa6fd0ef          	jal	80000ab2 <copyin>
    80003810:	05650063          	beq	a0,s6,80003850 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80003814:	21c4a783          	lw	a5,540(s1)
    80003818:	0017871b          	addiw	a4,a5,1
    8000381c:	20e4ae23          	sw	a4,540(s1)
    80003820:	1ff7f793          	andi	a5,a5,511
    80003824:	97a6                	add	a5,a5,s1
    80003826:	f9f44703          	lbu	a4,-97(s0)
    8000382a:	00e78c23          	sb	a4,24(a5)
      i++;
    8000382e:	2905                	addiw	s2,s2,1
    80003830:	b77d                	j	800037de <pipewrite+0x7a>
    80003832:	7b42                	ld	s6,48(sp)
    80003834:	7ba2                	ld	s7,40(sp)
    80003836:	7c02                	ld	s8,32(sp)
    80003838:	6ce2                	ld	s9,24(sp)
    8000383a:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    8000383c:	21848513          	addi	a0,s1,536
    80003840:	b61fd0ef          	jal	800013a0 <wakeup>
  release(&pi->lock);
    80003844:	8526                	mv	a0,s1
    80003846:	01a020ef          	jal	80005860 <release>
  return i;
    8000384a:	bf8d                	j	800037bc <pipewrite+0x58>
  int i = 0;
    8000384c:	4901                	li	s2,0
    8000384e:	b7fd                	j	8000383c <pipewrite+0xd8>
    80003850:	7b42                	ld	s6,48(sp)
    80003852:	7ba2                	ld	s7,40(sp)
    80003854:	7c02                	ld	s8,32(sp)
    80003856:	6ce2                	ld	s9,24(sp)
    80003858:	6d42                	ld	s10,16(sp)
    8000385a:	b7cd                	j	8000383c <pipewrite+0xd8>

000000008000385c <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    8000385c:	711d                	addi	sp,sp,-96
    8000385e:	ec86                	sd	ra,88(sp)
    80003860:	e8a2                	sd	s0,80(sp)
    80003862:	e4a6                	sd	s1,72(sp)
    80003864:	e0ca                	sd	s2,64(sp)
    80003866:	fc4e                	sd	s3,56(sp)
    80003868:	f852                	sd	s4,48(sp)
    8000386a:	f456                	sd	s5,40(sp)
    8000386c:	1080                	addi	s0,sp,96
    8000386e:	84aa                	mv	s1,a0
    80003870:	892e                	mv	s2,a1
    80003872:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80003874:	d0efd0ef          	jal	80000d82 <myproc>
    80003878:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    8000387a:	8526                	mv	a0,s1
    8000387c:	751010ef          	jal	800057cc <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003880:	2184a703          	lw	a4,536(s1)
    80003884:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003888:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000388c:	02f71763          	bne	a4,a5,800038ba <piperead+0x5e>
    80003890:	2244a783          	lw	a5,548(s1)
    80003894:	cf85                	beqz	a5,800038cc <piperead+0x70>
    if(killed(pr)){
    80003896:	8552                	mv	a0,s4
    80003898:	cf9fd0ef          	jal	80001590 <killed>
    8000389c:	e11d                	bnez	a0,800038c2 <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000389e:	85a6                	mv	a1,s1
    800038a0:	854e                	mv	a0,s3
    800038a2:	ab3fd0ef          	jal	80001354 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800038a6:	2184a703          	lw	a4,536(s1)
    800038aa:	21c4a783          	lw	a5,540(s1)
    800038ae:	fef701e3          	beq	a4,a5,80003890 <piperead+0x34>
    800038b2:	f05a                	sd	s6,32(sp)
    800038b4:	ec5e                	sd	s7,24(sp)
    800038b6:	e862                	sd	s8,16(sp)
    800038b8:	a829                	j	800038d2 <piperead+0x76>
    800038ba:	f05a                	sd	s6,32(sp)
    800038bc:	ec5e                	sd	s7,24(sp)
    800038be:	e862                	sd	s8,16(sp)
    800038c0:	a809                	j	800038d2 <piperead+0x76>
      release(&pi->lock);
    800038c2:	8526                	mv	a0,s1
    800038c4:	79d010ef          	jal	80005860 <release>
      return -1;
    800038c8:	59fd                	li	s3,-1
    800038ca:	a09d                	j	80003930 <piperead+0xd4>
    800038cc:	f05a                	sd	s6,32(sp)
    800038ce:	ec5e                	sd	s7,24(sp)
    800038d0:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800038d2:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    800038d4:	faf40c13          	addi	s8,s0,-81
    800038d8:	4b85                	li	s7,1
    800038da:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800038dc:	05505063          	blez	s5,8000391c <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    800038e0:	2184a783          	lw	a5,536(s1)
    800038e4:	21c4a703          	lw	a4,540(s1)
    800038e8:	02f70a63          	beq	a4,a5,8000391c <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    800038ec:	0017871b          	addiw	a4,a5,1
    800038f0:	20e4ac23          	sw	a4,536(s1)
    800038f4:	1ff7f793          	andi	a5,a5,511
    800038f8:	97a6                	add	a5,a5,s1
    800038fa:	0187c783          	lbu	a5,24(a5)
    800038fe:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003902:	86de                	mv	a3,s7
    80003904:	8662                	mv	a2,s8
    80003906:	85ca                	mv	a1,s2
    80003908:	050a3503          	ld	a0,80(s4)
    8000390c:	8f6fd0ef          	jal	80000a02 <copyout>
    80003910:	01650663          	beq	a0,s6,8000391c <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003914:	2985                	addiw	s3,s3,1
    80003916:	0905                	addi	s2,s2,1
    80003918:	fd3a94e3          	bne	s5,s3,800038e0 <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    8000391c:	21c48513          	addi	a0,s1,540
    80003920:	a81fd0ef          	jal	800013a0 <wakeup>
  release(&pi->lock);
    80003924:	8526                	mv	a0,s1
    80003926:	73b010ef          	jal	80005860 <release>
    8000392a:	7b02                	ld	s6,32(sp)
    8000392c:	6be2                	ld	s7,24(sp)
    8000392e:	6c42                	ld	s8,16(sp)
  return i;
}
    80003930:	854e                	mv	a0,s3
    80003932:	60e6                	ld	ra,88(sp)
    80003934:	6446                	ld	s0,80(sp)
    80003936:	64a6                	ld	s1,72(sp)
    80003938:	6906                	ld	s2,64(sp)
    8000393a:	79e2                	ld	s3,56(sp)
    8000393c:	7a42                	ld	s4,48(sp)
    8000393e:	7aa2                	ld	s5,40(sp)
    80003940:	6125                	addi	sp,sp,96
    80003942:	8082                	ret

0000000080003944 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003944:	1141                	addi	sp,sp,-16
    80003946:	e406                	sd	ra,8(sp)
    80003948:	e022                	sd	s0,0(sp)
    8000394a:	0800                	addi	s0,sp,16
    8000394c:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    8000394e:	0035151b          	slliw	a0,a0,0x3
    80003952:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80003954:	8b89                	andi	a5,a5,2
    80003956:	c399                	beqz	a5,8000395c <flags2perm+0x18>
      perm |= PTE_W;
    80003958:	00456513          	ori	a0,a0,4
    return perm;
}
    8000395c:	60a2                	ld	ra,8(sp)
    8000395e:	6402                	ld	s0,0(sp)
    80003960:	0141                	addi	sp,sp,16
    80003962:	8082                	ret

0000000080003964 <exec>:

int
exec(char *path, char **argv)
{
    80003964:	de010113          	addi	sp,sp,-544
    80003968:	20113c23          	sd	ra,536(sp)
    8000396c:	20813823          	sd	s0,528(sp)
    80003970:	20913423          	sd	s1,520(sp)
    80003974:	21213023          	sd	s2,512(sp)
    80003978:	1400                	addi	s0,sp,544
    8000397a:	892a                	mv	s2,a0
    8000397c:	dea43823          	sd	a0,-528(s0)
    80003980:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80003984:	bfefd0ef          	jal	80000d82 <myproc>
    80003988:	84aa                	mv	s1,a0

  begin_op();
    8000398a:	d66ff0ef          	jal	80002ef0 <begin_op>

  if((ip = namei(path)) == 0){
    8000398e:	854a                	mv	a0,s2
    80003990:	b9eff0ef          	jal	80002d2e <namei>
    80003994:	cd21                	beqz	a0,800039ec <exec+0x88>
    80003996:	fbd2                	sd	s4,496(sp)
    80003998:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    8000399a:	c9ffe0ef          	jal	80002638 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    8000399e:	04000713          	li	a4,64
    800039a2:	4681                	li	a3,0
    800039a4:	e5040613          	addi	a2,s0,-432
    800039a8:	4581                	li	a1,0
    800039aa:	8552                	mv	a0,s4
    800039ac:	ee7fe0ef          	jal	80002892 <readi>
    800039b0:	04000793          	li	a5,64
    800039b4:	00f51a63          	bne	a0,a5,800039c8 <exec+0x64>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    800039b8:	e5042703          	lw	a4,-432(s0)
    800039bc:	464c47b7          	lui	a5,0x464c4
    800039c0:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    800039c4:	02f70863          	beq	a4,a5,800039f4 <exec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    800039c8:	8552                	mv	a0,s4
    800039ca:	e7bfe0ef          	jal	80002844 <iunlockput>
    end_op();
    800039ce:	d92ff0ef          	jal	80002f60 <end_op>
  }
  return -1;
    800039d2:	557d                	li	a0,-1
    800039d4:	7a5e                	ld	s4,496(sp)
}
    800039d6:	21813083          	ld	ra,536(sp)
    800039da:	21013403          	ld	s0,528(sp)
    800039de:	20813483          	ld	s1,520(sp)
    800039e2:	20013903          	ld	s2,512(sp)
    800039e6:	22010113          	addi	sp,sp,544
    800039ea:	8082                	ret
    end_op();
    800039ec:	d74ff0ef          	jal	80002f60 <end_op>
    return -1;
    800039f0:	557d                	li	a0,-1
    800039f2:	b7d5                	j	800039d6 <exec+0x72>
    800039f4:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    800039f6:	8526                	mv	a0,s1
    800039f8:	c34fd0ef          	jal	80000e2c <proc_pagetable>
    800039fc:	8b2a                	mv	s6,a0
    800039fe:	26050d63          	beqz	a0,80003c78 <exec+0x314>
    80003a02:	ffce                	sd	s3,504(sp)
    80003a04:	f7d6                	sd	s5,488(sp)
    80003a06:	efde                	sd	s7,472(sp)
    80003a08:	ebe2                	sd	s8,464(sp)
    80003a0a:	e7e6                	sd	s9,456(sp)
    80003a0c:	e3ea                	sd	s10,448(sp)
    80003a0e:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003a10:	e8845783          	lhu	a5,-376(s0)
    80003a14:	0e078963          	beqz	a5,80003b06 <exec+0x1a2>
    80003a18:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003a1c:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003a1e:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003a20:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80003a24:	6c85                	lui	s9,0x1
    80003a26:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80003a2a:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80003a2e:	6a85                	lui	s5,0x1
    80003a30:	a085                	j	80003a90 <exec+0x12c>
      panic("loadseg: address should exist");
    80003a32:	00004517          	auipc	a0,0x4
    80003a36:	b6e50513          	addi	a0,a0,-1170 # 800075a0 <etext+0x5a0>
    80003a3a:	255010ef          	jal	8000548e <panic>
    if(sz - i < PGSIZE)
    80003a3e:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003a40:	874a                	mv	a4,s2
    80003a42:	009b86bb          	addw	a3,s7,s1
    80003a46:	4581                	li	a1,0
    80003a48:	8552                	mv	a0,s4
    80003a4a:	e49fe0ef          	jal	80002892 <readi>
    80003a4e:	22a91963          	bne	s2,a0,80003c80 <exec+0x31c>
  for(i = 0; i < sz; i += PGSIZE){
    80003a52:	009a84bb          	addw	s1,s5,s1
    80003a56:	0334f263          	bgeu	s1,s3,80003a7a <exec+0x116>
    pa = walkaddr(pagetable, va + i);
    80003a5a:	02049593          	slli	a1,s1,0x20
    80003a5e:	9181                	srli	a1,a1,0x20
    80003a60:	95e2                	add	a1,a1,s8
    80003a62:	855a                	mv	a0,s6
    80003a64:	a29fc0ef          	jal	8000048c <walkaddr>
    80003a68:	862a                	mv	a2,a0
    if(pa == 0)
    80003a6a:	d561                	beqz	a0,80003a32 <exec+0xce>
    if(sz - i < PGSIZE)
    80003a6c:	409987bb          	subw	a5,s3,s1
    80003a70:	893e                	mv	s2,a5
    80003a72:	fcfcf6e3          	bgeu	s9,a5,80003a3e <exec+0xda>
    80003a76:	8956                	mv	s2,s5
    80003a78:	b7d9                	j	80003a3e <exec+0xda>
    sz = sz1;
    80003a7a:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003a7e:	2d05                	addiw	s10,s10,1
    80003a80:	e0843783          	ld	a5,-504(s0)
    80003a84:	0387869b          	addiw	a3,a5,56
    80003a88:	e8845783          	lhu	a5,-376(s0)
    80003a8c:	06fd5e63          	bge	s10,a5,80003b08 <exec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003a90:	e0d43423          	sd	a3,-504(s0)
    80003a94:	876e                	mv	a4,s11
    80003a96:	e1840613          	addi	a2,s0,-488
    80003a9a:	4581                	li	a1,0
    80003a9c:	8552                	mv	a0,s4
    80003a9e:	df5fe0ef          	jal	80002892 <readi>
    80003aa2:	1db51d63          	bne	a0,s11,80003c7c <exec+0x318>
    if(ph.type != ELF_PROG_LOAD)
    80003aa6:	e1842783          	lw	a5,-488(s0)
    80003aaa:	4705                	li	a4,1
    80003aac:	fce799e3          	bne	a5,a4,80003a7e <exec+0x11a>
    if(ph.memsz < ph.filesz)
    80003ab0:	e4043483          	ld	s1,-448(s0)
    80003ab4:	e3843783          	ld	a5,-456(s0)
    80003ab8:	1ef4e263          	bltu	s1,a5,80003c9c <exec+0x338>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003abc:	e2843783          	ld	a5,-472(s0)
    80003ac0:	94be                	add	s1,s1,a5
    80003ac2:	1ef4e063          	bltu	s1,a5,80003ca2 <exec+0x33e>
    if(ph.vaddr % PGSIZE != 0)
    80003ac6:	de843703          	ld	a4,-536(s0)
    80003aca:	8ff9                	and	a5,a5,a4
    80003acc:	1c079e63          	bnez	a5,80003ca8 <exec+0x344>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003ad0:	e1c42503          	lw	a0,-484(s0)
    80003ad4:	e71ff0ef          	jal	80003944 <flags2perm>
    80003ad8:	86aa                	mv	a3,a0
    80003ada:	8626                	mv	a2,s1
    80003adc:	85ca                	mv	a1,s2
    80003ade:	855a                	mv	a0,s6
    80003ae0:	d13fc0ef          	jal	800007f2 <uvmalloc>
    80003ae4:	dea43c23          	sd	a0,-520(s0)
    80003ae8:	1c050363          	beqz	a0,80003cae <exec+0x34a>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003aec:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003af0:	00098863          	beqz	s3,80003b00 <exec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003af4:	e2843c03          	ld	s8,-472(s0)
    80003af8:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003afc:	4481                	li	s1,0
    80003afe:	bfb1                	j	80003a5a <exec+0xf6>
    sz = sz1;
    80003b00:	df843903          	ld	s2,-520(s0)
    80003b04:	bfad                	j	80003a7e <exec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003b06:	4901                	li	s2,0
  iunlockput(ip);
    80003b08:	8552                	mv	a0,s4
    80003b0a:	d3bfe0ef          	jal	80002844 <iunlockput>
  end_op();
    80003b0e:	c52ff0ef          	jal	80002f60 <end_op>
  p = myproc();
    80003b12:	a70fd0ef          	jal	80000d82 <myproc>
    80003b16:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80003b18:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003b1c:	6985                	lui	s3,0x1
    80003b1e:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80003b20:	99ca                	add	s3,s3,s2
    80003b22:	77fd                	lui	a5,0xfffff
    80003b24:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003b28:	4691                	li	a3,4
    80003b2a:	660d                	lui	a2,0x3
    80003b2c:	964e                	add	a2,a2,s3
    80003b2e:	85ce                	mv	a1,s3
    80003b30:	855a                	mv	a0,s6
    80003b32:	cc1fc0ef          	jal	800007f2 <uvmalloc>
    80003b36:	8a2a                	mv	s4,a0
    80003b38:	e105                	bnez	a0,80003b58 <exec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80003b3a:	85ce                	mv	a1,s3
    80003b3c:	855a                	mv	a0,s6
    80003b3e:	b72fd0ef          	jal	80000eb0 <proc_freepagetable>
  return -1;
    80003b42:	557d                	li	a0,-1
    80003b44:	79fe                	ld	s3,504(sp)
    80003b46:	7a5e                	ld	s4,496(sp)
    80003b48:	7abe                	ld	s5,488(sp)
    80003b4a:	7b1e                	ld	s6,480(sp)
    80003b4c:	6bfe                	ld	s7,472(sp)
    80003b4e:	6c5e                	ld	s8,464(sp)
    80003b50:	6cbe                	ld	s9,456(sp)
    80003b52:	6d1e                	ld	s10,448(sp)
    80003b54:	7dfa                	ld	s11,440(sp)
    80003b56:	b541                	j	800039d6 <exec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003b58:	75f5                	lui	a1,0xffffd
    80003b5a:	95aa                	add	a1,a1,a0
    80003b5c:	855a                	mv	a0,s6
    80003b5e:	e7bfc0ef          	jal	800009d8 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003b62:	7bf9                	lui	s7,0xffffe
    80003b64:	9bd2                	add	s7,s7,s4
  for(argc = 0; argv[argc]; argc++) {
    80003b66:	e0043783          	ld	a5,-512(s0)
    80003b6a:	6388                	ld	a0,0(a5)
  sp = sz;
    80003b6c:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80003b6e:	4481                	li	s1,0
    ustack[argc] = sp;
    80003b70:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80003b74:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80003b78:	cd21                	beqz	a0,80003bd0 <exec+0x26c>
    sp -= strlen(argv[argc]) + 1;
    80003b7a:	f6efc0ef          	jal	800002e8 <strlen>
    80003b7e:	0015079b          	addiw	a5,a0,1
    80003b82:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003b86:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80003b8a:	13796563          	bltu	s2,s7,80003cb4 <exec+0x350>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003b8e:	e0043d83          	ld	s11,-512(s0)
    80003b92:	000db983          	ld	s3,0(s11)
    80003b96:	854e                	mv	a0,s3
    80003b98:	f50fc0ef          	jal	800002e8 <strlen>
    80003b9c:	0015069b          	addiw	a3,a0,1
    80003ba0:	864e                	mv	a2,s3
    80003ba2:	85ca                	mv	a1,s2
    80003ba4:	855a                	mv	a0,s6
    80003ba6:	e5dfc0ef          	jal	80000a02 <copyout>
    80003baa:	10054763          	bltz	a0,80003cb8 <exec+0x354>
    ustack[argc] = sp;
    80003bae:	00349793          	slli	a5,s1,0x3
    80003bb2:	97e6                	add	a5,a5,s9
    80003bb4:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde3d0>
  for(argc = 0; argv[argc]; argc++) {
    80003bb8:	0485                	addi	s1,s1,1
    80003bba:	008d8793          	addi	a5,s11,8
    80003bbe:	e0f43023          	sd	a5,-512(s0)
    80003bc2:	008db503          	ld	a0,8(s11)
    80003bc6:	c509                	beqz	a0,80003bd0 <exec+0x26c>
    if(argc >= MAXARG)
    80003bc8:	fb8499e3          	bne	s1,s8,80003b7a <exec+0x216>
  sz = sz1;
    80003bcc:	89d2                	mv	s3,s4
    80003bce:	b7b5                	j	80003b3a <exec+0x1d6>
  ustack[argc] = 0;
    80003bd0:	00349793          	slli	a5,s1,0x3
    80003bd4:	f9078793          	addi	a5,a5,-112
    80003bd8:	97a2                	add	a5,a5,s0
    80003bda:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80003bde:	00349693          	slli	a3,s1,0x3
    80003be2:	06a1                	addi	a3,a3,8
    80003be4:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003be8:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80003bec:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80003bee:	f57966e3          	bltu	s2,s7,80003b3a <exec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003bf2:	e9040613          	addi	a2,s0,-368
    80003bf6:	85ca                	mv	a1,s2
    80003bf8:	855a                	mv	a0,s6
    80003bfa:	e09fc0ef          	jal	80000a02 <copyout>
    80003bfe:	f2054ee3          	bltz	a0,80003b3a <exec+0x1d6>
  p->trapframe->a1 = sp;
    80003c02:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80003c06:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003c0a:	df043783          	ld	a5,-528(s0)
    80003c0e:	0007c703          	lbu	a4,0(a5)
    80003c12:	cf11                	beqz	a4,80003c2e <exec+0x2ca>
    80003c14:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003c16:	02f00693          	li	a3,47
    80003c1a:	a029                	j	80003c24 <exec+0x2c0>
  for(last=s=path; *s; s++)
    80003c1c:	0785                	addi	a5,a5,1
    80003c1e:	fff7c703          	lbu	a4,-1(a5)
    80003c22:	c711                	beqz	a4,80003c2e <exec+0x2ca>
    if(*s == '/')
    80003c24:	fed71ce3          	bne	a4,a3,80003c1c <exec+0x2b8>
      last = s+1;
    80003c28:	def43823          	sd	a5,-528(s0)
    80003c2c:	bfc5                	j	80003c1c <exec+0x2b8>
  safestrcpy(p->name, last, sizeof(p->name));
    80003c2e:	4641                	li	a2,16
    80003c30:	df043583          	ld	a1,-528(s0)
    80003c34:	158a8513          	addi	a0,s5,344
    80003c38:	e7afc0ef          	jal	800002b2 <safestrcpy>
  oldpagetable = p->pagetable;
    80003c3c:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80003c40:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80003c44:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003c48:	058ab783          	ld	a5,88(s5)
    80003c4c:	e6843703          	ld	a4,-408(s0)
    80003c50:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003c52:	058ab783          	ld	a5,88(s5)
    80003c56:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003c5a:	85ea                	mv	a1,s10
    80003c5c:	a54fd0ef          	jal	80000eb0 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003c60:	0004851b          	sext.w	a0,s1
    80003c64:	79fe                	ld	s3,504(sp)
    80003c66:	7a5e                	ld	s4,496(sp)
    80003c68:	7abe                	ld	s5,488(sp)
    80003c6a:	7b1e                	ld	s6,480(sp)
    80003c6c:	6bfe                	ld	s7,472(sp)
    80003c6e:	6c5e                	ld	s8,464(sp)
    80003c70:	6cbe                	ld	s9,456(sp)
    80003c72:	6d1e                	ld	s10,448(sp)
    80003c74:	7dfa                	ld	s11,440(sp)
    80003c76:	b385                	j	800039d6 <exec+0x72>
    80003c78:	7b1e                	ld	s6,480(sp)
    80003c7a:	b3b9                	j	800039c8 <exec+0x64>
    80003c7c:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003c80:	df843583          	ld	a1,-520(s0)
    80003c84:	855a                	mv	a0,s6
    80003c86:	a2afd0ef          	jal	80000eb0 <proc_freepagetable>
  if(ip){
    80003c8a:	79fe                	ld	s3,504(sp)
    80003c8c:	7abe                	ld	s5,488(sp)
    80003c8e:	7b1e                	ld	s6,480(sp)
    80003c90:	6bfe                	ld	s7,472(sp)
    80003c92:	6c5e                	ld	s8,464(sp)
    80003c94:	6cbe                	ld	s9,456(sp)
    80003c96:	6d1e                	ld	s10,448(sp)
    80003c98:	7dfa                	ld	s11,440(sp)
    80003c9a:	b33d                	j	800039c8 <exec+0x64>
    80003c9c:	df243c23          	sd	s2,-520(s0)
    80003ca0:	b7c5                	j	80003c80 <exec+0x31c>
    80003ca2:	df243c23          	sd	s2,-520(s0)
    80003ca6:	bfe9                	j	80003c80 <exec+0x31c>
    80003ca8:	df243c23          	sd	s2,-520(s0)
    80003cac:	bfd1                	j	80003c80 <exec+0x31c>
    80003cae:	df243c23          	sd	s2,-520(s0)
    80003cb2:	b7f9                	j	80003c80 <exec+0x31c>
  sz = sz1;
    80003cb4:	89d2                	mv	s3,s4
    80003cb6:	b551                	j	80003b3a <exec+0x1d6>
    80003cb8:	89d2                	mv	s3,s4
    80003cba:	b541                	j	80003b3a <exec+0x1d6>

0000000080003cbc <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003cbc:	7179                	addi	sp,sp,-48
    80003cbe:	f406                	sd	ra,40(sp)
    80003cc0:	f022                	sd	s0,32(sp)
    80003cc2:	ec26                	sd	s1,24(sp)
    80003cc4:	e84a                	sd	s2,16(sp)
    80003cc6:	1800                	addi	s0,sp,48
    80003cc8:	892e                	mv	s2,a1
    80003cca:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003ccc:	fdc40593          	addi	a1,s0,-36
    80003cd0:	f73fd0ef          	jal	80001c42 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003cd4:	fdc42703          	lw	a4,-36(s0)
    80003cd8:	47bd                	li	a5,15
    80003cda:	02e7ea63          	bltu	a5,a4,80003d0e <argfd+0x52>
    80003cde:	8a4fd0ef          	jal	80000d82 <myproc>
    80003ce2:	fdc42703          	lw	a4,-36(s0)
    80003ce6:	00371793          	slli	a5,a4,0x3
    80003cea:	0d078793          	addi	a5,a5,208
    80003cee:	953e                	add	a0,a0,a5
    80003cf0:	611c                	ld	a5,0(a0)
    80003cf2:	c385                	beqz	a5,80003d12 <argfd+0x56>
    return -1;
  if(pfd)
    80003cf4:	00090463          	beqz	s2,80003cfc <argfd+0x40>
    *pfd = fd;
    80003cf8:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003cfc:	4501                	li	a0,0
  if(pf)
    80003cfe:	c091                	beqz	s1,80003d02 <argfd+0x46>
    *pf = f;
    80003d00:	e09c                	sd	a5,0(s1)
}
    80003d02:	70a2                	ld	ra,40(sp)
    80003d04:	7402                	ld	s0,32(sp)
    80003d06:	64e2                	ld	s1,24(sp)
    80003d08:	6942                	ld	s2,16(sp)
    80003d0a:	6145                	addi	sp,sp,48
    80003d0c:	8082                	ret
    return -1;
    80003d0e:	557d                	li	a0,-1
    80003d10:	bfcd                	j	80003d02 <argfd+0x46>
    80003d12:	557d                	li	a0,-1
    80003d14:	b7fd                	j	80003d02 <argfd+0x46>

0000000080003d16 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003d16:	1101                	addi	sp,sp,-32
    80003d18:	ec06                	sd	ra,24(sp)
    80003d1a:	e822                	sd	s0,16(sp)
    80003d1c:	e426                	sd	s1,8(sp)
    80003d1e:	1000                	addi	s0,sp,32
    80003d20:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003d22:	860fd0ef          	jal	80000d82 <myproc>
    80003d26:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003d28:	0d050793          	addi	a5,a0,208
    80003d2c:	4501                	li	a0,0
    80003d2e:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003d30:	6398                	ld	a4,0(a5)
    80003d32:	cb19                	beqz	a4,80003d48 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003d34:	2505                	addiw	a0,a0,1
    80003d36:	07a1                	addi	a5,a5,8
    80003d38:	fed51ce3          	bne	a0,a3,80003d30 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003d3c:	557d                	li	a0,-1
}
    80003d3e:	60e2                	ld	ra,24(sp)
    80003d40:	6442                	ld	s0,16(sp)
    80003d42:	64a2                	ld	s1,8(sp)
    80003d44:	6105                	addi	sp,sp,32
    80003d46:	8082                	ret
      p->ofile[fd] = f;
    80003d48:	00351793          	slli	a5,a0,0x3
    80003d4c:	0d078793          	addi	a5,a5,208
    80003d50:	963e                	add	a2,a2,a5
    80003d52:	e204                	sd	s1,0(a2)
      return fd;
    80003d54:	b7ed                	j	80003d3e <fdalloc+0x28>

0000000080003d56 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003d56:	715d                	addi	sp,sp,-80
    80003d58:	e486                	sd	ra,72(sp)
    80003d5a:	e0a2                	sd	s0,64(sp)
    80003d5c:	fc26                	sd	s1,56(sp)
    80003d5e:	f84a                	sd	s2,48(sp)
    80003d60:	f44e                	sd	s3,40(sp)
    80003d62:	f052                	sd	s4,32(sp)
    80003d64:	ec56                	sd	s5,24(sp)
    80003d66:	e85a                	sd	s6,16(sp)
    80003d68:	0880                	addi	s0,sp,80
    80003d6a:	892e                	mv	s2,a1
    80003d6c:	8a2e                	mv	s4,a1
    80003d6e:	8ab2                	mv	s5,a2
    80003d70:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003d72:	fb040593          	addi	a1,s0,-80
    80003d76:	fd3fe0ef          	jal	80002d48 <nameiparent>
    80003d7a:	84aa                	mv	s1,a0
    80003d7c:	10050763          	beqz	a0,80003e8a <create+0x134>
    return 0;

  ilock(dp);
    80003d80:	8b9fe0ef          	jal	80002638 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003d84:	4601                	li	a2,0
    80003d86:	fb040593          	addi	a1,s0,-80
    80003d8a:	8526                	mv	a0,s1
    80003d8c:	d0ffe0ef          	jal	80002a9a <dirlookup>
    80003d90:	89aa                	mv	s3,a0
    80003d92:	c131                	beqz	a0,80003dd6 <create+0x80>
    iunlockput(dp);
    80003d94:	8526                	mv	a0,s1
    80003d96:	aaffe0ef          	jal	80002844 <iunlockput>
    ilock(ip);
    80003d9a:	854e                	mv	a0,s3
    80003d9c:	89dfe0ef          	jal	80002638 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80003da0:	4789                	li	a5,2
    80003da2:	02f91563          	bne	s2,a5,80003dcc <create+0x76>
    80003da6:	0449d783          	lhu	a5,68(s3)
    80003daa:	37f9                	addiw	a5,a5,-2
    80003dac:	17c2                	slli	a5,a5,0x30
    80003dae:	93c1                	srli	a5,a5,0x30
    80003db0:	4705                	li	a4,1
    80003db2:	00f76d63          	bltu	a4,a5,80003dcc <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80003db6:	854e                	mv	a0,s3
    80003db8:	60a6                	ld	ra,72(sp)
    80003dba:	6406                	ld	s0,64(sp)
    80003dbc:	74e2                	ld	s1,56(sp)
    80003dbe:	7942                	ld	s2,48(sp)
    80003dc0:	79a2                	ld	s3,40(sp)
    80003dc2:	7a02                	ld	s4,32(sp)
    80003dc4:	6ae2                	ld	s5,24(sp)
    80003dc6:	6b42                	ld	s6,16(sp)
    80003dc8:	6161                	addi	sp,sp,80
    80003dca:	8082                	ret
    iunlockput(ip);
    80003dcc:	854e                	mv	a0,s3
    80003dce:	a77fe0ef          	jal	80002844 <iunlockput>
    return 0;
    80003dd2:	4981                	li	s3,0
    80003dd4:	b7cd                	j	80003db6 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80003dd6:	85ca                	mv	a1,s2
    80003dd8:	4088                	lw	a0,0(s1)
    80003dda:	eeefe0ef          	jal	800024c8 <ialloc>
    80003dde:	892a                	mv	s2,a0
    80003de0:	cd15                	beqz	a0,80003e1c <create+0xc6>
  ilock(ip);
    80003de2:	857fe0ef          	jal	80002638 <ilock>
  ip->major = major;
    80003de6:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80003dea:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80003dee:	4785                	li	a5,1
    80003df0:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80003df4:	854a                	mv	a0,s2
    80003df6:	f8efe0ef          	jal	80002584 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80003dfa:	4705                	li	a4,1
    80003dfc:	02ea0463          	beq	s4,a4,80003e24 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80003e00:	00492603          	lw	a2,4(s2)
    80003e04:	fb040593          	addi	a1,s0,-80
    80003e08:	8526                	mv	a0,s1
    80003e0a:	e7bfe0ef          	jal	80002c84 <dirlink>
    80003e0e:	06054263          	bltz	a0,80003e72 <create+0x11c>
  iunlockput(dp);
    80003e12:	8526                	mv	a0,s1
    80003e14:	a31fe0ef          	jal	80002844 <iunlockput>
  return ip;
    80003e18:	89ca                	mv	s3,s2
    80003e1a:	bf71                	j	80003db6 <create+0x60>
    iunlockput(dp);
    80003e1c:	8526                	mv	a0,s1
    80003e1e:	a27fe0ef          	jal	80002844 <iunlockput>
    return 0;
    80003e22:	bf51                	j	80003db6 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80003e24:	00492603          	lw	a2,4(s2)
    80003e28:	00003597          	auipc	a1,0x3
    80003e2c:	79858593          	addi	a1,a1,1944 # 800075c0 <etext+0x5c0>
    80003e30:	854a                	mv	a0,s2
    80003e32:	e53fe0ef          	jal	80002c84 <dirlink>
    80003e36:	02054e63          	bltz	a0,80003e72 <create+0x11c>
    80003e3a:	40d0                	lw	a2,4(s1)
    80003e3c:	00003597          	auipc	a1,0x3
    80003e40:	78c58593          	addi	a1,a1,1932 # 800075c8 <etext+0x5c8>
    80003e44:	854a                	mv	a0,s2
    80003e46:	e3ffe0ef          	jal	80002c84 <dirlink>
    80003e4a:	02054463          	bltz	a0,80003e72 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80003e4e:	00492603          	lw	a2,4(s2)
    80003e52:	fb040593          	addi	a1,s0,-80
    80003e56:	8526                	mv	a0,s1
    80003e58:	e2dfe0ef          	jal	80002c84 <dirlink>
    80003e5c:	00054b63          	bltz	a0,80003e72 <create+0x11c>
    dp->nlink++;  // for ".."
    80003e60:	04a4d783          	lhu	a5,74(s1)
    80003e64:	2785                	addiw	a5,a5,1
    80003e66:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80003e6a:	8526                	mv	a0,s1
    80003e6c:	f18fe0ef          	jal	80002584 <iupdate>
    80003e70:	b74d                	j	80003e12 <create+0xbc>
  ip->nlink = 0;
    80003e72:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80003e76:	854a                	mv	a0,s2
    80003e78:	f0cfe0ef          	jal	80002584 <iupdate>
  iunlockput(ip);
    80003e7c:	854a                	mv	a0,s2
    80003e7e:	9c7fe0ef          	jal	80002844 <iunlockput>
  iunlockput(dp);
    80003e82:	8526                	mv	a0,s1
    80003e84:	9c1fe0ef          	jal	80002844 <iunlockput>
  return 0;
    80003e88:	b73d                	j	80003db6 <create+0x60>
    return 0;
    80003e8a:	89aa                	mv	s3,a0
    80003e8c:	b72d                	j	80003db6 <create+0x60>

0000000080003e8e <sys_dup>:
{
    80003e8e:	7179                	addi	sp,sp,-48
    80003e90:	f406                	sd	ra,40(sp)
    80003e92:	f022                	sd	s0,32(sp)
    80003e94:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80003e96:	fd840613          	addi	a2,s0,-40
    80003e9a:	4581                	li	a1,0
    80003e9c:	4501                	li	a0,0
    80003e9e:	e1fff0ef          	jal	80003cbc <argfd>
    return -1;
    80003ea2:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80003ea4:	02054363          	bltz	a0,80003eca <sys_dup+0x3c>
    80003ea8:	ec26                	sd	s1,24(sp)
    80003eaa:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80003eac:	fd843483          	ld	s1,-40(s0)
    80003eb0:	8526                	mv	a0,s1
    80003eb2:	e65ff0ef          	jal	80003d16 <fdalloc>
    80003eb6:	892a                	mv	s2,a0
    return -1;
    80003eb8:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80003eba:	00054d63          	bltz	a0,80003ed4 <sys_dup+0x46>
  filedup(f);
    80003ebe:	8526                	mv	a0,s1
    80003ec0:	c1cff0ef          	jal	800032dc <filedup>
  return fd;
    80003ec4:	87ca                	mv	a5,s2
    80003ec6:	64e2                	ld	s1,24(sp)
    80003ec8:	6942                	ld	s2,16(sp)
}
    80003eca:	853e                	mv	a0,a5
    80003ecc:	70a2                	ld	ra,40(sp)
    80003ece:	7402                	ld	s0,32(sp)
    80003ed0:	6145                	addi	sp,sp,48
    80003ed2:	8082                	ret
    80003ed4:	64e2                	ld	s1,24(sp)
    80003ed6:	6942                	ld	s2,16(sp)
    80003ed8:	bfcd                	j	80003eca <sys_dup+0x3c>

0000000080003eda <sys_read>:
{
    80003eda:	7179                	addi	sp,sp,-48
    80003edc:	f406                	sd	ra,40(sp)
    80003ede:	f022                	sd	s0,32(sp)
    80003ee0:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80003ee2:	fd840593          	addi	a1,s0,-40
    80003ee6:	4505                	li	a0,1
    80003ee8:	d77fd0ef          	jal	80001c5e <argaddr>
  argint(2, &n);
    80003eec:	fe440593          	addi	a1,s0,-28
    80003ef0:	4509                	li	a0,2
    80003ef2:	d51fd0ef          	jal	80001c42 <argint>
  if(argfd(0, 0, &f) < 0)
    80003ef6:	fe840613          	addi	a2,s0,-24
    80003efa:	4581                	li	a1,0
    80003efc:	4501                	li	a0,0
    80003efe:	dbfff0ef          	jal	80003cbc <argfd>
    80003f02:	87aa                	mv	a5,a0
    return -1;
    80003f04:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80003f06:	0007ca63          	bltz	a5,80003f1a <sys_read+0x40>
  return fileread(f, p, n);
    80003f0a:	fe442603          	lw	a2,-28(s0)
    80003f0e:	fd843583          	ld	a1,-40(s0)
    80003f12:	fe843503          	ld	a0,-24(s0)
    80003f16:	d30ff0ef          	jal	80003446 <fileread>
}
    80003f1a:	70a2                	ld	ra,40(sp)
    80003f1c:	7402                	ld	s0,32(sp)
    80003f1e:	6145                	addi	sp,sp,48
    80003f20:	8082                	ret

0000000080003f22 <sys_write>:
{
    80003f22:	7179                	addi	sp,sp,-48
    80003f24:	f406                	sd	ra,40(sp)
    80003f26:	f022                	sd	s0,32(sp)
    80003f28:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80003f2a:	fd840593          	addi	a1,s0,-40
    80003f2e:	4505                	li	a0,1
    80003f30:	d2ffd0ef          	jal	80001c5e <argaddr>
  argint(2, &n);
    80003f34:	fe440593          	addi	a1,s0,-28
    80003f38:	4509                	li	a0,2
    80003f3a:	d09fd0ef          	jal	80001c42 <argint>
  if(argfd(0, 0, &f) < 0)
    80003f3e:	fe840613          	addi	a2,s0,-24
    80003f42:	4581                	li	a1,0
    80003f44:	4501                	li	a0,0
    80003f46:	d77ff0ef          	jal	80003cbc <argfd>
    80003f4a:	87aa                	mv	a5,a0
    return -1;
    80003f4c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80003f4e:	0007ca63          	bltz	a5,80003f62 <sys_write+0x40>
  return filewrite(f, p, n);
    80003f52:	fe442603          	lw	a2,-28(s0)
    80003f56:	fd843583          	ld	a1,-40(s0)
    80003f5a:	fe843503          	ld	a0,-24(s0)
    80003f5e:	dacff0ef          	jal	8000350a <filewrite>
}
    80003f62:	70a2                	ld	ra,40(sp)
    80003f64:	7402                	ld	s0,32(sp)
    80003f66:	6145                	addi	sp,sp,48
    80003f68:	8082                	ret

0000000080003f6a <sys_close>:
{
    80003f6a:	1101                	addi	sp,sp,-32
    80003f6c:	ec06                	sd	ra,24(sp)
    80003f6e:	e822                	sd	s0,16(sp)
    80003f70:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80003f72:	fe040613          	addi	a2,s0,-32
    80003f76:	fec40593          	addi	a1,s0,-20
    80003f7a:	4501                	li	a0,0
    80003f7c:	d41ff0ef          	jal	80003cbc <argfd>
    return -1;
    80003f80:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80003f82:	02054163          	bltz	a0,80003fa4 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80003f86:	dfdfc0ef          	jal	80000d82 <myproc>
    80003f8a:	fec42783          	lw	a5,-20(s0)
    80003f8e:	078e                	slli	a5,a5,0x3
    80003f90:	0d078793          	addi	a5,a5,208
    80003f94:	953e                	add	a0,a0,a5
    80003f96:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80003f9a:	fe043503          	ld	a0,-32(s0)
    80003f9e:	b84ff0ef          	jal	80003322 <fileclose>
  return 0;
    80003fa2:	4781                	li	a5,0
}
    80003fa4:	853e                	mv	a0,a5
    80003fa6:	60e2                	ld	ra,24(sp)
    80003fa8:	6442                	ld	s0,16(sp)
    80003faa:	6105                	addi	sp,sp,32
    80003fac:	8082                	ret

0000000080003fae <sys_fstat>:
{
    80003fae:	1101                	addi	sp,sp,-32
    80003fb0:	ec06                	sd	ra,24(sp)
    80003fb2:	e822                	sd	s0,16(sp)
    80003fb4:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80003fb6:	fe040593          	addi	a1,s0,-32
    80003fba:	4505                	li	a0,1
    80003fbc:	ca3fd0ef          	jal	80001c5e <argaddr>
  if(argfd(0, 0, &f) < 0)
    80003fc0:	fe840613          	addi	a2,s0,-24
    80003fc4:	4581                	li	a1,0
    80003fc6:	4501                	li	a0,0
    80003fc8:	cf5ff0ef          	jal	80003cbc <argfd>
    80003fcc:	87aa                	mv	a5,a0
    return -1;
    80003fce:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80003fd0:	0007c863          	bltz	a5,80003fe0 <sys_fstat+0x32>
  return filestat(f, st);
    80003fd4:	fe043583          	ld	a1,-32(s0)
    80003fd8:	fe843503          	ld	a0,-24(s0)
    80003fdc:	c08ff0ef          	jal	800033e4 <filestat>
}
    80003fe0:	60e2                	ld	ra,24(sp)
    80003fe2:	6442                	ld	s0,16(sp)
    80003fe4:	6105                	addi	sp,sp,32
    80003fe6:	8082                	ret

0000000080003fe8 <sys_link>:
{
    80003fe8:	7169                	addi	sp,sp,-304
    80003fea:	f606                	sd	ra,296(sp)
    80003fec:	f222                	sd	s0,288(sp)
    80003fee:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80003ff0:	08000613          	li	a2,128
    80003ff4:	ed040593          	addi	a1,s0,-304
    80003ff8:	4501                	li	a0,0
    80003ffa:	c81fd0ef          	jal	80001c7a <argstr>
    return -1;
    80003ffe:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004000:	0c054e63          	bltz	a0,800040dc <sys_link+0xf4>
    80004004:	08000613          	li	a2,128
    80004008:	f5040593          	addi	a1,s0,-176
    8000400c:	4505                	li	a0,1
    8000400e:	c6dfd0ef          	jal	80001c7a <argstr>
    return -1;
    80004012:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004014:	0c054463          	bltz	a0,800040dc <sys_link+0xf4>
    80004018:	ee26                	sd	s1,280(sp)
  begin_op();
    8000401a:	ed7fe0ef          	jal	80002ef0 <begin_op>
  if((ip = namei(old)) == 0){
    8000401e:	ed040513          	addi	a0,s0,-304
    80004022:	d0dfe0ef          	jal	80002d2e <namei>
    80004026:	84aa                	mv	s1,a0
    80004028:	c53d                	beqz	a0,80004096 <sys_link+0xae>
  ilock(ip);
    8000402a:	e0efe0ef          	jal	80002638 <ilock>
  if(ip->type == T_DIR){
    8000402e:	04449703          	lh	a4,68(s1)
    80004032:	4785                	li	a5,1
    80004034:	06f70663          	beq	a4,a5,800040a0 <sys_link+0xb8>
    80004038:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    8000403a:	04a4d783          	lhu	a5,74(s1)
    8000403e:	2785                	addiw	a5,a5,1
    80004040:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004044:	8526                	mv	a0,s1
    80004046:	d3efe0ef          	jal	80002584 <iupdate>
  iunlock(ip);
    8000404a:	8526                	mv	a0,s1
    8000404c:	e9afe0ef          	jal	800026e6 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004050:	fd040593          	addi	a1,s0,-48
    80004054:	f5040513          	addi	a0,s0,-176
    80004058:	cf1fe0ef          	jal	80002d48 <nameiparent>
    8000405c:	892a                	mv	s2,a0
    8000405e:	cd21                	beqz	a0,800040b6 <sys_link+0xce>
  ilock(dp);
    80004060:	dd8fe0ef          	jal	80002638 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004064:	854a                	mv	a0,s2
    80004066:	00092703          	lw	a4,0(s2)
    8000406a:	409c                	lw	a5,0(s1)
    8000406c:	04f71263          	bne	a4,a5,800040b0 <sys_link+0xc8>
    80004070:	40d0                	lw	a2,4(s1)
    80004072:	fd040593          	addi	a1,s0,-48
    80004076:	c0ffe0ef          	jal	80002c84 <dirlink>
    8000407a:	02054b63          	bltz	a0,800040b0 <sys_link+0xc8>
  iunlockput(dp);
    8000407e:	854a                	mv	a0,s2
    80004080:	fc4fe0ef          	jal	80002844 <iunlockput>
  iput(ip);
    80004084:	8526                	mv	a0,s1
    80004086:	f34fe0ef          	jal	800027ba <iput>
  end_op();
    8000408a:	ed7fe0ef          	jal	80002f60 <end_op>
  return 0;
    8000408e:	4781                	li	a5,0
    80004090:	64f2                	ld	s1,280(sp)
    80004092:	6952                	ld	s2,272(sp)
    80004094:	a0a1                	j	800040dc <sys_link+0xf4>
    end_op();
    80004096:	ecbfe0ef          	jal	80002f60 <end_op>
    return -1;
    8000409a:	57fd                	li	a5,-1
    8000409c:	64f2                	ld	s1,280(sp)
    8000409e:	a83d                	j	800040dc <sys_link+0xf4>
    iunlockput(ip);
    800040a0:	8526                	mv	a0,s1
    800040a2:	fa2fe0ef          	jal	80002844 <iunlockput>
    end_op();
    800040a6:	ebbfe0ef          	jal	80002f60 <end_op>
    return -1;
    800040aa:	57fd                	li	a5,-1
    800040ac:	64f2                	ld	s1,280(sp)
    800040ae:	a03d                	j	800040dc <sys_link+0xf4>
    iunlockput(dp);
    800040b0:	854a                	mv	a0,s2
    800040b2:	f92fe0ef          	jal	80002844 <iunlockput>
  ilock(ip);
    800040b6:	8526                	mv	a0,s1
    800040b8:	d80fe0ef          	jal	80002638 <ilock>
  ip->nlink--;
    800040bc:	04a4d783          	lhu	a5,74(s1)
    800040c0:	37fd                	addiw	a5,a5,-1
    800040c2:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800040c6:	8526                	mv	a0,s1
    800040c8:	cbcfe0ef          	jal	80002584 <iupdate>
  iunlockput(ip);
    800040cc:	8526                	mv	a0,s1
    800040ce:	f76fe0ef          	jal	80002844 <iunlockput>
  end_op();
    800040d2:	e8ffe0ef          	jal	80002f60 <end_op>
  return -1;
    800040d6:	57fd                	li	a5,-1
    800040d8:	64f2                	ld	s1,280(sp)
    800040da:	6952                	ld	s2,272(sp)
}
    800040dc:	853e                	mv	a0,a5
    800040de:	70b2                	ld	ra,296(sp)
    800040e0:	7412                	ld	s0,288(sp)
    800040e2:	6155                	addi	sp,sp,304
    800040e4:	8082                	ret

00000000800040e6 <sys_unlink>:
{
    800040e6:	7151                	addi	sp,sp,-240
    800040e8:	f586                	sd	ra,232(sp)
    800040ea:	f1a2                	sd	s0,224(sp)
    800040ec:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    800040ee:	08000613          	li	a2,128
    800040f2:	f3040593          	addi	a1,s0,-208
    800040f6:	4501                	li	a0,0
    800040f8:	b83fd0ef          	jal	80001c7a <argstr>
    800040fc:	14054d63          	bltz	a0,80004256 <sys_unlink+0x170>
    80004100:	eda6                	sd	s1,216(sp)
  begin_op();
    80004102:	deffe0ef          	jal	80002ef0 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004106:	fb040593          	addi	a1,s0,-80
    8000410a:	f3040513          	addi	a0,s0,-208
    8000410e:	c3bfe0ef          	jal	80002d48 <nameiparent>
    80004112:	84aa                	mv	s1,a0
    80004114:	c955                	beqz	a0,800041c8 <sys_unlink+0xe2>
  ilock(dp);
    80004116:	d22fe0ef          	jal	80002638 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000411a:	00003597          	auipc	a1,0x3
    8000411e:	4a658593          	addi	a1,a1,1190 # 800075c0 <etext+0x5c0>
    80004122:	fb040513          	addi	a0,s0,-80
    80004126:	95ffe0ef          	jal	80002a84 <namecmp>
    8000412a:	10050b63          	beqz	a0,80004240 <sys_unlink+0x15a>
    8000412e:	00003597          	auipc	a1,0x3
    80004132:	49a58593          	addi	a1,a1,1178 # 800075c8 <etext+0x5c8>
    80004136:	fb040513          	addi	a0,s0,-80
    8000413a:	94bfe0ef          	jal	80002a84 <namecmp>
    8000413e:	10050163          	beqz	a0,80004240 <sys_unlink+0x15a>
    80004142:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004144:	f2c40613          	addi	a2,s0,-212
    80004148:	fb040593          	addi	a1,s0,-80
    8000414c:	8526                	mv	a0,s1
    8000414e:	94dfe0ef          	jal	80002a9a <dirlookup>
    80004152:	892a                	mv	s2,a0
    80004154:	0e050563          	beqz	a0,8000423e <sys_unlink+0x158>
    80004158:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    8000415a:	cdefe0ef          	jal	80002638 <ilock>
  if(ip->nlink < 1)
    8000415e:	04a91783          	lh	a5,74(s2)
    80004162:	06f05863          	blez	a5,800041d2 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004166:	04491703          	lh	a4,68(s2)
    8000416a:	4785                	li	a5,1
    8000416c:	06f70963          	beq	a4,a5,800041de <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80004170:	fc040993          	addi	s3,s0,-64
    80004174:	4641                	li	a2,16
    80004176:	4581                	li	a1,0
    80004178:	854e                	mv	a0,s3
    8000417a:	fe5fb0ef          	jal	8000015e <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000417e:	4741                	li	a4,16
    80004180:	f2c42683          	lw	a3,-212(s0)
    80004184:	864e                	mv	a2,s3
    80004186:	4581                	li	a1,0
    80004188:	8526                	mv	a0,s1
    8000418a:	ffafe0ef          	jal	80002984 <writei>
    8000418e:	47c1                	li	a5,16
    80004190:	08f51863          	bne	a0,a5,80004220 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    80004194:	04491703          	lh	a4,68(s2)
    80004198:	4785                	li	a5,1
    8000419a:	08f70963          	beq	a4,a5,8000422c <sys_unlink+0x146>
  iunlockput(dp);
    8000419e:	8526                	mv	a0,s1
    800041a0:	ea4fe0ef          	jal	80002844 <iunlockput>
  ip->nlink--;
    800041a4:	04a95783          	lhu	a5,74(s2)
    800041a8:	37fd                	addiw	a5,a5,-1
    800041aa:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800041ae:	854a                	mv	a0,s2
    800041b0:	bd4fe0ef          	jal	80002584 <iupdate>
  iunlockput(ip);
    800041b4:	854a                	mv	a0,s2
    800041b6:	e8efe0ef          	jal	80002844 <iunlockput>
  end_op();
    800041ba:	da7fe0ef          	jal	80002f60 <end_op>
  return 0;
    800041be:	4501                	li	a0,0
    800041c0:	64ee                	ld	s1,216(sp)
    800041c2:	694e                	ld	s2,208(sp)
    800041c4:	69ae                	ld	s3,200(sp)
    800041c6:	a061                	j	8000424e <sys_unlink+0x168>
    end_op();
    800041c8:	d99fe0ef          	jal	80002f60 <end_op>
    return -1;
    800041cc:	557d                	li	a0,-1
    800041ce:	64ee                	ld	s1,216(sp)
    800041d0:	a8bd                	j	8000424e <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    800041d2:	00003517          	auipc	a0,0x3
    800041d6:	3fe50513          	addi	a0,a0,1022 # 800075d0 <etext+0x5d0>
    800041da:	2b4010ef          	jal	8000548e <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800041de:	04c92703          	lw	a4,76(s2)
    800041e2:	02000793          	li	a5,32
    800041e6:	f8e7f5e3          	bgeu	a5,a4,80004170 <sys_unlink+0x8a>
    800041ea:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800041ec:	4741                	li	a4,16
    800041ee:	86ce                	mv	a3,s3
    800041f0:	f1840613          	addi	a2,s0,-232
    800041f4:	4581                	li	a1,0
    800041f6:	854a                	mv	a0,s2
    800041f8:	e9afe0ef          	jal	80002892 <readi>
    800041fc:	47c1                	li	a5,16
    800041fe:	00f51b63          	bne	a0,a5,80004214 <sys_unlink+0x12e>
    if(de.inum != 0)
    80004202:	f1845783          	lhu	a5,-232(s0)
    80004206:	ebb1                	bnez	a5,8000425a <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004208:	29c1                	addiw	s3,s3,16
    8000420a:	04c92783          	lw	a5,76(s2)
    8000420e:	fcf9efe3          	bltu	s3,a5,800041ec <sys_unlink+0x106>
    80004212:	bfb9                	j	80004170 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004214:	00003517          	auipc	a0,0x3
    80004218:	3d450513          	addi	a0,a0,980 # 800075e8 <etext+0x5e8>
    8000421c:	272010ef          	jal	8000548e <panic>
    panic("unlink: writei");
    80004220:	00003517          	auipc	a0,0x3
    80004224:	3e050513          	addi	a0,a0,992 # 80007600 <etext+0x600>
    80004228:	266010ef          	jal	8000548e <panic>
    dp->nlink--;
    8000422c:	04a4d783          	lhu	a5,74(s1)
    80004230:	37fd                	addiw	a5,a5,-1
    80004232:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004236:	8526                	mv	a0,s1
    80004238:	b4cfe0ef          	jal	80002584 <iupdate>
    8000423c:	b78d                	j	8000419e <sys_unlink+0xb8>
    8000423e:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004240:	8526                	mv	a0,s1
    80004242:	e02fe0ef          	jal	80002844 <iunlockput>
  end_op();
    80004246:	d1bfe0ef          	jal	80002f60 <end_op>
  return -1;
    8000424a:	557d                	li	a0,-1
    8000424c:	64ee                	ld	s1,216(sp)
}
    8000424e:	70ae                	ld	ra,232(sp)
    80004250:	740e                	ld	s0,224(sp)
    80004252:	616d                	addi	sp,sp,240
    80004254:	8082                	ret
    return -1;
    80004256:	557d                	li	a0,-1
    80004258:	bfdd                	j	8000424e <sys_unlink+0x168>
    iunlockput(ip);
    8000425a:	854a                	mv	a0,s2
    8000425c:	de8fe0ef          	jal	80002844 <iunlockput>
    goto bad;
    80004260:	694e                	ld	s2,208(sp)
    80004262:	69ae                	ld	s3,200(sp)
    80004264:	bff1                	j	80004240 <sys_unlink+0x15a>

0000000080004266 <sys_open>:

uint64
sys_open(void)
{
    80004266:	7131                	addi	sp,sp,-192
    80004268:	fd06                	sd	ra,184(sp)
    8000426a:	f922                	sd	s0,176(sp)
    8000426c:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    8000426e:	f4c40593          	addi	a1,s0,-180
    80004272:	4505                	li	a0,1
    80004274:	9cffd0ef          	jal	80001c42 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004278:	08000613          	li	a2,128
    8000427c:	f5040593          	addi	a1,s0,-176
    80004280:	4501                	li	a0,0
    80004282:	9f9fd0ef          	jal	80001c7a <argstr>
    80004286:	87aa                	mv	a5,a0
    return -1;
    80004288:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000428a:	0a07c363          	bltz	a5,80004330 <sys_open+0xca>
    8000428e:	f526                	sd	s1,168(sp)

  begin_op();
    80004290:	c61fe0ef          	jal	80002ef0 <begin_op>

  if(omode & O_CREATE){
    80004294:	f4c42783          	lw	a5,-180(s0)
    80004298:	2007f793          	andi	a5,a5,512
    8000429c:	c3dd                	beqz	a5,80004342 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    8000429e:	4681                	li	a3,0
    800042a0:	4601                	li	a2,0
    800042a2:	4589                	li	a1,2
    800042a4:	f5040513          	addi	a0,s0,-176
    800042a8:	aafff0ef          	jal	80003d56 <create>
    800042ac:	84aa                	mv	s1,a0
    if(ip == 0){
    800042ae:	c549                	beqz	a0,80004338 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800042b0:	04449703          	lh	a4,68(s1)
    800042b4:	478d                	li	a5,3
    800042b6:	00f71763          	bne	a4,a5,800042c4 <sys_open+0x5e>
    800042ba:	0464d703          	lhu	a4,70(s1)
    800042be:	47a5                	li	a5,9
    800042c0:	0ae7ee63          	bltu	a5,a4,8000437c <sys_open+0x116>
    800042c4:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    800042c6:	fb9fe0ef          	jal	8000327e <filealloc>
    800042ca:	892a                	mv	s2,a0
    800042cc:	c561                	beqz	a0,80004394 <sys_open+0x12e>
    800042ce:	ed4e                	sd	s3,152(sp)
    800042d0:	a47ff0ef          	jal	80003d16 <fdalloc>
    800042d4:	89aa                	mv	s3,a0
    800042d6:	0a054b63          	bltz	a0,8000438c <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    800042da:	04449703          	lh	a4,68(s1)
    800042de:	478d                	li	a5,3
    800042e0:	0cf70363          	beq	a4,a5,800043a6 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    800042e4:	4789                	li	a5,2
    800042e6:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800042ea:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800042ee:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    800042f2:	f4c42783          	lw	a5,-180(s0)
    800042f6:	0017f713          	andi	a4,a5,1
    800042fa:	00174713          	xori	a4,a4,1
    800042fe:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004302:	0037f713          	andi	a4,a5,3
    80004306:	00e03733          	snez	a4,a4
    8000430a:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000430e:	4007f793          	andi	a5,a5,1024
    80004312:	c791                	beqz	a5,8000431e <sys_open+0xb8>
    80004314:	04449703          	lh	a4,68(s1)
    80004318:	4789                	li	a5,2
    8000431a:	08f70d63          	beq	a4,a5,800043b4 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    8000431e:	8526                	mv	a0,s1
    80004320:	bc6fe0ef          	jal	800026e6 <iunlock>
  end_op();
    80004324:	c3dfe0ef          	jal	80002f60 <end_op>

  return fd;
    80004328:	854e                	mv	a0,s3
    8000432a:	74aa                	ld	s1,168(sp)
    8000432c:	790a                	ld	s2,160(sp)
    8000432e:	69ea                	ld	s3,152(sp)
}
    80004330:	70ea                	ld	ra,184(sp)
    80004332:	744a                	ld	s0,176(sp)
    80004334:	6129                	addi	sp,sp,192
    80004336:	8082                	ret
      end_op();
    80004338:	c29fe0ef          	jal	80002f60 <end_op>
      return -1;
    8000433c:	557d                	li	a0,-1
    8000433e:	74aa                	ld	s1,168(sp)
    80004340:	bfc5                	j	80004330 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    80004342:	f5040513          	addi	a0,s0,-176
    80004346:	9e9fe0ef          	jal	80002d2e <namei>
    8000434a:	84aa                	mv	s1,a0
    8000434c:	c11d                	beqz	a0,80004372 <sys_open+0x10c>
    ilock(ip);
    8000434e:	aeafe0ef          	jal	80002638 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004352:	04449703          	lh	a4,68(s1)
    80004356:	4785                	li	a5,1
    80004358:	f4f71ce3          	bne	a4,a5,800042b0 <sys_open+0x4a>
    8000435c:	f4c42783          	lw	a5,-180(s0)
    80004360:	d3b5                	beqz	a5,800042c4 <sys_open+0x5e>
      iunlockput(ip);
    80004362:	8526                	mv	a0,s1
    80004364:	ce0fe0ef          	jal	80002844 <iunlockput>
      end_op();
    80004368:	bf9fe0ef          	jal	80002f60 <end_op>
      return -1;
    8000436c:	557d                	li	a0,-1
    8000436e:	74aa                	ld	s1,168(sp)
    80004370:	b7c1                	j	80004330 <sys_open+0xca>
      end_op();
    80004372:	beffe0ef          	jal	80002f60 <end_op>
      return -1;
    80004376:	557d                	li	a0,-1
    80004378:	74aa                	ld	s1,168(sp)
    8000437a:	bf5d                	j	80004330 <sys_open+0xca>
    iunlockput(ip);
    8000437c:	8526                	mv	a0,s1
    8000437e:	cc6fe0ef          	jal	80002844 <iunlockput>
    end_op();
    80004382:	bdffe0ef          	jal	80002f60 <end_op>
    return -1;
    80004386:	557d                	li	a0,-1
    80004388:	74aa                	ld	s1,168(sp)
    8000438a:	b75d                	j	80004330 <sys_open+0xca>
      fileclose(f);
    8000438c:	854a                	mv	a0,s2
    8000438e:	f95fe0ef          	jal	80003322 <fileclose>
    80004392:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80004394:	8526                	mv	a0,s1
    80004396:	caefe0ef          	jal	80002844 <iunlockput>
    end_op();
    8000439a:	bc7fe0ef          	jal	80002f60 <end_op>
    return -1;
    8000439e:	557d                	li	a0,-1
    800043a0:	74aa                	ld	s1,168(sp)
    800043a2:	790a                	ld	s2,160(sp)
    800043a4:	b771                	j	80004330 <sys_open+0xca>
    f->type = FD_DEVICE;
    800043a6:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800043aa:	04649783          	lh	a5,70(s1)
    800043ae:	02f91223          	sh	a5,36(s2)
    800043b2:	bf35                	j	800042ee <sys_open+0x88>
    itrunc(ip);
    800043b4:	8526                	mv	a0,s1
    800043b6:	b70fe0ef          	jal	80002726 <itrunc>
    800043ba:	b795                	j	8000431e <sys_open+0xb8>

00000000800043bc <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800043bc:	7175                	addi	sp,sp,-144
    800043be:	e506                	sd	ra,136(sp)
    800043c0:	e122                	sd	s0,128(sp)
    800043c2:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800043c4:	b2dfe0ef          	jal	80002ef0 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800043c8:	08000613          	li	a2,128
    800043cc:	f7040593          	addi	a1,s0,-144
    800043d0:	4501                	li	a0,0
    800043d2:	8a9fd0ef          	jal	80001c7a <argstr>
    800043d6:	02054363          	bltz	a0,800043fc <sys_mkdir+0x40>
    800043da:	4681                	li	a3,0
    800043dc:	4601                	li	a2,0
    800043de:	4585                	li	a1,1
    800043e0:	f7040513          	addi	a0,s0,-144
    800043e4:	973ff0ef          	jal	80003d56 <create>
    800043e8:	c911                	beqz	a0,800043fc <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800043ea:	c5afe0ef          	jal	80002844 <iunlockput>
  end_op();
    800043ee:	b73fe0ef          	jal	80002f60 <end_op>
  return 0;
    800043f2:	4501                	li	a0,0
}
    800043f4:	60aa                	ld	ra,136(sp)
    800043f6:	640a                	ld	s0,128(sp)
    800043f8:	6149                	addi	sp,sp,144
    800043fa:	8082                	ret
    end_op();
    800043fc:	b65fe0ef          	jal	80002f60 <end_op>
    return -1;
    80004400:	557d                	li	a0,-1
    80004402:	bfcd                	j	800043f4 <sys_mkdir+0x38>

0000000080004404 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004404:	7135                	addi	sp,sp,-160
    80004406:	ed06                	sd	ra,152(sp)
    80004408:	e922                	sd	s0,144(sp)
    8000440a:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000440c:	ae5fe0ef          	jal	80002ef0 <begin_op>
  argint(1, &major);
    80004410:	f6c40593          	addi	a1,s0,-148
    80004414:	4505                	li	a0,1
    80004416:	82dfd0ef          	jal	80001c42 <argint>
  argint(2, &minor);
    8000441a:	f6840593          	addi	a1,s0,-152
    8000441e:	4509                	li	a0,2
    80004420:	823fd0ef          	jal	80001c42 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004424:	08000613          	li	a2,128
    80004428:	f7040593          	addi	a1,s0,-144
    8000442c:	4501                	li	a0,0
    8000442e:	84dfd0ef          	jal	80001c7a <argstr>
    80004432:	02054563          	bltz	a0,8000445c <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004436:	f6841683          	lh	a3,-152(s0)
    8000443a:	f6c41603          	lh	a2,-148(s0)
    8000443e:	458d                	li	a1,3
    80004440:	f7040513          	addi	a0,s0,-144
    80004444:	913ff0ef          	jal	80003d56 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004448:	c911                	beqz	a0,8000445c <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000444a:	bfafe0ef          	jal	80002844 <iunlockput>
  end_op();
    8000444e:	b13fe0ef          	jal	80002f60 <end_op>
  return 0;
    80004452:	4501                	li	a0,0
}
    80004454:	60ea                	ld	ra,152(sp)
    80004456:	644a                	ld	s0,144(sp)
    80004458:	610d                	addi	sp,sp,160
    8000445a:	8082                	ret
    end_op();
    8000445c:	b05fe0ef          	jal	80002f60 <end_op>
    return -1;
    80004460:	557d                	li	a0,-1
    80004462:	bfcd                	j	80004454 <sys_mknod+0x50>

0000000080004464 <sys_chdir>:

uint64
sys_chdir(void)
{
    80004464:	7135                	addi	sp,sp,-160
    80004466:	ed06                	sd	ra,152(sp)
    80004468:	e922                	sd	s0,144(sp)
    8000446a:	e14a                	sd	s2,128(sp)
    8000446c:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    8000446e:	915fc0ef          	jal	80000d82 <myproc>
    80004472:	892a                	mv	s2,a0
  
  begin_op();
    80004474:	a7dfe0ef          	jal	80002ef0 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80004478:	08000613          	li	a2,128
    8000447c:	f6040593          	addi	a1,s0,-160
    80004480:	4501                	li	a0,0
    80004482:	ff8fd0ef          	jal	80001c7a <argstr>
    80004486:	04054363          	bltz	a0,800044cc <sys_chdir+0x68>
    8000448a:	e526                	sd	s1,136(sp)
    8000448c:	f6040513          	addi	a0,s0,-160
    80004490:	89ffe0ef          	jal	80002d2e <namei>
    80004494:	84aa                	mv	s1,a0
    80004496:	c915                	beqz	a0,800044ca <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80004498:	9a0fe0ef          	jal	80002638 <ilock>
  if(ip->type != T_DIR){
    8000449c:	04449703          	lh	a4,68(s1)
    800044a0:	4785                	li	a5,1
    800044a2:	02f71963          	bne	a4,a5,800044d4 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800044a6:	8526                	mv	a0,s1
    800044a8:	a3efe0ef          	jal	800026e6 <iunlock>
  iput(p->cwd);
    800044ac:	15093503          	ld	a0,336(s2)
    800044b0:	b0afe0ef          	jal	800027ba <iput>
  end_op();
    800044b4:	aadfe0ef          	jal	80002f60 <end_op>
  p->cwd = ip;
    800044b8:	14993823          	sd	s1,336(s2)
  return 0;
    800044bc:	4501                	li	a0,0
    800044be:	64aa                	ld	s1,136(sp)
}
    800044c0:	60ea                	ld	ra,152(sp)
    800044c2:	644a                	ld	s0,144(sp)
    800044c4:	690a                	ld	s2,128(sp)
    800044c6:	610d                	addi	sp,sp,160
    800044c8:	8082                	ret
    800044ca:	64aa                	ld	s1,136(sp)
    end_op();
    800044cc:	a95fe0ef          	jal	80002f60 <end_op>
    return -1;
    800044d0:	557d                	li	a0,-1
    800044d2:	b7fd                	j	800044c0 <sys_chdir+0x5c>
    iunlockput(ip);
    800044d4:	8526                	mv	a0,s1
    800044d6:	b6efe0ef          	jal	80002844 <iunlockput>
    end_op();
    800044da:	a87fe0ef          	jal	80002f60 <end_op>
    return -1;
    800044de:	557d                	li	a0,-1
    800044e0:	64aa                	ld	s1,136(sp)
    800044e2:	bff9                	j	800044c0 <sys_chdir+0x5c>

00000000800044e4 <sys_exec>:

uint64
sys_exec(void)
{
    800044e4:	7105                	addi	sp,sp,-480
    800044e6:	ef86                	sd	ra,472(sp)
    800044e8:	eba2                	sd	s0,464(sp)
    800044ea:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800044ec:	e2840593          	addi	a1,s0,-472
    800044f0:	4505                	li	a0,1
    800044f2:	f6cfd0ef          	jal	80001c5e <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    800044f6:	08000613          	li	a2,128
    800044fa:	f3040593          	addi	a1,s0,-208
    800044fe:	4501                	li	a0,0
    80004500:	f7afd0ef          	jal	80001c7a <argstr>
    80004504:	87aa                	mv	a5,a0
    return -1;
    80004506:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80004508:	0e07c063          	bltz	a5,800045e8 <sys_exec+0x104>
    8000450c:	e7a6                	sd	s1,456(sp)
    8000450e:	e3ca                	sd	s2,448(sp)
    80004510:	ff4e                	sd	s3,440(sp)
    80004512:	fb52                	sd	s4,432(sp)
    80004514:	f756                	sd	s5,424(sp)
    80004516:	f35a                	sd	s6,416(sp)
    80004518:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000451a:	e3040a13          	addi	s4,s0,-464
    8000451e:	10000613          	li	a2,256
    80004522:	4581                	li	a1,0
    80004524:	8552                	mv	a0,s4
    80004526:	c39fb0ef          	jal	8000015e <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    8000452a:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    8000452c:	89d2                	mv	s3,s4
    8000452e:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004530:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80004534:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    80004536:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000453a:	00391513          	slli	a0,s2,0x3
    8000453e:	85d6                	mv	a1,s5
    80004540:	e2843783          	ld	a5,-472(s0)
    80004544:	953e                	add	a0,a0,a5
    80004546:	e72fd0ef          	jal	80001bb8 <fetchaddr>
    8000454a:	02054663          	bltz	a0,80004576 <sys_exec+0x92>
    if(uarg == 0){
    8000454e:	e2043783          	ld	a5,-480(s0)
    80004552:	c7a1                	beqz	a5,8000459a <sys_exec+0xb6>
    argv[i] = kalloc();
    80004554:	bb1fb0ef          	jal	80000104 <kalloc>
    80004558:	85aa                	mv	a1,a0
    8000455a:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000455e:	cd01                	beqz	a0,80004576 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80004560:	865a                	mv	a2,s6
    80004562:	e2043503          	ld	a0,-480(s0)
    80004566:	e9cfd0ef          	jal	80001c02 <fetchstr>
    8000456a:	00054663          	bltz	a0,80004576 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    8000456e:	0905                	addi	s2,s2,1
    80004570:	09a1                	addi	s3,s3,8
    80004572:	fd7914e3          	bne	s2,s7,8000453a <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004576:	100a0a13          	addi	s4,s4,256
    8000457a:	6088                	ld	a0,0(s1)
    8000457c:	cd31                	beqz	a0,800045d8 <sys_exec+0xf4>
    kfree(argv[i]);
    8000457e:	a9ffb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004582:	04a1                	addi	s1,s1,8
    80004584:	ff449be3          	bne	s1,s4,8000457a <sys_exec+0x96>
  return -1;
    80004588:	557d                	li	a0,-1
    8000458a:	64be                	ld	s1,456(sp)
    8000458c:	691e                	ld	s2,448(sp)
    8000458e:	79fa                	ld	s3,440(sp)
    80004590:	7a5a                	ld	s4,432(sp)
    80004592:	7aba                	ld	s5,424(sp)
    80004594:	7b1a                	ld	s6,416(sp)
    80004596:	6bfa                	ld	s7,408(sp)
    80004598:	a881                	j	800045e8 <sys_exec+0x104>
      argv[i] = 0;
    8000459a:	0009079b          	sext.w	a5,s2
    8000459e:	e3040593          	addi	a1,s0,-464
    800045a2:	078e                	slli	a5,a5,0x3
    800045a4:	97ae                	add	a5,a5,a1
    800045a6:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    800045aa:	f3040513          	addi	a0,s0,-208
    800045ae:	bb6ff0ef          	jal	80003964 <exec>
    800045b2:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800045b4:	100a0a13          	addi	s4,s4,256
    800045b8:	6088                	ld	a0,0(s1)
    800045ba:	c511                	beqz	a0,800045c6 <sys_exec+0xe2>
    kfree(argv[i]);
    800045bc:	a61fb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800045c0:	04a1                	addi	s1,s1,8
    800045c2:	ff449be3          	bne	s1,s4,800045b8 <sys_exec+0xd4>
  return ret;
    800045c6:	854a                	mv	a0,s2
    800045c8:	64be                	ld	s1,456(sp)
    800045ca:	691e                	ld	s2,448(sp)
    800045cc:	79fa                	ld	s3,440(sp)
    800045ce:	7a5a                	ld	s4,432(sp)
    800045d0:	7aba                	ld	s5,424(sp)
    800045d2:	7b1a                	ld	s6,416(sp)
    800045d4:	6bfa                	ld	s7,408(sp)
    800045d6:	a809                	j	800045e8 <sys_exec+0x104>
  return -1;
    800045d8:	557d                	li	a0,-1
    800045da:	64be                	ld	s1,456(sp)
    800045dc:	691e                	ld	s2,448(sp)
    800045de:	79fa                	ld	s3,440(sp)
    800045e0:	7a5a                	ld	s4,432(sp)
    800045e2:	7aba                	ld	s5,424(sp)
    800045e4:	7b1a                	ld	s6,416(sp)
    800045e6:	6bfa                	ld	s7,408(sp)
}
    800045e8:	60fe                	ld	ra,472(sp)
    800045ea:	645e                	ld	s0,464(sp)
    800045ec:	613d                	addi	sp,sp,480
    800045ee:	8082                	ret

00000000800045f0 <sys_pipe>:

uint64
sys_pipe(void)
{
    800045f0:	7139                	addi	sp,sp,-64
    800045f2:	fc06                	sd	ra,56(sp)
    800045f4:	f822                	sd	s0,48(sp)
    800045f6:	f426                	sd	s1,40(sp)
    800045f8:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800045fa:	f88fc0ef          	jal	80000d82 <myproc>
    800045fe:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80004600:	fd840593          	addi	a1,s0,-40
    80004604:	4501                	li	a0,0
    80004606:	e58fd0ef          	jal	80001c5e <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000460a:	fc840593          	addi	a1,s0,-56
    8000460e:	fd040513          	addi	a0,s0,-48
    80004612:	82cff0ef          	jal	8000363e <pipealloc>
    return -1;
    80004616:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80004618:	0a054763          	bltz	a0,800046c6 <sys_pipe+0xd6>
  fd0 = -1;
    8000461c:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80004620:	fd043503          	ld	a0,-48(s0)
    80004624:	ef2ff0ef          	jal	80003d16 <fdalloc>
    80004628:	fca42223          	sw	a0,-60(s0)
    8000462c:	08054463          	bltz	a0,800046b4 <sys_pipe+0xc4>
    80004630:	fc843503          	ld	a0,-56(s0)
    80004634:	ee2ff0ef          	jal	80003d16 <fdalloc>
    80004638:	fca42023          	sw	a0,-64(s0)
    8000463c:	06054263          	bltz	a0,800046a0 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004640:	4691                	li	a3,4
    80004642:	fc440613          	addi	a2,s0,-60
    80004646:	fd843583          	ld	a1,-40(s0)
    8000464a:	68a8                	ld	a0,80(s1)
    8000464c:	bb6fc0ef          	jal	80000a02 <copyout>
    80004650:	00054e63          	bltz	a0,8000466c <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80004654:	4691                	li	a3,4
    80004656:	fc040613          	addi	a2,s0,-64
    8000465a:	fd843583          	ld	a1,-40(s0)
    8000465e:	95b6                	add	a1,a1,a3
    80004660:	68a8                	ld	a0,80(s1)
    80004662:	ba0fc0ef          	jal	80000a02 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80004666:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004668:	04055f63          	bgez	a0,800046c6 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    8000466c:	fc442783          	lw	a5,-60(s0)
    80004670:	078e                	slli	a5,a5,0x3
    80004672:	0d078793          	addi	a5,a5,208
    80004676:	97a6                	add	a5,a5,s1
    80004678:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    8000467c:	fc042783          	lw	a5,-64(s0)
    80004680:	078e                	slli	a5,a5,0x3
    80004682:	0d078793          	addi	a5,a5,208
    80004686:	97a6                	add	a5,a5,s1
    80004688:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    8000468c:	fd043503          	ld	a0,-48(s0)
    80004690:	c93fe0ef          	jal	80003322 <fileclose>
    fileclose(wf);
    80004694:	fc843503          	ld	a0,-56(s0)
    80004698:	c8bfe0ef          	jal	80003322 <fileclose>
    return -1;
    8000469c:	57fd                	li	a5,-1
    8000469e:	a025                	j	800046c6 <sys_pipe+0xd6>
    if(fd0 >= 0)
    800046a0:	fc442783          	lw	a5,-60(s0)
    800046a4:	0007c863          	bltz	a5,800046b4 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    800046a8:	078e                	slli	a5,a5,0x3
    800046aa:	0d078793          	addi	a5,a5,208
    800046ae:	97a6                	add	a5,a5,s1
    800046b0:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800046b4:	fd043503          	ld	a0,-48(s0)
    800046b8:	c6bfe0ef          	jal	80003322 <fileclose>
    fileclose(wf);
    800046bc:	fc843503          	ld	a0,-56(s0)
    800046c0:	c63fe0ef          	jal	80003322 <fileclose>
    return -1;
    800046c4:	57fd                	li	a5,-1
}
    800046c6:	853e                	mv	a0,a5
    800046c8:	70e2                	ld	ra,56(sp)
    800046ca:	7442                	ld	s0,48(sp)
    800046cc:	74a2                	ld	s1,40(sp)
    800046ce:	6121                	addi	sp,sp,64
    800046d0:	8082                	ret
	...

00000000800046e0 <kernelvec>:
    800046e0:	7111                	addi	sp,sp,-256
    800046e2:	e006                	sd	ra,0(sp)
    800046e4:	e40a                	sd	sp,8(sp)
    800046e6:	e80e                	sd	gp,16(sp)
    800046e8:	ec12                	sd	tp,24(sp)
    800046ea:	f016                	sd	t0,32(sp)
    800046ec:	f41a                	sd	t1,40(sp)
    800046ee:	f81e                	sd	t2,48(sp)
    800046f0:	e4aa                	sd	a0,72(sp)
    800046f2:	e8ae                	sd	a1,80(sp)
    800046f4:	ecb2                	sd	a2,88(sp)
    800046f6:	f0b6                	sd	a3,96(sp)
    800046f8:	f4ba                	sd	a4,104(sp)
    800046fa:	f8be                	sd	a5,112(sp)
    800046fc:	fcc2                	sd	a6,120(sp)
    800046fe:	e146                	sd	a7,128(sp)
    80004700:	edf2                	sd	t3,216(sp)
    80004702:	f1f6                	sd	t4,224(sp)
    80004704:	f5fa                	sd	t5,232(sp)
    80004706:	f9fe                	sd	t6,240(sp)
    80004708:	bbefd0ef          	jal	80001ac6 <kerneltrap>
    8000470c:	6082                	ld	ra,0(sp)
    8000470e:	6122                	ld	sp,8(sp)
    80004710:	61c2                	ld	gp,16(sp)
    80004712:	7282                	ld	t0,32(sp)
    80004714:	7322                	ld	t1,40(sp)
    80004716:	73c2                	ld	t2,48(sp)
    80004718:	6526                	ld	a0,72(sp)
    8000471a:	65c6                	ld	a1,80(sp)
    8000471c:	6666                	ld	a2,88(sp)
    8000471e:	7686                	ld	a3,96(sp)
    80004720:	7726                	ld	a4,104(sp)
    80004722:	77c6                	ld	a5,112(sp)
    80004724:	7866                	ld	a6,120(sp)
    80004726:	688a                	ld	a7,128(sp)
    80004728:	6e6e                	ld	t3,216(sp)
    8000472a:	7e8e                	ld	t4,224(sp)
    8000472c:	7f2e                	ld	t5,232(sp)
    8000472e:	7fce                	ld	t6,240(sp)
    80004730:	6111                	addi	sp,sp,256
    80004732:	10200073          	sret
    80004736:	00000013          	nop
    8000473a:	00000013          	nop

000000008000473e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000473e:	1141                	addi	sp,sp,-16
    80004740:	e406                	sd	ra,8(sp)
    80004742:	e022                	sd	s0,0(sp)
    80004744:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004746:	0c000737          	lui	a4,0xc000
    8000474a:	4785                	li	a5,1
    8000474c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000474e:	c35c                	sw	a5,4(a4)
}
    80004750:	60a2                	ld	ra,8(sp)
    80004752:	6402                	ld	s0,0(sp)
    80004754:	0141                	addi	sp,sp,16
    80004756:	8082                	ret

0000000080004758 <plicinithart>:

void
plicinithart(void)
{
    80004758:	1141                	addi	sp,sp,-16
    8000475a:	e406                	sd	ra,8(sp)
    8000475c:	e022                	sd	s0,0(sp)
    8000475e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004760:	deefc0ef          	jal	80000d4e <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80004764:	0085171b          	slliw	a4,a0,0x8
    80004768:	0c0027b7          	lui	a5,0xc002
    8000476c:	97ba                	add	a5,a5,a4
    8000476e:	40200713          	li	a4,1026
    80004772:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80004776:	00d5151b          	slliw	a0,a0,0xd
    8000477a:	0c2017b7          	lui	a5,0xc201
    8000477e:	97aa                	add	a5,a5,a0
    80004780:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80004784:	60a2                	ld	ra,8(sp)
    80004786:	6402                	ld	s0,0(sp)
    80004788:	0141                	addi	sp,sp,16
    8000478a:	8082                	ret

000000008000478c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000478c:	1141                	addi	sp,sp,-16
    8000478e:	e406                	sd	ra,8(sp)
    80004790:	e022                	sd	s0,0(sp)
    80004792:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004794:	dbafc0ef          	jal	80000d4e <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80004798:	00d5151b          	slliw	a0,a0,0xd
    8000479c:	0c2017b7          	lui	a5,0xc201
    800047a0:	97aa                	add	a5,a5,a0
  return irq;
}
    800047a2:	43c8                	lw	a0,4(a5)
    800047a4:	60a2                	ld	ra,8(sp)
    800047a6:	6402                	ld	s0,0(sp)
    800047a8:	0141                	addi	sp,sp,16
    800047aa:	8082                	ret

00000000800047ac <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800047ac:	1101                	addi	sp,sp,-32
    800047ae:	ec06                	sd	ra,24(sp)
    800047b0:	e822                	sd	s0,16(sp)
    800047b2:	e426                	sd	s1,8(sp)
    800047b4:	1000                	addi	s0,sp,32
    800047b6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800047b8:	d96fc0ef          	jal	80000d4e <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800047bc:	00d5179b          	slliw	a5,a0,0xd
    800047c0:	0c201737          	lui	a4,0xc201
    800047c4:	97ba                	add	a5,a5,a4
    800047c6:	c3c4                	sw	s1,4(a5)
}
    800047c8:	60e2                	ld	ra,24(sp)
    800047ca:	6442                	ld	s0,16(sp)
    800047cc:	64a2                	ld	s1,8(sp)
    800047ce:	6105                	addi	sp,sp,32
    800047d0:	8082                	ret

00000000800047d2 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800047d2:	1141                	addi	sp,sp,-16
    800047d4:	e406                	sd	ra,8(sp)
    800047d6:	e022                	sd	s0,0(sp)
    800047d8:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800047da:	479d                	li	a5,7
    800047dc:	04a7ca63          	blt	a5,a0,80004830 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800047e0:	00014797          	auipc	a5,0x14
    800047e4:	21078793          	addi	a5,a5,528 # 800189f0 <disk>
    800047e8:	97aa                	add	a5,a5,a0
    800047ea:	0187c783          	lbu	a5,24(a5)
    800047ee:	e7b9                	bnez	a5,8000483c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    800047f0:	00451693          	slli	a3,a0,0x4
    800047f4:	00014797          	auipc	a5,0x14
    800047f8:	1fc78793          	addi	a5,a5,508 # 800189f0 <disk>
    800047fc:	6398                	ld	a4,0(a5)
    800047fe:	9736                	add	a4,a4,a3
    80004800:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80004804:	6398                	ld	a4,0(a5)
    80004806:	9736                	add	a4,a4,a3
    80004808:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000480c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80004810:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004814:	97aa                	add	a5,a5,a0
    80004816:	4705                	li	a4,1
    80004818:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000481c:	00014517          	auipc	a0,0x14
    80004820:	1ec50513          	addi	a0,a0,492 # 80018a08 <disk+0x18>
    80004824:	b7dfc0ef          	jal	800013a0 <wakeup>
}
    80004828:	60a2                	ld	ra,8(sp)
    8000482a:	6402                	ld	s0,0(sp)
    8000482c:	0141                	addi	sp,sp,16
    8000482e:	8082                	ret
    panic("free_desc 1");
    80004830:	00003517          	auipc	a0,0x3
    80004834:	de050513          	addi	a0,a0,-544 # 80007610 <etext+0x610>
    80004838:	457000ef          	jal	8000548e <panic>
    panic("free_desc 2");
    8000483c:	00003517          	auipc	a0,0x3
    80004840:	de450513          	addi	a0,a0,-540 # 80007620 <etext+0x620>
    80004844:	44b000ef          	jal	8000548e <panic>

0000000080004848 <virtio_disk_init>:
{
    80004848:	1101                	addi	sp,sp,-32
    8000484a:	ec06                	sd	ra,24(sp)
    8000484c:	e822                	sd	s0,16(sp)
    8000484e:	e426                	sd	s1,8(sp)
    80004850:	e04a                	sd	s2,0(sp)
    80004852:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004854:	00003597          	auipc	a1,0x3
    80004858:	ddc58593          	addi	a1,a1,-548 # 80007630 <etext+0x630>
    8000485c:	00014517          	auipc	a0,0x14
    80004860:	2bc50513          	addi	a0,a0,700 # 80018b18 <disk+0x128>
    80004864:	6df000ef          	jal	80005742 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004868:	100017b7          	lui	a5,0x10001
    8000486c:	4398                	lw	a4,0(a5)
    8000486e:	2701                	sext.w	a4,a4
    80004870:	747277b7          	lui	a5,0x74727
    80004874:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80004878:	14f71863          	bne	a4,a5,800049c8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000487c:	100017b7          	lui	a5,0x10001
    80004880:	43dc                	lw	a5,4(a5)
    80004882:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004884:	4709                	li	a4,2
    80004886:	14e79163          	bne	a5,a4,800049c8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000488a:	100017b7          	lui	a5,0x10001
    8000488e:	479c                	lw	a5,8(a5)
    80004890:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004892:	12e79b63          	bne	a5,a4,800049c8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80004896:	100017b7          	lui	a5,0x10001
    8000489a:	47d8                	lw	a4,12(a5)
    8000489c:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000489e:	554d47b7          	lui	a5,0x554d4
    800048a2:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800048a6:	12f71163          	bne	a4,a5,800049c8 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    800048aa:	100017b7          	lui	a5,0x10001
    800048ae:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800048b2:	4705                	li	a4,1
    800048b4:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800048b6:	470d                	li	a4,3
    800048b8:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800048ba:	10001737          	lui	a4,0x10001
    800048be:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800048c0:	c7ffe6b7          	lui	a3,0xc7ffe
    800048c4:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fddb2f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800048c8:	8f75                	and	a4,a4,a3
    800048ca:	100016b7          	lui	a3,0x10001
    800048ce:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    800048d0:	472d                	li	a4,11
    800048d2:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800048d4:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    800048d8:	439c                	lw	a5,0(a5)
    800048da:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800048de:	8ba1                	andi	a5,a5,8
    800048e0:	0e078a63          	beqz	a5,800049d4 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800048e4:	100017b7          	lui	a5,0x10001
    800048e8:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    800048ec:	43fc                	lw	a5,68(a5)
    800048ee:	2781                	sext.w	a5,a5
    800048f0:	0e079863          	bnez	a5,800049e0 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800048f4:	100017b7          	lui	a5,0x10001
    800048f8:	5bdc                	lw	a5,52(a5)
    800048fa:	2781                	sext.w	a5,a5
  if(max == 0)
    800048fc:	0e078863          	beqz	a5,800049ec <virtio_disk_init+0x1a4>
  if(max < NUM)
    80004900:	471d                	li	a4,7
    80004902:	0ef77b63          	bgeu	a4,a5,800049f8 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80004906:	ffefb0ef          	jal	80000104 <kalloc>
    8000490a:	00014497          	auipc	s1,0x14
    8000490e:	0e648493          	addi	s1,s1,230 # 800189f0 <disk>
    80004912:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004914:	ff0fb0ef          	jal	80000104 <kalloc>
    80004918:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000491a:	feafb0ef          	jal	80000104 <kalloc>
    8000491e:	87aa                	mv	a5,a0
    80004920:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004922:	6088                	ld	a0,0(s1)
    80004924:	0e050063          	beqz	a0,80004a04 <virtio_disk_init+0x1bc>
    80004928:	00014717          	auipc	a4,0x14
    8000492c:	0d073703          	ld	a4,208(a4) # 800189f8 <disk+0x8>
    80004930:	cb71                	beqz	a4,80004a04 <virtio_disk_init+0x1bc>
    80004932:	cbe9                	beqz	a5,80004a04 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80004934:	6605                	lui	a2,0x1
    80004936:	4581                	li	a1,0
    80004938:	827fb0ef          	jal	8000015e <memset>
  memset(disk.avail, 0, PGSIZE);
    8000493c:	00014497          	auipc	s1,0x14
    80004940:	0b448493          	addi	s1,s1,180 # 800189f0 <disk>
    80004944:	6605                	lui	a2,0x1
    80004946:	4581                	li	a1,0
    80004948:	6488                	ld	a0,8(s1)
    8000494a:	815fb0ef          	jal	8000015e <memset>
  memset(disk.used, 0, PGSIZE);
    8000494e:	6605                	lui	a2,0x1
    80004950:	4581                	li	a1,0
    80004952:	6888                	ld	a0,16(s1)
    80004954:	80bfb0ef          	jal	8000015e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004958:	100017b7          	lui	a5,0x10001
    8000495c:	4721                	li	a4,8
    8000495e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004960:	4098                	lw	a4,0(s1)
    80004962:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004966:	40d8                	lw	a4,4(s1)
    80004968:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    8000496c:	649c                	ld	a5,8(s1)
    8000496e:	0007869b          	sext.w	a3,a5
    80004972:	10001737          	lui	a4,0x10001
    80004976:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    8000497a:	9781                	srai	a5,a5,0x20
    8000497c:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80004980:	689c                	ld	a5,16(s1)
    80004982:	0007869b          	sext.w	a3,a5
    80004986:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000498a:	9781                	srai	a5,a5,0x20
    8000498c:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80004990:	4785                	li	a5,1
    80004992:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80004994:	00f48c23          	sb	a5,24(s1)
    80004998:	00f48ca3          	sb	a5,25(s1)
    8000499c:	00f48d23          	sb	a5,26(s1)
    800049a0:	00f48da3          	sb	a5,27(s1)
    800049a4:	00f48e23          	sb	a5,28(s1)
    800049a8:	00f48ea3          	sb	a5,29(s1)
    800049ac:	00f48f23          	sb	a5,30(s1)
    800049b0:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    800049b4:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    800049b8:	07272823          	sw	s2,112(a4)
}
    800049bc:	60e2                	ld	ra,24(sp)
    800049be:	6442                	ld	s0,16(sp)
    800049c0:	64a2                	ld	s1,8(sp)
    800049c2:	6902                	ld	s2,0(sp)
    800049c4:	6105                	addi	sp,sp,32
    800049c6:	8082                	ret
    panic("could not find virtio disk");
    800049c8:	00003517          	auipc	a0,0x3
    800049cc:	c7850513          	addi	a0,a0,-904 # 80007640 <etext+0x640>
    800049d0:	2bf000ef          	jal	8000548e <panic>
    panic("virtio disk FEATURES_OK unset");
    800049d4:	00003517          	auipc	a0,0x3
    800049d8:	c8c50513          	addi	a0,a0,-884 # 80007660 <etext+0x660>
    800049dc:	2b3000ef          	jal	8000548e <panic>
    panic("virtio disk should not be ready");
    800049e0:	00003517          	auipc	a0,0x3
    800049e4:	ca050513          	addi	a0,a0,-864 # 80007680 <etext+0x680>
    800049e8:	2a7000ef          	jal	8000548e <panic>
    panic("virtio disk has no queue 0");
    800049ec:	00003517          	auipc	a0,0x3
    800049f0:	cb450513          	addi	a0,a0,-844 # 800076a0 <etext+0x6a0>
    800049f4:	29b000ef          	jal	8000548e <panic>
    panic("virtio disk max queue too short");
    800049f8:	00003517          	auipc	a0,0x3
    800049fc:	cc850513          	addi	a0,a0,-824 # 800076c0 <etext+0x6c0>
    80004a00:	28f000ef          	jal	8000548e <panic>
    panic("virtio disk kalloc");
    80004a04:	00003517          	auipc	a0,0x3
    80004a08:	cdc50513          	addi	a0,a0,-804 # 800076e0 <etext+0x6e0>
    80004a0c:	283000ef          	jal	8000548e <panic>

0000000080004a10 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004a10:	711d                	addi	sp,sp,-96
    80004a12:	ec86                	sd	ra,88(sp)
    80004a14:	e8a2                	sd	s0,80(sp)
    80004a16:	e4a6                	sd	s1,72(sp)
    80004a18:	e0ca                	sd	s2,64(sp)
    80004a1a:	fc4e                	sd	s3,56(sp)
    80004a1c:	f852                	sd	s4,48(sp)
    80004a1e:	f456                	sd	s5,40(sp)
    80004a20:	f05a                	sd	s6,32(sp)
    80004a22:	ec5e                	sd	s7,24(sp)
    80004a24:	e862                	sd	s8,16(sp)
    80004a26:	1080                	addi	s0,sp,96
    80004a28:	89aa                	mv	s3,a0
    80004a2a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004a2c:	00c52b83          	lw	s7,12(a0)
    80004a30:	001b9b9b          	slliw	s7,s7,0x1
    80004a34:	1b82                	slli	s7,s7,0x20
    80004a36:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80004a3a:	00014517          	auipc	a0,0x14
    80004a3e:	0de50513          	addi	a0,a0,222 # 80018b18 <disk+0x128>
    80004a42:	58b000ef          	jal	800057cc <acquire>
  for(int i = 0; i < NUM; i++){
    80004a46:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004a48:	00014a97          	auipc	s5,0x14
    80004a4c:	fa8a8a93          	addi	s5,s5,-88 # 800189f0 <disk>
  for(int i = 0; i < 3; i++){
    80004a50:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80004a52:	5c7d                	li	s8,-1
    80004a54:	a095                	j	80004ab8 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80004a56:	00fa8733          	add	a4,s5,a5
    80004a5a:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004a5e:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004a60:	0207c563          	bltz	a5,80004a8a <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80004a64:	2905                	addiw	s2,s2,1
    80004a66:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80004a68:	05490c63          	beq	s2,s4,80004ac0 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    80004a6c:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004a6e:	00014717          	auipc	a4,0x14
    80004a72:	f8270713          	addi	a4,a4,-126 # 800189f0 <disk>
    80004a76:	4781                	li	a5,0
    if(disk.free[i]){
    80004a78:	01874683          	lbu	a3,24(a4)
    80004a7c:	fee9                	bnez	a3,80004a56 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80004a7e:	2785                	addiw	a5,a5,1
    80004a80:	0705                	addi	a4,a4,1
    80004a82:	fe979be3          	bne	a5,s1,80004a78 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80004a86:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80004a8a:	01205d63          	blez	s2,80004aa4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004a8e:	fa042503          	lw	a0,-96(s0)
    80004a92:	d41ff0ef          	jal	800047d2 <free_desc>
      for(int j = 0; j < i; j++)
    80004a96:	4785                	li	a5,1
    80004a98:	0127d663          	bge	a5,s2,80004aa4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004a9c:	fa442503          	lw	a0,-92(s0)
    80004aa0:	d33ff0ef          	jal	800047d2 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004aa4:	00014597          	auipc	a1,0x14
    80004aa8:	07458593          	addi	a1,a1,116 # 80018b18 <disk+0x128>
    80004aac:	00014517          	auipc	a0,0x14
    80004ab0:	f5c50513          	addi	a0,a0,-164 # 80018a08 <disk+0x18>
    80004ab4:	8a1fc0ef          	jal	80001354 <sleep>
  for(int i = 0; i < 3; i++){
    80004ab8:	fa040613          	addi	a2,s0,-96
    80004abc:	4901                	li	s2,0
    80004abe:	b77d                	j	80004a6c <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004ac0:	fa042503          	lw	a0,-96(s0)
    80004ac4:	00451693          	slli	a3,a0,0x4

  if(write)
    80004ac8:	00014797          	auipc	a5,0x14
    80004acc:	f2878793          	addi	a5,a5,-216 # 800189f0 <disk>
    80004ad0:	00451713          	slli	a4,a0,0x4
    80004ad4:	0a070713          	addi	a4,a4,160
    80004ad8:	973e                	add	a4,a4,a5
    80004ada:	01603633          	snez	a2,s6
    80004ade:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004ae0:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004ae4:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004ae8:	6398                	ld	a4,0(a5)
    80004aea:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004aec:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80004af0:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004af2:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004af4:	6390                	ld	a2,0(a5)
    80004af6:	00d60833          	add	a6,a2,a3
    80004afa:	4741                	li	a4,16
    80004afc:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004b00:	4585                	li	a1,1
    80004b02:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80004b06:	fa442703          	lw	a4,-92(s0)
    80004b0a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004b0e:	0712                	slli	a4,a4,0x4
    80004b10:	963a                	add	a2,a2,a4
    80004b12:	05898813          	addi	a6,s3,88
    80004b16:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80004b1a:	0007b883          	ld	a7,0(a5)
    80004b1e:	9746                	add	a4,a4,a7
    80004b20:	40000613          	li	a2,1024
    80004b24:	c710                	sw	a2,8(a4)
  if(write)
    80004b26:	001b3613          	seqz	a2,s6
    80004b2a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004b2e:	8e4d                	or	a2,a2,a1
    80004b30:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004b34:	fa842603          	lw	a2,-88(s0)
    80004b38:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004b3c:	00451813          	slli	a6,a0,0x4
    80004b40:	02080813          	addi	a6,a6,32
    80004b44:	983e                	add	a6,a6,a5
    80004b46:	577d                	li	a4,-1
    80004b48:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004b4c:	0612                	slli	a2,a2,0x4
    80004b4e:	98b2                	add	a7,a7,a2
    80004b50:	03068713          	addi	a4,a3,48
    80004b54:	973e                	add	a4,a4,a5
    80004b56:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80004b5a:	6398                	ld	a4,0(a5)
    80004b5c:	9732                	add	a4,a4,a2
    80004b5e:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004b60:	4689                	li	a3,2
    80004b62:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80004b66:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004b6a:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80004b6e:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004b72:	6794                	ld	a3,8(a5)
    80004b74:	0026d703          	lhu	a4,2(a3)
    80004b78:	8b1d                	andi	a4,a4,7
    80004b7a:	0706                	slli	a4,a4,0x1
    80004b7c:	96ba                	add	a3,a3,a4
    80004b7e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80004b82:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004b86:	6798                	ld	a4,8(a5)
    80004b88:	00275783          	lhu	a5,2(a4)
    80004b8c:	2785                	addiw	a5,a5,1
    80004b8e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004b92:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004b96:	100017b7          	lui	a5,0x10001
    80004b9a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004b9e:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80004ba2:	00014917          	auipc	s2,0x14
    80004ba6:	f7690913          	addi	s2,s2,-138 # 80018b18 <disk+0x128>
  while(b->disk == 1) {
    80004baa:	84ae                	mv	s1,a1
    80004bac:	00b79a63          	bne	a5,a1,80004bc0 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80004bb0:	85ca                	mv	a1,s2
    80004bb2:	854e                	mv	a0,s3
    80004bb4:	fa0fc0ef          	jal	80001354 <sleep>
  while(b->disk == 1) {
    80004bb8:	0049a783          	lw	a5,4(s3)
    80004bbc:	fe978ae3          	beq	a5,s1,80004bb0 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80004bc0:	fa042903          	lw	s2,-96(s0)
    80004bc4:	00491713          	slli	a4,s2,0x4
    80004bc8:	02070713          	addi	a4,a4,32
    80004bcc:	00014797          	auipc	a5,0x14
    80004bd0:	e2478793          	addi	a5,a5,-476 # 800189f0 <disk>
    80004bd4:	97ba                	add	a5,a5,a4
    80004bd6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004bda:	00014997          	auipc	s3,0x14
    80004bde:	e1698993          	addi	s3,s3,-490 # 800189f0 <disk>
    80004be2:	00491713          	slli	a4,s2,0x4
    80004be6:	0009b783          	ld	a5,0(s3)
    80004bea:	97ba                	add	a5,a5,a4
    80004bec:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004bf0:	854a                	mv	a0,s2
    80004bf2:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004bf6:	bddff0ef          	jal	800047d2 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004bfa:	8885                	andi	s1,s1,1
    80004bfc:	f0fd                	bnez	s1,80004be2 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004bfe:	00014517          	auipc	a0,0x14
    80004c02:	f1a50513          	addi	a0,a0,-230 # 80018b18 <disk+0x128>
    80004c06:	45b000ef          	jal	80005860 <release>
}
    80004c0a:	60e6                	ld	ra,88(sp)
    80004c0c:	6446                	ld	s0,80(sp)
    80004c0e:	64a6                	ld	s1,72(sp)
    80004c10:	6906                	ld	s2,64(sp)
    80004c12:	79e2                	ld	s3,56(sp)
    80004c14:	7a42                	ld	s4,48(sp)
    80004c16:	7aa2                	ld	s5,40(sp)
    80004c18:	7b02                	ld	s6,32(sp)
    80004c1a:	6be2                	ld	s7,24(sp)
    80004c1c:	6c42                	ld	s8,16(sp)
    80004c1e:	6125                	addi	sp,sp,96
    80004c20:	8082                	ret

0000000080004c22 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004c22:	1101                	addi	sp,sp,-32
    80004c24:	ec06                	sd	ra,24(sp)
    80004c26:	e822                	sd	s0,16(sp)
    80004c28:	e426                	sd	s1,8(sp)
    80004c2a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004c2c:	00014497          	auipc	s1,0x14
    80004c30:	dc448493          	addi	s1,s1,-572 # 800189f0 <disk>
    80004c34:	00014517          	auipc	a0,0x14
    80004c38:	ee450513          	addi	a0,a0,-284 # 80018b18 <disk+0x128>
    80004c3c:	391000ef          	jal	800057cc <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004c40:	100017b7          	lui	a5,0x10001
    80004c44:	53bc                	lw	a5,96(a5)
    80004c46:	8b8d                	andi	a5,a5,3
    80004c48:	10001737          	lui	a4,0x10001
    80004c4c:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004c4e:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004c52:	689c                	ld	a5,16(s1)
    80004c54:	0204d703          	lhu	a4,32(s1)
    80004c58:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80004c5c:	04f70863          	beq	a4,a5,80004cac <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80004c60:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004c64:	6898                	ld	a4,16(s1)
    80004c66:	0204d783          	lhu	a5,32(s1)
    80004c6a:	8b9d                	andi	a5,a5,7
    80004c6c:	078e                	slli	a5,a5,0x3
    80004c6e:	97ba                	add	a5,a5,a4
    80004c70:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004c72:	00479713          	slli	a4,a5,0x4
    80004c76:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80004c7a:	9726                	add	a4,a4,s1
    80004c7c:	01074703          	lbu	a4,16(a4)
    80004c80:	e329                	bnez	a4,80004cc2 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004c82:	0792                	slli	a5,a5,0x4
    80004c84:	02078793          	addi	a5,a5,32
    80004c88:	97a6                	add	a5,a5,s1
    80004c8a:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004c8c:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004c90:	f10fc0ef          	jal	800013a0 <wakeup>

    disk.used_idx += 1;
    80004c94:	0204d783          	lhu	a5,32(s1)
    80004c98:	2785                	addiw	a5,a5,1
    80004c9a:	17c2                	slli	a5,a5,0x30
    80004c9c:	93c1                	srli	a5,a5,0x30
    80004c9e:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004ca2:	6898                	ld	a4,16(s1)
    80004ca4:	00275703          	lhu	a4,2(a4)
    80004ca8:	faf71ce3          	bne	a4,a5,80004c60 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80004cac:	00014517          	auipc	a0,0x14
    80004cb0:	e6c50513          	addi	a0,a0,-404 # 80018b18 <disk+0x128>
    80004cb4:	3ad000ef          	jal	80005860 <release>
}
    80004cb8:	60e2                	ld	ra,24(sp)
    80004cba:	6442                	ld	s0,16(sp)
    80004cbc:	64a2                	ld	s1,8(sp)
    80004cbe:	6105                	addi	sp,sp,32
    80004cc0:	8082                	ret
      panic("virtio_disk_intr status");
    80004cc2:	00003517          	auipc	a0,0x3
    80004cc6:	a3650513          	addi	a0,a0,-1482 # 800076f8 <etext+0x6f8>
    80004cca:	7c4000ef          	jal	8000548e <panic>

0000000080004cce <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80004cce:	1141                	addi	sp,sp,-16
    80004cd0:	e406                	sd	ra,8(sp)
    80004cd2:	e022                	sd	s0,0(sp)
    80004cd4:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80004cd6:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80004cda:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80004cde:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80004ce2:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80004ce6:	577d                	li	a4,-1
    80004ce8:	177e                	slli	a4,a4,0x3f
    80004cea:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80004cec:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80004cf0:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80004cf4:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80004cf8:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80004cfc:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80004d00:	000f4737          	lui	a4,0xf4
    80004d04:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80004d08:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80004d0a:	14d79073          	csrw	stimecmp,a5
}
    80004d0e:	60a2                	ld	ra,8(sp)
    80004d10:	6402                	ld	s0,0(sp)
    80004d12:	0141                	addi	sp,sp,16
    80004d14:	8082                	ret

0000000080004d16 <start>:
{
    80004d16:	1141                	addi	sp,sp,-16
    80004d18:	e406                	sd	ra,8(sp)
    80004d1a:	e022                	sd	s0,0(sp)
    80004d1c:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80004d1e:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80004d22:	7779                	lui	a4,0xffffe
    80004d24:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffddbcf>
    80004d28:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80004d2a:	6705                	lui	a4,0x1
    80004d2c:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80004d30:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80004d32:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80004d36:	ffffb797          	auipc	a5,0xffffb
    80004d3a:	5de78793          	addi	a5,a5,1502 # 80000314 <main>
    80004d3e:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80004d42:	4781                	li	a5,0
    80004d44:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80004d48:	67c1                	lui	a5,0x10
    80004d4a:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80004d4c:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80004d50:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80004d54:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80004d58:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80004d5c:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80004d60:	57fd                	li	a5,-1
    80004d62:	83a9                	srli	a5,a5,0xa
    80004d64:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80004d68:	47bd                	li	a5,15
    80004d6a:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80004d6e:	f61ff0ef          	jal	80004cce <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80004d72:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80004d76:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80004d78:	823e                	mv	tp,a5
  asm volatile("mret");
    80004d7a:	30200073          	mret
}
    80004d7e:	60a2                	ld	ra,8(sp)
    80004d80:	6402                	ld	s0,0(sp)
    80004d82:	0141                	addi	sp,sp,16
    80004d84:	8082                	ret

0000000080004d86 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80004d86:	711d                	addi	sp,sp,-96
    80004d88:	ec86                	sd	ra,88(sp)
    80004d8a:	e8a2                	sd	s0,80(sp)
    80004d8c:	e0ca                	sd	s2,64(sp)
    80004d8e:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    80004d90:	04c05763          	blez	a2,80004dde <consolewrite+0x58>
    80004d94:	e4a6                	sd	s1,72(sp)
    80004d96:	fc4e                	sd	s3,56(sp)
    80004d98:	f852                	sd	s4,48(sp)
    80004d9a:	f456                	sd	s5,40(sp)
    80004d9c:	f05a                	sd	s6,32(sp)
    80004d9e:	ec5e                	sd	s7,24(sp)
    80004da0:	8a2a                	mv	s4,a0
    80004da2:	84ae                	mv	s1,a1
    80004da4:	89b2                	mv	s3,a2
    80004da6:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80004da8:	faf40b93          	addi	s7,s0,-81
    80004dac:	4b05                	li	s6,1
    80004dae:	5afd                	li	s5,-1
    80004db0:	86da                	mv	a3,s6
    80004db2:	8626                	mv	a2,s1
    80004db4:	85d2                	mv	a1,s4
    80004db6:	855e                	mv	a0,s7
    80004db8:	941fc0ef          	jal	800016f8 <either_copyin>
    80004dbc:	03550363          	beq	a0,s5,80004de2 <consolewrite+0x5c>
      break;
    uartputc(c);
    80004dc0:	faf44503          	lbu	a0,-81(s0)
    80004dc4:	06b000ef          	jal	8000562e <uartputc>
  for(i = 0; i < n; i++){
    80004dc8:	2905                	addiw	s2,s2,1
    80004dca:	0485                	addi	s1,s1,1
    80004dcc:	ff2992e3          	bne	s3,s2,80004db0 <consolewrite+0x2a>
    80004dd0:	64a6                	ld	s1,72(sp)
    80004dd2:	79e2                	ld	s3,56(sp)
    80004dd4:	7a42                	ld	s4,48(sp)
    80004dd6:	7aa2                	ld	s5,40(sp)
    80004dd8:	7b02                	ld	s6,32(sp)
    80004dda:	6be2                	ld	s7,24(sp)
    80004ddc:	a809                	j	80004dee <consolewrite+0x68>
    80004dde:	4901                	li	s2,0
    80004de0:	a039                	j	80004dee <consolewrite+0x68>
    80004de2:	64a6                	ld	s1,72(sp)
    80004de4:	79e2                	ld	s3,56(sp)
    80004de6:	7a42                	ld	s4,48(sp)
    80004de8:	7aa2                	ld	s5,40(sp)
    80004dea:	7b02                	ld	s6,32(sp)
    80004dec:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    80004dee:	854a                	mv	a0,s2
    80004df0:	60e6                	ld	ra,88(sp)
    80004df2:	6446                	ld	s0,80(sp)
    80004df4:	6906                	ld	s2,64(sp)
    80004df6:	6125                	addi	sp,sp,96
    80004df8:	8082                	ret

0000000080004dfa <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80004dfa:	711d                	addi	sp,sp,-96
    80004dfc:	ec86                	sd	ra,88(sp)
    80004dfe:	e8a2                	sd	s0,80(sp)
    80004e00:	e4a6                	sd	s1,72(sp)
    80004e02:	e0ca                	sd	s2,64(sp)
    80004e04:	fc4e                	sd	s3,56(sp)
    80004e06:	f852                	sd	s4,48(sp)
    80004e08:	f05a                	sd	s6,32(sp)
    80004e0a:	ec5e                	sd	s7,24(sp)
    80004e0c:	1080                	addi	s0,sp,96
    80004e0e:	8b2a                	mv	s6,a0
    80004e10:	8a2e                	mv	s4,a1
    80004e12:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80004e14:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80004e16:	0001c517          	auipc	a0,0x1c
    80004e1a:	d1a50513          	addi	a0,a0,-742 # 80020b30 <cons>
    80004e1e:	1af000ef          	jal	800057cc <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80004e22:	0001c497          	auipc	s1,0x1c
    80004e26:	d0e48493          	addi	s1,s1,-754 # 80020b30 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80004e2a:	0001c917          	auipc	s2,0x1c
    80004e2e:	d9e90913          	addi	s2,s2,-610 # 80020bc8 <cons+0x98>
  while(n > 0){
    80004e32:	0b305b63          	blez	s3,80004ee8 <consoleread+0xee>
    while(cons.r == cons.w){
    80004e36:	0984a783          	lw	a5,152(s1)
    80004e3a:	09c4a703          	lw	a4,156(s1)
    80004e3e:	0af71063          	bne	a4,a5,80004ede <consoleread+0xe4>
      if(killed(myproc())){
    80004e42:	f41fb0ef          	jal	80000d82 <myproc>
    80004e46:	f4afc0ef          	jal	80001590 <killed>
    80004e4a:	e12d                	bnez	a0,80004eac <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    80004e4c:	85a6                	mv	a1,s1
    80004e4e:	854a                	mv	a0,s2
    80004e50:	d04fc0ef          	jal	80001354 <sleep>
    while(cons.r == cons.w){
    80004e54:	0984a783          	lw	a5,152(s1)
    80004e58:	09c4a703          	lw	a4,156(s1)
    80004e5c:	fef703e3          	beq	a4,a5,80004e42 <consoleread+0x48>
    80004e60:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80004e62:	0001c717          	auipc	a4,0x1c
    80004e66:	cce70713          	addi	a4,a4,-818 # 80020b30 <cons>
    80004e6a:	0017869b          	addiw	a3,a5,1
    80004e6e:	08d72c23          	sw	a3,152(a4)
    80004e72:	07f7f693          	andi	a3,a5,127
    80004e76:	9736                	add	a4,a4,a3
    80004e78:	01874703          	lbu	a4,24(a4)
    80004e7c:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    80004e80:	4691                	li	a3,4
    80004e82:	04da8663          	beq	s5,a3,80004ece <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80004e86:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004e8a:	4685                	li	a3,1
    80004e8c:	faf40613          	addi	a2,s0,-81
    80004e90:	85d2                	mv	a1,s4
    80004e92:	855a                	mv	a0,s6
    80004e94:	81bfc0ef          	jal	800016ae <either_copyout>
    80004e98:	57fd                	li	a5,-1
    80004e9a:	04f50663          	beq	a0,a5,80004ee6 <consoleread+0xec>
      break;

    dst++;
    80004e9e:	0a05                	addi	s4,s4,1
    --n;
    80004ea0:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80004ea2:	47a9                	li	a5,10
    80004ea4:	04fa8b63          	beq	s5,a5,80004efa <consoleread+0x100>
    80004ea8:	7aa2                	ld	s5,40(sp)
    80004eaa:	b761                	j	80004e32 <consoleread+0x38>
        release(&cons.lock);
    80004eac:	0001c517          	auipc	a0,0x1c
    80004eb0:	c8450513          	addi	a0,a0,-892 # 80020b30 <cons>
    80004eb4:	1ad000ef          	jal	80005860 <release>
        return -1;
    80004eb8:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80004eba:	60e6                	ld	ra,88(sp)
    80004ebc:	6446                	ld	s0,80(sp)
    80004ebe:	64a6                	ld	s1,72(sp)
    80004ec0:	6906                	ld	s2,64(sp)
    80004ec2:	79e2                	ld	s3,56(sp)
    80004ec4:	7a42                	ld	s4,48(sp)
    80004ec6:	7b02                	ld	s6,32(sp)
    80004ec8:	6be2                	ld	s7,24(sp)
    80004eca:	6125                	addi	sp,sp,96
    80004ecc:	8082                	ret
      if(n < target){
    80004ece:	0179fa63          	bgeu	s3,s7,80004ee2 <consoleread+0xe8>
        cons.r--;
    80004ed2:	0001c717          	auipc	a4,0x1c
    80004ed6:	cef72b23          	sw	a5,-778(a4) # 80020bc8 <cons+0x98>
    80004eda:	7aa2                	ld	s5,40(sp)
    80004edc:	a031                	j	80004ee8 <consoleread+0xee>
    80004ede:	f456                	sd	s5,40(sp)
    80004ee0:	b749                	j	80004e62 <consoleread+0x68>
    80004ee2:	7aa2                	ld	s5,40(sp)
    80004ee4:	a011                	j	80004ee8 <consoleread+0xee>
    80004ee6:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80004ee8:	0001c517          	auipc	a0,0x1c
    80004eec:	c4850513          	addi	a0,a0,-952 # 80020b30 <cons>
    80004ef0:	171000ef          	jal	80005860 <release>
  return target - n;
    80004ef4:	413b853b          	subw	a0,s7,s3
    80004ef8:	b7c9                	j	80004eba <consoleread+0xc0>
    80004efa:	7aa2                	ld	s5,40(sp)
    80004efc:	b7f5                	j	80004ee8 <consoleread+0xee>

0000000080004efe <consputc>:
{
    80004efe:	1141                	addi	sp,sp,-16
    80004f00:	e406                	sd	ra,8(sp)
    80004f02:	e022                	sd	s0,0(sp)
    80004f04:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80004f06:	10000793          	li	a5,256
    80004f0a:	00f50863          	beq	a0,a5,80004f1a <consputc+0x1c>
    uartputc_sync(c);
    80004f0e:	63e000ef          	jal	8000554c <uartputc_sync>
}
    80004f12:	60a2                	ld	ra,8(sp)
    80004f14:	6402                	ld	s0,0(sp)
    80004f16:	0141                	addi	sp,sp,16
    80004f18:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80004f1a:	4521                	li	a0,8
    80004f1c:	630000ef          	jal	8000554c <uartputc_sync>
    80004f20:	02000513          	li	a0,32
    80004f24:	628000ef          	jal	8000554c <uartputc_sync>
    80004f28:	4521                	li	a0,8
    80004f2a:	622000ef          	jal	8000554c <uartputc_sync>
    80004f2e:	b7d5                	j	80004f12 <consputc+0x14>

0000000080004f30 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80004f30:	1101                	addi	sp,sp,-32
    80004f32:	ec06                	sd	ra,24(sp)
    80004f34:	e822                	sd	s0,16(sp)
    80004f36:	e426                	sd	s1,8(sp)
    80004f38:	1000                	addi	s0,sp,32
    80004f3a:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80004f3c:	0001c517          	auipc	a0,0x1c
    80004f40:	bf450513          	addi	a0,a0,-1036 # 80020b30 <cons>
    80004f44:	089000ef          	jal	800057cc <acquire>

  switch(c){
    80004f48:	47d5                	li	a5,21
    80004f4a:	08f48d63          	beq	s1,a5,80004fe4 <consoleintr+0xb4>
    80004f4e:	0297c563          	blt	a5,s1,80004f78 <consoleintr+0x48>
    80004f52:	47a1                	li	a5,8
    80004f54:	0ef48263          	beq	s1,a5,80005038 <consoleintr+0x108>
    80004f58:	47c1                	li	a5,16
    80004f5a:	10f49363          	bne	s1,a5,80005060 <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    80004f5e:	fe4fc0ef          	jal	80001742 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    80004f62:	0001c517          	auipc	a0,0x1c
    80004f66:	bce50513          	addi	a0,a0,-1074 # 80020b30 <cons>
    80004f6a:	0f7000ef          	jal	80005860 <release>
}
    80004f6e:	60e2                	ld	ra,24(sp)
    80004f70:	6442                	ld	s0,16(sp)
    80004f72:	64a2                	ld	s1,8(sp)
    80004f74:	6105                	addi	sp,sp,32
    80004f76:	8082                	ret
  switch(c){
    80004f78:	07f00793          	li	a5,127
    80004f7c:	0af48e63          	beq	s1,a5,80005038 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80004f80:	0001c717          	auipc	a4,0x1c
    80004f84:	bb070713          	addi	a4,a4,-1104 # 80020b30 <cons>
    80004f88:	0a072783          	lw	a5,160(a4)
    80004f8c:	09872703          	lw	a4,152(a4)
    80004f90:	9f99                	subw	a5,a5,a4
    80004f92:	07f00713          	li	a4,127
    80004f96:	fcf766e3          	bltu	a4,a5,80004f62 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80004f9a:	47b5                	li	a5,13
    80004f9c:	0cf48563          	beq	s1,a5,80005066 <consoleintr+0x136>
      consputc(c);
    80004fa0:	8526                	mv	a0,s1
    80004fa2:	f5dff0ef          	jal	80004efe <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80004fa6:	0001c717          	auipc	a4,0x1c
    80004faa:	b8a70713          	addi	a4,a4,-1142 # 80020b30 <cons>
    80004fae:	0a072683          	lw	a3,160(a4)
    80004fb2:	0016879b          	addiw	a5,a3,1
    80004fb6:	863e                	mv	a2,a5
    80004fb8:	0af72023          	sw	a5,160(a4)
    80004fbc:	07f6f693          	andi	a3,a3,127
    80004fc0:	9736                	add	a4,a4,a3
    80004fc2:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80004fc6:	ff648713          	addi	a4,s1,-10
    80004fca:	c371                	beqz	a4,8000508e <consoleintr+0x15e>
    80004fcc:	14f1                	addi	s1,s1,-4
    80004fce:	c0e1                	beqz	s1,8000508e <consoleintr+0x15e>
    80004fd0:	0001c717          	auipc	a4,0x1c
    80004fd4:	bf872703          	lw	a4,-1032(a4) # 80020bc8 <cons+0x98>
    80004fd8:	9f99                	subw	a5,a5,a4
    80004fda:	08000713          	li	a4,128
    80004fde:	f8e792e3          	bne	a5,a4,80004f62 <consoleintr+0x32>
    80004fe2:	a075                	j	8000508e <consoleintr+0x15e>
    80004fe4:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80004fe6:	0001c717          	auipc	a4,0x1c
    80004fea:	b4a70713          	addi	a4,a4,-1206 # 80020b30 <cons>
    80004fee:	0a072783          	lw	a5,160(a4)
    80004ff2:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80004ff6:	0001c497          	auipc	s1,0x1c
    80004ffa:	b3a48493          	addi	s1,s1,-1222 # 80020b30 <cons>
    while(cons.e != cons.w &&
    80004ffe:	4929                	li	s2,10
    80005000:	02f70863          	beq	a4,a5,80005030 <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005004:	37fd                	addiw	a5,a5,-1
    80005006:	07f7f713          	andi	a4,a5,127
    8000500a:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000500c:	01874703          	lbu	a4,24(a4)
    80005010:	03270263          	beq	a4,s2,80005034 <consoleintr+0x104>
      cons.e--;
    80005014:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005018:	10000513          	li	a0,256
    8000501c:	ee3ff0ef          	jal	80004efe <consputc>
    while(cons.e != cons.w &&
    80005020:	0a04a783          	lw	a5,160(s1)
    80005024:	09c4a703          	lw	a4,156(s1)
    80005028:	fcf71ee3          	bne	a4,a5,80005004 <consoleintr+0xd4>
    8000502c:	6902                	ld	s2,0(sp)
    8000502e:	bf15                	j	80004f62 <consoleintr+0x32>
    80005030:	6902                	ld	s2,0(sp)
    80005032:	bf05                	j	80004f62 <consoleintr+0x32>
    80005034:	6902                	ld	s2,0(sp)
    80005036:	b735                	j	80004f62 <consoleintr+0x32>
    if(cons.e != cons.w){
    80005038:	0001c717          	auipc	a4,0x1c
    8000503c:	af870713          	addi	a4,a4,-1288 # 80020b30 <cons>
    80005040:	0a072783          	lw	a5,160(a4)
    80005044:	09c72703          	lw	a4,156(a4)
    80005048:	f0f70de3          	beq	a4,a5,80004f62 <consoleintr+0x32>
      cons.e--;
    8000504c:	37fd                	addiw	a5,a5,-1
    8000504e:	0001c717          	auipc	a4,0x1c
    80005052:	b8f72123          	sw	a5,-1150(a4) # 80020bd0 <cons+0xa0>
      consputc(BACKSPACE);
    80005056:	10000513          	li	a0,256
    8000505a:	ea5ff0ef          	jal	80004efe <consputc>
    8000505e:	b711                	j	80004f62 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005060:	f00481e3          	beqz	s1,80004f62 <consoleintr+0x32>
    80005064:	bf31                	j	80004f80 <consoleintr+0x50>
      consputc(c);
    80005066:	4529                	li	a0,10
    80005068:	e97ff0ef          	jal	80004efe <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    8000506c:	0001c797          	auipc	a5,0x1c
    80005070:	ac478793          	addi	a5,a5,-1340 # 80020b30 <cons>
    80005074:	0a07a703          	lw	a4,160(a5)
    80005078:	0017069b          	addiw	a3,a4,1
    8000507c:	8636                	mv	a2,a3
    8000507e:	0ad7a023          	sw	a3,160(a5)
    80005082:	07f77713          	andi	a4,a4,127
    80005086:	97ba                	add	a5,a5,a4
    80005088:	4729                	li	a4,10
    8000508a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000508e:	0001c797          	auipc	a5,0x1c
    80005092:	b2c7af23          	sw	a2,-1218(a5) # 80020bcc <cons+0x9c>
        wakeup(&cons.r);
    80005096:	0001c517          	auipc	a0,0x1c
    8000509a:	b3250513          	addi	a0,a0,-1230 # 80020bc8 <cons+0x98>
    8000509e:	b02fc0ef          	jal	800013a0 <wakeup>
    800050a2:	b5c1                	j	80004f62 <consoleintr+0x32>

00000000800050a4 <consoleinit>:

void
consoleinit(void)
{
    800050a4:	1141                	addi	sp,sp,-16
    800050a6:	e406                	sd	ra,8(sp)
    800050a8:	e022                	sd	s0,0(sp)
    800050aa:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800050ac:	00002597          	auipc	a1,0x2
    800050b0:	66458593          	addi	a1,a1,1636 # 80007710 <etext+0x710>
    800050b4:	0001c517          	auipc	a0,0x1c
    800050b8:	a7c50513          	addi	a0,a0,-1412 # 80020b30 <cons>
    800050bc:	686000ef          	jal	80005742 <initlock>

  uartinit();
    800050c0:	436000ef          	jal	800054f6 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    800050c4:	00013797          	auipc	a5,0x13
    800050c8:	8d478793          	addi	a5,a5,-1836 # 80017998 <devsw>
    800050cc:	00000717          	auipc	a4,0x0
    800050d0:	d2e70713          	addi	a4,a4,-722 # 80004dfa <consoleread>
    800050d4:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    800050d6:	00000717          	auipc	a4,0x0
    800050da:	cb070713          	addi	a4,a4,-848 # 80004d86 <consolewrite>
    800050de:	ef98                	sd	a4,24(a5)
}
    800050e0:	60a2                	ld	ra,8(sp)
    800050e2:	6402                	ld	s0,0(sp)
    800050e4:	0141                	addi	sp,sp,16
    800050e6:	8082                	ret

00000000800050e8 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    800050e8:	7179                	addi	sp,sp,-48
    800050ea:	f406                	sd	ra,40(sp)
    800050ec:	f022                	sd	s0,32(sp)
    800050ee:	e84a                	sd	s2,16(sp)
    800050f0:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    800050f2:	c219                	beqz	a2,800050f8 <printint+0x10>
    800050f4:	08054163          	bltz	a0,80005176 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    800050f8:	4301                	li	t1,0

  i = 0;
    800050fa:	fd040913          	addi	s2,s0,-48
    x = xx;
    800050fe:	86ca                	mv	a3,s2
  i = 0;
    80005100:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005102:	00002817          	auipc	a6,0x2
    80005106:	76680813          	addi	a6,a6,1894 # 80007868 <digits>
    8000510a:	88ba                	mv	a7,a4
    8000510c:	0017061b          	addiw	a2,a4,1
    80005110:	8732                	mv	a4,a2
    80005112:	02b577b3          	remu	a5,a0,a1
    80005116:	97c2                	add	a5,a5,a6
    80005118:	0007c783          	lbu	a5,0(a5)
    8000511c:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005120:	87aa                	mv	a5,a0
    80005122:	02b55533          	divu	a0,a0,a1
    80005126:	0685                	addi	a3,a3,1
    80005128:	feb7f1e3          	bgeu	a5,a1,8000510a <printint+0x22>

  if(sign)
    8000512c:	00030c63          	beqz	t1,80005144 <printint+0x5c>
    buf[i++] = '-';
    80005130:	fe060793          	addi	a5,a2,-32
    80005134:	00878633          	add	a2,a5,s0
    80005138:	02d00793          	li	a5,45
    8000513c:	fef60823          	sb	a5,-16(a2)
    80005140:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80005144:	02e05463          	blez	a4,8000516c <printint+0x84>
    80005148:	ec26                	sd	s1,24(sp)
    8000514a:	377d                	addiw	a4,a4,-1
    8000514c:	00e904b3          	add	s1,s2,a4
    80005150:	197d                	addi	s2,s2,-1
    80005152:	993a                	add	s2,s2,a4
    80005154:	1702                	slli	a4,a4,0x20
    80005156:	9301                	srli	a4,a4,0x20
    80005158:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    8000515c:	0004c503          	lbu	a0,0(s1)
    80005160:	d9fff0ef          	jal	80004efe <consputc>
  while(--i >= 0)
    80005164:	14fd                	addi	s1,s1,-1
    80005166:	ff249be3          	bne	s1,s2,8000515c <printint+0x74>
    8000516a:	64e2                	ld	s1,24(sp)
}
    8000516c:	70a2                	ld	ra,40(sp)
    8000516e:	7402                	ld	s0,32(sp)
    80005170:	6942                	ld	s2,16(sp)
    80005172:	6145                	addi	sp,sp,48
    80005174:	8082                	ret
    x = -xx;
    80005176:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    8000517a:	4305                	li	t1,1
    x = -xx;
    8000517c:	bfbd                	j	800050fa <printint+0x12>

000000008000517e <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    8000517e:	7131                	addi	sp,sp,-192
    80005180:	fc86                	sd	ra,120(sp)
    80005182:	f8a2                	sd	s0,112(sp)
    80005184:	f0ca                	sd	s2,96(sp)
    80005186:	ec6e                	sd	s11,24(sp)
    80005188:	0100                	addi	s0,sp,128
    8000518a:	892a                	mv	s2,a0
    8000518c:	e40c                	sd	a1,8(s0)
    8000518e:	e810                	sd	a2,16(s0)
    80005190:	ec14                	sd	a3,24(s0)
    80005192:	f018                	sd	a4,32(s0)
    80005194:	f41c                	sd	a5,40(s0)
    80005196:	03043823          	sd	a6,48(s0)
    8000519a:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    8000519e:	0001cd97          	auipc	s11,0x1c
    800051a2:	a52dad83          	lw	s11,-1454(s11) # 80020bf0 <pr+0x18>
  if(locking)
    800051a6:	020d9d63          	bnez	s11,800051e0 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800051aa:	00840793          	addi	a5,s0,8
    800051ae:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800051b2:	00054503          	lbu	a0,0(a0)
    800051b6:	20050f63          	beqz	a0,800053d4 <printf+0x256>
    800051ba:	f4a6                	sd	s1,104(sp)
    800051bc:	ecce                	sd	s3,88(sp)
    800051be:	e8d2                	sd	s4,80(sp)
    800051c0:	e4d6                	sd	s5,72(sp)
    800051c2:	e0da                	sd	s6,64(sp)
    800051c4:	fc5e                	sd	s7,56(sp)
    800051c6:	f862                	sd	s8,48(sp)
    800051c8:	f06a                	sd	s10,32(sp)
    800051ca:	4a81                	li	s5,0
    if(cx != '%'){
    800051cc:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    800051d0:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    800051d4:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    800051d8:	4b29                	li	s6,10
    if(c0 == 'd'){
    800051da:	06400b93          	li	s7,100
    800051de:	a80d                	j	80005210 <printf+0x92>
    acquire(&pr.lock);
    800051e0:	0001c517          	auipc	a0,0x1c
    800051e4:	9f850513          	addi	a0,a0,-1544 # 80020bd8 <pr>
    800051e8:	5e4000ef          	jal	800057cc <acquire>
  va_start(ap, fmt);
    800051ec:	00840793          	addi	a5,s0,8
    800051f0:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800051f4:	00094503          	lbu	a0,0(s2)
    800051f8:	f169                	bnez	a0,800051ba <printf+0x3c>
    800051fa:	aae5                	j	800053f2 <printf+0x274>
      consputc(cx);
    800051fc:	d03ff0ef          	jal	80004efe <consputc>
      continue;
    80005200:	84d6                	mv	s1,s5
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005202:	2485                	addiw	s1,s1,1
    80005204:	8aa6                	mv	s5,s1
    80005206:	94ca                	add	s1,s1,s2
    80005208:	0004c503          	lbu	a0,0(s1)
    8000520c:	1a050a63          	beqz	a0,800053c0 <printf+0x242>
    if(cx != '%'){
    80005210:	ff3516e3          	bne	a0,s3,800051fc <printf+0x7e>
    i++;
    80005214:	001a879b          	addiw	a5,s5,1
    80005218:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000521a:	00f90733          	add	a4,s2,a5
    8000521e:	00074a03          	lbu	s4,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005222:	1e0a0863          	beqz	s4,80005412 <printf+0x294>
    80005226:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000522a:	1c068b63          	beqz	a3,80005400 <printf+0x282>
    if(c0 == 'd'){
    8000522e:	037a0863          	beq	s4,s7,8000525e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005232:	f94a0713          	addi	a4,s4,-108
    80005236:	00173713          	seqz	a4,a4
    8000523a:	f9c68613          	addi	a2,a3,-100
    8000523e:	ee05                	bnez	a2,80005276 <printf+0xf8>
    80005240:	cb1d                	beqz	a4,80005276 <printf+0xf8>
      printint(va_arg(ap, uint64), 10, 1);
    80005242:	f8843783          	ld	a5,-120(s0)
    80005246:	00878713          	addi	a4,a5,8
    8000524a:	f8e43423          	sd	a4,-120(s0)
    8000524e:	4605                	li	a2,1
    80005250:	85da                	mv	a1,s6
    80005252:	6388                	ld	a0,0(a5)
    80005254:	e95ff0ef          	jal	800050e8 <printint>
      i += 1;
    80005258:	002a849b          	addiw	s1,s5,2
    8000525c:	b75d                	j	80005202 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    8000525e:	f8843783          	ld	a5,-120(s0)
    80005262:	00878713          	addi	a4,a5,8
    80005266:	f8e43423          	sd	a4,-120(s0)
    8000526a:	4605                	li	a2,1
    8000526c:	85da                	mv	a1,s6
    8000526e:	4388                	lw	a0,0(a5)
    80005270:	e79ff0ef          	jal	800050e8 <printint>
    80005274:	b779                	j	80005202 <printf+0x84>
    if(c1) c2 = fmt[i+2] & 0xff;
    80005276:	97ca                	add	a5,a5,s2
    80005278:	8636                	mv	a2,a3
    8000527a:	0027c683          	lbu	a3,2(a5)
    8000527e:	a245                	j	8000541e <printf+0x2a0>
      printint(va_arg(ap, uint64), 10, 1);
    80005280:	f8843783          	ld	a5,-120(s0)
    80005284:	00878713          	addi	a4,a5,8
    80005288:	f8e43423          	sd	a4,-120(s0)
    8000528c:	4605                	li	a2,1
    8000528e:	45a9                	li	a1,10
    80005290:	6388                	ld	a0,0(a5)
    80005292:	e57ff0ef          	jal	800050e8 <printint>
      i += 2;
    80005296:	003a849b          	addiw	s1,s5,3
    8000529a:	b7a5                	j	80005202 <printf+0x84>
      printint(va_arg(ap, int), 10, 0);
    8000529c:	f8843783          	ld	a5,-120(s0)
    800052a0:	00878713          	addi	a4,a5,8
    800052a4:	f8e43423          	sd	a4,-120(s0)
    800052a8:	4601                	li	a2,0
    800052aa:	85da                	mv	a1,s6
    800052ac:	4388                	lw	a0,0(a5)
    800052ae:	e3bff0ef          	jal	800050e8 <printint>
    800052b2:	bf81                	j	80005202 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800052b4:	f8843783          	ld	a5,-120(s0)
    800052b8:	00878713          	addi	a4,a5,8
    800052bc:	f8e43423          	sd	a4,-120(s0)
    800052c0:	4601                	li	a2,0
    800052c2:	85da                	mv	a1,s6
    800052c4:	6388                	ld	a0,0(a5)
    800052c6:	e23ff0ef          	jal	800050e8 <printint>
      i += 1;
    800052ca:	002a849b          	addiw	s1,s5,2
    800052ce:	bf15                	j	80005202 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800052d0:	f8843783          	ld	a5,-120(s0)
    800052d4:	00878713          	addi	a4,a5,8
    800052d8:	f8e43423          	sd	a4,-120(s0)
    800052dc:	4601                	li	a2,0
    800052de:	45a9                	li	a1,10
    800052e0:	6388                	ld	a0,0(a5)
    800052e2:	e07ff0ef          	jal	800050e8 <printint>
      i += 2;
    800052e6:	003a849b          	addiw	s1,s5,3
    800052ea:	bf21                	j	80005202 <printf+0x84>
      printint(va_arg(ap, int), 16, 0);
    800052ec:	f8843783          	ld	a5,-120(s0)
    800052f0:	00878713          	addi	a4,a5,8
    800052f4:	f8e43423          	sd	a4,-120(s0)
    800052f8:	4601                	li	a2,0
    800052fa:	45c1                	li	a1,16
    800052fc:	4388                	lw	a0,0(a5)
    800052fe:	debff0ef          	jal	800050e8 <printint>
    80005302:	b701                	j	80005202 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80005304:	f8843783          	ld	a5,-120(s0)
    80005308:	00878713          	addi	a4,a5,8
    8000530c:	f8e43423          	sd	a4,-120(s0)
    80005310:	45c1                	li	a1,16
    80005312:	6388                	ld	a0,0(a5)
    80005314:	dd5ff0ef          	jal	800050e8 <printint>
      i += 1;
    80005318:	002a849b          	addiw	s1,s5,2
    8000531c:	b5dd                	j	80005202 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    8000531e:	f8843783          	ld	a5,-120(s0)
    80005322:	00878713          	addi	a4,a5,8
    80005326:	f8e43423          	sd	a4,-120(s0)
    8000532a:	4601                	li	a2,0
    8000532c:	45c1                	li	a1,16
    8000532e:	6388                	ld	a0,0(a5)
    80005330:	db9ff0ef          	jal	800050e8 <printint>
      i += 2;
    80005334:	003a849b          	addiw	s1,s5,3
    80005338:	b5e9                	j	80005202 <printf+0x84>
    8000533a:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    8000533c:	f8843783          	ld	a5,-120(s0)
    80005340:	00878713          	addi	a4,a5,8
    80005344:	f8e43423          	sd	a4,-120(s0)
    80005348:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    8000534c:	03000513          	li	a0,48
    80005350:	bafff0ef          	jal	80004efe <consputc>
  consputc('x');
    80005354:	07800513          	li	a0,120
    80005358:	ba7ff0ef          	jal	80004efe <consputc>
    8000535c:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000535e:	00002c97          	auipc	s9,0x2
    80005362:	50ac8c93          	addi	s9,s9,1290 # 80007868 <digits>
    80005366:	03cad793          	srli	a5,s5,0x3c
    8000536a:	97e6                	add	a5,a5,s9
    8000536c:	0007c503          	lbu	a0,0(a5)
    80005370:	b8fff0ef          	jal	80004efe <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    80005374:	0a92                	slli	s5,s5,0x4
    80005376:	3a7d                	addiw	s4,s4,-1
    80005378:	fe0a17e3          	bnez	s4,80005366 <printf+0x1e8>
    8000537c:	7ca2                	ld	s9,40(sp)
    8000537e:	b551                	j	80005202 <printf+0x84>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80005380:	f8843783          	ld	a5,-120(s0)
    80005384:	00878713          	addi	a4,a5,8
    80005388:	f8e43423          	sd	a4,-120(s0)
    8000538c:	0007ba03          	ld	s4,0(a5)
    80005390:	000a0d63          	beqz	s4,800053aa <printf+0x22c>
        s = "(null)";
      for(; *s; s++)
    80005394:	000a4503          	lbu	a0,0(s4)
    80005398:	e60505e3          	beqz	a0,80005202 <printf+0x84>
        consputc(*s);
    8000539c:	b63ff0ef          	jal	80004efe <consputc>
      for(; *s; s++)
    800053a0:	0a05                	addi	s4,s4,1
    800053a2:	000a4503          	lbu	a0,0(s4)
    800053a6:	f97d                	bnez	a0,8000539c <printf+0x21e>
    800053a8:	bda9                	j	80005202 <printf+0x84>
        s = "(null)";
    800053aa:	00002a17          	auipc	s4,0x2
    800053ae:	36ea0a13          	addi	s4,s4,878 # 80007718 <etext+0x718>
      for(; *s; s++)
    800053b2:	02800513          	li	a0,40
    800053b6:	b7dd                	j	8000539c <printf+0x21e>
    } else if(c0 == '%'){
      consputc('%');
    800053b8:	8552                	mv	a0,s4
    800053ba:	b45ff0ef          	jal	80004efe <consputc>
    800053be:	b591                	j	80005202 <printf+0x84>
    }
#endif
  }
  va_end(ap);

  if(locking)
    800053c0:	020d9163          	bnez	s11,800053e2 <printf+0x264>
    800053c4:	74a6                	ld	s1,104(sp)
    800053c6:	69e6                	ld	s3,88(sp)
    800053c8:	6a46                	ld	s4,80(sp)
    800053ca:	6aa6                	ld	s5,72(sp)
    800053cc:	6b06                	ld	s6,64(sp)
    800053ce:	7be2                	ld	s7,56(sp)
    800053d0:	7c42                	ld	s8,48(sp)
    800053d2:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    800053d4:	4501                	li	a0,0
    800053d6:	70e6                	ld	ra,120(sp)
    800053d8:	7446                	ld	s0,112(sp)
    800053da:	7906                	ld	s2,96(sp)
    800053dc:	6de2                	ld	s11,24(sp)
    800053de:	6129                	addi	sp,sp,192
    800053e0:	8082                	ret
    800053e2:	74a6                	ld	s1,104(sp)
    800053e4:	69e6                	ld	s3,88(sp)
    800053e6:	6a46                	ld	s4,80(sp)
    800053e8:	6aa6                	ld	s5,72(sp)
    800053ea:	6b06                	ld	s6,64(sp)
    800053ec:	7be2                	ld	s7,56(sp)
    800053ee:	7c42                	ld	s8,48(sp)
    800053f0:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    800053f2:	0001b517          	auipc	a0,0x1b
    800053f6:	7e650513          	addi	a0,a0,2022 # 80020bd8 <pr>
    800053fa:	466000ef          	jal	80005860 <release>
    800053fe:	bfd9                	j	800053d4 <printf+0x256>
    if(c0 == 'd'){
    80005400:	e57a0fe3          	beq	s4,s7,8000525e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005404:	f94a0713          	addi	a4,s4,-108
    80005408:	00173713          	seqz	a4,a4
    8000540c:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000540e:	4781                	li	a5,0
    80005410:	a00d                	j	80005432 <printf+0x2b4>
    } else if(c0 == 'l' && c1 == 'd'){
    80005412:	f94a0713          	addi	a4,s4,-108
    80005416:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    8000541a:	8652                	mv	a2,s4
    8000541c:	86d2                	mv	a3,s4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000541e:	f9460793          	addi	a5,a2,-108
    80005422:	0017b793          	seqz	a5,a5
    80005426:	8ff9                	and	a5,a5,a4
    80005428:	f9c68593          	addi	a1,a3,-100
    8000542c:	e199                	bnez	a1,80005432 <printf+0x2b4>
    8000542e:	e40799e3          	bnez	a5,80005280 <printf+0x102>
    } else if(c0 == 'u'){
    80005432:	e78a05e3          	beq	s4,s8,8000529c <printf+0x11e>
    } else if(c0 == 'l' && c1 == 'u'){
    80005436:	f8b60593          	addi	a1,a2,-117
    8000543a:	e199                	bnez	a1,80005440 <printf+0x2c2>
    8000543c:	e6071ce3          	bnez	a4,800052b4 <printf+0x136>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005440:	f8b68593          	addi	a1,a3,-117
    80005444:	e199                	bnez	a1,8000544a <printf+0x2cc>
    80005446:	e80795e3          	bnez	a5,800052d0 <printf+0x152>
    } else if(c0 == 'x'){
    8000544a:	ebaa01e3          	beq	s4,s10,800052ec <printf+0x16e>
    } else if(c0 == 'l' && c1 == 'x'){
    8000544e:	f8860613          	addi	a2,a2,-120
    80005452:	e219                	bnez	a2,80005458 <printf+0x2da>
    80005454:	ea0718e3          	bnez	a4,80005304 <printf+0x186>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    80005458:	f8868693          	addi	a3,a3,-120
    8000545c:	e299                	bnez	a3,80005462 <printf+0x2e4>
    8000545e:	ec0790e3          	bnez	a5,8000531e <printf+0x1a0>
    } else if(c0 == 'p'){
    80005462:	07000793          	li	a5,112
    80005466:	ecfa0ae3          	beq	s4,a5,8000533a <printf+0x1bc>
    } else if(c0 == 's'){
    8000546a:	07300793          	li	a5,115
    8000546e:	f0fa09e3          	beq	s4,a5,80005380 <printf+0x202>
    } else if(c0 == '%'){
    80005472:	02500793          	li	a5,37
    80005476:	f4fa01e3          	beq	s4,a5,800053b8 <printf+0x23a>
    } else if(c0 == 0){
    8000547a:	f40a03e3          	beqz	s4,800053c0 <printf+0x242>
      consputc('%');
    8000547e:	02500513          	li	a0,37
    80005482:	a7dff0ef          	jal	80004efe <consputc>
      consputc(c0);
    80005486:	8552                	mv	a0,s4
    80005488:	a77ff0ef          	jal	80004efe <consputc>
    8000548c:	bb9d                	j	80005202 <printf+0x84>

000000008000548e <panic>:

void
panic(char *s)
{
    8000548e:	1101                	addi	sp,sp,-32
    80005490:	ec06                	sd	ra,24(sp)
    80005492:	e822                	sd	s0,16(sp)
    80005494:	e426                	sd	s1,8(sp)
    80005496:	1000                	addi	s0,sp,32
    80005498:	84aa                	mv	s1,a0
  pr.locking = 0;
    8000549a:	0001b797          	auipc	a5,0x1b
    8000549e:	7407ab23          	sw	zero,1878(a5) # 80020bf0 <pr+0x18>
  printf("panic: ");
    800054a2:	00002517          	auipc	a0,0x2
    800054a6:	27e50513          	addi	a0,a0,638 # 80007720 <etext+0x720>
    800054aa:	cd5ff0ef          	jal	8000517e <printf>
  printf("%s\n", s);
    800054ae:	85a6                	mv	a1,s1
    800054b0:	00002517          	auipc	a0,0x2
    800054b4:	27850513          	addi	a0,a0,632 # 80007728 <etext+0x728>
    800054b8:	cc7ff0ef          	jal	8000517e <printf>
  panicked = 1; // freeze uart output from other CPUs
    800054bc:	4785                	li	a5,1
    800054be:	00002717          	auipc	a4,0x2
    800054c2:	42f72723          	sw	a5,1070(a4) # 800078ec <panicked>
  for(;;)
    800054c6:	a001                	j	800054c6 <panic+0x38>

00000000800054c8 <printfinit>:
    ;
}

void
printfinit(void)
{
    800054c8:	1141                	addi	sp,sp,-16
    800054ca:	e406                	sd	ra,8(sp)
    800054cc:	e022                	sd	s0,0(sp)
    800054ce:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    800054d0:	00002597          	auipc	a1,0x2
    800054d4:	26058593          	addi	a1,a1,608 # 80007730 <etext+0x730>
    800054d8:	0001b517          	auipc	a0,0x1b
    800054dc:	70050513          	addi	a0,a0,1792 # 80020bd8 <pr>
    800054e0:	262000ef          	jal	80005742 <initlock>
  pr.locking = 1;
    800054e4:	4785                	li	a5,1
    800054e6:	0001b717          	auipc	a4,0x1b
    800054ea:	70f72523          	sw	a5,1802(a4) # 80020bf0 <pr+0x18>
}
    800054ee:	60a2                	ld	ra,8(sp)
    800054f0:	6402                	ld	s0,0(sp)
    800054f2:	0141                	addi	sp,sp,16
    800054f4:	8082                	ret

00000000800054f6 <uartinit>:

void uartstart();

void
uartinit(void)
{
    800054f6:	1141                	addi	sp,sp,-16
    800054f8:	e406                	sd	ra,8(sp)
    800054fa:	e022                	sd	s0,0(sp)
    800054fc:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800054fe:	100007b7          	lui	a5,0x10000
    80005502:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80005506:	10000737          	lui	a4,0x10000
    8000550a:	f8000693          	li	a3,-128
    8000550e:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005512:	468d                	li	a3,3
    80005514:	10000637          	lui	a2,0x10000
    80005518:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000551c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80005520:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80005524:	8732                	mv	a4,a2
    80005526:	461d                	li	a2,7
    80005528:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000552c:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80005530:	00002597          	auipc	a1,0x2
    80005534:	20858593          	addi	a1,a1,520 # 80007738 <etext+0x738>
    80005538:	0001b517          	auipc	a0,0x1b
    8000553c:	6c050513          	addi	a0,a0,1728 # 80020bf8 <uart_tx_lock>
    80005540:	202000ef          	jal	80005742 <initlock>
}
    80005544:	60a2                	ld	ra,8(sp)
    80005546:	6402                	ld	s0,0(sp)
    80005548:	0141                	addi	sp,sp,16
    8000554a:	8082                	ret

000000008000554c <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000554c:	1101                	addi	sp,sp,-32
    8000554e:	ec06                	sd	ra,24(sp)
    80005550:	e822                	sd	s0,16(sp)
    80005552:	e426                	sd	s1,8(sp)
    80005554:	1000                	addi	s0,sp,32
    80005556:	84aa                	mv	s1,a0
  push_off();
    80005558:	230000ef          	jal	80005788 <push_off>

  if(panicked){
    8000555c:	00002797          	auipc	a5,0x2
    80005560:	3907a783          	lw	a5,912(a5) # 800078ec <panicked>
    80005564:	e795                	bnez	a5,80005590 <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80005566:	10000737          	lui	a4,0x10000
    8000556a:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    8000556c:	00074783          	lbu	a5,0(a4)
    80005570:	0207f793          	andi	a5,a5,32
    80005574:	dfe5                	beqz	a5,8000556c <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    80005576:	0ff4f513          	zext.b	a0,s1
    8000557a:	100007b7          	lui	a5,0x10000
    8000557e:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80005582:	28e000ef          	jal	80005810 <pop_off>
}
    80005586:	60e2                	ld	ra,24(sp)
    80005588:	6442                	ld	s0,16(sp)
    8000558a:	64a2                	ld	s1,8(sp)
    8000558c:	6105                	addi	sp,sp,32
    8000558e:	8082                	ret
    for(;;)
    80005590:	a001                	j	80005590 <uartputc_sync+0x44>

0000000080005592 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80005592:	00002797          	auipc	a5,0x2
    80005596:	35e7b783          	ld	a5,862(a5) # 800078f0 <uart_tx_r>
    8000559a:	00002717          	auipc	a4,0x2
    8000559e:	35e73703          	ld	a4,862(a4) # 800078f8 <uart_tx_w>
    800055a2:	08f70163          	beq	a4,a5,80005624 <uartstart+0x92>
{
    800055a6:	7139                	addi	sp,sp,-64
    800055a8:	fc06                	sd	ra,56(sp)
    800055aa:	f822                	sd	s0,48(sp)
    800055ac:	f426                	sd	s1,40(sp)
    800055ae:	f04a                	sd	s2,32(sp)
    800055b0:	ec4e                	sd	s3,24(sp)
    800055b2:	e852                	sd	s4,16(sp)
    800055b4:	e456                	sd	s5,8(sp)
    800055b6:	e05a                	sd	s6,0(sp)
    800055b8:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800055ba:	10000937          	lui	s2,0x10000
    800055be:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800055c0:	0001ba97          	auipc	s5,0x1b
    800055c4:	638a8a93          	addi	s5,s5,1592 # 80020bf8 <uart_tx_lock>
    uart_tx_r += 1;
    800055c8:	00002497          	auipc	s1,0x2
    800055cc:	32848493          	addi	s1,s1,808 # 800078f0 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    800055d0:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    800055d4:	00002997          	auipc	s3,0x2
    800055d8:	32498993          	addi	s3,s3,804 # 800078f8 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800055dc:	00094703          	lbu	a4,0(s2)
    800055e0:	02077713          	andi	a4,a4,32
    800055e4:	c715                	beqz	a4,80005610 <uartstart+0x7e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800055e6:	01f7f713          	andi	a4,a5,31
    800055ea:	9756                	add	a4,a4,s5
    800055ec:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    800055f0:	0785                	addi	a5,a5,1
    800055f2:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    800055f4:	8526                	mv	a0,s1
    800055f6:	dabfb0ef          	jal	800013a0 <wakeup>
    WriteReg(THR, c);
    800055fa:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    800055fe:	609c                	ld	a5,0(s1)
    80005600:	0009b703          	ld	a4,0(s3)
    80005604:	fcf71ce3          	bne	a4,a5,800055dc <uartstart+0x4a>
      ReadReg(ISR);
    80005608:	100007b7          	lui	a5,0x10000
    8000560c:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005610:	70e2                	ld	ra,56(sp)
    80005612:	7442                	ld	s0,48(sp)
    80005614:	74a2                	ld	s1,40(sp)
    80005616:	7902                	ld	s2,32(sp)
    80005618:	69e2                	ld	s3,24(sp)
    8000561a:	6a42                	ld	s4,16(sp)
    8000561c:	6aa2                	ld	s5,8(sp)
    8000561e:	6b02                	ld	s6,0(sp)
    80005620:	6121                	addi	sp,sp,64
    80005622:	8082                	ret
      ReadReg(ISR);
    80005624:	100007b7          	lui	a5,0x10000
    80005628:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    8000562c:	8082                	ret

000000008000562e <uartputc>:
{
    8000562e:	7179                	addi	sp,sp,-48
    80005630:	f406                	sd	ra,40(sp)
    80005632:	f022                	sd	s0,32(sp)
    80005634:	ec26                	sd	s1,24(sp)
    80005636:	e84a                	sd	s2,16(sp)
    80005638:	e44e                	sd	s3,8(sp)
    8000563a:	e052                	sd	s4,0(sp)
    8000563c:	1800                	addi	s0,sp,48
    8000563e:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    80005640:	0001b517          	auipc	a0,0x1b
    80005644:	5b850513          	addi	a0,a0,1464 # 80020bf8 <uart_tx_lock>
    80005648:	184000ef          	jal	800057cc <acquire>
  if(panicked){
    8000564c:	00002797          	auipc	a5,0x2
    80005650:	2a07a783          	lw	a5,672(a5) # 800078ec <panicked>
    80005654:	e3d1                	bnez	a5,800056d8 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80005656:	00002717          	auipc	a4,0x2
    8000565a:	2a273703          	ld	a4,674(a4) # 800078f8 <uart_tx_w>
    8000565e:	00002797          	auipc	a5,0x2
    80005662:	2927b783          	ld	a5,658(a5) # 800078f0 <uart_tx_r>
    80005666:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    8000566a:	0001b997          	auipc	s3,0x1b
    8000566e:	58e98993          	addi	s3,s3,1422 # 80020bf8 <uart_tx_lock>
    80005672:	00002497          	auipc	s1,0x2
    80005676:	27e48493          	addi	s1,s1,638 # 800078f0 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000567a:	00002917          	auipc	s2,0x2
    8000567e:	27e90913          	addi	s2,s2,638 # 800078f8 <uart_tx_w>
    80005682:	00e79d63          	bne	a5,a4,8000569c <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    80005686:	85ce                	mv	a1,s3
    80005688:	8526                	mv	a0,s1
    8000568a:	ccbfb0ef          	jal	80001354 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000568e:	00093703          	ld	a4,0(s2)
    80005692:	609c                	ld	a5,0(s1)
    80005694:	02078793          	addi	a5,a5,32
    80005698:	fee787e3          	beq	a5,a4,80005686 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    8000569c:	01f77693          	andi	a3,a4,31
    800056a0:	0001b797          	auipc	a5,0x1b
    800056a4:	55878793          	addi	a5,a5,1368 # 80020bf8 <uart_tx_lock>
    800056a8:	97b6                	add	a5,a5,a3
    800056aa:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800056ae:	0705                	addi	a4,a4,1
    800056b0:	00002797          	auipc	a5,0x2
    800056b4:	24e7b423          	sd	a4,584(a5) # 800078f8 <uart_tx_w>
  uartstart();
    800056b8:	edbff0ef          	jal	80005592 <uartstart>
  release(&uart_tx_lock);
    800056bc:	0001b517          	auipc	a0,0x1b
    800056c0:	53c50513          	addi	a0,a0,1340 # 80020bf8 <uart_tx_lock>
    800056c4:	19c000ef          	jal	80005860 <release>
}
    800056c8:	70a2                	ld	ra,40(sp)
    800056ca:	7402                	ld	s0,32(sp)
    800056cc:	64e2                	ld	s1,24(sp)
    800056ce:	6942                	ld	s2,16(sp)
    800056d0:	69a2                	ld	s3,8(sp)
    800056d2:	6a02                	ld	s4,0(sp)
    800056d4:	6145                	addi	sp,sp,48
    800056d6:	8082                	ret
    for(;;)
    800056d8:	a001                	j	800056d8 <uartputc+0xaa>

00000000800056da <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800056da:	1141                	addi	sp,sp,-16
    800056dc:	e406                	sd	ra,8(sp)
    800056de:	e022                	sd	s0,0(sp)
    800056e0:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    800056e2:	100007b7          	lui	a5,0x10000
    800056e6:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800056ea:	8b85                	andi	a5,a5,1
    800056ec:	cb89                	beqz	a5,800056fe <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800056ee:	100007b7          	lui	a5,0x10000
    800056f2:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800056f6:	60a2                	ld	ra,8(sp)
    800056f8:	6402                	ld	s0,0(sp)
    800056fa:	0141                	addi	sp,sp,16
    800056fc:	8082                	ret
    return -1;
    800056fe:	557d                	li	a0,-1
    80005700:	bfdd                	j	800056f6 <uartgetc+0x1c>

0000000080005702 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80005702:	1101                	addi	sp,sp,-32
    80005704:	ec06                	sd	ra,24(sp)
    80005706:	e822                	sd	s0,16(sp)
    80005708:	e426                	sd	s1,8(sp)
    8000570a:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    8000570c:	54fd                	li	s1,-1
    int c = uartgetc();
    8000570e:	fcdff0ef          	jal	800056da <uartgetc>
    if(c == -1)
    80005712:	00950563          	beq	a0,s1,8000571c <uartintr+0x1a>
      break;
    consoleintr(c);
    80005716:	81bff0ef          	jal	80004f30 <consoleintr>
  while(1){
    8000571a:	bfd5                	j	8000570e <uartintr+0xc>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    8000571c:	0001b517          	auipc	a0,0x1b
    80005720:	4dc50513          	addi	a0,a0,1244 # 80020bf8 <uart_tx_lock>
    80005724:	0a8000ef          	jal	800057cc <acquire>
  uartstart();
    80005728:	e6bff0ef          	jal	80005592 <uartstart>
  release(&uart_tx_lock);
    8000572c:	0001b517          	auipc	a0,0x1b
    80005730:	4cc50513          	addi	a0,a0,1228 # 80020bf8 <uart_tx_lock>
    80005734:	12c000ef          	jal	80005860 <release>
}
    80005738:	60e2                	ld	ra,24(sp)
    8000573a:	6442                	ld	s0,16(sp)
    8000573c:	64a2                	ld	s1,8(sp)
    8000573e:	6105                	addi	sp,sp,32
    80005740:	8082                	ret

0000000080005742 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80005742:	1141                	addi	sp,sp,-16
    80005744:	e406                	sd	ra,8(sp)
    80005746:	e022                	sd	s0,0(sp)
    80005748:	0800                	addi	s0,sp,16
  lk->name = name;
    8000574a:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    8000574c:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80005750:	00053823          	sd	zero,16(a0)
}
    80005754:	60a2                	ld	ra,8(sp)
    80005756:	6402                	ld	s0,0(sp)
    80005758:	0141                	addi	sp,sp,16
    8000575a:	8082                	ret

000000008000575c <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    8000575c:	411c                	lw	a5,0(a0)
    8000575e:	e399                	bnez	a5,80005764 <holding+0x8>
    80005760:	4501                	li	a0,0
  return r;
}
    80005762:	8082                	ret
{
    80005764:	1101                	addi	sp,sp,-32
    80005766:	ec06                	sd	ra,24(sp)
    80005768:	e822                	sd	s0,16(sp)
    8000576a:	e426                	sd	s1,8(sp)
    8000576c:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    8000576e:	691c                	ld	a5,16(a0)
    80005770:	84be                	mv	s1,a5
    80005772:	df0fb0ef          	jal	80000d62 <mycpu>
    80005776:	40a48533          	sub	a0,s1,a0
    8000577a:	00153513          	seqz	a0,a0
}
    8000577e:	60e2                	ld	ra,24(sp)
    80005780:	6442                	ld	s0,16(sp)
    80005782:	64a2                	ld	s1,8(sp)
    80005784:	6105                	addi	sp,sp,32
    80005786:	8082                	ret

0000000080005788 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80005788:	1101                	addi	sp,sp,-32
    8000578a:	ec06                	sd	ra,24(sp)
    8000578c:	e822                	sd	s0,16(sp)
    8000578e:	e426                	sd	s1,8(sp)
    80005790:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005792:	100027f3          	csrr	a5,sstatus
    80005796:	84be                	mv	s1,a5
    80005798:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000579c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000579e:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    800057a2:	dc0fb0ef          	jal	80000d62 <mycpu>
    800057a6:	5d3c                	lw	a5,120(a0)
    800057a8:	cb99                	beqz	a5,800057be <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    800057aa:	db8fb0ef          	jal	80000d62 <mycpu>
    800057ae:	5d3c                	lw	a5,120(a0)
    800057b0:	2785                	addiw	a5,a5,1
    800057b2:	dd3c                	sw	a5,120(a0)
}
    800057b4:	60e2                	ld	ra,24(sp)
    800057b6:	6442                	ld	s0,16(sp)
    800057b8:	64a2                	ld	s1,8(sp)
    800057ba:	6105                	addi	sp,sp,32
    800057bc:	8082                	ret
    mycpu()->intena = old;
    800057be:	da4fb0ef          	jal	80000d62 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    800057c2:	0014d793          	srli	a5,s1,0x1
    800057c6:	8b85                	andi	a5,a5,1
    800057c8:	dd7c                	sw	a5,124(a0)
    800057ca:	b7c5                	j	800057aa <push_off+0x22>

00000000800057cc <acquire>:
{
    800057cc:	1101                	addi	sp,sp,-32
    800057ce:	ec06                	sd	ra,24(sp)
    800057d0:	e822                	sd	s0,16(sp)
    800057d2:	e426                	sd	s1,8(sp)
    800057d4:	1000                	addi	s0,sp,32
    800057d6:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    800057d8:	fb1ff0ef          	jal	80005788 <push_off>
  if(holding(lk))
    800057dc:	8526                	mv	a0,s1
    800057de:	f7fff0ef          	jal	8000575c <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    800057e2:	4705                	li	a4,1
  if(holding(lk))
    800057e4:	e105                	bnez	a0,80005804 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    800057e6:	87ba                	mv	a5,a4
    800057e8:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    800057ec:	2781                	sext.w	a5,a5
    800057ee:	ffe5                	bnez	a5,800057e6 <acquire+0x1a>
  __sync_synchronize();
    800057f0:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    800057f4:	d6efb0ef          	jal	80000d62 <mycpu>
    800057f8:	e888                	sd	a0,16(s1)
}
    800057fa:	60e2                	ld	ra,24(sp)
    800057fc:	6442                	ld	s0,16(sp)
    800057fe:	64a2                	ld	s1,8(sp)
    80005800:	6105                	addi	sp,sp,32
    80005802:	8082                	ret
    panic("acquire");
    80005804:	00002517          	auipc	a0,0x2
    80005808:	f3c50513          	addi	a0,a0,-196 # 80007740 <etext+0x740>
    8000580c:	c83ff0ef          	jal	8000548e <panic>

0000000080005810 <pop_off>:

void
pop_off(void)
{
    80005810:	1141                	addi	sp,sp,-16
    80005812:	e406                	sd	ra,8(sp)
    80005814:	e022                	sd	s0,0(sp)
    80005816:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005818:	d4afb0ef          	jal	80000d62 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000581c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80005820:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005822:	e39d                	bnez	a5,80005848 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005824:	5d3c                	lw	a5,120(a0)
    80005826:	02f05763          	blez	a5,80005854 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    8000582a:	37fd                	addiw	a5,a5,-1
    8000582c:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    8000582e:	eb89                	bnez	a5,80005840 <pop_off+0x30>
    80005830:	5d7c                	lw	a5,124(a0)
    80005832:	c799                	beqz	a5,80005840 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005834:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80005838:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000583c:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80005840:	60a2                	ld	ra,8(sp)
    80005842:	6402                	ld	s0,0(sp)
    80005844:	0141                	addi	sp,sp,16
    80005846:	8082                	ret
    panic("pop_off - interruptible");
    80005848:	00002517          	auipc	a0,0x2
    8000584c:	f0050513          	addi	a0,a0,-256 # 80007748 <etext+0x748>
    80005850:	c3fff0ef          	jal	8000548e <panic>
    panic("pop_off");
    80005854:	00002517          	auipc	a0,0x2
    80005858:	f0c50513          	addi	a0,a0,-244 # 80007760 <etext+0x760>
    8000585c:	c33ff0ef          	jal	8000548e <panic>

0000000080005860 <release>:
{
    80005860:	1101                	addi	sp,sp,-32
    80005862:	ec06                	sd	ra,24(sp)
    80005864:	e822                	sd	s0,16(sp)
    80005866:	e426                	sd	s1,8(sp)
    80005868:	1000                	addi	s0,sp,32
    8000586a:	84aa                	mv	s1,a0
  if(!holding(lk))
    8000586c:	ef1ff0ef          	jal	8000575c <holding>
    80005870:	c105                	beqz	a0,80005890 <release+0x30>
  lk->cpu = 0;
    80005872:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80005876:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    8000587a:	0310000f          	fence	rw,w
    8000587e:	0004a023          	sw	zero,0(s1)
  pop_off();
    80005882:	f8fff0ef          	jal	80005810 <pop_off>
}
    80005886:	60e2                	ld	ra,24(sp)
    80005888:	6442                	ld	s0,16(sp)
    8000588a:	64a2                	ld	s1,8(sp)
    8000588c:	6105                	addi	sp,sp,32
    8000588e:	8082                	ret
    panic("release");
    80005890:	00002517          	auipc	a0,0x2
    80005894:	ed850513          	addi	a0,a0,-296 # 80007768 <etext+0x768>
    80005898:	bf7ff0ef          	jal	8000548e <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
