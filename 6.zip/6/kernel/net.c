// kernel/net.c
// network support for xv6 (Ethernet, IP, UDP recv queue)

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "fs.h"
#include "sleeplock.h"
#include "file.h"
#include "net.h"

// xv6's ethernet and IP addresses
static uint8 local_mac[ETHADDR_LEN] = { 0x52, 0x54, 0x00, 0x12, 0x34, 0x56 };
static uint32 local_ip = MAKE_IP_ADDR(10, 0, 2, 15);

// qemu host's ethernet address.
static uint8 host_mac[ETHADDR_LEN] = { 0x52, 0x55, 0x0a, 0x00, 0x02, 0x02 };

static struct spinlock netlock;

void
netinit(void)
{
    initlock(&netlock, "netlock");
}

/*
 UDP receive queue / bind table
 For each bound destination port we keep a small queue (max 16 packets).
*/

#define MAX_UDP_PORTS 1024   // number of distinct ports we can track
#define MAX_PKTS_PER_PORT 16 // as the assignment requires

struct udp_pkt {
    char *data;    // kernel buffer allocated with kalloc(); holds payload bytes
    int len;       // payload length
    uint32 srcip;  // source IP in host byte order
    uint16 sport;  // source port in host byte order
};

struct udp_q {
    int port;                 // destination port (host byte order); -1 if unused
    struct udp_pkt pkts[MAX_PKTS_PER_PORT];
    int head;                 // index of earliest stored pkt
    int cnt;                  // number of packets queued
};

static struct udp_q udp_table[MAX_UDP_PORTS];
static int udp_table_inited = 0;

static void
udp_table_init(void)
{
    if (udp_table_inited)
        return;
    acquire(&netlock);
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
        udp_table[i].port = -1;
        udp_table[i].head = 0;
        udp_table[i].cnt = 0;
        for (int j = 0; j < MAX_PKTS_PER_PORT; j++) {
            udp_table[i].pkts[j].data = 0;
            udp_table[i].pkts[j].len = 0;
            udp_table[i].pkts[j].srcip = 0;
            udp_table[i].pkts[j].sport = 0;
        }
    }
    udp_table_inited = 1;
    release(&netlock);
}
static int
udp_find_port_idx(int port)
{
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
        if (udp_table[i].port == port)
            return i;
    }
    return -1;
}


static int
udp_alloc_port_idx(int port)
{
    int idx = udp_find_port_idx(port);
    if (idx >= 0) return idx;
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
        if (udp_table[i].port == -1) {
            udp_table[i].port = port;
            udp_table[i].head = 0;
            udp_table[i].cnt = 0;
            for (int j = 0; j < MAX_PKTS_PER_PORT; j++) {
                if (udp_table[i].pkts[j].data) {
                    kfree(udp_table[i].pkts[j].data);
                    udp_table[i].pkts[j].data = 0;
                }
                udp_table[i].pkts[j].len = 0;
                udp_table[i].pkts[j].srcip = 0;
                udp_table[i].pkts[j].sport = 0;
            }
            return i;
        }
    }
    return -1;
}

//
// bind(int port)
// prepare to receive UDP packets addressed to the port,
// i.e. allocate any queues &c needed.
//
uint64
sys_bind(void)
{
    int port;
    argint(0, &port);
    if (port < 0 || port > 0xffff)
        return -1;

    udp_table_init();

    acquire(&netlock);
    if (udp_find_port_idx(port) >= 0) {
        release(&netlock);
        return 0;
    }
    int idx = udp_alloc_port_idx(port);
    release(&netlock);
    if (idx < 0)
        return -1;
    return 0;
}

//
// unbind(int port)
// release any resources previously created by bind(port);
// from now on UDP packets addressed to port should be dropped.
//
uint64
sys_unbind(void)
{
    int port;
    argint(0, &port);
    if (port < 0 || port > 0xffff)
        return -1;

    udp_table_init();

    acquire(&netlock);
    int idx = udp_find_port_idx(port);
    if (idx >= 0) {
        struct udp_q *q = &udp_table[idx];
        for (int i = 0; i < MAX_PKTS_PER_PORT; i++) {
            if (q->pkts[i].data) {
                kfree(q->pkts[i].data);
                q->pkts[i].data = 0;
            }
            q->pkts[i].len = 0;
            q->pkts[i].srcip = 0;
            q->pkts[i].sport = 0;
        }
        q->head = 0;
        q->cnt = 0;
        q->port = -1;
    }
    release(&netlock);
    return 0;
}

//
// recv(int dport, int *src, short *sport, char *buf, int maxlen)
// if there's a received UDP packet already queued that was
// addressed to dport, then return it.
// otherwise wait for such a packet.
//
// sets *src to the IP source address.
// sets *sport to the UDP source port.
// copies up to maxlen bytes of UDP payload to buf.
// returns the number of bytes copied,
// and -1 if there was an error.
//
// dport, *src, and *sport are host byte order.
// bind(dport) must previously have been called.
//
uint64
sys_recv(void)
{
    int dport;
    uint64 src_addr;
    uint64 sport_addr;
    uint64 buf_addr;
    int maxlen;

    argint(0, &dport);
    argaddr(1, &src_addr);
    argaddr(2, &sport_addr);
    argaddr(3, &buf_addr);
    argint(4, &maxlen);

    if (dport < 0 || dport > 0xffff || maxlen < 0) return -1;

    struct proc *p = myproc();
    if (!p) return -1;

    udp_table_init();

    acquire(&netlock);
    int idx = udp_find_port_idx(dport);
    if (idx < 0) {
        release(&netlock);
        return -1;
    }
    struct udp_q *q = &udp_table[idx];

    while (q->cnt == 0) {
        sleep((void *)q, &netlock);
    }

    int i = q->head;
    struct udp_pkt pkt = q->pkts[i];

    q->pkts[i].data = 0;
    q->pkts[i].len = 0;
    q->pkts[i].srcip = 0;
    q->pkts[i].sport = 0;

    q->head = (q->head + 1) % MAX_PKTS_PER_PORT;
    q->cnt--;
    release(&netlock);

    if (!pkt.data)
        return -1;

    int tocopy = pkt.len;
    if (tocopy > maxlen) tocopy = maxlen;

    if (tocopy > 0) {
        if (copyout(p->pagetable, buf_addr, pkt.data, tocopy) < 0) {
            kfree(pkt.data);
            return -1;
        }
    }

    uint32 srcip = pkt.srcip;
    uint16 sport = pkt.sport;

    if (copyout(p->pagetable, src_addr, (char *)&srcip, sizeof(srcip)) < 0) {
        kfree(pkt.data);
        return -1;
    }
    if (copyout(p->pagetable, sport_addr, (char *)&sport, sizeof(sport)) < 0) {
        kfree(pkt.data);
        return -1;
    }

    kfree(pkt.data);
    return tocopy;
}

// This code is lifted from FreeBSD's ping.c, and is copyright by the Regents
// of the University of California.
static unsigned short
in_cksum(const unsigned char *addr, int len)
{
    int nleft = len;
    const unsigned short *w = (const unsigned short *)addr;
    unsigned int sum = 0;
    unsigned short answer = 0;

    /*
     * Our algorithm is simple, using a 32 bit accumulator (sum), we add
     * sequential 16 bit words to it, and at the end, fold back all the
     * carry bits from the top 16 bits into the lower 16 bits.
     */
    while (nleft > 1)  {
        sum += *w++;
        nleft -= 2;
    }

    /* mop up an odd byte, if necessary */
    if (nleft == 1) {
        *(unsigned char *)(&answer) = *(const unsigned char *)w;
        sum += answer;
    }

    /* add back carry outs from top 16 bits to low 16 bits */
    sum = (sum & 0xffff) + (sum >> 16);
    sum += (sum >> 16);
    /* guaranteed now that the lower 16 bits of sum are correct */

    answer = ~sum; /* truncate to 16 bits */
    return answer;
}

//
// send(int sport, int dst, int dport, char *buf, int len)
//
uint64
sys_send(void)
{
    struct proc *p = myproc();
    int sport;
    int dst;
    int dport;
    uint64 bufaddr;
    int len;

    argint(0, &sport);
    argint(1, &dst);
    argint(2, &dport);
    argaddr(3, &bufaddr);
    argint(4, &len);

    int total = len + sizeof(struct eth) + sizeof(struct ip) + sizeof(struct udp);
    if(total > PGSIZE)
        return -1;

    char *buf = kalloc();
    if(buf == 0){
        printf("sys_send: kalloc failed\n");
        return -1;
    }
    memset(buf, 0, PGSIZE);

    struct eth *eth = (struct eth *) buf;
    memmove(eth->dhost, host_mac, ETHADDR_LEN);
    memmove(eth->shost, local_mac, ETHADDR_LEN);
    eth->type = htons(ETHTYPE_IP);

    struct ip *ip = (struct ip *)(eth + 1);
    ip->ip_vhl = 0x45; // version 4, header length 4*5
    ip->ip_tos = 0;
    ip->ip_len = htons(sizeof(struct ip) + sizeof(struct udp) + len);
    ip->ip_id = 0;
    ip->ip_off = 0;
    ip->ip_ttl = 100;
    ip->ip_p = IPPROTO_UDP;
    ip->ip_src = htonl(local_ip);
    ip->ip_dst = htonl(dst);
    ip->ip_sum = in_cksum((unsigned char *)ip, sizeof(*ip));

    struct udp *udp = (struct udp *)(ip + 1);
    udp->sport = htons(sport);
    udp->dport = htons(dport);
    udp->ulen = htons(len + sizeof(struct udp));

    char *payload = (char *)(udp + 1);
    if(copyin(p->pagetable, payload, bufaddr, len) < 0){
        kfree(buf);
        printf("send: copyin failed\n");
        return -1;
    }

    e1000_transmit(buf, total);

    return 0;
}

void
ip_rx(char *buf, int len)
{
    // don't delete this printf; make grade depends on it.
    static int seen_ip = 0;
    if(seen_ip == 0)
        printf("ip_rx: received an IP packet\n");
    seen_ip = 1;

    //
    // parse ethernet + ip + udp, and if UDP and destination port bound,
    // queue UDP payload for recv() to pick up.
    //

    // minimal sanity checks
    if (len < sizeof(struct eth) + sizeof(struct ip) + sizeof(struct udp)) {
        kfree(buf);
        return;
    }

    struct eth *eth = (struct eth *) buf;
    if (ntohs(eth->type) != ETHTYPE_IP) {
        kfree(buf);
        return;
    }

    struct ip *ip = (struct ip *)(eth + 1);
    // only support IPv4 without options (ip header assumed 20 bytes as in lab)
    if (ip->ip_p != IPPROTO_UDP) {
        kfree(buf);
        return;
    }

    struct udp *udp = (struct udp *)(ip + 1);

    int dport = ntohs(udp->dport);
    int sport = ntohs(udp->sport);
    int ulen = ntohs(udp->ulen);

    if (ulen < (int)sizeof(struct udp)) {
        // malformed
        kfree(buf);
        return;
    }

    int payload_len = ulen - sizeof(struct udp);

    // Check that packet buffer actually contains payload_len bytes after headers.
    int after_hdrs = len - (sizeof(struct eth) + sizeof(struct ip) + sizeof(struct udp));
    if (after_hdrs < payload_len) {
        // truncated packet
        kfree(buf);
        return;
    }

    // where payload begins
    char *payload = (char *)(udp + 1);

    udp_table_init();
    acquire(&netlock);

    int idx = udp_find_port_idx(dport);
    if (idx < 0) {
        // no one bound to this port -> drop
        release(&netlock);
        kfree(buf);
        return;
    }

    struct udp_q *q = &udp_table[idx];
    if (q->cnt >= MAX_PKTS_PER_PORT) {
        // queue full -> drop packet
        release(&netlock);
        kfree(buf);
        return;
    }

    // allocate kernel buffer for payload
    char *kbuf = kalloc();
    if (!kbuf) {
        // allocation failed; drop packet
        release(&netlock);
        kfree(buf);
        return;
    }

    // copy only payload_len bytes
    memmove(kbuf, payload, payload_len);

    int tail = (q->head + q->cnt) % MAX_PKTS_PER_PORT;
    q->pkts[tail].data = kbuf;
    q->pkts[tail].len = payload_len;
    q->pkts[tail].srcip = ntohl(ip->ip_src); // store in host byte order
    q->pkts[tail].sport = sport;             // already host order
    q->cnt++;

    // wakeup any waiting receiver for this port; channel = q address
    wakeup((void *)q);

    release(&netlock);

    // free the original frame buffer
    kfree(buf);
}

//
// send an ARP reply packet to tell qemu to map
// xv6's ip address to its ethernet address.
// this is the bare minimum needed to persuade
// qemu to send IP packets to xv6; the real ARP
// protocol is more complex.
//
void
arp_rx(char *inbuf)
{
    static int seen_arp = 0;

    if(seen_arp){
        kfree(inbuf);
        return;
    }
    printf("arp_rx: received an ARP packet\n");
    seen_arp = 1;

    struct eth *ineth = (struct eth *) inbuf;
    struct arp *inarp = (struct arp *) (ineth + 1);

    char *buf = kalloc();
    if(buf == 0)
        panic("send_arp_reply");

    struct eth *eth = (struct eth *) buf;
    memmove(eth->dhost, ineth->shost, ETHADDR_LEN); // ethernet destination = query source
    memmove(eth->shost, local_mac, ETHADDR_LEN); // ethernet source = xv6's ethernet address
    eth->type = htons(ETHTYPE_ARP);

    struct arp *arp = (struct arp *)(eth + 1);
    arp->hrd = htons(ARP_HRD_ETHER);
    arp->pro = htons(ETHTYPE_IP);
    arp->hln = ETHADDR_LEN;
    arp->pln = sizeof(uint32);
    arp->op = htons(ARP_OP_REPLY);

    memmove(arp->sha, local_mac, ETHADDR_LEN);
    arp->sip = htonl(local_ip);
    memmove(arp->tha, ineth->shost, ETHADDR_LEN);
    arp->tip = inarp->sip;

    e1000_transmit(buf, sizeof(*eth) + sizeof(*arp));

    kfree(inbuf);
}

void
net_rx(char *buf, int len)
{
    struct eth *eth = (struct eth *) buf;

    if(len >= sizeof(struct eth) + sizeof(struct arp) &&
       ntohs(eth->type) == ETHTYPE_ARP){
        arp_rx(buf);
    } else if(len >= sizeof(struct eth) + sizeof(struct ip) &&
              ntohs(eth->type) == ETHTYPE_IP){
        ip_rx(buf, len);
    } else {
        kfree(buf);
    }
}
