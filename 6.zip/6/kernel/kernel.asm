
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	0007e117          	auipc	sp,0x7e
    80000004:	fc010113          	addi	sp,sp,-64 # 8007dfc0 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	34b050ef          	jal	80005b60 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	00086797          	auipc	a5,0x86
    8000002c:	09878793          	addi	a5,a5,152 # 800860c0 <end>
    80000030:	00f53733          	sltu	a4,a0,a5
    80000034:	47c5                	li	a5,17
    80000036:	07ee                	slli	a5,a5,0x1b
    80000038:	17fd                	addi	a5,a5,-1
    8000003a:	00a7b7b3          	sltu	a5,a5,a0
    8000003e:	8fd9                	or	a5,a5,a4
    80000040:	ef95                	bnez	a5,8000007c <kfree+0x60>
    80000042:	84aa                	mv	s1,a0
    80000044:	03451793          	slli	a5,a0,0x34
    80000048:	eb95                	bnez	a5,8000007c <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    8000004a:	6605                	lui	a2,0x1
    8000004c:	4585                	li	a1,1
    8000004e:	110000ef          	jal	8000015e <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000052:	00009917          	auipc	s2,0x9
    80000056:	9fe90913          	addi	s2,s2,-1538 # 80008a50 <kmem>
    8000005a:	854a                	mv	a0,s2
    8000005c:	5ba060ef          	jal	80006616 <acquire>
  r->next = kmem.freelist;
    80000060:	01893783          	ld	a5,24(s2)
    80000064:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000066:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    8000006a:	854a                	mv	a0,s2
    8000006c:	63e060ef          	jal	800066aa <release>
}
    80000070:	60e2                	ld	ra,24(sp)
    80000072:	6442                	ld	s0,16(sp)
    80000074:	64a2                	ld	s1,8(sp)
    80000076:	6902                	ld	s2,0(sp)
    80000078:	6105                	addi	sp,sp,32
    8000007a:	8082                	ret
    panic("kfree");
    8000007c:	00008517          	auipc	a0,0x8
    80000080:	f8450513          	addi	a0,a0,-124 # 80008000 <etext>
    80000084:	254060ef          	jal	800062d8 <panic>

0000000080000088 <freerange>:
{
    80000088:	7179                	addi	sp,sp,-48
    8000008a:	f406                	sd	ra,40(sp)
    8000008c:	f022                	sd	s0,32(sp)
    8000008e:	ec26                	sd	s1,24(sp)
    80000090:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000092:	6785                	lui	a5,0x1
    80000094:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000098:	00e504b3          	add	s1,a0,a4
    8000009c:	777d                	lui	a4,0xfffff
    8000009e:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000a0:	94be                	add	s1,s1,a5
    800000a2:	0295e263          	bltu	a1,s1,800000c6 <freerange+0x3e>
    800000a6:	e84a                	sd	s2,16(sp)
    800000a8:	e44e                	sd	s3,8(sp)
    800000aa:	e052                	sd	s4,0(sp)
    800000ac:	892e                	mv	s2,a1
    kfree(p);
    800000ae:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000b0:	89be                	mv	s3,a5
    kfree(p);
    800000b2:	01448533          	add	a0,s1,s4
    800000b6:	f67ff0ef          	jal	8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000ba:	94ce                	add	s1,s1,s3
    800000bc:	fe997be3          	bgeu	s2,s1,800000b2 <freerange+0x2a>
    800000c0:	6942                	ld	s2,16(sp)
    800000c2:	69a2                	ld	s3,8(sp)
    800000c4:	6a02                	ld	s4,0(sp)
}
    800000c6:	70a2                	ld	ra,40(sp)
    800000c8:	7402                	ld	s0,32(sp)
    800000ca:	64e2                	ld	s1,24(sp)
    800000cc:	6145                	addi	sp,sp,48
    800000ce:	8082                	ret

00000000800000d0 <kinit>:
{
    800000d0:	1141                	addi	sp,sp,-16
    800000d2:	e406                	sd	ra,8(sp)
    800000d4:	e022                	sd	s0,0(sp)
    800000d6:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d8:	00008597          	auipc	a1,0x8
    800000dc:	f3858593          	addi	a1,a1,-200 # 80008010 <etext+0x10>
    800000e0:	00009517          	auipc	a0,0x9
    800000e4:	97050513          	addi	a0,a0,-1680 # 80008a50 <kmem>
    800000e8:	4a4060ef          	jal	8000658c <initlock>
  freerange(end, (void*)PHYSTOP);
    800000ec:	45c5                	li	a1,17
    800000ee:	05ee                	slli	a1,a1,0x1b
    800000f0:	00086517          	auipc	a0,0x86
    800000f4:	fd050513          	addi	a0,a0,-48 # 800860c0 <end>
    800000f8:	f91ff0ef          	jal	80000088 <freerange>
}
    800000fc:	60a2                	ld	ra,8(sp)
    800000fe:	6402                	ld	s0,0(sp)
    80000100:	0141                	addi	sp,sp,16
    80000102:	8082                	ret

0000000080000104 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000104:	1101                	addi	sp,sp,-32
    80000106:	ec06                	sd	ra,24(sp)
    80000108:	e822                	sd	s0,16(sp)
    8000010a:	e426                	sd	s1,8(sp)
    8000010c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    8000010e:	00009517          	auipc	a0,0x9
    80000112:	94250513          	addi	a0,a0,-1726 # 80008a50 <kmem>
    80000116:	500060ef          	jal	80006616 <acquire>
  r = kmem.freelist;
    8000011a:	00009497          	auipc	s1,0x9
    8000011e:	94e4b483          	ld	s1,-1714(s1) # 80008a68 <kmem+0x18>
  if(r)
    80000122:	c49d                	beqz	s1,80000150 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000124:	609c                	ld	a5,0(s1)
    80000126:	00009717          	auipc	a4,0x9
    8000012a:	94f73123          	sd	a5,-1726(a4) # 80008a68 <kmem+0x18>
  release(&kmem.lock);
    8000012e:	00009517          	auipc	a0,0x9
    80000132:	92250513          	addi	a0,a0,-1758 # 80008a50 <kmem>
    80000136:	574060ef          	jal	800066aa <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    8000013a:	6605                	lui	a2,0x1
    8000013c:	4595                	li	a1,5
    8000013e:	8526                	mv	a0,s1
    80000140:	01e000ef          	jal	8000015e <memset>
  return (void*)r;
}
    80000144:	8526                	mv	a0,s1
    80000146:	60e2                	ld	ra,24(sp)
    80000148:	6442                	ld	s0,16(sp)
    8000014a:	64a2                	ld	s1,8(sp)
    8000014c:	6105                	addi	sp,sp,32
    8000014e:	8082                	ret
  release(&kmem.lock);
    80000150:	00009517          	auipc	a0,0x9
    80000154:	90050513          	addi	a0,a0,-1792 # 80008a50 <kmem>
    80000158:	552060ef          	jal	800066aa <release>
  if(r)
    8000015c:	b7e5                	j	80000144 <kalloc+0x40>

000000008000015e <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000015e:	1141                	addi	sp,sp,-16
    80000160:	e406                	sd	ra,8(sp)
    80000162:	e022                	sd	s0,0(sp)
    80000164:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000166:	ca19                	beqz	a2,8000017c <memset+0x1e>
    80000168:	87aa                	mv	a5,a0
    8000016a:	1602                	slli	a2,a2,0x20
    8000016c:	9201                	srli	a2,a2,0x20
    8000016e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000172:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000176:	0785                	addi	a5,a5,1
    80000178:	fee79de3          	bne	a5,a4,80000172 <memset+0x14>
  }
  return dst;
}
    8000017c:	60a2                	ld	ra,8(sp)
    8000017e:	6402                	ld	s0,0(sp)
    80000180:	0141                	addi	sp,sp,16
    80000182:	8082                	ret

0000000080000184 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000184:	1141                	addi	sp,sp,-16
    80000186:	e406                	sd	ra,8(sp)
    80000188:	e022                	sd	s0,0(sp)
    8000018a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    8000018c:	c61d                	beqz	a2,800001ba <memcmp+0x36>
    8000018e:	1602                	slli	a2,a2,0x20
    80000190:	9201                	srli	a2,a2,0x20
    80000192:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000196:	00054783          	lbu	a5,0(a0)
    8000019a:	0005c703          	lbu	a4,0(a1)
    8000019e:	00e79863          	bne	a5,a4,800001ae <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    800001a2:	0505                	addi	a0,a0,1
    800001a4:	0585                	addi	a1,a1,1
  while(n-- > 0){
    800001a6:	fed518e3          	bne	a0,a3,80000196 <memcmp+0x12>
  }

  return 0;
    800001aa:	4501                	li	a0,0
    800001ac:	a019                	j	800001b2 <memcmp+0x2e>
      return *s1 - *s2;
    800001ae:	40e7853b          	subw	a0,a5,a4
}
    800001b2:	60a2                	ld	ra,8(sp)
    800001b4:	6402                	ld	s0,0(sp)
    800001b6:	0141                	addi	sp,sp,16
    800001b8:	8082                	ret
  return 0;
    800001ba:	4501                	li	a0,0
    800001bc:	bfdd                	j	800001b2 <memcmp+0x2e>

00000000800001be <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001be:	1141                	addi	sp,sp,-16
    800001c0:	e406                	sd	ra,8(sp)
    800001c2:	e022                	sd	s0,0(sp)
    800001c4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001c6:	c205                	beqz	a2,800001e6 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001c8:	02a5e363          	bltu	a1,a0,800001ee <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001cc:	1602                	slli	a2,a2,0x20
    800001ce:	9201                	srli	a2,a2,0x20
    800001d0:	00c587b3          	add	a5,a1,a2
{
    800001d4:	872a                	mv	a4,a0
      *d++ = *s++;
    800001d6:	0585                	addi	a1,a1,1
    800001d8:	0705                	addi	a4,a4,1
    800001da:	fff5c683          	lbu	a3,-1(a1)
    800001de:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001e2:	feb79ae3          	bne	a5,a1,800001d6 <memmove+0x18>

  return dst;
}
    800001e6:	60a2                	ld	ra,8(sp)
    800001e8:	6402                	ld	s0,0(sp)
    800001ea:	0141                	addi	sp,sp,16
    800001ec:	8082                	ret
  if(s < d && s + n > d){
    800001ee:	02061693          	slli	a3,a2,0x20
    800001f2:	9281                	srli	a3,a3,0x20
    800001f4:	00d58733          	add	a4,a1,a3
    800001f8:	fce57ae3          	bgeu	a0,a4,800001cc <memmove+0xe>
    d += n;
    800001fc:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001fe:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000202:	1782                	slli	a5,a5,0x20
    80000204:	9381                	srli	a5,a5,0x20
    80000206:	fff7c793          	not	a5,a5
    8000020a:	97ba                	add	a5,a5,a4
      *--d = *--s;
    8000020c:	177d                	addi	a4,a4,-1
    8000020e:	16fd                	addi	a3,a3,-1
    80000210:	00074603          	lbu	a2,0(a4)
    80000214:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000218:	fee79ae3          	bne	a5,a4,8000020c <memmove+0x4e>
    8000021c:	b7e9                	j	800001e6 <memmove+0x28>

000000008000021e <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    8000021e:	1141                	addi	sp,sp,-16
    80000220:	e406                	sd	ra,8(sp)
    80000222:	e022                	sd	s0,0(sp)
    80000224:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000226:	f99ff0ef          	jal	800001be <memmove>
}
    8000022a:	60a2                	ld	ra,8(sp)
    8000022c:	6402                	ld	s0,0(sp)
    8000022e:	0141                	addi	sp,sp,16
    80000230:	8082                	ret

0000000080000232 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000232:	1141                	addi	sp,sp,-16
    80000234:	e406                	sd	ra,8(sp)
    80000236:	e022                	sd	s0,0(sp)
    80000238:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000023a:	ce11                	beqz	a2,80000256 <strncmp+0x24>
    8000023c:	00054783          	lbu	a5,0(a0)
    80000240:	cf89                	beqz	a5,8000025a <strncmp+0x28>
    80000242:	0005c703          	lbu	a4,0(a1)
    80000246:	00f71a63          	bne	a4,a5,8000025a <strncmp+0x28>
    n--, p++, q++;
    8000024a:	367d                	addiw	a2,a2,-1
    8000024c:	0505                	addi	a0,a0,1
    8000024e:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000250:	f675                	bnez	a2,8000023c <strncmp+0xa>
  if(n == 0)
    return 0;
    80000252:	4501                	li	a0,0
    80000254:	a801                	j	80000264 <strncmp+0x32>
    80000256:	4501                	li	a0,0
    80000258:	a031                	j	80000264 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    8000025a:	00054503          	lbu	a0,0(a0)
    8000025e:	0005c783          	lbu	a5,0(a1)
    80000262:	9d1d                	subw	a0,a0,a5
}
    80000264:	60a2                	ld	ra,8(sp)
    80000266:	6402                	ld	s0,0(sp)
    80000268:	0141                	addi	sp,sp,16
    8000026a:	8082                	ret

000000008000026c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    8000026c:	1141                	addi	sp,sp,-16
    8000026e:	e406                	sd	ra,8(sp)
    80000270:	e022                	sd	s0,0(sp)
    80000272:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000274:	87aa                	mv	a5,a0
    80000276:	a011                	j	8000027a <strncpy+0xe>
    80000278:	8636                	mv	a2,a3
    8000027a:	02c05863          	blez	a2,800002aa <strncpy+0x3e>
    8000027e:	fff6069b          	addiw	a3,a2,-1
    80000282:	8836                	mv	a6,a3
    80000284:	0785                	addi	a5,a5,1
    80000286:	0005c703          	lbu	a4,0(a1)
    8000028a:	fee78fa3          	sb	a4,-1(a5)
    8000028e:	0585                	addi	a1,a1,1
    80000290:	f765                	bnez	a4,80000278 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000292:	873e                	mv	a4,a5
    80000294:	01005b63          	blez	a6,800002aa <strncpy+0x3e>
    80000298:	9fb1                	addw	a5,a5,a2
    8000029a:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    8000029c:	0705                	addi	a4,a4,1
    8000029e:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    800002a2:	40e786bb          	subw	a3,a5,a4
    800002a6:	fed04be3          	bgtz	a3,8000029c <strncpy+0x30>
  return os;
}
    800002aa:	60a2                	ld	ra,8(sp)
    800002ac:	6402                	ld	s0,0(sp)
    800002ae:	0141                	addi	sp,sp,16
    800002b0:	8082                	ret

00000000800002b2 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    800002b2:	1141                	addi	sp,sp,-16
    800002b4:	e406                	sd	ra,8(sp)
    800002b6:	e022                	sd	s0,0(sp)
    800002b8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    800002ba:	02c05363          	blez	a2,800002e0 <safestrcpy+0x2e>
    800002be:	fff6069b          	addiw	a3,a2,-1
    800002c2:	1682                	slli	a3,a3,0x20
    800002c4:	9281                	srli	a3,a3,0x20
    800002c6:	96ae                	add	a3,a3,a1
    800002c8:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002ca:	00d58963          	beq	a1,a3,800002dc <safestrcpy+0x2a>
    800002ce:	0585                	addi	a1,a1,1
    800002d0:	0785                	addi	a5,a5,1
    800002d2:	fff5c703          	lbu	a4,-1(a1)
    800002d6:	fee78fa3          	sb	a4,-1(a5)
    800002da:	fb65                	bnez	a4,800002ca <safestrcpy+0x18>
    ;
  *s = 0;
    800002dc:	00078023          	sb	zero,0(a5)
  return os;
}
    800002e0:	60a2                	ld	ra,8(sp)
    800002e2:	6402                	ld	s0,0(sp)
    800002e4:	0141                	addi	sp,sp,16
    800002e6:	8082                	ret

00000000800002e8 <strlen>:

int
strlen(const char *s)
{
    800002e8:	1141                	addi	sp,sp,-16
    800002ea:	e406                	sd	ra,8(sp)
    800002ec:	e022                	sd	s0,0(sp)
    800002ee:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002f0:	00054783          	lbu	a5,0(a0)
    800002f4:	cf91                	beqz	a5,80000310 <strlen+0x28>
    800002f6:	00150793          	addi	a5,a0,1
    800002fa:	86be                	mv	a3,a5
    800002fc:	0785                	addi	a5,a5,1
    800002fe:	fff7c703          	lbu	a4,-1(a5)
    80000302:	ff65                	bnez	a4,800002fa <strlen+0x12>
    80000304:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000308:	60a2                	ld	ra,8(sp)
    8000030a:	6402                	ld	s0,0(sp)
    8000030c:	0141                	addi	sp,sp,16
    8000030e:	8082                	ret
  for(n = 0; s[n]; n++)
    80000310:	4501                	li	a0,0
    80000312:	bfdd                	j	80000308 <strlen+0x20>

0000000080000314 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000314:	1101                	addi	sp,sp,-32
    80000316:	ec06                	sd	ra,24(sp)
    80000318:	e822                	sd	s0,16(sp)
    8000031a:	e426                	sd	s1,8(sp)
    8000031c:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    8000031e:	269000ef          	jal	80000d86 <cpuid>
    kcsaninit();
#endif
    __sync_synchronize();
    started = 1;
  } else {
    while(atomic_read4((int *) &started) == 0)
    80000322:	00008497          	auipc	s1,0x8
    80000326:	6de48493          	addi	s1,s1,1758 # 80008a00 <started>
  if(cpuid() == 0){
    8000032a:	c905                	beqz	a0,8000035a <main+0x46>
    while(atomic_read4((int *) &started) == 0)
    8000032c:	8526                	mv	a0,s1
    8000032e:	3b8060ef          	jal	800066e6 <atomic_read4>
    80000332:	dd6d                	beqz	a0,8000032c <main+0x18>
      ;
    __sync_synchronize();
    80000334:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000338:	24f000ef          	jal	80000d86 <cpuid>
    8000033c:	85aa                	mv	a1,a0
    8000033e:	00008517          	auipc	a0,0x8
    80000342:	cfa50513          	addi	a0,a0,-774 # 80008038 <etext+0x38>
    80000346:	483050ef          	jal	80005fc8 <printf>
    kvminithart();    // turn on paging
    8000034a:	084000ef          	jal	800003ce <kvminithart>
    trapinithart();   // install kernel trap vector
    8000034e:	55e010ef          	jal	800018ac <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000352:	458040ef          	jal	800047aa <plicinithart>
  }

  scheduler();        
    80000356:	69b000ef          	jal	800011f0 <scheduler>
    consoleinit();
    8000035a:	395050ef          	jal	80005eee <consoleinit>
    printfinit();
    8000035e:	7b5050ef          	jal	80006312 <printfinit>
    printf("\n");
    80000362:	00008517          	auipc	a0,0x8
    80000366:	cb650513          	addi	a0,a0,-842 # 80008018 <etext+0x18>
    8000036a:	45f050ef          	jal	80005fc8 <printf>
    printf("xv6 kernel is booting\n");
    8000036e:	00008517          	auipc	a0,0x8
    80000372:	cb250513          	addi	a0,a0,-846 # 80008020 <etext+0x20>
    80000376:	453050ef          	jal	80005fc8 <printf>
    printf("\n");
    8000037a:	00008517          	auipc	a0,0x8
    8000037e:	c9e50513          	addi	a0,a0,-866 # 80008018 <etext+0x18>
    80000382:	447050ef          	jal	80005fc8 <printf>
    kinit();         // physical page allocator
    80000386:	d4bff0ef          	jal	800000d0 <kinit>
    kvminit();       // create kernel page table
    8000038a:	2f4000ef          	jal	8000067e <kvminit>
    kvminithart();   // turn on paging
    8000038e:	040000ef          	jal	800003ce <kvminithart>
    procinit();      // process table
    80000392:	141000ef          	jal	80000cd2 <procinit>
    trapinit();      // trap vectors
    80000396:	4f2010ef          	jal	80001888 <trapinit>
    trapinithart();  // install kernel trap vector
    8000039a:	512010ef          	jal	800018ac <trapinithart>
    plicinit();      // set up interrupt controller
    8000039e:	3e0040ef          	jal	8000477e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    800003a2:	408040ef          	jal	800047aa <plicinithart>
    binit();         // buffer cache
    800003a6:	351010ef          	jal	80001ef6 <binit>
    iinit();         // inode table
    800003aa:	10c020ef          	jal	800024b6 <iinit>
    fileinit();      // file table
    800003ae:	6f3020ef          	jal	800032a0 <fileinit>
    virtio_disk_init(); // emulated hard disk
    800003b2:	4ee040ef          	jal	800048a0 <virtio_disk_init>
    pci_init();
    800003b6:	6da050ef          	jal	80005a90 <pci_init>
    userinit();      // first user process
    800003ba:	46b000ef          	jal	80001024 <userinit>
    __sync_synchronize();
    800003be:	0330000f          	fence	rw,rw
    started = 1;
    800003c2:	4785                	li	a5,1
    800003c4:	00008717          	auipc	a4,0x8
    800003c8:	62f72e23          	sw	a5,1596(a4) # 80008a00 <started>
    800003cc:	b769                	j	80000356 <main+0x42>

00000000800003ce <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    800003ce:	1141                	addi	sp,sp,-16
    800003d0:	e406                	sd	ra,8(sp)
    800003d2:	e022                	sd	s0,0(sp)
    800003d4:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800003d6:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    800003da:	00008797          	auipc	a5,0x8
    800003de:	62e7b783          	ld	a5,1582(a5) # 80008a08 <kernel_pagetable>
    800003e2:	83b1                	srli	a5,a5,0xc
    800003e4:	577d                	li	a4,-1
    800003e6:	177e                	slli	a4,a4,0x3f
    800003e8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800003ea:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800003ee:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    800003f2:	60a2                	ld	ra,8(sp)
    800003f4:	6402                	ld	s0,0(sp)
    800003f6:	0141                	addi	sp,sp,16
    800003f8:	8082                	ret

00000000800003fa <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800003fa:	7139                	addi	sp,sp,-64
    800003fc:	fc06                	sd	ra,56(sp)
    800003fe:	f822                	sd	s0,48(sp)
    80000400:	f426                	sd	s1,40(sp)
    80000402:	f04a                	sd	s2,32(sp)
    80000404:	ec4e                	sd	s3,24(sp)
    80000406:	e852                	sd	s4,16(sp)
    80000408:	e456                	sd	s5,8(sp)
    8000040a:	e05a                	sd	s6,0(sp)
    8000040c:	0080                	addi	s0,sp,64
    8000040e:	84aa                	mv	s1,a0
    80000410:	89ae                	mv	s3,a1
    80000412:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80000414:	57fd                	li	a5,-1
    80000416:	83e9                	srli	a5,a5,0x1a
    80000418:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    8000041a:	4ab1                	li	s5,12
  if(va >= MAXVA)
    8000041c:	04b7e263          	bltu	a5,a1,80000460 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000420:	0149d933          	srl	s2,s3,s4
    80000424:	1ff97913          	andi	s2,s2,511
    80000428:	090e                	slli	s2,s2,0x3
    8000042a:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    8000042c:	00093483          	ld	s1,0(s2)
    80000430:	0014f793          	andi	a5,s1,1
    80000434:	cf85                	beqz	a5,8000046c <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000436:	80a9                	srli	s1,s1,0xa
    80000438:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    8000043a:	3a5d                	addiw	s4,s4,-9
    8000043c:	ff5a12e3          	bne	s4,s5,80000420 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000440:	00c9d513          	srli	a0,s3,0xc
    80000444:	1ff57513          	andi	a0,a0,511
    80000448:	050e                	slli	a0,a0,0x3
    8000044a:	9526                	add	a0,a0,s1
}
    8000044c:	70e2                	ld	ra,56(sp)
    8000044e:	7442                	ld	s0,48(sp)
    80000450:	74a2                	ld	s1,40(sp)
    80000452:	7902                	ld	s2,32(sp)
    80000454:	69e2                	ld	s3,24(sp)
    80000456:	6a42                	ld	s4,16(sp)
    80000458:	6aa2                	ld	s5,8(sp)
    8000045a:	6b02                	ld	s6,0(sp)
    8000045c:	6121                	addi	sp,sp,64
    8000045e:	8082                	ret
    panic("walk");
    80000460:	00008517          	auipc	a0,0x8
    80000464:	bf050513          	addi	a0,a0,-1040 # 80008050 <etext+0x50>
    80000468:	671050ef          	jal	800062d8 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    8000046c:	020b0263          	beqz	s6,80000490 <walk+0x96>
    80000470:	c95ff0ef          	jal	80000104 <kalloc>
    80000474:	84aa                	mv	s1,a0
    80000476:	d979                	beqz	a0,8000044c <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80000478:	6605                	lui	a2,0x1
    8000047a:	4581                	li	a1,0
    8000047c:	ce3ff0ef          	jal	8000015e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000480:	00c4d793          	srli	a5,s1,0xc
    80000484:	07aa                	slli	a5,a5,0xa
    80000486:	0017e793          	ori	a5,a5,1
    8000048a:	00f93023          	sd	a5,0(s2)
    8000048e:	b775                	j	8000043a <walk+0x40>
        return 0;
    80000490:	4501                	li	a0,0
    80000492:	bf6d                	j	8000044c <walk+0x52>

0000000080000494 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80000494:	57fd                	li	a5,-1
    80000496:	83e9                	srli	a5,a5,0x1a
    80000498:	00b7f463          	bgeu	a5,a1,800004a0 <walkaddr+0xc>
    return 0;
    8000049c:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    8000049e:	8082                	ret
{
    800004a0:	1141                	addi	sp,sp,-16
    800004a2:	e406                	sd	ra,8(sp)
    800004a4:	e022                	sd	s0,0(sp)
    800004a6:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    800004a8:	4601                	li	a2,0
    800004aa:	f51ff0ef          	jal	800003fa <walk>
  if(pte == 0)
    800004ae:	c901                	beqz	a0,800004be <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    800004b0:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    800004b2:	0117f693          	andi	a3,a5,17
    800004b6:	4745                	li	a4,17
    return 0;
    800004b8:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    800004ba:	00e68663          	beq	a3,a4,800004c6 <walkaddr+0x32>
}
    800004be:	60a2                	ld	ra,8(sp)
    800004c0:	6402                	ld	s0,0(sp)
    800004c2:	0141                	addi	sp,sp,16
    800004c4:	8082                	ret
  pa = PTE2PA(*pte);
    800004c6:	83a9                	srli	a5,a5,0xa
    800004c8:	00c79513          	slli	a0,a5,0xc
  return pa;
    800004cc:	bfcd                	j	800004be <walkaddr+0x2a>

00000000800004ce <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800004ce:	715d                	addi	sp,sp,-80
    800004d0:	e486                	sd	ra,72(sp)
    800004d2:	e0a2                	sd	s0,64(sp)
    800004d4:	fc26                	sd	s1,56(sp)
    800004d6:	f84a                	sd	s2,48(sp)
    800004d8:	f44e                	sd	s3,40(sp)
    800004da:	f052                	sd	s4,32(sp)
    800004dc:	ec56                	sd	s5,24(sp)
    800004de:	e85a                	sd	s6,16(sp)
    800004e0:	e45e                	sd	s7,8(sp)
    800004e2:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800004e4:	03459793          	slli	a5,a1,0x34
    800004e8:	eba1                	bnez	a5,80000538 <mappages+0x6a>
    800004ea:	8a2a                	mv	s4,a0
    800004ec:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800004ee:	03461793          	slli	a5,a2,0x34
    800004f2:	eba9                	bnez	a5,80000544 <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    800004f4:	ce31                	beqz	a2,80000550 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800004f6:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    800004fa:	80060613          	addi	a2,a2,-2048
    800004fe:	00b60933          	add	s2,a2,a1
  a = va;
    80000502:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    80000504:	4b05                	li	s6,1
    80000506:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    8000050a:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    8000050c:	865a                	mv	a2,s6
    8000050e:	85a6                	mv	a1,s1
    80000510:	8552                	mv	a0,s4
    80000512:	ee9ff0ef          	jal	800003fa <walk>
    80000516:	c929                	beqz	a0,80000568 <mappages+0x9a>
    if(*pte & PTE_V)
    80000518:	611c                	ld	a5,0(a0)
    8000051a:	8b85                	andi	a5,a5,1
    8000051c:	e3a1                	bnez	a5,8000055c <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000051e:	013487b3          	add	a5,s1,s3
    80000522:	83b1                	srli	a5,a5,0xc
    80000524:	07aa                	slli	a5,a5,0xa
    80000526:	0157e7b3          	or	a5,a5,s5
    8000052a:	0017e793          	ori	a5,a5,1
    8000052e:	e11c                	sd	a5,0(a0)
    if(a == last)
    80000530:	05248863          	beq	s1,s2,80000580 <mappages+0xb2>
    a += PGSIZE;
    80000534:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80000536:	bfd9                	j	8000050c <mappages+0x3e>
    panic("mappages: va not aligned");
    80000538:	00008517          	auipc	a0,0x8
    8000053c:	b2050513          	addi	a0,a0,-1248 # 80008058 <etext+0x58>
    80000540:	599050ef          	jal	800062d8 <panic>
    panic("mappages: size not aligned");
    80000544:	00008517          	auipc	a0,0x8
    80000548:	b3450513          	addi	a0,a0,-1228 # 80008078 <etext+0x78>
    8000054c:	58d050ef          	jal	800062d8 <panic>
    panic("mappages: size");
    80000550:	00008517          	auipc	a0,0x8
    80000554:	b4850513          	addi	a0,a0,-1208 # 80008098 <etext+0x98>
    80000558:	581050ef          	jal	800062d8 <panic>
      panic("mappages: remap");
    8000055c:	00008517          	auipc	a0,0x8
    80000560:	b4c50513          	addi	a0,a0,-1204 # 800080a8 <etext+0xa8>
    80000564:	575050ef          	jal	800062d8 <panic>
      return -1;
    80000568:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    8000056a:	60a6                	ld	ra,72(sp)
    8000056c:	6406                	ld	s0,64(sp)
    8000056e:	74e2                	ld	s1,56(sp)
    80000570:	7942                	ld	s2,48(sp)
    80000572:	79a2                	ld	s3,40(sp)
    80000574:	7a02                	ld	s4,32(sp)
    80000576:	6ae2                	ld	s5,24(sp)
    80000578:	6b42                	ld	s6,16(sp)
    8000057a:	6ba2                	ld	s7,8(sp)
    8000057c:	6161                	addi	sp,sp,80
    8000057e:	8082                	ret
  return 0;
    80000580:	4501                	li	a0,0
    80000582:	b7e5                	j	8000056a <mappages+0x9c>

0000000080000584 <kvmmap>:
{
    80000584:	1141                	addi	sp,sp,-16
    80000586:	e406                	sd	ra,8(sp)
    80000588:	e022                	sd	s0,0(sp)
    8000058a:	0800                	addi	s0,sp,16
    8000058c:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    8000058e:	86b2                	mv	a3,a2
    80000590:	863e                	mv	a2,a5
    80000592:	f3dff0ef          	jal	800004ce <mappages>
    80000596:	e509                	bnez	a0,800005a0 <kvmmap+0x1c>
}
    80000598:	60a2                	ld	ra,8(sp)
    8000059a:	6402                	ld	s0,0(sp)
    8000059c:	0141                	addi	sp,sp,16
    8000059e:	8082                	ret
    panic("kvmmap");
    800005a0:	00008517          	auipc	a0,0x8
    800005a4:	b1850513          	addi	a0,a0,-1256 # 800080b8 <etext+0xb8>
    800005a8:	531050ef          	jal	800062d8 <panic>

00000000800005ac <kvmmake>:
{
    800005ac:	1101                	addi	sp,sp,-32
    800005ae:	ec06                	sd	ra,24(sp)
    800005b0:	e822                	sd	s0,16(sp)
    800005b2:	e426                	sd	s1,8(sp)
    800005b4:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800005b6:	b4fff0ef          	jal	80000104 <kalloc>
    800005ba:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800005bc:	6605                	lui	a2,0x1
    800005be:	4581                	li	a1,0
    800005c0:	b9fff0ef          	jal	8000015e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800005c4:	4719                	li	a4,6
    800005c6:	6685                	lui	a3,0x1
    800005c8:	10000637          	lui	a2,0x10000
    800005cc:	85b2                	mv	a1,a2
    800005ce:	8526                	mv	a0,s1
    800005d0:	fb5ff0ef          	jal	80000584 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800005d4:	4719                	li	a4,6
    800005d6:	6685                	lui	a3,0x1
    800005d8:	10001637          	lui	a2,0x10001
    800005dc:	85b2                	mv	a1,a2
    800005de:	8526                	mv	a0,s1
    800005e0:	fa5ff0ef          	jal	80000584 <kvmmap>
  kvmmap(kpgtbl, 0x30000000L, 0x30000000L, 0x10000000, PTE_R | PTE_W);
    800005e4:	4719                	li	a4,6
    800005e6:	100006b7          	lui	a3,0x10000
    800005ea:	30000637          	lui	a2,0x30000
    800005ee:	85b2                	mv	a1,a2
    800005f0:	8526                	mv	a0,s1
    800005f2:	f93ff0ef          	jal	80000584 <kvmmap>
  kvmmap(kpgtbl, 0x40000000L, 0x40000000L, 0x20000, PTE_R | PTE_W);
    800005f6:	4719                	li	a4,6
    800005f8:	000206b7          	lui	a3,0x20
    800005fc:	40000637          	lui	a2,0x40000
    80000600:	85b2                	mv	a1,a2
    80000602:	8526                	mv	a0,s1
    80000604:	f81ff0ef          	jal	80000584 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80000608:	4719                	li	a4,6
    8000060a:	040006b7          	lui	a3,0x4000
    8000060e:	0c000637          	lui	a2,0xc000
    80000612:	85b2                	mv	a1,a2
    80000614:	8526                	mv	a0,s1
    80000616:	f6fff0ef          	jal	80000584 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    8000061a:	4729                	li	a4,10
    8000061c:	80008697          	auipc	a3,0x80008
    80000620:	9e468693          	addi	a3,a3,-1564 # 8000 <_entry-0x7fff8000>
    80000624:	4605                	li	a2,1
    80000626:	067e                	slli	a2,a2,0x1f
    80000628:	85b2                	mv	a1,a2
    8000062a:	8526                	mv	a0,s1
    8000062c:	f59ff0ef          	jal	80000584 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80000630:	4719                	li	a4,6
    80000632:	00008697          	auipc	a3,0x8
    80000636:	9ce68693          	addi	a3,a3,-1586 # 80008000 <etext>
    8000063a:	47c5                	li	a5,17
    8000063c:	07ee                	slli	a5,a5,0x1b
    8000063e:	40d786b3          	sub	a3,a5,a3
    80000642:	00008617          	auipc	a2,0x8
    80000646:	9be60613          	addi	a2,a2,-1602 # 80008000 <etext>
    8000064a:	85b2                	mv	a1,a2
    8000064c:	8526                	mv	a0,s1
    8000064e:	f37ff0ef          	jal	80000584 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80000652:	4729                	li	a4,10
    80000654:	6685                	lui	a3,0x1
    80000656:	00007617          	auipc	a2,0x7
    8000065a:	9aa60613          	addi	a2,a2,-1622 # 80007000 <_trampoline>
    8000065e:	040005b7          	lui	a1,0x4000
    80000662:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000664:	05b2                	slli	a1,a1,0xc
    80000666:	8526                	mv	a0,s1
    80000668:	f1dff0ef          	jal	80000584 <kvmmap>
  proc_mapstacks(kpgtbl);
    8000066c:	8526                	mv	a0,s1
    8000066e:	5c2000ef          	jal	80000c30 <proc_mapstacks>
}
    80000672:	8526                	mv	a0,s1
    80000674:	60e2                	ld	ra,24(sp)
    80000676:	6442                	ld	s0,16(sp)
    80000678:	64a2                	ld	s1,8(sp)
    8000067a:	6105                	addi	sp,sp,32
    8000067c:	8082                	ret

000000008000067e <kvminit>:
{
    8000067e:	1141                	addi	sp,sp,-16
    80000680:	e406                	sd	ra,8(sp)
    80000682:	e022                	sd	s0,0(sp)
    80000684:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80000686:	f27ff0ef          	jal	800005ac <kvmmake>
    8000068a:	00008797          	auipc	a5,0x8
    8000068e:	36a7bf23          	sd	a0,894(a5) # 80008a08 <kernel_pagetable>
}
    80000692:	60a2                	ld	ra,8(sp)
    80000694:	6402                	ld	s0,0(sp)
    80000696:	0141                	addi	sp,sp,16
    80000698:	8082                	ret

000000008000069a <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000069a:	715d                	addi	sp,sp,-80
    8000069c:	e486                	sd	ra,72(sp)
    8000069e:	e0a2                	sd	s0,64(sp)
    800006a0:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;
  int sz;

  if((va % PGSIZE) != 0)
    800006a2:	03459793          	slli	a5,a1,0x34
    800006a6:	e39d                	bnez	a5,800006cc <uvmunmap+0x32>
    800006a8:	f84a                	sd	s2,48(sp)
    800006aa:	f44e                	sd	s3,40(sp)
    800006ac:	f052                	sd	s4,32(sp)
    800006ae:	ec56                	sd	s5,24(sp)
    800006b0:	e85a                	sd	s6,16(sp)
    800006b2:	e45e                	sd	s7,8(sp)
    800006b4:	8a2a                	mv	s4,a0
    800006b6:	892e                	mv	s2,a1
    800006b8:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += sz){
    800006ba:	0632                	slli	a2,a2,0xc
    800006bc:	00b609b3          	add	s3,a2,a1
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0) {
      printf("va=%ld pte=%ld\n", a, *pte);
      panic("uvmunmap: not mapped");
    }
    if(PTE_FLAGS(*pte) == PTE_V)
    800006c0:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += sz){
    800006c2:	6b05                	lui	s6,0x1
    800006c4:	0935f763          	bgeu	a1,s3,80000752 <uvmunmap+0xb8>
    800006c8:	fc26                	sd	s1,56(sp)
    800006ca:	a8a1                	j	80000722 <uvmunmap+0x88>
    800006cc:	fc26                	sd	s1,56(sp)
    800006ce:	f84a                	sd	s2,48(sp)
    800006d0:	f44e                	sd	s3,40(sp)
    800006d2:	f052                	sd	s4,32(sp)
    800006d4:	ec56                	sd	s5,24(sp)
    800006d6:	e85a                	sd	s6,16(sp)
    800006d8:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    800006da:	00008517          	auipc	a0,0x8
    800006de:	9e650513          	addi	a0,a0,-1562 # 800080c0 <etext+0xc0>
    800006e2:	3f7050ef          	jal	800062d8 <panic>
      panic("uvmunmap: walk");
    800006e6:	00008517          	auipc	a0,0x8
    800006ea:	9f250513          	addi	a0,a0,-1550 # 800080d8 <etext+0xd8>
    800006ee:	3eb050ef          	jal	800062d8 <panic>
      printf("va=%ld pte=%ld\n", a, *pte);
    800006f2:	85ca                	mv	a1,s2
    800006f4:	00008517          	auipc	a0,0x8
    800006f8:	9f450513          	addi	a0,a0,-1548 # 800080e8 <etext+0xe8>
    800006fc:	0cd050ef          	jal	80005fc8 <printf>
      panic("uvmunmap: not mapped");
    80000700:	00008517          	auipc	a0,0x8
    80000704:	9f850513          	addi	a0,a0,-1544 # 800080f8 <etext+0xf8>
    80000708:	3d1050ef          	jal	800062d8 <panic>
      panic("uvmunmap: not a leaf");
    8000070c:	00008517          	auipc	a0,0x8
    80000710:	a0450513          	addi	a0,a0,-1532 # 80008110 <etext+0x110>
    80000714:	3c5050ef          	jal	800062d8 <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80000718:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += sz){
    8000071c:	995a                	add	s2,s2,s6
    8000071e:	03397963          	bgeu	s2,s3,80000750 <uvmunmap+0xb6>
    if((pte = walk(pagetable, a, 0)) == 0)
    80000722:	4601                	li	a2,0
    80000724:	85ca                	mv	a1,s2
    80000726:	8552                	mv	a0,s4
    80000728:	cd3ff0ef          	jal	800003fa <walk>
    8000072c:	84aa                	mv	s1,a0
    8000072e:	dd45                	beqz	a0,800006e6 <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0) {
    80000730:	6110                	ld	a2,0(a0)
    80000732:	00167793          	andi	a5,a2,1
    80000736:	dfd5                	beqz	a5,800006f2 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    80000738:	3ff67793          	andi	a5,a2,1023
    8000073c:	fd7788e3          	beq	a5,s7,8000070c <uvmunmap+0x72>
    if(do_free){
    80000740:	fc0a8ce3          	beqz	s5,80000718 <uvmunmap+0x7e>
      uint64 pa = PTE2PA(*pte);
    80000744:	8229                	srli	a2,a2,0xa
      kfree((void*)pa);
    80000746:	00c61513          	slli	a0,a2,0xc
    8000074a:	8d3ff0ef          	jal	8000001c <kfree>
    8000074e:	b7e9                	j	80000718 <uvmunmap+0x7e>
    80000750:	74e2                	ld	s1,56(sp)
    80000752:	7942                	ld	s2,48(sp)
    80000754:	79a2                	ld	s3,40(sp)
    80000756:	7a02                	ld	s4,32(sp)
    80000758:	6ae2                	ld	s5,24(sp)
    8000075a:	6b42                	ld	s6,16(sp)
    8000075c:	6ba2                	ld	s7,8(sp)
  }
}
    8000075e:	60a6                	ld	ra,72(sp)
    80000760:	6406                	ld	s0,64(sp)
    80000762:	6161                	addi	sp,sp,80
    80000764:	8082                	ret

0000000080000766 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80000766:	1101                	addi	sp,sp,-32
    80000768:	ec06                	sd	ra,24(sp)
    8000076a:	e822                	sd	s0,16(sp)
    8000076c:	e426                	sd	s1,8(sp)
    8000076e:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80000770:	995ff0ef          	jal	80000104 <kalloc>
    80000774:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000776:	c509                	beqz	a0,80000780 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80000778:	6605                	lui	a2,0x1
    8000077a:	4581                	li	a1,0
    8000077c:	9e3ff0ef          	jal	8000015e <memset>
  return pagetable;
}
    80000780:	8526                	mv	a0,s1
    80000782:	60e2                	ld	ra,24(sp)
    80000784:	6442                	ld	s0,16(sp)
    80000786:	64a2                	ld	s1,8(sp)
    80000788:	6105                	addi	sp,sp,32
    8000078a:	8082                	ret

000000008000078c <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    8000078c:	7179                	addi	sp,sp,-48
    8000078e:	f406                	sd	ra,40(sp)
    80000790:	f022                	sd	s0,32(sp)
    80000792:	ec26                	sd	s1,24(sp)
    80000794:	e84a                	sd	s2,16(sp)
    80000796:	e44e                	sd	s3,8(sp)
    80000798:	e052                	sd	s4,0(sp)
    8000079a:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    8000079c:	6785                	lui	a5,0x1
    8000079e:	04f67063          	bgeu	a2,a5,800007de <uvmfirst+0x52>
    800007a2:	89aa                	mv	s3,a0
    800007a4:	8a2e                	mv	s4,a1
    800007a6:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    800007a8:	95dff0ef          	jal	80000104 <kalloc>
    800007ac:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    800007ae:	6605                	lui	a2,0x1
    800007b0:	4581                	li	a1,0
    800007b2:	9adff0ef          	jal	8000015e <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    800007b6:	4779                	li	a4,30
    800007b8:	86ca                	mv	a3,s2
    800007ba:	6605                	lui	a2,0x1
    800007bc:	4581                	li	a1,0
    800007be:	854e                	mv	a0,s3
    800007c0:	d0fff0ef          	jal	800004ce <mappages>
  memmove(mem, src, sz);
    800007c4:	8626                	mv	a2,s1
    800007c6:	85d2                	mv	a1,s4
    800007c8:	854a                	mv	a0,s2
    800007ca:	9f5ff0ef          	jal	800001be <memmove>
}
    800007ce:	70a2                	ld	ra,40(sp)
    800007d0:	7402                	ld	s0,32(sp)
    800007d2:	64e2                	ld	s1,24(sp)
    800007d4:	6942                	ld	s2,16(sp)
    800007d6:	69a2                	ld	s3,8(sp)
    800007d8:	6a02                	ld	s4,0(sp)
    800007da:	6145                	addi	sp,sp,48
    800007dc:	8082                	ret
    panic("uvmfirst: more than a page");
    800007de:	00008517          	auipc	a0,0x8
    800007e2:	94a50513          	addi	a0,a0,-1718 # 80008128 <etext+0x128>
    800007e6:	2f3050ef          	jal	800062d8 <panic>

00000000800007ea <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800007ea:	1101                	addi	sp,sp,-32
    800007ec:	ec06                	sd	ra,24(sp)
    800007ee:	e822                	sd	s0,16(sp)
    800007f0:	e426                	sd	s1,8(sp)
    800007f2:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800007f4:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800007f6:	00b67d63          	bgeu	a2,a1,80000810 <uvmdealloc+0x26>
    800007fa:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800007fc:	6785                	lui	a5,0x1
    800007fe:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000800:	00f60733          	add	a4,a2,a5
    80000804:	76fd                	lui	a3,0xfffff
    80000806:	8f75                	and	a4,a4,a3
    80000808:	97ae                	add	a5,a5,a1
    8000080a:	8ff5                	and	a5,a5,a3
    8000080c:	00f76863          	bltu	a4,a5,8000081c <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80000810:	8526                	mv	a0,s1
    80000812:	60e2                	ld	ra,24(sp)
    80000814:	6442                	ld	s0,16(sp)
    80000816:	64a2                	ld	s1,8(sp)
    80000818:	6105                	addi	sp,sp,32
    8000081a:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000081c:	8f99                	sub	a5,a5,a4
    8000081e:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80000820:	4685                	li	a3,1
    80000822:	0007861b          	sext.w	a2,a5
    80000826:	85ba                	mv	a1,a4
    80000828:	e73ff0ef          	jal	8000069a <uvmunmap>
    8000082c:	b7d5                	j	80000810 <uvmdealloc+0x26>

000000008000082e <uvmalloc>:
  if(newsz < oldsz)
    8000082e:	0ab66163          	bltu	a2,a1,800008d0 <uvmalloc+0xa2>
{
    80000832:	715d                	addi	sp,sp,-80
    80000834:	e486                	sd	ra,72(sp)
    80000836:	e0a2                	sd	s0,64(sp)
    80000838:	f84a                	sd	s2,48(sp)
    8000083a:	f052                	sd	s4,32(sp)
    8000083c:	ec56                	sd	s5,24(sp)
    8000083e:	e45e                	sd	s7,8(sp)
    80000840:	0880                	addi	s0,sp,80
    80000842:	8aaa                	mv	s5,a0
    80000844:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80000846:	6785                	lui	a5,0x1
    80000848:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000084a:	95be                	add	a1,a1,a5
    8000084c:	77fd                	lui	a5,0xfffff
    8000084e:	00f5f933          	and	s2,a1,a5
    80000852:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += sz){
    80000854:	08c97063          	bgeu	s2,a2,800008d4 <uvmalloc+0xa6>
    80000858:	fc26                	sd	s1,56(sp)
    8000085a:	f44e                	sd	s3,40(sp)
    8000085c:	e85a                	sd	s6,16(sp)
    memset(mem, 0, sz);
    8000085e:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000860:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80000864:	8a1ff0ef          	jal	80000104 <kalloc>
    80000868:	84aa                	mv	s1,a0
    if(mem == 0){
    8000086a:	c50d                	beqz	a0,80000894 <uvmalloc+0x66>
    memset(mem, 0, sz);
    8000086c:	864e                	mv	a2,s3
    8000086e:	4581                	li	a1,0
    80000870:	8efff0ef          	jal	8000015e <memset>
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000874:	875a                	mv	a4,s6
    80000876:	86a6                	mv	a3,s1
    80000878:	864e                	mv	a2,s3
    8000087a:	85ca                	mv	a1,s2
    8000087c:	8556                	mv	a0,s5
    8000087e:	c51ff0ef          	jal	800004ce <mappages>
    80000882:	e915                	bnez	a0,800008b6 <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += sz){
    80000884:	994e                	add	s2,s2,s3
    80000886:	fd496fe3          	bltu	s2,s4,80000864 <uvmalloc+0x36>
  return newsz;
    8000088a:	8552                	mv	a0,s4
    8000088c:	74e2                	ld	s1,56(sp)
    8000088e:	79a2                	ld	s3,40(sp)
    80000890:	6b42                	ld	s6,16(sp)
    80000892:	a811                	j	800008a6 <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80000894:	865e                	mv	a2,s7
    80000896:	85ca                	mv	a1,s2
    80000898:	8556                	mv	a0,s5
    8000089a:	f51ff0ef          	jal	800007ea <uvmdealloc>
      return 0;
    8000089e:	4501                	li	a0,0
    800008a0:	74e2                	ld	s1,56(sp)
    800008a2:	79a2                	ld	s3,40(sp)
    800008a4:	6b42                	ld	s6,16(sp)
}
    800008a6:	60a6                	ld	ra,72(sp)
    800008a8:	6406                	ld	s0,64(sp)
    800008aa:	7942                	ld	s2,48(sp)
    800008ac:	7a02                	ld	s4,32(sp)
    800008ae:	6ae2                	ld	s5,24(sp)
    800008b0:	6ba2                	ld	s7,8(sp)
    800008b2:	6161                	addi	sp,sp,80
    800008b4:	8082                	ret
      kfree(mem);
    800008b6:	8526                	mv	a0,s1
    800008b8:	f64ff0ef          	jal	8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800008bc:	865e                	mv	a2,s7
    800008be:	85ca                	mv	a1,s2
    800008c0:	8556                	mv	a0,s5
    800008c2:	f29ff0ef          	jal	800007ea <uvmdealloc>
      return 0;
    800008c6:	4501                	li	a0,0
    800008c8:	74e2                	ld	s1,56(sp)
    800008ca:	79a2                	ld	s3,40(sp)
    800008cc:	6b42                	ld	s6,16(sp)
    800008ce:	bfe1                	j	800008a6 <uvmalloc+0x78>
    return oldsz;
    800008d0:	852e                	mv	a0,a1
}
    800008d2:	8082                	ret
  return newsz;
    800008d4:	8532                	mv	a0,a2
    800008d6:	bfc1                	j	800008a6 <uvmalloc+0x78>

00000000800008d8 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800008d8:	7179                	addi	sp,sp,-48
    800008da:	f406                	sd	ra,40(sp)
    800008dc:	f022                	sd	s0,32(sp)
    800008de:	ec26                	sd	s1,24(sp)
    800008e0:	e84a                	sd	s2,16(sp)
    800008e2:	e44e                	sd	s3,8(sp)
    800008e4:	1800                	addi	s0,sp,48
    800008e6:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800008e8:	84aa                	mv	s1,a0
    800008ea:	6905                	lui	s2,0x1
    800008ec:	992a                	add	s2,s2,a0
    800008ee:	a811                	j	80000902 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    800008f0:	00008517          	auipc	a0,0x8
    800008f4:	85850513          	addi	a0,a0,-1960 # 80008148 <etext+0x148>
    800008f8:	1e1050ef          	jal	800062d8 <panic>
  for(int i = 0; i < 512; i++){
    800008fc:	04a1                	addi	s1,s1,8
    800008fe:	03248163          	beq	s1,s2,80000920 <freewalk+0x48>
    pte_t pte = pagetable[i];
    80000902:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000904:	0017f713          	andi	a4,a5,1
    80000908:	db75                	beqz	a4,800008fc <freewalk+0x24>
    8000090a:	00e7f713          	andi	a4,a5,14
    8000090e:	f36d                	bnez	a4,800008f0 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80000910:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80000912:	00c79513          	slli	a0,a5,0xc
    80000916:	fc3ff0ef          	jal	800008d8 <freewalk>
      pagetable[i] = 0;
    8000091a:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000091e:	bff9                	j	800008fc <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    80000920:	854e                	mv	a0,s3
    80000922:	efaff0ef          	jal	8000001c <kfree>
}
    80000926:	70a2                	ld	ra,40(sp)
    80000928:	7402                	ld	s0,32(sp)
    8000092a:	64e2                	ld	s1,24(sp)
    8000092c:	6942                	ld	s2,16(sp)
    8000092e:	69a2                	ld	s3,8(sp)
    80000930:	6145                	addi	sp,sp,48
    80000932:	8082                	ret

0000000080000934 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80000934:	1101                	addi	sp,sp,-32
    80000936:	ec06                	sd	ra,24(sp)
    80000938:	e822                	sd	s0,16(sp)
    8000093a:	e426                	sd	s1,8(sp)
    8000093c:	1000                	addi	s0,sp,32
    8000093e:	84aa                	mv	s1,a0
  if(sz > 0)
    80000940:	e989                	bnez	a1,80000952 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80000942:	8526                	mv	a0,s1
    80000944:	f95ff0ef          	jal	800008d8 <freewalk>
}
    80000948:	60e2                	ld	ra,24(sp)
    8000094a:	6442                	ld	s0,16(sp)
    8000094c:	64a2                	ld	s1,8(sp)
    8000094e:	6105                	addi	sp,sp,32
    80000950:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80000952:	6785                	lui	a5,0x1
    80000954:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000956:	95be                	add	a1,a1,a5
    80000958:	4685                	li	a3,1
    8000095a:	00c5d613          	srli	a2,a1,0xc
    8000095e:	4581                	li	a1,0
    80000960:	d3bff0ef          	jal	8000069a <uvmunmap>
    80000964:	bff9                	j	80000942 <uvmfree+0xe>

0000000080000966 <uvmcopy>:
  uint64 pa, i;
  uint flags;
  char *mem;
  int szinc;

  for(i = 0; i < sz; i += szinc){
    80000966:	c64d                	beqz	a2,80000a10 <uvmcopy+0xaa>
{
    80000968:	715d                	addi	sp,sp,-80
    8000096a:	e486                	sd	ra,72(sp)
    8000096c:	e0a2                	sd	s0,64(sp)
    8000096e:	fc26                	sd	s1,56(sp)
    80000970:	f84a                	sd	s2,48(sp)
    80000972:	f44e                	sd	s3,40(sp)
    80000974:	f052                	sd	s4,32(sp)
    80000976:	ec56                	sd	s5,24(sp)
    80000978:	e85a                	sd	s6,16(sp)
    8000097a:	e45e                	sd	s7,8(sp)
    8000097c:	0880                	addi	s0,sp,80
    8000097e:	8b2a                	mv	s6,a0
    80000980:	8aae                	mv	s5,a1
    80000982:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += szinc){
    80000984:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80000986:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    80000988:	4601                	li	a2,0
    8000098a:	85ca                	mv	a1,s2
    8000098c:	855a                	mv	a0,s6
    8000098e:	a6dff0ef          	jal	800003fa <walk>
    80000992:	cd0d                	beqz	a0,800009cc <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    80000994:	00053b83          	ld	s7,0(a0)
    80000998:	001bf793          	andi	a5,s7,1
    8000099c:	cf95                	beqz	a5,800009d8 <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    8000099e:	f66ff0ef          	jal	80000104 <kalloc>
    800009a2:	84aa                	mv	s1,a0
    800009a4:	c139                	beqz	a0,800009ea <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    800009a6:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    800009aa:	864e                	mv	a2,s3
    800009ac:	05b2                	slli	a1,a1,0xc
    800009ae:	811ff0ef          	jal	800001be <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800009b2:	3ffbf713          	andi	a4,s7,1023
    800009b6:	86a6                	mv	a3,s1
    800009b8:	864e                	mv	a2,s3
    800009ba:	85ca                	mv	a1,s2
    800009bc:	8556                	mv	a0,s5
    800009be:	b11ff0ef          	jal	800004ce <mappages>
    800009c2:	e10d                	bnez	a0,800009e4 <uvmcopy+0x7e>
  for(i = 0; i < sz; i += szinc){
    800009c4:	994e                	add	s2,s2,s3
    800009c6:	fd4961e3          	bltu	s2,s4,80000988 <uvmcopy+0x22>
    800009ca:	a805                	j	800009fa <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    800009cc:	00007517          	auipc	a0,0x7
    800009d0:	78c50513          	addi	a0,a0,1932 # 80008158 <etext+0x158>
    800009d4:	105050ef          	jal	800062d8 <panic>
      panic("uvmcopy: page not present");
    800009d8:	00007517          	auipc	a0,0x7
    800009dc:	7a050513          	addi	a0,a0,1952 # 80008178 <etext+0x178>
    800009e0:	0f9050ef          	jal	800062d8 <panic>
      kfree(mem);
    800009e4:	8526                	mv	a0,s1
    800009e6:	e36ff0ef          	jal	8000001c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800009ea:	4685                	li	a3,1
    800009ec:	00c95613          	srli	a2,s2,0xc
    800009f0:	4581                	li	a1,0
    800009f2:	8556                	mv	a0,s5
    800009f4:	ca7ff0ef          	jal	8000069a <uvmunmap>
  return -1;
    800009f8:	557d                	li	a0,-1
}
    800009fa:	60a6                	ld	ra,72(sp)
    800009fc:	6406                	ld	s0,64(sp)
    800009fe:	74e2                	ld	s1,56(sp)
    80000a00:	7942                	ld	s2,48(sp)
    80000a02:	79a2                	ld	s3,40(sp)
    80000a04:	7a02                	ld	s4,32(sp)
    80000a06:	6ae2                	ld	s5,24(sp)
    80000a08:	6b42                	ld	s6,16(sp)
    80000a0a:	6ba2                	ld	s7,8(sp)
    80000a0c:	6161                	addi	sp,sp,80
    80000a0e:	8082                	ret
  return 0;
    80000a10:	4501                	li	a0,0
}
    80000a12:	8082                	ret

0000000080000a14 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80000a14:	1141                	addi	sp,sp,-16
    80000a16:	e406                	sd	ra,8(sp)
    80000a18:	e022                	sd	s0,0(sp)
    80000a1a:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80000a1c:	4601                	li	a2,0
    80000a1e:	9ddff0ef          	jal	800003fa <walk>
  if(pte == 0)
    80000a22:	c901                	beqz	a0,80000a32 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80000a24:	611c                	ld	a5,0(a0)
    80000a26:	9bbd                	andi	a5,a5,-17
    80000a28:	e11c                	sd	a5,0(a0)
}
    80000a2a:	60a2                	ld	ra,8(sp)
    80000a2c:	6402                	ld	s0,0(sp)
    80000a2e:	0141                	addi	sp,sp,16
    80000a30:	8082                	ret
    panic("uvmclear");
    80000a32:	00007517          	auipc	a0,0x7
    80000a36:	76650513          	addi	a0,a0,1894 # 80008198 <etext+0x198>
    80000a3a:	09f050ef          	jal	800062d8 <panic>

0000000080000a3e <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    80000a3e:	c2d1                	beqz	a3,80000ac2 <copyout+0x84>
{
    80000a40:	711d                	addi	sp,sp,-96
    80000a42:	ec86                	sd	ra,88(sp)
    80000a44:	e8a2                	sd	s0,80(sp)
    80000a46:	e4a6                	sd	s1,72(sp)
    80000a48:	e0ca                	sd	s2,64(sp)
    80000a4a:	fc4e                	sd	s3,56(sp)
    80000a4c:	f852                	sd	s4,48(sp)
    80000a4e:	f456                	sd	s5,40(sp)
    80000a50:	f05a                	sd	s6,32(sp)
    80000a52:	ec5e                	sd	s7,24(sp)
    80000a54:	e862                	sd	s8,16(sp)
    80000a56:	e466                	sd	s9,8(sp)
    80000a58:	1080                	addi	s0,sp,96
    80000a5a:	8b2a                	mv	s6,a0
    80000a5c:	89ae                	mv	s3,a1
    80000a5e:	8ab2                	mv	s5,a2
    80000a60:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80000a62:	7cfd                	lui	s9,0xfffff
    if (va0 >= MAXVA)
    80000a64:	5c7d                	li	s8,-1
    80000a66:	01ac5c13          	srli	s8,s8,0x1a
      return -1;
    
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    80000a6a:	6b85                	lui	s7,0x1
    80000a6c:	a005                	j	80000a8c <copyout+0x4e>
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000a6e:	412989b3          	sub	s3,s3,s2
    80000a72:	0004861b          	sext.w	a2,s1
    80000a76:	85d6                	mv	a1,s5
    80000a78:	954e                	add	a0,a0,s3
    80000a7a:	f44ff0ef          	jal	800001be <memmove>

    len -= n;
    80000a7e:	409a0a33          	sub	s4,s4,s1
    src += n;
    80000a82:	9aa6                	add	s5,s5,s1
    dstva = va0 + PGSIZE;
    80000a84:	017909b3          	add	s3,s2,s7
  while(len > 0){
    80000a88:	020a0b63          	beqz	s4,80000abe <copyout+0x80>
    va0 = PGROUNDDOWN(dstva);
    80000a8c:	0199f933          	and	s2,s3,s9
    if (va0 >= MAXVA)
    80000a90:	032c6b63          	bltu	s8,s2,80000ac6 <copyout+0x88>
    if((pte = walk(pagetable, va0, 0)) == 0) {
    80000a94:	4601                	li	a2,0
    80000a96:	85ca                	mv	a1,s2
    80000a98:	855a                	mv	a0,s6
    80000a9a:	961ff0ef          	jal	800003fa <walk>
    80000a9e:	c131                	beqz	a0,80000ae2 <copyout+0xa4>
    if((*pte & PTE_W) == 0)
    80000aa0:	611c                	ld	a5,0(a0)
    80000aa2:	8b91                	andi	a5,a5,4
    80000aa4:	c3a9                	beqz	a5,80000ae6 <copyout+0xa8>
    pa0 = walkaddr(pagetable, va0);
    80000aa6:	85ca                	mv	a1,s2
    80000aa8:	855a                	mv	a0,s6
    80000aaa:	9ebff0ef          	jal	80000494 <walkaddr>
    if(pa0 == 0)
    80000aae:	cd15                	beqz	a0,80000aea <copyout+0xac>
    n = PGSIZE - (dstva - va0);
    80000ab0:	413904b3          	sub	s1,s2,s3
    80000ab4:	94de                	add	s1,s1,s7
    if(n > len)
    80000ab6:	fa9a7ce3          	bgeu	s4,s1,80000a6e <copyout+0x30>
    80000aba:	84d2                	mv	s1,s4
    80000abc:	bf4d                	j	80000a6e <copyout+0x30>
  }
  return 0;
    80000abe:	4501                	li	a0,0
    80000ac0:	a021                	j	80000ac8 <copyout+0x8a>
    80000ac2:	4501                	li	a0,0
}
    80000ac4:	8082                	ret
      return -1;
    80000ac6:	557d                	li	a0,-1
}
    80000ac8:	60e6                	ld	ra,88(sp)
    80000aca:	6446                	ld	s0,80(sp)
    80000acc:	64a6                	ld	s1,72(sp)
    80000ace:	6906                	ld	s2,64(sp)
    80000ad0:	79e2                	ld	s3,56(sp)
    80000ad2:	7a42                	ld	s4,48(sp)
    80000ad4:	7aa2                	ld	s5,40(sp)
    80000ad6:	7b02                	ld	s6,32(sp)
    80000ad8:	6be2                	ld	s7,24(sp)
    80000ada:	6c42                	ld	s8,16(sp)
    80000adc:	6ca2                	ld	s9,8(sp)
    80000ade:	6125                	addi	sp,sp,96
    80000ae0:	8082                	ret
      return -1;
    80000ae2:	557d                	li	a0,-1
    80000ae4:	b7d5                	j	80000ac8 <copyout+0x8a>
      return -1;
    80000ae6:	557d                	li	a0,-1
    80000ae8:	b7c5                	j	80000ac8 <copyout+0x8a>
      return -1;
    80000aea:	557d                	li	a0,-1
    80000aec:	bff1                	j	80000ac8 <copyout+0x8a>

0000000080000aee <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;
  
  while(len > 0){
    80000aee:	c6a5                	beqz	a3,80000b56 <copyin+0x68>
{
    80000af0:	715d                	addi	sp,sp,-80
    80000af2:	e486                	sd	ra,72(sp)
    80000af4:	e0a2                	sd	s0,64(sp)
    80000af6:	fc26                	sd	s1,56(sp)
    80000af8:	f84a                	sd	s2,48(sp)
    80000afa:	f44e                	sd	s3,40(sp)
    80000afc:	f052                	sd	s4,32(sp)
    80000afe:	ec56                	sd	s5,24(sp)
    80000b00:	e85a                	sd	s6,16(sp)
    80000b02:	e45e                	sd	s7,8(sp)
    80000b04:	e062                	sd	s8,0(sp)
    80000b06:	0880                	addi	s0,sp,80
    80000b08:	8b2a                	mv	s6,a0
    80000b0a:	8a2e                	mv	s4,a1
    80000b0c:	8c32                	mv	s8,a2
    80000b0e:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000b10:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000b12:	6a85                	lui	s5,0x1
    80000b14:	a00d                	j	80000b36 <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000b16:	018505b3          	add	a1,a0,s8
    80000b1a:	0004861b          	sext.w	a2,s1
    80000b1e:	412585b3          	sub	a1,a1,s2
    80000b22:	8552                	mv	a0,s4
    80000b24:	e9aff0ef          	jal	800001be <memmove>

    len -= n;
    80000b28:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000b2c:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000b2e:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000b32:	02098063          	beqz	s3,80000b52 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000b36:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000b3a:	85ca                	mv	a1,s2
    80000b3c:	855a                	mv	a0,s6
    80000b3e:	957ff0ef          	jal	80000494 <walkaddr>
    if(pa0 == 0)
    80000b42:	cd01                	beqz	a0,80000b5a <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000b44:	418904b3          	sub	s1,s2,s8
    80000b48:	94d6                	add	s1,s1,s5
    if(n > len)
    80000b4a:	fc99f6e3          	bgeu	s3,s1,80000b16 <copyin+0x28>
    80000b4e:	84ce                	mv	s1,s3
    80000b50:	b7d9                	j	80000b16 <copyin+0x28>
  }
  return 0;
    80000b52:	4501                	li	a0,0
    80000b54:	a021                	j	80000b5c <copyin+0x6e>
    80000b56:	4501                	li	a0,0
}
    80000b58:	8082                	ret
      return -1;
    80000b5a:	557d                	li	a0,-1
}
    80000b5c:	60a6                	ld	ra,72(sp)
    80000b5e:	6406                	ld	s0,64(sp)
    80000b60:	74e2                	ld	s1,56(sp)
    80000b62:	7942                	ld	s2,48(sp)
    80000b64:	79a2                	ld	s3,40(sp)
    80000b66:	7a02                	ld	s4,32(sp)
    80000b68:	6ae2                	ld	s5,24(sp)
    80000b6a:	6b42                	ld	s6,16(sp)
    80000b6c:	6ba2                	ld	s7,8(sp)
    80000b6e:	6c02                	ld	s8,0(sp)
    80000b70:	6161                	addi	sp,sp,80
    80000b72:	8082                	ret

0000000080000b74 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000b74:	cac5                	beqz	a3,80000c24 <copyinstr+0xb0>
{
    80000b76:	715d                	addi	sp,sp,-80
    80000b78:	e486                	sd	ra,72(sp)
    80000b7a:	e0a2                	sd	s0,64(sp)
    80000b7c:	fc26                	sd	s1,56(sp)
    80000b7e:	f84a                	sd	s2,48(sp)
    80000b80:	f44e                	sd	s3,40(sp)
    80000b82:	f052                	sd	s4,32(sp)
    80000b84:	ec56                	sd	s5,24(sp)
    80000b86:	e85a                	sd	s6,16(sp)
    80000b88:	e45e                	sd	s7,8(sp)
    80000b8a:	0880                	addi	s0,sp,80
    80000b8c:	8aaa                	mv	s5,a0
    80000b8e:	84ae                	mv	s1,a1
    80000b90:	8bb2                	mv	s7,a2
    80000b92:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000b94:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000b96:	6a05                	lui	s4,0x1
    80000b98:	a82d                	j	80000bd2 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000b9a:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80000b9e:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000ba0:	0017c793          	xori	a5,a5,1
    80000ba4:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000ba8:	60a6                	ld	ra,72(sp)
    80000baa:	6406                	ld	s0,64(sp)
    80000bac:	74e2                	ld	s1,56(sp)
    80000bae:	7942                	ld	s2,48(sp)
    80000bb0:	79a2                	ld	s3,40(sp)
    80000bb2:	7a02                	ld	s4,32(sp)
    80000bb4:	6ae2                	ld	s5,24(sp)
    80000bb6:	6b42                	ld	s6,16(sp)
    80000bb8:	6ba2                	ld	s7,8(sp)
    80000bba:	6161                	addi	sp,sp,80
    80000bbc:	8082                	ret
    80000bbe:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80000bc2:	9726                	add	a4,a4,s1
      --max;
    80000bc4:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80000bc8:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80000bcc:	04e58463          	beq	a1,a4,80000c14 <copyinstr+0xa0>
{
    80000bd0:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80000bd2:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80000bd6:	85ca                	mv	a1,s2
    80000bd8:	8556                	mv	a0,s5
    80000bda:	8bbff0ef          	jal	80000494 <walkaddr>
    if(pa0 == 0)
    80000bde:	cd0d                	beqz	a0,80000c18 <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80000be0:	417906b3          	sub	a3,s2,s7
    80000be4:	96d2                	add	a3,a3,s4
    if(n > max)
    80000be6:	00d9f363          	bgeu	s3,a3,80000bec <copyinstr+0x78>
    80000bea:	86ce                	mv	a3,s3
    while(n > 0){
    80000bec:	ca85                	beqz	a3,80000c1c <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80000bee:	01750633          	add	a2,a0,s7
    80000bf2:	41260633          	sub	a2,a2,s2
    80000bf6:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80000bf8:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80000bfa:	96a6                	add	a3,a3,s1
    80000bfc:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000bfe:	00f60733          	add	a4,a2,a5
    80000c02:	00074703          	lbu	a4,0(a4)
    80000c06:	db51                	beqz	a4,80000b9a <copyinstr+0x26>
        *dst = *p;
    80000c08:	00e78023          	sb	a4,0(a5)
      dst++;
    80000c0c:	0785                	addi	a5,a5,1
    while(n > 0){
    80000c0e:	fed797e3          	bne	a5,a3,80000bfc <copyinstr+0x88>
    80000c12:	b775                	j	80000bbe <copyinstr+0x4a>
    80000c14:	4781                	li	a5,0
    80000c16:	b769                	j	80000ba0 <copyinstr+0x2c>
      return -1;
    80000c18:	557d                	li	a0,-1
    80000c1a:	b779                	j	80000ba8 <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80000c1c:	6b85                	lui	s7,0x1
    80000c1e:	9bca                	add	s7,s7,s2
    80000c20:	87a6                	mv	a5,s1
    80000c22:	b77d                	j	80000bd0 <copyinstr+0x5c>
  int got_null = 0;
    80000c24:	4781                	li	a5,0
  if(got_null){
    80000c26:	0017c793          	xori	a5,a5,1
    80000c2a:	40f0053b          	negw	a0,a5
}
    80000c2e:	8082                	ret

0000000080000c30 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000c30:	715d                	addi	sp,sp,-80
    80000c32:	e486                	sd	ra,72(sp)
    80000c34:	e0a2                	sd	s0,64(sp)
    80000c36:	fc26                	sd	s1,56(sp)
    80000c38:	f84a                	sd	s2,48(sp)
    80000c3a:	f44e                	sd	s3,40(sp)
    80000c3c:	f052                	sd	s4,32(sp)
    80000c3e:	ec56                	sd	s5,24(sp)
    80000c40:	e85a                	sd	s6,16(sp)
    80000c42:	e45e                	sd	s7,8(sp)
    80000c44:	e062                	sd	s8,0(sp)
    80000c46:	0880                	addi	s0,sp,80
    80000c48:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c4a:	00008497          	auipc	s1,0x8
    80000c4e:	25648493          	addi	s1,s1,598 # 80008ea0 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000c52:	8c26                	mv	s8,s1
    80000c54:	000a57b7          	lui	a5,0xa5
    80000c58:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80000c5c:	07b2                	slli	a5,a5,0xc
    80000c5e:	fa578793          	addi	a5,a5,-91
    80000c62:	4fa50937          	lui	s2,0x4fa50
    80000c66:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80000c6a:	1902                	slli	s2,s2,0x20
    80000c6c:	993e                	add	s2,s2,a5
    80000c6e:	010009b7          	lui	s3,0x1000
    80000c72:	19fd                	addi	s3,s3,-1 # ffffff <_entry-0x7f000001>
    80000c74:	09ba                	slli	s3,s3,0xe
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c76:	4b99                	li	s7,6
    80000c78:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c7a:	0000ea97          	auipc	s5,0xe
    80000c7e:	c26a8a93          	addi	s5,s5,-986 # 8000e8a0 <tickslock>
    char *pa = kalloc();
    80000c82:	c82ff0ef          	jal	80000104 <kalloc>
    80000c86:	862a                	mv	a2,a0
    if(pa == 0)
    80000c88:	cd1d                	beqz	a0,80000cc6 <proc_mapstacks+0x96>
    uint64 va = KSTACK((int) (p - proc));
    80000c8a:	418485b3          	sub	a1,s1,s8
    80000c8e:	858d                	srai	a1,a1,0x3
    80000c90:	032585b3          	mul	a1,a1,s2
    80000c94:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c98:	875e                	mv	a4,s7
    80000c9a:	86da                	mv	a3,s6
    80000c9c:	40b985b3          	sub	a1,s3,a1
    80000ca0:	8552                	mv	a0,s4
    80000ca2:	8e3ff0ef          	jal	80000584 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000ca6:	16848493          	addi	s1,s1,360
    80000caa:	fd549ce3          	bne	s1,s5,80000c82 <proc_mapstacks+0x52>
  }
}
    80000cae:	60a6                	ld	ra,72(sp)
    80000cb0:	6406                	ld	s0,64(sp)
    80000cb2:	74e2                	ld	s1,56(sp)
    80000cb4:	7942                	ld	s2,48(sp)
    80000cb6:	79a2                	ld	s3,40(sp)
    80000cb8:	7a02                	ld	s4,32(sp)
    80000cba:	6ae2                	ld	s5,24(sp)
    80000cbc:	6b42                	ld	s6,16(sp)
    80000cbe:	6ba2                	ld	s7,8(sp)
    80000cc0:	6c02                	ld	s8,0(sp)
    80000cc2:	6161                	addi	sp,sp,80
    80000cc4:	8082                	ret
      panic("kalloc");
    80000cc6:	00007517          	auipc	a0,0x7
    80000cca:	4e250513          	addi	a0,a0,1250 # 800081a8 <etext+0x1a8>
    80000cce:	60a050ef          	jal	800062d8 <panic>

0000000080000cd2 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000cd2:	7139                	addi	sp,sp,-64
    80000cd4:	fc06                	sd	ra,56(sp)
    80000cd6:	f822                	sd	s0,48(sp)
    80000cd8:	f426                	sd	s1,40(sp)
    80000cda:	f04a                	sd	s2,32(sp)
    80000cdc:	ec4e                	sd	s3,24(sp)
    80000cde:	e852                	sd	s4,16(sp)
    80000ce0:	e456                	sd	s5,8(sp)
    80000ce2:	e05a                	sd	s6,0(sp)
    80000ce4:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000ce6:	00007597          	auipc	a1,0x7
    80000cea:	4ca58593          	addi	a1,a1,1226 # 800081b0 <etext+0x1b0>
    80000cee:	00008517          	auipc	a0,0x8
    80000cf2:	d8250513          	addi	a0,a0,-638 # 80008a70 <pid_lock>
    80000cf6:	097050ef          	jal	8000658c <initlock>
  initlock(&wait_lock, "wait_lock");
    80000cfa:	00007597          	auipc	a1,0x7
    80000cfe:	4be58593          	addi	a1,a1,1214 # 800081b8 <etext+0x1b8>
    80000d02:	00008517          	auipc	a0,0x8
    80000d06:	d8650513          	addi	a0,a0,-634 # 80008a88 <wait_lock>
    80000d0a:	083050ef          	jal	8000658c <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d0e:	00008497          	auipc	s1,0x8
    80000d12:	19248493          	addi	s1,s1,402 # 80008ea0 <proc>
      initlock(&p->lock, "proc");
    80000d16:	00007a97          	auipc	s5,0x7
    80000d1a:	4b2a8a93          	addi	s5,s5,1202 # 800081c8 <etext+0x1c8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000d1e:	8a26                	mv	s4,s1
    80000d20:	000a57b7          	lui	a5,0xa5
    80000d24:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80000d28:	07b2                	slli	a5,a5,0xc
    80000d2a:	fa578793          	addi	a5,a5,-91
    80000d2e:	4fa50937          	lui	s2,0x4fa50
    80000d32:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80000d36:	1902                	slli	s2,s2,0x20
    80000d38:	993e                	add	s2,s2,a5
    80000d3a:	010009b7          	lui	s3,0x1000
    80000d3e:	19fd                	addi	s3,s3,-1 # ffffff <_entry-0x7f000001>
    80000d40:	09ba                	slli	s3,s3,0xe
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d42:	0000eb17          	auipc	s6,0xe
    80000d46:	b5eb0b13          	addi	s6,s6,-1186 # 8000e8a0 <tickslock>
      initlock(&p->lock, "proc");
    80000d4a:	85d6                	mv	a1,s5
    80000d4c:	8526                	mv	a0,s1
    80000d4e:	03f050ef          	jal	8000658c <initlock>
      p->state = UNUSED;
    80000d52:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000d56:	414487b3          	sub	a5,s1,s4
    80000d5a:	878d                	srai	a5,a5,0x3
    80000d5c:	032787b3          	mul	a5,a5,s2
    80000d60:	00d7979b          	slliw	a5,a5,0xd
    80000d64:	40f987b3          	sub	a5,s3,a5
    80000d68:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d6a:	16848493          	addi	s1,s1,360
    80000d6e:	fd649ee3          	bne	s1,s6,80000d4a <procinit+0x78>
  }
}
    80000d72:	70e2                	ld	ra,56(sp)
    80000d74:	7442                	ld	s0,48(sp)
    80000d76:	74a2                	ld	s1,40(sp)
    80000d78:	7902                	ld	s2,32(sp)
    80000d7a:	69e2                	ld	s3,24(sp)
    80000d7c:	6a42                	ld	s4,16(sp)
    80000d7e:	6aa2                	ld	s5,8(sp)
    80000d80:	6b02                	ld	s6,0(sp)
    80000d82:	6121                	addi	sp,sp,64
    80000d84:	8082                	ret

0000000080000d86 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000d86:	1141                	addi	sp,sp,-16
    80000d88:	e406                	sd	ra,8(sp)
    80000d8a:	e022                	sd	s0,0(sp)
    80000d8c:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000d8e:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000d90:	2501                	sext.w	a0,a0
    80000d92:	60a2                	ld	ra,8(sp)
    80000d94:	6402                	ld	s0,0(sp)
    80000d96:	0141                	addi	sp,sp,16
    80000d98:	8082                	ret

0000000080000d9a <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000d9a:	1141                	addi	sp,sp,-16
    80000d9c:	e406                	sd	ra,8(sp)
    80000d9e:	e022                	sd	s0,0(sp)
    80000da0:	0800                	addi	s0,sp,16
    80000da2:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000da4:	2781                	sext.w	a5,a5
    80000da6:	079e                	slli	a5,a5,0x7
  return c;
}
    80000da8:	00008517          	auipc	a0,0x8
    80000dac:	cf850513          	addi	a0,a0,-776 # 80008aa0 <cpus>
    80000db0:	953e                	add	a0,a0,a5
    80000db2:	60a2                	ld	ra,8(sp)
    80000db4:	6402                	ld	s0,0(sp)
    80000db6:	0141                	addi	sp,sp,16
    80000db8:	8082                	ret

0000000080000dba <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000dba:	1101                	addi	sp,sp,-32
    80000dbc:	ec06                	sd	ra,24(sp)
    80000dbe:	e822                	sd	s0,16(sp)
    80000dc0:	e426                	sd	s1,8(sp)
    80000dc2:	1000                	addi	s0,sp,32
  push_off();
    80000dc4:	00f050ef          	jal	800065d2 <push_off>
    80000dc8:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000dca:	2781                	sext.w	a5,a5
    80000dcc:	079e                	slli	a5,a5,0x7
    80000dce:	00008717          	auipc	a4,0x8
    80000dd2:	ca270713          	addi	a4,a4,-862 # 80008a70 <pid_lock>
    80000dd6:	97ba                	add	a5,a5,a4
    80000dd8:	7b9c                	ld	a5,48(a5)
    80000dda:	84be                	mv	s1,a5
  pop_off();
    80000ddc:	07f050ef          	jal	8000665a <pop_off>
  return p;
}
    80000de0:	8526                	mv	a0,s1
    80000de2:	60e2                	ld	ra,24(sp)
    80000de4:	6442                	ld	s0,16(sp)
    80000de6:	64a2                	ld	s1,8(sp)
    80000de8:	6105                	addi	sp,sp,32
    80000dea:	8082                	ret

0000000080000dec <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000dec:	1141                	addi	sp,sp,-16
    80000dee:	e406                	sd	ra,8(sp)
    80000df0:	e022                	sd	s0,0(sp)
    80000df2:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000df4:	fc7ff0ef          	jal	80000dba <myproc>
    80000df8:	0b3050ef          	jal	800066aa <release>

  if (first) {
    80000dfc:	00008797          	auipc	a5,0x8
    80000e00:	ba47a783          	lw	a5,-1116(a5) # 800089a0 <first.1>
    80000e04:	e799                	bnez	a5,80000e12 <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000e06:	2c3000ef          	jal	800018c8 <usertrapret>
}
    80000e0a:	60a2                	ld	ra,8(sp)
    80000e0c:	6402                	ld	s0,0(sp)
    80000e0e:	0141                	addi	sp,sp,16
    80000e10:	8082                	ret
    fsinit(ROOTDEV);
    80000e12:	4505                	li	a0,1
    80000e14:	638010ef          	jal	8000244c <fsinit>
    first = 0;
    80000e18:	00008797          	auipc	a5,0x8
    80000e1c:	b807a423          	sw	zero,-1144(a5) # 800089a0 <first.1>
    __sync_synchronize();
    80000e20:	0330000f          	fence	rw,rw
    80000e24:	b7cd                	j	80000e06 <forkret+0x1a>

0000000080000e26 <allocpid>:
{
    80000e26:	1101                	addi	sp,sp,-32
    80000e28:	ec06                	sd	ra,24(sp)
    80000e2a:	e822                	sd	s0,16(sp)
    80000e2c:	e426                	sd	s1,8(sp)
    80000e2e:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000e30:	00008517          	auipc	a0,0x8
    80000e34:	c4050513          	addi	a0,a0,-960 # 80008a70 <pid_lock>
    80000e38:	7de050ef          	jal	80006616 <acquire>
  pid = nextpid;
    80000e3c:	00008797          	auipc	a5,0x8
    80000e40:	b6878793          	addi	a5,a5,-1176 # 800089a4 <nextpid>
    80000e44:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000e46:	0014871b          	addiw	a4,s1,1
    80000e4a:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000e4c:	00008517          	auipc	a0,0x8
    80000e50:	c2450513          	addi	a0,a0,-988 # 80008a70 <pid_lock>
    80000e54:	057050ef          	jal	800066aa <release>
}
    80000e58:	8526                	mv	a0,s1
    80000e5a:	60e2                	ld	ra,24(sp)
    80000e5c:	6442                	ld	s0,16(sp)
    80000e5e:	64a2                	ld	s1,8(sp)
    80000e60:	6105                	addi	sp,sp,32
    80000e62:	8082                	ret

0000000080000e64 <proc_pagetable>:
{
    80000e64:	1101                	addi	sp,sp,-32
    80000e66:	ec06                	sd	ra,24(sp)
    80000e68:	e822                	sd	s0,16(sp)
    80000e6a:	e426                	sd	s1,8(sp)
    80000e6c:	e04a                	sd	s2,0(sp)
    80000e6e:	1000                	addi	s0,sp,32
    80000e70:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000e72:	8f5ff0ef          	jal	80000766 <uvmcreate>
    80000e76:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000e78:	cd05                	beqz	a0,80000eb0 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000e7a:	4729                	li	a4,10
    80000e7c:	00006697          	auipc	a3,0x6
    80000e80:	18468693          	addi	a3,a3,388 # 80007000 <_trampoline>
    80000e84:	6605                	lui	a2,0x1
    80000e86:	040005b7          	lui	a1,0x4000
    80000e8a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e8c:	05b2                	slli	a1,a1,0xc
    80000e8e:	e40ff0ef          	jal	800004ce <mappages>
    80000e92:	02054663          	bltz	a0,80000ebe <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000e96:	4719                	li	a4,6
    80000e98:	05893683          	ld	a3,88(s2)
    80000e9c:	6605                	lui	a2,0x1
    80000e9e:	020005b7          	lui	a1,0x2000
    80000ea2:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000ea4:	05b6                	slli	a1,a1,0xd
    80000ea6:	8526                	mv	a0,s1
    80000ea8:	e26ff0ef          	jal	800004ce <mappages>
    80000eac:	00054f63          	bltz	a0,80000eca <proc_pagetable+0x66>
}
    80000eb0:	8526                	mv	a0,s1
    80000eb2:	60e2                	ld	ra,24(sp)
    80000eb4:	6442                	ld	s0,16(sp)
    80000eb6:	64a2                	ld	s1,8(sp)
    80000eb8:	6902                	ld	s2,0(sp)
    80000eba:	6105                	addi	sp,sp,32
    80000ebc:	8082                	ret
    uvmfree(pagetable, 0);
    80000ebe:	4581                	li	a1,0
    80000ec0:	8526                	mv	a0,s1
    80000ec2:	a73ff0ef          	jal	80000934 <uvmfree>
    return 0;
    80000ec6:	4481                	li	s1,0
    80000ec8:	b7e5                	j	80000eb0 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000eca:	4681                	li	a3,0
    80000ecc:	4605                	li	a2,1
    80000ece:	040005b7          	lui	a1,0x4000
    80000ed2:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000ed4:	05b2                	slli	a1,a1,0xc
    80000ed6:	8526                	mv	a0,s1
    80000ed8:	fc2ff0ef          	jal	8000069a <uvmunmap>
    uvmfree(pagetable, 0);
    80000edc:	4581                	li	a1,0
    80000ede:	8526                	mv	a0,s1
    80000ee0:	a55ff0ef          	jal	80000934 <uvmfree>
    return 0;
    80000ee4:	4481                	li	s1,0
    80000ee6:	b7e9                	j	80000eb0 <proc_pagetable+0x4c>

0000000080000ee8 <proc_freepagetable>:
{
    80000ee8:	1101                	addi	sp,sp,-32
    80000eea:	ec06                	sd	ra,24(sp)
    80000eec:	e822                	sd	s0,16(sp)
    80000eee:	e426                	sd	s1,8(sp)
    80000ef0:	e04a                	sd	s2,0(sp)
    80000ef2:	1000                	addi	s0,sp,32
    80000ef4:	84aa                	mv	s1,a0
    80000ef6:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000ef8:	4681                	li	a3,0
    80000efa:	4605                	li	a2,1
    80000efc:	040005b7          	lui	a1,0x4000
    80000f00:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000f02:	05b2                	slli	a1,a1,0xc
    80000f04:	f96ff0ef          	jal	8000069a <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000f08:	4681                	li	a3,0
    80000f0a:	4605                	li	a2,1
    80000f0c:	020005b7          	lui	a1,0x2000
    80000f10:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000f12:	05b6                	slli	a1,a1,0xd
    80000f14:	8526                	mv	a0,s1
    80000f16:	f84ff0ef          	jal	8000069a <uvmunmap>
  uvmfree(pagetable, sz);
    80000f1a:	85ca                	mv	a1,s2
    80000f1c:	8526                	mv	a0,s1
    80000f1e:	a17ff0ef          	jal	80000934 <uvmfree>
}
    80000f22:	60e2                	ld	ra,24(sp)
    80000f24:	6442                	ld	s0,16(sp)
    80000f26:	64a2                	ld	s1,8(sp)
    80000f28:	6902                	ld	s2,0(sp)
    80000f2a:	6105                	addi	sp,sp,32
    80000f2c:	8082                	ret

0000000080000f2e <freeproc>:
{
    80000f2e:	1101                	addi	sp,sp,-32
    80000f30:	ec06                	sd	ra,24(sp)
    80000f32:	e822                	sd	s0,16(sp)
    80000f34:	e426                	sd	s1,8(sp)
    80000f36:	1000                	addi	s0,sp,32
    80000f38:	84aa                	mv	s1,a0
  if(p->trapframe)
    80000f3a:	6d28                	ld	a0,88(a0)
    80000f3c:	c119                	beqz	a0,80000f42 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80000f3e:	8deff0ef          	jal	8000001c <kfree>
  p->trapframe = 0;
    80000f42:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80000f46:	68a8                	ld	a0,80(s1)
    80000f48:	c501                	beqz	a0,80000f50 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80000f4a:	64ac                	ld	a1,72(s1)
    80000f4c:	f9dff0ef          	jal	80000ee8 <proc_freepagetable>
  p->pagetable = 0;
    80000f50:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80000f54:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80000f58:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80000f5c:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80000f60:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80000f64:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80000f68:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80000f6c:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80000f70:	0004ac23          	sw	zero,24(s1)
}
    80000f74:	60e2                	ld	ra,24(sp)
    80000f76:	6442                	ld	s0,16(sp)
    80000f78:	64a2                	ld	s1,8(sp)
    80000f7a:	6105                	addi	sp,sp,32
    80000f7c:	8082                	ret

0000000080000f7e <allocproc>:
{
    80000f7e:	1101                	addi	sp,sp,-32
    80000f80:	ec06                	sd	ra,24(sp)
    80000f82:	e822                	sd	s0,16(sp)
    80000f84:	e426                	sd	s1,8(sp)
    80000f86:	e04a                	sd	s2,0(sp)
    80000f88:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f8a:	00008497          	auipc	s1,0x8
    80000f8e:	f1648493          	addi	s1,s1,-234 # 80008ea0 <proc>
    80000f92:	0000e917          	auipc	s2,0xe
    80000f96:	90e90913          	addi	s2,s2,-1778 # 8000e8a0 <tickslock>
    acquire(&p->lock);
    80000f9a:	8526                	mv	a0,s1
    80000f9c:	67a050ef          	jal	80006616 <acquire>
    if(p->state == UNUSED) {
    80000fa0:	4c9c                	lw	a5,24(s1)
    80000fa2:	cb91                	beqz	a5,80000fb6 <allocproc+0x38>
      release(&p->lock);
    80000fa4:	8526                	mv	a0,s1
    80000fa6:	704050ef          	jal	800066aa <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000faa:	16848493          	addi	s1,s1,360
    80000fae:	ff2496e3          	bne	s1,s2,80000f9a <allocproc+0x1c>
  return 0;
    80000fb2:	4481                	li	s1,0
    80000fb4:	a089                	j	80000ff6 <allocproc+0x78>
  p->pid = allocpid();
    80000fb6:	e71ff0ef          	jal	80000e26 <allocpid>
    80000fba:	d888                	sw	a0,48(s1)
  p->state = USED;
    80000fbc:	4785                	li	a5,1
    80000fbe:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80000fc0:	944ff0ef          	jal	80000104 <kalloc>
    80000fc4:	892a                	mv	s2,a0
    80000fc6:	eca8                	sd	a0,88(s1)
    80000fc8:	cd15                	beqz	a0,80001004 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80000fca:	8526                	mv	a0,s1
    80000fcc:	e99ff0ef          	jal	80000e64 <proc_pagetable>
    80000fd0:	892a                	mv	s2,a0
    80000fd2:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80000fd4:	c121                	beqz	a0,80001014 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80000fd6:	07000613          	li	a2,112
    80000fda:	4581                	li	a1,0
    80000fdc:	06048513          	addi	a0,s1,96
    80000fe0:	97eff0ef          	jal	8000015e <memset>
  p->context.ra = (uint64)forkret;
    80000fe4:	00000797          	auipc	a5,0x0
    80000fe8:	e0878793          	addi	a5,a5,-504 # 80000dec <forkret>
    80000fec:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80000fee:	60bc                	ld	a5,64(s1)
    80000ff0:	6705                	lui	a4,0x1
    80000ff2:	97ba                	add	a5,a5,a4
    80000ff4:	f4bc                	sd	a5,104(s1)
}
    80000ff6:	8526                	mv	a0,s1
    80000ff8:	60e2                	ld	ra,24(sp)
    80000ffa:	6442                	ld	s0,16(sp)
    80000ffc:	64a2                	ld	s1,8(sp)
    80000ffe:	6902                	ld	s2,0(sp)
    80001000:	6105                	addi	sp,sp,32
    80001002:	8082                	ret
    freeproc(p);
    80001004:	8526                	mv	a0,s1
    80001006:	f29ff0ef          	jal	80000f2e <freeproc>
    release(&p->lock);
    8000100a:	8526                	mv	a0,s1
    8000100c:	69e050ef          	jal	800066aa <release>
    return 0;
    80001010:	84ca                	mv	s1,s2
    80001012:	b7d5                	j	80000ff6 <allocproc+0x78>
    freeproc(p);
    80001014:	8526                	mv	a0,s1
    80001016:	f19ff0ef          	jal	80000f2e <freeproc>
    release(&p->lock);
    8000101a:	8526                	mv	a0,s1
    8000101c:	68e050ef          	jal	800066aa <release>
    return 0;
    80001020:	84ca                	mv	s1,s2
    80001022:	bfd1                	j	80000ff6 <allocproc+0x78>

0000000080001024 <userinit>:
{
    80001024:	1101                	addi	sp,sp,-32
    80001026:	ec06                	sd	ra,24(sp)
    80001028:	e822                	sd	s0,16(sp)
    8000102a:	e426                	sd	s1,8(sp)
    8000102c:	1000                	addi	s0,sp,32
  p = allocproc();
    8000102e:	f51ff0ef          	jal	80000f7e <allocproc>
    80001032:	84aa                	mv	s1,a0
  initproc = p;
    80001034:	00008797          	auipc	a5,0x8
    80001038:	9ca7be23          	sd	a0,-1572(a5) # 80008a10 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    8000103c:	03400613          	li	a2,52
    80001040:	00008597          	auipc	a1,0x8
    80001044:	98058593          	addi	a1,a1,-1664 # 800089c0 <initcode>
    80001048:	6928                	ld	a0,80(a0)
    8000104a:	f42ff0ef          	jal	8000078c <uvmfirst>
  p->sz = PGSIZE;
    8000104e:	6785                	lui	a5,0x1
    80001050:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001052:	6cb8                	ld	a4,88(s1)
    80001054:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001058:	6cb8                	ld	a4,88(s1)
    8000105a:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    8000105c:	4641                	li	a2,16
    8000105e:	00007597          	auipc	a1,0x7
    80001062:	17258593          	addi	a1,a1,370 # 800081d0 <etext+0x1d0>
    80001066:	15848513          	addi	a0,s1,344
    8000106a:	a48ff0ef          	jal	800002b2 <safestrcpy>
  p->cwd = namei("/");
    8000106e:	00007517          	auipc	a0,0x7
    80001072:	17250513          	addi	a0,a0,370 # 800081e0 <etext+0x1e0>
    80001076:	4ff010ef          	jal	80002d74 <namei>
    8000107a:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    8000107e:	478d                	li	a5,3
    80001080:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001082:	8526                	mv	a0,s1
    80001084:	626050ef          	jal	800066aa <release>
}
    80001088:	60e2                	ld	ra,24(sp)
    8000108a:	6442                	ld	s0,16(sp)
    8000108c:	64a2                	ld	s1,8(sp)
    8000108e:	6105                	addi	sp,sp,32
    80001090:	8082                	ret

0000000080001092 <growproc>:
{
    80001092:	1101                	addi	sp,sp,-32
    80001094:	ec06                	sd	ra,24(sp)
    80001096:	e822                	sd	s0,16(sp)
    80001098:	e426                	sd	s1,8(sp)
    8000109a:	e04a                	sd	s2,0(sp)
    8000109c:	1000                	addi	s0,sp,32
    8000109e:	892a                	mv	s2,a0
  struct proc *p = myproc();
    800010a0:	d1bff0ef          	jal	80000dba <myproc>
    800010a4:	84aa                	mv	s1,a0
  sz = p->sz;
    800010a6:	652c                	ld	a1,72(a0)
  if(n > 0){
    800010a8:	01204c63          	bgtz	s2,800010c0 <growproc+0x2e>
  } else if(n < 0){
    800010ac:	02094463          	bltz	s2,800010d4 <growproc+0x42>
  p->sz = sz;
    800010b0:	e4ac                	sd	a1,72(s1)
  return 0;
    800010b2:	4501                	li	a0,0
}
    800010b4:	60e2                	ld	ra,24(sp)
    800010b6:	6442                	ld	s0,16(sp)
    800010b8:	64a2                	ld	s1,8(sp)
    800010ba:	6902                	ld	s2,0(sp)
    800010bc:	6105                	addi	sp,sp,32
    800010be:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    800010c0:	4691                	li	a3,4
    800010c2:	00b90633          	add	a2,s2,a1
    800010c6:	6928                	ld	a0,80(a0)
    800010c8:	f66ff0ef          	jal	8000082e <uvmalloc>
    800010cc:	85aa                	mv	a1,a0
    800010ce:	f16d                	bnez	a0,800010b0 <growproc+0x1e>
      return -1;
    800010d0:	557d                	li	a0,-1
    800010d2:	b7cd                	j	800010b4 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    800010d4:	00b90633          	add	a2,s2,a1
    800010d8:	6928                	ld	a0,80(a0)
    800010da:	f10ff0ef          	jal	800007ea <uvmdealloc>
    800010de:	85aa                	mv	a1,a0
    800010e0:	bfc1                	j	800010b0 <growproc+0x1e>

00000000800010e2 <fork>:
{
    800010e2:	7139                	addi	sp,sp,-64
    800010e4:	fc06                	sd	ra,56(sp)
    800010e6:	f822                	sd	s0,48(sp)
    800010e8:	f426                	sd	s1,40(sp)
    800010ea:	e456                	sd	s5,8(sp)
    800010ec:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    800010ee:	ccdff0ef          	jal	80000dba <myproc>
    800010f2:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    800010f4:	e8bff0ef          	jal	80000f7e <allocproc>
    800010f8:	0e050a63          	beqz	a0,800011ec <fork+0x10a>
    800010fc:	e852                	sd	s4,16(sp)
    800010fe:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001100:	048ab603          	ld	a2,72(s5)
    80001104:	692c                	ld	a1,80(a0)
    80001106:	050ab503          	ld	a0,80(s5)
    8000110a:	85dff0ef          	jal	80000966 <uvmcopy>
    8000110e:	04054863          	bltz	a0,8000115e <fork+0x7c>
    80001112:	f04a                	sd	s2,32(sp)
    80001114:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001116:	048ab783          	ld	a5,72(s5)
    8000111a:	04fa3423          	sd	a5,72(s4) # 1048 <_entry-0x7fffefb8>
  *(np->trapframe) = *(p->trapframe);
    8000111e:	058ab683          	ld	a3,88(s5)
    80001122:	87b6                	mv	a5,a3
    80001124:	058a3703          	ld	a4,88(s4)
    80001128:	12068693          	addi	a3,a3,288
    8000112c:	6388                	ld	a0,0(a5)
    8000112e:	678c                	ld	a1,8(a5)
    80001130:	6b90                	ld	a2,16(a5)
    80001132:	e308                	sd	a0,0(a4)
    80001134:	e70c                	sd	a1,8(a4)
    80001136:	eb10                	sd	a2,16(a4)
    80001138:	6f90                	ld	a2,24(a5)
    8000113a:	ef10                	sd	a2,24(a4)
    8000113c:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    80001140:	02070713          	addi	a4,a4,32
    80001144:	fed794e3          	bne	a5,a3,8000112c <fork+0x4a>
  np->trapframe->a0 = 0;
    80001148:	058a3783          	ld	a5,88(s4)
    8000114c:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001150:	0d0a8493          	addi	s1,s5,208
    80001154:	0d0a0913          	addi	s2,s4,208
    80001158:	150a8993          	addi	s3,s5,336
    8000115c:	a831                	j	80001178 <fork+0x96>
    freeproc(np);
    8000115e:	8552                	mv	a0,s4
    80001160:	dcfff0ef          	jal	80000f2e <freeproc>
    release(&np->lock);
    80001164:	8552                	mv	a0,s4
    80001166:	544050ef          	jal	800066aa <release>
    return -1;
    8000116a:	54fd                	li	s1,-1
    8000116c:	6a42                	ld	s4,16(sp)
    8000116e:	a885                	j	800011de <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001170:	04a1                	addi	s1,s1,8
    80001172:	0921                	addi	s2,s2,8
    80001174:	01348963          	beq	s1,s3,80001186 <fork+0xa4>
    if(p->ofile[i])
    80001178:	6088                	ld	a0,0(s1)
    8000117a:	d97d                	beqz	a0,80001170 <fork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    8000117c:	1a6020ef          	jal	80003322 <filedup>
    80001180:	00a93023          	sd	a0,0(s2)
    80001184:	b7f5                	j	80001170 <fork+0x8e>
  np->cwd = idup(p->cwd);
    80001186:	150ab503          	ld	a0,336(s5)
    8000118a:	4be010ef          	jal	80002648 <idup>
    8000118e:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001192:	4641                	li	a2,16
    80001194:	158a8593          	addi	a1,s5,344
    80001198:	158a0513          	addi	a0,s4,344
    8000119c:	916ff0ef          	jal	800002b2 <safestrcpy>
  pid = np->pid;
    800011a0:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    800011a4:	8552                	mv	a0,s4
    800011a6:	504050ef          	jal	800066aa <release>
  acquire(&wait_lock);
    800011aa:	00008517          	auipc	a0,0x8
    800011ae:	8de50513          	addi	a0,a0,-1826 # 80008a88 <wait_lock>
    800011b2:	464050ef          	jal	80006616 <acquire>
  np->parent = p;
    800011b6:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    800011ba:	00008517          	auipc	a0,0x8
    800011be:	8ce50513          	addi	a0,a0,-1842 # 80008a88 <wait_lock>
    800011c2:	4e8050ef          	jal	800066aa <release>
  acquire(&np->lock);
    800011c6:	8552                	mv	a0,s4
    800011c8:	44e050ef          	jal	80006616 <acquire>
  np->state = RUNNABLE;
    800011cc:	478d                	li	a5,3
    800011ce:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    800011d2:	8552                	mv	a0,s4
    800011d4:	4d6050ef          	jal	800066aa <release>
  return pid;
    800011d8:	7902                	ld	s2,32(sp)
    800011da:	69e2                	ld	s3,24(sp)
    800011dc:	6a42                	ld	s4,16(sp)
}
    800011de:	8526                	mv	a0,s1
    800011e0:	70e2                	ld	ra,56(sp)
    800011e2:	7442                	ld	s0,48(sp)
    800011e4:	74a2                	ld	s1,40(sp)
    800011e6:	6aa2                	ld	s5,8(sp)
    800011e8:	6121                	addi	sp,sp,64
    800011ea:	8082                	ret
    return -1;
    800011ec:	54fd                	li	s1,-1
    800011ee:	bfc5                	j	800011de <fork+0xfc>

00000000800011f0 <scheduler>:
{
    800011f0:	715d                	addi	sp,sp,-80
    800011f2:	e486                	sd	ra,72(sp)
    800011f4:	e0a2                	sd	s0,64(sp)
    800011f6:	fc26                	sd	s1,56(sp)
    800011f8:	f84a                	sd	s2,48(sp)
    800011fa:	f44e                	sd	s3,40(sp)
    800011fc:	f052                	sd	s4,32(sp)
    800011fe:	ec56                	sd	s5,24(sp)
    80001200:	e85a                	sd	s6,16(sp)
    80001202:	e45e                	sd	s7,8(sp)
    80001204:	e062                	sd	s8,0(sp)
    80001206:	0880                	addi	s0,sp,80
    80001208:	8792                	mv	a5,tp
  int id = r_tp();
    8000120a:	2781                	sext.w	a5,a5
  c->proc = 0;
    8000120c:	00779b13          	slli	s6,a5,0x7
    80001210:	00008717          	auipc	a4,0x8
    80001214:	86070713          	addi	a4,a4,-1952 # 80008a70 <pid_lock>
    80001218:	975a                	add	a4,a4,s6
    8000121a:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    8000121e:	00008717          	auipc	a4,0x8
    80001222:	88a70713          	addi	a4,a4,-1910 # 80008aa8 <cpus+0x8>
    80001226:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001228:	4c11                	li	s8,4
        c->proc = p;
    8000122a:	079e                	slli	a5,a5,0x7
    8000122c:	00008a17          	auipc	s4,0x8
    80001230:	844a0a13          	addi	s4,s4,-1980 # 80008a70 <pid_lock>
    80001234:	9a3e                	add	s4,s4,a5
        found = 1;
    80001236:	4b85                	li	s7,1
    80001238:	a0a9                	j	80001282 <scheduler+0x92>
      release(&p->lock);
    8000123a:	8526                	mv	a0,s1
    8000123c:	46e050ef          	jal	800066aa <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001240:	16848493          	addi	s1,s1,360
    80001244:	03248563          	beq	s1,s2,8000126e <scheduler+0x7e>
      acquire(&p->lock);
    80001248:	8526                	mv	a0,s1
    8000124a:	3cc050ef          	jal	80006616 <acquire>
      if(p->state == RUNNABLE) {
    8000124e:	4c9c                	lw	a5,24(s1)
    80001250:	ff3795e3          	bne	a5,s3,8000123a <scheduler+0x4a>
        p->state = RUNNING;
    80001254:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001258:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    8000125c:	06048593          	addi	a1,s1,96
    80001260:	855a                	mv	a0,s6
    80001262:	5bc000ef          	jal	8000181e <swtch>
        c->proc = 0;
    80001266:	020a3823          	sd	zero,48(s4)
        found = 1;
    8000126a:	8ade                	mv	s5,s7
    8000126c:	b7f9                	j	8000123a <scheduler+0x4a>
    if(found == 0) {
    8000126e:	000a9a63          	bnez	s5,80001282 <scheduler+0x92>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001272:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001276:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000127a:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    8000127e:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001282:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001286:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000128a:	10079073          	csrw	sstatus,a5
    int found = 0;
    8000128e:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001290:	00008497          	auipc	s1,0x8
    80001294:	c1048493          	addi	s1,s1,-1008 # 80008ea0 <proc>
      if(p->state == RUNNABLE) {
    80001298:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    8000129a:	0000d917          	auipc	s2,0xd
    8000129e:	60690913          	addi	s2,s2,1542 # 8000e8a0 <tickslock>
    800012a2:	b75d                	j	80001248 <scheduler+0x58>

00000000800012a4 <sched>:
{
    800012a4:	7179                	addi	sp,sp,-48
    800012a6:	f406                	sd	ra,40(sp)
    800012a8:	f022                	sd	s0,32(sp)
    800012aa:	ec26                	sd	s1,24(sp)
    800012ac:	e84a                	sd	s2,16(sp)
    800012ae:	e44e                	sd	s3,8(sp)
    800012b0:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    800012b2:	b09ff0ef          	jal	80000dba <myproc>
    800012b6:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    800012b8:	2ee050ef          	jal	800065a6 <holding>
    800012bc:	c935                	beqz	a0,80001330 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    800012be:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    800012c0:	2781                	sext.w	a5,a5
    800012c2:	079e                	slli	a5,a5,0x7
    800012c4:	00007717          	auipc	a4,0x7
    800012c8:	7ac70713          	addi	a4,a4,1964 # 80008a70 <pid_lock>
    800012cc:	97ba                	add	a5,a5,a4
    800012ce:	0a87a703          	lw	a4,168(a5)
    800012d2:	4785                	li	a5,1
    800012d4:	06f71463          	bne	a4,a5,8000133c <sched+0x98>
  if(p->state == RUNNING)
    800012d8:	4c98                	lw	a4,24(s1)
    800012da:	4791                	li	a5,4
    800012dc:	06f70663          	beq	a4,a5,80001348 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800012e0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800012e4:	8b89                	andi	a5,a5,2
  if(intr_get())
    800012e6:	e7bd                	bnez	a5,80001354 <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    800012e8:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    800012ea:	00007917          	auipc	s2,0x7
    800012ee:	78690913          	addi	s2,s2,1926 # 80008a70 <pid_lock>
    800012f2:	2781                	sext.w	a5,a5
    800012f4:	079e                	slli	a5,a5,0x7
    800012f6:	97ca                	add	a5,a5,s2
    800012f8:	0ac7a983          	lw	s3,172(a5)
    800012fc:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800012fe:	2781                	sext.w	a5,a5
    80001300:	079e                	slli	a5,a5,0x7
    80001302:	07a1                	addi	a5,a5,8
    80001304:	00007597          	auipc	a1,0x7
    80001308:	79c58593          	addi	a1,a1,1948 # 80008aa0 <cpus>
    8000130c:	95be                	add	a1,a1,a5
    8000130e:	06048513          	addi	a0,s1,96
    80001312:	50c000ef          	jal	8000181e <swtch>
    80001316:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001318:	2781                	sext.w	a5,a5
    8000131a:	079e                	slli	a5,a5,0x7
    8000131c:	993e                	add	s2,s2,a5
    8000131e:	0b392623          	sw	s3,172(s2)
}
    80001322:	70a2                	ld	ra,40(sp)
    80001324:	7402                	ld	s0,32(sp)
    80001326:	64e2                	ld	s1,24(sp)
    80001328:	6942                	ld	s2,16(sp)
    8000132a:	69a2                	ld	s3,8(sp)
    8000132c:	6145                	addi	sp,sp,48
    8000132e:	8082                	ret
    panic("sched p->lock");
    80001330:	00007517          	auipc	a0,0x7
    80001334:	eb850513          	addi	a0,a0,-328 # 800081e8 <etext+0x1e8>
    80001338:	7a1040ef          	jal	800062d8 <panic>
    panic("sched locks");
    8000133c:	00007517          	auipc	a0,0x7
    80001340:	ebc50513          	addi	a0,a0,-324 # 800081f8 <etext+0x1f8>
    80001344:	795040ef          	jal	800062d8 <panic>
    panic("sched running");
    80001348:	00007517          	auipc	a0,0x7
    8000134c:	ec050513          	addi	a0,a0,-320 # 80008208 <etext+0x208>
    80001350:	789040ef          	jal	800062d8 <panic>
    panic("sched interruptible");
    80001354:	00007517          	auipc	a0,0x7
    80001358:	ec450513          	addi	a0,a0,-316 # 80008218 <etext+0x218>
    8000135c:	77d040ef          	jal	800062d8 <panic>

0000000080001360 <yield>:
{
    80001360:	1101                	addi	sp,sp,-32
    80001362:	ec06                	sd	ra,24(sp)
    80001364:	e822                	sd	s0,16(sp)
    80001366:	e426                	sd	s1,8(sp)
    80001368:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    8000136a:	a51ff0ef          	jal	80000dba <myproc>
    8000136e:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001370:	2a6050ef          	jal	80006616 <acquire>
  p->state = RUNNABLE;
    80001374:	478d                	li	a5,3
    80001376:	cc9c                	sw	a5,24(s1)
  sched();
    80001378:	f2dff0ef          	jal	800012a4 <sched>
  release(&p->lock);
    8000137c:	8526                	mv	a0,s1
    8000137e:	32c050ef          	jal	800066aa <release>
}
    80001382:	60e2                	ld	ra,24(sp)
    80001384:	6442                	ld	s0,16(sp)
    80001386:	64a2                	ld	s1,8(sp)
    80001388:	6105                	addi	sp,sp,32
    8000138a:	8082                	ret

000000008000138c <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    8000138c:	7179                	addi	sp,sp,-48
    8000138e:	f406                	sd	ra,40(sp)
    80001390:	f022                	sd	s0,32(sp)
    80001392:	ec26                	sd	s1,24(sp)
    80001394:	e84a                	sd	s2,16(sp)
    80001396:	e44e                	sd	s3,8(sp)
    80001398:	1800                	addi	s0,sp,48
    8000139a:	89aa                	mv	s3,a0
    8000139c:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000139e:	a1dff0ef          	jal	80000dba <myproc>
    800013a2:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    800013a4:	272050ef          	jal	80006616 <acquire>
  release(lk);
    800013a8:	854a                	mv	a0,s2
    800013aa:	300050ef          	jal	800066aa <release>

  // Go to sleep.
  p->chan = chan;
    800013ae:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    800013b2:	4789                	li	a5,2
    800013b4:	cc9c                	sw	a5,24(s1)

  sched();
    800013b6:	eefff0ef          	jal	800012a4 <sched>

  // Tidy up.
  p->chan = 0;
    800013ba:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    800013be:	8526                	mv	a0,s1
    800013c0:	2ea050ef          	jal	800066aa <release>
  acquire(lk);
    800013c4:	854a                	mv	a0,s2
    800013c6:	250050ef          	jal	80006616 <acquire>
}
    800013ca:	70a2                	ld	ra,40(sp)
    800013cc:	7402                	ld	s0,32(sp)
    800013ce:	64e2                	ld	s1,24(sp)
    800013d0:	6942                	ld	s2,16(sp)
    800013d2:	69a2                	ld	s3,8(sp)
    800013d4:	6145                	addi	sp,sp,48
    800013d6:	8082                	ret

00000000800013d8 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800013d8:	7139                	addi	sp,sp,-64
    800013da:	fc06                	sd	ra,56(sp)
    800013dc:	f822                	sd	s0,48(sp)
    800013de:	f426                	sd	s1,40(sp)
    800013e0:	f04a                	sd	s2,32(sp)
    800013e2:	ec4e                	sd	s3,24(sp)
    800013e4:	e852                	sd	s4,16(sp)
    800013e6:	e456                	sd	s5,8(sp)
    800013e8:	0080                	addi	s0,sp,64
    800013ea:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800013ec:	00008497          	auipc	s1,0x8
    800013f0:	ab448493          	addi	s1,s1,-1356 # 80008ea0 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800013f4:	4989                	li	s3,2
        p->state = RUNNABLE;
    800013f6:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800013f8:	0000d917          	auipc	s2,0xd
    800013fc:	4a890913          	addi	s2,s2,1192 # 8000e8a0 <tickslock>
    80001400:	a801                	j	80001410 <wakeup+0x38>
      }
      release(&p->lock);
    80001402:	8526                	mv	a0,s1
    80001404:	2a6050ef          	jal	800066aa <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001408:	16848493          	addi	s1,s1,360
    8000140c:	03248263          	beq	s1,s2,80001430 <wakeup+0x58>
    if(p != myproc()){
    80001410:	9abff0ef          	jal	80000dba <myproc>
    80001414:	fe950ae3          	beq	a0,s1,80001408 <wakeup+0x30>
      acquire(&p->lock);
    80001418:	8526                	mv	a0,s1
    8000141a:	1fc050ef          	jal	80006616 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    8000141e:	4c9c                	lw	a5,24(s1)
    80001420:	ff3791e3          	bne	a5,s3,80001402 <wakeup+0x2a>
    80001424:	709c                	ld	a5,32(s1)
    80001426:	fd479ee3          	bne	a5,s4,80001402 <wakeup+0x2a>
        p->state = RUNNABLE;
    8000142a:	0154ac23          	sw	s5,24(s1)
    8000142e:	bfd1                	j	80001402 <wakeup+0x2a>
    }
  }
}
    80001430:	70e2                	ld	ra,56(sp)
    80001432:	7442                	ld	s0,48(sp)
    80001434:	74a2                	ld	s1,40(sp)
    80001436:	7902                	ld	s2,32(sp)
    80001438:	69e2                	ld	s3,24(sp)
    8000143a:	6a42                	ld	s4,16(sp)
    8000143c:	6aa2                	ld	s5,8(sp)
    8000143e:	6121                	addi	sp,sp,64
    80001440:	8082                	ret

0000000080001442 <reparent>:
{
    80001442:	7179                	addi	sp,sp,-48
    80001444:	f406                	sd	ra,40(sp)
    80001446:	f022                	sd	s0,32(sp)
    80001448:	ec26                	sd	s1,24(sp)
    8000144a:	e84a                	sd	s2,16(sp)
    8000144c:	e44e                	sd	s3,8(sp)
    8000144e:	e052                	sd	s4,0(sp)
    80001450:	1800                	addi	s0,sp,48
    80001452:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001454:	00008497          	auipc	s1,0x8
    80001458:	a4c48493          	addi	s1,s1,-1460 # 80008ea0 <proc>
      pp->parent = initproc;
    8000145c:	00007a17          	auipc	s4,0x7
    80001460:	5b4a0a13          	addi	s4,s4,1460 # 80008a10 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001464:	0000d997          	auipc	s3,0xd
    80001468:	43c98993          	addi	s3,s3,1084 # 8000e8a0 <tickslock>
    8000146c:	a029                	j	80001476 <reparent+0x34>
    8000146e:	16848493          	addi	s1,s1,360
    80001472:	01348b63          	beq	s1,s3,80001488 <reparent+0x46>
    if(pp->parent == p){
    80001476:	7c9c                	ld	a5,56(s1)
    80001478:	ff279be3          	bne	a5,s2,8000146e <reparent+0x2c>
      pp->parent = initproc;
    8000147c:	000a3503          	ld	a0,0(s4)
    80001480:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001482:	f57ff0ef          	jal	800013d8 <wakeup>
    80001486:	b7e5                	j	8000146e <reparent+0x2c>
}
    80001488:	70a2                	ld	ra,40(sp)
    8000148a:	7402                	ld	s0,32(sp)
    8000148c:	64e2                	ld	s1,24(sp)
    8000148e:	6942                	ld	s2,16(sp)
    80001490:	69a2                	ld	s3,8(sp)
    80001492:	6a02                	ld	s4,0(sp)
    80001494:	6145                	addi	sp,sp,48
    80001496:	8082                	ret

0000000080001498 <exit>:
{
    80001498:	7179                	addi	sp,sp,-48
    8000149a:	f406                	sd	ra,40(sp)
    8000149c:	f022                	sd	s0,32(sp)
    8000149e:	ec26                	sd	s1,24(sp)
    800014a0:	e84a                	sd	s2,16(sp)
    800014a2:	e44e                	sd	s3,8(sp)
    800014a4:	e052                	sd	s4,0(sp)
    800014a6:	1800                	addi	s0,sp,48
    800014a8:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800014aa:	911ff0ef          	jal	80000dba <myproc>
    800014ae:	89aa                	mv	s3,a0
  if(p == initproc)
    800014b0:	00007797          	auipc	a5,0x7
    800014b4:	5607b783          	ld	a5,1376(a5) # 80008a10 <initproc>
    800014b8:	0d050493          	addi	s1,a0,208
    800014bc:	15050913          	addi	s2,a0,336
    800014c0:	00a79b63          	bne	a5,a0,800014d6 <exit+0x3e>
    panic("init exiting");
    800014c4:	00007517          	auipc	a0,0x7
    800014c8:	d6c50513          	addi	a0,a0,-660 # 80008230 <etext+0x230>
    800014cc:	60d040ef          	jal	800062d8 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    800014d0:	04a1                	addi	s1,s1,8
    800014d2:	01248963          	beq	s1,s2,800014e4 <exit+0x4c>
    if(p->ofile[fd]){
    800014d6:	6088                	ld	a0,0(s1)
    800014d8:	dd65                	beqz	a0,800014d0 <exit+0x38>
      fileclose(f);
    800014da:	68f010ef          	jal	80003368 <fileclose>
      p->ofile[fd] = 0;
    800014de:	0004b023          	sd	zero,0(s1)
    800014e2:	b7fd                	j	800014d0 <exit+0x38>
  begin_op();
    800014e4:	253010ef          	jal	80002f36 <begin_op>
  iput(p->cwd);
    800014e8:	1509b503          	ld	a0,336(s3)
    800014ec:	314010ef          	jal	80002800 <iput>
  end_op();
    800014f0:	2b7010ef          	jal	80002fa6 <end_op>
  p->cwd = 0;
    800014f4:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800014f8:	00007517          	auipc	a0,0x7
    800014fc:	59050513          	addi	a0,a0,1424 # 80008a88 <wait_lock>
    80001500:	116050ef          	jal	80006616 <acquire>
  reparent(p);
    80001504:	854e                	mv	a0,s3
    80001506:	f3dff0ef          	jal	80001442 <reparent>
  wakeup(p->parent);
    8000150a:	0389b503          	ld	a0,56(s3)
    8000150e:	ecbff0ef          	jal	800013d8 <wakeup>
  acquire(&p->lock);
    80001512:	854e                	mv	a0,s3
    80001514:	102050ef          	jal	80006616 <acquire>
  p->xstate = status;
    80001518:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    8000151c:	4795                	li	a5,5
    8000151e:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80001522:	00007517          	auipc	a0,0x7
    80001526:	56650513          	addi	a0,a0,1382 # 80008a88 <wait_lock>
    8000152a:	180050ef          	jal	800066aa <release>
  sched();
    8000152e:	d77ff0ef          	jal	800012a4 <sched>
  panic("zombie exit");
    80001532:	00007517          	auipc	a0,0x7
    80001536:	d0e50513          	addi	a0,a0,-754 # 80008240 <etext+0x240>
    8000153a:	59f040ef          	jal	800062d8 <panic>

000000008000153e <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    8000153e:	7179                	addi	sp,sp,-48
    80001540:	f406                	sd	ra,40(sp)
    80001542:	f022                	sd	s0,32(sp)
    80001544:	ec26                	sd	s1,24(sp)
    80001546:	e84a                	sd	s2,16(sp)
    80001548:	e44e                	sd	s3,8(sp)
    8000154a:	1800                	addi	s0,sp,48
    8000154c:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    8000154e:	00008497          	auipc	s1,0x8
    80001552:	95248493          	addi	s1,s1,-1710 # 80008ea0 <proc>
    80001556:	0000d997          	auipc	s3,0xd
    8000155a:	34a98993          	addi	s3,s3,842 # 8000e8a0 <tickslock>
    acquire(&p->lock);
    8000155e:	8526                	mv	a0,s1
    80001560:	0b6050ef          	jal	80006616 <acquire>
    if(p->pid == pid){
    80001564:	589c                	lw	a5,48(s1)
    80001566:	01278b63          	beq	a5,s2,8000157c <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000156a:	8526                	mv	a0,s1
    8000156c:	13e050ef          	jal	800066aa <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80001570:	16848493          	addi	s1,s1,360
    80001574:	ff3495e3          	bne	s1,s3,8000155e <kill+0x20>
  }
  return -1;
    80001578:	557d                	li	a0,-1
    8000157a:	a819                	j	80001590 <kill+0x52>
      p->killed = 1;
    8000157c:	4785                	li	a5,1
    8000157e:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80001580:	4c98                	lw	a4,24(s1)
    80001582:	4789                	li	a5,2
    80001584:	00f70d63          	beq	a4,a5,8000159e <kill+0x60>
      release(&p->lock);
    80001588:	8526                	mv	a0,s1
    8000158a:	120050ef          	jal	800066aa <release>
      return 0;
    8000158e:	4501                	li	a0,0
}
    80001590:	70a2                	ld	ra,40(sp)
    80001592:	7402                	ld	s0,32(sp)
    80001594:	64e2                	ld	s1,24(sp)
    80001596:	6942                	ld	s2,16(sp)
    80001598:	69a2                	ld	s3,8(sp)
    8000159a:	6145                	addi	sp,sp,48
    8000159c:	8082                	ret
        p->state = RUNNABLE;
    8000159e:	478d                	li	a5,3
    800015a0:	cc9c                	sw	a5,24(s1)
    800015a2:	b7dd                	j	80001588 <kill+0x4a>

00000000800015a4 <setkilled>:

void
setkilled(struct proc *p)
{
    800015a4:	1101                	addi	sp,sp,-32
    800015a6:	ec06                	sd	ra,24(sp)
    800015a8:	e822                	sd	s0,16(sp)
    800015aa:	e426                	sd	s1,8(sp)
    800015ac:	1000                	addi	s0,sp,32
    800015ae:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800015b0:	066050ef          	jal	80006616 <acquire>
  p->killed = 1;
    800015b4:	4785                	li	a5,1
    800015b6:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800015b8:	8526                	mv	a0,s1
    800015ba:	0f0050ef          	jal	800066aa <release>
}
    800015be:	60e2                	ld	ra,24(sp)
    800015c0:	6442                	ld	s0,16(sp)
    800015c2:	64a2                	ld	s1,8(sp)
    800015c4:	6105                	addi	sp,sp,32
    800015c6:	8082                	ret

00000000800015c8 <killed>:

int
killed(struct proc *p)
{
    800015c8:	1101                	addi	sp,sp,-32
    800015ca:	ec06                	sd	ra,24(sp)
    800015cc:	e822                	sd	s0,16(sp)
    800015ce:	e426                	sd	s1,8(sp)
    800015d0:	e04a                	sd	s2,0(sp)
    800015d2:	1000                	addi	s0,sp,32
    800015d4:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800015d6:	040050ef          	jal	80006616 <acquire>
  k = p->killed;
    800015da:	549c                	lw	a5,40(s1)
    800015dc:	893e                	mv	s2,a5
  release(&p->lock);
    800015de:	8526                	mv	a0,s1
    800015e0:	0ca050ef          	jal	800066aa <release>
  return k;
}
    800015e4:	854a                	mv	a0,s2
    800015e6:	60e2                	ld	ra,24(sp)
    800015e8:	6442                	ld	s0,16(sp)
    800015ea:	64a2                	ld	s1,8(sp)
    800015ec:	6902                	ld	s2,0(sp)
    800015ee:	6105                	addi	sp,sp,32
    800015f0:	8082                	ret

00000000800015f2 <wait>:
{
    800015f2:	715d                	addi	sp,sp,-80
    800015f4:	e486                	sd	ra,72(sp)
    800015f6:	e0a2                	sd	s0,64(sp)
    800015f8:	fc26                	sd	s1,56(sp)
    800015fa:	f84a                	sd	s2,48(sp)
    800015fc:	f44e                	sd	s3,40(sp)
    800015fe:	f052                	sd	s4,32(sp)
    80001600:	ec56                	sd	s5,24(sp)
    80001602:	e85a                	sd	s6,16(sp)
    80001604:	e45e                	sd	s7,8(sp)
    80001606:	0880                	addi	s0,sp,80
    80001608:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    8000160a:	fb0ff0ef          	jal	80000dba <myproc>
    8000160e:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80001610:	00007517          	auipc	a0,0x7
    80001614:	47850513          	addi	a0,a0,1144 # 80008a88 <wait_lock>
    80001618:	7ff040ef          	jal	80006616 <acquire>
        if(pp->state == ZOMBIE){
    8000161c:	4a15                	li	s4,5
        havekids = 1;
    8000161e:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001620:	0000d997          	auipc	s3,0xd
    80001624:	28098993          	addi	s3,s3,640 # 8000e8a0 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80001628:	00007b17          	auipc	s6,0x7
    8000162c:	460b0b13          	addi	s6,s6,1120 # 80008a88 <wait_lock>
    80001630:	a869                	j	800016ca <wait+0xd8>
          pid = pp->pid;
    80001632:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80001636:	000b8c63          	beqz	s7,8000164e <wait+0x5c>
    8000163a:	4691                	li	a3,4
    8000163c:	02c48613          	addi	a2,s1,44
    80001640:	85de                	mv	a1,s7
    80001642:	05093503          	ld	a0,80(s2)
    80001646:	bf8ff0ef          	jal	80000a3e <copyout>
    8000164a:	02054a63          	bltz	a0,8000167e <wait+0x8c>
          freeproc(pp);
    8000164e:	8526                	mv	a0,s1
    80001650:	8dfff0ef          	jal	80000f2e <freeproc>
          release(&pp->lock);
    80001654:	8526                	mv	a0,s1
    80001656:	054050ef          	jal	800066aa <release>
          release(&wait_lock);
    8000165a:	00007517          	auipc	a0,0x7
    8000165e:	42e50513          	addi	a0,a0,1070 # 80008a88 <wait_lock>
    80001662:	048050ef          	jal	800066aa <release>
}
    80001666:	854e                	mv	a0,s3
    80001668:	60a6                	ld	ra,72(sp)
    8000166a:	6406                	ld	s0,64(sp)
    8000166c:	74e2                	ld	s1,56(sp)
    8000166e:	7942                	ld	s2,48(sp)
    80001670:	79a2                	ld	s3,40(sp)
    80001672:	7a02                	ld	s4,32(sp)
    80001674:	6ae2                	ld	s5,24(sp)
    80001676:	6b42                	ld	s6,16(sp)
    80001678:	6ba2                	ld	s7,8(sp)
    8000167a:	6161                	addi	sp,sp,80
    8000167c:	8082                	ret
            release(&pp->lock);
    8000167e:	8526                	mv	a0,s1
    80001680:	02a050ef          	jal	800066aa <release>
            release(&wait_lock);
    80001684:	00007517          	auipc	a0,0x7
    80001688:	40450513          	addi	a0,a0,1028 # 80008a88 <wait_lock>
    8000168c:	01e050ef          	jal	800066aa <release>
            return -1;
    80001690:	59fd                	li	s3,-1
    80001692:	bfd1                	j	80001666 <wait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001694:	16848493          	addi	s1,s1,360
    80001698:	03348063          	beq	s1,s3,800016b8 <wait+0xc6>
      if(pp->parent == p){
    8000169c:	7c9c                	ld	a5,56(s1)
    8000169e:	ff279be3          	bne	a5,s2,80001694 <wait+0xa2>
        acquire(&pp->lock);
    800016a2:	8526                	mv	a0,s1
    800016a4:	773040ef          	jal	80006616 <acquire>
        if(pp->state == ZOMBIE){
    800016a8:	4c9c                	lw	a5,24(s1)
    800016aa:	f94784e3          	beq	a5,s4,80001632 <wait+0x40>
        release(&pp->lock);
    800016ae:	8526                	mv	a0,s1
    800016b0:	7fb040ef          	jal	800066aa <release>
        havekids = 1;
    800016b4:	8756                	mv	a4,s5
    800016b6:	bff9                	j	80001694 <wait+0xa2>
    if(!havekids || killed(p)){
    800016b8:	cf19                	beqz	a4,800016d6 <wait+0xe4>
    800016ba:	854a                	mv	a0,s2
    800016bc:	f0dff0ef          	jal	800015c8 <killed>
    800016c0:	e919                	bnez	a0,800016d6 <wait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800016c2:	85da                	mv	a1,s6
    800016c4:	854a                	mv	a0,s2
    800016c6:	cc7ff0ef          	jal	8000138c <sleep>
    havekids = 0;
    800016ca:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800016cc:	00007497          	auipc	s1,0x7
    800016d0:	7d448493          	addi	s1,s1,2004 # 80008ea0 <proc>
    800016d4:	b7e1                	j	8000169c <wait+0xaa>
      release(&wait_lock);
    800016d6:	00007517          	auipc	a0,0x7
    800016da:	3b250513          	addi	a0,a0,946 # 80008a88 <wait_lock>
    800016de:	7cd040ef          	jal	800066aa <release>
      return -1;
    800016e2:	59fd                	li	s3,-1
    800016e4:	b749                	j	80001666 <wait+0x74>

00000000800016e6 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800016e6:	7179                	addi	sp,sp,-48
    800016e8:	f406                	sd	ra,40(sp)
    800016ea:	f022                	sd	s0,32(sp)
    800016ec:	ec26                	sd	s1,24(sp)
    800016ee:	e84a                	sd	s2,16(sp)
    800016f0:	e44e                	sd	s3,8(sp)
    800016f2:	e052                	sd	s4,0(sp)
    800016f4:	1800                	addi	s0,sp,48
    800016f6:	84aa                	mv	s1,a0
    800016f8:	8a2e                	mv	s4,a1
    800016fa:	89b2                	mv	s3,a2
    800016fc:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800016fe:	ebcff0ef          	jal	80000dba <myproc>
  if(user_dst){
    80001702:	cc99                	beqz	s1,80001720 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80001704:	86ca                	mv	a3,s2
    80001706:	864e                	mv	a2,s3
    80001708:	85d2                	mv	a1,s4
    8000170a:	6928                	ld	a0,80(a0)
    8000170c:	b32ff0ef          	jal	80000a3e <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80001710:	70a2                	ld	ra,40(sp)
    80001712:	7402                	ld	s0,32(sp)
    80001714:	64e2                	ld	s1,24(sp)
    80001716:	6942                	ld	s2,16(sp)
    80001718:	69a2                	ld	s3,8(sp)
    8000171a:	6a02                	ld	s4,0(sp)
    8000171c:	6145                	addi	sp,sp,48
    8000171e:	8082                	ret
    memmove((char *)dst, src, len);
    80001720:	0009061b          	sext.w	a2,s2
    80001724:	85ce                	mv	a1,s3
    80001726:	8552                	mv	a0,s4
    80001728:	a97fe0ef          	jal	800001be <memmove>
    return 0;
    8000172c:	8526                	mv	a0,s1
    8000172e:	b7cd                	j	80001710 <either_copyout+0x2a>

0000000080001730 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80001730:	7179                	addi	sp,sp,-48
    80001732:	f406                	sd	ra,40(sp)
    80001734:	f022                	sd	s0,32(sp)
    80001736:	ec26                	sd	s1,24(sp)
    80001738:	e84a                	sd	s2,16(sp)
    8000173a:	e44e                	sd	s3,8(sp)
    8000173c:	e052                	sd	s4,0(sp)
    8000173e:	1800                	addi	s0,sp,48
    80001740:	8a2a                	mv	s4,a0
    80001742:	84ae                	mv	s1,a1
    80001744:	89b2                	mv	s3,a2
    80001746:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80001748:	e72ff0ef          	jal	80000dba <myproc>
  if(user_src){
    8000174c:	cc99                	beqz	s1,8000176a <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    8000174e:	86ca                	mv	a3,s2
    80001750:	864e                	mv	a2,s3
    80001752:	85d2                	mv	a1,s4
    80001754:	6928                	ld	a0,80(a0)
    80001756:	b98ff0ef          	jal	80000aee <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    8000175a:	70a2                	ld	ra,40(sp)
    8000175c:	7402                	ld	s0,32(sp)
    8000175e:	64e2                	ld	s1,24(sp)
    80001760:	6942                	ld	s2,16(sp)
    80001762:	69a2                	ld	s3,8(sp)
    80001764:	6a02                	ld	s4,0(sp)
    80001766:	6145                	addi	sp,sp,48
    80001768:	8082                	ret
    memmove(dst, (char*)src, len);
    8000176a:	0009061b          	sext.w	a2,s2
    8000176e:	85ce                	mv	a1,s3
    80001770:	8552                	mv	a0,s4
    80001772:	a4dfe0ef          	jal	800001be <memmove>
    return 0;
    80001776:	8526                	mv	a0,s1
    80001778:	b7cd                	j	8000175a <either_copyin+0x2a>

000000008000177a <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000177a:	715d                	addi	sp,sp,-80
    8000177c:	e486                	sd	ra,72(sp)
    8000177e:	e0a2                	sd	s0,64(sp)
    80001780:	fc26                	sd	s1,56(sp)
    80001782:	f84a                	sd	s2,48(sp)
    80001784:	f44e                	sd	s3,40(sp)
    80001786:	f052                	sd	s4,32(sp)
    80001788:	ec56                	sd	s5,24(sp)
    8000178a:	e85a                	sd	s6,16(sp)
    8000178c:	e45e                	sd	s7,8(sp)
    8000178e:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80001790:	00007517          	auipc	a0,0x7
    80001794:	88850513          	addi	a0,a0,-1912 # 80008018 <etext+0x18>
    80001798:	031040ef          	jal	80005fc8 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000179c:	00008497          	auipc	s1,0x8
    800017a0:	85c48493          	addi	s1,s1,-1956 # 80008ff8 <proc+0x158>
    800017a4:	0000d917          	auipc	s2,0xd
    800017a8:	25490913          	addi	s2,s2,596 # 8000e9f8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800017ac:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800017ae:	00007997          	auipc	s3,0x7
    800017b2:	aa298993          	addi	s3,s3,-1374 # 80008250 <etext+0x250>
    printf("%d %s %s", p->pid, state, p->name);
    800017b6:	00007a97          	auipc	s5,0x7
    800017ba:	aa2a8a93          	addi	s5,s5,-1374 # 80008258 <etext+0x258>
    printf("\n");
    800017be:	00007a17          	auipc	s4,0x7
    800017c2:	85aa0a13          	addi	s4,s4,-1958 # 80008018 <etext+0x18>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800017c6:	00007b97          	auipc	s7,0x7
    800017ca:	072b8b93          	addi	s7,s7,114 # 80008838 <states.0>
    800017ce:	a829                	j	800017e8 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800017d0:	ed86a583          	lw	a1,-296(a3)
    800017d4:	8556                	mv	a0,s5
    800017d6:	7f2040ef          	jal	80005fc8 <printf>
    printf("\n");
    800017da:	8552                	mv	a0,s4
    800017dc:	7ec040ef          	jal	80005fc8 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800017e0:	16848493          	addi	s1,s1,360
    800017e4:	03248263          	beq	s1,s2,80001808 <procdump+0x8e>
    if(p->state == UNUSED)
    800017e8:	86a6                	mv	a3,s1
    800017ea:	ec04a783          	lw	a5,-320(s1)
    800017ee:	dbed                	beqz	a5,800017e0 <procdump+0x66>
      state = "???";
    800017f0:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800017f2:	fcfb6fe3          	bltu	s6,a5,800017d0 <procdump+0x56>
    800017f6:	02079713          	slli	a4,a5,0x20
    800017fa:	01d75793          	srli	a5,a4,0x1d
    800017fe:	97de                	add	a5,a5,s7
    80001800:	6390                	ld	a2,0(a5)
    80001802:	f679                	bnez	a2,800017d0 <procdump+0x56>
      state = "???";
    80001804:	864e                	mv	a2,s3
    80001806:	b7e9                	j	800017d0 <procdump+0x56>
  }
}
    80001808:	60a6                	ld	ra,72(sp)
    8000180a:	6406                	ld	s0,64(sp)
    8000180c:	74e2                	ld	s1,56(sp)
    8000180e:	7942                	ld	s2,48(sp)
    80001810:	79a2                	ld	s3,40(sp)
    80001812:	7a02                	ld	s4,32(sp)
    80001814:	6ae2                	ld	s5,24(sp)
    80001816:	6b42                	ld	s6,16(sp)
    80001818:	6ba2                	ld	s7,8(sp)
    8000181a:	6161                	addi	sp,sp,80
    8000181c:	8082                	ret

000000008000181e <swtch>:
    8000181e:	00153023          	sd	ra,0(a0)
    80001822:	00253423          	sd	sp,8(a0)
    80001826:	e900                	sd	s0,16(a0)
    80001828:	ed04                	sd	s1,24(a0)
    8000182a:	03253023          	sd	s2,32(a0)
    8000182e:	03353423          	sd	s3,40(a0)
    80001832:	03453823          	sd	s4,48(a0)
    80001836:	03553c23          	sd	s5,56(a0)
    8000183a:	05653023          	sd	s6,64(a0)
    8000183e:	05753423          	sd	s7,72(a0)
    80001842:	05853823          	sd	s8,80(a0)
    80001846:	05953c23          	sd	s9,88(a0)
    8000184a:	07a53023          	sd	s10,96(a0)
    8000184e:	07b53423          	sd	s11,104(a0)
    80001852:	0005b083          	ld	ra,0(a1)
    80001856:	0085b103          	ld	sp,8(a1)
    8000185a:	6980                	ld	s0,16(a1)
    8000185c:	6d84                	ld	s1,24(a1)
    8000185e:	0205b903          	ld	s2,32(a1)
    80001862:	0285b983          	ld	s3,40(a1)
    80001866:	0305ba03          	ld	s4,48(a1)
    8000186a:	0385ba83          	ld	s5,56(a1)
    8000186e:	0405bb03          	ld	s6,64(a1)
    80001872:	0485bb83          	ld	s7,72(a1)
    80001876:	0505bc03          	ld	s8,80(a1)
    8000187a:	0585bc83          	ld	s9,88(a1)
    8000187e:	0605bd03          	ld	s10,96(a1)
    80001882:	0685bd83          	ld	s11,104(a1)
    80001886:	8082                	ret

0000000080001888 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001888:	1141                	addi	sp,sp,-16
    8000188a:	e406                	sd	ra,8(sp)
    8000188c:	e022                	sd	s0,0(sp)
    8000188e:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001890:	00007597          	auipc	a1,0x7
    80001894:	a0858593          	addi	a1,a1,-1528 # 80008298 <etext+0x298>
    80001898:	0000d517          	auipc	a0,0xd
    8000189c:	00850513          	addi	a0,a0,8 # 8000e8a0 <tickslock>
    800018a0:	4ed040ef          	jal	8000658c <initlock>
}
    800018a4:	60a2                	ld	ra,8(sp)
    800018a6:	6402                	ld	s0,0(sp)
    800018a8:	0141                	addi	sp,sp,16
    800018aa:	8082                	ret

00000000800018ac <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800018ac:	1141                	addi	sp,sp,-16
    800018ae:	e406                	sd	ra,8(sp)
    800018b0:	e022                	sd	s0,0(sp)
    800018b2:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    800018b4:	00003797          	auipc	a5,0x3
    800018b8:	e6c78793          	addi	a5,a5,-404 # 80004720 <kernelvec>
    800018bc:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800018c0:	60a2                	ld	ra,8(sp)
    800018c2:	6402                	ld	s0,0(sp)
    800018c4:	0141                	addi	sp,sp,16
    800018c6:	8082                	ret

00000000800018c8 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    800018c8:	1141                	addi	sp,sp,-16
    800018ca:	e406                	sd	ra,8(sp)
    800018cc:	e022                	sd	s0,0(sp)
    800018ce:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800018d0:	ceaff0ef          	jal	80000dba <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800018d4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800018d8:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800018da:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800018de:	00005697          	auipc	a3,0x5
    800018e2:	72268693          	addi	a3,a3,1826 # 80007000 <_trampoline>
    800018e6:	00005717          	auipc	a4,0x5
    800018ea:	71a70713          	addi	a4,a4,1818 # 80007000 <_trampoline>
    800018ee:	8f15                	sub	a4,a4,a3
    800018f0:	040007b7          	lui	a5,0x4000
    800018f4:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    800018f6:	07b2                	slli	a5,a5,0xc
    800018f8:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    800018fa:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800018fe:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80001900:	18002673          	csrr	a2,satp
    80001904:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80001906:	6d30                	ld	a2,88(a0)
    80001908:	6138                	ld	a4,64(a0)
    8000190a:	6585                	lui	a1,0x1
    8000190c:	972e                	add	a4,a4,a1
    8000190e:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80001910:	6d38                	ld	a4,88(a0)
    80001912:	00000617          	auipc	a2,0x0
    80001916:	12260613          	addi	a2,a2,290 # 80001a34 <usertrap>
    8000191a:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    8000191c:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    8000191e:	8612                	mv	a2,tp
    80001920:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001922:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80001926:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    8000192a:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000192e:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80001932:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001934:	6f18                	ld	a4,24(a4)
    80001936:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    8000193a:	6928                	ld	a0,80(a0)
    8000193c:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    8000193e:	00005717          	auipc	a4,0x5
    80001942:	75e70713          	addi	a4,a4,1886 # 8000709c <userret>
    80001946:	8f15                	sub	a4,a4,a3
    80001948:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    8000194a:	577d                	li	a4,-1
    8000194c:	177e                	slli	a4,a4,0x3f
    8000194e:	8d59                	or	a0,a0,a4
    80001950:	9782                	jalr	a5
}
    80001952:	60a2                	ld	ra,8(sp)
    80001954:	6402                	ld	s0,0(sp)
    80001956:	0141                	addi	sp,sp,16
    80001958:	8082                	ret

000000008000195a <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    8000195a:	1141                	addi	sp,sp,-16
    8000195c:	e406                	sd	ra,8(sp)
    8000195e:	e022                	sd	s0,0(sp)
    80001960:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80001962:	c24ff0ef          	jal	80000d86 <cpuid>
    80001966:	cd11                	beqz	a0,80001982 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001968:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    8000196c:	000f4737          	lui	a4,0xf4
    80001970:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80001974:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80001976:	14d79073          	csrw	stimecmp,a5
}
    8000197a:	60a2                	ld	ra,8(sp)
    8000197c:	6402                	ld	s0,0(sp)
    8000197e:	0141                	addi	sp,sp,16
    80001980:	8082                	ret
    acquire(&tickslock);
    80001982:	0000d517          	auipc	a0,0xd
    80001986:	f1e50513          	addi	a0,a0,-226 # 8000e8a0 <tickslock>
    8000198a:	48d040ef          	jal	80006616 <acquire>
    ticks++;
    8000198e:	00007717          	auipc	a4,0x7
    80001992:	08a70713          	addi	a4,a4,138 # 80008a18 <ticks>
    80001996:	431c                	lw	a5,0(a4)
    80001998:	2785                	addiw	a5,a5,1
    8000199a:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    8000199c:	853a                	mv	a0,a4
    8000199e:	a3bff0ef          	jal	800013d8 <wakeup>
    release(&tickslock);
    800019a2:	0000d517          	auipc	a0,0xd
    800019a6:	efe50513          	addi	a0,a0,-258 # 8000e8a0 <tickslock>
    800019aa:	501040ef          	jal	800066aa <release>
    800019ae:	bf6d                	j	80001968 <clockintr+0xe>

00000000800019b0 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800019b0:	1101                	addi	sp,sp,-32
    800019b2:	ec06                	sd	ra,24(sp)
    800019b4:	e822                	sd	s0,16(sp)
    800019b6:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    800019b8:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    800019bc:	57fd                	li	a5,-1
    800019be:	17fe                	slli	a5,a5,0x3f
    800019c0:	07a5                	addi	a5,a5,9
    800019c2:	00f70c63          	beq	a4,a5,800019da <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    800019c6:	57fd                	li	a5,-1
    800019c8:	17fe                	slli	a5,a5,0x3f
    800019ca:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    800019cc:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    800019ce:	04f70f63          	beq	a4,a5,80001a2c <devintr+0x7c>
  }
}
    800019d2:	60e2                	ld	ra,24(sp)
    800019d4:	6442                	ld	s0,16(sp)
    800019d6:	6105                	addi	sp,sp,32
    800019d8:	8082                	ret
    800019da:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    800019dc:	609020ef          	jal	800047e4 <plic_claim>
    800019e0:	872a                	mv	a4,a0
    800019e2:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    800019e4:	47a9                	li	a5,10
    800019e6:	00f50d63          	beq	a0,a5,80001a00 <devintr+0x50>
    } else if(irq == VIRTIO0_IRQ){
    800019ea:	4785                	li	a5,1
    800019ec:	02f50263          	beq	a0,a5,80001a10 <devintr+0x60>
    else if(irq == E1000_IRQ){
    800019f0:	02100793          	li	a5,33
    800019f4:	02f50163          	beq	a0,a5,80001a16 <devintr+0x66>
    return 1;
    800019f8:	4505                	li	a0,1
    else if(irq){
    800019fa:	e30d                	bnez	a4,80001a1c <devintr+0x6c>
    800019fc:	64a2                	ld	s1,8(sp)
    800019fe:	bfd1                	j	800019d2 <devintr+0x22>
      uartintr();
    80001a00:	34d040ef          	jal	8000654c <uartintr>
      plic_complete(irq);
    80001a04:	8526                	mv	a0,s1
    80001a06:	5ff020ef          	jal	80004804 <plic_complete>
    return 1;
    80001a0a:	4505                	li	a0,1
    80001a0c:	64a2                	ld	s1,8(sp)
    80001a0e:	b7d1                	j	800019d2 <devintr+0x22>
      virtio_disk_intr();
    80001a10:	26a030ef          	jal	80004c7a <virtio_disk_intr>
    if(irq)
    80001a14:	bfc5                	j	80001a04 <devintr+0x54>
      e1000_intr();
    80001a16:	5ac030ef          	jal	80004fc2 <e1000_intr>
    if(irq)
    80001a1a:	b7ed                	j	80001a04 <devintr+0x54>
      printf("unexpected interrupt irq=%d\n", irq);
    80001a1c:	85ba                	mv	a1,a4
    80001a1e:	00007517          	auipc	a0,0x7
    80001a22:	88250513          	addi	a0,a0,-1918 # 800082a0 <etext+0x2a0>
    80001a26:	5a2040ef          	jal	80005fc8 <printf>
    if(irq)
    80001a2a:	bfe9                	j	80001a04 <devintr+0x54>
    clockintr();
    80001a2c:	f2fff0ef          	jal	8000195a <clockintr>
    return 2;
    80001a30:	4509                	li	a0,2
    80001a32:	b745                	j	800019d2 <devintr+0x22>

0000000080001a34 <usertrap>:
{
    80001a34:	1101                	addi	sp,sp,-32
    80001a36:	ec06                	sd	ra,24(sp)
    80001a38:	e822                	sd	s0,16(sp)
    80001a3a:	e426                	sd	s1,8(sp)
    80001a3c:	e04a                	sd	s2,0(sp)
    80001a3e:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a40:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80001a44:	1007f793          	andi	a5,a5,256
    80001a48:	ef85                	bnez	a5,80001a80 <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001a4a:	00003797          	auipc	a5,0x3
    80001a4e:	cd678793          	addi	a5,a5,-810 # 80004720 <kernelvec>
    80001a52:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001a56:	b64ff0ef          	jal	80000dba <myproc>
    80001a5a:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001a5c:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001a5e:	14102773          	csrr	a4,sepc
    80001a62:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001a64:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001a68:	47a1                	li	a5,8
    80001a6a:	02f70163          	beq	a4,a5,80001a8c <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001a6e:	f43ff0ef          	jal	800019b0 <devintr>
    80001a72:	892a                	mv	s2,a0
    80001a74:	c135                	beqz	a0,80001ad8 <usertrap+0xa4>
  if(killed(p))
    80001a76:	8526                	mv	a0,s1
    80001a78:	b51ff0ef          	jal	800015c8 <killed>
    80001a7c:	cd1d                	beqz	a0,80001aba <usertrap+0x86>
    80001a7e:	a81d                	j	80001ab4 <usertrap+0x80>
    panic("usertrap: not from user mode");
    80001a80:	00007517          	auipc	a0,0x7
    80001a84:	84050513          	addi	a0,a0,-1984 # 800082c0 <etext+0x2c0>
    80001a88:	051040ef          	jal	800062d8 <panic>
    if(killed(p))
    80001a8c:	b3dff0ef          	jal	800015c8 <killed>
    80001a90:	e121                	bnez	a0,80001ad0 <usertrap+0x9c>
    p->trapframe->epc += 4;
    80001a92:	6cb8                	ld	a4,88(s1)
    80001a94:	6f1c                	ld	a5,24(a4)
    80001a96:	0791                	addi	a5,a5,4
    80001a98:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a9a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001a9e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001aa2:	10079073          	csrw	sstatus,a5
    syscall();
    80001aa6:	242000ef          	jal	80001ce8 <syscall>
  if(killed(p))
    80001aaa:	8526                	mv	a0,s1
    80001aac:	b1dff0ef          	jal	800015c8 <killed>
    80001ab0:	c901                	beqz	a0,80001ac0 <usertrap+0x8c>
    80001ab2:	4901                	li	s2,0
    exit(-1);
    80001ab4:	557d                	li	a0,-1
    80001ab6:	9e3ff0ef          	jal	80001498 <exit>
  if(which_dev == 2)
    80001aba:	4789                	li	a5,2
    80001abc:	04f90563          	beq	s2,a5,80001b06 <usertrap+0xd2>
  usertrapret();
    80001ac0:	e09ff0ef          	jal	800018c8 <usertrapret>
}
    80001ac4:	60e2                	ld	ra,24(sp)
    80001ac6:	6442                	ld	s0,16(sp)
    80001ac8:	64a2                	ld	s1,8(sp)
    80001aca:	6902                	ld	s2,0(sp)
    80001acc:	6105                	addi	sp,sp,32
    80001ace:	8082                	ret
      exit(-1);
    80001ad0:	557d                	li	a0,-1
    80001ad2:	9c7ff0ef          	jal	80001498 <exit>
    80001ad6:	bf75                	j	80001a92 <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001ad8:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001adc:	5890                	lw	a2,48(s1)
    80001ade:	00007517          	auipc	a0,0x7
    80001ae2:	80250513          	addi	a0,a0,-2046 # 800082e0 <etext+0x2e0>
    80001ae6:	4e2040ef          	jal	80005fc8 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001aea:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001aee:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001af2:	00007517          	auipc	a0,0x7
    80001af6:	81e50513          	addi	a0,a0,-2018 # 80008310 <etext+0x310>
    80001afa:	4ce040ef          	jal	80005fc8 <printf>
    setkilled(p);
    80001afe:	8526                	mv	a0,s1
    80001b00:	aa5ff0ef          	jal	800015a4 <setkilled>
    80001b04:	b75d                	j	80001aaa <usertrap+0x76>
    yield();
    80001b06:	85bff0ef          	jal	80001360 <yield>
    80001b0a:	bf5d                	j	80001ac0 <usertrap+0x8c>

0000000080001b0c <kerneltrap>:
{
    80001b0c:	7179                	addi	sp,sp,-48
    80001b0e:	f406                	sd	ra,40(sp)
    80001b10:	f022                	sd	s0,32(sp)
    80001b12:	ec26                	sd	s1,24(sp)
    80001b14:	e84a                	sd	s2,16(sp)
    80001b16:	e44e                	sd	s3,8(sp)
    80001b18:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b1a:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b1e:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001b22:	142027f3          	csrr	a5,scause
    80001b26:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80001b28:	1004f793          	andi	a5,s1,256
    80001b2c:	c795                	beqz	a5,80001b58 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b2e:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001b32:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001b34:	eb85                	bnez	a5,80001b64 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80001b36:	e7bff0ef          	jal	800019b0 <devintr>
    80001b3a:	c91d                	beqz	a0,80001b70 <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80001b3c:	4789                	li	a5,2
    80001b3e:	04f50a63          	beq	a0,a5,80001b92 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001b42:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001b46:	10049073          	csrw	sstatus,s1
}
    80001b4a:	70a2                	ld	ra,40(sp)
    80001b4c:	7402                	ld	s0,32(sp)
    80001b4e:	64e2                	ld	s1,24(sp)
    80001b50:	6942                	ld	s2,16(sp)
    80001b52:	69a2                	ld	s3,8(sp)
    80001b54:	6145                	addi	sp,sp,48
    80001b56:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001b58:	00006517          	auipc	a0,0x6
    80001b5c:	7e050513          	addi	a0,a0,2016 # 80008338 <etext+0x338>
    80001b60:	778040ef          	jal	800062d8 <panic>
    panic("kerneltrap: interrupts enabled");
    80001b64:	00006517          	auipc	a0,0x6
    80001b68:	7fc50513          	addi	a0,a0,2044 # 80008360 <etext+0x360>
    80001b6c:	76c040ef          	jal	800062d8 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b70:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001b74:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001b78:	85ce                	mv	a1,s3
    80001b7a:	00007517          	auipc	a0,0x7
    80001b7e:	80650513          	addi	a0,a0,-2042 # 80008380 <etext+0x380>
    80001b82:	446040ef          	jal	80005fc8 <printf>
    panic("kerneltrap");
    80001b86:	00007517          	auipc	a0,0x7
    80001b8a:	82250513          	addi	a0,a0,-2014 # 800083a8 <etext+0x3a8>
    80001b8e:	74a040ef          	jal	800062d8 <panic>
  if(which_dev == 2 && myproc() != 0)
    80001b92:	a28ff0ef          	jal	80000dba <myproc>
    80001b96:	d555                	beqz	a0,80001b42 <kerneltrap+0x36>
    yield();
    80001b98:	fc8ff0ef          	jal	80001360 <yield>
    80001b9c:	b75d                	j	80001b42 <kerneltrap+0x36>

0000000080001b9e <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001b9e:	1101                	addi	sp,sp,-32
    80001ba0:	ec06                	sd	ra,24(sp)
    80001ba2:	e822                	sd	s0,16(sp)
    80001ba4:	e426                	sd	s1,8(sp)
    80001ba6:	1000                	addi	s0,sp,32
    80001ba8:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001baa:	a10ff0ef          	jal	80000dba <myproc>
  switch (n) {
    80001bae:	4795                	li	a5,5
    80001bb0:	0497e163          	bltu	a5,s1,80001bf2 <argraw+0x54>
    80001bb4:	048a                	slli	s1,s1,0x2
    80001bb6:	00007717          	auipc	a4,0x7
    80001bba:	cb270713          	addi	a4,a4,-846 # 80008868 <states.0+0x30>
    80001bbe:	94ba                	add	s1,s1,a4
    80001bc0:	409c                	lw	a5,0(s1)
    80001bc2:	97ba                	add	a5,a5,a4
    80001bc4:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001bc6:	6d3c                	ld	a5,88(a0)
    80001bc8:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001bca:	60e2                	ld	ra,24(sp)
    80001bcc:	6442                	ld	s0,16(sp)
    80001bce:	64a2                	ld	s1,8(sp)
    80001bd0:	6105                	addi	sp,sp,32
    80001bd2:	8082                	ret
    return p->trapframe->a1;
    80001bd4:	6d3c                	ld	a5,88(a0)
    80001bd6:	7fa8                	ld	a0,120(a5)
    80001bd8:	bfcd                	j	80001bca <argraw+0x2c>
    return p->trapframe->a2;
    80001bda:	6d3c                	ld	a5,88(a0)
    80001bdc:	63c8                	ld	a0,128(a5)
    80001bde:	b7f5                	j	80001bca <argraw+0x2c>
    return p->trapframe->a3;
    80001be0:	6d3c                	ld	a5,88(a0)
    80001be2:	67c8                	ld	a0,136(a5)
    80001be4:	b7dd                	j	80001bca <argraw+0x2c>
    return p->trapframe->a4;
    80001be6:	6d3c                	ld	a5,88(a0)
    80001be8:	6bc8                	ld	a0,144(a5)
    80001bea:	b7c5                	j	80001bca <argraw+0x2c>
    return p->trapframe->a5;
    80001bec:	6d3c                	ld	a5,88(a0)
    80001bee:	6fc8                	ld	a0,152(a5)
    80001bf0:	bfe9                	j	80001bca <argraw+0x2c>
  panic("argraw");
    80001bf2:	00006517          	auipc	a0,0x6
    80001bf6:	7c650513          	addi	a0,a0,1990 # 800083b8 <etext+0x3b8>
    80001bfa:	6de040ef          	jal	800062d8 <panic>

0000000080001bfe <fetchaddr>:
{
    80001bfe:	1101                	addi	sp,sp,-32
    80001c00:	ec06                	sd	ra,24(sp)
    80001c02:	e822                	sd	s0,16(sp)
    80001c04:	e426                	sd	s1,8(sp)
    80001c06:	e04a                	sd	s2,0(sp)
    80001c08:	1000                	addi	s0,sp,32
    80001c0a:	84aa                	mv	s1,a0
    80001c0c:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001c0e:	9acff0ef          	jal	80000dba <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001c12:	653c                	ld	a5,72(a0)
    80001c14:	02f4f663          	bgeu	s1,a5,80001c40 <fetchaddr+0x42>
    80001c18:	00848713          	addi	a4,s1,8
    80001c1c:	02e7e463          	bltu	a5,a4,80001c44 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001c20:	46a1                	li	a3,8
    80001c22:	8626                	mv	a2,s1
    80001c24:	85ca                	mv	a1,s2
    80001c26:	6928                	ld	a0,80(a0)
    80001c28:	ec7fe0ef          	jal	80000aee <copyin>
    80001c2c:	00a03533          	snez	a0,a0
    80001c30:	40a0053b          	negw	a0,a0
}
    80001c34:	60e2                	ld	ra,24(sp)
    80001c36:	6442                	ld	s0,16(sp)
    80001c38:	64a2                	ld	s1,8(sp)
    80001c3a:	6902                	ld	s2,0(sp)
    80001c3c:	6105                	addi	sp,sp,32
    80001c3e:	8082                	ret
    return -1;
    80001c40:	557d                	li	a0,-1
    80001c42:	bfcd                	j	80001c34 <fetchaddr+0x36>
    80001c44:	557d                	li	a0,-1
    80001c46:	b7fd                	j	80001c34 <fetchaddr+0x36>

0000000080001c48 <fetchstr>:
{
    80001c48:	7179                	addi	sp,sp,-48
    80001c4a:	f406                	sd	ra,40(sp)
    80001c4c:	f022                	sd	s0,32(sp)
    80001c4e:	ec26                	sd	s1,24(sp)
    80001c50:	e84a                	sd	s2,16(sp)
    80001c52:	e44e                	sd	s3,8(sp)
    80001c54:	1800                	addi	s0,sp,48
    80001c56:	89aa                	mv	s3,a0
    80001c58:	84ae                	mv	s1,a1
    80001c5a:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80001c5c:	95eff0ef          	jal	80000dba <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001c60:	86ca                	mv	a3,s2
    80001c62:	864e                	mv	a2,s3
    80001c64:	85a6                	mv	a1,s1
    80001c66:	6928                	ld	a0,80(a0)
    80001c68:	f0dfe0ef          	jal	80000b74 <copyinstr>
    80001c6c:	00054c63          	bltz	a0,80001c84 <fetchstr+0x3c>
  return strlen(buf);
    80001c70:	8526                	mv	a0,s1
    80001c72:	e76fe0ef          	jal	800002e8 <strlen>
}
    80001c76:	70a2                	ld	ra,40(sp)
    80001c78:	7402                	ld	s0,32(sp)
    80001c7a:	64e2                	ld	s1,24(sp)
    80001c7c:	6942                	ld	s2,16(sp)
    80001c7e:	69a2                	ld	s3,8(sp)
    80001c80:	6145                	addi	sp,sp,48
    80001c82:	8082                	ret
    return -1;
    80001c84:	557d                	li	a0,-1
    80001c86:	bfc5                	j	80001c76 <fetchstr+0x2e>

0000000080001c88 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001c88:	1101                	addi	sp,sp,-32
    80001c8a:	ec06                	sd	ra,24(sp)
    80001c8c:	e822                	sd	s0,16(sp)
    80001c8e:	e426                	sd	s1,8(sp)
    80001c90:	1000                	addi	s0,sp,32
    80001c92:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001c94:	f0bff0ef          	jal	80001b9e <argraw>
    80001c98:	c088                	sw	a0,0(s1)
}
    80001c9a:	60e2                	ld	ra,24(sp)
    80001c9c:	6442                	ld	s0,16(sp)
    80001c9e:	64a2                	ld	s1,8(sp)
    80001ca0:	6105                	addi	sp,sp,32
    80001ca2:	8082                	ret

0000000080001ca4 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001ca4:	1101                	addi	sp,sp,-32
    80001ca6:	ec06                	sd	ra,24(sp)
    80001ca8:	e822                	sd	s0,16(sp)
    80001caa:	e426                	sd	s1,8(sp)
    80001cac:	1000                	addi	s0,sp,32
    80001cae:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001cb0:	eefff0ef          	jal	80001b9e <argraw>
    80001cb4:	e088                	sd	a0,0(s1)
}
    80001cb6:	60e2                	ld	ra,24(sp)
    80001cb8:	6442                	ld	s0,16(sp)
    80001cba:	64a2                	ld	s1,8(sp)
    80001cbc:	6105                	addi	sp,sp,32
    80001cbe:	8082                	ret

0000000080001cc0 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001cc0:	1101                	addi	sp,sp,-32
    80001cc2:	ec06                	sd	ra,24(sp)
    80001cc4:	e822                	sd	s0,16(sp)
    80001cc6:	e426                	sd	s1,8(sp)
    80001cc8:	e04a                	sd	s2,0(sp)
    80001cca:	1000                	addi	s0,sp,32
    80001ccc:	892e                	mv	s2,a1
    80001cce:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80001cd0:	ecfff0ef          	jal	80001b9e <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80001cd4:	8626                	mv	a2,s1
    80001cd6:	85ca                	mv	a1,s2
    80001cd8:	f71ff0ef          	jal	80001c48 <fetchstr>
}
    80001cdc:	60e2                	ld	ra,24(sp)
    80001cde:	6442                	ld	s0,16(sp)
    80001ce0:	64a2                	ld	s1,8(sp)
    80001ce2:	6902                	ld	s2,0(sp)
    80001ce4:	6105                	addi	sp,sp,32
    80001ce6:	8082                	ret

0000000080001ce8 <syscall>:



void
syscall(void)
{
    80001ce8:	1101                	addi	sp,sp,-32
    80001cea:	ec06                	sd	ra,24(sp)
    80001cec:	e822                	sd	s0,16(sp)
    80001cee:	e426                	sd	s1,8(sp)
    80001cf0:	e04a                	sd	s2,0(sp)
    80001cf2:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001cf4:	8c6ff0ef          	jal	80000dba <myproc>
    80001cf8:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001cfa:	05853903          	ld	s2,88(a0)
    80001cfe:	0a893783          	ld	a5,168(s2)
    80001d02:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001d06:	37fd                	addiw	a5,a5,-1
    80001d08:	477d                	li	a4,31
    80001d0a:	00f76f63          	bltu	a4,a5,80001d28 <syscall+0x40>
    80001d0e:	00369713          	slli	a4,a3,0x3
    80001d12:	00007797          	auipc	a5,0x7
    80001d16:	b6e78793          	addi	a5,a5,-1170 # 80008880 <syscalls>
    80001d1a:	97ba                	add	a5,a5,a4
    80001d1c:	639c                	ld	a5,0(a5)
    80001d1e:	c789                	beqz	a5,80001d28 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001d20:	9782                	jalr	a5
    80001d22:	06a93823          	sd	a0,112(s2)
    80001d26:	a829                	j	80001d40 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001d28:	15848613          	addi	a2,s1,344
    80001d2c:	588c                	lw	a1,48(s1)
    80001d2e:	00006517          	auipc	a0,0x6
    80001d32:	69250513          	addi	a0,a0,1682 # 800083c0 <etext+0x3c0>
    80001d36:	292040ef          	jal	80005fc8 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001d3a:	6cbc                	ld	a5,88(s1)
    80001d3c:	577d                	li	a4,-1
    80001d3e:	fbb8                	sd	a4,112(a5)
  }
}
    80001d40:	60e2                	ld	ra,24(sp)
    80001d42:	6442                	ld	s0,16(sp)
    80001d44:	64a2                	ld	s1,8(sp)
    80001d46:	6902                	ld	s2,0(sp)
    80001d48:	6105                	addi	sp,sp,32
    80001d4a:	8082                	ret

0000000080001d4c <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001d4c:	1101                	addi	sp,sp,-32
    80001d4e:	ec06                	sd	ra,24(sp)
    80001d50:	e822                	sd	s0,16(sp)
    80001d52:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001d54:	fec40593          	addi	a1,s0,-20
    80001d58:	4501                	li	a0,0
    80001d5a:	f2fff0ef          	jal	80001c88 <argint>
  exit(n);
    80001d5e:	fec42503          	lw	a0,-20(s0)
    80001d62:	f36ff0ef          	jal	80001498 <exit>
  return 0;  // not reached
}
    80001d66:	4501                	li	a0,0
    80001d68:	60e2                	ld	ra,24(sp)
    80001d6a:	6442                	ld	s0,16(sp)
    80001d6c:	6105                	addi	sp,sp,32
    80001d6e:	8082                	ret

0000000080001d70 <sys_getpid>:

uint64
sys_getpid(void)
{
    80001d70:	1141                	addi	sp,sp,-16
    80001d72:	e406                	sd	ra,8(sp)
    80001d74:	e022                	sd	s0,0(sp)
    80001d76:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001d78:	842ff0ef          	jal	80000dba <myproc>
}
    80001d7c:	5908                	lw	a0,48(a0)
    80001d7e:	60a2                	ld	ra,8(sp)
    80001d80:	6402                	ld	s0,0(sp)
    80001d82:	0141                	addi	sp,sp,16
    80001d84:	8082                	ret

0000000080001d86 <sys_fork>:

uint64
sys_fork(void)
{
    80001d86:	1141                	addi	sp,sp,-16
    80001d88:	e406                	sd	ra,8(sp)
    80001d8a:	e022                	sd	s0,0(sp)
    80001d8c:	0800                	addi	s0,sp,16
  return fork();
    80001d8e:	b54ff0ef          	jal	800010e2 <fork>
}
    80001d92:	60a2                	ld	ra,8(sp)
    80001d94:	6402                	ld	s0,0(sp)
    80001d96:	0141                	addi	sp,sp,16
    80001d98:	8082                	ret

0000000080001d9a <sys_wait>:

uint64
sys_wait(void)
{
    80001d9a:	1101                	addi	sp,sp,-32
    80001d9c:	ec06                	sd	ra,24(sp)
    80001d9e:	e822                	sd	s0,16(sp)
    80001da0:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001da2:	fe840593          	addi	a1,s0,-24
    80001da6:	4501                	li	a0,0
    80001da8:	efdff0ef          	jal	80001ca4 <argaddr>
  return wait(p);
    80001dac:	fe843503          	ld	a0,-24(s0)
    80001db0:	843ff0ef          	jal	800015f2 <wait>
}
    80001db4:	60e2                	ld	ra,24(sp)
    80001db6:	6442                	ld	s0,16(sp)
    80001db8:	6105                	addi	sp,sp,32
    80001dba:	8082                	ret

0000000080001dbc <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001dbc:	7179                	addi	sp,sp,-48
    80001dbe:	f406                	sd	ra,40(sp)
    80001dc0:	f022                	sd	s0,32(sp)
    80001dc2:	ec26                	sd	s1,24(sp)
    80001dc4:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001dc6:	fdc40593          	addi	a1,s0,-36
    80001dca:	4501                	li	a0,0
    80001dcc:	ebdff0ef          	jal	80001c88 <argint>
  addr = myproc()->sz;
    80001dd0:	febfe0ef          	jal	80000dba <myproc>
    80001dd4:	653c                	ld	a5,72(a0)
    80001dd6:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80001dd8:	fdc42503          	lw	a0,-36(s0)
    80001ddc:	ab6ff0ef          	jal	80001092 <growproc>
    80001de0:	00054863          	bltz	a0,80001df0 <sys_sbrk+0x34>
    return -1;
  return addr;
}
    80001de4:	8526                	mv	a0,s1
    80001de6:	70a2                	ld	ra,40(sp)
    80001de8:	7402                	ld	s0,32(sp)
    80001dea:	64e2                	ld	s1,24(sp)
    80001dec:	6145                	addi	sp,sp,48
    80001dee:	8082                	ret
    return -1;
    80001df0:	57fd                	li	a5,-1
    80001df2:	84be                	mv	s1,a5
    80001df4:	bfc5                	j	80001de4 <sys_sbrk+0x28>

0000000080001df6 <sys_sleep>:

uint64
sys_sleep(void)
{
    80001df6:	7139                	addi	sp,sp,-64
    80001df8:	fc06                	sd	ra,56(sp)
    80001dfa:	f822                	sd	s0,48(sp)
    80001dfc:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80001dfe:	fcc40593          	addi	a1,s0,-52
    80001e02:	4501                	li	a0,0
    80001e04:	e85ff0ef          	jal	80001c88 <argint>
  if(n < 0)
    80001e08:	fcc42783          	lw	a5,-52(s0)
    80001e0c:	0607c863          	bltz	a5,80001e7c <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80001e10:	0000d517          	auipc	a0,0xd
    80001e14:	a9050513          	addi	a0,a0,-1392 # 8000e8a0 <tickslock>
    80001e18:	7fe040ef          	jal	80006616 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80001e1c:	fcc42783          	lw	a5,-52(s0)
    80001e20:	c3b9                	beqz	a5,80001e66 <sys_sleep+0x70>
    80001e22:	f426                	sd	s1,40(sp)
    80001e24:	f04a                	sd	s2,32(sp)
    80001e26:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80001e28:	00007997          	auipc	s3,0x7
    80001e2c:	bf09a983          	lw	s3,-1040(s3) # 80008a18 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80001e30:	0000d917          	auipc	s2,0xd
    80001e34:	a7090913          	addi	s2,s2,-1424 # 8000e8a0 <tickslock>
    80001e38:	00007497          	auipc	s1,0x7
    80001e3c:	be048493          	addi	s1,s1,-1056 # 80008a18 <ticks>
    if(killed(myproc())){
    80001e40:	f7bfe0ef          	jal	80000dba <myproc>
    80001e44:	f84ff0ef          	jal	800015c8 <killed>
    80001e48:	ed0d                	bnez	a0,80001e82 <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80001e4a:	85ca                	mv	a1,s2
    80001e4c:	8526                	mv	a0,s1
    80001e4e:	d3eff0ef          	jal	8000138c <sleep>
  while(ticks - ticks0 < n){
    80001e52:	409c                	lw	a5,0(s1)
    80001e54:	413787bb          	subw	a5,a5,s3
    80001e58:	fcc42703          	lw	a4,-52(s0)
    80001e5c:	fee7e2e3          	bltu	a5,a4,80001e40 <sys_sleep+0x4a>
    80001e60:	74a2                	ld	s1,40(sp)
    80001e62:	7902                	ld	s2,32(sp)
    80001e64:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80001e66:	0000d517          	auipc	a0,0xd
    80001e6a:	a3a50513          	addi	a0,a0,-1478 # 8000e8a0 <tickslock>
    80001e6e:	03d040ef          	jal	800066aa <release>
  return 0;
    80001e72:	4501                	li	a0,0
}
    80001e74:	70e2                	ld	ra,56(sp)
    80001e76:	7442                	ld	s0,48(sp)
    80001e78:	6121                	addi	sp,sp,64
    80001e7a:	8082                	ret
    n = 0;
    80001e7c:	fc042623          	sw	zero,-52(s0)
    80001e80:	bf41                	j	80001e10 <sys_sleep+0x1a>
      release(&tickslock);
    80001e82:	0000d517          	auipc	a0,0xd
    80001e86:	a1e50513          	addi	a0,a0,-1506 # 8000e8a0 <tickslock>
    80001e8a:	021040ef          	jal	800066aa <release>
      return -1;
    80001e8e:	557d                	li	a0,-1
    80001e90:	74a2                	ld	s1,40(sp)
    80001e92:	7902                	ld	s2,32(sp)
    80001e94:	69e2                	ld	s3,24(sp)
    80001e96:	bff9                	j	80001e74 <sys_sleep+0x7e>

0000000080001e98 <sys_kill>:

uint64
sys_kill(void)
{
    80001e98:	1101                	addi	sp,sp,-32
    80001e9a:	ec06                	sd	ra,24(sp)
    80001e9c:	e822                	sd	s0,16(sp)
    80001e9e:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80001ea0:	fec40593          	addi	a1,s0,-20
    80001ea4:	4501                	li	a0,0
    80001ea6:	de3ff0ef          	jal	80001c88 <argint>
  return kill(pid);
    80001eaa:	fec42503          	lw	a0,-20(s0)
    80001eae:	e90ff0ef          	jal	8000153e <kill>
}
    80001eb2:	60e2                	ld	ra,24(sp)
    80001eb4:	6442                	ld	s0,16(sp)
    80001eb6:	6105                	addi	sp,sp,32
    80001eb8:	8082                	ret

0000000080001eba <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80001eba:	1101                	addi	sp,sp,-32
    80001ebc:	ec06                	sd	ra,24(sp)
    80001ebe:	e822                	sd	s0,16(sp)
    80001ec0:	e426                	sd	s1,8(sp)
    80001ec2:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80001ec4:	0000d517          	auipc	a0,0xd
    80001ec8:	9dc50513          	addi	a0,a0,-1572 # 8000e8a0 <tickslock>
    80001ecc:	74a040ef          	jal	80006616 <acquire>
  xticks = ticks;
    80001ed0:	00007797          	auipc	a5,0x7
    80001ed4:	b487a783          	lw	a5,-1208(a5) # 80008a18 <ticks>
    80001ed8:	84be                	mv	s1,a5
  release(&tickslock);
    80001eda:	0000d517          	auipc	a0,0xd
    80001ede:	9c650513          	addi	a0,a0,-1594 # 8000e8a0 <tickslock>
    80001ee2:	7c8040ef          	jal	800066aa <release>
  return xticks;
}
    80001ee6:	02049513          	slli	a0,s1,0x20
    80001eea:	9101                	srli	a0,a0,0x20
    80001eec:	60e2                	ld	ra,24(sp)
    80001eee:	6442                	ld	s0,16(sp)
    80001ef0:	64a2                	ld	s1,8(sp)
    80001ef2:	6105                	addi	sp,sp,32
    80001ef4:	8082                	ret

0000000080001ef6 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80001ef6:	7179                	addi	sp,sp,-48
    80001ef8:	f406                	sd	ra,40(sp)
    80001efa:	f022                	sd	s0,32(sp)
    80001efc:	ec26                	sd	s1,24(sp)
    80001efe:	e84a                	sd	s2,16(sp)
    80001f00:	e44e                	sd	s3,8(sp)
    80001f02:	e052                	sd	s4,0(sp)
    80001f04:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80001f06:	00006597          	auipc	a1,0x6
    80001f0a:	4da58593          	addi	a1,a1,1242 # 800083e0 <etext+0x3e0>
    80001f0e:	0000d517          	auipc	a0,0xd
    80001f12:	9aa50513          	addi	a0,a0,-1622 # 8000e8b8 <bcache>
    80001f16:	676040ef          	jal	8000658c <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80001f1a:	00015797          	auipc	a5,0x15
    80001f1e:	99e78793          	addi	a5,a5,-1634 # 800168b8 <bcache+0x8000>
    80001f22:	00015717          	auipc	a4,0x15
    80001f26:	bfe70713          	addi	a4,a4,-1026 # 80016b20 <bcache+0x8268>
    80001f2a:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80001f2e:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80001f32:	0000d497          	auipc	s1,0xd
    80001f36:	99e48493          	addi	s1,s1,-1634 # 8000e8d0 <bcache+0x18>
    b->next = bcache.head.next;
    80001f3a:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80001f3c:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80001f3e:	00006a17          	auipc	s4,0x6
    80001f42:	4aaa0a13          	addi	s4,s4,1194 # 800083e8 <etext+0x3e8>
    b->next = bcache.head.next;
    80001f46:	2b893783          	ld	a5,696(s2)
    80001f4a:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80001f4c:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80001f50:	85d2                	mv	a1,s4
    80001f52:	01048513          	addi	a0,s1,16
    80001f56:	24c010ef          	jal	800031a2 <initsleeplock>
    bcache.head.next->prev = b;
    80001f5a:	2b893783          	ld	a5,696(s2)
    80001f5e:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80001f60:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80001f64:	45848493          	addi	s1,s1,1112
    80001f68:	fd349fe3          	bne	s1,s3,80001f46 <binit+0x50>
  }
}
    80001f6c:	70a2                	ld	ra,40(sp)
    80001f6e:	7402                	ld	s0,32(sp)
    80001f70:	64e2                	ld	s1,24(sp)
    80001f72:	6942                	ld	s2,16(sp)
    80001f74:	69a2                	ld	s3,8(sp)
    80001f76:	6a02                	ld	s4,0(sp)
    80001f78:	6145                	addi	sp,sp,48
    80001f7a:	8082                	ret

0000000080001f7c <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80001f7c:	7179                	addi	sp,sp,-48
    80001f7e:	f406                	sd	ra,40(sp)
    80001f80:	f022                	sd	s0,32(sp)
    80001f82:	ec26                	sd	s1,24(sp)
    80001f84:	e84a                	sd	s2,16(sp)
    80001f86:	e44e                	sd	s3,8(sp)
    80001f88:	1800                	addi	s0,sp,48
    80001f8a:	892a                	mv	s2,a0
    80001f8c:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80001f8e:	0000d517          	auipc	a0,0xd
    80001f92:	92a50513          	addi	a0,a0,-1750 # 8000e8b8 <bcache>
    80001f96:	680040ef          	jal	80006616 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80001f9a:	00015497          	auipc	s1,0x15
    80001f9e:	bd64b483          	ld	s1,-1066(s1) # 80016b70 <bcache+0x82b8>
    80001fa2:	00015797          	auipc	a5,0x15
    80001fa6:	b7e78793          	addi	a5,a5,-1154 # 80016b20 <bcache+0x8268>
    80001faa:	02f48b63          	beq	s1,a5,80001fe0 <bread+0x64>
    80001fae:	873e                	mv	a4,a5
    80001fb0:	a021                	j	80001fb8 <bread+0x3c>
    80001fb2:	68a4                	ld	s1,80(s1)
    80001fb4:	02e48663          	beq	s1,a4,80001fe0 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80001fb8:	449c                	lw	a5,8(s1)
    80001fba:	ff279ce3          	bne	a5,s2,80001fb2 <bread+0x36>
    80001fbe:	44dc                	lw	a5,12(s1)
    80001fc0:	ff3799e3          	bne	a5,s3,80001fb2 <bread+0x36>
      b->refcnt++;
    80001fc4:	40bc                	lw	a5,64(s1)
    80001fc6:	2785                	addiw	a5,a5,1
    80001fc8:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80001fca:	0000d517          	auipc	a0,0xd
    80001fce:	8ee50513          	addi	a0,a0,-1810 # 8000e8b8 <bcache>
    80001fd2:	6d8040ef          	jal	800066aa <release>
      acquiresleep(&b->lock);
    80001fd6:	01048513          	addi	a0,s1,16
    80001fda:	1fe010ef          	jal	800031d8 <acquiresleep>
      return b;
    80001fde:	a889                	j	80002030 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80001fe0:	00015497          	auipc	s1,0x15
    80001fe4:	b884b483          	ld	s1,-1144(s1) # 80016b68 <bcache+0x82b0>
    80001fe8:	00015797          	auipc	a5,0x15
    80001fec:	b3878793          	addi	a5,a5,-1224 # 80016b20 <bcache+0x8268>
    80001ff0:	00f48863          	beq	s1,a5,80002000 <bread+0x84>
    80001ff4:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80001ff6:	40bc                	lw	a5,64(s1)
    80001ff8:	cb91                	beqz	a5,8000200c <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80001ffa:	64a4                	ld	s1,72(s1)
    80001ffc:	fee49de3          	bne	s1,a4,80001ff6 <bread+0x7a>
  panic("bget: no buffers");
    80002000:	00006517          	auipc	a0,0x6
    80002004:	3f050513          	addi	a0,a0,1008 # 800083f0 <etext+0x3f0>
    80002008:	2d0040ef          	jal	800062d8 <panic>
      b->dev = dev;
    8000200c:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002010:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002014:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002018:	4785                	li	a5,1
    8000201a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    8000201c:	0000d517          	auipc	a0,0xd
    80002020:	89c50513          	addi	a0,a0,-1892 # 8000e8b8 <bcache>
    80002024:	686040ef          	jal	800066aa <release>
      acquiresleep(&b->lock);
    80002028:	01048513          	addi	a0,s1,16
    8000202c:	1ac010ef          	jal	800031d8 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002030:	409c                	lw	a5,0(s1)
    80002032:	cb89                	beqz	a5,80002044 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002034:	8526                	mv	a0,s1
    80002036:	70a2                	ld	ra,40(sp)
    80002038:	7402                	ld	s0,32(sp)
    8000203a:	64e2                	ld	s1,24(sp)
    8000203c:	6942                	ld	s2,16(sp)
    8000203e:	69a2                	ld	s3,8(sp)
    80002040:	6145                	addi	sp,sp,48
    80002042:	8082                	ret
    virtio_disk_rw(b, 0);
    80002044:	4581                	li	a1,0
    80002046:	8526                	mv	a0,s1
    80002048:	221020ef          	jal	80004a68 <virtio_disk_rw>
    b->valid = 1;
    8000204c:	4785                	li	a5,1
    8000204e:	c09c                	sw	a5,0(s1)
  return b;
    80002050:	b7d5                	j	80002034 <bread+0xb8>

0000000080002052 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002052:	1101                	addi	sp,sp,-32
    80002054:	ec06                	sd	ra,24(sp)
    80002056:	e822                	sd	s0,16(sp)
    80002058:	e426                	sd	s1,8(sp)
    8000205a:	1000                	addi	s0,sp,32
    8000205c:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000205e:	0541                	addi	a0,a0,16
    80002060:	1f6010ef          	jal	80003256 <holdingsleep>
    80002064:	c911                	beqz	a0,80002078 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002066:	4585                	li	a1,1
    80002068:	8526                	mv	a0,s1
    8000206a:	1ff020ef          	jal	80004a68 <virtio_disk_rw>
}
    8000206e:	60e2                	ld	ra,24(sp)
    80002070:	6442                	ld	s0,16(sp)
    80002072:	64a2                	ld	s1,8(sp)
    80002074:	6105                	addi	sp,sp,32
    80002076:	8082                	ret
    panic("bwrite");
    80002078:	00006517          	auipc	a0,0x6
    8000207c:	39050513          	addi	a0,a0,912 # 80008408 <etext+0x408>
    80002080:	258040ef          	jal	800062d8 <panic>

0000000080002084 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002084:	1101                	addi	sp,sp,-32
    80002086:	ec06                	sd	ra,24(sp)
    80002088:	e822                	sd	s0,16(sp)
    8000208a:	e426                	sd	s1,8(sp)
    8000208c:	e04a                	sd	s2,0(sp)
    8000208e:	1000                	addi	s0,sp,32
    80002090:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002092:	01050913          	addi	s2,a0,16
    80002096:	854a                	mv	a0,s2
    80002098:	1be010ef          	jal	80003256 <holdingsleep>
    8000209c:	c125                	beqz	a0,800020fc <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    8000209e:	854a                	mv	a0,s2
    800020a0:	17e010ef          	jal	8000321e <releasesleep>

  acquire(&bcache.lock);
    800020a4:	0000d517          	auipc	a0,0xd
    800020a8:	81450513          	addi	a0,a0,-2028 # 8000e8b8 <bcache>
    800020ac:	56a040ef          	jal	80006616 <acquire>
  b->refcnt--;
    800020b0:	40bc                	lw	a5,64(s1)
    800020b2:	37fd                	addiw	a5,a5,-1
    800020b4:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800020b6:	e79d                	bnez	a5,800020e4 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800020b8:	68b8                	ld	a4,80(s1)
    800020ba:	64bc                	ld	a5,72(s1)
    800020bc:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    800020be:	68b8                	ld	a4,80(s1)
    800020c0:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800020c2:	00014797          	auipc	a5,0x14
    800020c6:	7f678793          	addi	a5,a5,2038 # 800168b8 <bcache+0x8000>
    800020ca:	2b87b703          	ld	a4,696(a5)
    800020ce:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800020d0:	00015717          	auipc	a4,0x15
    800020d4:	a5070713          	addi	a4,a4,-1456 # 80016b20 <bcache+0x8268>
    800020d8:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800020da:	2b87b703          	ld	a4,696(a5)
    800020de:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800020e0:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800020e4:	0000c517          	auipc	a0,0xc
    800020e8:	7d450513          	addi	a0,a0,2004 # 8000e8b8 <bcache>
    800020ec:	5be040ef          	jal	800066aa <release>
}
    800020f0:	60e2                	ld	ra,24(sp)
    800020f2:	6442                	ld	s0,16(sp)
    800020f4:	64a2                	ld	s1,8(sp)
    800020f6:	6902                	ld	s2,0(sp)
    800020f8:	6105                	addi	sp,sp,32
    800020fa:	8082                	ret
    panic("brelse");
    800020fc:	00006517          	auipc	a0,0x6
    80002100:	31450513          	addi	a0,a0,788 # 80008410 <etext+0x410>
    80002104:	1d4040ef          	jal	800062d8 <panic>

0000000080002108 <bpin>:

void
bpin(struct buf *b) {
    80002108:	1101                	addi	sp,sp,-32
    8000210a:	ec06                	sd	ra,24(sp)
    8000210c:	e822                	sd	s0,16(sp)
    8000210e:	e426                	sd	s1,8(sp)
    80002110:	1000                	addi	s0,sp,32
    80002112:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002114:	0000c517          	auipc	a0,0xc
    80002118:	7a450513          	addi	a0,a0,1956 # 8000e8b8 <bcache>
    8000211c:	4fa040ef          	jal	80006616 <acquire>
  b->refcnt++;
    80002120:	40bc                	lw	a5,64(s1)
    80002122:	2785                	addiw	a5,a5,1
    80002124:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002126:	0000c517          	auipc	a0,0xc
    8000212a:	79250513          	addi	a0,a0,1938 # 8000e8b8 <bcache>
    8000212e:	57c040ef          	jal	800066aa <release>
}
    80002132:	60e2                	ld	ra,24(sp)
    80002134:	6442                	ld	s0,16(sp)
    80002136:	64a2                	ld	s1,8(sp)
    80002138:	6105                	addi	sp,sp,32
    8000213a:	8082                	ret

000000008000213c <bunpin>:

void
bunpin(struct buf *b) {
    8000213c:	1101                	addi	sp,sp,-32
    8000213e:	ec06                	sd	ra,24(sp)
    80002140:	e822                	sd	s0,16(sp)
    80002142:	e426                	sd	s1,8(sp)
    80002144:	1000                	addi	s0,sp,32
    80002146:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002148:	0000c517          	auipc	a0,0xc
    8000214c:	77050513          	addi	a0,a0,1904 # 8000e8b8 <bcache>
    80002150:	4c6040ef          	jal	80006616 <acquire>
  b->refcnt--;
    80002154:	40bc                	lw	a5,64(s1)
    80002156:	37fd                	addiw	a5,a5,-1
    80002158:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000215a:	0000c517          	auipc	a0,0xc
    8000215e:	75e50513          	addi	a0,a0,1886 # 8000e8b8 <bcache>
    80002162:	548040ef          	jal	800066aa <release>
}
    80002166:	60e2                	ld	ra,24(sp)
    80002168:	6442                	ld	s0,16(sp)
    8000216a:	64a2                	ld	s1,8(sp)
    8000216c:	6105                	addi	sp,sp,32
    8000216e:	8082                	ret

0000000080002170 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002170:	1101                	addi	sp,sp,-32
    80002172:	ec06                	sd	ra,24(sp)
    80002174:	e822                	sd	s0,16(sp)
    80002176:	e426                	sd	s1,8(sp)
    80002178:	e04a                	sd	s2,0(sp)
    8000217a:	1000                	addi	s0,sp,32
    8000217c:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000217e:	00d5d79b          	srliw	a5,a1,0xd
    80002182:	00015597          	auipc	a1,0x15
    80002186:	e125a583          	lw	a1,-494(a1) # 80016f94 <sb+0x1c>
    8000218a:	9dbd                	addw	a1,a1,a5
    8000218c:	df1ff0ef          	jal	80001f7c <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002190:	0074f713          	andi	a4,s1,7
    80002194:	4785                	li	a5,1
    80002196:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    8000219a:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    8000219c:	90d9                	srli	s1,s1,0x36
    8000219e:	00950733          	add	a4,a0,s1
    800021a2:	05874703          	lbu	a4,88(a4)
    800021a6:	00e7f6b3          	and	a3,a5,a4
    800021aa:	c29d                	beqz	a3,800021d0 <bfree+0x60>
    800021ac:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800021ae:	94aa                	add	s1,s1,a0
    800021b0:	fff7c793          	not	a5,a5
    800021b4:	8f7d                	and	a4,a4,a5
    800021b6:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    800021ba:	717000ef          	jal	800030d0 <log_write>
  brelse(bp);
    800021be:	854a                	mv	a0,s2
    800021c0:	ec5ff0ef          	jal	80002084 <brelse>
}
    800021c4:	60e2                	ld	ra,24(sp)
    800021c6:	6442                	ld	s0,16(sp)
    800021c8:	64a2                	ld	s1,8(sp)
    800021ca:	6902                	ld	s2,0(sp)
    800021cc:	6105                	addi	sp,sp,32
    800021ce:	8082                	ret
    panic("freeing free block");
    800021d0:	00006517          	auipc	a0,0x6
    800021d4:	24850513          	addi	a0,a0,584 # 80008418 <etext+0x418>
    800021d8:	100040ef          	jal	800062d8 <panic>

00000000800021dc <balloc>:
{
    800021dc:	715d                	addi	sp,sp,-80
    800021de:	e486                	sd	ra,72(sp)
    800021e0:	e0a2                	sd	s0,64(sp)
    800021e2:	fc26                	sd	s1,56(sp)
    800021e4:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    800021e6:	00015797          	auipc	a5,0x15
    800021ea:	d967a783          	lw	a5,-618(a5) # 80016f7c <sb+0x4>
    800021ee:	0e078263          	beqz	a5,800022d2 <balloc+0xf6>
    800021f2:	f84a                	sd	s2,48(sp)
    800021f4:	f44e                	sd	s3,40(sp)
    800021f6:	f052                	sd	s4,32(sp)
    800021f8:	ec56                	sd	s5,24(sp)
    800021fa:	e85a                	sd	s6,16(sp)
    800021fc:	e45e                	sd	s7,8(sp)
    800021fe:	e062                	sd	s8,0(sp)
    80002200:	8baa                	mv	s7,a0
    80002202:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002204:	00015b17          	auipc	s6,0x15
    80002208:	d74b0b13          	addi	s6,s6,-652 # 80016f78 <sb>
      m = 1 << (bi % 8);
    8000220c:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000220e:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002210:	6c09                	lui	s8,0x2
    80002212:	a09d                	j	80002278 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002214:	97ca                	add	a5,a5,s2
    80002216:	8e55                	or	a2,a2,a3
    80002218:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    8000221c:	854a                	mv	a0,s2
    8000221e:	6b3000ef          	jal	800030d0 <log_write>
        brelse(bp);
    80002222:	854a                	mv	a0,s2
    80002224:	e61ff0ef          	jal	80002084 <brelse>
  bp = bread(dev, bno);
    80002228:	85a6                	mv	a1,s1
    8000222a:	855e                	mv	a0,s7
    8000222c:	d51ff0ef          	jal	80001f7c <bread>
    80002230:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002232:	40000613          	li	a2,1024
    80002236:	4581                	li	a1,0
    80002238:	05850513          	addi	a0,a0,88
    8000223c:	f23fd0ef          	jal	8000015e <memset>
  log_write(bp);
    80002240:	854a                	mv	a0,s2
    80002242:	68f000ef          	jal	800030d0 <log_write>
  brelse(bp);
    80002246:	854a                	mv	a0,s2
    80002248:	e3dff0ef          	jal	80002084 <brelse>
}
    8000224c:	7942                	ld	s2,48(sp)
    8000224e:	79a2                	ld	s3,40(sp)
    80002250:	7a02                	ld	s4,32(sp)
    80002252:	6ae2                	ld	s5,24(sp)
    80002254:	6b42                	ld	s6,16(sp)
    80002256:	6ba2                	ld	s7,8(sp)
    80002258:	6c02                	ld	s8,0(sp)
}
    8000225a:	8526                	mv	a0,s1
    8000225c:	60a6                	ld	ra,72(sp)
    8000225e:	6406                	ld	s0,64(sp)
    80002260:	74e2                	ld	s1,56(sp)
    80002262:	6161                	addi	sp,sp,80
    80002264:	8082                	ret
    brelse(bp);
    80002266:	854a                	mv	a0,s2
    80002268:	e1dff0ef          	jal	80002084 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    8000226c:	015c0abb          	addw	s5,s8,s5
    80002270:	004b2783          	lw	a5,4(s6)
    80002274:	04faf863          	bgeu	s5,a5,800022c4 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002278:	40dad59b          	sraiw	a1,s5,0xd
    8000227c:	01cb2783          	lw	a5,28(s6)
    80002280:	9dbd                	addw	a1,a1,a5
    80002282:	855e                	mv	a0,s7
    80002284:	cf9ff0ef          	jal	80001f7c <bread>
    80002288:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000228a:	004b2503          	lw	a0,4(s6)
    8000228e:	84d6                	mv	s1,s5
    80002290:	4701                	li	a4,0
    80002292:	fca4fae3          	bgeu	s1,a0,80002266 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002296:	00777693          	andi	a3,a4,7
    8000229a:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    8000229e:	41f7579b          	sraiw	a5,a4,0x1f
    800022a2:	01d7d79b          	srliw	a5,a5,0x1d
    800022a6:	9fb9                	addw	a5,a5,a4
    800022a8:	4037d79b          	sraiw	a5,a5,0x3
    800022ac:	00f90633          	add	a2,s2,a5
    800022b0:	05864603          	lbu	a2,88(a2)
    800022b4:	00c6f5b3          	and	a1,a3,a2
    800022b8:	ddb1                	beqz	a1,80002214 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800022ba:	2705                	addiw	a4,a4,1
    800022bc:	2485                	addiw	s1,s1,1
    800022be:	fd471ae3          	bne	a4,s4,80002292 <balloc+0xb6>
    800022c2:	b755                	j	80002266 <balloc+0x8a>
    800022c4:	7942                	ld	s2,48(sp)
    800022c6:	79a2                	ld	s3,40(sp)
    800022c8:	7a02                	ld	s4,32(sp)
    800022ca:	6ae2                	ld	s5,24(sp)
    800022cc:	6b42                	ld	s6,16(sp)
    800022ce:	6ba2                	ld	s7,8(sp)
    800022d0:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    800022d2:	00006517          	auipc	a0,0x6
    800022d6:	15e50513          	addi	a0,a0,350 # 80008430 <etext+0x430>
    800022da:	4ef030ef          	jal	80005fc8 <printf>
  return 0;
    800022de:	4481                	li	s1,0
    800022e0:	bfad                	j	8000225a <balloc+0x7e>

00000000800022e2 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800022e2:	7179                	addi	sp,sp,-48
    800022e4:	f406                	sd	ra,40(sp)
    800022e6:	f022                	sd	s0,32(sp)
    800022e8:	ec26                	sd	s1,24(sp)
    800022ea:	e84a                	sd	s2,16(sp)
    800022ec:	e44e                	sd	s3,8(sp)
    800022ee:	1800                	addi	s0,sp,48
    800022f0:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800022f2:	47ad                	li	a5,11
    800022f4:	02b7e363          	bltu	a5,a1,8000231a <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    800022f8:	02059793          	slli	a5,a1,0x20
    800022fc:	01e7d593          	srli	a1,a5,0x1e
    80002300:	00b509b3          	add	s3,a0,a1
    80002304:	0509a483          	lw	s1,80(s3)
    80002308:	e0b5                	bnez	s1,8000236c <bmap+0x8a>
      addr = balloc(ip->dev);
    8000230a:	4108                	lw	a0,0(a0)
    8000230c:	ed1ff0ef          	jal	800021dc <balloc>
    80002310:	84aa                	mv	s1,a0
      if(addr == 0)
    80002312:	cd29                	beqz	a0,8000236c <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002314:	04a9a823          	sw	a0,80(s3)
    80002318:	a891                	j	8000236c <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    8000231a:	ff45879b          	addiw	a5,a1,-12
    8000231e:	873e                	mv	a4,a5
    80002320:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80002322:	0ff00793          	li	a5,255
    80002326:	06e7e763          	bltu	a5,a4,80002394 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000232a:	08052483          	lw	s1,128(a0)
    8000232e:	e891                	bnez	s1,80002342 <bmap+0x60>
      addr = balloc(ip->dev);
    80002330:	4108                	lw	a0,0(a0)
    80002332:	eabff0ef          	jal	800021dc <balloc>
    80002336:	84aa                	mv	s1,a0
      if(addr == 0)
    80002338:	c915                	beqz	a0,8000236c <bmap+0x8a>
    8000233a:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000233c:	08a92023          	sw	a0,128(s2)
    80002340:	a011                	j	80002344 <bmap+0x62>
    80002342:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002344:	85a6                	mv	a1,s1
    80002346:	00092503          	lw	a0,0(s2)
    8000234a:	c33ff0ef          	jal	80001f7c <bread>
    8000234e:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002350:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002354:	02099713          	slli	a4,s3,0x20
    80002358:	01e75593          	srli	a1,a4,0x1e
    8000235c:	97ae                	add	a5,a5,a1
    8000235e:	89be                	mv	s3,a5
    80002360:	4384                	lw	s1,0(a5)
    80002362:	cc89                	beqz	s1,8000237c <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002364:	8552                	mv	a0,s4
    80002366:	d1fff0ef          	jal	80002084 <brelse>
    return addr;
    8000236a:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000236c:	8526                	mv	a0,s1
    8000236e:	70a2                	ld	ra,40(sp)
    80002370:	7402                	ld	s0,32(sp)
    80002372:	64e2                	ld	s1,24(sp)
    80002374:	6942                	ld	s2,16(sp)
    80002376:	69a2                	ld	s3,8(sp)
    80002378:	6145                	addi	sp,sp,48
    8000237a:	8082                	ret
      addr = balloc(ip->dev);
    8000237c:	00092503          	lw	a0,0(s2)
    80002380:	e5dff0ef          	jal	800021dc <balloc>
    80002384:	84aa                	mv	s1,a0
      if(addr){
    80002386:	dd79                	beqz	a0,80002364 <bmap+0x82>
        a[bn] = addr;
    80002388:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    8000238c:	8552                	mv	a0,s4
    8000238e:	543000ef          	jal	800030d0 <log_write>
    80002392:	bfc9                	j	80002364 <bmap+0x82>
    80002394:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80002396:	00006517          	auipc	a0,0x6
    8000239a:	0b250513          	addi	a0,a0,178 # 80008448 <etext+0x448>
    8000239e:	73b030ef          	jal	800062d8 <panic>

00000000800023a2 <iget>:
{
    800023a2:	7179                	addi	sp,sp,-48
    800023a4:	f406                	sd	ra,40(sp)
    800023a6:	f022                	sd	s0,32(sp)
    800023a8:	ec26                	sd	s1,24(sp)
    800023aa:	e84a                	sd	s2,16(sp)
    800023ac:	e44e                	sd	s3,8(sp)
    800023ae:	e052                	sd	s4,0(sp)
    800023b0:	1800                	addi	s0,sp,48
    800023b2:	892a                	mv	s2,a0
    800023b4:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800023b6:	00015517          	auipc	a0,0x15
    800023ba:	be250513          	addi	a0,a0,-1054 # 80016f98 <itable>
    800023be:	258040ef          	jal	80006616 <acquire>
  empty = 0;
    800023c2:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800023c4:	00015497          	auipc	s1,0x15
    800023c8:	bec48493          	addi	s1,s1,-1044 # 80016fb0 <itable+0x18>
    800023cc:	00016697          	auipc	a3,0x16
    800023d0:	67468693          	addi	a3,a3,1652 # 80018a40 <log>
    800023d4:	a809                	j	800023e6 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800023d6:	e781                	bnez	a5,800023de <iget+0x3c>
    800023d8:	00099363          	bnez	s3,800023de <iget+0x3c>
      empty = ip;
    800023dc:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800023de:	08848493          	addi	s1,s1,136
    800023e2:	02d48563          	beq	s1,a3,8000240c <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800023e6:	449c                	lw	a5,8(s1)
    800023e8:	fef057e3          	blez	a5,800023d6 <iget+0x34>
    800023ec:	4098                	lw	a4,0(s1)
    800023ee:	ff2718e3          	bne	a4,s2,800023de <iget+0x3c>
    800023f2:	40d8                	lw	a4,4(s1)
    800023f4:	ff4715e3          	bne	a4,s4,800023de <iget+0x3c>
      ip->ref++;
    800023f8:	2785                	addiw	a5,a5,1
    800023fa:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800023fc:	00015517          	auipc	a0,0x15
    80002400:	b9c50513          	addi	a0,a0,-1124 # 80016f98 <itable>
    80002404:	2a6040ef          	jal	800066aa <release>
      return ip;
    80002408:	89a6                	mv	s3,s1
    8000240a:	a015                	j	8000242e <iget+0x8c>
  if(empty == 0)
    8000240c:	02098a63          	beqz	s3,80002440 <iget+0x9e>
  ip->dev = dev;
    80002410:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    80002414:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80002418:	4785                	li	a5,1
    8000241a:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    8000241e:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    80002422:	00015517          	auipc	a0,0x15
    80002426:	b7650513          	addi	a0,a0,-1162 # 80016f98 <itable>
    8000242a:	280040ef          	jal	800066aa <release>
}
    8000242e:	854e                	mv	a0,s3
    80002430:	70a2                	ld	ra,40(sp)
    80002432:	7402                	ld	s0,32(sp)
    80002434:	64e2                	ld	s1,24(sp)
    80002436:	6942                	ld	s2,16(sp)
    80002438:	69a2                	ld	s3,8(sp)
    8000243a:	6a02                	ld	s4,0(sp)
    8000243c:	6145                	addi	sp,sp,48
    8000243e:	8082                	ret
    panic("iget: no inodes");
    80002440:	00006517          	auipc	a0,0x6
    80002444:	02050513          	addi	a0,a0,32 # 80008460 <etext+0x460>
    80002448:	691030ef          	jal	800062d8 <panic>

000000008000244c <fsinit>:
fsinit(int dev) {
    8000244c:	1101                	addi	sp,sp,-32
    8000244e:	ec06                	sd	ra,24(sp)
    80002450:	e822                	sd	s0,16(sp)
    80002452:	e426                	sd	s1,8(sp)
    80002454:	e04a                	sd	s2,0(sp)
    80002456:	1000                	addi	s0,sp,32
    80002458:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    8000245a:	4585                	li	a1,1
    8000245c:	b21ff0ef          	jal	80001f7c <bread>
    80002460:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002462:	02000613          	li	a2,32
    80002466:	05850593          	addi	a1,a0,88
    8000246a:	00015517          	auipc	a0,0x15
    8000246e:	b0e50513          	addi	a0,a0,-1266 # 80016f78 <sb>
    80002472:	d4dfd0ef          	jal	800001be <memmove>
  brelse(bp);
    80002476:	8526                	mv	a0,s1
    80002478:	c0dff0ef          	jal	80002084 <brelse>
  if(sb.magic != FSMAGIC)
    8000247c:	00015717          	auipc	a4,0x15
    80002480:	afc72703          	lw	a4,-1284(a4) # 80016f78 <sb>
    80002484:	102037b7          	lui	a5,0x10203
    80002488:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000248c:	00f71f63          	bne	a4,a5,800024aa <fsinit+0x5e>
  initlog(dev, &sb);
    80002490:	00015597          	auipc	a1,0x15
    80002494:	ae858593          	addi	a1,a1,-1304 # 80016f78 <sb>
    80002498:	854a                	mv	a0,s2
    8000249a:	219000ef          	jal	80002eb2 <initlog>
}
    8000249e:	60e2                	ld	ra,24(sp)
    800024a0:	6442                	ld	s0,16(sp)
    800024a2:	64a2                	ld	s1,8(sp)
    800024a4:	6902                	ld	s2,0(sp)
    800024a6:	6105                	addi	sp,sp,32
    800024a8:	8082                	ret
    panic("invalid file system");
    800024aa:	00006517          	auipc	a0,0x6
    800024ae:	fc650513          	addi	a0,a0,-58 # 80008470 <etext+0x470>
    800024b2:	627030ef          	jal	800062d8 <panic>

00000000800024b6 <iinit>:
{
    800024b6:	7179                	addi	sp,sp,-48
    800024b8:	f406                	sd	ra,40(sp)
    800024ba:	f022                	sd	s0,32(sp)
    800024bc:	ec26                	sd	s1,24(sp)
    800024be:	e84a                	sd	s2,16(sp)
    800024c0:	e44e                	sd	s3,8(sp)
    800024c2:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800024c4:	00006597          	auipc	a1,0x6
    800024c8:	fc458593          	addi	a1,a1,-60 # 80008488 <etext+0x488>
    800024cc:	00015517          	auipc	a0,0x15
    800024d0:	acc50513          	addi	a0,a0,-1332 # 80016f98 <itable>
    800024d4:	0b8040ef          	jal	8000658c <initlock>
  for(i = 0; i < NINODE; i++) {
    800024d8:	00015497          	auipc	s1,0x15
    800024dc:	ae848493          	addi	s1,s1,-1304 # 80016fc0 <itable+0x28>
    800024e0:	00016997          	auipc	s3,0x16
    800024e4:	57098993          	addi	s3,s3,1392 # 80018a50 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800024e8:	00006917          	auipc	s2,0x6
    800024ec:	fa890913          	addi	s2,s2,-88 # 80008490 <etext+0x490>
    800024f0:	85ca                	mv	a1,s2
    800024f2:	8526                	mv	a0,s1
    800024f4:	4af000ef          	jal	800031a2 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800024f8:	08848493          	addi	s1,s1,136
    800024fc:	ff349ae3          	bne	s1,s3,800024f0 <iinit+0x3a>
}
    80002500:	70a2                	ld	ra,40(sp)
    80002502:	7402                	ld	s0,32(sp)
    80002504:	64e2                	ld	s1,24(sp)
    80002506:	6942                	ld	s2,16(sp)
    80002508:	69a2                	ld	s3,8(sp)
    8000250a:	6145                	addi	sp,sp,48
    8000250c:	8082                	ret

000000008000250e <ialloc>:
{
    8000250e:	7139                	addi	sp,sp,-64
    80002510:	fc06                	sd	ra,56(sp)
    80002512:	f822                	sd	s0,48(sp)
    80002514:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80002516:	00015717          	auipc	a4,0x15
    8000251a:	a6e72703          	lw	a4,-1426(a4) # 80016f84 <sb+0xc>
    8000251e:	4785                	li	a5,1
    80002520:	06e7f063          	bgeu	a5,a4,80002580 <ialloc+0x72>
    80002524:	f426                	sd	s1,40(sp)
    80002526:	f04a                	sd	s2,32(sp)
    80002528:	ec4e                	sd	s3,24(sp)
    8000252a:	e852                	sd	s4,16(sp)
    8000252c:	e456                	sd	s5,8(sp)
    8000252e:	e05a                	sd	s6,0(sp)
    80002530:	8aaa                	mv	s5,a0
    80002532:	8b2e                	mv	s6,a1
    80002534:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80002536:	00015a17          	auipc	s4,0x15
    8000253a:	a42a0a13          	addi	s4,s4,-1470 # 80016f78 <sb>
    8000253e:	00495593          	srli	a1,s2,0x4
    80002542:	018a2783          	lw	a5,24(s4)
    80002546:	9dbd                	addw	a1,a1,a5
    80002548:	8556                	mv	a0,s5
    8000254a:	a33ff0ef          	jal	80001f7c <bread>
    8000254e:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80002550:	05850993          	addi	s3,a0,88
    80002554:	00f97793          	andi	a5,s2,15
    80002558:	079a                	slli	a5,a5,0x6
    8000255a:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    8000255c:	00099783          	lh	a5,0(s3)
    80002560:	cb9d                	beqz	a5,80002596 <ialloc+0x88>
    brelse(bp);
    80002562:	b23ff0ef          	jal	80002084 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80002566:	0905                	addi	s2,s2,1
    80002568:	00ca2703          	lw	a4,12(s4)
    8000256c:	0009079b          	sext.w	a5,s2
    80002570:	fce7e7e3          	bltu	a5,a4,8000253e <ialloc+0x30>
    80002574:	74a2                	ld	s1,40(sp)
    80002576:	7902                	ld	s2,32(sp)
    80002578:	69e2                	ld	s3,24(sp)
    8000257a:	6a42                	ld	s4,16(sp)
    8000257c:	6aa2                	ld	s5,8(sp)
    8000257e:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80002580:	00006517          	auipc	a0,0x6
    80002584:	f1850513          	addi	a0,a0,-232 # 80008498 <etext+0x498>
    80002588:	241030ef          	jal	80005fc8 <printf>
  return 0;
    8000258c:	4501                	li	a0,0
}
    8000258e:	70e2                	ld	ra,56(sp)
    80002590:	7442                	ld	s0,48(sp)
    80002592:	6121                	addi	sp,sp,64
    80002594:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80002596:	04000613          	li	a2,64
    8000259a:	4581                	li	a1,0
    8000259c:	854e                	mv	a0,s3
    8000259e:	bc1fd0ef          	jal	8000015e <memset>
      dip->type = type;
    800025a2:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800025a6:	8526                	mv	a0,s1
    800025a8:	329000ef          	jal	800030d0 <log_write>
      brelse(bp);
    800025ac:	8526                	mv	a0,s1
    800025ae:	ad7ff0ef          	jal	80002084 <brelse>
      return iget(dev, inum);
    800025b2:	0009059b          	sext.w	a1,s2
    800025b6:	8556                	mv	a0,s5
    800025b8:	debff0ef          	jal	800023a2 <iget>
    800025bc:	74a2                	ld	s1,40(sp)
    800025be:	7902                	ld	s2,32(sp)
    800025c0:	69e2                	ld	s3,24(sp)
    800025c2:	6a42                	ld	s4,16(sp)
    800025c4:	6aa2                	ld	s5,8(sp)
    800025c6:	6b02                	ld	s6,0(sp)
    800025c8:	b7d9                	j	8000258e <ialloc+0x80>

00000000800025ca <iupdate>:
{
    800025ca:	1101                	addi	sp,sp,-32
    800025cc:	ec06                	sd	ra,24(sp)
    800025ce:	e822                	sd	s0,16(sp)
    800025d0:	e426                	sd	s1,8(sp)
    800025d2:	e04a                	sd	s2,0(sp)
    800025d4:	1000                	addi	s0,sp,32
    800025d6:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800025d8:	415c                	lw	a5,4(a0)
    800025da:	0047d79b          	srliw	a5,a5,0x4
    800025de:	00015597          	auipc	a1,0x15
    800025e2:	9b25a583          	lw	a1,-1614(a1) # 80016f90 <sb+0x18>
    800025e6:	9dbd                	addw	a1,a1,a5
    800025e8:	4108                	lw	a0,0(a0)
    800025ea:	993ff0ef          	jal	80001f7c <bread>
    800025ee:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800025f0:	05850793          	addi	a5,a0,88
    800025f4:	40d8                	lw	a4,4(s1)
    800025f6:	8b3d                	andi	a4,a4,15
    800025f8:	071a                	slli	a4,a4,0x6
    800025fa:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800025fc:	04449703          	lh	a4,68(s1)
    80002600:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80002604:	04649703          	lh	a4,70(s1)
    80002608:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    8000260c:	04849703          	lh	a4,72(s1)
    80002610:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80002614:	04a49703          	lh	a4,74(s1)
    80002618:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    8000261c:	44f8                	lw	a4,76(s1)
    8000261e:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80002620:	03400613          	li	a2,52
    80002624:	05048593          	addi	a1,s1,80
    80002628:	00c78513          	addi	a0,a5,12
    8000262c:	b93fd0ef          	jal	800001be <memmove>
  log_write(bp);
    80002630:	854a                	mv	a0,s2
    80002632:	29f000ef          	jal	800030d0 <log_write>
  brelse(bp);
    80002636:	854a                	mv	a0,s2
    80002638:	a4dff0ef          	jal	80002084 <brelse>
}
    8000263c:	60e2                	ld	ra,24(sp)
    8000263e:	6442                	ld	s0,16(sp)
    80002640:	64a2                	ld	s1,8(sp)
    80002642:	6902                	ld	s2,0(sp)
    80002644:	6105                	addi	sp,sp,32
    80002646:	8082                	ret

0000000080002648 <idup>:
{
    80002648:	1101                	addi	sp,sp,-32
    8000264a:	ec06                	sd	ra,24(sp)
    8000264c:	e822                	sd	s0,16(sp)
    8000264e:	e426                	sd	s1,8(sp)
    80002650:	1000                	addi	s0,sp,32
    80002652:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002654:	00015517          	auipc	a0,0x15
    80002658:	94450513          	addi	a0,a0,-1724 # 80016f98 <itable>
    8000265c:	7bb030ef          	jal	80006616 <acquire>
  ip->ref++;
    80002660:	449c                	lw	a5,8(s1)
    80002662:	2785                	addiw	a5,a5,1
    80002664:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002666:	00015517          	auipc	a0,0x15
    8000266a:	93250513          	addi	a0,a0,-1742 # 80016f98 <itable>
    8000266e:	03c040ef          	jal	800066aa <release>
}
    80002672:	8526                	mv	a0,s1
    80002674:	60e2                	ld	ra,24(sp)
    80002676:	6442                	ld	s0,16(sp)
    80002678:	64a2                	ld	s1,8(sp)
    8000267a:	6105                	addi	sp,sp,32
    8000267c:	8082                	ret

000000008000267e <ilock>:
{
    8000267e:	1101                	addi	sp,sp,-32
    80002680:	ec06                	sd	ra,24(sp)
    80002682:	e822                	sd	s0,16(sp)
    80002684:	e426                	sd	s1,8(sp)
    80002686:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80002688:	cd19                	beqz	a0,800026a6 <ilock+0x28>
    8000268a:	84aa                	mv	s1,a0
    8000268c:	451c                	lw	a5,8(a0)
    8000268e:	00f05c63          	blez	a5,800026a6 <ilock+0x28>
  acquiresleep(&ip->lock);
    80002692:	0541                	addi	a0,a0,16
    80002694:	345000ef          	jal	800031d8 <acquiresleep>
  if(ip->valid == 0){
    80002698:	40bc                	lw	a5,64(s1)
    8000269a:	cf89                	beqz	a5,800026b4 <ilock+0x36>
}
    8000269c:	60e2                	ld	ra,24(sp)
    8000269e:	6442                	ld	s0,16(sp)
    800026a0:	64a2                	ld	s1,8(sp)
    800026a2:	6105                	addi	sp,sp,32
    800026a4:	8082                	ret
    800026a6:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800026a8:	00006517          	auipc	a0,0x6
    800026ac:	e0850513          	addi	a0,a0,-504 # 800084b0 <etext+0x4b0>
    800026b0:	429030ef          	jal	800062d8 <panic>
    800026b4:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800026b6:	40dc                	lw	a5,4(s1)
    800026b8:	0047d79b          	srliw	a5,a5,0x4
    800026bc:	00015597          	auipc	a1,0x15
    800026c0:	8d45a583          	lw	a1,-1836(a1) # 80016f90 <sb+0x18>
    800026c4:	9dbd                	addw	a1,a1,a5
    800026c6:	4088                	lw	a0,0(s1)
    800026c8:	8b5ff0ef          	jal	80001f7c <bread>
    800026cc:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800026ce:	05850593          	addi	a1,a0,88
    800026d2:	40dc                	lw	a5,4(s1)
    800026d4:	8bbd                	andi	a5,a5,15
    800026d6:	079a                	slli	a5,a5,0x6
    800026d8:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800026da:	00059783          	lh	a5,0(a1)
    800026de:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800026e2:	00259783          	lh	a5,2(a1)
    800026e6:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800026ea:	00459783          	lh	a5,4(a1)
    800026ee:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800026f2:	00659783          	lh	a5,6(a1)
    800026f6:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800026fa:	459c                	lw	a5,8(a1)
    800026fc:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800026fe:	03400613          	li	a2,52
    80002702:	05b1                	addi	a1,a1,12
    80002704:	05048513          	addi	a0,s1,80
    80002708:	ab7fd0ef          	jal	800001be <memmove>
    brelse(bp);
    8000270c:	854a                	mv	a0,s2
    8000270e:	977ff0ef          	jal	80002084 <brelse>
    ip->valid = 1;
    80002712:	4785                	li	a5,1
    80002714:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80002716:	04449783          	lh	a5,68(s1)
    8000271a:	c399                	beqz	a5,80002720 <ilock+0xa2>
    8000271c:	6902                	ld	s2,0(sp)
    8000271e:	bfbd                	j	8000269c <ilock+0x1e>
      panic("ilock: no type");
    80002720:	00006517          	auipc	a0,0x6
    80002724:	d9850513          	addi	a0,a0,-616 # 800084b8 <etext+0x4b8>
    80002728:	3b1030ef          	jal	800062d8 <panic>

000000008000272c <iunlock>:
{
    8000272c:	1101                	addi	sp,sp,-32
    8000272e:	ec06                	sd	ra,24(sp)
    80002730:	e822                	sd	s0,16(sp)
    80002732:	e426                	sd	s1,8(sp)
    80002734:	e04a                	sd	s2,0(sp)
    80002736:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80002738:	c505                	beqz	a0,80002760 <iunlock+0x34>
    8000273a:	84aa                	mv	s1,a0
    8000273c:	01050913          	addi	s2,a0,16
    80002740:	854a                	mv	a0,s2
    80002742:	315000ef          	jal	80003256 <holdingsleep>
    80002746:	cd09                	beqz	a0,80002760 <iunlock+0x34>
    80002748:	449c                	lw	a5,8(s1)
    8000274a:	00f05b63          	blez	a5,80002760 <iunlock+0x34>
  releasesleep(&ip->lock);
    8000274e:	854a                	mv	a0,s2
    80002750:	2cf000ef          	jal	8000321e <releasesleep>
}
    80002754:	60e2                	ld	ra,24(sp)
    80002756:	6442                	ld	s0,16(sp)
    80002758:	64a2                	ld	s1,8(sp)
    8000275a:	6902                	ld	s2,0(sp)
    8000275c:	6105                	addi	sp,sp,32
    8000275e:	8082                	ret
    panic("iunlock");
    80002760:	00006517          	auipc	a0,0x6
    80002764:	d6850513          	addi	a0,a0,-664 # 800084c8 <etext+0x4c8>
    80002768:	371030ef          	jal	800062d8 <panic>

000000008000276c <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000276c:	7179                	addi	sp,sp,-48
    8000276e:	f406                	sd	ra,40(sp)
    80002770:	f022                	sd	s0,32(sp)
    80002772:	ec26                	sd	s1,24(sp)
    80002774:	e84a                	sd	s2,16(sp)
    80002776:	e44e                	sd	s3,8(sp)
    80002778:	1800                	addi	s0,sp,48
    8000277a:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    8000277c:	05050493          	addi	s1,a0,80
    80002780:	08050913          	addi	s2,a0,128
    80002784:	a021                	j	8000278c <itrunc+0x20>
    80002786:	0491                	addi	s1,s1,4
    80002788:	01248b63          	beq	s1,s2,8000279e <itrunc+0x32>
    if(ip->addrs[i]){
    8000278c:	408c                	lw	a1,0(s1)
    8000278e:	dde5                	beqz	a1,80002786 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80002790:	0009a503          	lw	a0,0(s3)
    80002794:	9ddff0ef          	jal	80002170 <bfree>
      ip->addrs[i] = 0;
    80002798:	0004a023          	sw	zero,0(s1)
    8000279c:	b7ed                	j	80002786 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    8000279e:	0809a583          	lw	a1,128(s3)
    800027a2:	ed89                	bnez	a1,800027bc <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800027a4:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800027a8:	854e                	mv	a0,s3
    800027aa:	e21ff0ef          	jal	800025ca <iupdate>
}
    800027ae:	70a2                	ld	ra,40(sp)
    800027b0:	7402                	ld	s0,32(sp)
    800027b2:	64e2                	ld	s1,24(sp)
    800027b4:	6942                	ld	s2,16(sp)
    800027b6:	69a2                	ld	s3,8(sp)
    800027b8:	6145                	addi	sp,sp,48
    800027ba:	8082                	ret
    800027bc:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800027be:	0009a503          	lw	a0,0(s3)
    800027c2:	fbaff0ef          	jal	80001f7c <bread>
    800027c6:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800027c8:	05850493          	addi	s1,a0,88
    800027cc:	45850913          	addi	s2,a0,1112
    800027d0:	a021                	j	800027d8 <itrunc+0x6c>
    800027d2:	0491                	addi	s1,s1,4
    800027d4:	01248963          	beq	s1,s2,800027e6 <itrunc+0x7a>
      if(a[j])
    800027d8:	408c                	lw	a1,0(s1)
    800027da:	dde5                	beqz	a1,800027d2 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800027dc:	0009a503          	lw	a0,0(s3)
    800027e0:	991ff0ef          	jal	80002170 <bfree>
    800027e4:	b7fd                	j	800027d2 <itrunc+0x66>
    brelse(bp);
    800027e6:	8552                	mv	a0,s4
    800027e8:	89dff0ef          	jal	80002084 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800027ec:	0809a583          	lw	a1,128(s3)
    800027f0:	0009a503          	lw	a0,0(s3)
    800027f4:	97dff0ef          	jal	80002170 <bfree>
    ip->addrs[NDIRECT] = 0;
    800027f8:	0809a023          	sw	zero,128(s3)
    800027fc:	6a02                	ld	s4,0(sp)
    800027fe:	b75d                	j	800027a4 <itrunc+0x38>

0000000080002800 <iput>:
{
    80002800:	1101                	addi	sp,sp,-32
    80002802:	ec06                	sd	ra,24(sp)
    80002804:	e822                	sd	s0,16(sp)
    80002806:	e426                	sd	s1,8(sp)
    80002808:	1000                	addi	s0,sp,32
    8000280a:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000280c:	00014517          	auipc	a0,0x14
    80002810:	78c50513          	addi	a0,a0,1932 # 80016f98 <itable>
    80002814:	603030ef          	jal	80006616 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002818:	4498                	lw	a4,8(s1)
    8000281a:	4785                	li	a5,1
    8000281c:	02f70063          	beq	a4,a5,8000283c <iput+0x3c>
  ip->ref--;
    80002820:	449c                	lw	a5,8(s1)
    80002822:	37fd                	addiw	a5,a5,-1
    80002824:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002826:	00014517          	auipc	a0,0x14
    8000282a:	77250513          	addi	a0,a0,1906 # 80016f98 <itable>
    8000282e:	67d030ef          	jal	800066aa <release>
}
    80002832:	60e2                	ld	ra,24(sp)
    80002834:	6442                	ld	s0,16(sp)
    80002836:	64a2                	ld	s1,8(sp)
    80002838:	6105                	addi	sp,sp,32
    8000283a:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000283c:	40bc                	lw	a5,64(s1)
    8000283e:	d3ed                	beqz	a5,80002820 <iput+0x20>
    80002840:	04a49783          	lh	a5,74(s1)
    80002844:	fff1                	bnez	a5,80002820 <iput+0x20>
    80002846:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80002848:	01048793          	addi	a5,s1,16
    8000284c:	893e                	mv	s2,a5
    8000284e:	853e                	mv	a0,a5
    80002850:	189000ef          	jal	800031d8 <acquiresleep>
    release(&itable.lock);
    80002854:	00014517          	auipc	a0,0x14
    80002858:	74450513          	addi	a0,a0,1860 # 80016f98 <itable>
    8000285c:	64f030ef          	jal	800066aa <release>
    itrunc(ip);
    80002860:	8526                	mv	a0,s1
    80002862:	f0bff0ef          	jal	8000276c <itrunc>
    ip->type = 0;
    80002866:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    8000286a:	8526                	mv	a0,s1
    8000286c:	d5fff0ef          	jal	800025ca <iupdate>
    ip->valid = 0;
    80002870:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002874:	854a                	mv	a0,s2
    80002876:	1a9000ef          	jal	8000321e <releasesleep>
    acquire(&itable.lock);
    8000287a:	00014517          	auipc	a0,0x14
    8000287e:	71e50513          	addi	a0,a0,1822 # 80016f98 <itable>
    80002882:	595030ef          	jal	80006616 <acquire>
    80002886:	6902                	ld	s2,0(sp)
    80002888:	bf61                	j	80002820 <iput+0x20>

000000008000288a <iunlockput>:
{
    8000288a:	1101                	addi	sp,sp,-32
    8000288c:	ec06                	sd	ra,24(sp)
    8000288e:	e822                	sd	s0,16(sp)
    80002890:	e426                	sd	s1,8(sp)
    80002892:	1000                	addi	s0,sp,32
    80002894:	84aa                	mv	s1,a0
  iunlock(ip);
    80002896:	e97ff0ef          	jal	8000272c <iunlock>
  iput(ip);
    8000289a:	8526                	mv	a0,s1
    8000289c:	f65ff0ef          	jal	80002800 <iput>
}
    800028a0:	60e2                	ld	ra,24(sp)
    800028a2:	6442                	ld	s0,16(sp)
    800028a4:	64a2                	ld	s1,8(sp)
    800028a6:	6105                	addi	sp,sp,32
    800028a8:	8082                	ret

00000000800028aa <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800028aa:	1141                	addi	sp,sp,-16
    800028ac:	e406                	sd	ra,8(sp)
    800028ae:	e022                	sd	s0,0(sp)
    800028b0:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800028b2:	411c                	lw	a5,0(a0)
    800028b4:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800028b6:	415c                	lw	a5,4(a0)
    800028b8:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800028ba:	04451783          	lh	a5,68(a0)
    800028be:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800028c2:	04a51783          	lh	a5,74(a0)
    800028c6:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800028ca:	04c56783          	lwu	a5,76(a0)
    800028ce:	e99c                	sd	a5,16(a1)
}
    800028d0:	60a2                	ld	ra,8(sp)
    800028d2:	6402                	ld	s0,0(sp)
    800028d4:	0141                	addi	sp,sp,16
    800028d6:	8082                	ret

00000000800028d8 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800028d8:	457c                	lw	a5,76(a0)
    800028da:	0ed7e663          	bltu	a5,a3,800029c6 <readi+0xee>
{
    800028de:	7159                	addi	sp,sp,-112
    800028e0:	f486                	sd	ra,104(sp)
    800028e2:	f0a2                	sd	s0,96(sp)
    800028e4:	eca6                	sd	s1,88(sp)
    800028e6:	e0d2                	sd	s4,64(sp)
    800028e8:	fc56                	sd	s5,56(sp)
    800028ea:	f85a                	sd	s6,48(sp)
    800028ec:	f45e                	sd	s7,40(sp)
    800028ee:	1880                	addi	s0,sp,112
    800028f0:	8b2a                	mv	s6,a0
    800028f2:	8bae                	mv	s7,a1
    800028f4:	8a32                	mv	s4,a2
    800028f6:	84b6                	mv	s1,a3
    800028f8:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800028fa:	9f35                	addw	a4,a4,a3
    return 0;
    800028fc:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800028fe:	0ad76b63          	bltu	a4,a3,800029b4 <readi+0xdc>
    80002902:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80002904:	00e7f463          	bgeu	a5,a4,8000290c <readi+0x34>
    n = ip->size - off;
    80002908:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000290c:	080a8b63          	beqz	s5,800029a2 <readi+0xca>
    80002910:	e8ca                	sd	s2,80(sp)
    80002912:	f062                	sd	s8,32(sp)
    80002914:	ec66                	sd	s9,24(sp)
    80002916:	e86a                	sd	s10,16(sp)
    80002918:	e46e                	sd	s11,8(sp)
    8000291a:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    8000291c:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002920:	5c7d                	li	s8,-1
    80002922:	a80d                	j	80002954 <readi+0x7c>
    80002924:	020d1d93          	slli	s11,s10,0x20
    80002928:	020ddd93          	srli	s11,s11,0x20
    8000292c:	05890613          	addi	a2,s2,88
    80002930:	86ee                	mv	a3,s11
    80002932:	963e                	add	a2,a2,a5
    80002934:	85d2                	mv	a1,s4
    80002936:	855e                	mv	a0,s7
    80002938:	daffe0ef          	jal	800016e6 <either_copyout>
    8000293c:	05850363          	beq	a0,s8,80002982 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002940:	854a                	mv	a0,s2
    80002942:	f42ff0ef          	jal	80002084 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002946:	013d09bb          	addw	s3,s10,s3
    8000294a:	009d04bb          	addw	s1,s10,s1
    8000294e:	9a6e                	add	s4,s4,s11
    80002950:	0559f363          	bgeu	s3,s5,80002996 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002954:	00a4d59b          	srliw	a1,s1,0xa
    80002958:	855a                	mv	a0,s6
    8000295a:	989ff0ef          	jal	800022e2 <bmap>
    8000295e:	85aa                	mv	a1,a0
    if(addr == 0)
    80002960:	c139                	beqz	a0,800029a6 <readi+0xce>
    bp = bread(ip->dev, addr);
    80002962:	000b2503          	lw	a0,0(s6)
    80002966:	e16ff0ef          	jal	80001f7c <bread>
    8000296a:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000296c:	3ff4f793          	andi	a5,s1,1023
    80002970:	40fc873b          	subw	a4,s9,a5
    80002974:	413a86bb          	subw	a3,s5,s3
    80002978:	8d3a                	mv	s10,a4
    8000297a:	fae6f5e3          	bgeu	a3,a4,80002924 <readi+0x4c>
    8000297e:	8d36                	mv	s10,a3
    80002980:	b755                	j	80002924 <readi+0x4c>
      brelse(bp);
    80002982:	854a                	mv	a0,s2
    80002984:	f00ff0ef          	jal	80002084 <brelse>
      tot = -1;
    80002988:	59fd                	li	s3,-1
      break;
    8000298a:	6946                	ld	s2,80(sp)
    8000298c:	7c02                	ld	s8,32(sp)
    8000298e:	6ce2                	ld	s9,24(sp)
    80002990:	6d42                	ld	s10,16(sp)
    80002992:	6da2                	ld	s11,8(sp)
    80002994:	a831                	j	800029b0 <readi+0xd8>
    80002996:	6946                	ld	s2,80(sp)
    80002998:	7c02                	ld	s8,32(sp)
    8000299a:	6ce2                	ld	s9,24(sp)
    8000299c:	6d42                	ld	s10,16(sp)
    8000299e:	6da2                	ld	s11,8(sp)
    800029a0:	a801                	j	800029b0 <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800029a2:	89d6                	mv	s3,s5
    800029a4:	a031                	j	800029b0 <readi+0xd8>
    800029a6:	6946                	ld	s2,80(sp)
    800029a8:	7c02                	ld	s8,32(sp)
    800029aa:	6ce2                	ld	s9,24(sp)
    800029ac:	6d42                	ld	s10,16(sp)
    800029ae:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800029b0:	854e                	mv	a0,s3
    800029b2:	69a6                	ld	s3,72(sp)
}
    800029b4:	70a6                	ld	ra,104(sp)
    800029b6:	7406                	ld	s0,96(sp)
    800029b8:	64e6                	ld	s1,88(sp)
    800029ba:	6a06                	ld	s4,64(sp)
    800029bc:	7ae2                	ld	s5,56(sp)
    800029be:	7b42                	ld	s6,48(sp)
    800029c0:	7ba2                	ld	s7,40(sp)
    800029c2:	6165                	addi	sp,sp,112
    800029c4:	8082                	ret
    return 0;
    800029c6:	4501                	li	a0,0
}
    800029c8:	8082                	ret

00000000800029ca <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800029ca:	457c                	lw	a5,76(a0)
    800029cc:	0ed7eb63          	bltu	a5,a3,80002ac2 <writei+0xf8>
{
    800029d0:	7159                	addi	sp,sp,-112
    800029d2:	f486                	sd	ra,104(sp)
    800029d4:	f0a2                	sd	s0,96(sp)
    800029d6:	e8ca                	sd	s2,80(sp)
    800029d8:	e0d2                	sd	s4,64(sp)
    800029da:	fc56                	sd	s5,56(sp)
    800029dc:	f85a                	sd	s6,48(sp)
    800029de:	f45e                	sd	s7,40(sp)
    800029e0:	1880                	addi	s0,sp,112
    800029e2:	8aaa                	mv	s5,a0
    800029e4:	8bae                	mv	s7,a1
    800029e6:	8a32                	mv	s4,a2
    800029e8:	8936                	mv	s2,a3
    800029ea:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800029ec:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800029f0:	00043737          	lui	a4,0x43
    800029f4:	0cf76963          	bltu	a4,a5,80002ac6 <writei+0xfc>
    800029f8:	0cd7e763          	bltu	a5,a3,80002ac6 <writei+0xfc>
    800029fc:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800029fe:	0a0b0a63          	beqz	s6,80002ab2 <writei+0xe8>
    80002a02:	eca6                	sd	s1,88(sp)
    80002a04:	f062                	sd	s8,32(sp)
    80002a06:	ec66                	sd	s9,24(sp)
    80002a08:	e86a                	sd	s10,16(sp)
    80002a0a:	e46e                	sd	s11,8(sp)
    80002a0c:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002a0e:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002a12:	5c7d                	li	s8,-1
    80002a14:	a825                	j	80002a4c <writei+0x82>
    80002a16:	020d1d93          	slli	s11,s10,0x20
    80002a1a:	020ddd93          	srli	s11,s11,0x20
    80002a1e:	05848513          	addi	a0,s1,88
    80002a22:	86ee                	mv	a3,s11
    80002a24:	8652                	mv	a2,s4
    80002a26:	85de                	mv	a1,s7
    80002a28:	953e                	add	a0,a0,a5
    80002a2a:	d07fe0ef          	jal	80001730 <either_copyin>
    80002a2e:	05850663          	beq	a0,s8,80002a7a <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002a32:	8526                	mv	a0,s1
    80002a34:	69c000ef          	jal	800030d0 <log_write>
    brelse(bp);
    80002a38:	8526                	mv	a0,s1
    80002a3a:	e4aff0ef          	jal	80002084 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002a3e:	013d09bb          	addw	s3,s10,s3
    80002a42:	012d093b          	addw	s2,s10,s2
    80002a46:	9a6e                	add	s4,s4,s11
    80002a48:	0369fc63          	bgeu	s3,s6,80002a80 <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80002a4c:	00a9559b          	srliw	a1,s2,0xa
    80002a50:	8556                	mv	a0,s5
    80002a52:	891ff0ef          	jal	800022e2 <bmap>
    80002a56:	85aa                	mv	a1,a0
    if(addr == 0)
    80002a58:	c505                	beqz	a0,80002a80 <writei+0xb6>
    bp = bread(ip->dev, addr);
    80002a5a:	000aa503          	lw	a0,0(s5)
    80002a5e:	d1eff0ef          	jal	80001f7c <bread>
    80002a62:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002a64:	3ff97793          	andi	a5,s2,1023
    80002a68:	40fc873b          	subw	a4,s9,a5
    80002a6c:	413b06bb          	subw	a3,s6,s3
    80002a70:	8d3a                	mv	s10,a4
    80002a72:	fae6f2e3          	bgeu	a3,a4,80002a16 <writei+0x4c>
    80002a76:	8d36                	mv	s10,a3
    80002a78:	bf79                	j	80002a16 <writei+0x4c>
      brelse(bp);
    80002a7a:	8526                	mv	a0,s1
    80002a7c:	e08ff0ef          	jal	80002084 <brelse>
  }

  if(off > ip->size)
    80002a80:	04caa783          	lw	a5,76(s5)
    80002a84:	0327f963          	bgeu	a5,s2,80002ab6 <writei+0xec>
    ip->size = off;
    80002a88:	052aa623          	sw	s2,76(s5)
    80002a8c:	64e6                	ld	s1,88(sp)
    80002a8e:	7c02                	ld	s8,32(sp)
    80002a90:	6ce2                	ld	s9,24(sp)
    80002a92:	6d42                	ld	s10,16(sp)
    80002a94:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002a96:	8556                	mv	a0,s5
    80002a98:	b33ff0ef          	jal	800025ca <iupdate>

  return tot;
    80002a9c:	854e                	mv	a0,s3
    80002a9e:	69a6                	ld	s3,72(sp)
}
    80002aa0:	70a6                	ld	ra,104(sp)
    80002aa2:	7406                	ld	s0,96(sp)
    80002aa4:	6946                	ld	s2,80(sp)
    80002aa6:	6a06                	ld	s4,64(sp)
    80002aa8:	7ae2                	ld	s5,56(sp)
    80002aaa:	7b42                	ld	s6,48(sp)
    80002aac:	7ba2                	ld	s7,40(sp)
    80002aae:	6165                	addi	sp,sp,112
    80002ab0:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002ab2:	89da                	mv	s3,s6
    80002ab4:	b7cd                	j	80002a96 <writei+0xcc>
    80002ab6:	64e6                	ld	s1,88(sp)
    80002ab8:	7c02                	ld	s8,32(sp)
    80002aba:	6ce2                	ld	s9,24(sp)
    80002abc:	6d42                	ld	s10,16(sp)
    80002abe:	6da2                	ld	s11,8(sp)
    80002ac0:	bfd9                	j	80002a96 <writei+0xcc>
    return -1;
    80002ac2:	557d                	li	a0,-1
}
    80002ac4:	8082                	ret
    return -1;
    80002ac6:	557d                	li	a0,-1
    80002ac8:	bfe1                	j	80002aa0 <writei+0xd6>

0000000080002aca <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002aca:	1141                	addi	sp,sp,-16
    80002acc:	e406                	sd	ra,8(sp)
    80002ace:	e022                	sd	s0,0(sp)
    80002ad0:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002ad2:	4639                	li	a2,14
    80002ad4:	f5efd0ef          	jal	80000232 <strncmp>
}
    80002ad8:	60a2                	ld	ra,8(sp)
    80002ada:	6402                	ld	s0,0(sp)
    80002adc:	0141                	addi	sp,sp,16
    80002ade:	8082                	ret

0000000080002ae0 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002ae0:	711d                	addi	sp,sp,-96
    80002ae2:	ec86                	sd	ra,88(sp)
    80002ae4:	e8a2                	sd	s0,80(sp)
    80002ae6:	e4a6                	sd	s1,72(sp)
    80002ae8:	e0ca                	sd	s2,64(sp)
    80002aea:	fc4e                	sd	s3,56(sp)
    80002aec:	f852                	sd	s4,48(sp)
    80002aee:	f456                	sd	s5,40(sp)
    80002af0:	f05a                	sd	s6,32(sp)
    80002af2:	ec5e                	sd	s7,24(sp)
    80002af4:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002af6:	04451703          	lh	a4,68(a0)
    80002afa:	4785                	li	a5,1
    80002afc:	00f71f63          	bne	a4,a5,80002b1a <dirlookup+0x3a>
    80002b00:	892a                	mv	s2,a0
    80002b02:	8aae                	mv	s5,a1
    80002b04:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002b06:	457c                	lw	a5,76(a0)
    80002b08:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002b0a:	fa040a13          	addi	s4,s0,-96
    80002b0e:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80002b10:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002b14:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002b16:	e39d                	bnez	a5,80002b3c <dirlookup+0x5c>
    80002b18:	a8b9                	j	80002b76 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80002b1a:	00006517          	auipc	a0,0x6
    80002b1e:	9b650513          	addi	a0,a0,-1610 # 800084d0 <etext+0x4d0>
    80002b22:	7b6030ef          	jal	800062d8 <panic>
      panic("dirlookup read");
    80002b26:	00006517          	auipc	a0,0x6
    80002b2a:	9c250513          	addi	a0,a0,-1598 # 800084e8 <etext+0x4e8>
    80002b2e:	7aa030ef          	jal	800062d8 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002b32:	24c1                	addiw	s1,s1,16
    80002b34:	04c92783          	lw	a5,76(s2)
    80002b38:	02f4fe63          	bgeu	s1,a5,80002b74 <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002b3c:	874e                	mv	a4,s3
    80002b3e:	86a6                	mv	a3,s1
    80002b40:	8652                	mv	a2,s4
    80002b42:	4581                	li	a1,0
    80002b44:	854a                	mv	a0,s2
    80002b46:	d93ff0ef          	jal	800028d8 <readi>
    80002b4a:	fd351ee3          	bne	a0,s3,80002b26 <dirlookup+0x46>
    if(de.inum == 0)
    80002b4e:	fa045783          	lhu	a5,-96(s0)
    80002b52:	d3e5                	beqz	a5,80002b32 <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80002b54:	85da                	mv	a1,s6
    80002b56:	8556                	mv	a0,s5
    80002b58:	f73ff0ef          	jal	80002aca <namecmp>
    80002b5c:	f979                	bnez	a0,80002b32 <dirlookup+0x52>
      if(poff)
    80002b5e:	000b8463          	beqz	s7,80002b66 <dirlookup+0x86>
        *poff = off;
    80002b62:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80002b66:	fa045583          	lhu	a1,-96(s0)
    80002b6a:	00092503          	lw	a0,0(s2)
    80002b6e:	835ff0ef          	jal	800023a2 <iget>
    80002b72:	a011                	j	80002b76 <dirlookup+0x96>
  return 0;
    80002b74:	4501                	li	a0,0
}
    80002b76:	60e6                	ld	ra,88(sp)
    80002b78:	6446                	ld	s0,80(sp)
    80002b7a:	64a6                	ld	s1,72(sp)
    80002b7c:	6906                	ld	s2,64(sp)
    80002b7e:	79e2                	ld	s3,56(sp)
    80002b80:	7a42                	ld	s4,48(sp)
    80002b82:	7aa2                	ld	s5,40(sp)
    80002b84:	7b02                	ld	s6,32(sp)
    80002b86:	6be2                	ld	s7,24(sp)
    80002b88:	6125                	addi	sp,sp,96
    80002b8a:	8082                	ret

0000000080002b8c <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002b8c:	711d                	addi	sp,sp,-96
    80002b8e:	ec86                	sd	ra,88(sp)
    80002b90:	e8a2                	sd	s0,80(sp)
    80002b92:	e4a6                	sd	s1,72(sp)
    80002b94:	e0ca                	sd	s2,64(sp)
    80002b96:	fc4e                	sd	s3,56(sp)
    80002b98:	f852                	sd	s4,48(sp)
    80002b9a:	f456                	sd	s5,40(sp)
    80002b9c:	f05a                	sd	s6,32(sp)
    80002b9e:	ec5e                	sd	s7,24(sp)
    80002ba0:	e862                	sd	s8,16(sp)
    80002ba2:	e466                	sd	s9,8(sp)
    80002ba4:	e06a                	sd	s10,0(sp)
    80002ba6:	1080                	addi	s0,sp,96
    80002ba8:	84aa                	mv	s1,a0
    80002baa:	8b2e                	mv	s6,a1
    80002bac:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002bae:	00054703          	lbu	a4,0(a0)
    80002bb2:	02f00793          	li	a5,47
    80002bb6:	00f70f63          	beq	a4,a5,80002bd4 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002bba:	a00fe0ef          	jal	80000dba <myproc>
    80002bbe:	15053503          	ld	a0,336(a0)
    80002bc2:	a87ff0ef          	jal	80002648 <idup>
    80002bc6:	8a2a                	mv	s4,a0
  while(*path == '/')
    80002bc8:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80002bcc:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80002bce:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002bd0:	4b85                	li	s7,1
    80002bd2:	a879                	j	80002c70 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80002bd4:	4585                	li	a1,1
    80002bd6:	852e                	mv	a0,a1
    80002bd8:	fcaff0ef          	jal	800023a2 <iget>
    80002bdc:	8a2a                	mv	s4,a0
    80002bde:	b7ed                	j	80002bc8 <namex+0x3c>
      iunlockput(ip);
    80002be0:	8552                	mv	a0,s4
    80002be2:	ca9ff0ef          	jal	8000288a <iunlockput>
      return 0;
    80002be6:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002be8:	8552                	mv	a0,s4
    80002bea:	60e6                	ld	ra,88(sp)
    80002bec:	6446                	ld	s0,80(sp)
    80002bee:	64a6                	ld	s1,72(sp)
    80002bf0:	6906                	ld	s2,64(sp)
    80002bf2:	79e2                	ld	s3,56(sp)
    80002bf4:	7a42                	ld	s4,48(sp)
    80002bf6:	7aa2                	ld	s5,40(sp)
    80002bf8:	7b02                	ld	s6,32(sp)
    80002bfa:	6be2                	ld	s7,24(sp)
    80002bfc:	6c42                	ld	s8,16(sp)
    80002bfe:	6ca2                	ld	s9,8(sp)
    80002c00:	6d02                	ld	s10,0(sp)
    80002c02:	6125                	addi	sp,sp,96
    80002c04:	8082                	ret
      iunlock(ip);
    80002c06:	8552                	mv	a0,s4
    80002c08:	b25ff0ef          	jal	8000272c <iunlock>
      return ip;
    80002c0c:	bff1                	j	80002be8 <namex+0x5c>
      iunlockput(ip);
    80002c0e:	8552                	mv	a0,s4
    80002c10:	c7bff0ef          	jal	8000288a <iunlockput>
      return 0;
    80002c14:	8a4a                	mv	s4,s2
    80002c16:	bfc9                	j	80002be8 <namex+0x5c>
  len = path - s;
    80002c18:	40990633          	sub	a2,s2,s1
    80002c1c:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80002c20:	09ac5463          	bge	s8,s10,80002ca8 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80002c24:	8666                	mv	a2,s9
    80002c26:	85a6                	mv	a1,s1
    80002c28:	8556                	mv	a0,s5
    80002c2a:	d94fd0ef          	jal	800001be <memmove>
    80002c2e:	84ca                	mv	s1,s2
  while(*path == '/')
    80002c30:	0004c783          	lbu	a5,0(s1)
    80002c34:	01379763          	bne	a5,s3,80002c42 <namex+0xb6>
    path++;
    80002c38:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002c3a:	0004c783          	lbu	a5,0(s1)
    80002c3e:	ff378de3          	beq	a5,s3,80002c38 <namex+0xac>
    ilock(ip);
    80002c42:	8552                	mv	a0,s4
    80002c44:	a3bff0ef          	jal	8000267e <ilock>
    if(ip->type != T_DIR){
    80002c48:	044a1783          	lh	a5,68(s4)
    80002c4c:	f9779ae3          	bne	a5,s7,80002be0 <namex+0x54>
    if(nameiparent && *path == '\0'){
    80002c50:	000b0563          	beqz	s6,80002c5a <namex+0xce>
    80002c54:	0004c783          	lbu	a5,0(s1)
    80002c58:	d7dd                	beqz	a5,80002c06 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002c5a:	4601                	li	a2,0
    80002c5c:	85d6                	mv	a1,s5
    80002c5e:	8552                	mv	a0,s4
    80002c60:	e81ff0ef          	jal	80002ae0 <dirlookup>
    80002c64:	892a                	mv	s2,a0
    80002c66:	d545                	beqz	a0,80002c0e <namex+0x82>
    iunlockput(ip);
    80002c68:	8552                	mv	a0,s4
    80002c6a:	c21ff0ef          	jal	8000288a <iunlockput>
    ip = next;
    80002c6e:	8a4a                	mv	s4,s2
  while(*path == '/')
    80002c70:	0004c783          	lbu	a5,0(s1)
    80002c74:	01379763          	bne	a5,s3,80002c82 <namex+0xf6>
    path++;
    80002c78:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002c7a:	0004c783          	lbu	a5,0(s1)
    80002c7e:	ff378de3          	beq	a5,s3,80002c78 <namex+0xec>
  if(*path == 0)
    80002c82:	cf8d                	beqz	a5,80002cbc <namex+0x130>
  while(*path != '/' && *path != 0)
    80002c84:	0004c783          	lbu	a5,0(s1)
    80002c88:	fd178713          	addi	a4,a5,-47
    80002c8c:	cb19                	beqz	a4,80002ca2 <namex+0x116>
    80002c8e:	cb91                	beqz	a5,80002ca2 <namex+0x116>
    80002c90:	8926                	mv	s2,s1
    path++;
    80002c92:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80002c94:	00094783          	lbu	a5,0(s2)
    80002c98:	fd178713          	addi	a4,a5,-47
    80002c9c:	df35                	beqz	a4,80002c18 <namex+0x8c>
    80002c9e:	fbf5                	bnez	a5,80002c92 <namex+0x106>
    80002ca0:	bfa5                	j	80002c18 <namex+0x8c>
    80002ca2:	8926                	mv	s2,s1
  len = path - s;
    80002ca4:	4d01                	li	s10,0
    80002ca6:	4601                	li	a2,0
    memmove(name, s, len);
    80002ca8:	2601                	sext.w	a2,a2
    80002caa:	85a6                	mv	a1,s1
    80002cac:	8556                	mv	a0,s5
    80002cae:	d10fd0ef          	jal	800001be <memmove>
    name[len] = 0;
    80002cb2:	9d56                	add	s10,s10,s5
    80002cb4:	000d0023          	sb	zero,0(s10)
    80002cb8:	84ca                	mv	s1,s2
    80002cba:	bf9d                	j	80002c30 <namex+0xa4>
  if(nameiparent){
    80002cbc:	f20b06e3          	beqz	s6,80002be8 <namex+0x5c>
    iput(ip);
    80002cc0:	8552                	mv	a0,s4
    80002cc2:	b3fff0ef          	jal	80002800 <iput>
    return 0;
    80002cc6:	4a01                	li	s4,0
    80002cc8:	b705                	j	80002be8 <namex+0x5c>

0000000080002cca <dirlink>:
{
    80002cca:	715d                	addi	sp,sp,-80
    80002ccc:	e486                	sd	ra,72(sp)
    80002cce:	e0a2                	sd	s0,64(sp)
    80002cd0:	f84a                	sd	s2,48(sp)
    80002cd2:	ec56                	sd	s5,24(sp)
    80002cd4:	e85a                	sd	s6,16(sp)
    80002cd6:	0880                	addi	s0,sp,80
    80002cd8:	892a                	mv	s2,a0
    80002cda:	8aae                	mv	s5,a1
    80002cdc:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002cde:	4601                	li	a2,0
    80002ce0:	e01ff0ef          	jal	80002ae0 <dirlookup>
    80002ce4:	ed1d                	bnez	a0,80002d22 <dirlink+0x58>
    80002ce6:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ce8:	04c92483          	lw	s1,76(s2)
    80002cec:	c4b9                	beqz	s1,80002d3a <dirlink+0x70>
    80002cee:	f44e                	sd	s3,40(sp)
    80002cf0:	f052                	sd	s4,32(sp)
    80002cf2:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002cf4:	fb040a13          	addi	s4,s0,-80
    80002cf8:	49c1                	li	s3,16
    80002cfa:	874e                	mv	a4,s3
    80002cfc:	86a6                	mv	a3,s1
    80002cfe:	8652                	mv	a2,s4
    80002d00:	4581                	li	a1,0
    80002d02:	854a                	mv	a0,s2
    80002d04:	bd5ff0ef          	jal	800028d8 <readi>
    80002d08:	03351163          	bne	a0,s3,80002d2a <dirlink+0x60>
    if(de.inum == 0)
    80002d0c:	fb045783          	lhu	a5,-80(s0)
    80002d10:	c39d                	beqz	a5,80002d36 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d12:	24c1                	addiw	s1,s1,16
    80002d14:	04c92783          	lw	a5,76(s2)
    80002d18:	fef4e1e3          	bltu	s1,a5,80002cfa <dirlink+0x30>
    80002d1c:	79a2                	ld	s3,40(sp)
    80002d1e:	7a02                	ld	s4,32(sp)
    80002d20:	a829                	j	80002d3a <dirlink+0x70>
    iput(ip);
    80002d22:	adfff0ef          	jal	80002800 <iput>
    return -1;
    80002d26:	557d                	li	a0,-1
    80002d28:	a83d                	j	80002d66 <dirlink+0x9c>
      panic("dirlink read");
    80002d2a:	00005517          	auipc	a0,0x5
    80002d2e:	7ce50513          	addi	a0,a0,1998 # 800084f8 <etext+0x4f8>
    80002d32:	5a6030ef          	jal	800062d8 <panic>
    80002d36:	79a2                	ld	s3,40(sp)
    80002d38:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80002d3a:	4639                	li	a2,14
    80002d3c:	85d6                	mv	a1,s5
    80002d3e:	fb240513          	addi	a0,s0,-78
    80002d42:	d2afd0ef          	jal	8000026c <strncpy>
  de.inum = inum;
    80002d46:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d4a:	4741                	li	a4,16
    80002d4c:	86a6                	mv	a3,s1
    80002d4e:	fb040613          	addi	a2,s0,-80
    80002d52:	4581                	li	a1,0
    80002d54:	854a                	mv	a0,s2
    80002d56:	c75ff0ef          	jal	800029ca <writei>
    80002d5a:	1541                	addi	a0,a0,-16
    80002d5c:	00a03533          	snez	a0,a0
    80002d60:	40a0053b          	negw	a0,a0
    80002d64:	74e2                	ld	s1,56(sp)
}
    80002d66:	60a6                	ld	ra,72(sp)
    80002d68:	6406                	ld	s0,64(sp)
    80002d6a:	7942                	ld	s2,48(sp)
    80002d6c:	6ae2                	ld	s5,24(sp)
    80002d6e:	6b42                	ld	s6,16(sp)
    80002d70:	6161                	addi	sp,sp,80
    80002d72:	8082                	ret

0000000080002d74 <namei>:

struct inode*
namei(char *path)
{
    80002d74:	1101                	addi	sp,sp,-32
    80002d76:	ec06                	sd	ra,24(sp)
    80002d78:	e822                	sd	s0,16(sp)
    80002d7a:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002d7c:	fe040613          	addi	a2,s0,-32
    80002d80:	4581                	li	a1,0
    80002d82:	e0bff0ef          	jal	80002b8c <namex>
}
    80002d86:	60e2                	ld	ra,24(sp)
    80002d88:	6442                	ld	s0,16(sp)
    80002d8a:	6105                	addi	sp,sp,32
    80002d8c:	8082                	ret

0000000080002d8e <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002d8e:	1141                	addi	sp,sp,-16
    80002d90:	e406                	sd	ra,8(sp)
    80002d92:	e022                	sd	s0,0(sp)
    80002d94:	0800                	addi	s0,sp,16
    80002d96:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002d98:	4585                	li	a1,1
    80002d9a:	df3ff0ef          	jal	80002b8c <namex>
}
    80002d9e:	60a2                	ld	ra,8(sp)
    80002da0:	6402                	ld	s0,0(sp)
    80002da2:	0141                	addi	sp,sp,16
    80002da4:	8082                	ret

0000000080002da6 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002da6:	1101                	addi	sp,sp,-32
    80002da8:	ec06                	sd	ra,24(sp)
    80002daa:	e822                	sd	s0,16(sp)
    80002dac:	e426                	sd	s1,8(sp)
    80002dae:	e04a                	sd	s2,0(sp)
    80002db0:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002db2:	00016917          	auipc	s2,0x16
    80002db6:	c8e90913          	addi	s2,s2,-882 # 80018a40 <log>
    80002dba:	01892583          	lw	a1,24(s2)
    80002dbe:	02892503          	lw	a0,40(s2)
    80002dc2:	9baff0ef          	jal	80001f7c <bread>
    80002dc6:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002dc8:	02c92603          	lw	a2,44(s2)
    80002dcc:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002dce:	00c05f63          	blez	a2,80002dec <write_head+0x46>
    80002dd2:	00016717          	auipc	a4,0x16
    80002dd6:	c9e70713          	addi	a4,a4,-866 # 80018a70 <log+0x30>
    80002dda:	87aa                	mv	a5,a0
    80002ddc:	060a                	slli	a2,a2,0x2
    80002dde:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80002de0:	4314                	lw	a3,0(a4)
    80002de2:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80002de4:	0711                	addi	a4,a4,4
    80002de6:	0791                	addi	a5,a5,4
    80002de8:	fec79ce3          	bne	a5,a2,80002de0 <write_head+0x3a>
  }
  bwrite(buf);
    80002dec:	8526                	mv	a0,s1
    80002dee:	a64ff0ef          	jal	80002052 <bwrite>
  brelse(buf);
    80002df2:	8526                	mv	a0,s1
    80002df4:	a90ff0ef          	jal	80002084 <brelse>
}
    80002df8:	60e2                	ld	ra,24(sp)
    80002dfa:	6442                	ld	s0,16(sp)
    80002dfc:	64a2                	ld	s1,8(sp)
    80002dfe:	6902                	ld	s2,0(sp)
    80002e00:	6105                	addi	sp,sp,32
    80002e02:	8082                	ret

0000000080002e04 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80002e04:	00016797          	auipc	a5,0x16
    80002e08:	c687a783          	lw	a5,-920(a5) # 80018a6c <log+0x2c>
    80002e0c:	0af05263          	blez	a5,80002eb0 <install_trans+0xac>
{
    80002e10:	715d                	addi	sp,sp,-80
    80002e12:	e486                	sd	ra,72(sp)
    80002e14:	e0a2                	sd	s0,64(sp)
    80002e16:	fc26                	sd	s1,56(sp)
    80002e18:	f84a                	sd	s2,48(sp)
    80002e1a:	f44e                	sd	s3,40(sp)
    80002e1c:	f052                	sd	s4,32(sp)
    80002e1e:	ec56                	sd	s5,24(sp)
    80002e20:	e85a                	sd	s6,16(sp)
    80002e22:	e45e                	sd	s7,8(sp)
    80002e24:	0880                	addi	s0,sp,80
    80002e26:	8b2a                	mv	s6,a0
    80002e28:	00016a97          	auipc	s5,0x16
    80002e2c:	c48a8a93          	addi	s5,s5,-952 # 80018a70 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002e30:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002e32:	00016997          	auipc	s3,0x16
    80002e36:	c0e98993          	addi	s3,s3,-1010 # 80018a40 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80002e3a:	40000b93          	li	s7,1024
    80002e3e:	a829                	j	80002e58 <install_trans+0x54>
    brelse(lbuf);
    80002e40:	854a                	mv	a0,s2
    80002e42:	a42ff0ef          	jal	80002084 <brelse>
    brelse(dbuf);
    80002e46:	8526                	mv	a0,s1
    80002e48:	a3cff0ef          	jal	80002084 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002e4c:	2a05                	addiw	s4,s4,1
    80002e4e:	0a91                	addi	s5,s5,4
    80002e50:	02c9a783          	lw	a5,44(s3)
    80002e54:	04fa5363          	bge	s4,a5,80002e9a <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002e58:	0189a583          	lw	a1,24(s3)
    80002e5c:	014585bb          	addw	a1,a1,s4
    80002e60:	2585                	addiw	a1,a1,1
    80002e62:	0289a503          	lw	a0,40(s3)
    80002e66:	916ff0ef          	jal	80001f7c <bread>
    80002e6a:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80002e6c:	000aa583          	lw	a1,0(s5)
    80002e70:	0289a503          	lw	a0,40(s3)
    80002e74:	908ff0ef          	jal	80001f7c <bread>
    80002e78:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80002e7a:	865e                	mv	a2,s7
    80002e7c:	05890593          	addi	a1,s2,88
    80002e80:	05850513          	addi	a0,a0,88
    80002e84:	b3afd0ef          	jal	800001be <memmove>
    bwrite(dbuf);  // write dst to disk
    80002e88:	8526                	mv	a0,s1
    80002e8a:	9c8ff0ef          	jal	80002052 <bwrite>
    if(recovering == 0)
    80002e8e:	fa0b19e3          	bnez	s6,80002e40 <install_trans+0x3c>
      bunpin(dbuf);
    80002e92:	8526                	mv	a0,s1
    80002e94:	aa8ff0ef          	jal	8000213c <bunpin>
    80002e98:	b765                	j	80002e40 <install_trans+0x3c>
}
    80002e9a:	60a6                	ld	ra,72(sp)
    80002e9c:	6406                	ld	s0,64(sp)
    80002e9e:	74e2                	ld	s1,56(sp)
    80002ea0:	7942                	ld	s2,48(sp)
    80002ea2:	79a2                	ld	s3,40(sp)
    80002ea4:	7a02                	ld	s4,32(sp)
    80002ea6:	6ae2                	ld	s5,24(sp)
    80002ea8:	6b42                	ld	s6,16(sp)
    80002eaa:	6ba2                	ld	s7,8(sp)
    80002eac:	6161                	addi	sp,sp,80
    80002eae:	8082                	ret
    80002eb0:	8082                	ret

0000000080002eb2 <initlog>:
{
    80002eb2:	7179                	addi	sp,sp,-48
    80002eb4:	f406                	sd	ra,40(sp)
    80002eb6:	f022                	sd	s0,32(sp)
    80002eb8:	ec26                	sd	s1,24(sp)
    80002eba:	e84a                	sd	s2,16(sp)
    80002ebc:	e44e                	sd	s3,8(sp)
    80002ebe:	1800                	addi	s0,sp,48
    80002ec0:	892a                	mv	s2,a0
    80002ec2:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80002ec4:	00016497          	auipc	s1,0x16
    80002ec8:	b7c48493          	addi	s1,s1,-1156 # 80018a40 <log>
    80002ecc:	00005597          	auipc	a1,0x5
    80002ed0:	63c58593          	addi	a1,a1,1596 # 80008508 <etext+0x508>
    80002ed4:	8526                	mv	a0,s1
    80002ed6:	6b6030ef          	jal	8000658c <initlock>
  log.start = sb->logstart;
    80002eda:	0149a583          	lw	a1,20(s3)
    80002ede:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80002ee0:	0109a783          	lw	a5,16(s3)
    80002ee4:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80002ee6:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80002eea:	854a                	mv	a0,s2
    80002eec:	890ff0ef          	jal	80001f7c <bread>
  log.lh.n = lh->n;
    80002ef0:	4d30                	lw	a2,88(a0)
    80002ef2:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80002ef4:	00c05f63          	blez	a2,80002f12 <initlog+0x60>
    80002ef8:	87aa                	mv	a5,a0
    80002efa:	00016717          	auipc	a4,0x16
    80002efe:	b7670713          	addi	a4,a4,-1162 # 80018a70 <log+0x30>
    80002f02:	060a                	slli	a2,a2,0x2
    80002f04:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80002f06:	4ff4                	lw	a3,92(a5)
    80002f08:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80002f0a:	0791                	addi	a5,a5,4
    80002f0c:	0711                	addi	a4,a4,4
    80002f0e:	fec79ce3          	bne	a5,a2,80002f06 <initlog+0x54>
  brelse(buf);
    80002f12:	972ff0ef          	jal	80002084 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80002f16:	4505                	li	a0,1
    80002f18:	eedff0ef          	jal	80002e04 <install_trans>
  log.lh.n = 0;
    80002f1c:	00016797          	auipc	a5,0x16
    80002f20:	b407a823          	sw	zero,-1200(a5) # 80018a6c <log+0x2c>
  write_head(); // clear the log
    80002f24:	e83ff0ef          	jal	80002da6 <write_head>
}
    80002f28:	70a2                	ld	ra,40(sp)
    80002f2a:	7402                	ld	s0,32(sp)
    80002f2c:	64e2                	ld	s1,24(sp)
    80002f2e:	6942                	ld	s2,16(sp)
    80002f30:	69a2                	ld	s3,8(sp)
    80002f32:	6145                	addi	sp,sp,48
    80002f34:	8082                	ret

0000000080002f36 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80002f36:	1101                	addi	sp,sp,-32
    80002f38:	ec06                	sd	ra,24(sp)
    80002f3a:	e822                	sd	s0,16(sp)
    80002f3c:	e426                	sd	s1,8(sp)
    80002f3e:	e04a                	sd	s2,0(sp)
    80002f40:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80002f42:	00016517          	auipc	a0,0x16
    80002f46:	afe50513          	addi	a0,a0,-1282 # 80018a40 <log>
    80002f4a:	6cc030ef          	jal	80006616 <acquire>
  while(1){
    if(log.committing){
    80002f4e:	00016497          	auipc	s1,0x16
    80002f52:	af248493          	addi	s1,s1,-1294 # 80018a40 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80002f56:	4979                	li	s2,30
    80002f58:	a029                	j	80002f62 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80002f5a:	85a6                	mv	a1,s1
    80002f5c:	8526                	mv	a0,s1
    80002f5e:	c2efe0ef          	jal	8000138c <sleep>
    if(log.committing){
    80002f62:	50dc                	lw	a5,36(s1)
    80002f64:	fbfd                	bnez	a5,80002f5a <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80002f66:	5098                	lw	a4,32(s1)
    80002f68:	2705                	addiw	a4,a4,1
    80002f6a:	0027179b          	slliw	a5,a4,0x2
    80002f6e:	9fb9                	addw	a5,a5,a4
    80002f70:	0017979b          	slliw	a5,a5,0x1
    80002f74:	54d4                	lw	a3,44(s1)
    80002f76:	9fb5                	addw	a5,a5,a3
    80002f78:	00f95763          	bge	s2,a5,80002f86 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80002f7c:	85a6                	mv	a1,s1
    80002f7e:	8526                	mv	a0,s1
    80002f80:	c0cfe0ef          	jal	8000138c <sleep>
    80002f84:	bff9                	j	80002f62 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80002f86:	00016797          	auipc	a5,0x16
    80002f8a:	ace7ad23          	sw	a4,-1318(a5) # 80018a60 <log+0x20>
      release(&log.lock);
    80002f8e:	00016517          	auipc	a0,0x16
    80002f92:	ab250513          	addi	a0,a0,-1358 # 80018a40 <log>
    80002f96:	714030ef          	jal	800066aa <release>
      break;
    }
  }
}
    80002f9a:	60e2                	ld	ra,24(sp)
    80002f9c:	6442                	ld	s0,16(sp)
    80002f9e:	64a2                	ld	s1,8(sp)
    80002fa0:	6902                	ld	s2,0(sp)
    80002fa2:	6105                	addi	sp,sp,32
    80002fa4:	8082                	ret

0000000080002fa6 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80002fa6:	7139                	addi	sp,sp,-64
    80002fa8:	fc06                	sd	ra,56(sp)
    80002faa:	f822                	sd	s0,48(sp)
    80002fac:	f426                	sd	s1,40(sp)
    80002fae:	f04a                	sd	s2,32(sp)
    80002fb0:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80002fb2:	00016497          	auipc	s1,0x16
    80002fb6:	a8e48493          	addi	s1,s1,-1394 # 80018a40 <log>
    80002fba:	8526                	mv	a0,s1
    80002fbc:	65a030ef          	jal	80006616 <acquire>
  log.outstanding -= 1;
    80002fc0:	509c                	lw	a5,32(s1)
    80002fc2:	37fd                	addiw	a5,a5,-1
    80002fc4:	893e                	mv	s2,a5
    80002fc6:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80002fc8:	50dc                	lw	a5,36(s1)
    80002fca:	e7b1                	bnez	a5,80003016 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80002fcc:	04091e63          	bnez	s2,80003028 <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    80002fd0:	00016497          	auipc	s1,0x16
    80002fd4:	a7048493          	addi	s1,s1,-1424 # 80018a40 <log>
    80002fd8:	4785                	li	a5,1
    80002fda:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80002fdc:	8526                	mv	a0,s1
    80002fde:	6cc030ef          	jal	800066aa <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80002fe2:	54dc                	lw	a5,44(s1)
    80002fe4:	06f04463          	bgtz	a5,8000304c <end_op+0xa6>
    acquire(&log.lock);
    80002fe8:	00016517          	auipc	a0,0x16
    80002fec:	a5850513          	addi	a0,a0,-1448 # 80018a40 <log>
    80002ff0:	626030ef          	jal	80006616 <acquire>
    log.committing = 0;
    80002ff4:	00016797          	auipc	a5,0x16
    80002ff8:	a607a823          	sw	zero,-1424(a5) # 80018a64 <log+0x24>
    wakeup(&log);
    80002ffc:	00016517          	auipc	a0,0x16
    80003000:	a4450513          	addi	a0,a0,-1468 # 80018a40 <log>
    80003004:	bd4fe0ef          	jal	800013d8 <wakeup>
    release(&log.lock);
    80003008:	00016517          	auipc	a0,0x16
    8000300c:	a3850513          	addi	a0,a0,-1480 # 80018a40 <log>
    80003010:	69a030ef          	jal	800066aa <release>
}
    80003014:	a035                	j	80003040 <end_op+0x9a>
    80003016:	ec4e                	sd	s3,24(sp)
    80003018:	e852                	sd	s4,16(sp)
    8000301a:	e456                	sd	s5,8(sp)
    panic("log.committing");
    8000301c:	00005517          	auipc	a0,0x5
    80003020:	4f450513          	addi	a0,a0,1268 # 80008510 <etext+0x510>
    80003024:	2b4030ef          	jal	800062d8 <panic>
    wakeup(&log);
    80003028:	00016517          	auipc	a0,0x16
    8000302c:	a1850513          	addi	a0,a0,-1512 # 80018a40 <log>
    80003030:	ba8fe0ef          	jal	800013d8 <wakeup>
  release(&log.lock);
    80003034:	00016517          	auipc	a0,0x16
    80003038:	a0c50513          	addi	a0,a0,-1524 # 80018a40 <log>
    8000303c:	66e030ef          	jal	800066aa <release>
}
    80003040:	70e2                	ld	ra,56(sp)
    80003042:	7442                	ld	s0,48(sp)
    80003044:	74a2                	ld	s1,40(sp)
    80003046:	7902                	ld	s2,32(sp)
    80003048:	6121                	addi	sp,sp,64
    8000304a:	8082                	ret
    8000304c:	ec4e                	sd	s3,24(sp)
    8000304e:	e852                	sd	s4,16(sp)
    80003050:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003052:	00016a97          	auipc	s5,0x16
    80003056:	a1ea8a93          	addi	s5,s5,-1506 # 80018a70 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    8000305a:	00016a17          	auipc	s4,0x16
    8000305e:	9e6a0a13          	addi	s4,s4,-1562 # 80018a40 <log>
    80003062:	018a2583          	lw	a1,24(s4)
    80003066:	012585bb          	addw	a1,a1,s2
    8000306a:	2585                	addiw	a1,a1,1
    8000306c:	028a2503          	lw	a0,40(s4)
    80003070:	f0dfe0ef          	jal	80001f7c <bread>
    80003074:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003076:	000aa583          	lw	a1,0(s5)
    8000307a:	028a2503          	lw	a0,40(s4)
    8000307e:	efffe0ef          	jal	80001f7c <bread>
    80003082:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003084:	40000613          	li	a2,1024
    80003088:	05850593          	addi	a1,a0,88
    8000308c:	05848513          	addi	a0,s1,88
    80003090:	92efd0ef          	jal	800001be <memmove>
    bwrite(to);  // write the log
    80003094:	8526                	mv	a0,s1
    80003096:	fbdfe0ef          	jal	80002052 <bwrite>
    brelse(from);
    8000309a:	854e                	mv	a0,s3
    8000309c:	fe9fe0ef          	jal	80002084 <brelse>
    brelse(to);
    800030a0:	8526                	mv	a0,s1
    800030a2:	fe3fe0ef          	jal	80002084 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800030a6:	2905                	addiw	s2,s2,1
    800030a8:	0a91                	addi	s5,s5,4
    800030aa:	02ca2783          	lw	a5,44(s4)
    800030ae:	faf94ae3          	blt	s2,a5,80003062 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800030b2:	cf5ff0ef          	jal	80002da6 <write_head>
    install_trans(0); // Now install writes to home locations
    800030b6:	4501                	li	a0,0
    800030b8:	d4dff0ef          	jal	80002e04 <install_trans>
    log.lh.n = 0;
    800030bc:	00016797          	auipc	a5,0x16
    800030c0:	9a07a823          	sw	zero,-1616(a5) # 80018a6c <log+0x2c>
    write_head();    // Erase the transaction from the log
    800030c4:	ce3ff0ef          	jal	80002da6 <write_head>
    800030c8:	69e2                	ld	s3,24(sp)
    800030ca:	6a42                	ld	s4,16(sp)
    800030cc:	6aa2                	ld	s5,8(sp)
    800030ce:	bf29                	j	80002fe8 <end_op+0x42>

00000000800030d0 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800030d0:	1101                	addi	sp,sp,-32
    800030d2:	ec06                	sd	ra,24(sp)
    800030d4:	e822                	sd	s0,16(sp)
    800030d6:	e426                	sd	s1,8(sp)
    800030d8:	1000                	addi	s0,sp,32
    800030da:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800030dc:	00016517          	auipc	a0,0x16
    800030e0:	96450513          	addi	a0,a0,-1692 # 80018a40 <log>
    800030e4:	532030ef          	jal	80006616 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800030e8:	00016617          	auipc	a2,0x16
    800030ec:	98462603          	lw	a2,-1660(a2) # 80018a6c <log+0x2c>
    800030f0:	47f5                	li	a5,29
    800030f2:	06c7c463          	blt	a5,a2,8000315a <log_write+0x8a>
    800030f6:	00016797          	auipc	a5,0x16
    800030fa:	9667a783          	lw	a5,-1690(a5) # 80018a5c <log+0x1c>
    800030fe:	37fd                	addiw	a5,a5,-1
    80003100:	04f65d63          	bge	a2,a5,8000315a <log_write+0x8a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003104:	00016797          	auipc	a5,0x16
    80003108:	95c7a783          	lw	a5,-1700(a5) # 80018a60 <log+0x20>
    8000310c:	04f05d63          	blez	a5,80003166 <log_write+0x96>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003110:	4781                	li	a5,0
    80003112:	06c05063          	blez	a2,80003172 <log_write+0xa2>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003116:	44cc                	lw	a1,12(s1)
    80003118:	00016717          	auipc	a4,0x16
    8000311c:	95870713          	addi	a4,a4,-1704 # 80018a70 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003120:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003122:	4314                	lw	a3,0(a4)
    80003124:	04b68763          	beq	a3,a1,80003172 <log_write+0xa2>
  for (i = 0; i < log.lh.n; i++) {
    80003128:	2785                	addiw	a5,a5,1
    8000312a:	0711                	addi	a4,a4,4
    8000312c:	fef61be3          	bne	a2,a5,80003122 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003130:	060a                	slli	a2,a2,0x2
    80003132:	02060613          	addi	a2,a2,32
    80003136:	00016797          	auipc	a5,0x16
    8000313a:	90a78793          	addi	a5,a5,-1782 # 80018a40 <log>
    8000313e:	97b2                	add	a5,a5,a2
    80003140:	44d8                	lw	a4,12(s1)
    80003142:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003144:	8526                	mv	a0,s1
    80003146:	fc3fe0ef          	jal	80002108 <bpin>
    log.lh.n++;
    8000314a:	00016717          	auipc	a4,0x16
    8000314e:	8f670713          	addi	a4,a4,-1802 # 80018a40 <log>
    80003152:	575c                	lw	a5,44(a4)
    80003154:	2785                	addiw	a5,a5,1
    80003156:	d75c                	sw	a5,44(a4)
    80003158:	a815                	j	8000318c <log_write+0xbc>
    panic("too big a transaction");
    8000315a:	00005517          	auipc	a0,0x5
    8000315e:	3c650513          	addi	a0,a0,966 # 80008520 <etext+0x520>
    80003162:	176030ef          	jal	800062d8 <panic>
    panic("log_write outside of trans");
    80003166:	00005517          	auipc	a0,0x5
    8000316a:	3d250513          	addi	a0,a0,978 # 80008538 <etext+0x538>
    8000316e:	16a030ef          	jal	800062d8 <panic>
  log.lh.block[i] = b->blockno;
    80003172:	00279693          	slli	a3,a5,0x2
    80003176:	02068693          	addi	a3,a3,32
    8000317a:	00016717          	auipc	a4,0x16
    8000317e:	8c670713          	addi	a4,a4,-1850 # 80018a40 <log>
    80003182:	9736                	add	a4,a4,a3
    80003184:	44d4                	lw	a3,12(s1)
    80003186:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003188:	faf60ee3          	beq	a2,a5,80003144 <log_write+0x74>
  }
  release(&log.lock);
    8000318c:	00016517          	auipc	a0,0x16
    80003190:	8b450513          	addi	a0,a0,-1868 # 80018a40 <log>
    80003194:	516030ef          	jal	800066aa <release>
}
    80003198:	60e2                	ld	ra,24(sp)
    8000319a:	6442                	ld	s0,16(sp)
    8000319c:	64a2                	ld	s1,8(sp)
    8000319e:	6105                	addi	sp,sp,32
    800031a0:	8082                	ret

00000000800031a2 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800031a2:	1101                	addi	sp,sp,-32
    800031a4:	ec06                	sd	ra,24(sp)
    800031a6:	e822                	sd	s0,16(sp)
    800031a8:	e426                	sd	s1,8(sp)
    800031aa:	e04a                	sd	s2,0(sp)
    800031ac:	1000                	addi	s0,sp,32
    800031ae:	84aa                	mv	s1,a0
    800031b0:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800031b2:	00005597          	auipc	a1,0x5
    800031b6:	3a658593          	addi	a1,a1,934 # 80008558 <etext+0x558>
    800031ba:	0521                	addi	a0,a0,8
    800031bc:	3d0030ef          	jal	8000658c <initlock>
  lk->name = name;
    800031c0:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800031c4:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800031c8:	0204a423          	sw	zero,40(s1)
}
    800031cc:	60e2                	ld	ra,24(sp)
    800031ce:	6442                	ld	s0,16(sp)
    800031d0:	64a2                	ld	s1,8(sp)
    800031d2:	6902                	ld	s2,0(sp)
    800031d4:	6105                	addi	sp,sp,32
    800031d6:	8082                	ret

00000000800031d8 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800031d8:	1101                	addi	sp,sp,-32
    800031da:	ec06                	sd	ra,24(sp)
    800031dc:	e822                	sd	s0,16(sp)
    800031de:	e426                	sd	s1,8(sp)
    800031e0:	e04a                	sd	s2,0(sp)
    800031e2:	1000                	addi	s0,sp,32
    800031e4:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800031e6:	00850913          	addi	s2,a0,8
    800031ea:	854a                	mv	a0,s2
    800031ec:	42a030ef          	jal	80006616 <acquire>
  while (lk->locked) {
    800031f0:	409c                	lw	a5,0(s1)
    800031f2:	c799                	beqz	a5,80003200 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    800031f4:	85ca                	mv	a1,s2
    800031f6:	8526                	mv	a0,s1
    800031f8:	994fe0ef          	jal	8000138c <sleep>
  while (lk->locked) {
    800031fc:	409c                	lw	a5,0(s1)
    800031fe:	fbfd                	bnez	a5,800031f4 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003200:	4785                	li	a5,1
    80003202:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003204:	bb7fd0ef          	jal	80000dba <myproc>
    80003208:	591c                	lw	a5,48(a0)
    8000320a:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    8000320c:	854a                	mv	a0,s2
    8000320e:	49c030ef          	jal	800066aa <release>
}
    80003212:	60e2                	ld	ra,24(sp)
    80003214:	6442                	ld	s0,16(sp)
    80003216:	64a2                	ld	s1,8(sp)
    80003218:	6902                	ld	s2,0(sp)
    8000321a:	6105                	addi	sp,sp,32
    8000321c:	8082                	ret

000000008000321e <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    8000321e:	1101                	addi	sp,sp,-32
    80003220:	ec06                	sd	ra,24(sp)
    80003222:	e822                	sd	s0,16(sp)
    80003224:	e426                	sd	s1,8(sp)
    80003226:	e04a                	sd	s2,0(sp)
    80003228:	1000                	addi	s0,sp,32
    8000322a:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000322c:	00850913          	addi	s2,a0,8
    80003230:	854a                	mv	a0,s2
    80003232:	3e4030ef          	jal	80006616 <acquire>
  lk->locked = 0;
    80003236:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000323a:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000323e:	8526                	mv	a0,s1
    80003240:	998fe0ef          	jal	800013d8 <wakeup>
  release(&lk->lk);
    80003244:	854a                	mv	a0,s2
    80003246:	464030ef          	jal	800066aa <release>
}
    8000324a:	60e2                	ld	ra,24(sp)
    8000324c:	6442                	ld	s0,16(sp)
    8000324e:	64a2                	ld	s1,8(sp)
    80003250:	6902                	ld	s2,0(sp)
    80003252:	6105                	addi	sp,sp,32
    80003254:	8082                	ret

0000000080003256 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003256:	7179                	addi	sp,sp,-48
    80003258:	f406                	sd	ra,40(sp)
    8000325a:	f022                	sd	s0,32(sp)
    8000325c:	ec26                	sd	s1,24(sp)
    8000325e:	e84a                	sd	s2,16(sp)
    80003260:	1800                	addi	s0,sp,48
    80003262:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003264:	00850913          	addi	s2,a0,8
    80003268:	854a                	mv	a0,s2
    8000326a:	3ac030ef          	jal	80006616 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000326e:	409c                	lw	a5,0(s1)
    80003270:	ef81                	bnez	a5,80003288 <holdingsleep+0x32>
    80003272:	4481                	li	s1,0
  release(&lk->lk);
    80003274:	854a                	mv	a0,s2
    80003276:	434030ef          	jal	800066aa <release>
  return r;
}
    8000327a:	8526                	mv	a0,s1
    8000327c:	70a2                	ld	ra,40(sp)
    8000327e:	7402                	ld	s0,32(sp)
    80003280:	64e2                	ld	s1,24(sp)
    80003282:	6942                	ld	s2,16(sp)
    80003284:	6145                	addi	sp,sp,48
    80003286:	8082                	ret
    80003288:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    8000328a:	0284a983          	lw	s3,40(s1)
    8000328e:	b2dfd0ef          	jal	80000dba <myproc>
    80003292:	5904                	lw	s1,48(a0)
    80003294:	413484b3          	sub	s1,s1,s3
    80003298:	0014b493          	seqz	s1,s1
    8000329c:	69a2                	ld	s3,8(sp)
    8000329e:	bfd9                	j	80003274 <holdingsleep+0x1e>

00000000800032a0 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800032a0:	1141                	addi	sp,sp,-16
    800032a2:	e406                	sd	ra,8(sp)
    800032a4:	e022                	sd	s0,0(sp)
    800032a6:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800032a8:	00005597          	auipc	a1,0x5
    800032ac:	2c058593          	addi	a1,a1,704 # 80008568 <etext+0x568>
    800032b0:	00016517          	auipc	a0,0x16
    800032b4:	8d850513          	addi	a0,a0,-1832 # 80018b88 <ftable>
    800032b8:	2d4030ef          	jal	8000658c <initlock>
}
    800032bc:	60a2                	ld	ra,8(sp)
    800032be:	6402                	ld	s0,0(sp)
    800032c0:	0141                	addi	sp,sp,16
    800032c2:	8082                	ret

00000000800032c4 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    800032c4:	1101                	addi	sp,sp,-32
    800032c6:	ec06                	sd	ra,24(sp)
    800032c8:	e822                	sd	s0,16(sp)
    800032ca:	e426                	sd	s1,8(sp)
    800032cc:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800032ce:	00016517          	auipc	a0,0x16
    800032d2:	8ba50513          	addi	a0,a0,-1862 # 80018b88 <ftable>
    800032d6:	340030ef          	jal	80006616 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800032da:	00016497          	auipc	s1,0x16
    800032de:	8c648493          	addi	s1,s1,-1850 # 80018ba0 <ftable+0x18>
    800032e2:	00017717          	auipc	a4,0x17
    800032e6:	85e70713          	addi	a4,a4,-1954 # 80019b40 <disk>
    if(f->ref == 0){
    800032ea:	40dc                	lw	a5,4(s1)
    800032ec:	cf89                	beqz	a5,80003306 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800032ee:	02848493          	addi	s1,s1,40
    800032f2:	fee49ce3          	bne	s1,a4,800032ea <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800032f6:	00016517          	auipc	a0,0x16
    800032fa:	89250513          	addi	a0,a0,-1902 # 80018b88 <ftable>
    800032fe:	3ac030ef          	jal	800066aa <release>
  return 0;
    80003302:	4481                	li	s1,0
    80003304:	a809                	j	80003316 <filealloc+0x52>
      f->ref = 1;
    80003306:	4785                	li	a5,1
    80003308:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    8000330a:	00016517          	auipc	a0,0x16
    8000330e:	87e50513          	addi	a0,a0,-1922 # 80018b88 <ftable>
    80003312:	398030ef          	jal	800066aa <release>
}
    80003316:	8526                	mv	a0,s1
    80003318:	60e2                	ld	ra,24(sp)
    8000331a:	6442                	ld	s0,16(sp)
    8000331c:	64a2                	ld	s1,8(sp)
    8000331e:	6105                	addi	sp,sp,32
    80003320:	8082                	ret

0000000080003322 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003322:	1101                	addi	sp,sp,-32
    80003324:	ec06                	sd	ra,24(sp)
    80003326:	e822                	sd	s0,16(sp)
    80003328:	e426                	sd	s1,8(sp)
    8000332a:	1000                	addi	s0,sp,32
    8000332c:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000332e:	00016517          	auipc	a0,0x16
    80003332:	85a50513          	addi	a0,a0,-1958 # 80018b88 <ftable>
    80003336:	2e0030ef          	jal	80006616 <acquire>
  if(f->ref < 1)
    8000333a:	40dc                	lw	a5,4(s1)
    8000333c:	02f05063          	blez	a5,8000335c <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003340:	2785                	addiw	a5,a5,1
    80003342:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003344:	00016517          	auipc	a0,0x16
    80003348:	84450513          	addi	a0,a0,-1980 # 80018b88 <ftable>
    8000334c:	35e030ef          	jal	800066aa <release>
  return f;
}
    80003350:	8526                	mv	a0,s1
    80003352:	60e2                	ld	ra,24(sp)
    80003354:	6442                	ld	s0,16(sp)
    80003356:	64a2                	ld	s1,8(sp)
    80003358:	6105                	addi	sp,sp,32
    8000335a:	8082                	ret
    panic("filedup");
    8000335c:	00005517          	auipc	a0,0x5
    80003360:	21450513          	addi	a0,a0,532 # 80008570 <etext+0x570>
    80003364:	775020ef          	jal	800062d8 <panic>

0000000080003368 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003368:	7139                	addi	sp,sp,-64
    8000336a:	fc06                	sd	ra,56(sp)
    8000336c:	f822                	sd	s0,48(sp)
    8000336e:	f426                	sd	s1,40(sp)
    80003370:	0080                	addi	s0,sp,64
    80003372:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003374:	00016517          	auipc	a0,0x16
    80003378:	81450513          	addi	a0,a0,-2028 # 80018b88 <ftable>
    8000337c:	29a030ef          	jal	80006616 <acquire>
  if(f->ref < 1)
    80003380:	40dc                	lw	a5,4(s1)
    80003382:	04f05a63          	blez	a5,800033d6 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    80003386:	37fd                	addiw	a5,a5,-1
    80003388:	c0dc                	sw	a5,4(s1)
    8000338a:	06f04063          	bgtz	a5,800033ea <fileclose+0x82>
    8000338e:	f04a                	sd	s2,32(sp)
    80003390:	ec4e                	sd	s3,24(sp)
    80003392:	e852                	sd	s4,16(sp)
    80003394:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003396:	0004a903          	lw	s2,0(s1)
    8000339a:	0094c783          	lbu	a5,9(s1)
    8000339e:	89be                	mv	s3,a5
    800033a0:	689c                	ld	a5,16(s1)
    800033a2:	8a3e                	mv	s4,a5
    800033a4:	6c9c                	ld	a5,24(s1)
    800033a6:	8abe                	mv	s5,a5
  f->ref = 0;
    800033a8:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800033ac:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800033b0:	00015517          	auipc	a0,0x15
    800033b4:	7d850513          	addi	a0,a0,2008 # 80018b88 <ftable>
    800033b8:	2f2030ef          	jal	800066aa <release>

  if(ff.type == FD_PIPE){
    800033bc:	4785                	li	a5,1
    800033be:	04f90163          	beq	s2,a5,80003400 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800033c2:	ffe9079b          	addiw	a5,s2,-2
    800033c6:	4705                	li	a4,1
    800033c8:	04f77563          	bgeu	a4,a5,80003412 <fileclose+0xaa>
    800033cc:	7902                	ld	s2,32(sp)
    800033ce:	69e2                	ld	s3,24(sp)
    800033d0:	6a42                	ld	s4,16(sp)
    800033d2:	6aa2                	ld	s5,8(sp)
    800033d4:	a00d                	j	800033f6 <fileclose+0x8e>
    800033d6:	f04a                	sd	s2,32(sp)
    800033d8:	ec4e                	sd	s3,24(sp)
    800033da:	e852                	sd	s4,16(sp)
    800033dc:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800033de:	00005517          	auipc	a0,0x5
    800033e2:	19a50513          	addi	a0,a0,410 # 80008578 <etext+0x578>
    800033e6:	6f3020ef          	jal	800062d8 <panic>
    release(&ftable.lock);
    800033ea:	00015517          	auipc	a0,0x15
    800033ee:	79e50513          	addi	a0,a0,1950 # 80018b88 <ftable>
    800033f2:	2b8030ef          	jal	800066aa <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800033f6:	70e2                	ld	ra,56(sp)
    800033f8:	7442                	ld	s0,48(sp)
    800033fa:	74a2                	ld	s1,40(sp)
    800033fc:	6121                	addi	sp,sp,64
    800033fe:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80003400:	85ce                	mv	a1,s3
    80003402:	8552                	mv	a0,s4
    80003404:	348000ef          	jal	8000374c <pipeclose>
    80003408:	7902                	ld	s2,32(sp)
    8000340a:	69e2                	ld	s3,24(sp)
    8000340c:	6a42                	ld	s4,16(sp)
    8000340e:	6aa2                	ld	s5,8(sp)
    80003410:	b7dd                	j	800033f6 <fileclose+0x8e>
    begin_op();
    80003412:	b25ff0ef          	jal	80002f36 <begin_op>
    iput(ff.ip);
    80003416:	8556                	mv	a0,s5
    80003418:	be8ff0ef          	jal	80002800 <iput>
    end_op();
    8000341c:	b8bff0ef          	jal	80002fa6 <end_op>
    80003420:	7902                	ld	s2,32(sp)
    80003422:	69e2                	ld	s3,24(sp)
    80003424:	6a42                	ld	s4,16(sp)
    80003426:	6aa2                	ld	s5,8(sp)
    80003428:	b7f9                	j	800033f6 <fileclose+0x8e>

000000008000342a <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000342a:	715d                	addi	sp,sp,-80
    8000342c:	e486                	sd	ra,72(sp)
    8000342e:	e0a2                	sd	s0,64(sp)
    80003430:	fc26                	sd	s1,56(sp)
    80003432:	f052                	sd	s4,32(sp)
    80003434:	0880                	addi	s0,sp,80
    80003436:	84aa                	mv	s1,a0
    80003438:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    8000343a:	981fd0ef          	jal	80000dba <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    8000343e:	409c                	lw	a5,0(s1)
    80003440:	37f9                	addiw	a5,a5,-2
    80003442:	4705                	li	a4,1
    80003444:	04f76263          	bltu	a4,a5,80003488 <filestat+0x5e>
    80003448:	f84a                	sd	s2,48(sp)
    8000344a:	f44e                	sd	s3,40(sp)
    8000344c:	89aa                	mv	s3,a0
    ilock(f->ip);
    8000344e:	6c88                	ld	a0,24(s1)
    80003450:	a2eff0ef          	jal	8000267e <ilock>
    stati(f->ip, &st);
    80003454:	fb840913          	addi	s2,s0,-72
    80003458:	85ca                	mv	a1,s2
    8000345a:	6c88                	ld	a0,24(s1)
    8000345c:	c4eff0ef          	jal	800028aa <stati>
    iunlock(f->ip);
    80003460:	6c88                	ld	a0,24(s1)
    80003462:	acaff0ef          	jal	8000272c <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003466:	46e1                	li	a3,24
    80003468:	864a                	mv	a2,s2
    8000346a:	85d2                	mv	a1,s4
    8000346c:	0509b503          	ld	a0,80(s3)
    80003470:	dcefd0ef          	jal	80000a3e <copyout>
    80003474:	41f5551b          	sraiw	a0,a0,0x1f
    80003478:	7942                	ld	s2,48(sp)
    8000347a:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    8000347c:	60a6                	ld	ra,72(sp)
    8000347e:	6406                	ld	s0,64(sp)
    80003480:	74e2                	ld	s1,56(sp)
    80003482:	7a02                	ld	s4,32(sp)
    80003484:	6161                	addi	sp,sp,80
    80003486:	8082                	ret
  return -1;
    80003488:	557d                	li	a0,-1
    8000348a:	bfcd                	j	8000347c <filestat+0x52>

000000008000348c <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000348c:	7179                	addi	sp,sp,-48
    8000348e:	f406                	sd	ra,40(sp)
    80003490:	f022                	sd	s0,32(sp)
    80003492:	e84a                	sd	s2,16(sp)
    80003494:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003496:	00854783          	lbu	a5,8(a0)
    8000349a:	cfd1                	beqz	a5,80003536 <fileread+0xaa>
    8000349c:	ec26                	sd	s1,24(sp)
    8000349e:	e44e                	sd	s3,8(sp)
    800034a0:	84aa                	mv	s1,a0
    800034a2:	892e                	mv	s2,a1
    800034a4:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    800034a6:	411c                	lw	a5,0(a0)
    800034a8:	4705                	li	a4,1
    800034aa:	04e78363          	beq	a5,a4,800034f0 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800034ae:	470d                	li	a4,3
    800034b0:	04e78763          	beq	a5,a4,800034fe <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800034b4:	4709                	li	a4,2
    800034b6:	06e79a63          	bne	a5,a4,8000352a <fileread+0x9e>
    ilock(f->ip);
    800034ba:	6d08                	ld	a0,24(a0)
    800034bc:	9c2ff0ef          	jal	8000267e <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800034c0:	874e                	mv	a4,s3
    800034c2:	5094                	lw	a3,32(s1)
    800034c4:	864a                	mv	a2,s2
    800034c6:	4585                	li	a1,1
    800034c8:	6c88                	ld	a0,24(s1)
    800034ca:	c0eff0ef          	jal	800028d8 <readi>
    800034ce:	892a                	mv	s2,a0
    800034d0:	00a05563          	blez	a0,800034da <fileread+0x4e>
      f->off += r;
    800034d4:	509c                	lw	a5,32(s1)
    800034d6:	9fa9                	addw	a5,a5,a0
    800034d8:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800034da:	6c88                	ld	a0,24(s1)
    800034dc:	a50ff0ef          	jal	8000272c <iunlock>
    800034e0:	64e2                	ld	s1,24(sp)
    800034e2:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800034e4:	854a                	mv	a0,s2
    800034e6:	70a2                	ld	ra,40(sp)
    800034e8:	7402                	ld	s0,32(sp)
    800034ea:	6942                	ld	s2,16(sp)
    800034ec:	6145                	addi	sp,sp,48
    800034ee:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800034f0:	6908                	ld	a0,16(a0)
    800034f2:	3b0000ef          	jal	800038a2 <piperead>
    800034f6:	892a                	mv	s2,a0
    800034f8:	64e2                	ld	s1,24(sp)
    800034fa:	69a2                	ld	s3,8(sp)
    800034fc:	b7e5                	j	800034e4 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800034fe:	02451783          	lh	a5,36(a0)
    80003502:	03079693          	slli	a3,a5,0x30
    80003506:	92c1                	srli	a3,a3,0x30
    80003508:	4725                	li	a4,9
    8000350a:	02d76963          	bltu	a4,a3,8000353c <fileread+0xb0>
    8000350e:	0792                	slli	a5,a5,0x4
    80003510:	00015717          	auipc	a4,0x15
    80003514:	5d870713          	addi	a4,a4,1496 # 80018ae8 <devsw>
    80003518:	97ba                	add	a5,a5,a4
    8000351a:	639c                	ld	a5,0(a5)
    8000351c:	c78d                	beqz	a5,80003546 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    8000351e:	4505                	li	a0,1
    80003520:	9782                	jalr	a5
    80003522:	892a                	mv	s2,a0
    80003524:	64e2                	ld	s1,24(sp)
    80003526:	69a2                	ld	s3,8(sp)
    80003528:	bf75                	j	800034e4 <fileread+0x58>
    panic("fileread");
    8000352a:	00005517          	auipc	a0,0x5
    8000352e:	05e50513          	addi	a0,a0,94 # 80008588 <etext+0x588>
    80003532:	5a7020ef          	jal	800062d8 <panic>
    return -1;
    80003536:	57fd                	li	a5,-1
    80003538:	893e                	mv	s2,a5
    8000353a:	b76d                	j	800034e4 <fileread+0x58>
      return -1;
    8000353c:	57fd                	li	a5,-1
    8000353e:	893e                	mv	s2,a5
    80003540:	64e2                	ld	s1,24(sp)
    80003542:	69a2                	ld	s3,8(sp)
    80003544:	b745                	j	800034e4 <fileread+0x58>
    80003546:	57fd                	li	a5,-1
    80003548:	893e                	mv	s2,a5
    8000354a:	64e2                	ld	s1,24(sp)
    8000354c:	69a2                	ld	s3,8(sp)
    8000354e:	bf59                	j	800034e4 <fileread+0x58>

0000000080003550 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80003550:	00954783          	lbu	a5,9(a0)
    80003554:	10078f63          	beqz	a5,80003672 <filewrite+0x122>
{
    80003558:	711d                	addi	sp,sp,-96
    8000355a:	ec86                	sd	ra,88(sp)
    8000355c:	e8a2                	sd	s0,80(sp)
    8000355e:	e0ca                	sd	s2,64(sp)
    80003560:	f456                	sd	s5,40(sp)
    80003562:	f05a                	sd	s6,32(sp)
    80003564:	1080                	addi	s0,sp,96
    80003566:	892a                	mv	s2,a0
    80003568:	8b2e                	mv	s6,a1
    8000356a:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    8000356c:	411c                	lw	a5,0(a0)
    8000356e:	4705                	li	a4,1
    80003570:	02e78a63          	beq	a5,a4,800035a4 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003574:	470d                	li	a4,3
    80003576:	02e78b63          	beq	a5,a4,800035ac <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    8000357a:	4709                	li	a4,2
    8000357c:	0ce79f63          	bne	a5,a4,8000365a <filewrite+0x10a>
    80003580:	f852                	sd	s4,48(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80003582:	0ac05a63          	blez	a2,80003636 <filewrite+0xe6>
    80003586:	e4a6                	sd	s1,72(sp)
    80003588:	fc4e                	sd	s3,56(sp)
    8000358a:	ec5e                	sd	s7,24(sp)
    8000358c:	e862                	sd	s8,16(sp)
    8000358e:	e466                	sd	s9,8(sp)
    int i = 0;
    80003590:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    80003592:	6b85                	lui	s7,0x1
    80003594:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80003598:	6785                	lui	a5,0x1
    8000359a:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    8000359e:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800035a0:	4c05                	li	s8,1
    800035a2:	a8ad                	j	8000361c <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800035a4:	6908                	ld	a0,16(a0)
    800035a6:	204000ef          	jal	800037aa <pipewrite>
    800035aa:	a04d                	j	8000364c <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800035ac:	02451783          	lh	a5,36(a0)
    800035b0:	03079693          	slli	a3,a5,0x30
    800035b4:	92c1                	srli	a3,a3,0x30
    800035b6:	4725                	li	a4,9
    800035b8:	0ad76f63          	bltu	a4,a3,80003676 <filewrite+0x126>
    800035bc:	0792                	slli	a5,a5,0x4
    800035be:	00015717          	auipc	a4,0x15
    800035c2:	52a70713          	addi	a4,a4,1322 # 80018ae8 <devsw>
    800035c6:	97ba                	add	a5,a5,a4
    800035c8:	679c                	ld	a5,8(a5)
    800035ca:	cbc5                	beqz	a5,8000367a <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    800035cc:	4505                	li	a0,1
    800035ce:	9782                	jalr	a5
    800035d0:	a8b5                	j	8000364c <filewrite+0xfc>
      if(n1 > max)
    800035d2:	2981                	sext.w	s3,s3
      begin_op();
    800035d4:	963ff0ef          	jal	80002f36 <begin_op>
      ilock(f->ip);
    800035d8:	01893503          	ld	a0,24(s2)
    800035dc:	8a2ff0ef          	jal	8000267e <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800035e0:	874e                	mv	a4,s3
    800035e2:	02092683          	lw	a3,32(s2)
    800035e6:	016a0633          	add	a2,s4,s6
    800035ea:	85e2                	mv	a1,s8
    800035ec:	01893503          	ld	a0,24(s2)
    800035f0:	bdaff0ef          	jal	800029ca <writei>
    800035f4:	84aa                	mv	s1,a0
    800035f6:	00a05763          	blez	a0,80003604 <filewrite+0xb4>
        f->off += r;
    800035fa:	02092783          	lw	a5,32(s2)
    800035fe:	9fa9                	addw	a5,a5,a0
    80003600:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80003604:	01893503          	ld	a0,24(s2)
    80003608:	924ff0ef          	jal	8000272c <iunlock>
      end_op();
    8000360c:	99bff0ef          	jal	80002fa6 <end_op>

      if(r != n1){
    80003610:	02999563          	bne	s3,s1,8000363a <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    80003614:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80003618:	015a5963          	bge	s4,s5,8000362a <filewrite+0xda>
      int n1 = n - i;
    8000361c:	414a87bb          	subw	a5,s5,s4
    80003620:	89be                	mv	s3,a5
      if(n1 > max)
    80003622:	fafbd8e3          	bge	s7,a5,800035d2 <filewrite+0x82>
    80003626:	89e6                	mv	s3,s9
    80003628:	b76d                	j	800035d2 <filewrite+0x82>
    8000362a:	64a6                	ld	s1,72(sp)
    8000362c:	79e2                	ld	s3,56(sp)
    8000362e:	6be2                	ld	s7,24(sp)
    80003630:	6c42                	ld	s8,16(sp)
    80003632:	6ca2                	ld	s9,8(sp)
    80003634:	a801                	j	80003644 <filewrite+0xf4>
    int i = 0;
    80003636:	4a01                	li	s4,0
    80003638:	a031                	j	80003644 <filewrite+0xf4>
    8000363a:	64a6                	ld	s1,72(sp)
    8000363c:	79e2                	ld	s3,56(sp)
    8000363e:	6be2                	ld	s7,24(sp)
    80003640:	6c42                	ld	s8,16(sp)
    80003642:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    80003644:	034a9d63          	bne	s5,s4,8000367e <filewrite+0x12e>
    80003648:	8556                	mv	a0,s5
    8000364a:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000364c:	60e6                	ld	ra,88(sp)
    8000364e:	6446                	ld	s0,80(sp)
    80003650:	6906                	ld	s2,64(sp)
    80003652:	7aa2                	ld	s5,40(sp)
    80003654:	7b02                	ld	s6,32(sp)
    80003656:	6125                	addi	sp,sp,96
    80003658:	8082                	ret
    8000365a:	e4a6                	sd	s1,72(sp)
    8000365c:	fc4e                	sd	s3,56(sp)
    8000365e:	f852                	sd	s4,48(sp)
    80003660:	ec5e                	sd	s7,24(sp)
    80003662:	e862                	sd	s8,16(sp)
    80003664:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80003666:	00005517          	auipc	a0,0x5
    8000366a:	f3250513          	addi	a0,a0,-206 # 80008598 <etext+0x598>
    8000366e:	46b020ef          	jal	800062d8 <panic>
    return -1;
    80003672:	557d                	li	a0,-1
}
    80003674:	8082                	ret
      return -1;
    80003676:	557d                	li	a0,-1
    80003678:	bfd1                	j	8000364c <filewrite+0xfc>
    8000367a:	557d                	li	a0,-1
    8000367c:	bfc1                	j	8000364c <filewrite+0xfc>
    ret = (i == n ? n : -1);
    8000367e:	557d                	li	a0,-1
    80003680:	7a42                	ld	s4,48(sp)
    80003682:	b7e9                	j	8000364c <filewrite+0xfc>

0000000080003684 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80003684:	7179                	addi	sp,sp,-48
    80003686:	f406                	sd	ra,40(sp)
    80003688:	f022                	sd	s0,32(sp)
    8000368a:	ec26                	sd	s1,24(sp)
    8000368c:	e052                	sd	s4,0(sp)
    8000368e:	1800                	addi	s0,sp,48
    80003690:	84aa                	mv	s1,a0
    80003692:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80003694:	0005b023          	sd	zero,0(a1)
    80003698:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    8000369c:	c29ff0ef          	jal	800032c4 <filealloc>
    800036a0:	e088                	sd	a0,0(s1)
    800036a2:	c549                	beqz	a0,8000372c <pipealloc+0xa8>
    800036a4:	c21ff0ef          	jal	800032c4 <filealloc>
    800036a8:	00aa3023          	sd	a0,0(s4)
    800036ac:	cd25                	beqz	a0,80003724 <pipealloc+0xa0>
    800036ae:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800036b0:	a55fc0ef          	jal	80000104 <kalloc>
    800036b4:	892a                	mv	s2,a0
    800036b6:	c12d                	beqz	a0,80003718 <pipealloc+0x94>
    800036b8:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800036ba:	4985                	li	s3,1
    800036bc:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800036c0:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800036c4:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800036c8:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800036cc:	00005597          	auipc	a1,0x5
    800036d0:	edc58593          	addi	a1,a1,-292 # 800085a8 <etext+0x5a8>
    800036d4:	6b9020ef          	jal	8000658c <initlock>
  (*f0)->type = FD_PIPE;
    800036d8:	609c                	ld	a5,0(s1)
    800036da:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800036de:	609c                	ld	a5,0(s1)
    800036e0:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800036e4:	609c                	ld	a5,0(s1)
    800036e6:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800036ea:	609c                	ld	a5,0(s1)
    800036ec:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800036f0:	000a3783          	ld	a5,0(s4)
    800036f4:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800036f8:	000a3783          	ld	a5,0(s4)
    800036fc:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80003700:	000a3783          	ld	a5,0(s4)
    80003704:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80003708:	000a3783          	ld	a5,0(s4)
    8000370c:	0127b823          	sd	s2,16(a5)
  return 0;
    80003710:	4501                	li	a0,0
    80003712:	6942                	ld	s2,16(sp)
    80003714:	69a2                	ld	s3,8(sp)
    80003716:	a01d                	j	8000373c <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80003718:	6088                	ld	a0,0(s1)
    8000371a:	c119                	beqz	a0,80003720 <pipealloc+0x9c>
    8000371c:	6942                	ld	s2,16(sp)
    8000371e:	a029                	j	80003728 <pipealloc+0xa4>
    80003720:	6942                	ld	s2,16(sp)
    80003722:	a029                	j	8000372c <pipealloc+0xa8>
    80003724:	6088                	ld	a0,0(s1)
    80003726:	c10d                	beqz	a0,80003748 <pipealloc+0xc4>
    fileclose(*f0);
    80003728:	c41ff0ef          	jal	80003368 <fileclose>
  if(*f1)
    8000372c:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80003730:	557d                	li	a0,-1
  if(*f1)
    80003732:	c789                	beqz	a5,8000373c <pipealloc+0xb8>
    fileclose(*f1);
    80003734:	853e                	mv	a0,a5
    80003736:	c33ff0ef          	jal	80003368 <fileclose>
  return -1;
    8000373a:	557d                	li	a0,-1
}
    8000373c:	70a2                	ld	ra,40(sp)
    8000373e:	7402                	ld	s0,32(sp)
    80003740:	64e2                	ld	s1,24(sp)
    80003742:	6a02                	ld	s4,0(sp)
    80003744:	6145                	addi	sp,sp,48
    80003746:	8082                	ret
  return -1;
    80003748:	557d                	li	a0,-1
    8000374a:	bfcd                	j	8000373c <pipealloc+0xb8>

000000008000374c <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    8000374c:	1101                	addi	sp,sp,-32
    8000374e:	ec06                	sd	ra,24(sp)
    80003750:	e822                	sd	s0,16(sp)
    80003752:	e426                	sd	s1,8(sp)
    80003754:	e04a                	sd	s2,0(sp)
    80003756:	1000                	addi	s0,sp,32
    80003758:	84aa                	mv	s1,a0
    8000375a:	892e                	mv	s2,a1
  acquire(&pi->lock);
    8000375c:	6bb020ef          	jal	80006616 <acquire>
  if(writable){
    80003760:	02090763          	beqz	s2,8000378e <pipeclose+0x42>
    pi->writeopen = 0;
    80003764:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80003768:	21848513          	addi	a0,s1,536
    8000376c:	c6dfd0ef          	jal	800013d8 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80003770:	2204a783          	lw	a5,544(s1)
    80003774:	e781                	bnez	a5,8000377c <pipeclose+0x30>
    80003776:	2244a783          	lw	a5,548(s1)
    8000377a:	c38d                	beqz	a5,8000379c <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    8000377c:	8526                	mv	a0,s1
    8000377e:	72d020ef          	jal	800066aa <release>
}
    80003782:	60e2                	ld	ra,24(sp)
    80003784:	6442                	ld	s0,16(sp)
    80003786:	64a2                	ld	s1,8(sp)
    80003788:	6902                	ld	s2,0(sp)
    8000378a:	6105                	addi	sp,sp,32
    8000378c:	8082                	ret
    pi->readopen = 0;
    8000378e:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80003792:	21c48513          	addi	a0,s1,540
    80003796:	c43fd0ef          	jal	800013d8 <wakeup>
    8000379a:	bfd9                	j	80003770 <pipeclose+0x24>
    release(&pi->lock);
    8000379c:	8526                	mv	a0,s1
    8000379e:	70d020ef          	jal	800066aa <release>
    kfree((char*)pi);
    800037a2:	8526                	mv	a0,s1
    800037a4:	879fc0ef          	jal	8000001c <kfree>
    800037a8:	bfe9                	j	80003782 <pipeclose+0x36>

00000000800037aa <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800037aa:	7159                	addi	sp,sp,-112
    800037ac:	f486                	sd	ra,104(sp)
    800037ae:	f0a2                	sd	s0,96(sp)
    800037b0:	eca6                	sd	s1,88(sp)
    800037b2:	e8ca                	sd	s2,80(sp)
    800037b4:	e4ce                	sd	s3,72(sp)
    800037b6:	e0d2                	sd	s4,64(sp)
    800037b8:	fc56                	sd	s5,56(sp)
    800037ba:	1880                	addi	s0,sp,112
    800037bc:	84aa                	mv	s1,a0
    800037be:	8aae                	mv	s5,a1
    800037c0:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800037c2:	df8fd0ef          	jal	80000dba <myproc>
    800037c6:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800037c8:	8526                	mv	a0,s1
    800037ca:	64d020ef          	jal	80006616 <acquire>
  while(i < n){
    800037ce:	0d405263          	blez	s4,80003892 <pipewrite+0xe8>
    800037d2:	f85a                	sd	s6,48(sp)
    800037d4:	f45e                	sd	s7,40(sp)
    800037d6:	f062                	sd	s8,32(sp)
    800037d8:	ec66                	sd	s9,24(sp)
    800037da:	e86a                	sd	s10,16(sp)
  int i = 0;
    800037dc:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800037de:	f9f40c13          	addi	s8,s0,-97
    800037e2:	4b85                	li	s7,1
    800037e4:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800037e6:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    800037ea:	21c48c93          	addi	s9,s1,540
    800037ee:	a82d                	j	80003828 <pipewrite+0x7e>
      release(&pi->lock);
    800037f0:	8526                	mv	a0,s1
    800037f2:	6b9020ef          	jal	800066aa <release>
      return -1;
    800037f6:	597d                	li	s2,-1
    800037f8:	7b42                	ld	s6,48(sp)
    800037fa:	7ba2                	ld	s7,40(sp)
    800037fc:	7c02                	ld	s8,32(sp)
    800037fe:	6ce2                	ld	s9,24(sp)
    80003800:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80003802:	854a                	mv	a0,s2
    80003804:	70a6                	ld	ra,104(sp)
    80003806:	7406                	ld	s0,96(sp)
    80003808:	64e6                	ld	s1,88(sp)
    8000380a:	6946                	ld	s2,80(sp)
    8000380c:	69a6                	ld	s3,72(sp)
    8000380e:	6a06                	ld	s4,64(sp)
    80003810:	7ae2                	ld	s5,56(sp)
    80003812:	6165                	addi	sp,sp,112
    80003814:	8082                	ret
      wakeup(&pi->nread);
    80003816:	856a                	mv	a0,s10
    80003818:	bc1fd0ef          	jal	800013d8 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    8000381c:	85a6                	mv	a1,s1
    8000381e:	8566                	mv	a0,s9
    80003820:	b6dfd0ef          	jal	8000138c <sleep>
  while(i < n){
    80003824:	05495a63          	bge	s2,s4,80003878 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80003828:	2204a783          	lw	a5,544(s1)
    8000382c:	d3f1                	beqz	a5,800037f0 <pipewrite+0x46>
    8000382e:	854e                	mv	a0,s3
    80003830:	d99fd0ef          	jal	800015c8 <killed>
    80003834:	fd55                	bnez	a0,800037f0 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80003836:	2184a783          	lw	a5,536(s1)
    8000383a:	21c4a703          	lw	a4,540(s1)
    8000383e:	2007879b          	addiw	a5,a5,512
    80003842:	fcf70ae3          	beq	a4,a5,80003816 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003846:	86de                	mv	a3,s7
    80003848:	01590633          	add	a2,s2,s5
    8000384c:	85e2                	mv	a1,s8
    8000384e:	0509b503          	ld	a0,80(s3)
    80003852:	a9cfd0ef          	jal	80000aee <copyin>
    80003856:	05650063          	beq	a0,s6,80003896 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000385a:	21c4a783          	lw	a5,540(s1)
    8000385e:	0017871b          	addiw	a4,a5,1
    80003862:	20e4ae23          	sw	a4,540(s1)
    80003866:	1ff7f793          	andi	a5,a5,511
    8000386a:	97a6                	add	a5,a5,s1
    8000386c:	f9f44703          	lbu	a4,-97(s0)
    80003870:	00e78c23          	sb	a4,24(a5)
      i++;
    80003874:	2905                	addiw	s2,s2,1
    80003876:	b77d                	j	80003824 <pipewrite+0x7a>
    80003878:	7b42                	ld	s6,48(sp)
    8000387a:	7ba2                	ld	s7,40(sp)
    8000387c:	7c02                	ld	s8,32(sp)
    8000387e:	6ce2                	ld	s9,24(sp)
    80003880:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80003882:	21848513          	addi	a0,s1,536
    80003886:	b53fd0ef          	jal	800013d8 <wakeup>
  release(&pi->lock);
    8000388a:	8526                	mv	a0,s1
    8000388c:	61f020ef          	jal	800066aa <release>
  return i;
    80003890:	bf8d                	j	80003802 <pipewrite+0x58>
  int i = 0;
    80003892:	4901                	li	s2,0
    80003894:	b7fd                	j	80003882 <pipewrite+0xd8>
    80003896:	7b42                	ld	s6,48(sp)
    80003898:	7ba2                	ld	s7,40(sp)
    8000389a:	7c02                	ld	s8,32(sp)
    8000389c:	6ce2                	ld	s9,24(sp)
    8000389e:	6d42                	ld	s10,16(sp)
    800038a0:	b7cd                	j	80003882 <pipewrite+0xd8>

00000000800038a2 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800038a2:	711d                	addi	sp,sp,-96
    800038a4:	ec86                	sd	ra,88(sp)
    800038a6:	e8a2                	sd	s0,80(sp)
    800038a8:	e4a6                	sd	s1,72(sp)
    800038aa:	e0ca                	sd	s2,64(sp)
    800038ac:	fc4e                	sd	s3,56(sp)
    800038ae:	f852                	sd	s4,48(sp)
    800038b0:	f456                	sd	s5,40(sp)
    800038b2:	1080                	addi	s0,sp,96
    800038b4:	84aa                	mv	s1,a0
    800038b6:	892e                	mv	s2,a1
    800038b8:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800038ba:	d00fd0ef          	jal	80000dba <myproc>
    800038be:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800038c0:	8526                	mv	a0,s1
    800038c2:	555020ef          	jal	80006616 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800038c6:	2184a703          	lw	a4,536(s1)
    800038ca:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800038ce:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800038d2:	02f71763          	bne	a4,a5,80003900 <piperead+0x5e>
    800038d6:	2244a783          	lw	a5,548(s1)
    800038da:	cf85                	beqz	a5,80003912 <piperead+0x70>
    if(killed(pr)){
    800038dc:	8552                	mv	a0,s4
    800038de:	cebfd0ef          	jal	800015c8 <killed>
    800038e2:	e11d                	bnez	a0,80003908 <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800038e4:	85a6                	mv	a1,s1
    800038e6:	854e                	mv	a0,s3
    800038e8:	aa5fd0ef          	jal	8000138c <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800038ec:	2184a703          	lw	a4,536(s1)
    800038f0:	21c4a783          	lw	a5,540(s1)
    800038f4:	fef701e3          	beq	a4,a5,800038d6 <piperead+0x34>
    800038f8:	f05a                	sd	s6,32(sp)
    800038fa:	ec5e                	sd	s7,24(sp)
    800038fc:	e862                	sd	s8,16(sp)
    800038fe:	a829                	j	80003918 <piperead+0x76>
    80003900:	f05a                	sd	s6,32(sp)
    80003902:	ec5e                	sd	s7,24(sp)
    80003904:	e862                	sd	s8,16(sp)
    80003906:	a809                	j	80003918 <piperead+0x76>
      release(&pi->lock);
    80003908:	8526                	mv	a0,s1
    8000390a:	5a1020ef          	jal	800066aa <release>
      return -1;
    8000390e:	59fd                	li	s3,-1
    80003910:	a09d                	j	80003976 <piperead+0xd4>
    80003912:	f05a                	sd	s6,32(sp)
    80003914:	ec5e                	sd	s7,24(sp)
    80003916:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003918:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    8000391a:	faf40c13          	addi	s8,s0,-81
    8000391e:	4b85                	li	s7,1
    80003920:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003922:	05505063          	blez	s5,80003962 <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    80003926:	2184a783          	lw	a5,536(s1)
    8000392a:	21c4a703          	lw	a4,540(s1)
    8000392e:	02f70a63          	beq	a4,a5,80003962 <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003932:	0017871b          	addiw	a4,a5,1
    80003936:	20e4ac23          	sw	a4,536(s1)
    8000393a:	1ff7f793          	andi	a5,a5,511
    8000393e:	97a6                	add	a5,a5,s1
    80003940:	0187c783          	lbu	a5,24(a5)
    80003944:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003948:	86de                	mv	a3,s7
    8000394a:	8662                	mv	a2,s8
    8000394c:	85ca                	mv	a1,s2
    8000394e:	050a3503          	ld	a0,80(s4)
    80003952:	8ecfd0ef          	jal	80000a3e <copyout>
    80003956:	01650663          	beq	a0,s6,80003962 <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000395a:	2985                	addiw	s3,s3,1
    8000395c:	0905                	addi	s2,s2,1
    8000395e:	fd3a94e3          	bne	s5,s3,80003926 <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003962:	21c48513          	addi	a0,s1,540
    80003966:	a73fd0ef          	jal	800013d8 <wakeup>
  release(&pi->lock);
    8000396a:	8526                	mv	a0,s1
    8000396c:	53f020ef          	jal	800066aa <release>
    80003970:	7b02                	ld	s6,32(sp)
    80003972:	6be2                	ld	s7,24(sp)
    80003974:	6c42                	ld	s8,16(sp)
  return i;
}
    80003976:	854e                	mv	a0,s3
    80003978:	60e6                	ld	ra,88(sp)
    8000397a:	6446                	ld	s0,80(sp)
    8000397c:	64a6                	ld	s1,72(sp)
    8000397e:	6906                	ld	s2,64(sp)
    80003980:	79e2                	ld	s3,56(sp)
    80003982:	7a42                	ld	s4,48(sp)
    80003984:	7aa2                	ld	s5,40(sp)
    80003986:	6125                	addi	sp,sp,96
    80003988:	8082                	ret

000000008000398a <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    8000398a:	1141                	addi	sp,sp,-16
    8000398c:	e406                	sd	ra,8(sp)
    8000398e:	e022                	sd	s0,0(sp)
    80003990:	0800                	addi	s0,sp,16
    80003992:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003994:	0035151b          	slliw	a0,a0,0x3
    80003998:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    8000399a:	8b89                	andi	a5,a5,2
    8000399c:	c399                	beqz	a5,800039a2 <flags2perm+0x18>
      perm |= PTE_W;
    8000399e:	00456513          	ori	a0,a0,4
    return perm;
}
    800039a2:	60a2                	ld	ra,8(sp)
    800039a4:	6402                	ld	s0,0(sp)
    800039a6:	0141                	addi	sp,sp,16
    800039a8:	8082                	ret

00000000800039aa <exec>:

int
exec(char *path, char **argv)
{
    800039aa:	de010113          	addi	sp,sp,-544
    800039ae:	20113c23          	sd	ra,536(sp)
    800039b2:	20813823          	sd	s0,528(sp)
    800039b6:	20913423          	sd	s1,520(sp)
    800039ba:	21213023          	sd	s2,512(sp)
    800039be:	1400                	addi	s0,sp,544
    800039c0:	892a                	mv	s2,a0
    800039c2:	dea43823          	sd	a0,-528(s0)
    800039c6:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800039ca:	bf0fd0ef          	jal	80000dba <myproc>
    800039ce:	84aa                	mv	s1,a0

  begin_op();
    800039d0:	d66ff0ef          	jal	80002f36 <begin_op>

  if((ip = namei(path)) == 0){
    800039d4:	854a                	mv	a0,s2
    800039d6:	b9eff0ef          	jal	80002d74 <namei>
    800039da:	cd21                	beqz	a0,80003a32 <exec+0x88>
    800039dc:	fbd2                	sd	s4,496(sp)
    800039de:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800039e0:	c9ffe0ef          	jal	8000267e <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800039e4:	04000713          	li	a4,64
    800039e8:	4681                	li	a3,0
    800039ea:	e5040613          	addi	a2,s0,-432
    800039ee:	4581                	li	a1,0
    800039f0:	8552                	mv	a0,s4
    800039f2:	ee7fe0ef          	jal	800028d8 <readi>
    800039f6:	04000793          	li	a5,64
    800039fa:	00f51a63          	bne	a0,a5,80003a0e <exec+0x64>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    800039fe:	e5042703          	lw	a4,-432(s0)
    80003a02:	464c47b7          	lui	a5,0x464c4
    80003a06:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003a0a:	02f70863          	beq	a4,a5,80003a3a <exec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003a0e:	8552                	mv	a0,s4
    80003a10:	e7bfe0ef          	jal	8000288a <iunlockput>
    end_op();
    80003a14:	d92ff0ef          	jal	80002fa6 <end_op>
  }
  return -1;
    80003a18:	557d                	li	a0,-1
    80003a1a:	7a5e                	ld	s4,496(sp)
}
    80003a1c:	21813083          	ld	ra,536(sp)
    80003a20:	21013403          	ld	s0,528(sp)
    80003a24:	20813483          	ld	s1,520(sp)
    80003a28:	20013903          	ld	s2,512(sp)
    80003a2c:	22010113          	addi	sp,sp,544
    80003a30:	8082                	ret
    end_op();
    80003a32:	d74ff0ef          	jal	80002fa6 <end_op>
    return -1;
    80003a36:	557d                	li	a0,-1
    80003a38:	b7d5                	j	80003a1c <exec+0x72>
    80003a3a:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80003a3c:	8526                	mv	a0,s1
    80003a3e:	c26fd0ef          	jal	80000e64 <proc_pagetable>
    80003a42:	8b2a                	mv	s6,a0
    80003a44:	26050f63          	beqz	a0,80003cc2 <exec+0x318>
    80003a48:	ffce                	sd	s3,504(sp)
    80003a4a:	f7d6                	sd	s5,488(sp)
    80003a4c:	efde                	sd	s7,472(sp)
    80003a4e:	ebe2                	sd	s8,464(sp)
    80003a50:	e7e6                	sd	s9,456(sp)
    80003a52:	e3ea                	sd	s10,448(sp)
    80003a54:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003a56:	e8845783          	lhu	a5,-376(s0)
    80003a5a:	0e078963          	beqz	a5,80003b4c <exec+0x1a2>
    80003a5e:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003a62:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003a64:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003a66:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80003a6a:	6c85                	lui	s9,0x1
    80003a6c:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80003a70:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80003a74:	6a85                	lui	s5,0x1
    80003a76:	a085                	j	80003ad6 <exec+0x12c>
      panic("loadseg: address should exist");
    80003a78:	00005517          	auipc	a0,0x5
    80003a7c:	b3850513          	addi	a0,a0,-1224 # 800085b0 <etext+0x5b0>
    80003a80:	059020ef          	jal	800062d8 <panic>
    if(sz - i < PGSIZE)
    80003a84:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003a86:	874a                	mv	a4,s2
    80003a88:	009b86bb          	addw	a3,s7,s1
    80003a8c:	4581                	li	a1,0
    80003a8e:	8552                	mv	a0,s4
    80003a90:	e49fe0ef          	jal	800028d8 <readi>
    80003a94:	22a91b63          	bne	s2,a0,80003cca <exec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    80003a98:	009a84bb          	addw	s1,s5,s1
    80003a9c:	0334f263          	bgeu	s1,s3,80003ac0 <exec+0x116>
    pa = walkaddr(pagetable, va + i);
    80003aa0:	02049593          	slli	a1,s1,0x20
    80003aa4:	9181                	srli	a1,a1,0x20
    80003aa6:	95e2                	add	a1,a1,s8
    80003aa8:	855a                	mv	a0,s6
    80003aaa:	9ebfc0ef          	jal	80000494 <walkaddr>
    80003aae:	862a                	mv	a2,a0
    if(pa == 0)
    80003ab0:	d561                	beqz	a0,80003a78 <exec+0xce>
    if(sz - i < PGSIZE)
    80003ab2:	409987bb          	subw	a5,s3,s1
    80003ab6:	893e                	mv	s2,a5
    80003ab8:	fcfcf6e3          	bgeu	s9,a5,80003a84 <exec+0xda>
    80003abc:	8956                	mv	s2,s5
    80003abe:	b7d9                	j	80003a84 <exec+0xda>
    sz = sz1;
    80003ac0:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003ac4:	2d05                	addiw	s10,s10,1
    80003ac6:	e0843783          	ld	a5,-504(s0)
    80003aca:	0387869b          	addiw	a3,a5,56
    80003ace:	e8845783          	lhu	a5,-376(s0)
    80003ad2:	06fd5e63          	bge	s10,a5,80003b4e <exec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003ad6:	e0d43423          	sd	a3,-504(s0)
    80003ada:	876e                	mv	a4,s11
    80003adc:	e1840613          	addi	a2,s0,-488
    80003ae0:	4581                	li	a1,0
    80003ae2:	8552                	mv	a0,s4
    80003ae4:	df5fe0ef          	jal	800028d8 <readi>
    80003ae8:	1db51f63          	bne	a0,s11,80003cc6 <exec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80003aec:	e1842783          	lw	a5,-488(s0)
    80003af0:	4705                	li	a4,1
    80003af2:	fce799e3          	bne	a5,a4,80003ac4 <exec+0x11a>
    if(ph.memsz < ph.filesz)
    80003af6:	e4043483          	ld	s1,-448(s0)
    80003afa:	e3843783          	ld	a5,-456(s0)
    80003afe:	1ef4e463          	bltu	s1,a5,80003ce6 <exec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003b02:	e2843783          	ld	a5,-472(s0)
    80003b06:	94be                	add	s1,s1,a5
    80003b08:	1ef4e263          	bltu	s1,a5,80003cec <exec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80003b0c:	de843703          	ld	a4,-536(s0)
    80003b10:	8ff9                	and	a5,a5,a4
    80003b12:	1e079063          	bnez	a5,80003cf2 <exec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003b16:	e1c42503          	lw	a0,-484(s0)
    80003b1a:	e71ff0ef          	jal	8000398a <flags2perm>
    80003b1e:	86aa                	mv	a3,a0
    80003b20:	8626                	mv	a2,s1
    80003b22:	85ca                	mv	a1,s2
    80003b24:	855a                	mv	a0,s6
    80003b26:	d09fc0ef          	jal	8000082e <uvmalloc>
    80003b2a:	dea43c23          	sd	a0,-520(s0)
    80003b2e:	1c050563          	beqz	a0,80003cf8 <exec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003b32:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003b36:	00098863          	beqz	s3,80003b46 <exec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003b3a:	e2843c03          	ld	s8,-472(s0)
    80003b3e:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003b42:	4481                	li	s1,0
    80003b44:	bfb1                	j	80003aa0 <exec+0xf6>
    sz = sz1;
    80003b46:	df843903          	ld	s2,-520(s0)
    80003b4a:	bfad                	j	80003ac4 <exec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003b4c:	4901                	li	s2,0
  iunlockput(ip);
    80003b4e:	8552                	mv	a0,s4
    80003b50:	d3bfe0ef          	jal	8000288a <iunlockput>
  end_op();
    80003b54:	c52ff0ef          	jal	80002fa6 <end_op>
  p = myproc();
    80003b58:	a62fd0ef          	jal	80000dba <myproc>
    80003b5c:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80003b5e:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003b62:	6985                	lui	s3,0x1
    80003b64:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80003b66:	99ca                	add	s3,s3,s2
    80003b68:	77fd                	lui	a5,0xfffff
    80003b6a:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003b6e:	4691                	li	a3,4
    80003b70:	6609                	lui	a2,0x2
    80003b72:	964e                	add	a2,a2,s3
    80003b74:	85ce                	mv	a1,s3
    80003b76:	855a                	mv	a0,s6
    80003b78:	cb7fc0ef          	jal	8000082e <uvmalloc>
    80003b7c:	8a2a                	mv	s4,a0
    80003b7e:	e105                	bnez	a0,80003b9e <exec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80003b80:	85ce                	mv	a1,s3
    80003b82:	855a                	mv	a0,s6
    80003b84:	b64fd0ef          	jal	80000ee8 <proc_freepagetable>
  return -1;
    80003b88:	557d                	li	a0,-1
    80003b8a:	79fe                	ld	s3,504(sp)
    80003b8c:	7a5e                	ld	s4,496(sp)
    80003b8e:	7abe                	ld	s5,488(sp)
    80003b90:	7b1e                	ld	s6,480(sp)
    80003b92:	6bfe                	ld	s7,472(sp)
    80003b94:	6c5e                	ld	s8,464(sp)
    80003b96:	6cbe                	ld	s9,456(sp)
    80003b98:	6d1e                	ld	s10,448(sp)
    80003b9a:	7dfa                	ld	s11,440(sp)
    80003b9c:	b541                	j	80003a1c <exec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003b9e:	75f9                	lui	a1,0xffffe
    80003ba0:	95aa                	add	a1,a1,a0
    80003ba2:	855a                	mv	a0,s6
    80003ba4:	e71fc0ef          	jal	80000a14 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003ba8:	800a0b93          	addi	s7,s4,-2048
    80003bac:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80003bb0:	e0043783          	ld	a5,-512(s0)
    80003bb4:	6388                	ld	a0,0(a5)
  sp = sz;
    80003bb6:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80003bb8:	4481                	li	s1,0
    ustack[argc] = sp;
    80003bba:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80003bbe:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80003bc2:	cd21                	beqz	a0,80003c1a <exec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80003bc4:	f24fc0ef          	jal	800002e8 <strlen>
    80003bc8:	0015079b          	addiw	a5,a0,1
    80003bcc:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003bd0:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80003bd4:	13796563          	bltu	s2,s7,80003cfe <exec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003bd8:	e0043d83          	ld	s11,-512(s0)
    80003bdc:	000db983          	ld	s3,0(s11)
    80003be0:	854e                	mv	a0,s3
    80003be2:	f06fc0ef          	jal	800002e8 <strlen>
    80003be6:	0015069b          	addiw	a3,a0,1
    80003bea:	864e                	mv	a2,s3
    80003bec:	85ca                	mv	a1,s2
    80003bee:	855a                	mv	a0,s6
    80003bf0:	e4ffc0ef          	jal	80000a3e <copyout>
    80003bf4:	10054763          	bltz	a0,80003d02 <exec+0x358>
    ustack[argc] = sp;
    80003bf8:	00349793          	slli	a5,s1,0x3
    80003bfc:	97e6                	add	a5,a5,s9
    80003bfe:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ff78f40>
  for(argc = 0; argv[argc]; argc++) {
    80003c02:	0485                	addi	s1,s1,1
    80003c04:	008d8793          	addi	a5,s11,8
    80003c08:	e0f43023          	sd	a5,-512(s0)
    80003c0c:	008db503          	ld	a0,8(s11)
    80003c10:	c509                	beqz	a0,80003c1a <exec+0x270>
    if(argc >= MAXARG)
    80003c12:	fb8499e3          	bne	s1,s8,80003bc4 <exec+0x21a>
  sz = sz1;
    80003c16:	89d2                	mv	s3,s4
    80003c18:	b7a5                	j	80003b80 <exec+0x1d6>
  ustack[argc] = 0;
    80003c1a:	00349793          	slli	a5,s1,0x3
    80003c1e:	f9078793          	addi	a5,a5,-112
    80003c22:	97a2                	add	a5,a5,s0
    80003c24:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80003c28:	00349693          	slli	a3,s1,0x3
    80003c2c:	06a1                	addi	a3,a3,8
    80003c2e:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003c32:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80003c36:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80003c38:	f57964e3          	bltu	s2,s7,80003b80 <exec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003c3c:	e9040613          	addi	a2,s0,-368
    80003c40:	85ca                	mv	a1,s2
    80003c42:	855a                	mv	a0,s6
    80003c44:	dfbfc0ef          	jal	80000a3e <copyout>
    80003c48:	f2054ce3          	bltz	a0,80003b80 <exec+0x1d6>
  p->trapframe->a1 = sp;
    80003c4c:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80003c50:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003c54:	df043783          	ld	a5,-528(s0)
    80003c58:	0007c703          	lbu	a4,0(a5)
    80003c5c:	cf11                	beqz	a4,80003c78 <exec+0x2ce>
    80003c5e:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003c60:	02f00693          	li	a3,47
    80003c64:	a029                	j	80003c6e <exec+0x2c4>
  for(last=s=path; *s; s++)
    80003c66:	0785                	addi	a5,a5,1
    80003c68:	fff7c703          	lbu	a4,-1(a5)
    80003c6c:	c711                	beqz	a4,80003c78 <exec+0x2ce>
    if(*s == '/')
    80003c6e:	fed71ce3          	bne	a4,a3,80003c66 <exec+0x2bc>
      last = s+1;
    80003c72:	def43823          	sd	a5,-528(s0)
    80003c76:	bfc5                	j	80003c66 <exec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80003c78:	4641                	li	a2,16
    80003c7a:	df043583          	ld	a1,-528(s0)
    80003c7e:	158a8513          	addi	a0,s5,344
    80003c82:	e30fc0ef          	jal	800002b2 <safestrcpy>
  oldpagetable = p->pagetable;
    80003c86:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80003c8a:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80003c8e:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003c92:	058ab783          	ld	a5,88(s5)
    80003c96:	e6843703          	ld	a4,-408(s0)
    80003c9a:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003c9c:	058ab783          	ld	a5,88(s5)
    80003ca0:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003ca4:	85ea                	mv	a1,s10
    80003ca6:	a42fd0ef          	jal	80000ee8 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003caa:	0004851b          	sext.w	a0,s1
    80003cae:	79fe                	ld	s3,504(sp)
    80003cb0:	7a5e                	ld	s4,496(sp)
    80003cb2:	7abe                	ld	s5,488(sp)
    80003cb4:	7b1e                	ld	s6,480(sp)
    80003cb6:	6bfe                	ld	s7,472(sp)
    80003cb8:	6c5e                	ld	s8,464(sp)
    80003cba:	6cbe                	ld	s9,456(sp)
    80003cbc:	6d1e                	ld	s10,448(sp)
    80003cbe:	7dfa                	ld	s11,440(sp)
    80003cc0:	bbb1                	j	80003a1c <exec+0x72>
    80003cc2:	7b1e                	ld	s6,480(sp)
    80003cc4:	b3a9                	j	80003a0e <exec+0x64>
    80003cc6:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003cca:	df843583          	ld	a1,-520(s0)
    80003cce:	855a                	mv	a0,s6
    80003cd0:	a18fd0ef          	jal	80000ee8 <proc_freepagetable>
  if(ip){
    80003cd4:	79fe                	ld	s3,504(sp)
    80003cd6:	7abe                	ld	s5,488(sp)
    80003cd8:	7b1e                	ld	s6,480(sp)
    80003cda:	6bfe                	ld	s7,472(sp)
    80003cdc:	6c5e                	ld	s8,464(sp)
    80003cde:	6cbe                	ld	s9,456(sp)
    80003ce0:	6d1e                	ld	s10,448(sp)
    80003ce2:	7dfa                	ld	s11,440(sp)
    80003ce4:	b32d                	j	80003a0e <exec+0x64>
    80003ce6:	df243c23          	sd	s2,-520(s0)
    80003cea:	b7c5                	j	80003cca <exec+0x320>
    80003cec:	df243c23          	sd	s2,-520(s0)
    80003cf0:	bfe9                	j	80003cca <exec+0x320>
    80003cf2:	df243c23          	sd	s2,-520(s0)
    80003cf6:	bfd1                	j	80003cca <exec+0x320>
    80003cf8:	df243c23          	sd	s2,-520(s0)
    80003cfc:	b7f9                	j	80003cca <exec+0x320>
  sz = sz1;
    80003cfe:	89d2                	mv	s3,s4
    80003d00:	b541                	j	80003b80 <exec+0x1d6>
    80003d02:	89d2                	mv	s3,s4
    80003d04:	bdb5                	j	80003b80 <exec+0x1d6>

0000000080003d06 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003d06:	7179                	addi	sp,sp,-48
    80003d08:	f406                	sd	ra,40(sp)
    80003d0a:	f022                	sd	s0,32(sp)
    80003d0c:	ec26                	sd	s1,24(sp)
    80003d0e:	e84a                	sd	s2,16(sp)
    80003d10:	1800                	addi	s0,sp,48
    80003d12:	892e                	mv	s2,a1
    80003d14:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003d16:	fdc40593          	addi	a1,s0,-36
    80003d1a:	f6ffd0ef          	jal	80001c88 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003d1e:	fdc42703          	lw	a4,-36(s0)
    80003d22:	47bd                	li	a5,15
    80003d24:	02e7ea63          	bltu	a5,a4,80003d58 <argfd+0x52>
    80003d28:	892fd0ef          	jal	80000dba <myproc>
    80003d2c:	fdc42703          	lw	a4,-36(s0)
    80003d30:	00371793          	slli	a5,a4,0x3
    80003d34:	0d078793          	addi	a5,a5,208
    80003d38:	953e                	add	a0,a0,a5
    80003d3a:	611c                	ld	a5,0(a0)
    80003d3c:	c385                	beqz	a5,80003d5c <argfd+0x56>
    return -1;
  if(pfd)
    80003d3e:	00090463          	beqz	s2,80003d46 <argfd+0x40>
    *pfd = fd;
    80003d42:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003d46:	4501                	li	a0,0
  if(pf)
    80003d48:	c091                	beqz	s1,80003d4c <argfd+0x46>
    *pf = f;
    80003d4a:	e09c                	sd	a5,0(s1)
}
    80003d4c:	70a2                	ld	ra,40(sp)
    80003d4e:	7402                	ld	s0,32(sp)
    80003d50:	64e2                	ld	s1,24(sp)
    80003d52:	6942                	ld	s2,16(sp)
    80003d54:	6145                	addi	sp,sp,48
    80003d56:	8082                	ret
    return -1;
    80003d58:	557d                	li	a0,-1
    80003d5a:	bfcd                	j	80003d4c <argfd+0x46>
    80003d5c:	557d                	li	a0,-1
    80003d5e:	b7fd                	j	80003d4c <argfd+0x46>

0000000080003d60 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003d60:	1101                	addi	sp,sp,-32
    80003d62:	ec06                	sd	ra,24(sp)
    80003d64:	e822                	sd	s0,16(sp)
    80003d66:	e426                	sd	s1,8(sp)
    80003d68:	1000                	addi	s0,sp,32
    80003d6a:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003d6c:	84efd0ef          	jal	80000dba <myproc>
    80003d70:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003d72:	0d050793          	addi	a5,a0,208
    80003d76:	4501                	li	a0,0
    80003d78:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003d7a:	6398                	ld	a4,0(a5)
    80003d7c:	cb19                	beqz	a4,80003d92 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003d7e:	2505                	addiw	a0,a0,1
    80003d80:	07a1                	addi	a5,a5,8
    80003d82:	fed51ce3          	bne	a0,a3,80003d7a <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003d86:	557d                	li	a0,-1
}
    80003d88:	60e2                	ld	ra,24(sp)
    80003d8a:	6442                	ld	s0,16(sp)
    80003d8c:	64a2                	ld	s1,8(sp)
    80003d8e:	6105                	addi	sp,sp,32
    80003d90:	8082                	ret
      p->ofile[fd] = f;
    80003d92:	00351793          	slli	a5,a0,0x3
    80003d96:	0d078793          	addi	a5,a5,208
    80003d9a:	963e                	add	a2,a2,a5
    80003d9c:	e204                	sd	s1,0(a2)
      return fd;
    80003d9e:	b7ed                	j	80003d88 <fdalloc+0x28>

0000000080003da0 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003da0:	715d                	addi	sp,sp,-80
    80003da2:	e486                	sd	ra,72(sp)
    80003da4:	e0a2                	sd	s0,64(sp)
    80003da6:	fc26                	sd	s1,56(sp)
    80003da8:	f84a                	sd	s2,48(sp)
    80003daa:	f44e                	sd	s3,40(sp)
    80003dac:	f052                	sd	s4,32(sp)
    80003dae:	ec56                	sd	s5,24(sp)
    80003db0:	e85a                	sd	s6,16(sp)
    80003db2:	0880                	addi	s0,sp,80
    80003db4:	892e                	mv	s2,a1
    80003db6:	8a2e                	mv	s4,a1
    80003db8:	8ab2                	mv	s5,a2
    80003dba:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003dbc:	fb040593          	addi	a1,s0,-80
    80003dc0:	fcffe0ef          	jal	80002d8e <nameiparent>
    80003dc4:	84aa                	mv	s1,a0
    80003dc6:	10050763          	beqz	a0,80003ed4 <create+0x134>
    return 0;

  ilock(dp);
    80003dca:	8b5fe0ef          	jal	8000267e <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003dce:	4601                	li	a2,0
    80003dd0:	fb040593          	addi	a1,s0,-80
    80003dd4:	8526                	mv	a0,s1
    80003dd6:	d0bfe0ef          	jal	80002ae0 <dirlookup>
    80003dda:	89aa                	mv	s3,a0
    80003ddc:	c131                	beqz	a0,80003e20 <create+0x80>
    iunlockput(dp);
    80003dde:	8526                	mv	a0,s1
    80003de0:	aabfe0ef          	jal	8000288a <iunlockput>
    ilock(ip);
    80003de4:	854e                	mv	a0,s3
    80003de6:	899fe0ef          	jal	8000267e <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80003dea:	4789                	li	a5,2
    80003dec:	02f91563          	bne	s2,a5,80003e16 <create+0x76>
    80003df0:	0449d783          	lhu	a5,68(s3)
    80003df4:	37f9                	addiw	a5,a5,-2
    80003df6:	17c2                	slli	a5,a5,0x30
    80003df8:	93c1                	srli	a5,a5,0x30
    80003dfa:	4705                	li	a4,1
    80003dfc:	00f76d63          	bltu	a4,a5,80003e16 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80003e00:	854e                	mv	a0,s3
    80003e02:	60a6                	ld	ra,72(sp)
    80003e04:	6406                	ld	s0,64(sp)
    80003e06:	74e2                	ld	s1,56(sp)
    80003e08:	7942                	ld	s2,48(sp)
    80003e0a:	79a2                	ld	s3,40(sp)
    80003e0c:	7a02                	ld	s4,32(sp)
    80003e0e:	6ae2                	ld	s5,24(sp)
    80003e10:	6b42                	ld	s6,16(sp)
    80003e12:	6161                	addi	sp,sp,80
    80003e14:	8082                	ret
    iunlockput(ip);
    80003e16:	854e                	mv	a0,s3
    80003e18:	a73fe0ef          	jal	8000288a <iunlockput>
    return 0;
    80003e1c:	4981                	li	s3,0
    80003e1e:	b7cd                	j	80003e00 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80003e20:	85ca                	mv	a1,s2
    80003e22:	4088                	lw	a0,0(s1)
    80003e24:	eeafe0ef          	jal	8000250e <ialloc>
    80003e28:	892a                	mv	s2,a0
    80003e2a:	cd15                	beqz	a0,80003e66 <create+0xc6>
  ilock(ip);
    80003e2c:	853fe0ef          	jal	8000267e <ilock>
  ip->major = major;
    80003e30:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80003e34:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80003e38:	4785                	li	a5,1
    80003e3a:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80003e3e:	854a                	mv	a0,s2
    80003e40:	f8afe0ef          	jal	800025ca <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80003e44:	4705                	li	a4,1
    80003e46:	02ea0463          	beq	s4,a4,80003e6e <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80003e4a:	00492603          	lw	a2,4(s2)
    80003e4e:	fb040593          	addi	a1,s0,-80
    80003e52:	8526                	mv	a0,s1
    80003e54:	e77fe0ef          	jal	80002cca <dirlink>
    80003e58:	06054263          	bltz	a0,80003ebc <create+0x11c>
  iunlockput(dp);
    80003e5c:	8526                	mv	a0,s1
    80003e5e:	a2dfe0ef          	jal	8000288a <iunlockput>
  return ip;
    80003e62:	89ca                	mv	s3,s2
    80003e64:	bf71                	j	80003e00 <create+0x60>
    iunlockput(dp);
    80003e66:	8526                	mv	a0,s1
    80003e68:	a23fe0ef          	jal	8000288a <iunlockput>
    return 0;
    80003e6c:	bf51                	j	80003e00 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80003e6e:	00492603          	lw	a2,4(s2)
    80003e72:	00004597          	auipc	a1,0x4
    80003e76:	75e58593          	addi	a1,a1,1886 # 800085d0 <etext+0x5d0>
    80003e7a:	854a                	mv	a0,s2
    80003e7c:	e4ffe0ef          	jal	80002cca <dirlink>
    80003e80:	02054e63          	bltz	a0,80003ebc <create+0x11c>
    80003e84:	40d0                	lw	a2,4(s1)
    80003e86:	00004597          	auipc	a1,0x4
    80003e8a:	75258593          	addi	a1,a1,1874 # 800085d8 <etext+0x5d8>
    80003e8e:	854a                	mv	a0,s2
    80003e90:	e3bfe0ef          	jal	80002cca <dirlink>
    80003e94:	02054463          	bltz	a0,80003ebc <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80003e98:	00492603          	lw	a2,4(s2)
    80003e9c:	fb040593          	addi	a1,s0,-80
    80003ea0:	8526                	mv	a0,s1
    80003ea2:	e29fe0ef          	jal	80002cca <dirlink>
    80003ea6:	00054b63          	bltz	a0,80003ebc <create+0x11c>
    dp->nlink++;  // for ".."
    80003eaa:	04a4d783          	lhu	a5,74(s1)
    80003eae:	2785                	addiw	a5,a5,1
    80003eb0:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80003eb4:	8526                	mv	a0,s1
    80003eb6:	f14fe0ef          	jal	800025ca <iupdate>
    80003eba:	b74d                	j	80003e5c <create+0xbc>
  ip->nlink = 0;
    80003ebc:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80003ec0:	854a                	mv	a0,s2
    80003ec2:	f08fe0ef          	jal	800025ca <iupdate>
  iunlockput(ip);
    80003ec6:	854a                	mv	a0,s2
    80003ec8:	9c3fe0ef          	jal	8000288a <iunlockput>
  iunlockput(dp);
    80003ecc:	8526                	mv	a0,s1
    80003ece:	9bdfe0ef          	jal	8000288a <iunlockput>
  return 0;
    80003ed2:	b73d                	j	80003e00 <create+0x60>
    return 0;
    80003ed4:	89aa                	mv	s3,a0
    80003ed6:	b72d                	j	80003e00 <create+0x60>

0000000080003ed8 <sys_dup>:
{
    80003ed8:	7179                	addi	sp,sp,-48
    80003eda:	f406                	sd	ra,40(sp)
    80003edc:	f022                	sd	s0,32(sp)
    80003ede:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80003ee0:	fd840613          	addi	a2,s0,-40
    80003ee4:	4581                	li	a1,0
    80003ee6:	4501                	li	a0,0
    80003ee8:	e1fff0ef          	jal	80003d06 <argfd>
    return -1;
    80003eec:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80003eee:	02054363          	bltz	a0,80003f14 <sys_dup+0x3c>
    80003ef2:	ec26                	sd	s1,24(sp)
    80003ef4:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80003ef6:	fd843483          	ld	s1,-40(s0)
    80003efa:	8526                	mv	a0,s1
    80003efc:	e65ff0ef          	jal	80003d60 <fdalloc>
    80003f00:	892a                	mv	s2,a0
    return -1;
    80003f02:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80003f04:	00054d63          	bltz	a0,80003f1e <sys_dup+0x46>
  filedup(f);
    80003f08:	8526                	mv	a0,s1
    80003f0a:	c18ff0ef          	jal	80003322 <filedup>
  return fd;
    80003f0e:	87ca                	mv	a5,s2
    80003f10:	64e2                	ld	s1,24(sp)
    80003f12:	6942                	ld	s2,16(sp)
}
    80003f14:	853e                	mv	a0,a5
    80003f16:	70a2                	ld	ra,40(sp)
    80003f18:	7402                	ld	s0,32(sp)
    80003f1a:	6145                	addi	sp,sp,48
    80003f1c:	8082                	ret
    80003f1e:	64e2                	ld	s1,24(sp)
    80003f20:	6942                	ld	s2,16(sp)
    80003f22:	bfcd                	j	80003f14 <sys_dup+0x3c>

0000000080003f24 <sys_read>:
{
    80003f24:	7179                	addi	sp,sp,-48
    80003f26:	f406                	sd	ra,40(sp)
    80003f28:	f022                	sd	s0,32(sp)
    80003f2a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80003f2c:	fd840593          	addi	a1,s0,-40
    80003f30:	4505                	li	a0,1
    80003f32:	d73fd0ef          	jal	80001ca4 <argaddr>
  argint(2, &n);
    80003f36:	fe440593          	addi	a1,s0,-28
    80003f3a:	4509                	li	a0,2
    80003f3c:	d4dfd0ef          	jal	80001c88 <argint>
  if(argfd(0, 0, &f) < 0)
    80003f40:	fe840613          	addi	a2,s0,-24
    80003f44:	4581                	li	a1,0
    80003f46:	4501                	li	a0,0
    80003f48:	dbfff0ef          	jal	80003d06 <argfd>
    80003f4c:	87aa                	mv	a5,a0
    return -1;
    80003f4e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80003f50:	0007ca63          	bltz	a5,80003f64 <sys_read+0x40>
  return fileread(f, p, n);
    80003f54:	fe442603          	lw	a2,-28(s0)
    80003f58:	fd843583          	ld	a1,-40(s0)
    80003f5c:	fe843503          	ld	a0,-24(s0)
    80003f60:	d2cff0ef          	jal	8000348c <fileread>
}
    80003f64:	70a2                	ld	ra,40(sp)
    80003f66:	7402                	ld	s0,32(sp)
    80003f68:	6145                	addi	sp,sp,48
    80003f6a:	8082                	ret

0000000080003f6c <sys_write>:
{
    80003f6c:	7179                	addi	sp,sp,-48
    80003f6e:	f406                	sd	ra,40(sp)
    80003f70:	f022                	sd	s0,32(sp)
    80003f72:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80003f74:	fd840593          	addi	a1,s0,-40
    80003f78:	4505                	li	a0,1
    80003f7a:	d2bfd0ef          	jal	80001ca4 <argaddr>
  argint(2, &n);
    80003f7e:	fe440593          	addi	a1,s0,-28
    80003f82:	4509                	li	a0,2
    80003f84:	d05fd0ef          	jal	80001c88 <argint>
  if(argfd(0, 0, &f) < 0)
    80003f88:	fe840613          	addi	a2,s0,-24
    80003f8c:	4581                	li	a1,0
    80003f8e:	4501                	li	a0,0
    80003f90:	d77ff0ef          	jal	80003d06 <argfd>
    80003f94:	87aa                	mv	a5,a0
    return -1;
    80003f96:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80003f98:	0007ca63          	bltz	a5,80003fac <sys_write+0x40>
  return filewrite(f, p, n);
    80003f9c:	fe442603          	lw	a2,-28(s0)
    80003fa0:	fd843583          	ld	a1,-40(s0)
    80003fa4:	fe843503          	ld	a0,-24(s0)
    80003fa8:	da8ff0ef          	jal	80003550 <filewrite>
}
    80003fac:	70a2                	ld	ra,40(sp)
    80003fae:	7402                	ld	s0,32(sp)
    80003fb0:	6145                	addi	sp,sp,48
    80003fb2:	8082                	ret

0000000080003fb4 <sys_close>:
{
    80003fb4:	1101                	addi	sp,sp,-32
    80003fb6:	ec06                	sd	ra,24(sp)
    80003fb8:	e822                	sd	s0,16(sp)
    80003fba:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80003fbc:	fe040613          	addi	a2,s0,-32
    80003fc0:	fec40593          	addi	a1,s0,-20
    80003fc4:	4501                	li	a0,0
    80003fc6:	d41ff0ef          	jal	80003d06 <argfd>
    return -1;
    80003fca:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80003fcc:	02054163          	bltz	a0,80003fee <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80003fd0:	debfc0ef          	jal	80000dba <myproc>
    80003fd4:	fec42783          	lw	a5,-20(s0)
    80003fd8:	078e                	slli	a5,a5,0x3
    80003fda:	0d078793          	addi	a5,a5,208
    80003fde:	953e                	add	a0,a0,a5
    80003fe0:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80003fe4:	fe043503          	ld	a0,-32(s0)
    80003fe8:	b80ff0ef          	jal	80003368 <fileclose>
  return 0;
    80003fec:	4781                	li	a5,0
}
    80003fee:	853e                	mv	a0,a5
    80003ff0:	60e2                	ld	ra,24(sp)
    80003ff2:	6442                	ld	s0,16(sp)
    80003ff4:	6105                	addi	sp,sp,32
    80003ff6:	8082                	ret

0000000080003ff8 <sys_fstat>:
{
    80003ff8:	1101                	addi	sp,sp,-32
    80003ffa:	ec06                	sd	ra,24(sp)
    80003ffc:	e822                	sd	s0,16(sp)
    80003ffe:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004000:	fe040593          	addi	a1,s0,-32
    80004004:	4505                	li	a0,1
    80004006:	c9ffd0ef          	jal	80001ca4 <argaddr>
  if(argfd(0, 0, &f) < 0)
    8000400a:	fe840613          	addi	a2,s0,-24
    8000400e:	4581                	li	a1,0
    80004010:	4501                	li	a0,0
    80004012:	cf5ff0ef          	jal	80003d06 <argfd>
    80004016:	87aa                	mv	a5,a0
    return -1;
    80004018:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000401a:	0007c863          	bltz	a5,8000402a <sys_fstat+0x32>
  return filestat(f, st);
    8000401e:	fe043583          	ld	a1,-32(s0)
    80004022:	fe843503          	ld	a0,-24(s0)
    80004026:	c04ff0ef          	jal	8000342a <filestat>
}
    8000402a:	60e2                	ld	ra,24(sp)
    8000402c:	6442                	ld	s0,16(sp)
    8000402e:	6105                	addi	sp,sp,32
    80004030:	8082                	ret

0000000080004032 <sys_link>:
{
    80004032:	7169                	addi	sp,sp,-304
    80004034:	f606                	sd	ra,296(sp)
    80004036:	f222                	sd	s0,288(sp)
    80004038:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000403a:	08000613          	li	a2,128
    8000403e:	ed040593          	addi	a1,s0,-304
    80004042:	4501                	li	a0,0
    80004044:	c7dfd0ef          	jal	80001cc0 <argstr>
    return -1;
    80004048:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000404a:	0c054e63          	bltz	a0,80004126 <sys_link+0xf4>
    8000404e:	08000613          	li	a2,128
    80004052:	f5040593          	addi	a1,s0,-176
    80004056:	4505                	li	a0,1
    80004058:	c69fd0ef          	jal	80001cc0 <argstr>
    return -1;
    8000405c:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000405e:	0c054463          	bltz	a0,80004126 <sys_link+0xf4>
    80004062:	ee26                	sd	s1,280(sp)
  begin_op();
    80004064:	ed3fe0ef          	jal	80002f36 <begin_op>
  if((ip = namei(old)) == 0){
    80004068:	ed040513          	addi	a0,s0,-304
    8000406c:	d09fe0ef          	jal	80002d74 <namei>
    80004070:	84aa                	mv	s1,a0
    80004072:	c53d                	beqz	a0,800040e0 <sys_link+0xae>
  ilock(ip);
    80004074:	e0afe0ef          	jal	8000267e <ilock>
  if(ip->type == T_DIR){
    80004078:	04449703          	lh	a4,68(s1)
    8000407c:	4785                	li	a5,1
    8000407e:	06f70663          	beq	a4,a5,800040ea <sys_link+0xb8>
    80004082:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004084:	04a4d783          	lhu	a5,74(s1)
    80004088:	2785                	addiw	a5,a5,1
    8000408a:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000408e:	8526                	mv	a0,s1
    80004090:	d3afe0ef          	jal	800025ca <iupdate>
  iunlock(ip);
    80004094:	8526                	mv	a0,s1
    80004096:	e96fe0ef          	jal	8000272c <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    8000409a:	fd040593          	addi	a1,s0,-48
    8000409e:	f5040513          	addi	a0,s0,-176
    800040a2:	cedfe0ef          	jal	80002d8e <nameiparent>
    800040a6:	892a                	mv	s2,a0
    800040a8:	cd21                	beqz	a0,80004100 <sys_link+0xce>
  ilock(dp);
    800040aa:	dd4fe0ef          	jal	8000267e <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800040ae:	854a                	mv	a0,s2
    800040b0:	00092703          	lw	a4,0(s2)
    800040b4:	409c                	lw	a5,0(s1)
    800040b6:	04f71263          	bne	a4,a5,800040fa <sys_link+0xc8>
    800040ba:	40d0                	lw	a2,4(s1)
    800040bc:	fd040593          	addi	a1,s0,-48
    800040c0:	c0bfe0ef          	jal	80002cca <dirlink>
    800040c4:	02054b63          	bltz	a0,800040fa <sys_link+0xc8>
  iunlockput(dp);
    800040c8:	854a                	mv	a0,s2
    800040ca:	fc0fe0ef          	jal	8000288a <iunlockput>
  iput(ip);
    800040ce:	8526                	mv	a0,s1
    800040d0:	f30fe0ef          	jal	80002800 <iput>
  end_op();
    800040d4:	ed3fe0ef          	jal	80002fa6 <end_op>
  return 0;
    800040d8:	4781                	li	a5,0
    800040da:	64f2                	ld	s1,280(sp)
    800040dc:	6952                	ld	s2,272(sp)
    800040de:	a0a1                	j	80004126 <sys_link+0xf4>
    end_op();
    800040e0:	ec7fe0ef          	jal	80002fa6 <end_op>
    return -1;
    800040e4:	57fd                	li	a5,-1
    800040e6:	64f2                	ld	s1,280(sp)
    800040e8:	a83d                	j	80004126 <sys_link+0xf4>
    iunlockput(ip);
    800040ea:	8526                	mv	a0,s1
    800040ec:	f9efe0ef          	jal	8000288a <iunlockput>
    end_op();
    800040f0:	eb7fe0ef          	jal	80002fa6 <end_op>
    return -1;
    800040f4:	57fd                	li	a5,-1
    800040f6:	64f2                	ld	s1,280(sp)
    800040f8:	a03d                	j	80004126 <sys_link+0xf4>
    iunlockput(dp);
    800040fa:	854a                	mv	a0,s2
    800040fc:	f8efe0ef          	jal	8000288a <iunlockput>
  ilock(ip);
    80004100:	8526                	mv	a0,s1
    80004102:	d7cfe0ef          	jal	8000267e <ilock>
  ip->nlink--;
    80004106:	04a4d783          	lhu	a5,74(s1)
    8000410a:	37fd                	addiw	a5,a5,-1
    8000410c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004110:	8526                	mv	a0,s1
    80004112:	cb8fe0ef          	jal	800025ca <iupdate>
  iunlockput(ip);
    80004116:	8526                	mv	a0,s1
    80004118:	f72fe0ef          	jal	8000288a <iunlockput>
  end_op();
    8000411c:	e8bfe0ef          	jal	80002fa6 <end_op>
  return -1;
    80004120:	57fd                	li	a5,-1
    80004122:	64f2                	ld	s1,280(sp)
    80004124:	6952                	ld	s2,272(sp)
}
    80004126:	853e                	mv	a0,a5
    80004128:	70b2                	ld	ra,296(sp)
    8000412a:	7412                	ld	s0,288(sp)
    8000412c:	6155                	addi	sp,sp,304
    8000412e:	8082                	ret

0000000080004130 <sys_unlink>:
{
    80004130:	7151                	addi	sp,sp,-240
    80004132:	f586                	sd	ra,232(sp)
    80004134:	f1a2                	sd	s0,224(sp)
    80004136:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004138:	08000613          	li	a2,128
    8000413c:	f3040593          	addi	a1,s0,-208
    80004140:	4501                	li	a0,0
    80004142:	b7ffd0ef          	jal	80001cc0 <argstr>
    80004146:	14054d63          	bltz	a0,800042a0 <sys_unlink+0x170>
    8000414a:	eda6                	sd	s1,216(sp)
  begin_op();
    8000414c:	debfe0ef          	jal	80002f36 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004150:	fb040593          	addi	a1,s0,-80
    80004154:	f3040513          	addi	a0,s0,-208
    80004158:	c37fe0ef          	jal	80002d8e <nameiparent>
    8000415c:	84aa                	mv	s1,a0
    8000415e:	c955                	beqz	a0,80004212 <sys_unlink+0xe2>
  ilock(dp);
    80004160:	d1efe0ef          	jal	8000267e <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004164:	00004597          	auipc	a1,0x4
    80004168:	46c58593          	addi	a1,a1,1132 # 800085d0 <etext+0x5d0>
    8000416c:	fb040513          	addi	a0,s0,-80
    80004170:	95bfe0ef          	jal	80002aca <namecmp>
    80004174:	10050b63          	beqz	a0,8000428a <sys_unlink+0x15a>
    80004178:	00004597          	auipc	a1,0x4
    8000417c:	46058593          	addi	a1,a1,1120 # 800085d8 <etext+0x5d8>
    80004180:	fb040513          	addi	a0,s0,-80
    80004184:	947fe0ef          	jal	80002aca <namecmp>
    80004188:	10050163          	beqz	a0,8000428a <sys_unlink+0x15a>
    8000418c:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    8000418e:	f2c40613          	addi	a2,s0,-212
    80004192:	fb040593          	addi	a1,s0,-80
    80004196:	8526                	mv	a0,s1
    80004198:	949fe0ef          	jal	80002ae0 <dirlookup>
    8000419c:	892a                	mv	s2,a0
    8000419e:	0e050563          	beqz	a0,80004288 <sys_unlink+0x158>
    800041a2:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800041a4:	cdafe0ef          	jal	8000267e <ilock>
  if(ip->nlink < 1)
    800041a8:	04a91783          	lh	a5,74(s2)
    800041ac:	06f05863          	blez	a5,8000421c <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800041b0:	04491703          	lh	a4,68(s2)
    800041b4:	4785                	li	a5,1
    800041b6:	06f70963          	beq	a4,a5,80004228 <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    800041ba:	fc040993          	addi	s3,s0,-64
    800041be:	4641                	li	a2,16
    800041c0:	4581                	li	a1,0
    800041c2:	854e                	mv	a0,s3
    800041c4:	f9bfb0ef          	jal	8000015e <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800041c8:	4741                	li	a4,16
    800041ca:	f2c42683          	lw	a3,-212(s0)
    800041ce:	864e                	mv	a2,s3
    800041d0:	4581                	li	a1,0
    800041d2:	8526                	mv	a0,s1
    800041d4:	ff6fe0ef          	jal	800029ca <writei>
    800041d8:	47c1                	li	a5,16
    800041da:	08f51863          	bne	a0,a5,8000426a <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    800041de:	04491703          	lh	a4,68(s2)
    800041e2:	4785                	li	a5,1
    800041e4:	08f70963          	beq	a4,a5,80004276 <sys_unlink+0x146>
  iunlockput(dp);
    800041e8:	8526                	mv	a0,s1
    800041ea:	ea0fe0ef          	jal	8000288a <iunlockput>
  ip->nlink--;
    800041ee:	04a95783          	lhu	a5,74(s2)
    800041f2:	37fd                	addiw	a5,a5,-1
    800041f4:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800041f8:	854a                	mv	a0,s2
    800041fa:	bd0fe0ef          	jal	800025ca <iupdate>
  iunlockput(ip);
    800041fe:	854a                	mv	a0,s2
    80004200:	e8afe0ef          	jal	8000288a <iunlockput>
  end_op();
    80004204:	da3fe0ef          	jal	80002fa6 <end_op>
  return 0;
    80004208:	4501                	li	a0,0
    8000420a:	64ee                	ld	s1,216(sp)
    8000420c:	694e                	ld	s2,208(sp)
    8000420e:	69ae                	ld	s3,200(sp)
    80004210:	a061                	j	80004298 <sys_unlink+0x168>
    end_op();
    80004212:	d95fe0ef          	jal	80002fa6 <end_op>
    return -1;
    80004216:	557d                	li	a0,-1
    80004218:	64ee                	ld	s1,216(sp)
    8000421a:	a8bd                	j	80004298 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    8000421c:	00004517          	auipc	a0,0x4
    80004220:	3c450513          	addi	a0,a0,964 # 800085e0 <etext+0x5e0>
    80004224:	0b4020ef          	jal	800062d8 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004228:	04c92703          	lw	a4,76(s2)
    8000422c:	02000793          	li	a5,32
    80004230:	f8e7f5e3          	bgeu	a5,a4,800041ba <sys_unlink+0x8a>
    80004234:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004236:	4741                	li	a4,16
    80004238:	86ce                	mv	a3,s3
    8000423a:	f1840613          	addi	a2,s0,-232
    8000423e:	4581                	li	a1,0
    80004240:	854a                	mv	a0,s2
    80004242:	e96fe0ef          	jal	800028d8 <readi>
    80004246:	47c1                	li	a5,16
    80004248:	00f51b63          	bne	a0,a5,8000425e <sys_unlink+0x12e>
    if(de.inum != 0)
    8000424c:	f1845783          	lhu	a5,-232(s0)
    80004250:	ebb1                	bnez	a5,800042a4 <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004252:	29c1                	addiw	s3,s3,16
    80004254:	04c92783          	lw	a5,76(s2)
    80004258:	fcf9efe3          	bltu	s3,a5,80004236 <sys_unlink+0x106>
    8000425c:	bfb9                	j	800041ba <sys_unlink+0x8a>
      panic("isdirempty: readi");
    8000425e:	00004517          	auipc	a0,0x4
    80004262:	39a50513          	addi	a0,a0,922 # 800085f8 <etext+0x5f8>
    80004266:	072020ef          	jal	800062d8 <panic>
    panic("unlink: writei");
    8000426a:	00004517          	auipc	a0,0x4
    8000426e:	3a650513          	addi	a0,a0,934 # 80008610 <etext+0x610>
    80004272:	066020ef          	jal	800062d8 <panic>
    dp->nlink--;
    80004276:	04a4d783          	lhu	a5,74(s1)
    8000427a:	37fd                	addiw	a5,a5,-1
    8000427c:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004280:	8526                	mv	a0,s1
    80004282:	b48fe0ef          	jal	800025ca <iupdate>
    80004286:	b78d                	j	800041e8 <sys_unlink+0xb8>
    80004288:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    8000428a:	8526                	mv	a0,s1
    8000428c:	dfefe0ef          	jal	8000288a <iunlockput>
  end_op();
    80004290:	d17fe0ef          	jal	80002fa6 <end_op>
  return -1;
    80004294:	557d                	li	a0,-1
    80004296:	64ee                	ld	s1,216(sp)
}
    80004298:	70ae                	ld	ra,232(sp)
    8000429a:	740e                	ld	s0,224(sp)
    8000429c:	616d                	addi	sp,sp,240
    8000429e:	8082                	ret
    return -1;
    800042a0:	557d                	li	a0,-1
    800042a2:	bfdd                	j	80004298 <sys_unlink+0x168>
    iunlockput(ip);
    800042a4:	854a                	mv	a0,s2
    800042a6:	de4fe0ef          	jal	8000288a <iunlockput>
    goto bad;
    800042aa:	694e                	ld	s2,208(sp)
    800042ac:	69ae                	ld	s3,200(sp)
    800042ae:	bff1                	j	8000428a <sys_unlink+0x15a>

00000000800042b0 <sys_open>:

uint64
sys_open(void)
{
    800042b0:	7131                	addi	sp,sp,-192
    800042b2:	fd06                	sd	ra,184(sp)
    800042b4:	f922                	sd	s0,176(sp)
    800042b6:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800042b8:	f4c40593          	addi	a1,s0,-180
    800042bc:	4505                	li	a0,1
    800042be:	9cbfd0ef          	jal	80001c88 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800042c2:	08000613          	li	a2,128
    800042c6:	f5040593          	addi	a1,s0,-176
    800042ca:	4501                	li	a0,0
    800042cc:	9f5fd0ef          	jal	80001cc0 <argstr>
    800042d0:	87aa                	mv	a5,a0
    return -1;
    800042d2:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800042d4:	0a07c363          	bltz	a5,8000437a <sys_open+0xca>
    800042d8:	f526                	sd	s1,168(sp)

  begin_op();
    800042da:	c5dfe0ef          	jal	80002f36 <begin_op>

  if(omode & O_CREATE){
    800042de:	f4c42783          	lw	a5,-180(s0)
    800042e2:	2007f793          	andi	a5,a5,512
    800042e6:	c3dd                	beqz	a5,8000438c <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    800042e8:	4681                	li	a3,0
    800042ea:	4601                	li	a2,0
    800042ec:	4589                	li	a1,2
    800042ee:	f5040513          	addi	a0,s0,-176
    800042f2:	aafff0ef          	jal	80003da0 <create>
    800042f6:	84aa                	mv	s1,a0
    if(ip == 0){
    800042f8:	c549                	beqz	a0,80004382 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800042fa:	04449703          	lh	a4,68(s1)
    800042fe:	478d                	li	a5,3
    80004300:	00f71763          	bne	a4,a5,8000430e <sys_open+0x5e>
    80004304:	0464d703          	lhu	a4,70(s1)
    80004308:	47a5                	li	a5,9
    8000430a:	0ae7ee63          	bltu	a5,a4,800043c6 <sys_open+0x116>
    8000430e:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004310:	fb5fe0ef          	jal	800032c4 <filealloc>
    80004314:	892a                	mv	s2,a0
    80004316:	c561                	beqz	a0,800043de <sys_open+0x12e>
    80004318:	ed4e                	sd	s3,152(sp)
    8000431a:	a47ff0ef          	jal	80003d60 <fdalloc>
    8000431e:	89aa                	mv	s3,a0
    80004320:	0a054b63          	bltz	a0,800043d6 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004324:	04449703          	lh	a4,68(s1)
    80004328:	478d                	li	a5,3
    8000432a:	0cf70363          	beq	a4,a5,800043f0 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000432e:	4789                	li	a5,2
    80004330:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004334:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004338:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    8000433c:	f4c42783          	lw	a5,-180(s0)
    80004340:	0017f713          	andi	a4,a5,1
    80004344:	00174713          	xori	a4,a4,1
    80004348:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000434c:	0037f713          	andi	a4,a5,3
    80004350:	00e03733          	snez	a4,a4
    80004354:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004358:	4007f793          	andi	a5,a5,1024
    8000435c:	c791                	beqz	a5,80004368 <sys_open+0xb8>
    8000435e:	04449703          	lh	a4,68(s1)
    80004362:	4789                	li	a5,2
    80004364:	08f70d63          	beq	a4,a5,800043fe <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    80004368:	8526                	mv	a0,s1
    8000436a:	bc2fe0ef          	jal	8000272c <iunlock>
  end_op();
    8000436e:	c39fe0ef          	jal	80002fa6 <end_op>

  return fd;
    80004372:	854e                	mv	a0,s3
    80004374:	74aa                	ld	s1,168(sp)
    80004376:	790a                	ld	s2,160(sp)
    80004378:	69ea                	ld	s3,152(sp)
}
    8000437a:	70ea                	ld	ra,184(sp)
    8000437c:	744a                	ld	s0,176(sp)
    8000437e:	6129                	addi	sp,sp,192
    80004380:	8082                	ret
      end_op();
    80004382:	c25fe0ef          	jal	80002fa6 <end_op>
      return -1;
    80004386:	557d                	li	a0,-1
    80004388:	74aa                	ld	s1,168(sp)
    8000438a:	bfc5                	j	8000437a <sys_open+0xca>
    if((ip = namei(path)) == 0){
    8000438c:	f5040513          	addi	a0,s0,-176
    80004390:	9e5fe0ef          	jal	80002d74 <namei>
    80004394:	84aa                	mv	s1,a0
    80004396:	c11d                	beqz	a0,800043bc <sys_open+0x10c>
    ilock(ip);
    80004398:	ae6fe0ef          	jal	8000267e <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    8000439c:	04449703          	lh	a4,68(s1)
    800043a0:	4785                	li	a5,1
    800043a2:	f4f71ce3          	bne	a4,a5,800042fa <sys_open+0x4a>
    800043a6:	f4c42783          	lw	a5,-180(s0)
    800043aa:	d3b5                	beqz	a5,8000430e <sys_open+0x5e>
      iunlockput(ip);
    800043ac:	8526                	mv	a0,s1
    800043ae:	cdcfe0ef          	jal	8000288a <iunlockput>
      end_op();
    800043b2:	bf5fe0ef          	jal	80002fa6 <end_op>
      return -1;
    800043b6:	557d                	li	a0,-1
    800043b8:	74aa                	ld	s1,168(sp)
    800043ba:	b7c1                	j	8000437a <sys_open+0xca>
      end_op();
    800043bc:	bebfe0ef          	jal	80002fa6 <end_op>
      return -1;
    800043c0:	557d                	li	a0,-1
    800043c2:	74aa                	ld	s1,168(sp)
    800043c4:	bf5d                	j	8000437a <sys_open+0xca>
    iunlockput(ip);
    800043c6:	8526                	mv	a0,s1
    800043c8:	cc2fe0ef          	jal	8000288a <iunlockput>
    end_op();
    800043cc:	bdbfe0ef          	jal	80002fa6 <end_op>
    return -1;
    800043d0:	557d                	li	a0,-1
    800043d2:	74aa                	ld	s1,168(sp)
    800043d4:	b75d                	j	8000437a <sys_open+0xca>
      fileclose(f);
    800043d6:	854a                	mv	a0,s2
    800043d8:	f91fe0ef          	jal	80003368 <fileclose>
    800043dc:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    800043de:	8526                	mv	a0,s1
    800043e0:	caafe0ef          	jal	8000288a <iunlockput>
    end_op();
    800043e4:	bc3fe0ef          	jal	80002fa6 <end_op>
    return -1;
    800043e8:	557d                	li	a0,-1
    800043ea:	74aa                	ld	s1,168(sp)
    800043ec:	790a                	ld	s2,160(sp)
    800043ee:	b771                	j	8000437a <sys_open+0xca>
    f->type = FD_DEVICE;
    800043f0:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800043f4:	04649783          	lh	a5,70(s1)
    800043f8:	02f91223          	sh	a5,36(s2)
    800043fc:	bf35                	j	80004338 <sys_open+0x88>
    itrunc(ip);
    800043fe:	8526                	mv	a0,s1
    80004400:	b6cfe0ef          	jal	8000276c <itrunc>
    80004404:	b795                	j	80004368 <sys_open+0xb8>

0000000080004406 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004406:	7175                	addi	sp,sp,-144
    80004408:	e506                	sd	ra,136(sp)
    8000440a:	e122                	sd	s0,128(sp)
    8000440c:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000440e:	b29fe0ef          	jal	80002f36 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80004412:	08000613          	li	a2,128
    80004416:	f7040593          	addi	a1,s0,-144
    8000441a:	4501                	li	a0,0
    8000441c:	8a5fd0ef          	jal	80001cc0 <argstr>
    80004420:	02054363          	bltz	a0,80004446 <sys_mkdir+0x40>
    80004424:	4681                	li	a3,0
    80004426:	4601                	li	a2,0
    80004428:	4585                	li	a1,1
    8000442a:	f7040513          	addi	a0,s0,-144
    8000442e:	973ff0ef          	jal	80003da0 <create>
    80004432:	c911                	beqz	a0,80004446 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004434:	c56fe0ef          	jal	8000288a <iunlockput>
  end_op();
    80004438:	b6ffe0ef          	jal	80002fa6 <end_op>
  return 0;
    8000443c:	4501                	li	a0,0
}
    8000443e:	60aa                	ld	ra,136(sp)
    80004440:	640a                	ld	s0,128(sp)
    80004442:	6149                	addi	sp,sp,144
    80004444:	8082                	ret
    end_op();
    80004446:	b61fe0ef          	jal	80002fa6 <end_op>
    return -1;
    8000444a:	557d                	li	a0,-1
    8000444c:	bfcd                	j	8000443e <sys_mkdir+0x38>

000000008000444e <sys_mknod>:

uint64
sys_mknod(void)
{
    8000444e:	7135                	addi	sp,sp,-160
    80004450:	ed06                	sd	ra,152(sp)
    80004452:	e922                	sd	s0,144(sp)
    80004454:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004456:	ae1fe0ef          	jal	80002f36 <begin_op>
  argint(1, &major);
    8000445a:	f6c40593          	addi	a1,s0,-148
    8000445e:	4505                	li	a0,1
    80004460:	829fd0ef          	jal	80001c88 <argint>
  argint(2, &minor);
    80004464:	f6840593          	addi	a1,s0,-152
    80004468:	4509                	li	a0,2
    8000446a:	81ffd0ef          	jal	80001c88 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000446e:	08000613          	li	a2,128
    80004472:	f7040593          	addi	a1,s0,-144
    80004476:	4501                	li	a0,0
    80004478:	849fd0ef          	jal	80001cc0 <argstr>
    8000447c:	02054563          	bltz	a0,800044a6 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004480:	f6841683          	lh	a3,-152(s0)
    80004484:	f6c41603          	lh	a2,-148(s0)
    80004488:	458d                	li	a1,3
    8000448a:	f7040513          	addi	a0,s0,-144
    8000448e:	913ff0ef          	jal	80003da0 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004492:	c911                	beqz	a0,800044a6 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004494:	bf6fe0ef          	jal	8000288a <iunlockput>
  end_op();
    80004498:	b0ffe0ef          	jal	80002fa6 <end_op>
  return 0;
    8000449c:	4501                	li	a0,0
}
    8000449e:	60ea                	ld	ra,152(sp)
    800044a0:	644a                	ld	s0,144(sp)
    800044a2:	610d                	addi	sp,sp,160
    800044a4:	8082                	ret
    end_op();
    800044a6:	b01fe0ef          	jal	80002fa6 <end_op>
    return -1;
    800044aa:	557d                	li	a0,-1
    800044ac:	bfcd                	j	8000449e <sys_mknod+0x50>

00000000800044ae <sys_chdir>:

uint64
sys_chdir(void)
{
    800044ae:	7135                	addi	sp,sp,-160
    800044b0:	ed06                	sd	ra,152(sp)
    800044b2:	e922                	sd	s0,144(sp)
    800044b4:	e14a                	sd	s2,128(sp)
    800044b6:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800044b8:	903fc0ef          	jal	80000dba <myproc>
    800044bc:	892a                	mv	s2,a0
  
  begin_op();
    800044be:	a79fe0ef          	jal	80002f36 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800044c2:	08000613          	li	a2,128
    800044c6:	f6040593          	addi	a1,s0,-160
    800044ca:	4501                	li	a0,0
    800044cc:	ff4fd0ef          	jal	80001cc0 <argstr>
    800044d0:	04054363          	bltz	a0,80004516 <sys_chdir+0x68>
    800044d4:	e526                	sd	s1,136(sp)
    800044d6:	f6040513          	addi	a0,s0,-160
    800044da:	89bfe0ef          	jal	80002d74 <namei>
    800044de:	84aa                	mv	s1,a0
    800044e0:	c915                	beqz	a0,80004514 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800044e2:	99cfe0ef          	jal	8000267e <ilock>
  if(ip->type != T_DIR){
    800044e6:	04449703          	lh	a4,68(s1)
    800044ea:	4785                	li	a5,1
    800044ec:	02f71963          	bne	a4,a5,8000451e <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800044f0:	8526                	mv	a0,s1
    800044f2:	a3afe0ef          	jal	8000272c <iunlock>
  iput(p->cwd);
    800044f6:	15093503          	ld	a0,336(s2)
    800044fa:	b06fe0ef          	jal	80002800 <iput>
  end_op();
    800044fe:	aa9fe0ef          	jal	80002fa6 <end_op>
  p->cwd = ip;
    80004502:	14993823          	sd	s1,336(s2)
  return 0;
    80004506:	4501                	li	a0,0
    80004508:	64aa                	ld	s1,136(sp)
}
    8000450a:	60ea                	ld	ra,152(sp)
    8000450c:	644a                	ld	s0,144(sp)
    8000450e:	690a                	ld	s2,128(sp)
    80004510:	610d                	addi	sp,sp,160
    80004512:	8082                	ret
    80004514:	64aa                	ld	s1,136(sp)
    end_op();
    80004516:	a91fe0ef          	jal	80002fa6 <end_op>
    return -1;
    8000451a:	557d                	li	a0,-1
    8000451c:	b7fd                	j	8000450a <sys_chdir+0x5c>
    iunlockput(ip);
    8000451e:	8526                	mv	a0,s1
    80004520:	b6afe0ef          	jal	8000288a <iunlockput>
    end_op();
    80004524:	a83fe0ef          	jal	80002fa6 <end_op>
    return -1;
    80004528:	557d                	li	a0,-1
    8000452a:	64aa                	ld	s1,136(sp)
    8000452c:	bff9                	j	8000450a <sys_chdir+0x5c>

000000008000452e <sys_exec>:

uint64
sys_exec(void)
{
    8000452e:	7105                	addi	sp,sp,-480
    80004530:	ef86                	sd	ra,472(sp)
    80004532:	eba2                	sd	s0,464(sp)
    80004534:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004536:	e2840593          	addi	a1,s0,-472
    8000453a:	4505                	li	a0,1
    8000453c:	f68fd0ef          	jal	80001ca4 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80004540:	08000613          	li	a2,128
    80004544:	f3040593          	addi	a1,s0,-208
    80004548:	4501                	li	a0,0
    8000454a:	f76fd0ef          	jal	80001cc0 <argstr>
    8000454e:	87aa                	mv	a5,a0
    return -1;
    80004550:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80004552:	0e07c063          	bltz	a5,80004632 <sys_exec+0x104>
    80004556:	e7a6                	sd	s1,456(sp)
    80004558:	e3ca                	sd	s2,448(sp)
    8000455a:	ff4e                	sd	s3,440(sp)
    8000455c:	fb52                	sd	s4,432(sp)
    8000455e:	f756                	sd	s5,424(sp)
    80004560:	f35a                	sd	s6,416(sp)
    80004562:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    80004564:	e3040a13          	addi	s4,s0,-464
    80004568:	10000613          	li	a2,256
    8000456c:	4581                	li	a1,0
    8000456e:	8552                	mv	a0,s4
    80004570:	beffb0ef          	jal	8000015e <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80004574:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    80004576:	89d2                	mv	s3,s4
    80004578:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000457a:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000457e:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    80004580:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004584:	00391513          	slli	a0,s2,0x3
    80004588:	85d6                	mv	a1,s5
    8000458a:	e2843783          	ld	a5,-472(s0)
    8000458e:	953e                	add	a0,a0,a5
    80004590:	e6efd0ef          	jal	80001bfe <fetchaddr>
    80004594:	02054663          	bltz	a0,800045c0 <sys_exec+0x92>
    if(uarg == 0){
    80004598:	e2043783          	ld	a5,-480(s0)
    8000459c:	c7a1                	beqz	a5,800045e4 <sys_exec+0xb6>
    argv[i] = kalloc();
    8000459e:	b67fb0ef          	jal	80000104 <kalloc>
    800045a2:	85aa                	mv	a1,a0
    800045a4:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800045a8:	cd01                	beqz	a0,800045c0 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800045aa:	865a                	mv	a2,s6
    800045ac:	e2043503          	ld	a0,-480(s0)
    800045b0:	e98fd0ef          	jal	80001c48 <fetchstr>
    800045b4:	00054663          	bltz	a0,800045c0 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    800045b8:	0905                	addi	s2,s2,1
    800045ba:	09a1                	addi	s3,s3,8
    800045bc:	fd7914e3          	bne	s2,s7,80004584 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800045c0:	100a0a13          	addi	s4,s4,256
    800045c4:	6088                	ld	a0,0(s1)
    800045c6:	cd31                	beqz	a0,80004622 <sys_exec+0xf4>
    kfree(argv[i]);
    800045c8:	a55fb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800045cc:	04a1                	addi	s1,s1,8
    800045ce:	ff449be3          	bne	s1,s4,800045c4 <sys_exec+0x96>
  return -1;
    800045d2:	557d                	li	a0,-1
    800045d4:	64be                	ld	s1,456(sp)
    800045d6:	691e                	ld	s2,448(sp)
    800045d8:	79fa                	ld	s3,440(sp)
    800045da:	7a5a                	ld	s4,432(sp)
    800045dc:	7aba                	ld	s5,424(sp)
    800045de:	7b1a                	ld	s6,416(sp)
    800045e0:	6bfa                	ld	s7,408(sp)
    800045e2:	a881                	j	80004632 <sys_exec+0x104>
      argv[i] = 0;
    800045e4:	0009079b          	sext.w	a5,s2
    800045e8:	e3040593          	addi	a1,s0,-464
    800045ec:	078e                	slli	a5,a5,0x3
    800045ee:	97ae                	add	a5,a5,a1
    800045f0:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    800045f4:	f3040513          	addi	a0,s0,-208
    800045f8:	bb2ff0ef          	jal	800039aa <exec>
    800045fc:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800045fe:	100a0a13          	addi	s4,s4,256
    80004602:	6088                	ld	a0,0(s1)
    80004604:	c511                	beqz	a0,80004610 <sys_exec+0xe2>
    kfree(argv[i]);
    80004606:	a17fb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000460a:	04a1                	addi	s1,s1,8
    8000460c:	ff449be3          	bne	s1,s4,80004602 <sys_exec+0xd4>
  return ret;
    80004610:	854a                	mv	a0,s2
    80004612:	64be                	ld	s1,456(sp)
    80004614:	691e                	ld	s2,448(sp)
    80004616:	79fa                	ld	s3,440(sp)
    80004618:	7a5a                	ld	s4,432(sp)
    8000461a:	7aba                	ld	s5,424(sp)
    8000461c:	7b1a                	ld	s6,416(sp)
    8000461e:	6bfa                	ld	s7,408(sp)
    80004620:	a809                	j	80004632 <sys_exec+0x104>
  return -1;
    80004622:	557d                	li	a0,-1
    80004624:	64be                	ld	s1,456(sp)
    80004626:	691e                	ld	s2,448(sp)
    80004628:	79fa                	ld	s3,440(sp)
    8000462a:	7a5a                	ld	s4,432(sp)
    8000462c:	7aba                	ld	s5,424(sp)
    8000462e:	7b1a                	ld	s6,416(sp)
    80004630:	6bfa                	ld	s7,408(sp)
}
    80004632:	60fe                	ld	ra,472(sp)
    80004634:	645e                	ld	s0,464(sp)
    80004636:	613d                	addi	sp,sp,480
    80004638:	8082                	ret

000000008000463a <sys_pipe>:

uint64
sys_pipe(void)
{
    8000463a:	7139                	addi	sp,sp,-64
    8000463c:	fc06                	sd	ra,56(sp)
    8000463e:	f822                	sd	s0,48(sp)
    80004640:	f426                	sd	s1,40(sp)
    80004642:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80004644:	f76fc0ef          	jal	80000dba <myproc>
    80004648:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000464a:	fd840593          	addi	a1,s0,-40
    8000464e:	4501                	li	a0,0
    80004650:	e54fd0ef          	jal	80001ca4 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80004654:	fc840593          	addi	a1,s0,-56
    80004658:	fd040513          	addi	a0,s0,-48
    8000465c:	828ff0ef          	jal	80003684 <pipealloc>
    return -1;
    80004660:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80004662:	0a054763          	bltz	a0,80004710 <sys_pipe+0xd6>
  fd0 = -1;
    80004666:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000466a:	fd043503          	ld	a0,-48(s0)
    8000466e:	ef2ff0ef          	jal	80003d60 <fdalloc>
    80004672:	fca42223          	sw	a0,-60(s0)
    80004676:	08054463          	bltz	a0,800046fe <sys_pipe+0xc4>
    8000467a:	fc843503          	ld	a0,-56(s0)
    8000467e:	ee2ff0ef          	jal	80003d60 <fdalloc>
    80004682:	fca42023          	sw	a0,-64(s0)
    80004686:	06054263          	bltz	a0,800046ea <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000468a:	4691                	li	a3,4
    8000468c:	fc440613          	addi	a2,s0,-60
    80004690:	fd843583          	ld	a1,-40(s0)
    80004694:	68a8                	ld	a0,80(s1)
    80004696:	ba8fc0ef          	jal	80000a3e <copyout>
    8000469a:	00054e63          	bltz	a0,800046b6 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    8000469e:	4691                	li	a3,4
    800046a0:	fc040613          	addi	a2,s0,-64
    800046a4:	fd843583          	ld	a1,-40(s0)
    800046a8:	95b6                	add	a1,a1,a3
    800046aa:	68a8                	ld	a0,80(s1)
    800046ac:	b92fc0ef          	jal	80000a3e <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800046b0:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800046b2:	04055f63          	bgez	a0,80004710 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    800046b6:	fc442783          	lw	a5,-60(s0)
    800046ba:	078e                	slli	a5,a5,0x3
    800046bc:	0d078793          	addi	a5,a5,208
    800046c0:	97a6                	add	a5,a5,s1
    800046c2:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800046c6:	fc042783          	lw	a5,-64(s0)
    800046ca:	078e                	slli	a5,a5,0x3
    800046cc:	0d078793          	addi	a5,a5,208
    800046d0:	97a6                	add	a5,a5,s1
    800046d2:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800046d6:	fd043503          	ld	a0,-48(s0)
    800046da:	c8ffe0ef          	jal	80003368 <fileclose>
    fileclose(wf);
    800046de:	fc843503          	ld	a0,-56(s0)
    800046e2:	c87fe0ef          	jal	80003368 <fileclose>
    return -1;
    800046e6:	57fd                	li	a5,-1
    800046e8:	a025                	j	80004710 <sys_pipe+0xd6>
    if(fd0 >= 0)
    800046ea:	fc442783          	lw	a5,-60(s0)
    800046ee:	0007c863          	bltz	a5,800046fe <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    800046f2:	078e                	slli	a5,a5,0x3
    800046f4:	0d078793          	addi	a5,a5,208
    800046f8:	97a6                	add	a5,a5,s1
    800046fa:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800046fe:	fd043503          	ld	a0,-48(s0)
    80004702:	c67fe0ef          	jal	80003368 <fileclose>
    fileclose(wf);
    80004706:	fc843503          	ld	a0,-56(s0)
    8000470a:	c5ffe0ef          	jal	80003368 <fileclose>
    return -1;
    8000470e:	57fd                	li	a5,-1
}
    80004710:	853e                	mv	a0,a5
    80004712:	70e2                	ld	ra,56(sp)
    80004714:	7442                	ld	s0,48(sp)
    80004716:	74a2                	ld	s1,40(sp)
    80004718:	6121                	addi	sp,sp,64
    8000471a:	8082                	ret
    8000471c:	0000                	unimp
	...

0000000080004720 <kernelvec>:
    80004720:	7111                	addi	sp,sp,-256
    80004722:	e006                	sd	ra,0(sp)
    80004724:	e40a                	sd	sp,8(sp)
    80004726:	e80e                	sd	gp,16(sp)
    80004728:	ec12                	sd	tp,24(sp)
    8000472a:	f016                	sd	t0,32(sp)
    8000472c:	f41a                	sd	t1,40(sp)
    8000472e:	f81e                	sd	t2,48(sp)
    80004730:	e4aa                	sd	a0,72(sp)
    80004732:	e8ae                	sd	a1,80(sp)
    80004734:	ecb2                	sd	a2,88(sp)
    80004736:	f0b6                	sd	a3,96(sp)
    80004738:	f4ba                	sd	a4,104(sp)
    8000473a:	f8be                	sd	a5,112(sp)
    8000473c:	fcc2                	sd	a6,120(sp)
    8000473e:	e146                	sd	a7,128(sp)
    80004740:	edf2                	sd	t3,216(sp)
    80004742:	f1f6                	sd	t4,224(sp)
    80004744:	f5fa                	sd	t5,232(sp)
    80004746:	f9fe                	sd	t6,240(sp)
    80004748:	bc4fd0ef          	jal	80001b0c <kerneltrap>
    8000474c:	6082                	ld	ra,0(sp)
    8000474e:	6122                	ld	sp,8(sp)
    80004750:	61c2                	ld	gp,16(sp)
    80004752:	7282                	ld	t0,32(sp)
    80004754:	7322                	ld	t1,40(sp)
    80004756:	73c2                	ld	t2,48(sp)
    80004758:	6526                	ld	a0,72(sp)
    8000475a:	65c6                	ld	a1,80(sp)
    8000475c:	6666                	ld	a2,88(sp)
    8000475e:	7686                	ld	a3,96(sp)
    80004760:	7726                	ld	a4,104(sp)
    80004762:	77c6                	ld	a5,112(sp)
    80004764:	7866                	ld	a6,120(sp)
    80004766:	688a                	ld	a7,128(sp)
    80004768:	6e6e                	ld	t3,216(sp)
    8000476a:	7e8e                	ld	t4,224(sp)
    8000476c:	7f2e                	ld	t5,232(sp)
    8000476e:	7fce                	ld	t6,240(sp)
    80004770:	6111                	addi	sp,sp,256
    80004772:	10200073          	sret
    80004776:	00000013          	nop
    8000477a:	00000013          	nop

000000008000477e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000477e:	1141                	addi	sp,sp,-16
    80004780:	e406                	sd	ra,8(sp)
    80004782:	e022                	sd	s0,0(sp)
    80004784:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004786:	0c000737          	lui	a4,0xc000
    8000478a:	4785                	li	a5,1
    8000478c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000478e:	c35c                	sw	a5,4(a4)
    80004790:	00470793          	addi	a5,a4,4 # c000004 <_entry-0x73fffffc>
  
#ifdef LAB_NET
  // PCIE IRQs are 32 to 35
  for(int irq = 1; irq < 0x35; irq++){
    *(uint32*)(PLIC + irq*4) = 1;
    80004794:	4685                	li	a3,1
  for(int irq = 1; irq < 0x35; irq++){
    80004796:	0d470713          	addi	a4,a4,212
    *(uint32*)(PLIC + irq*4) = 1;
    8000479a:	c394                	sw	a3,0(a5)
  for(int irq = 1; irq < 0x35; irq++){
    8000479c:	0791                	addi	a5,a5,4
    8000479e:	fee79ee3          	bne	a5,a4,8000479a <plicinit+0x1c>
  }
#endif  
}
    800047a2:	60a2                	ld	ra,8(sp)
    800047a4:	6402                	ld	s0,0(sp)
    800047a6:	0141                	addi	sp,sp,16
    800047a8:	8082                	ret

00000000800047aa <plicinithart>:

void
plicinithart(void)
{
    800047aa:	1141                	addi	sp,sp,-16
    800047ac:	e406                	sd	ra,8(sp)
    800047ae:	e022                	sd	s0,0(sp)
    800047b0:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800047b2:	dd4fc0ef          	jal	80000d86 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800047b6:	0085171b          	slliw	a4,a0,0x8
    800047ba:	0c0027b7          	lui	a5,0xc002
    800047be:	97ba                	add	a5,a5,a4
    800047c0:	40200713          	li	a4,1026
    800047c4:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

#ifdef LAB_NET
  // hack to get at next 32 IRQs for e1000
  *(uint32*)(PLIC_SENABLE(hart)+4) = 0xffffffff;
    800047c8:	577d                	li	a4,-1
    800047ca:	08e7a223          	sw	a4,132(a5)
#endif
  
  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800047ce:	00d5151b          	slliw	a0,a0,0xd
    800047d2:	0c2017b7          	lui	a5,0xc201
    800047d6:	97aa                	add	a5,a5,a0
    800047d8:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800047dc:	60a2                	ld	ra,8(sp)
    800047de:	6402                	ld	s0,0(sp)
    800047e0:	0141                	addi	sp,sp,16
    800047e2:	8082                	ret

00000000800047e4 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800047e4:	1141                	addi	sp,sp,-16
    800047e6:	e406                	sd	ra,8(sp)
    800047e8:	e022                	sd	s0,0(sp)
    800047ea:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800047ec:	d9afc0ef          	jal	80000d86 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800047f0:	00d5151b          	slliw	a0,a0,0xd
    800047f4:	0c2017b7          	lui	a5,0xc201
    800047f8:	97aa                	add	a5,a5,a0
  return irq;
}
    800047fa:	43c8                	lw	a0,4(a5)
    800047fc:	60a2                	ld	ra,8(sp)
    800047fe:	6402                	ld	s0,0(sp)
    80004800:	0141                	addi	sp,sp,16
    80004802:	8082                	ret

0000000080004804 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80004804:	1101                	addi	sp,sp,-32
    80004806:	ec06                	sd	ra,24(sp)
    80004808:	e822                	sd	s0,16(sp)
    8000480a:	e426                	sd	s1,8(sp)
    8000480c:	1000                	addi	s0,sp,32
    8000480e:	84aa                	mv	s1,a0
  int hart = cpuid();
    80004810:	d76fc0ef          	jal	80000d86 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80004814:	00d5179b          	slliw	a5,a0,0xd
    80004818:	0c201737          	lui	a4,0xc201
    8000481c:	97ba                	add	a5,a5,a4
    8000481e:	c3c4                	sw	s1,4(a5)
}
    80004820:	60e2                	ld	ra,24(sp)
    80004822:	6442                	ld	s0,16(sp)
    80004824:	64a2                	ld	s1,8(sp)
    80004826:	6105                	addi	sp,sp,32
    80004828:	8082                	ret

000000008000482a <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    8000482a:	1141                	addi	sp,sp,-16
    8000482c:	e406                	sd	ra,8(sp)
    8000482e:	e022                	sd	s0,0(sp)
    80004830:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80004832:	479d                	li	a5,7
    80004834:	04a7ca63          	blt	a5,a0,80004888 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80004838:	00015797          	auipc	a5,0x15
    8000483c:	30878793          	addi	a5,a5,776 # 80019b40 <disk>
    80004840:	97aa                	add	a5,a5,a0
    80004842:	0187c783          	lbu	a5,24(a5)
    80004846:	e7b9                	bnez	a5,80004894 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80004848:	00451693          	slli	a3,a0,0x4
    8000484c:	00015797          	auipc	a5,0x15
    80004850:	2f478793          	addi	a5,a5,756 # 80019b40 <disk>
    80004854:	6398                	ld	a4,0(a5)
    80004856:	9736                	add	a4,a4,a3
    80004858:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    8000485c:	6398                	ld	a4,0(a5)
    8000485e:	9736                	add	a4,a4,a3
    80004860:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80004864:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80004868:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    8000486c:	97aa                	add	a5,a5,a0
    8000486e:	4705                	li	a4,1
    80004870:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80004874:	00015517          	auipc	a0,0x15
    80004878:	2e450513          	addi	a0,a0,740 # 80019b58 <disk+0x18>
    8000487c:	b5dfc0ef          	jal	800013d8 <wakeup>
}
    80004880:	60a2                	ld	ra,8(sp)
    80004882:	6402                	ld	s0,0(sp)
    80004884:	0141                	addi	sp,sp,16
    80004886:	8082                	ret
    panic("free_desc 1");
    80004888:	00004517          	auipc	a0,0x4
    8000488c:	d9850513          	addi	a0,a0,-616 # 80008620 <etext+0x620>
    80004890:	249010ef          	jal	800062d8 <panic>
    panic("free_desc 2");
    80004894:	00004517          	auipc	a0,0x4
    80004898:	d9c50513          	addi	a0,a0,-612 # 80008630 <etext+0x630>
    8000489c:	23d010ef          	jal	800062d8 <panic>

00000000800048a0 <virtio_disk_init>:
{
    800048a0:	1101                	addi	sp,sp,-32
    800048a2:	ec06                	sd	ra,24(sp)
    800048a4:	e822                	sd	s0,16(sp)
    800048a6:	e426                	sd	s1,8(sp)
    800048a8:	e04a                	sd	s2,0(sp)
    800048aa:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800048ac:	00004597          	auipc	a1,0x4
    800048b0:	d9458593          	addi	a1,a1,-620 # 80008640 <etext+0x640>
    800048b4:	00015517          	auipc	a0,0x15
    800048b8:	3b450513          	addi	a0,a0,948 # 80019c68 <disk+0x128>
    800048bc:	4d1010ef          	jal	8000658c <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800048c0:	100017b7          	lui	a5,0x10001
    800048c4:	4398                	lw	a4,0(a5)
    800048c6:	2701                	sext.w	a4,a4
    800048c8:	747277b7          	lui	a5,0x74727
    800048cc:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800048d0:	14f71863          	bne	a4,a5,80004a20 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800048d4:	100017b7          	lui	a5,0x10001
    800048d8:	43dc                	lw	a5,4(a5)
    800048da:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800048dc:	4709                	li	a4,2
    800048de:	14e79163          	bne	a5,a4,80004a20 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800048e2:	100017b7          	lui	a5,0x10001
    800048e6:	479c                	lw	a5,8(a5)
    800048e8:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800048ea:	12e79b63          	bne	a5,a4,80004a20 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800048ee:	100017b7          	lui	a5,0x10001
    800048f2:	47d8                	lw	a4,12(a5)
    800048f4:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800048f6:	554d47b7          	lui	a5,0x554d4
    800048fa:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800048fe:	12f71163          	bne	a4,a5,80004a20 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004902:	100017b7          	lui	a5,0x10001
    80004906:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000490a:	4705                	li	a4,1
    8000490c:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000490e:	470d                	li	a4,3
    80004910:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80004912:	10001737          	lui	a4,0x10001
    80004916:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80004918:	c7ffe6b7          	lui	a3,0xc7ffe
    8000491c:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47f7869f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80004920:	8f75                	and	a4,a4,a3
    80004922:	100016b7          	lui	a3,0x10001
    80004926:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004928:	472d                	li	a4,11
    8000492a:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000492c:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80004930:	439c                	lw	a5,0(a5)
    80004932:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80004936:	8ba1                	andi	a5,a5,8
    80004938:	0e078a63          	beqz	a5,80004a2c <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8000493c:	100017b7          	lui	a5,0x10001
    80004940:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80004944:	43fc                	lw	a5,68(a5)
    80004946:	2781                	sext.w	a5,a5
    80004948:	0e079863          	bnez	a5,80004a38 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    8000494c:	100017b7          	lui	a5,0x10001
    80004950:	5bdc                	lw	a5,52(a5)
    80004952:	2781                	sext.w	a5,a5
  if(max == 0)
    80004954:	0e078863          	beqz	a5,80004a44 <virtio_disk_init+0x1a4>
  if(max < NUM)
    80004958:	471d                	li	a4,7
    8000495a:	0ef77b63          	bgeu	a4,a5,80004a50 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    8000495e:	fa6fb0ef          	jal	80000104 <kalloc>
    80004962:	00015497          	auipc	s1,0x15
    80004966:	1de48493          	addi	s1,s1,478 # 80019b40 <disk>
    8000496a:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    8000496c:	f98fb0ef          	jal	80000104 <kalloc>
    80004970:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004972:	f92fb0ef          	jal	80000104 <kalloc>
    80004976:	87aa                	mv	a5,a0
    80004978:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    8000497a:	6088                	ld	a0,0(s1)
    8000497c:	0e050063          	beqz	a0,80004a5c <virtio_disk_init+0x1bc>
    80004980:	00015717          	auipc	a4,0x15
    80004984:	1c873703          	ld	a4,456(a4) # 80019b48 <disk+0x8>
    80004988:	cb71                	beqz	a4,80004a5c <virtio_disk_init+0x1bc>
    8000498a:	cbe9                	beqz	a5,80004a5c <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    8000498c:	6605                	lui	a2,0x1
    8000498e:	4581                	li	a1,0
    80004990:	fcefb0ef          	jal	8000015e <memset>
  memset(disk.avail, 0, PGSIZE);
    80004994:	00015497          	auipc	s1,0x15
    80004998:	1ac48493          	addi	s1,s1,428 # 80019b40 <disk>
    8000499c:	6605                	lui	a2,0x1
    8000499e:	4581                	li	a1,0
    800049a0:	6488                	ld	a0,8(s1)
    800049a2:	fbcfb0ef          	jal	8000015e <memset>
  memset(disk.used, 0, PGSIZE);
    800049a6:	6605                	lui	a2,0x1
    800049a8:	4581                	li	a1,0
    800049aa:	6888                	ld	a0,16(s1)
    800049ac:	fb2fb0ef          	jal	8000015e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800049b0:	100017b7          	lui	a5,0x10001
    800049b4:	4721                	li	a4,8
    800049b6:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800049b8:	4098                	lw	a4,0(s1)
    800049ba:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800049be:	40d8                	lw	a4,4(s1)
    800049c0:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800049c4:	649c                	ld	a5,8(s1)
    800049c6:	0007869b          	sext.w	a3,a5
    800049ca:	10001737          	lui	a4,0x10001
    800049ce:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800049d2:	9781                	srai	a5,a5,0x20
    800049d4:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800049d8:	689c                	ld	a5,16(s1)
    800049da:	0007869b          	sext.w	a3,a5
    800049de:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800049e2:	9781                	srai	a5,a5,0x20
    800049e4:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800049e8:	4785                	li	a5,1
    800049ea:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800049ec:	00f48c23          	sb	a5,24(s1)
    800049f0:	00f48ca3          	sb	a5,25(s1)
    800049f4:	00f48d23          	sb	a5,26(s1)
    800049f8:	00f48da3          	sb	a5,27(s1)
    800049fc:	00f48e23          	sb	a5,28(s1)
    80004a00:	00f48ea3          	sb	a5,29(s1)
    80004a04:	00f48f23          	sb	a5,30(s1)
    80004a08:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80004a0c:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80004a10:	07272823          	sw	s2,112(a4)
}
    80004a14:	60e2                	ld	ra,24(sp)
    80004a16:	6442                	ld	s0,16(sp)
    80004a18:	64a2                	ld	s1,8(sp)
    80004a1a:	6902                	ld	s2,0(sp)
    80004a1c:	6105                	addi	sp,sp,32
    80004a1e:	8082                	ret
    panic("could not find virtio disk");
    80004a20:	00004517          	auipc	a0,0x4
    80004a24:	c3050513          	addi	a0,a0,-976 # 80008650 <etext+0x650>
    80004a28:	0b1010ef          	jal	800062d8 <panic>
    panic("virtio disk FEATURES_OK unset");
    80004a2c:	00004517          	auipc	a0,0x4
    80004a30:	c4450513          	addi	a0,a0,-956 # 80008670 <etext+0x670>
    80004a34:	0a5010ef          	jal	800062d8 <panic>
    panic("virtio disk should not be ready");
    80004a38:	00004517          	auipc	a0,0x4
    80004a3c:	c5850513          	addi	a0,a0,-936 # 80008690 <etext+0x690>
    80004a40:	099010ef          	jal	800062d8 <panic>
    panic("virtio disk has no queue 0");
    80004a44:	00004517          	auipc	a0,0x4
    80004a48:	c6c50513          	addi	a0,a0,-916 # 800086b0 <etext+0x6b0>
    80004a4c:	08d010ef          	jal	800062d8 <panic>
    panic("virtio disk max queue too short");
    80004a50:	00004517          	auipc	a0,0x4
    80004a54:	c8050513          	addi	a0,a0,-896 # 800086d0 <etext+0x6d0>
    80004a58:	081010ef          	jal	800062d8 <panic>
    panic("virtio disk kalloc");
    80004a5c:	00004517          	auipc	a0,0x4
    80004a60:	c9450513          	addi	a0,a0,-876 # 800086f0 <etext+0x6f0>
    80004a64:	075010ef          	jal	800062d8 <panic>

0000000080004a68 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004a68:	711d                	addi	sp,sp,-96
    80004a6a:	ec86                	sd	ra,88(sp)
    80004a6c:	e8a2                	sd	s0,80(sp)
    80004a6e:	e4a6                	sd	s1,72(sp)
    80004a70:	e0ca                	sd	s2,64(sp)
    80004a72:	fc4e                	sd	s3,56(sp)
    80004a74:	f852                	sd	s4,48(sp)
    80004a76:	f456                	sd	s5,40(sp)
    80004a78:	f05a                	sd	s6,32(sp)
    80004a7a:	ec5e                	sd	s7,24(sp)
    80004a7c:	e862                	sd	s8,16(sp)
    80004a7e:	1080                	addi	s0,sp,96
    80004a80:	89aa                	mv	s3,a0
    80004a82:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004a84:	00c52b83          	lw	s7,12(a0)
    80004a88:	001b9b9b          	slliw	s7,s7,0x1
    80004a8c:	1b82                	slli	s7,s7,0x20
    80004a8e:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80004a92:	00015517          	auipc	a0,0x15
    80004a96:	1d650513          	addi	a0,a0,470 # 80019c68 <disk+0x128>
    80004a9a:	37d010ef          	jal	80006616 <acquire>
  for(int i = 0; i < NUM; i++){
    80004a9e:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004aa0:	00015a97          	auipc	s5,0x15
    80004aa4:	0a0a8a93          	addi	s5,s5,160 # 80019b40 <disk>
  for(int i = 0; i < 3; i++){
    80004aa8:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80004aaa:	5c7d                	li	s8,-1
    80004aac:	a095                	j	80004b10 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80004aae:	00fa8733          	add	a4,s5,a5
    80004ab2:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004ab6:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004ab8:	0207c563          	bltz	a5,80004ae2 <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80004abc:	2905                	addiw	s2,s2,1
    80004abe:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80004ac0:	05490c63          	beq	s2,s4,80004b18 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    80004ac4:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004ac6:	00015717          	auipc	a4,0x15
    80004aca:	07a70713          	addi	a4,a4,122 # 80019b40 <disk>
    80004ace:	4781                	li	a5,0
    if(disk.free[i]){
    80004ad0:	01874683          	lbu	a3,24(a4)
    80004ad4:	fee9                	bnez	a3,80004aae <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80004ad6:	2785                	addiw	a5,a5,1
    80004ad8:	0705                	addi	a4,a4,1
    80004ada:	fe979be3          	bne	a5,s1,80004ad0 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80004ade:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80004ae2:	01205d63          	blez	s2,80004afc <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004ae6:	fa042503          	lw	a0,-96(s0)
    80004aea:	d41ff0ef          	jal	8000482a <free_desc>
      for(int j = 0; j < i; j++)
    80004aee:	4785                	li	a5,1
    80004af0:	0127d663          	bge	a5,s2,80004afc <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004af4:	fa442503          	lw	a0,-92(s0)
    80004af8:	d33ff0ef          	jal	8000482a <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004afc:	00015597          	auipc	a1,0x15
    80004b00:	16c58593          	addi	a1,a1,364 # 80019c68 <disk+0x128>
    80004b04:	00015517          	auipc	a0,0x15
    80004b08:	05450513          	addi	a0,a0,84 # 80019b58 <disk+0x18>
    80004b0c:	881fc0ef          	jal	8000138c <sleep>
  for(int i = 0; i < 3; i++){
    80004b10:	fa040613          	addi	a2,s0,-96
    80004b14:	4901                	li	s2,0
    80004b16:	b77d                	j	80004ac4 <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004b18:	fa042503          	lw	a0,-96(s0)
    80004b1c:	00451693          	slli	a3,a0,0x4

  if(write)
    80004b20:	00015797          	auipc	a5,0x15
    80004b24:	02078793          	addi	a5,a5,32 # 80019b40 <disk>
    80004b28:	00451713          	slli	a4,a0,0x4
    80004b2c:	0a070713          	addi	a4,a4,160
    80004b30:	973e                	add	a4,a4,a5
    80004b32:	01603633          	snez	a2,s6
    80004b36:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004b38:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004b3c:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004b40:	6398                	ld	a4,0(a5)
    80004b42:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004b44:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80004b48:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004b4a:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004b4c:	6390                	ld	a2,0(a5)
    80004b4e:	00d60833          	add	a6,a2,a3
    80004b52:	4741                	li	a4,16
    80004b54:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004b58:	4585                	li	a1,1
    80004b5a:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80004b5e:	fa442703          	lw	a4,-92(s0)
    80004b62:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004b66:	0712                	slli	a4,a4,0x4
    80004b68:	963a                	add	a2,a2,a4
    80004b6a:	05898813          	addi	a6,s3,88
    80004b6e:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80004b72:	0007b883          	ld	a7,0(a5)
    80004b76:	9746                	add	a4,a4,a7
    80004b78:	40000613          	li	a2,1024
    80004b7c:	c710                	sw	a2,8(a4)
  if(write)
    80004b7e:	001b3613          	seqz	a2,s6
    80004b82:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004b86:	8e4d                	or	a2,a2,a1
    80004b88:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004b8c:	fa842603          	lw	a2,-88(s0)
    80004b90:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004b94:	00451813          	slli	a6,a0,0x4
    80004b98:	02080813          	addi	a6,a6,32
    80004b9c:	983e                	add	a6,a6,a5
    80004b9e:	577d                	li	a4,-1
    80004ba0:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004ba4:	0612                	slli	a2,a2,0x4
    80004ba6:	98b2                	add	a7,a7,a2
    80004ba8:	03068713          	addi	a4,a3,48
    80004bac:	973e                	add	a4,a4,a5
    80004bae:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80004bb2:	6398                	ld	a4,0(a5)
    80004bb4:	9732                	add	a4,a4,a2
    80004bb6:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004bb8:	4689                	li	a3,2
    80004bba:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80004bbe:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004bc2:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80004bc6:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004bca:	6794                	ld	a3,8(a5)
    80004bcc:	0026d703          	lhu	a4,2(a3)
    80004bd0:	8b1d                	andi	a4,a4,7
    80004bd2:	0706                	slli	a4,a4,0x1
    80004bd4:	96ba                	add	a3,a3,a4
    80004bd6:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80004bda:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004bde:	6798                	ld	a4,8(a5)
    80004be0:	00275783          	lhu	a5,2(a4)
    80004be4:	2785                	addiw	a5,a5,1
    80004be6:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004bea:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004bee:	100017b7          	lui	a5,0x10001
    80004bf2:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004bf6:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80004bfa:	00015917          	auipc	s2,0x15
    80004bfe:	06e90913          	addi	s2,s2,110 # 80019c68 <disk+0x128>
  while(b->disk == 1) {
    80004c02:	84ae                	mv	s1,a1
    80004c04:	00b79a63          	bne	a5,a1,80004c18 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80004c08:	85ca                	mv	a1,s2
    80004c0a:	854e                	mv	a0,s3
    80004c0c:	f80fc0ef          	jal	8000138c <sleep>
  while(b->disk == 1) {
    80004c10:	0049a783          	lw	a5,4(s3)
    80004c14:	fe978ae3          	beq	a5,s1,80004c08 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80004c18:	fa042903          	lw	s2,-96(s0)
    80004c1c:	00491713          	slli	a4,s2,0x4
    80004c20:	02070713          	addi	a4,a4,32
    80004c24:	00015797          	auipc	a5,0x15
    80004c28:	f1c78793          	addi	a5,a5,-228 # 80019b40 <disk>
    80004c2c:	97ba                	add	a5,a5,a4
    80004c2e:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004c32:	00015997          	auipc	s3,0x15
    80004c36:	f0e98993          	addi	s3,s3,-242 # 80019b40 <disk>
    80004c3a:	00491713          	slli	a4,s2,0x4
    80004c3e:	0009b783          	ld	a5,0(s3)
    80004c42:	97ba                	add	a5,a5,a4
    80004c44:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004c48:	854a                	mv	a0,s2
    80004c4a:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004c4e:	bddff0ef          	jal	8000482a <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004c52:	8885                	andi	s1,s1,1
    80004c54:	f0fd                	bnez	s1,80004c3a <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004c56:	00015517          	auipc	a0,0x15
    80004c5a:	01250513          	addi	a0,a0,18 # 80019c68 <disk+0x128>
    80004c5e:	24d010ef          	jal	800066aa <release>
}
    80004c62:	60e6                	ld	ra,88(sp)
    80004c64:	6446                	ld	s0,80(sp)
    80004c66:	64a6                	ld	s1,72(sp)
    80004c68:	6906                	ld	s2,64(sp)
    80004c6a:	79e2                	ld	s3,56(sp)
    80004c6c:	7a42                	ld	s4,48(sp)
    80004c6e:	7aa2                	ld	s5,40(sp)
    80004c70:	7b02                	ld	s6,32(sp)
    80004c72:	6be2                	ld	s7,24(sp)
    80004c74:	6c42                	ld	s8,16(sp)
    80004c76:	6125                	addi	sp,sp,96
    80004c78:	8082                	ret

0000000080004c7a <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004c7a:	1101                	addi	sp,sp,-32
    80004c7c:	ec06                	sd	ra,24(sp)
    80004c7e:	e822                	sd	s0,16(sp)
    80004c80:	e426                	sd	s1,8(sp)
    80004c82:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004c84:	00015497          	auipc	s1,0x15
    80004c88:	ebc48493          	addi	s1,s1,-324 # 80019b40 <disk>
    80004c8c:	00015517          	auipc	a0,0x15
    80004c90:	fdc50513          	addi	a0,a0,-36 # 80019c68 <disk+0x128>
    80004c94:	183010ef          	jal	80006616 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004c98:	100017b7          	lui	a5,0x10001
    80004c9c:	53bc                	lw	a5,96(a5)
    80004c9e:	8b8d                	andi	a5,a5,3
    80004ca0:	10001737          	lui	a4,0x10001
    80004ca4:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004ca6:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004caa:	689c                	ld	a5,16(s1)
    80004cac:	0204d703          	lhu	a4,32(s1)
    80004cb0:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80004cb4:	04f70863          	beq	a4,a5,80004d04 <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80004cb8:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004cbc:	6898                	ld	a4,16(s1)
    80004cbe:	0204d783          	lhu	a5,32(s1)
    80004cc2:	8b9d                	andi	a5,a5,7
    80004cc4:	078e                	slli	a5,a5,0x3
    80004cc6:	97ba                	add	a5,a5,a4
    80004cc8:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004cca:	00479713          	slli	a4,a5,0x4
    80004cce:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80004cd2:	9726                	add	a4,a4,s1
    80004cd4:	01074703          	lbu	a4,16(a4)
    80004cd8:	e329                	bnez	a4,80004d1a <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004cda:	0792                	slli	a5,a5,0x4
    80004cdc:	02078793          	addi	a5,a5,32
    80004ce0:	97a6                	add	a5,a5,s1
    80004ce2:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004ce4:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004ce8:	ef0fc0ef          	jal	800013d8 <wakeup>

    disk.used_idx += 1;
    80004cec:	0204d783          	lhu	a5,32(s1)
    80004cf0:	2785                	addiw	a5,a5,1
    80004cf2:	17c2                	slli	a5,a5,0x30
    80004cf4:	93c1                	srli	a5,a5,0x30
    80004cf6:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004cfa:	6898                	ld	a4,16(s1)
    80004cfc:	00275703          	lhu	a4,2(a4)
    80004d00:	faf71ce3          	bne	a4,a5,80004cb8 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80004d04:	00015517          	auipc	a0,0x15
    80004d08:	f6450513          	addi	a0,a0,-156 # 80019c68 <disk+0x128>
    80004d0c:	19f010ef          	jal	800066aa <release>
}
    80004d10:	60e2                	ld	ra,24(sp)
    80004d12:	6442                	ld	s0,16(sp)
    80004d14:	64a2                	ld	s1,8(sp)
    80004d16:	6105                	addi	sp,sp,32
    80004d18:	8082                	ret
      panic("virtio_disk_intr status");
    80004d1a:	00004517          	auipc	a0,0x4
    80004d1e:	9ee50513          	addi	a0,a0,-1554 # 80008708 <etext+0x708>
    80004d22:	5b6010ef          	jal	800062d8 <panic>

0000000080004d26 <e1000_init>:
// called by pci_init().
// xregs is the memory address at which the
// e1000's registers are mapped.
void
e1000_init(uint32 *xregs)
{
    80004d26:	7179                	addi	sp,sp,-48
    80004d28:	f406                	sd	ra,40(sp)
    80004d2a:	f022                	sd	s0,32(sp)
    80004d2c:	ec26                	sd	s1,24(sp)
    80004d2e:	e84a                	sd	s2,16(sp)
    80004d30:	e44e                	sd	s3,8(sp)
    80004d32:	1800                	addi	s0,sp,48
    80004d34:	84aa                	mv	s1,a0
    int i;

    initlock(&e1000_lock, "e1000");
    80004d36:	00004597          	auipc	a1,0x4
    80004d3a:	9ea58593          	addi	a1,a1,-1558 # 80008720 <etext+0x720>
    80004d3e:	00015517          	auipc	a0,0x15
    80004d42:	f4250513          	addi	a0,a0,-190 # 80019c80 <e1000_lock>
    80004d46:	047010ef          	jal	8000658c <initlock>

    regs = xregs;
    80004d4a:	00004797          	auipc	a5,0x4
    80004d4e:	cc97bb23          	sd	s1,-810(a5) # 80008a20 <regs>

    // Reset the device
    regs[E1000_IMS] = 0; // disable interrupts
    80004d52:	0c04a823          	sw	zero,208(s1)
    regs[E1000_CTL] |= E1000_CTL_RST;
    80004d56:	409c                	lw	a5,0(s1)
    80004d58:	04000737          	lui	a4,0x4000
    80004d5c:	8fd9                	or	a5,a5,a4
    80004d5e:	c09c                	sw	a5,0(s1)
    regs[E1000_IMS] = 0; // redisable interrupts
    80004d60:	0c04a823          	sw	zero,208(s1)
    __sync_synchronize();
    80004d64:	0330000f          	fence	rw,rw

    // [E1000 14.5] Transmit initialization
    memset(tx_ring, 0, sizeof(tx_ring));
    80004d68:	10000613          	li	a2,256
    80004d6c:	4581                	li	a1,0
    80004d6e:	00015517          	auipc	a0,0x15
    80004d72:	f3250513          	addi	a0,a0,-206 # 80019ca0 <tx_ring>
    80004d76:	be8fb0ef          	jal	8000015e <memset>
    for (i = 0; i < TX_RING_SIZE; i++) {
    80004d7a:	00015717          	auipc	a4,0x15
    80004d7e:	f3270713          	addi	a4,a4,-206 # 80019cac <tx_ring+0xc>
    80004d82:	00015797          	auipc	a5,0x15
    80004d86:	01e78793          	addi	a5,a5,30 # 80019da0 <tx_bufs>
    80004d8a:	00015617          	auipc	a2,0x15
    80004d8e:	09660613          	addi	a2,a2,150 # 80019e20 <rx_ring>
        tx_ring[i].status = E1000_TXD_STAT_DD;
    80004d92:	4685                	li	a3,1
    80004d94:	00d70023          	sb	a3,0(a4)
        tx_bufs[i] = 0;
    80004d98:	0007b023          	sd	zero,0(a5)
    for (i = 0; i < TX_RING_SIZE; i++) {
    80004d9c:	0741                	addi	a4,a4,16
    80004d9e:	07a1                	addi	a5,a5,8
    80004da0:	fec79ae3          	bne	a5,a2,80004d94 <e1000_init+0x6e>
    }
    regs[E1000_TDBAL] = (uint64) tx_ring;
    80004da4:	00015717          	auipc	a4,0x15
    80004da8:	efc70713          	addi	a4,a4,-260 # 80019ca0 <tx_ring>
    80004dac:	00004797          	auipc	a5,0x4
    80004db0:	c747b783          	ld	a5,-908(a5) # 80008a20 <regs>
    80004db4:	6691                	lui	a3,0x4
    80004db6:	97b6                	add	a5,a5,a3
    80004db8:	80e7a023          	sw	a4,-2048(a5)
    if(sizeof(tx_ring) % 128 != 0)
        panic("e1000");
    regs[E1000_TDLEN] = sizeof(tx_ring);
    80004dbc:	10000713          	li	a4,256
    80004dc0:	80e7a423          	sw	a4,-2040(a5)
    regs[E1000_TDH] = regs[E1000_TDT] = 0;
    80004dc4:	8007ac23          	sw	zero,-2024(a5)
    80004dc8:	8007a823          	sw	zero,-2032(a5)

    // [E1000 14.4] Receive initialization
    memset(rx_ring, 0, sizeof(rx_ring));
    80004dcc:	863a                	mv	a2,a4
    80004dce:	4581                	li	a1,0
    80004dd0:	00015517          	auipc	a0,0x15
    80004dd4:	05050513          	addi	a0,a0,80 # 80019e20 <rx_ring>
    80004dd8:	b86fb0ef          	jal	8000015e <memset>
    for (i = 0; i < RX_RING_SIZE; i++) {
    80004ddc:	00015497          	auipc	s1,0x15
    80004de0:	14448493          	addi	s1,s1,324 # 80019f20 <rx_bufs>
    80004de4:	00015917          	auipc	s2,0x15
    80004de8:	03c90913          	addi	s2,s2,60 # 80019e20 <rx_ring>
    80004dec:	00015997          	auipc	s3,0x15
    80004df0:	1b498993          	addi	s3,s3,436 # 80019fa0 <netlock>
        rx_bufs[i] = kalloc();
    80004df4:	b10fb0ef          	jal	80000104 <kalloc>
    80004df8:	e088                	sd	a0,0(s1)
        if (!rx_bufs[i])
    80004dfa:	c945                	beqz	a0,80004eaa <e1000_init+0x184>
            panic("e1000");
        rx_ring[i].addr = (uint64) rx_bufs[i];
    80004dfc:	00a93023          	sd	a0,0(s2)
    for (i = 0; i < RX_RING_SIZE; i++) {
    80004e00:	04a1                	addi	s1,s1,8
    80004e02:	0941                	addi	s2,s2,16
    80004e04:	ff3498e3          	bne	s1,s3,80004df4 <e1000_init+0xce>
    }
    regs[E1000_RDBAL] = (uint64) rx_ring;
    80004e08:	00004697          	auipc	a3,0x4
    80004e0c:	c186b683          	ld	a3,-1000(a3) # 80008a20 <regs>
    80004e10:	00015717          	auipc	a4,0x15
    80004e14:	01070713          	addi	a4,a4,16 # 80019e20 <rx_ring>
    80004e18:	678d                	lui	a5,0x3
    80004e1a:	97b6                	add	a5,a5,a3
    80004e1c:	80e7a023          	sw	a4,-2048(a5) # 2800 <_entry-0x7fffd800>
    if(sizeof(rx_ring) % 128 != 0)
        panic("e1000");
    regs[E1000_RDH] = 0;
    80004e20:	8007a823          	sw	zero,-2032(a5)
    regs[E1000_RDT] = RX_RING_SIZE - 1;
    80004e24:	473d                	li	a4,15
    80004e26:	80e7ac23          	sw	a4,-2024(a5)
    regs[E1000_RDLEN] = sizeof(rx_ring);
    80004e2a:	10000713          	li	a4,256
    80004e2e:	80e7a423          	sw	a4,-2040(a5)

    // filter by qemu's MAC address, 52:54:00:12:34:56
    regs[E1000_RA] = 0x12005452;
    80004e32:	6795                	lui	a5,0x5
    80004e34:	97b6                	add	a5,a5,a3
    80004e36:	12005737          	lui	a4,0x12005
    80004e3a:	45270713          	addi	a4,a4,1106 # 12005452 <_entry-0x6dffabae>
    80004e3e:	40e7a023          	sw	a4,1024(a5) # 5400 <_entry-0x7fffac00>
    regs[E1000_RA+1] = 0x5634 | (1<<31);
    80004e42:	80005737          	lui	a4,0x80005
    80004e46:	63470713          	addi	a4,a4,1588 # ffffffff80005634 <end+0xfffffffefff7f574>
    80004e4a:	40e7a223          	sw	a4,1028(a5)
    // multicast table
    for (int i = 0; i < 4096/32; i++)
    80004e4e:	6795                	lui	a5,0x5
    80004e50:	20078793          	addi	a5,a5,512 # 5200 <_entry-0x7fffae00>
    80004e54:	97b6                	add	a5,a5,a3
    80004e56:	6715                	lui	a4,0x5
    80004e58:	40070713          	addi	a4,a4,1024 # 5400 <_entry-0x7fffac00>
    80004e5c:	9736                	add	a4,a4,a3
        regs[E1000_MTA + i] = 0;
    80004e5e:	0007a023          	sw	zero,0(a5)
    for (int i = 0; i < 4096/32; i++)
    80004e62:	0791                	addi	a5,a5,4
    80004e64:	fee79de3          	bne	a5,a4,80004e5e <e1000_init+0x138>

    // transmitter control bits.
    regs[E1000_TCTL] = E1000_TCTL_EN |  // enable
    80004e68:	000407b7          	lui	a5,0x40
    80004e6c:	10a78793          	addi	a5,a5,266 # 4010a <_entry-0x7ffbfef6>
    80004e70:	40f6a023          	sw	a5,1024(a3)
                       E1000_TCTL_PSP |                  // pad short packets
                       (0x10 << E1000_TCTL_CT_SHIFT) |   // collision stuff
                       (0x40 << E1000_TCTL_COLD_SHIFT);
    regs[E1000_TIPG] = 10 | (8<<10) | (6<<20); // inter-pkt gap
    80004e74:	006027b7          	lui	a5,0x602
    80004e78:	07a9                	addi	a5,a5,10 # 60200a <_entry-0x7f9fdff6>
    80004e7a:	40f6a823          	sw	a5,1040(a3)

    // receiver control bits.
    regs[E1000_RCTL] = E1000_RCTL_EN | // enable receiver
    80004e7e:	040087b7          	lui	a5,0x4008
    80004e82:	0789                	addi	a5,a5,2 # 4008002 <_entry-0x7bff7ffe>
    80004e84:	10f6a023          	sw	a5,256(a3)
                       E1000_RCTL_BAM |                 // enable broadcast
                       E1000_RCTL_SZ_2048 |             // 2048-byte rx buffers
                       E1000_RCTL_SECRC;                // strip CRC

    // ask e1000 for receive interrupts.
    regs[E1000_RDTR] = 0; // interrupt after every received packet (no timer)
    80004e88:	678d                	lui	a5,0x3
    80004e8a:	97b6                	add	a5,a5,a3
    80004e8c:	8207a023          	sw	zero,-2016(a5) # 2820 <_entry-0x7fffd7e0>
    regs[E1000_RADV] = 0; // interrupt after every packet (no timer)
    80004e90:	8207a623          	sw	zero,-2004(a5)
    regs[E1000_IMS] = (1 << 7); // RXDW -- Receiver Descriptor Write Back
    80004e94:	08000793          	li	a5,128
    80004e98:	0cf6a823          	sw	a5,208(a3)
}
    80004e9c:	70a2                	ld	ra,40(sp)
    80004e9e:	7402                	ld	s0,32(sp)
    80004ea0:	64e2                	ld	s1,24(sp)
    80004ea2:	6942                	ld	s2,16(sp)
    80004ea4:	69a2                	ld	s3,8(sp)
    80004ea6:	6145                	addi	sp,sp,48
    80004ea8:	8082                	ret
            panic("e1000");
    80004eaa:	00004517          	auipc	a0,0x4
    80004eae:	87650513          	addi	a0,a0,-1930 # 80008720 <etext+0x720>
    80004eb2:	426010ef          	jal	800062d8 <panic>

0000000080004eb6 <e1000_transmit>:

int
e1000_transmit(char *buf, int len)
{
    80004eb6:	7179                	addi	sp,sp,-48
    80004eb8:	f406                	sd	ra,40(sp)
    80004eba:	f022                	sd	s0,32(sp)
    80004ebc:	ec26                	sd	s1,24(sp)
    80004ebe:	e44e                	sd	s3,8(sp)
    80004ec0:	e052                	sd	s4,0(sp)
    80004ec2:	1800                	addi	s0,sp,48
    80004ec4:	8a2a                	mv	s4,a0
    80004ec6:	89ae                	mv	s3,a1
    acquire(&e1000_lock);
    80004ec8:	00015517          	auipc	a0,0x15
    80004ecc:	db850513          	addi	a0,a0,-584 # 80019c80 <e1000_lock>
    80004ed0:	746010ef          	jal	80006616 <acquire>

    uint32 tdt = regs[E1000_TDT];
    80004ed4:	00004797          	auipc	a5,0x4
    80004ed8:	b4c7b783          	ld	a5,-1204(a5) # 80008a20 <regs>
    80004edc:	6711                	lui	a4,0x4
    80004ede:	97ba                	add	a5,a5,a4
    80004ee0:	8187a783          	lw	a5,-2024(a5)
    80004ee4:	0007849b          	sext.w	s1,a5

    // 描述符是否可用
    if ((tx_ring[tdt].status & E1000_TXD_STAT_DD) == 0) {
    80004ee8:	02079713          	slli	a4,a5,0x20
    80004eec:	01c75793          	srli	a5,a4,0x1c
    80004ef0:	00015717          	auipc	a4,0x15
    80004ef4:	d9070713          	addi	a4,a4,-624 # 80019c80 <e1000_lock>
    80004ef8:	97ba                	add	a5,a5,a4
    80004efa:	02c7c783          	lbu	a5,44(a5)
    80004efe:	8b85                	andi	a5,a5,1
    80004f00:	c3dd                	beqz	a5,80004fa6 <e1000_transmit+0xf0>
    80004f02:	e84a                	sd	s2,16(sp)
        release(&e1000_lock);
        return -1;
    }

    // 如果有旧缓冲区，释放
    if (tx_bufs[tdt] != 0) {
    80004f04:	02049793          	slli	a5,s1,0x20
    80004f08:	01d7d713          	srli	a4,a5,0x1d
    80004f0c:	00015797          	auipc	a5,0x15
    80004f10:	d7478793          	addi	a5,a5,-652 # 80019c80 <e1000_lock>
    80004f14:	97ba                	add	a5,a5,a4
    80004f16:	1207b503          	ld	a0,288(a5)
    80004f1a:	cd11                	beqz	a0,80004f36 <e1000_transmit+0x80>
        kfree(tx_bufs[tdt]);
    80004f1c:	900fb0ef          	jal	8000001c <kfree>
        tx_bufs[tdt] = 0;
    80004f20:	02049793          	slli	a5,s1,0x20
    80004f24:	01d7d713          	srli	a4,a5,0x1d
    80004f28:	00015797          	auipc	a5,0x15
    80004f2c:	d5878793          	addi	a5,a5,-680 # 80019c80 <e1000_lock>
    80004f30:	97ba                	add	a5,a5,a4
    80004f32:	1207b023          	sd	zero,288(a5)
    }

    // 分配新缓冲区
    char *dma_buf = kalloc();
    80004f36:	9cefb0ef          	jal	80000104 <kalloc>
    80004f3a:	892a                	mv	s2,a0
    if (!dma_buf) {
    80004f3c:	c935                	beqz	a0,80004fb0 <e1000_transmit+0xfa>
        release(&e1000_lock);
        return -1;
    }

    // 拷贝数据
    memmove(dma_buf, buf, len);
    80004f3e:	864e                	mv	a2,s3
    80004f40:	85d2                	mv	a1,s4
    80004f42:	a7cfb0ef          	jal	800001be <memmove>

    // 设置描述符
    tx_ring[tdt].addr = (uint64) dma_buf;
    80004f46:	00015717          	auipc	a4,0x15
    80004f4a:	d3a70713          	addi	a4,a4,-710 # 80019c80 <e1000_lock>
    80004f4e:	02049693          	slli	a3,s1,0x20
    80004f52:	9281                	srli	a3,a3,0x20
    80004f54:	00469793          	slli	a5,a3,0x4
    80004f58:	97ba                	add	a5,a5,a4
    80004f5a:	0327b023          	sd	s2,32(a5)
    tx_ring[tdt].length = len;
    80004f5e:	03379423          	sh	s3,40(a5)
    tx_ring[tdt].cmd = E1000_TXD_CMD_EOP | E1000_TXD_CMD_RS;
    80004f62:	4625                	li	a2,9
    80004f64:	02c785a3          	sb	a2,43(a5)
    tx_ring[tdt].status = 0;
    80004f68:	02078623          	sb	zero,44(a5)

    // 保存指针
    tx_bufs[tdt] = dma_buf;
    80004f6c:	068e                	slli	a3,a3,0x3
    80004f6e:	9736                	add	a4,a4,a3
    80004f70:	13273023          	sd	s2,288(a4)

    // 更新指针
    regs[E1000_TDT] = (tdt + 1) % TX_RING_SIZE;
    80004f74:	2485                	addiw	s1,s1,1
    80004f76:	88bd                	andi	s1,s1,15
    80004f78:	00004797          	auipc	a5,0x4
    80004f7c:	aa87b783          	ld	a5,-1368(a5) # 80008a20 <regs>
    80004f80:	6711                	lui	a4,0x4
    80004f82:	97ba                	add	a5,a5,a4
    80004f84:	8097ac23          	sw	s1,-2024(a5)

    release(&e1000_lock);
    80004f88:	00015517          	auipc	a0,0x15
    80004f8c:	cf850513          	addi	a0,a0,-776 # 80019c80 <e1000_lock>
    80004f90:	71a010ef          	jal	800066aa <release>
    return 0;
    80004f94:	4501                	li	a0,0
    80004f96:	6942                	ld	s2,16(sp)
}
    80004f98:	70a2                	ld	ra,40(sp)
    80004f9a:	7402                	ld	s0,32(sp)
    80004f9c:	64e2                	ld	s1,24(sp)
    80004f9e:	69a2                	ld	s3,8(sp)
    80004fa0:	6a02                	ld	s4,0(sp)
    80004fa2:	6145                	addi	sp,sp,48
    80004fa4:	8082                	ret
        release(&e1000_lock);
    80004fa6:	853a                	mv	a0,a4
    80004fa8:	702010ef          	jal	800066aa <release>
        return -1;
    80004fac:	557d                	li	a0,-1
    80004fae:	b7ed                	j	80004f98 <e1000_transmit+0xe2>
        release(&e1000_lock);
    80004fb0:	00015517          	auipc	a0,0x15
    80004fb4:	cd050513          	addi	a0,a0,-816 # 80019c80 <e1000_lock>
    80004fb8:	6f2010ef          	jal	800066aa <release>
        return -1;
    80004fbc:	557d                	li	a0,-1
    80004fbe:	6942                	ld	s2,16(sp)
    80004fc0:	bfe1                	j	80004f98 <e1000_transmit+0xe2>

0000000080004fc2 <e1000_intr>:
    }
}

void
e1000_intr(void)
{
    80004fc2:	715d                	addi	sp,sp,-80
    80004fc4:	e486                	sd	ra,72(sp)
    80004fc6:	e0a2                	sd	s0,64(sp)
    80004fc8:	fc26                	sd	s1,56(sp)
    80004fca:	f84a                	sd	s2,48(sp)
    80004fcc:	f44e                	sd	s3,40(sp)
    80004fce:	f052                	sd	s4,32(sp)
    80004fd0:	ec56                	sd	s5,24(sp)
    80004fd2:	e85a                	sd	s6,16(sp)
    80004fd4:	e45e                	sd	s7,8(sp)
    80004fd6:	0880                	addi	s0,sp,80
    // tell the e1000 we've seen this interrupt;
    // without this the e1000 won't raise any
    // further interrupts.
    regs[E1000_ICR] = 0xffffffff;
    80004fd8:	00004797          	auipc	a5,0x4
    80004fdc:	a487b783          	ld	a5,-1464(a5) # 80008a20 <regs>
    80004fe0:	577d                	li	a4,-1
    80004fe2:	0ce7a023          	sw	a4,192(a5)
        acquire(&e1000_lock);
    80004fe6:	00015497          	auipc	s1,0x15
    80004fea:	c9a48493          	addi	s1,s1,-870 # 80019c80 <e1000_lock>
        uint32 rdt = regs[E1000_RDT];
    80004fee:	00004a17          	auipc	s4,0x4
    80004ff2:	a32a0a13          	addi	s4,s4,-1486 # 80008a20 <regs>
    80004ff6:	698d                	lui	s3,0x3
        acquire(&e1000_lock);
    80004ff8:	8526                	mv	a0,s1
    80004ffa:	61c010ef          	jal	80006616 <acquire>
        uint32 rdt = regs[E1000_RDT];
    80004ffe:	000a3783          	ld	a5,0(s4)
    80005002:	97ce                	add	a5,a5,s3
    80005004:	8187a783          	lw	a5,-2024(a5)
        uint32 next = (rdt + 1) % RX_RING_SIZE;
    80005008:	2785                	addiw	a5,a5,1
    8000500a:	00f7f913          	andi	s2,a5,15
        if ((rx_ring[next].status & E1000_RXD_STAT_DD) == 0) {
    8000500e:	00491793          	slli	a5,s2,0x4
    80005012:	97a6                	add	a5,a5,s1
    80005014:	1ac7c783          	lbu	a5,428(a5)
    80005018:	8b85                	andi	a5,a5,1
    8000501a:	c7a1                	beqz	a5,80005062 <e1000_intr+0xa0>
        char *buf = rx_bufs[next];
    8000501c:	00391a93          	slli	s5,s2,0x3
    80005020:	9aa6                	add	s5,s5,s1
    80005022:	2a0abb03          	ld	s6,672(s5)
        int len = rx_ring[next].length;
    80005026:	00491793          	slli	a5,s2,0x4
    8000502a:	97a6                	add	a5,a5,s1
    8000502c:	1a87db83          	lhu	s7,424(a5)
        rx_bufs[next] = kalloc();
    80005030:	8d4fb0ef          	jal	80000104 <kalloc>
    80005034:	2aaab023          	sd	a0,672(s5)
        if (!rx_bufs[next]) {
    80005038:	c531                	beqz	a0,80005084 <e1000_intr+0xc2>
        rx_ring[next].addr = (uint64) rx_bufs[next];
    8000503a:	00491793          	slli	a5,s2,0x4
    8000503e:	97a6                	add	a5,a5,s1
    80005040:	1aa7b023          	sd	a0,416(a5)
        rx_ring[next].status = 0; // 清除状态位
    80005044:	1a078623          	sb	zero,428(a5)
        regs[E1000_RDT] = next;
    80005048:	000a3783          	ld	a5,0(s4)
    8000504c:	97ce                	add	a5,a5,s3
    8000504e:	8127ac23          	sw	s2,-2024(a5)
        release(&e1000_lock);
    80005052:	8526                	mv	a0,s1
    80005054:	656010ef          	jal	800066aa <release>
        net_rx(buf, len);
    80005058:	85de                	mv	a1,s7
    8000505a:	855a                	mv	a0,s6
    8000505c:	1dd000ef          	jal	80005a38 <net_rx>
    while(1) {
    80005060:	bf61                	j	80004ff8 <e1000_intr+0x36>
            release(&e1000_lock);
    80005062:	00015517          	auipc	a0,0x15
    80005066:	c1e50513          	addi	a0,a0,-994 # 80019c80 <e1000_lock>
    8000506a:	640010ef          	jal	800066aa <release>

    e1000_recv();
}
    8000506e:	60a6                	ld	ra,72(sp)
    80005070:	6406                	ld	s0,64(sp)
    80005072:	74e2                	ld	s1,56(sp)
    80005074:	7942                	ld	s2,48(sp)
    80005076:	79a2                	ld	s3,40(sp)
    80005078:	7a02                	ld	s4,32(sp)
    8000507a:	6ae2                	ld	s5,24(sp)
    8000507c:	6b42                	ld	s6,16(sp)
    8000507e:	6ba2                	ld	s7,8(sp)
    80005080:	6161                	addi	sp,sp,80
    80005082:	8082                	ret
            panic("e1000_recv: kalloc failed");
    80005084:	00003517          	auipc	a0,0x3
    80005088:	6a450513          	addi	a0,a0,1700 # 80008728 <etext+0x728>
    8000508c:	24c010ef          	jal	800062d8 <panic>

0000000080005090 <udp_find_port_idx>:
    udp_table_inited = 1;
    release(&netlock);
}
static int
udp_find_port_idx(int port)
{
    80005090:	1141                	addi	sp,sp,-16
    80005092:	e406                	sd	ra,8(sp)
    80005094:	e022                	sd	s0,0(sp)
    80005096:	0800                	addi	s0,sp,16
    80005098:	86aa                	mv	a3,a0
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
    8000509a:	00015797          	auipc	a5,0x15
    8000509e:	f1e78793          	addi	a5,a5,-226 # 80019fb8 <udp_table>
    800050a2:	4501                	li	a0,0
    800050a4:	40000613          	li	a2,1024
        if (udp_table[i].port == port)
    800050a8:	4398                	lw	a4,0(a5)
    800050aa:	00d70863          	beq	a4,a3,800050ba <udp_find_port_idx+0x2a>
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
    800050ae:	2505                	addiw	a0,a0,1
    800050b0:	19078793          	addi	a5,a5,400
    800050b4:	fec51ae3          	bne	a0,a2,800050a8 <udp_find_port_idx+0x18>
            return i;
    }
    return -1;
    800050b8:	557d                	li	a0,-1
}
    800050ba:	60a2                	ld	ra,8(sp)
    800050bc:	6402                	ld	s0,0(sp)
    800050be:	0141                	addi	sp,sp,16
    800050c0:	8082                	ret

00000000800050c2 <udp_table_init>:
    if (udp_table_inited)
    800050c2:	00004797          	auipc	a5,0x4
    800050c6:	96e7a783          	lw	a5,-1682(a5) # 80008a30 <udp_table_inited>
    800050ca:	c391                	beqz	a5,800050ce <udp_table_init+0xc>
    800050cc:	8082                	ret
{
    800050ce:	1141                	addi	sp,sp,-16
    800050d0:	e406                	sd	ra,8(sp)
    800050d2:	e022                	sd	s0,0(sp)
    800050d4:	0800                	addi	s0,sp,16
    acquire(&netlock);
    800050d6:	00015517          	auipc	a0,0x15
    800050da:	eca50513          	addi	a0,a0,-310 # 80019fa0 <netlock>
    800050de:	538010ef          	jal	80006616 <acquire>
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
    800050e2:	00015717          	auipc	a4,0x15
    800050e6:	05e70713          	addi	a4,a4,94 # 8001a140 <udp_table+0x188>
    800050ea:	00079617          	auipc	a2,0x79
    800050ee:	05660613          	addi	a2,a2,86 # 8007e140 <stack0+0x180>
        udp_table[i].port = -1;
    800050f2:	56fd                	li	a3,-1
    800050f4:	e6d72c23          	sw	a3,-392(a4)
        udp_table[i].head = 0;
    800050f8:	00072023          	sw	zero,0(a4)
        udp_table[i].cnt = 0;
    800050fc:	00072223          	sw	zero,4(a4)
        for (int j = 0; j < MAX_PKTS_PER_PORT; j++) {
    80005100:	e8070793          	addi	a5,a4,-384
            udp_table[i].pkts[j].data = 0;
    80005104:	0007b023          	sd	zero,0(a5)
            udp_table[i].pkts[j].len = 0;
    80005108:	0007a423          	sw	zero,8(a5)
            udp_table[i].pkts[j].srcip = 0;
    8000510c:	0007a623          	sw	zero,12(a5)
            udp_table[i].pkts[j].sport = 0;
    80005110:	00079823          	sh	zero,16(a5)
        for (int j = 0; j < MAX_PKTS_PER_PORT; j++) {
    80005114:	07e1                	addi	a5,a5,24
    80005116:	fee797e3          	bne	a5,a4,80005104 <udp_table_init+0x42>
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
    8000511a:	19070713          	addi	a4,a4,400
    8000511e:	fcc71be3          	bne	a4,a2,800050f4 <udp_table_init+0x32>
    udp_table_inited = 1;
    80005122:	4785                	li	a5,1
    80005124:	00004717          	auipc	a4,0x4
    80005128:	90f72623          	sw	a5,-1780(a4) # 80008a30 <udp_table_inited>
    release(&netlock);
    8000512c:	00015517          	auipc	a0,0x15
    80005130:	e7450513          	addi	a0,a0,-396 # 80019fa0 <netlock>
    80005134:	576010ef          	jal	800066aa <release>
}
    80005138:	60a2                	ld	ra,8(sp)
    8000513a:	6402                	ld	s0,0(sp)
    8000513c:	0141                	addi	sp,sp,16
    8000513e:	8082                	ret

0000000080005140 <netinit>:
{
    80005140:	1141                	addi	sp,sp,-16
    80005142:	e406                	sd	ra,8(sp)
    80005144:	e022                	sd	s0,0(sp)
    80005146:	0800                	addi	s0,sp,16
    initlock(&netlock, "netlock");
    80005148:	00003597          	auipc	a1,0x3
    8000514c:	60058593          	addi	a1,a1,1536 # 80008748 <etext+0x748>
    80005150:	00015517          	auipc	a0,0x15
    80005154:	e5050513          	addi	a0,a0,-432 # 80019fa0 <netlock>
    80005158:	434010ef          	jal	8000658c <initlock>
}
    8000515c:	60a2                	ld	ra,8(sp)
    8000515e:	6402                	ld	s0,0(sp)
    80005160:	0141                	addi	sp,sp,16
    80005162:	8082                	ret

0000000080005164 <sys_bind>:
// prepare to receive UDP packets addressed to the port,
// i.e. allocate any queues &c needed.
//
uint64
sys_bind(void)
{
    80005164:	7139                	addi	sp,sp,-64
    80005166:	fc06                	sd	ra,56(sp)
    80005168:	f822                	sd	s0,48(sp)
    8000516a:	0080                	addi	s0,sp,64
    int port;
    argint(0, &port);
    8000516c:	fcc40593          	addi	a1,s0,-52
    80005170:	4501                	li	a0,0
    80005172:	b17fc0ef          	jal	80001c88 <argint>
    if (port < 0 || port > 0xffff)
    80005176:	fcc42703          	lw	a4,-52(s0)
    8000517a:	67c1                	lui	a5,0x10
        return -1;
    8000517c:	557d                	li	a0,-1
    if (port < 0 || port > 0xffff)
    8000517e:	0cf77763          	bgeu	a4,a5,8000524c <sys_bind+0xe8>
    80005182:	f426                	sd	s1,40(sp)
    80005184:	f04a                	sd	s2,32(sp)

    udp_table_init();
    80005186:	f3dff0ef          	jal	800050c2 <udp_table_init>

    acquire(&netlock);
    8000518a:	00015517          	auipc	a0,0x15
    8000518e:	e1650513          	addi	a0,a0,-490 # 80019fa0 <netlock>
    80005192:	484010ef          	jal	80006616 <acquire>
    if (udp_find_port_idx(port) >= 0) {
    80005196:	fcc42483          	lw	s1,-52(s0)
    8000519a:	8526                	mv	a0,s1
    8000519c:	ef5ff0ef          	jal	80005090 <udp_find_port_idx>
    800051a0:	00015797          	auipc	a5,0x15
    800051a4:	e1878793          	addi	a5,a5,-488 # 80019fb8 <udp_table>
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
    800051a8:	4901                	li	s2,0
        if (udp_table[i].port == -1) {
    800051aa:	56fd                	li	a3,-1
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
    800051ac:	40000613          	li	a2,1024
    if (udp_find_port_idx(port) >= 0) {
    800051b0:	00055c63          	bgez	a0,800051c8 <sys_bind+0x64>
        if (udp_table[i].port == -1) {
    800051b4:	4398                	lw	a4,0(a5)
    800051b6:	02d70363          	beq	a4,a3,800051dc <sys_bind+0x78>
    for (int i = 0; i < MAX_UDP_PORTS; i++) {
    800051ba:	2905                	addiw	s2,s2,1
    800051bc:	19078793          	addi	a5,a5,400
    800051c0:	fec91ae3          	bne	s2,a2,800051b4 <sys_bind+0x50>
    return -1;
    800051c4:	597d                	li	s2,-1
    800051c6:	a88d                	j	80005238 <sys_bind+0xd4>
        release(&netlock);
    800051c8:	00015517          	auipc	a0,0x15
    800051cc:	dd850513          	addi	a0,a0,-552 # 80019fa0 <netlock>
    800051d0:	4da010ef          	jal	800066aa <release>
        return 0;
    800051d4:	4501                	li	a0,0
    800051d6:	74a2                	ld	s1,40(sp)
    800051d8:	7902                	ld	s2,32(sp)
    800051da:	a88d                	j	8000524c <sys_bind+0xe8>
    800051dc:	ec4e                	sd	s3,24(sp)
    800051de:	e852                	sd	s4,16(sp)
            udp_table[i].port = port;
    800051e0:	19000793          	li	a5,400
    800051e4:	02f907b3          	mul	a5,s2,a5
    800051e8:	00015717          	auipc	a4,0x15
    800051ec:	dd070713          	addi	a4,a4,-560 # 80019fb8 <udp_table>
    800051f0:	973e                	add	a4,a4,a5
    800051f2:	c304                	sw	s1,0(a4)
            udp_table[i].head = 0;
    800051f4:	18072423          	sw	zero,392(a4)
            udp_table[i].cnt = 0;
    800051f8:	18072623          	sw	zero,396(a4)
            for (int j = 0; j < MAX_PKTS_PER_PORT; j++) {
    800051fc:	00015497          	auipc	s1,0x15
    80005200:	dc448493          	addi	s1,s1,-572 # 80019fc0 <udp_table+0x8>
    80005204:	94be                	add	s1,s1,a5
    80005206:	00015a17          	auipc	s4,0x15
    8000520a:	f3aa0a13          	addi	s4,s4,-198 # 8001a140 <udp_table+0x188>
    8000520e:	9a3e                	add	s4,s4,a5
    80005210:	a831                	j	8000522c <sys_bind+0xc8>
                    kfree(udp_table[i].pkts[j].data);
    80005212:	e0bfa0ef          	jal	8000001c <kfree>
                    udp_table[i].pkts[j].data = 0;
    80005216:	0004b023          	sd	zero,0(s1)
                udp_table[i].pkts[j].len = 0;
    8000521a:	0009a423          	sw	zero,8(s3) # 3008 <_entry-0x7fffcff8>
                udp_table[i].pkts[j].srcip = 0;
    8000521e:	0009a623          	sw	zero,12(s3)
                udp_table[i].pkts[j].sport = 0;
    80005222:	00099823          	sh	zero,16(s3)
            for (int j = 0; j < MAX_PKTS_PER_PORT; j++) {
    80005226:	04e1                	addi	s1,s1,24
    80005228:	01448663          	beq	s1,s4,80005234 <sys_bind+0xd0>
                if (udp_table[i].pkts[j].data) {
    8000522c:	89a6                	mv	s3,s1
    8000522e:	6088                	ld	a0,0(s1)
    80005230:	f16d                	bnez	a0,80005212 <sys_bind+0xae>
    80005232:	b7e5                	j	8000521a <sys_bind+0xb6>
    80005234:	69e2                	ld	s3,24(sp)
    80005236:	6a42                	ld	s4,16(sp)
    }
    int idx = udp_alloc_port_idx(port);
    release(&netlock);
    80005238:	00015517          	auipc	a0,0x15
    8000523c:	d6850513          	addi	a0,a0,-664 # 80019fa0 <netlock>
    80005240:	46a010ef          	jal	800066aa <release>
    if (idx < 0)
    80005244:	43f95513          	srai	a0,s2,0x3f
    80005248:	74a2                	ld	s1,40(sp)
    8000524a:	7902                	ld	s2,32(sp)
        return -1;
    return 0;
}
    8000524c:	70e2                	ld	ra,56(sp)
    8000524e:	7442                	ld	s0,48(sp)
    80005250:	6121                	addi	sp,sp,64
    80005252:	8082                	ret

0000000080005254 <sys_unbind>:
// release any resources previously created by bind(port);
// from now on UDP packets addressed to port should be dropped.
//
uint64
sys_unbind(void)
{
    80005254:	7139                	addi	sp,sp,-64
    80005256:	fc06                	sd	ra,56(sp)
    80005258:	f822                	sd	s0,48(sp)
    8000525a:	0080                	addi	s0,sp,64
    int port;
    argint(0, &port);
    8000525c:	fcc40593          	addi	a1,s0,-52
    80005260:	4501                	li	a0,0
    80005262:	a27fc0ef          	jal	80001c88 <argint>
    if (port < 0 || port > 0xffff)
    80005266:	fcc42703          	lw	a4,-52(s0)
    8000526a:	67c1                	lui	a5,0x10
        return -1;
    8000526c:	557d                	li	a0,-1
    if (port < 0 || port > 0xffff)
    8000526e:	08f77f63          	bgeu	a4,a5,8000530c <sys_unbind+0xb8>
    80005272:	e852                	sd	s4,16(sp)

    udp_table_init();
    80005274:	e4fff0ef          	jal	800050c2 <udp_table_init>

    acquire(&netlock);
    80005278:	00015517          	auipc	a0,0x15
    8000527c:	d2850513          	addi	a0,a0,-728 # 80019fa0 <netlock>
    80005280:	396010ef          	jal	80006616 <acquire>
    int idx = udp_find_port_idx(port);
    80005284:	fcc42503          	lw	a0,-52(s0)
    80005288:	e09ff0ef          	jal	80005090 <udp_find_port_idx>
    8000528c:	8a2a                	mv	s4,a0
    if (idx >= 0) {
    8000528e:	06054763          	bltz	a0,800052fc <sys_unbind+0xa8>
    80005292:	f426                	sd	s1,40(sp)
    80005294:	f04a                	sd	s2,32(sp)
    80005296:	ec4e                	sd	s3,24(sp)
    80005298:	19000793          	li	a5,400
    8000529c:	02f507b3          	mul	a5,a0,a5
    800052a0:	00015497          	auipc	s1,0x15
    800052a4:	d2048493          	addi	s1,s1,-736 # 80019fc0 <udp_table+0x8>
    800052a8:	94be                	add	s1,s1,a5
    800052aa:	00015997          	auipc	s3,0x15
    800052ae:	e9698993          	addi	s3,s3,-362 # 8001a140 <udp_table+0x188>
    800052b2:	99be                	add	s3,s3,a5
    800052b4:	a811                	j	800052c8 <sys_unbind+0x74>
        for (int i = 0; i < MAX_PKTS_PER_PORT; i++) {
            if (q->pkts[i].data) {
                kfree(q->pkts[i].data);
                q->pkts[i].data = 0;
            }
            q->pkts[i].len = 0;
    800052b6:	00092423          	sw	zero,8(s2)
            q->pkts[i].srcip = 0;
    800052ba:	00092623          	sw	zero,12(s2)
            q->pkts[i].sport = 0;
    800052be:	00091823          	sh	zero,16(s2)
        for (int i = 0; i < MAX_PKTS_PER_PORT; i++) {
    800052c2:	04e1                	addi	s1,s1,24
    800052c4:	01348a63          	beq	s1,s3,800052d8 <sys_unbind+0x84>
            if (q->pkts[i].data) {
    800052c8:	8926                	mv	s2,s1
    800052ca:	6088                	ld	a0,0(s1)
    800052cc:	d56d                	beqz	a0,800052b6 <sys_unbind+0x62>
                kfree(q->pkts[i].data);
    800052ce:	d4ffa0ef          	jal	8000001c <kfree>
                q->pkts[i].data = 0;
    800052d2:	0004b023          	sd	zero,0(s1)
    800052d6:	b7c5                	j	800052b6 <sys_unbind+0x62>
        }
        q->head = 0;
    800052d8:	19000793          	li	a5,400
    800052dc:	02fa0533          	mul	a0,s4,a5
    800052e0:	00015797          	auipc	a5,0x15
    800052e4:	cd878793          	addi	a5,a5,-808 # 80019fb8 <udp_table>
    800052e8:	97aa                	add	a5,a5,a0
    800052ea:	1807a423          	sw	zero,392(a5)
        q->cnt = 0;
    800052ee:	1807a623          	sw	zero,396(a5)
        q->port = -1;
    800052f2:	577d                	li	a4,-1
    800052f4:	c398                	sw	a4,0(a5)
    800052f6:	74a2                	ld	s1,40(sp)
    800052f8:	7902                	ld	s2,32(sp)
    800052fa:	69e2                	ld	s3,24(sp)
    }
    release(&netlock);
    800052fc:	00015517          	auipc	a0,0x15
    80005300:	ca450513          	addi	a0,a0,-860 # 80019fa0 <netlock>
    80005304:	3a6010ef          	jal	800066aa <release>
    return 0;
    80005308:	4501                	li	a0,0
    8000530a:	6a42                	ld	s4,16(sp)
}
    8000530c:	70e2                	ld	ra,56(sp)
    8000530e:	7442                	ld	s0,48(sp)
    80005310:	6121                	addi	sp,sp,64
    80005312:	8082                	ret

0000000080005314 <sys_recv>:
// dport, *src, and *sport are host byte order.
// bind(dport) must previously have been called.
//
uint64
sys_recv(void)
{
    80005314:	7159                	addi	sp,sp,-112
    80005316:	f486                	sd	ra,104(sp)
    80005318:	f0a2                	sd	s0,96(sp)
    8000531a:	1880                	addi	s0,sp,112
    uint64 src_addr;
    uint64 sport_addr;
    uint64 buf_addr;
    int maxlen;

    argint(0, &dport);
    8000531c:	fbc40593          	addi	a1,s0,-68
    80005320:	4501                	li	a0,0
    80005322:	967fc0ef          	jal	80001c88 <argint>
    argaddr(1, &src_addr);
    80005326:	fb040593          	addi	a1,s0,-80
    8000532a:	4505                	li	a0,1
    8000532c:	979fc0ef          	jal	80001ca4 <argaddr>
    argaddr(2, &sport_addr);
    80005330:	fa840593          	addi	a1,s0,-88
    80005334:	4509                	li	a0,2
    80005336:	96ffc0ef          	jal	80001ca4 <argaddr>
    argaddr(3, &buf_addr);
    8000533a:	fa040593          	addi	a1,s0,-96
    8000533e:	450d                	li	a0,3
    80005340:	965fc0ef          	jal	80001ca4 <argaddr>
    argint(4, &maxlen);
    80005344:	f9c40593          	addi	a1,s0,-100
    80005348:	4511                	li	a0,4
    8000534a:	93ffc0ef          	jal	80001c88 <argint>

    if (dport < 0 || dport > 0xffff || maxlen < 0) return -1;
    8000534e:	fbc42703          	lw	a4,-68(s0)
    80005352:	67c1                	lui	a5,0x10
    80005354:	557d                	li	a0,-1
    80005356:	14f77b63          	bgeu	a4,a5,800054ac <sys_recv+0x198>
    8000535a:	f9c42783          	lw	a5,-100(s0)
    8000535e:	1407c763          	bltz	a5,800054ac <sys_recv+0x198>
    80005362:	fc56                	sd	s5,56(sp)

    struct proc *p = myproc();
    80005364:	a57fb0ef          	jal	80000dba <myproc>
    80005368:	8aaa                	mv	s5,a0
    if (!p) return -1;
    8000536a:	18050d63          	beqz	a0,80005504 <sys_recv+0x1f0>
    8000536e:	e8ca                	sd	s2,80(sp)

    udp_table_init();
    80005370:	d53ff0ef          	jal	800050c2 <udp_table_init>

    acquire(&netlock);
    80005374:	00015517          	auipc	a0,0x15
    80005378:	c2c50513          	addi	a0,a0,-980 # 80019fa0 <netlock>
    8000537c:	29a010ef          	jal	80006616 <acquire>
    int idx = udp_find_port_idx(dport);
    80005380:	fbc42503          	lw	a0,-68(s0)
    80005384:	d0dff0ef          	jal	80005090 <udp_find_port_idx>
    80005388:	892a                	mv	s2,a0
    if (idx < 0) {
    8000538a:	12054563          	bltz	a0,800054b4 <sys_recv+0x1a0>
    8000538e:	eca6                	sd	s1,88(sp)
    80005390:	e4ce                	sd	s3,72(sp)
    80005392:	e0d2                	sd	s4,64(sp)
        release(&netlock);
        return -1;
    }
    struct udp_q *q = &udp_table[idx];

    while (q->cnt == 0) {
    80005394:	19000713          	li	a4,400
    80005398:	02e50733          	mul	a4,a0,a4
    8000539c:	00015797          	auipc	a5,0x15
    800053a0:	c1c78793          	addi	a5,a5,-996 # 80019fb8 <udp_table>
    800053a4:	97ba                	add	a5,a5,a4
    800053a6:	18c7a783          	lw	a5,396(a5)
    800053aa:	e39d                	bnez	a5,800053d0 <sys_recv+0xbc>
    struct udp_q *q = &udp_table[idx];
    800053ac:	00015797          	auipc	a5,0x15
    800053b0:	c0c78793          	addi	a5,a5,-1012 # 80019fb8 <udp_table>
    800053b4:	00f704b3          	add	s1,a4,a5
        sleep((void *)q, &netlock);
    800053b8:	00015a17          	auipc	s4,0x15
    800053bc:	be8a0a13          	addi	s4,s4,-1048 # 80019fa0 <netlock>
    while (q->cnt == 0) {
    800053c0:	89a6                	mv	s3,s1
        sleep((void *)q, &netlock);
    800053c2:	85d2                	mv	a1,s4
    800053c4:	8526                	mv	a0,s1
    800053c6:	fc7fb0ef          	jal	8000138c <sleep>
    while (q->cnt == 0) {
    800053ca:	18c9a783          	lw	a5,396(s3)
    800053ce:	dbf5                	beqz	a5,800053c2 <sys_recv+0xae>
    }

    int i = q->head;
    800053d0:	00015697          	auipc	a3,0x15
    800053d4:	be868693          	addi	a3,a3,-1048 # 80019fb8 <udp_table>
    800053d8:	19000713          	li	a4,400
    800053dc:	02e90933          	mul	s2,s2,a4
    800053e0:	012685b3          	add	a1,a3,s2
    800053e4:	1885a703          	lw	a4,392(a1)
    struct udp_pkt pkt = q->pkts[i];
    800053e8:	00171613          	slli	a2,a4,0x1
    800053ec:	963a                	add	a2,a2,a4
    800053ee:	060e                	slli	a2,a2,0x3
    800053f0:	964a                	add	a2,a2,s2
    800053f2:	96b2                	add	a3,a3,a2
    800053f4:	0086b903          	ld	s2,8(a3)
    800053f8:	4a84                	lw	s1,16(a3)
    800053fa:	0146aa03          	lw	s4,20(a3)
    800053fe:	0186d983          	lhu	s3,24(a3)

    q->pkts[i].data = 0;
    80005402:	0006b423          	sd	zero,8(a3)
    q->pkts[i].len = 0;
    80005406:	0006a823          	sw	zero,16(a3)
    q->pkts[i].srcip = 0;
    8000540a:	0006aa23          	sw	zero,20(a3)
    q->pkts[i].sport = 0;
    8000540e:	00069c23          	sh	zero,24(a3)

    q->head = (q->head + 1) % MAX_PKTS_PER_PORT;
    80005412:	2705                	addiw	a4,a4,1
    80005414:	41f7569b          	sraiw	a3,a4,0x1f
    80005418:	01c6d69b          	srliw	a3,a3,0x1c
    8000541c:	9f35                	addw	a4,a4,a3
    8000541e:	8b3d                	andi	a4,a4,15
    80005420:	9f15                	subw	a4,a4,a3
    80005422:	18e5a423          	sw	a4,392(a1)
    q->cnt--;
    80005426:	37fd                	addiw	a5,a5,-1
    80005428:	18f5a623          	sw	a5,396(a1)
    release(&netlock);
    8000542c:	00015517          	auipc	a0,0x15
    80005430:	b7450513          	addi	a0,a0,-1164 # 80019fa0 <netlock>
    80005434:	276010ef          	jal	800066aa <release>

    if (!pkt.data)
    80005438:	0c090963          	beqz	s2,8000550a <sys_recv+0x1f6>
        return -1;

    int tocopy = pkt.len;
    if (tocopy > maxlen) tocopy = maxlen;
    8000543c:	f9c42703          	lw	a4,-100(s0)
    80005440:	87ba                	mv	a5,a4
    80005442:	2701                	sext.w	a4,a4
    80005444:	00e4d363          	bge	s1,a4,8000544a <sys_recv+0x136>
    80005448:	87a6                	mv	a5,s1
    8000544a:	0007849b          	sext.w	s1,a5

    if (tocopy > 0) {
    8000544e:	00905c63          	blez	s1,80005466 <sys_recv+0x152>
        if (copyout(p->pagetable, buf_addr, pkt.data, tocopy) < 0) {
    80005452:	86a6                	mv	a3,s1
    80005454:	864a                	mv	a2,s2
    80005456:	fa043583          	ld	a1,-96(s0)
    8000545a:	050ab503          	ld	a0,80(s5)
    8000545e:	de0fb0ef          	jal	80000a3e <copyout>
    80005462:	06054363          	bltz	a0,800054c8 <sys_recv+0x1b4>
            kfree(pkt.data);
            return -1;
        }
    }

    uint32 srcip = pkt.srcip;
    80005466:	f9442c23          	sw	s4,-104(s0)
    uint16 sport = pkt.sport;
    8000546a:	f9341b23          	sh	s3,-106(s0)

    if (copyout(p->pagetable, src_addr, (char *)&srcip, sizeof(srcip)) < 0) {
    8000546e:	4691                	li	a3,4
    80005470:	f9840613          	addi	a2,s0,-104
    80005474:	fb043583          	ld	a1,-80(s0)
    80005478:	050ab503          	ld	a0,80(s5)
    8000547c:	dc2fb0ef          	jal	80000a3e <copyout>
    80005480:	04054e63          	bltz	a0,800054dc <sys_recv+0x1c8>
        kfree(pkt.data);
        return -1;
    }
    if (copyout(p->pagetable, sport_addr, (char *)&sport, sizeof(sport)) < 0) {
    80005484:	4689                	li	a3,2
    80005486:	f9640613          	addi	a2,s0,-106
    8000548a:	fa843583          	ld	a1,-88(s0)
    8000548e:	050ab503          	ld	a0,80(s5)
    80005492:	dacfb0ef          	jal	80000a3e <copyout>
    80005496:	04054d63          	bltz	a0,800054f0 <sys_recv+0x1dc>
        kfree(pkt.data);
        return -1;
    }

    kfree(pkt.data);
    8000549a:	854a                	mv	a0,s2
    8000549c:	b81fa0ef          	jal	8000001c <kfree>
    return tocopy;
    800054a0:	8526                	mv	a0,s1
    800054a2:	64e6                	ld	s1,88(sp)
    800054a4:	6946                	ld	s2,80(sp)
    800054a6:	69a6                	ld	s3,72(sp)
    800054a8:	6a06                	ld	s4,64(sp)
    800054aa:	7ae2                	ld	s5,56(sp)
}
    800054ac:	70a6                	ld	ra,104(sp)
    800054ae:	7406                	ld	s0,96(sp)
    800054b0:	6165                	addi	sp,sp,112
    800054b2:	8082                	ret
        release(&netlock);
    800054b4:	00015517          	auipc	a0,0x15
    800054b8:	aec50513          	addi	a0,a0,-1300 # 80019fa0 <netlock>
    800054bc:	1ee010ef          	jal	800066aa <release>
        return -1;
    800054c0:	557d                	li	a0,-1
    800054c2:	6946                	ld	s2,80(sp)
    800054c4:	7ae2                	ld	s5,56(sp)
    800054c6:	b7dd                	j	800054ac <sys_recv+0x198>
            kfree(pkt.data);
    800054c8:	854a                	mv	a0,s2
    800054ca:	b53fa0ef          	jal	8000001c <kfree>
            return -1;
    800054ce:	557d                	li	a0,-1
    800054d0:	64e6                	ld	s1,88(sp)
    800054d2:	6946                	ld	s2,80(sp)
    800054d4:	69a6                	ld	s3,72(sp)
    800054d6:	6a06                	ld	s4,64(sp)
    800054d8:	7ae2                	ld	s5,56(sp)
    800054da:	bfc9                	j	800054ac <sys_recv+0x198>
        kfree(pkt.data);
    800054dc:	854a                	mv	a0,s2
    800054de:	b3ffa0ef          	jal	8000001c <kfree>
        return -1;
    800054e2:	557d                	li	a0,-1
    800054e4:	64e6                	ld	s1,88(sp)
    800054e6:	6946                	ld	s2,80(sp)
    800054e8:	69a6                	ld	s3,72(sp)
    800054ea:	6a06                	ld	s4,64(sp)
    800054ec:	7ae2                	ld	s5,56(sp)
    800054ee:	bf7d                	j	800054ac <sys_recv+0x198>
        kfree(pkt.data);
    800054f0:	854a                	mv	a0,s2
    800054f2:	b2bfa0ef          	jal	8000001c <kfree>
        return -1;
    800054f6:	557d                	li	a0,-1
    800054f8:	64e6                	ld	s1,88(sp)
    800054fa:	6946                	ld	s2,80(sp)
    800054fc:	69a6                	ld	s3,72(sp)
    800054fe:	6a06                	ld	s4,64(sp)
    80005500:	7ae2                	ld	s5,56(sp)
    80005502:	b76d                	j	800054ac <sys_recv+0x198>
    if (!p) return -1;
    80005504:	557d                	li	a0,-1
    80005506:	7ae2                	ld	s5,56(sp)
    80005508:	b755                	j	800054ac <sys_recv+0x198>
        return -1;
    8000550a:	557d                	li	a0,-1
    8000550c:	64e6                	ld	s1,88(sp)
    8000550e:	6946                	ld	s2,80(sp)
    80005510:	69a6                	ld	s3,72(sp)
    80005512:	6a06                	ld	s4,64(sp)
    80005514:	7ae2                	ld	s5,56(sp)
    80005516:	bf59                	j	800054ac <sys_recv+0x198>

0000000080005518 <sys_send>:
//
// send(int sport, int dst, int dport, char *buf, int len)
//
uint64
sys_send(void)
{
    80005518:	715d                	addi	sp,sp,-80
    8000551a:	e486                	sd	ra,72(sp)
    8000551c:	e0a2                	sd	s0,64(sp)
    8000551e:	f84a                	sd	s2,48(sp)
    80005520:	f44e                	sd	s3,40(sp)
    80005522:	0880                	addi	s0,sp,80
    struct proc *p = myproc();
    80005524:	897fb0ef          	jal	80000dba <myproc>
    80005528:	89aa                	mv	s3,a0
    int dst;
    int dport;
    uint64 bufaddr;
    int len;

    argint(0, &sport);
    8000552a:	fcc40593          	addi	a1,s0,-52
    8000552e:	4501                	li	a0,0
    80005530:	f58fc0ef          	jal	80001c88 <argint>
    argint(1, &dst);
    80005534:	fc840593          	addi	a1,s0,-56
    80005538:	4505                	li	a0,1
    8000553a:	f4efc0ef          	jal	80001c88 <argint>
    argint(2, &dport);
    8000553e:	fc440593          	addi	a1,s0,-60
    80005542:	4509                	li	a0,2
    80005544:	f44fc0ef          	jal	80001c88 <argint>
    argaddr(3, &bufaddr);
    80005548:	fb840593          	addi	a1,s0,-72
    8000554c:	450d                	li	a0,3
    8000554e:	f56fc0ef          	jal	80001ca4 <argaddr>
    argint(4, &len);
    80005552:	fb440593          	addi	a1,s0,-76
    80005556:	4511                	li	a0,4
    80005558:	f30fc0ef          	jal	80001c88 <argint>

    int total = len + sizeof(struct eth) + sizeof(struct ip) + sizeof(struct udp);
    8000555c:	fb442903          	lw	s2,-76(s0)
    80005560:	02a9091b          	addiw	s2,s2,42
    if(total > PGSIZE)
    80005564:	6785                	lui	a5,0x1
        return -1;
    80005566:	557d                	li	a0,-1
    if(total > PGSIZE)
    80005568:	1527c963          	blt	a5,s2,800056ba <sys_send+0x1a2>
    8000556c:	fc26                	sd	s1,56(sp)

    char *buf = kalloc();
    8000556e:	b97fa0ef          	jal	80000104 <kalloc>
    80005572:	84aa                	mv	s1,a0
    if(buf == 0){
    80005574:	14050963          	beqz	a0,800056c6 <sys_send+0x1ae>
        printf("sys_send: kalloc failed\n");
        return -1;
    }
    memset(buf, 0, PGSIZE);
    80005578:	6605                	lui	a2,0x1
    8000557a:	4581                	li	a1,0
    8000557c:	be3fa0ef          	jal	8000015e <memset>

    struct eth *eth = (struct eth *) buf;
    memmove(eth->dhost, host_mac, ETHADDR_LEN);
    80005580:	4619                	li	a2,6
    80005582:	00003597          	auipc	a1,0x3
    80005586:	42658593          	addi	a1,a1,1062 # 800089a8 <host_mac>
    8000558a:	8526                	mv	a0,s1
    8000558c:	c33fa0ef          	jal	800001be <memmove>
    memmove(eth->shost, local_mac, ETHADDR_LEN);
    80005590:	4619                	li	a2,6
    80005592:	00003597          	auipc	a1,0x3
    80005596:	41e58593          	addi	a1,a1,1054 # 800089b0 <local_mac>
    8000559a:	00c48533          	add	a0,s1,a2
    8000559e:	c21fa0ef          	jal	800001be <memmove>
    eth->type = htons(ETHTYPE_IP);
    800055a2:	47a1                	li	a5,8
    800055a4:	00f48623          	sb	a5,12(s1)
    800055a8:	000486a3          	sb	zero,13(s1)

    struct ip *ip = (struct ip *)(eth + 1);
    800055ac:	00e48713          	addi	a4,s1,14
    ip->ip_vhl = 0x45; // version 4, header length 4*5
    800055b0:	04500793          	li	a5,69
    800055b4:	00f48723          	sb	a5,14(s1)
    ip->ip_tos = 0;
    800055b8:	000487a3          	sb	zero,15(s1)
    ip->ip_len = htons(sizeof(struct ip) + sizeof(struct udp) + len);
    800055bc:	fb442683          	lw	a3,-76(s0)
    800055c0:	03069593          	slli	a1,a3,0x30
    800055c4:	91c1                	srli	a1,a1,0x30
    800055c6:	01c5879b          	addiw	a5,a1,28
// endianness support
//

static inline uint16 bswaps(uint16 val)
{
  return (((val & 0x00ffU) << 8) |
    800055ca:	03079513          	slli	a0,a5,0x30
    800055ce:	03855613          	srli	a2,a0,0x38
    800055d2:	0087979b          	slliw	a5,a5,0x8
    800055d6:	9fb1                	addw	a5,a5,a2
    800055d8:	00f49823          	sh	a5,16(s1)
    ip->ip_id = 0;
    800055dc:	00049923          	sh	zero,18(s1)
    ip->ip_off = 0;
    800055e0:	00049a23          	sh	zero,20(s1)
    ip->ip_ttl = 100;
    800055e4:	06400793          	li	a5,100
    800055e8:	00f48b23          	sb	a5,22(s1)
    ip->ip_p = IPPROTO_UDP;
    800055ec:	47c5                	li	a5,17
    800055ee:	00f48ba3          	sb	a5,23(s1)
    ip->ip_src = htonl(local_ip);
    800055f2:	0f0207b7          	lui	a5,0xf020
    800055f6:	07a9                	addi	a5,a5,10 # f02000a <_entry-0x70fdfff6>
    800055f8:	00f4ad23          	sw	a5,26(s1)
    ip->ip_dst = htonl(dst);
    800055fc:	fc842783          	lw	a5,-56(s0)
          ((val & 0xff00U) >> 8));
}

static inline uint32 bswapl(uint32 val)
{
  return (((val & 0x000000ffUL) << 24) |
    80005600:	0187961b          	slliw	a2,a5,0x18
          ((val & 0x0000ff00UL) << 8) |
          ((val & 0x00ff0000UL) >> 8) |
          ((val & 0xff000000UL) >> 24));
    80005604:	0187d51b          	srliw	a0,a5,0x18
          ((val & 0x00ff0000UL) >> 8) |
    80005608:	8e49                	or	a2,a2,a0
          ((val & 0x0000ff00UL) << 8) |
    8000560a:	0087951b          	slliw	a0,a5,0x8
    8000560e:	00ff0837          	lui	a6,0xff0
    80005612:	01057533          	and	a0,a0,a6
          ((val & 0x00ff0000UL) >> 8) |
    80005616:	8e49                	or	a2,a2,a0
    80005618:	0087d79b          	srliw	a5,a5,0x8
    8000561c:	6541                	lui	a0,0x10
    8000561e:	f0050513          	addi	a0,a0,-256 # ff00 <_entry-0x7fff0100>
    80005622:	8fe9                	and	a5,a5,a0
    80005624:	8fd1                	or	a5,a5,a2
    80005626:	00f4af23          	sw	a5,30(s1)
    while (nleft > 1)  {
    8000562a:	02248813          	addi	a6,s1,34
    unsigned int sum = 0;
    8000562e:	4601                	li	a2,0
        sum += *w++;
    80005630:	0709                	addi	a4,a4,2
    80005632:	ffe75783          	lhu	a5,-2(a4)
    80005636:	9fb1                	addw	a5,a5,a2
    80005638:	863e                	mv	a2,a5
    while (nleft > 1)  {
    8000563a:	ff071be3          	bne	a4,a6,80005630 <sys_send+0x118>
    sum = (sum & 0xffff) + (sum >> 16);
    8000563e:	03079713          	slli	a4,a5,0x30
    80005642:	9341                	srli	a4,a4,0x30
    80005644:	0107d79b          	srliw	a5,a5,0x10
    80005648:	9fb9                	addw	a5,a5,a4
    sum += (sum >> 16);
    8000564a:	0107d71b          	srliw	a4,a5,0x10
    8000564e:	9fb9                	addw	a5,a5,a4
    answer = ~sum; /* truncate to 16 bits */
    80005650:	fff7c793          	not	a5,a5
    ip->ip_sum = in_cksum((unsigned char *)ip, sizeof(*ip));
    80005654:	00f49c23          	sh	a5,24(s1)

    struct udp *udp = (struct udp *)(ip + 1);
    udp->sport = htons(sport);
    80005658:	fcc42783          	lw	a5,-52(s0)
  return (((val & 0x00ffU) << 8) |
    8000565c:	03079613          	slli	a2,a5,0x30
    80005660:	03865713          	srli	a4,a2,0x38
    80005664:	0087979b          	slliw	a5,a5,0x8
    80005668:	9fb9                	addw	a5,a5,a4
    8000566a:	02f49123          	sh	a5,34(s1)
    udp->dport = htons(dport);
    8000566e:	fc442783          	lw	a5,-60(s0)
    80005672:	03079613          	slli	a2,a5,0x30
    80005676:	03865713          	srli	a4,a2,0x38
    8000567a:	0087979b          	slliw	a5,a5,0x8
    8000567e:	9fb9                	addw	a5,a5,a4
    80005680:	02f49223          	sh	a5,36(s1)
    udp->ulen = htons(len + sizeof(struct udp));
    80005684:	0085879b          	addiw	a5,a1,8
    80005688:	03079613          	slli	a2,a5,0x30
    8000568c:	03865713          	srli	a4,a2,0x38
    80005690:	0087979b          	slliw	a5,a5,0x8
    80005694:	9fb9                	addw	a5,a5,a4
    80005696:	02f49323          	sh	a5,38(s1)

    char *payload = (char *)(udp + 1);
    if(copyin(p->pagetable, payload, bufaddr, len) < 0){
    8000569a:	fb843603          	ld	a2,-72(s0)
    8000569e:	02a48593          	addi	a1,s1,42
    800056a2:	0509b503          	ld	a0,80(s3)
    800056a6:	c48fb0ef          	jal	80000aee <copyin>
    800056aa:	02054763          	bltz	a0,800056d8 <sys_send+0x1c0>
        kfree(buf);
        printf("send: copyin failed\n");
        return -1;
    }

    e1000_transmit(buf, total);
    800056ae:	85ca                	mv	a1,s2
    800056b0:	8526                	mv	a0,s1
    800056b2:	805ff0ef          	jal	80004eb6 <e1000_transmit>

    return 0;
    800056b6:	4501                	li	a0,0
    800056b8:	74e2                	ld	s1,56(sp)
}
    800056ba:	60a6                	ld	ra,72(sp)
    800056bc:	6406                	ld	s0,64(sp)
    800056be:	7942                	ld	s2,48(sp)
    800056c0:	79a2                	ld	s3,40(sp)
    800056c2:	6161                	addi	sp,sp,80
    800056c4:	8082                	ret
        printf("sys_send: kalloc failed\n");
    800056c6:	00003517          	auipc	a0,0x3
    800056ca:	08a50513          	addi	a0,a0,138 # 80008750 <etext+0x750>
    800056ce:	0fb000ef          	jal	80005fc8 <printf>
        return -1;
    800056d2:	557d                	li	a0,-1
    800056d4:	74e2                	ld	s1,56(sp)
    800056d6:	b7d5                	j	800056ba <sys_send+0x1a2>
        kfree(buf);
    800056d8:	8526                	mv	a0,s1
    800056da:	943fa0ef          	jal	8000001c <kfree>
        printf("send: copyin failed\n");
    800056de:	00003517          	auipc	a0,0x3
    800056e2:	09250513          	addi	a0,a0,146 # 80008770 <etext+0x770>
    800056e6:	0e3000ef          	jal	80005fc8 <printf>
        return -1;
    800056ea:	557d                	li	a0,-1
    800056ec:	74e2                	ld	s1,56(sp)
    800056ee:	b7f1                	j	800056ba <sys_send+0x1a2>

00000000800056f0 <ip_rx>:

void
ip_rx(char *buf, int len)
{
    800056f0:	7139                	addi	sp,sp,-64
    800056f2:	fc06                	sd	ra,56(sp)
    800056f4:	f822                	sd	s0,48(sp)
    800056f6:	f426                	sd	s1,40(sp)
    800056f8:	f04a                	sd	s2,32(sp)
    800056fa:	0080                	addi	s0,sp,64
    800056fc:	84aa                	mv	s1,a0
    800056fe:	892e                	mv	s2,a1
    // don't delete this printf; make grade depends on it.
    static int seen_ip = 0;
    if(seen_ip == 0)
    80005700:	00003797          	auipc	a5,0x3
    80005704:	32c7a783          	lw	a5,812(a5) # 80008a2c <seen_ip.1>
    80005708:	16078b63          	beqz	a5,8000587e <ip_rx+0x18e>
        printf("ip_rx: received an IP packet\n");
    seen_ip = 1;
    8000570c:	4785                	li	a5,1
    8000570e:	00003717          	auipc	a4,0x3
    80005712:	30f72f23          	sw	a5,798(a4) # 80008a2c <seen_ip.1>
    // parse ethernet + ip + udp, and if UDP and destination port bound,
    // queue UDP payload for recv() to pick up.
    //

    // minimal sanity checks
    if (len < sizeof(struct eth) + sizeof(struct ip) + sizeof(struct udp)) {
    80005716:	02900793          	li	a5,41
    8000571a:	1727f963          	bgeu	a5,s2,8000588c <ip_rx+0x19c>
        kfree(buf);
        return;
    }

    struct eth *eth = (struct eth *) buf;
    if (ntohs(eth->type) != ETHTYPE_IP) {
    8000571e:	00c4c703          	lbu	a4,12(s1)
    80005722:	00d4c783          	lbu	a5,13(s1)
    80005726:	07a2                	slli	a5,a5,0x8
    80005728:	8fd9                	or	a5,a5,a4
    8000572a:	4721                	li	a4,8
    8000572c:	16e79463          	bne	a5,a4,80005894 <ip_rx+0x1a4>
        return;
    }

    struct ip *ip = (struct ip *)(eth + 1);
    // only support IPv4 without options (ip header assumed 20 bytes as in lab)
    if (ip->ip_p != IPPROTO_UDP) {
    80005730:	0174c703          	lbu	a4,23(s1)
    80005734:	47c5                	li	a5,17
    80005736:	16f71863          	bne	a4,a5,800058a6 <ip_rx+0x1b6>
    8000573a:	0264d783          	lhu	a5,38(s1)
    8000573e:	0087d613          	srli	a2,a5,0x8
    80005742:	0087979b          	slliw	a5,a5,0x8
    80005746:	9e3d                	addw	a2,a2,a5
    80005748:	1642                	slli	a2,a2,0x30
    8000574a:	9241                	srli	a2,a2,0x30

    int dport = ntohs(udp->dport);
    int sport = ntohs(udp->sport);
    int ulen = ntohs(udp->ulen);

    if (ulen < (int)sizeof(struct udp)) {
    8000574c:	0006071b          	sext.w	a4,a2
    80005750:	479d                	li	a5,7
    80005752:	14e7fe63          	bgeu	a5,a4,800058ae <ip_rx+0x1be>
    80005756:	ec4e                	sd	s3,24(sp)
        // malformed
        kfree(buf);
        return;
    }

    int payload_len = ulen - sizeof(struct udp);
    80005758:	ff86071b          	addiw	a4,a2,-8 # ff8 <_entry-0x7ffff008>
    8000575c:	89ba                	mv	s3,a4

    // Check that packet buffer actually contains payload_len bytes after headers.
    int after_hdrs = len - (sizeof(struct eth) + sizeof(struct ip) + sizeof(struct udp));
    if (after_hdrs < payload_len) {
    8000575e:	fd69079b          	addiw	a5,s2,-42
    80005762:	14e7ca63          	blt	a5,a4,800058b6 <ip_rx+0x1c6>
    80005766:	e852                	sd	s4,16(sp)
    80005768:	e456                	sd	s5,8(sp)
    8000576a:	0244d703          	lhu	a4,36(s1)
    8000576e:	00875793          	srli	a5,a4,0x8
    80005772:	0087171b          	slliw	a4,a4,0x8
    80005776:	9fb9                	addw	a5,a5,a4
    int dport = ntohs(udp->dport);
    80005778:	03079913          	slli	s2,a5,0x30
    8000577c:	03095913          	srli	s2,s2,0x30
    int sport = ntohs(udp->sport);
    80005780:	0224d783          	lhu	a5,34(s1)
    80005784:	8abe                	mv	s5,a5
    }

    // where payload begins
    char *payload = (char *)(udp + 1);

    udp_table_init();
    80005786:	93dff0ef          	jal	800050c2 <udp_table_init>
    acquire(&netlock);
    8000578a:	00015517          	auipc	a0,0x15
    8000578e:	81650513          	addi	a0,a0,-2026 # 80019fa0 <netlock>
    80005792:	685000ef          	jal	80006616 <acquire>

    int idx = udp_find_port_idx(dport);
    80005796:	854a                	mv	a0,s2
    80005798:	8f9ff0ef          	jal	80005090 <udp_find_port_idx>
    8000579c:	8a2a                	mv	s4,a0
    if (idx < 0) {
    8000579e:	12054163          	bltz	a0,800058c0 <ip_rx+0x1d0>
        kfree(buf);
        return;
    }

    struct udp_q *q = &udp_table[idx];
    if (q->cnt >= MAX_PKTS_PER_PORT) {
    800057a2:	19000713          	li	a4,400
    800057a6:	02e50733          	mul	a4,a0,a4
    800057aa:	00015797          	auipc	a5,0x15
    800057ae:	80e78793          	addi	a5,a5,-2034 # 80019fb8 <udp_table>
    800057b2:	97ba                	add	a5,a5,a4
    800057b4:	18c7a703          	lw	a4,396(a5)
    800057b8:	47bd                	li	a5,15
    800057ba:	12e7c063          	blt	a5,a4,800058da <ip_rx+0x1ea>
        kfree(buf);
        return;
    }

    // allocate kernel buffer for payload
    char *kbuf = kalloc();
    800057be:	947fa0ef          	jal	80000104 <kalloc>
    if (!kbuf) {
    800057c2:	12050963          	beqz	a0,800058f4 <ip_rx+0x204>
        kfree(buf);
        return;
    }

    // copy only payload_len bytes
    memmove(kbuf, payload, payload_len);
    800057c6:	864e                	mv	a2,s3
    800057c8:	02a48593          	addi	a1,s1,42
    800057cc:	892a                	mv	s2,a0
    800057ce:	9f1fa0ef          	jal	800001be <memmove>

    int tail = (q->head + q->cnt) % MAX_PKTS_PER_PORT;
    800057d2:	00014897          	auipc	a7,0x14
    800057d6:	7e688893          	addi	a7,a7,2022 # 80019fb8 <udp_table>
    800057da:	19000793          	li	a5,400
    800057de:	02fa0633          	mul	a2,s4,a5
    800057e2:	00c88533          	add	a0,a7,a2
    800057e6:	18c52303          	lw	t1,396(a0)
    800057ea:	18852783          	lw	a5,392(a0)
    800057ee:	006787bb          	addw	a5,a5,t1
    800057f2:	41f7d71b          	sraiw	a4,a5,0x1f
    800057f6:	01c7571b          	srliw	a4,a4,0x1c
    800057fa:	9fb9                	addw	a5,a5,a4
    800057fc:	8bbd                	andi	a5,a5,15
    800057fe:	9f99                	subw	a5,a5,a4
    q->pkts[tail].data = kbuf;
    80005800:	00179593          	slli	a1,a5,0x1
    80005804:	00f58733          	add	a4,a1,a5
    80005808:	070e                	slli	a4,a4,0x3
    8000580a:	9732                	add	a4,a4,a2
    8000580c:	9746                	add	a4,a4,a7
    8000580e:	01273423          	sd	s2,8(a4)
    q->pkts[tail].len = payload_len;
    80005812:	01372823          	sw	s3,16(a4)
    q->pkts[tail].srcip = ntohl(ip->ip_src); // store in host byte order
    80005816:	01a4a683          	lw	a3,26(s1)
  return (((val & 0x000000ffUL) << 24) |
    8000581a:	0186981b          	slliw	a6,a3,0x18
          ((val & 0xff000000UL) >> 24));
    8000581e:	0186de1b          	srliw	t3,a3,0x18
          ((val & 0x00ff0000UL) >> 8) |
    80005822:	01c86833          	or	a6,a6,t3
          ((val & 0x0000ff00UL) << 8) |
    80005826:	00869e1b          	slliw	t3,a3,0x8
    8000582a:	00ff0eb7          	lui	t4,0xff0
    8000582e:	01de7e33          	and	t3,t3,t4
          ((val & 0x00ff0000UL) >> 8) |
    80005832:	01c86833          	or	a6,a6,t3
    80005836:	0086d69b          	srliw	a3,a3,0x8
    8000583a:	6e41                	lui	t3,0x10
    8000583c:	f00e0e13          	addi	t3,t3,-256 # ff00 <_entry-0x7fff0100>
    80005840:	01c6f6b3          	and	a3,a3,t3
    80005844:	00d866b3          	or	a3,a6,a3
    80005848:	cb54                	sw	a3,20(a4)
    q->pkts[tail].sport = sport;             // already host order
    8000584a:	88ba                	mv	a7,a4
  return (((val & 0x00ffU) << 8) |
    8000584c:	008ad71b          	srliw	a4,s5,0x8
    80005850:	008a979b          	slliw	a5,s5,0x8
    80005854:	9fb9                	addw	a5,a5,a4
    80005856:	00f89c23          	sh	a5,24(a7)
    q->cnt++;
    8000585a:	2305                	addiw	t1,t1,1
    8000585c:	18652623          	sw	t1,396(a0)

    // wakeup any waiting receiver for this port; channel = q address
    wakeup((void *)q);
    80005860:	b79fb0ef          	jal	800013d8 <wakeup>

    release(&netlock);
    80005864:	00014517          	auipc	a0,0x14
    80005868:	73c50513          	addi	a0,a0,1852 # 80019fa0 <netlock>
    8000586c:	63f000ef          	jal	800066aa <release>

    // free the original frame buffer
    kfree(buf);
    80005870:	8526                	mv	a0,s1
    80005872:	faafa0ef          	jal	8000001c <kfree>
    80005876:	69e2                	ld	s3,24(sp)
    80005878:	6a42                	ld	s4,16(sp)
    8000587a:	6aa2                	ld	s5,8(sp)
    8000587c:	a839                	j	8000589a <ip_rx+0x1aa>
        printf("ip_rx: received an IP packet\n");
    8000587e:	00003517          	auipc	a0,0x3
    80005882:	f0a50513          	addi	a0,a0,-246 # 80008788 <etext+0x788>
    80005886:	742000ef          	jal	80005fc8 <printf>
    8000588a:	b549                	j	8000570c <ip_rx+0x1c>
        kfree(buf);
    8000588c:	8526                	mv	a0,s1
    8000588e:	f8efa0ef          	jal	8000001c <kfree>
        return;
    80005892:	a021                	j	8000589a <ip_rx+0x1aa>
        kfree(buf);
    80005894:	8526                	mv	a0,s1
    80005896:	f86fa0ef          	jal	8000001c <kfree>
}
    8000589a:	70e2                	ld	ra,56(sp)
    8000589c:	7442                	ld	s0,48(sp)
    8000589e:	74a2                	ld	s1,40(sp)
    800058a0:	7902                	ld	s2,32(sp)
    800058a2:	6121                	addi	sp,sp,64
    800058a4:	8082                	ret
        kfree(buf);
    800058a6:	8526                	mv	a0,s1
    800058a8:	f74fa0ef          	jal	8000001c <kfree>
        return;
    800058ac:	b7fd                	j	8000589a <ip_rx+0x1aa>
        kfree(buf);
    800058ae:	8526                	mv	a0,s1
    800058b0:	f6cfa0ef          	jal	8000001c <kfree>
        return;
    800058b4:	b7dd                	j	8000589a <ip_rx+0x1aa>
        kfree(buf);
    800058b6:	8526                	mv	a0,s1
    800058b8:	f64fa0ef          	jal	8000001c <kfree>
        return;
    800058bc:	69e2                	ld	s3,24(sp)
    800058be:	bff1                	j	8000589a <ip_rx+0x1aa>
        release(&netlock);
    800058c0:	00014517          	auipc	a0,0x14
    800058c4:	6e050513          	addi	a0,a0,1760 # 80019fa0 <netlock>
    800058c8:	5e3000ef          	jal	800066aa <release>
        kfree(buf);
    800058cc:	8526                	mv	a0,s1
    800058ce:	f4efa0ef          	jal	8000001c <kfree>
        return;
    800058d2:	69e2                	ld	s3,24(sp)
    800058d4:	6a42                	ld	s4,16(sp)
    800058d6:	6aa2                	ld	s5,8(sp)
    800058d8:	b7c9                	j	8000589a <ip_rx+0x1aa>
        release(&netlock);
    800058da:	00014517          	auipc	a0,0x14
    800058de:	6c650513          	addi	a0,a0,1734 # 80019fa0 <netlock>
    800058e2:	5c9000ef          	jal	800066aa <release>
        kfree(buf);
    800058e6:	8526                	mv	a0,s1
    800058e8:	f34fa0ef          	jal	8000001c <kfree>
        return;
    800058ec:	69e2                	ld	s3,24(sp)
    800058ee:	6a42                	ld	s4,16(sp)
    800058f0:	6aa2                	ld	s5,8(sp)
    800058f2:	b765                	j	8000589a <ip_rx+0x1aa>
        release(&netlock);
    800058f4:	00014517          	auipc	a0,0x14
    800058f8:	6ac50513          	addi	a0,a0,1708 # 80019fa0 <netlock>
    800058fc:	5af000ef          	jal	800066aa <release>
        kfree(buf);
    80005900:	8526                	mv	a0,s1
    80005902:	f1afa0ef          	jal	8000001c <kfree>
        return;
    80005906:	69e2                	ld	s3,24(sp)
    80005908:	6a42                	ld	s4,16(sp)
    8000590a:	6aa2                	ld	s5,8(sp)
    8000590c:	b779                	j	8000589a <ip_rx+0x1aa>

000000008000590e <arp_rx>:
// qemu to send IP packets to xv6; the real ARP
// protocol is more complex.
//
void
arp_rx(char *inbuf)
{
    8000590e:	7179                	addi	sp,sp,-48
    80005910:	f406                	sd	ra,40(sp)
    80005912:	f022                	sd	s0,32(sp)
    80005914:	e84a                	sd	s2,16(sp)
    80005916:	1800                	addi	s0,sp,48
    80005918:	892a                	mv	s2,a0
    static int seen_arp = 0;

    if(seen_arp){
    8000591a:	00003797          	auipc	a5,0x3
    8000591e:	10e7a783          	lw	a5,270(a5) # 80008a28 <seen_arp.0>
    80005922:	10079263          	bnez	a5,80005a26 <arp_rx+0x118>
    80005926:	ec26                	sd	s1,24(sp)
    80005928:	e44e                	sd	s3,8(sp)
    8000592a:	e052                	sd	s4,0(sp)
        kfree(inbuf);
        return;
    }
    printf("arp_rx: received an ARP packet\n");
    8000592c:	00003517          	auipc	a0,0x3
    80005930:	e7c50513          	addi	a0,a0,-388 # 800087a8 <etext+0x7a8>
    80005934:	694000ef          	jal	80005fc8 <printf>
    seen_arp = 1;
    80005938:	4785                	li	a5,1
    8000593a:	00003717          	auipc	a4,0x3
    8000593e:	0ef72723          	sw	a5,238(a4) # 80008a28 <seen_arp.0>

    struct eth *ineth = (struct eth *) inbuf;
    struct arp *inarp = (struct arp *) (ineth + 1);

    char *buf = kalloc();
    80005942:	fc2fa0ef          	jal	80000104 <kalloc>
    80005946:	84aa                	mv	s1,a0
    if(buf == 0)
    80005948:	0e050263          	beqz	a0,80005a2c <arp_rx+0x11e>
        panic("send_arp_reply");

    struct eth *eth = (struct eth *) buf;
    memmove(eth->dhost, ineth->shost, ETHADDR_LEN); // ethernet destination = query source
    8000594c:	00690a13          	addi	s4,s2,6
    80005950:	4619                	li	a2,6
    80005952:	85d2                	mv	a1,s4
    80005954:	86bfa0ef          	jal	800001be <memmove>
    memmove(eth->shost, local_mac, ETHADDR_LEN); // ethernet source = xv6's ethernet address
    80005958:	4619                	li	a2,6
    8000595a:	00003597          	auipc	a1,0x3
    8000595e:	05658593          	addi	a1,a1,86 # 800089b0 <local_mac>
    80005962:	00c48533          	add	a0,s1,a2
    80005966:	859fa0ef          	jal	800001be <memmove>
    eth->type = htons(ETHTYPE_ARP);
    8000596a:	47a1                	li	a5,8
    8000596c:	00f48623          	sb	a5,12(s1)
    80005970:	4719                	li	a4,6
    80005972:	00e486a3          	sb	a4,13(s1)

    struct arp *arp = (struct arp *)(eth + 1);
    arp->hrd = htons(ARP_HRD_ETHER);
    80005976:	00048723          	sb	zero,14(s1)
    8000597a:	4705                	li	a4,1
    8000597c:	00e487a3          	sb	a4,15(s1)
    arp->pro = htons(ETHTYPE_IP);
    80005980:	00f48823          	sb	a5,16(s1)
    80005984:	000488a3          	sb	zero,17(s1)
    arp->hln = ETHADDR_LEN;
    80005988:	4799                	li	a5,6
    8000598a:	00f48923          	sb	a5,18(s1)
    arp->pln = sizeof(uint32);
    8000598e:	4791                	li	a5,4
    80005990:	00f489a3          	sb	a5,19(s1)
    arp->op = htons(ARP_OP_REPLY);
    80005994:	00048a23          	sb	zero,20(s1)
    80005998:	4989                	li	s3,2
    8000599a:	01348aa3          	sb	s3,21(s1)

    memmove(arp->sha, local_mac, ETHADDR_LEN);
    8000599e:	4619                	li	a2,6
    800059a0:	00003597          	auipc	a1,0x3
    800059a4:	01058593          	addi	a1,a1,16 # 800089b0 <local_mac>
    800059a8:	01648513          	addi	a0,s1,22
    800059ac:	813fa0ef          	jal	800001be <memmove>
    arp->sip = htonl(local_ip);
    800059b0:	47a9                	li	a5,10
    800059b2:	00f48e23          	sb	a5,28(s1)
    800059b6:	00048ea3          	sb	zero,29(s1)
    800059ba:	01348f23          	sb	s3,30(s1)
    800059be:	47bd                	li	a5,15
    800059c0:	00f48fa3          	sb	a5,31(s1)
    memmove(arp->tha, ineth->shost, ETHADDR_LEN);
    800059c4:	4619                	li	a2,6
    800059c6:	85d2                	mv	a1,s4
    800059c8:	02048513          	addi	a0,s1,32
    800059cc:	ff2fa0ef          	jal	800001be <memmove>
    arp->tip = inarp->sip;
    800059d0:	01c94703          	lbu	a4,28(s2)
    800059d4:	01d94783          	lbu	a5,29(s2)
    800059d8:	07a2                	slli	a5,a5,0x8
    800059da:	8fd9                	or	a5,a5,a4
    800059dc:	01e94703          	lbu	a4,30(s2)
    800059e0:	0742                	slli	a4,a4,0x10
    800059e2:	8f5d                	or	a4,a4,a5
    800059e4:	01f94783          	lbu	a5,31(s2)
    800059e8:	07e2                	slli	a5,a5,0x18
    800059ea:	8fd9                	or	a5,a5,a4
    800059ec:	02f48323          	sb	a5,38(s1)
    800059f0:	0087d713          	srli	a4,a5,0x8
    800059f4:	02e483a3          	sb	a4,39(s1)
    800059f8:	0107d713          	srli	a4,a5,0x10
    800059fc:	02e48423          	sb	a4,40(s1)
    80005a00:	83e1                	srli	a5,a5,0x18
    80005a02:	02f484a3          	sb	a5,41(s1)

    e1000_transmit(buf, sizeof(*eth) + sizeof(*arp));
    80005a06:	02a00593          	li	a1,42
    80005a0a:	8526                	mv	a0,s1
    80005a0c:	caaff0ef          	jal	80004eb6 <e1000_transmit>

    kfree(inbuf);
    80005a10:	854a                	mv	a0,s2
    80005a12:	e0afa0ef          	jal	8000001c <kfree>
    80005a16:	64e2                	ld	s1,24(sp)
    80005a18:	69a2                	ld	s3,8(sp)
    80005a1a:	6a02                	ld	s4,0(sp)
}
    80005a1c:	70a2                	ld	ra,40(sp)
    80005a1e:	7402                	ld	s0,32(sp)
    80005a20:	6942                	ld	s2,16(sp)
    80005a22:	6145                	addi	sp,sp,48
    80005a24:	8082                	ret
        kfree(inbuf);
    80005a26:	df6fa0ef          	jal	8000001c <kfree>
        return;
    80005a2a:	bfcd                	j	80005a1c <arp_rx+0x10e>
        panic("send_arp_reply");
    80005a2c:	00003517          	auipc	a0,0x3
    80005a30:	d9c50513          	addi	a0,a0,-612 # 800087c8 <etext+0x7c8>
    80005a34:	0a5000ef          	jal	800062d8 <panic>

0000000080005a38 <net_rx>:

void
net_rx(char *buf, int len)
{
    80005a38:	1141                	addi	sp,sp,-16
    80005a3a:	e406                	sd	ra,8(sp)
    80005a3c:	e022                	sd	s0,0(sp)
    80005a3e:	0800                	addi	s0,sp,16
    struct eth *eth = (struct eth *) buf;

    if(len >= sizeof(struct eth) + sizeof(struct arp) &&
    80005a40:	02900793          	li	a5,41
    80005a44:	02b7fe63          	bgeu	a5,a1,80005a80 <net_rx+0x48>
       ntohs(eth->type) == ETHTYPE_ARP){
    80005a48:	00c54703          	lbu	a4,12(a0)
    80005a4c:	00d54783          	lbu	a5,13(a0)
    80005a50:	07a2                	slli	a5,a5,0x8
    if(len >= sizeof(struct eth) + sizeof(struct arp) &&
    80005a52:	8fd9                	or	a5,a5,a4
    80005a54:	60800713          	li	a4,1544
    80005a58:	02e78163          	beq	a5,a4,80005a7a <net_rx+0x42>
        arp_rx(buf);
    } else if(len >= sizeof(struct eth) + sizeof(struct ip) &&
              ntohs(eth->type) == ETHTYPE_IP){
    80005a5c:	00c54703          	lbu	a4,12(a0)
    80005a60:	00d54783          	lbu	a5,13(a0)
    80005a64:	07a2                	slli	a5,a5,0x8
    } else if(len >= sizeof(struct eth) + sizeof(struct ip) &&
    80005a66:	8fd9                	or	a5,a5,a4
    80005a68:	4721                	li	a4,8
    80005a6a:	02e78063          	beq	a5,a4,80005a8a <net_rx+0x52>
        ip_rx(buf, len);
    } else {
        kfree(buf);
    80005a6e:	daefa0ef          	jal	8000001c <kfree>
    }
}
    80005a72:	60a2                	ld	ra,8(sp)
    80005a74:	6402                	ld	s0,0(sp)
    80005a76:	0141                	addi	sp,sp,16
    80005a78:	8082                	ret
        arp_rx(buf);
    80005a7a:	e95ff0ef          	jal	8000590e <arp_rx>
    80005a7e:	bfd5                	j	80005a72 <net_rx+0x3a>
    } else if(len >= sizeof(struct eth) + sizeof(struct ip) &&
    80005a80:	02100793          	li	a5,33
    80005a84:	feb7f5e3          	bgeu	a5,a1,80005a6e <net_rx+0x36>
    80005a88:	bfd1                	j	80005a5c <net_rx+0x24>
        ip_rx(buf, len);
    80005a8a:	c67ff0ef          	jal	800056f0 <ip_rx>
    80005a8e:	b7d5                	j	80005a72 <net_rx+0x3a>

0000000080005a90 <pci_init>:
#include "proc.h"
#include "defs.h"

void
pci_init()
{
    80005a90:	715d                	addi	sp,sp,-80
    80005a92:	e486                	sd	ra,72(sp)
    80005a94:	e0a2                	sd	s0,64(sp)
    80005a96:	fc26                	sd	s1,56(sp)
    80005a98:	f84a                	sd	s2,48(sp)
    80005a9a:	f44e                	sd	s3,40(sp)
    80005a9c:	f052                	sd	s4,32(sp)
    80005a9e:	ec56                	sd	s5,24(sp)
    80005aa0:	e85a                	sd	s6,16(sp)
    80005aa2:	e45e                	sd	s7,8(sp)
    80005aa4:	0880                	addi	s0,sp,80
    80005aa6:	300004b7          	lui	s1,0x30000
    uint32 off = (bus << 16) | (dev << 11) | (func << 8) | (offset);
    volatile uint32 *base = ecam + off;
    uint32 id = base[0];
    
    // 100e:8086 is an e1000
    if(id == 0x100e8086){
    80005aaa:	100e8937          	lui	s2,0x100e8
    80005aae:	08690913          	addi	s2,s2,134 # 100e8086 <_entry-0x6ff17f7a>
      // command and status register.
      // bit 0 : I/O access enable
      // bit 1 : memory access enable
      // bit 2 : enable mastering
      base[1] = 7;
    80005ab2:	4b9d                	li	s7,7
      for(int i = 0; i < 6; i++){
        uint32 old = base[4+i];

        // writing all 1's to the BAR causes it to be
        // replaced with its size.
        base[4+i] = 0xffffffff;
    80005ab4:	5afd                	li	s5,-1
        base[4+i] = old;
      }

      // tell the e1000 to reveal its registers at
      // physical address 0x40000000.
      base[4+0] = e1000_regs;
    80005ab6:	40000b37          	lui	s6,0x40000
  for(int dev = 0; dev < 32; dev++){
    80005aba:	6a09                	lui	s4,0x2
    80005abc:	300409b7          	lui	s3,0x30040
    80005ac0:	a021                	j	80005ac8 <pci_init+0x38>
    80005ac2:	94d2                	add	s1,s1,s4
    80005ac4:	03348f63          	beq	s1,s3,80005b02 <pci_init+0x72>
    volatile uint32 *base = ecam + off;
    80005ac8:	86a6                	mv	a3,s1
    uint32 id = base[0];
    80005aca:	409c                	lw	a5,0(s1)
    80005acc:	2781                	sext.w	a5,a5
    if(id == 0x100e8086){
    80005ace:	ff279ae3          	bne	a5,s2,80005ac2 <pci_init+0x32>
      base[1] = 7;
    80005ad2:	0174a223          	sw	s7,4(s1) # 30000004 <_entry-0x4ffffffc>
      __sync_synchronize();
    80005ad6:	0330000f          	fence	rw,rw
      for(int i = 0; i < 6; i++){
    80005ada:	01048793          	addi	a5,s1,16
    80005ade:	02848613          	addi	a2,s1,40
        uint32 old = base[4+i];
    80005ae2:	4398                	lw	a4,0(a5)
    80005ae4:	2701                	sext.w	a4,a4
        base[4+i] = 0xffffffff;
    80005ae6:	0157a023          	sw	s5,0(a5)
        __sync_synchronize();
    80005aea:	0330000f          	fence	rw,rw
        base[4+i] = old;
    80005aee:	c398                	sw	a4,0(a5)
      for(int i = 0; i < 6; i++){
    80005af0:	0791                	addi	a5,a5,4
    80005af2:	fec798e3          	bne	a5,a2,80005ae2 <pci_init+0x52>
      base[4+0] = e1000_regs;
    80005af6:	0166a823          	sw	s6,16(a3)

      e1000_init((uint32*)e1000_regs);
    80005afa:	855a                	mv	a0,s6
    80005afc:	a2aff0ef          	jal	80004d26 <e1000_init>
    80005b00:	b7c9                	j	80005ac2 <pci_init+0x32>
    }
  }
}
    80005b02:	60a6                	ld	ra,72(sp)
    80005b04:	6406                	ld	s0,64(sp)
    80005b06:	74e2                	ld	s1,56(sp)
    80005b08:	7942                	ld	s2,48(sp)
    80005b0a:	79a2                	ld	s3,40(sp)
    80005b0c:	7a02                	ld	s4,32(sp)
    80005b0e:	6ae2                	ld	s5,24(sp)
    80005b10:	6b42                	ld	s6,16(sp)
    80005b12:	6ba2                	ld	s7,8(sp)
    80005b14:	6161                	addi	sp,sp,80
    80005b16:	8082                	ret

0000000080005b18 <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80005b18:	1141                	addi	sp,sp,-16
    80005b1a:	e406                	sd	ra,8(sp)
    80005b1c:	e022                	sd	s0,0(sp)
    80005b1e:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80005b20:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80005b24:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80005b28:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80005b2c:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80005b30:	577d                	li	a4,-1
    80005b32:	177e                	slli	a4,a4,0x3f
    80005b34:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80005b36:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80005b3a:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80005b3e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80005b42:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80005b46:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80005b4a:	000f4737          	lui	a4,0xf4
    80005b4e:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80005b52:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80005b54:	14d79073          	csrw	stimecmp,a5
}
    80005b58:	60a2                	ld	ra,8(sp)
    80005b5a:	6402                	ld	s0,0(sp)
    80005b5c:	0141                	addi	sp,sp,16
    80005b5e:	8082                	ret

0000000080005b60 <start>:
{
    80005b60:	1141                	addi	sp,sp,-16
    80005b62:	e406                	sd	ra,8(sp)
    80005b64:	e022                	sd	s0,0(sp)
    80005b66:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80005b68:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80005b6c:	7779                	lui	a4,0xffffe
    80005b6e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ff7873f>
    80005b72:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80005b74:	6705                	lui	a4,0x1
    80005b76:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80005b7a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80005b7c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80005b80:	ffffa797          	auipc	a5,0xffffa
    80005b84:	79478793          	addi	a5,a5,1940 # 80000314 <main>
    80005b88:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80005b8c:	4781                	li	a5,0
    80005b8e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80005b92:	67c1                	lui	a5,0x10
    80005b94:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80005b96:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80005b9a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80005b9e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80005ba2:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80005ba6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80005baa:	57fd                	li	a5,-1
    80005bac:	83a9                	srli	a5,a5,0xa
    80005bae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80005bb2:	47bd                	li	a5,15
    80005bb4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80005bb8:	f61ff0ef          	jal	80005b18 <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80005bbc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80005bc0:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80005bc2:	823e                	mv	tp,a5
  asm volatile("mret");
    80005bc4:	30200073          	mret
}
    80005bc8:	60a2                	ld	ra,8(sp)
    80005bca:	6402                	ld	s0,0(sp)
    80005bcc:	0141                	addi	sp,sp,16
    80005bce:	8082                	ret

0000000080005bd0 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80005bd0:	711d                	addi	sp,sp,-96
    80005bd2:	ec86                	sd	ra,88(sp)
    80005bd4:	e8a2                	sd	s0,80(sp)
    80005bd6:	e0ca                	sd	s2,64(sp)
    80005bd8:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    80005bda:	04c05763          	blez	a2,80005c28 <consolewrite+0x58>
    80005bde:	e4a6                	sd	s1,72(sp)
    80005be0:	fc4e                	sd	s3,56(sp)
    80005be2:	f852                	sd	s4,48(sp)
    80005be4:	f456                	sd	s5,40(sp)
    80005be6:	f05a                	sd	s6,32(sp)
    80005be8:	ec5e                	sd	s7,24(sp)
    80005bea:	8a2a                	mv	s4,a0
    80005bec:	84ae                	mv	s1,a1
    80005bee:	89b2                	mv	s3,a2
    80005bf0:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80005bf2:	faf40b93          	addi	s7,s0,-81
    80005bf6:	4b05                	li	s6,1
    80005bf8:	5afd                	li	s5,-1
    80005bfa:	86da                	mv	a3,s6
    80005bfc:	8626                	mv	a2,s1
    80005bfe:	85d2                	mv	a1,s4
    80005c00:	855e                	mv	a0,s7
    80005c02:	b2ffb0ef          	jal	80001730 <either_copyin>
    80005c06:	03550363          	beq	a0,s5,80005c2c <consolewrite+0x5c>
      break;
    uartputc(c);
    80005c0a:	faf44503          	lbu	a0,-81(s0)
    80005c0e:	06b000ef          	jal	80006478 <uartputc>
  for(i = 0; i < n; i++){
    80005c12:	2905                	addiw	s2,s2,1
    80005c14:	0485                	addi	s1,s1,1
    80005c16:	ff2992e3          	bne	s3,s2,80005bfa <consolewrite+0x2a>
    80005c1a:	64a6                	ld	s1,72(sp)
    80005c1c:	79e2                	ld	s3,56(sp)
    80005c1e:	7a42                	ld	s4,48(sp)
    80005c20:	7aa2                	ld	s5,40(sp)
    80005c22:	7b02                	ld	s6,32(sp)
    80005c24:	6be2                	ld	s7,24(sp)
    80005c26:	a809                	j	80005c38 <consolewrite+0x68>
    80005c28:	4901                	li	s2,0
    80005c2a:	a039                	j	80005c38 <consolewrite+0x68>
    80005c2c:	64a6                	ld	s1,72(sp)
    80005c2e:	79e2                	ld	s3,56(sp)
    80005c30:	7a42                	ld	s4,48(sp)
    80005c32:	7aa2                	ld	s5,40(sp)
    80005c34:	7b02                	ld	s6,32(sp)
    80005c36:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    80005c38:	854a                	mv	a0,s2
    80005c3a:	60e6                	ld	ra,88(sp)
    80005c3c:	6446                	ld	s0,80(sp)
    80005c3e:	6906                	ld	s2,64(sp)
    80005c40:	6125                	addi	sp,sp,96
    80005c42:	8082                	ret

0000000080005c44 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80005c44:	711d                	addi	sp,sp,-96
    80005c46:	ec86                	sd	ra,88(sp)
    80005c48:	e8a2                	sd	s0,80(sp)
    80005c4a:	e4a6                	sd	s1,72(sp)
    80005c4c:	e0ca                	sd	s2,64(sp)
    80005c4e:	fc4e                	sd	s3,56(sp)
    80005c50:	f852                	sd	s4,48(sp)
    80005c52:	f05a                	sd	s6,32(sp)
    80005c54:	ec5e                	sd	s7,24(sp)
    80005c56:	1080                	addi	s0,sp,96
    80005c58:	8b2a                	mv	s6,a0
    80005c5a:	8a2e                	mv	s4,a1
    80005c5c:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80005c5e:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80005c60:	00080517          	auipc	a0,0x80
    80005c64:	36050513          	addi	a0,a0,864 # 80085fc0 <cons>
    80005c68:	1af000ef          	jal	80006616 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80005c6c:	00080497          	auipc	s1,0x80
    80005c70:	35448493          	addi	s1,s1,852 # 80085fc0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80005c74:	00080917          	auipc	s2,0x80
    80005c78:	3e490913          	addi	s2,s2,996 # 80086058 <cons+0x98>
  while(n > 0){
    80005c7c:	0b305b63          	blez	s3,80005d32 <consoleread+0xee>
    while(cons.r == cons.w){
    80005c80:	0984a783          	lw	a5,152(s1)
    80005c84:	09c4a703          	lw	a4,156(s1)
    80005c88:	0af71063          	bne	a4,a5,80005d28 <consoleread+0xe4>
      if(killed(myproc())){
    80005c8c:	92efb0ef          	jal	80000dba <myproc>
    80005c90:	939fb0ef          	jal	800015c8 <killed>
    80005c94:	e12d                	bnez	a0,80005cf6 <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    80005c96:	85a6                	mv	a1,s1
    80005c98:	854a                	mv	a0,s2
    80005c9a:	ef2fb0ef          	jal	8000138c <sleep>
    while(cons.r == cons.w){
    80005c9e:	0984a783          	lw	a5,152(s1)
    80005ca2:	09c4a703          	lw	a4,156(s1)
    80005ca6:	fef703e3          	beq	a4,a5,80005c8c <consoleread+0x48>
    80005caa:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80005cac:	00080717          	auipc	a4,0x80
    80005cb0:	31470713          	addi	a4,a4,788 # 80085fc0 <cons>
    80005cb4:	0017869b          	addiw	a3,a5,1
    80005cb8:	08d72c23          	sw	a3,152(a4)
    80005cbc:	07f7f693          	andi	a3,a5,127
    80005cc0:	9736                	add	a4,a4,a3
    80005cc2:	01874703          	lbu	a4,24(a4)
    80005cc6:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    80005cca:	4691                	li	a3,4
    80005ccc:	04da8663          	beq	s5,a3,80005d18 <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80005cd0:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80005cd4:	4685                	li	a3,1
    80005cd6:	faf40613          	addi	a2,s0,-81
    80005cda:	85d2                	mv	a1,s4
    80005cdc:	855a                	mv	a0,s6
    80005cde:	a09fb0ef          	jal	800016e6 <either_copyout>
    80005ce2:	57fd                	li	a5,-1
    80005ce4:	04f50663          	beq	a0,a5,80005d30 <consoleread+0xec>
      break;

    dst++;
    80005ce8:	0a05                	addi	s4,s4,1 # 2001 <_entry-0x7fffdfff>
    --n;
    80005cea:	39fd                	addiw	s3,s3,-1 # 3003ffff <_entry-0x4ffc0001>

    if(c == '\n'){
    80005cec:	47a9                	li	a5,10
    80005cee:	04fa8b63          	beq	s5,a5,80005d44 <consoleread+0x100>
    80005cf2:	7aa2                	ld	s5,40(sp)
    80005cf4:	b761                	j	80005c7c <consoleread+0x38>
        release(&cons.lock);
    80005cf6:	00080517          	auipc	a0,0x80
    80005cfa:	2ca50513          	addi	a0,a0,714 # 80085fc0 <cons>
    80005cfe:	1ad000ef          	jal	800066aa <release>
        return -1;
    80005d02:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80005d04:	60e6                	ld	ra,88(sp)
    80005d06:	6446                	ld	s0,80(sp)
    80005d08:	64a6                	ld	s1,72(sp)
    80005d0a:	6906                	ld	s2,64(sp)
    80005d0c:	79e2                	ld	s3,56(sp)
    80005d0e:	7a42                	ld	s4,48(sp)
    80005d10:	7b02                	ld	s6,32(sp)
    80005d12:	6be2                	ld	s7,24(sp)
    80005d14:	6125                	addi	sp,sp,96
    80005d16:	8082                	ret
      if(n < target){
    80005d18:	0179fa63          	bgeu	s3,s7,80005d2c <consoleread+0xe8>
        cons.r--;
    80005d1c:	00080717          	auipc	a4,0x80
    80005d20:	32f72e23          	sw	a5,828(a4) # 80086058 <cons+0x98>
    80005d24:	7aa2                	ld	s5,40(sp)
    80005d26:	a031                	j	80005d32 <consoleread+0xee>
    80005d28:	f456                	sd	s5,40(sp)
    80005d2a:	b749                	j	80005cac <consoleread+0x68>
    80005d2c:	7aa2                	ld	s5,40(sp)
    80005d2e:	a011                	j	80005d32 <consoleread+0xee>
    80005d30:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80005d32:	00080517          	auipc	a0,0x80
    80005d36:	28e50513          	addi	a0,a0,654 # 80085fc0 <cons>
    80005d3a:	171000ef          	jal	800066aa <release>
  return target - n;
    80005d3e:	413b853b          	subw	a0,s7,s3
    80005d42:	b7c9                	j	80005d04 <consoleread+0xc0>
    80005d44:	7aa2                	ld	s5,40(sp)
    80005d46:	b7f5                	j	80005d32 <consoleread+0xee>

0000000080005d48 <consputc>:
{
    80005d48:	1141                	addi	sp,sp,-16
    80005d4a:	e406                	sd	ra,8(sp)
    80005d4c:	e022                	sd	s0,0(sp)
    80005d4e:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80005d50:	10000793          	li	a5,256
    80005d54:	00f50863          	beq	a0,a5,80005d64 <consputc+0x1c>
    uartputc_sync(c);
    80005d58:	63e000ef          	jal	80006396 <uartputc_sync>
}
    80005d5c:	60a2                	ld	ra,8(sp)
    80005d5e:	6402                	ld	s0,0(sp)
    80005d60:	0141                	addi	sp,sp,16
    80005d62:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80005d64:	4521                	li	a0,8
    80005d66:	630000ef          	jal	80006396 <uartputc_sync>
    80005d6a:	02000513          	li	a0,32
    80005d6e:	628000ef          	jal	80006396 <uartputc_sync>
    80005d72:	4521                	li	a0,8
    80005d74:	622000ef          	jal	80006396 <uartputc_sync>
    80005d78:	b7d5                	j	80005d5c <consputc+0x14>

0000000080005d7a <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80005d7a:	1101                	addi	sp,sp,-32
    80005d7c:	ec06                	sd	ra,24(sp)
    80005d7e:	e822                	sd	s0,16(sp)
    80005d80:	e426                	sd	s1,8(sp)
    80005d82:	1000                	addi	s0,sp,32
    80005d84:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80005d86:	00080517          	auipc	a0,0x80
    80005d8a:	23a50513          	addi	a0,a0,570 # 80085fc0 <cons>
    80005d8e:	089000ef          	jal	80006616 <acquire>

  switch(c){
    80005d92:	47d5                	li	a5,21
    80005d94:	08f48d63          	beq	s1,a5,80005e2e <consoleintr+0xb4>
    80005d98:	0297c563          	blt	a5,s1,80005dc2 <consoleintr+0x48>
    80005d9c:	47a1                	li	a5,8
    80005d9e:	0ef48263          	beq	s1,a5,80005e82 <consoleintr+0x108>
    80005da2:	47c1                	li	a5,16
    80005da4:	10f49363          	bne	s1,a5,80005eaa <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    80005da8:	9d3fb0ef          	jal	8000177a <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    80005dac:	00080517          	auipc	a0,0x80
    80005db0:	21450513          	addi	a0,a0,532 # 80085fc0 <cons>
    80005db4:	0f7000ef          	jal	800066aa <release>
}
    80005db8:	60e2                	ld	ra,24(sp)
    80005dba:	6442                	ld	s0,16(sp)
    80005dbc:	64a2                	ld	s1,8(sp)
    80005dbe:	6105                	addi	sp,sp,32
    80005dc0:	8082                	ret
  switch(c){
    80005dc2:	07f00793          	li	a5,127
    80005dc6:	0af48e63          	beq	s1,a5,80005e82 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005dca:	00080717          	auipc	a4,0x80
    80005dce:	1f670713          	addi	a4,a4,502 # 80085fc0 <cons>
    80005dd2:	0a072783          	lw	a5,160(a4)
    80005dd6:	09872703          	lw	a4,152(a4)
    80005dda:	9f99                	subw	a5,a5,a4
    80005ddc:	07f00713          	li	a4,127
    80005de0:	fcf766e3          	bltu	a4,a5,80005dac <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80005de4:	47b5                	li	a5,13
    80005de6:	0cf48563          	beq	s1,a5,80005eb0 <consoleintr+0x136>
      consputc(c);
    80005dea:	8526                	mv	a0,s1
    80005dec:	f5dff0ef          	jal	80005d48 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005df0:	00080717          	auipc	a4,0x80
    80005df4:	1d070713          	addi	a4,a4,464 # 80085fc0 <cons>
    80005df8:	0a072683          	lw	a3,160(a4)
    80005dfc:	0016879b          	addiw	a5,a3,1
    80005e00:	863e                	mv	a2,a5
    80005e02:	0af72023          	sw	a5,160(a4)
    80005e06:	07f6f693          	andi	a3,a3,127
    80005e0a:	9736                	add	a4,a4,a3
    80005e0c:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80005e10:	ff648713          	addi	a4,s1,-10
    80005e14:	c371                	beqz	a4,80005ed8 <consoleintr+0x15e>
    80005e16:	14f1                	addi	s1,s1,-4
    80005e18:	c0e1                	beqz	s1,80005ed8 <consoleintr+0x15e>
    80005e1a:	00080717          	auipc	a4,0x80
    80005e1e:	23e72703          	lw	a4,574(a4) # 80086058 <cons+0x98>
    80005e22:	9f99                	subw	a5,a5,a4
    80005e24:	08000713          	li	a4,128
    80005e28:	f8e792e3          	bne	a5,a4,80005dac <consoleintr+0x32>
    80005e2c:	a075                	j	80005ed8 <consoleintr+0x15e>
    80005e2e:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80005e30:	00080717          	auipc	a4,0x80
    80005e34:	19070713          	addi	a4,a4,400 # 80085fc0 <cons>
    80005e38:	0a072783          	lw	a5,160(a4)
    80005e3c:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005e40:	00080497          	auipc	s1,0x80
    80005e44:	18048493          	addi	s1,s1,384 # 80085fc0 <cons>
    while(cons.e != cons.w &&
    80005e48:	4929                	li	s2,10
    80005e4a:	02f70863          	beq	a4,a5,80005e7a <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005e4e:	37fd                	addiw	a5,a5,-1
    80005e50:	07f7f713          	andi	a4,a5,127
    80005e54:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80005e56:	01874703          	lbu	a4,24(a4)
    80005e5a:	03270263          	beq	a4,s2,80005e7e <consoleintr+0x104>
      cons.e--;
    80005e5e:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005e62:	10000513          	li	a0,256
    80005e66:	ee3ff0ef          	jal	80005d48 <consputc>
    while(cons.e != cons.w &&
    80005e6a:	0a04a783          	lw	a5,160(s1)
    80005e6e:	09c4a703          	lw	a4,156(s1)
    80005e72:	fcf71ee3          	bne	a4,a5,80005e4e <consoleintr+0xd4>
    80005e76:	6902                	ld	s2,0(sp)
    80005e78:	bf15                	j	80005dac <consoleintr+0x32>
    80005e7a:	6902                	ld	s2,0(sp)
    80005e7c:	bf05                	j	80005dac <consoleintr+0x32>
    80005e7e:	6902                	ld	s2,0(sp)
    80005e80:	b735                	j	80005dac <consoleintr+0x32>
    if(cons.e != cons.w){
    80005e82:	00080717          	auipc	a4,0x80
    80005e86:	13e70713          	addi	a4,a4,318 # 80085fc0 <cons>
    80005e8a:	0a072783          	lw	a5,160(a4)
    80005e8e:	09c72703          	lw	a4,156(a4)
    80005e92:	f0f70de3          	beq	a4,a5,80005dac <consoleintr+0x32>
      cons.e--;
    80005e96:	37fd                	addiw	a5,a5,-1
    80005e98:	00080717          	auipc	a4,0x80
    80005e9c:	1cf72423          	sw	a5,456(a4) # 80086060 <cons+0xa0>
      consputc(BACKSPACE);
    80005ea0:	10000513          	li	a0,256
    80005ea4:	ea5ff0ef          	jal	80005d48 <consputc>
    80005ea8:	b711                	j	80005dac <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005eaa:	f00481e3          	beqz	s1,80005dac <consoleintr+0x32>
    80005eae:	bf31                	j	80005dca <consoleintr+0x50>
      consputc(c);
    80005eb0:	4529                	li	a0,10
    80005eb2:	e97ff0ef          	jal	80005d48 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005eb6:	00080797          	auipc	a5,0x80
    80005eba:	10a78793          	addi	a5,a5,266 # 80085fc0 <cons>
    80005ebe:	0a07a703          	lw	a4,160(a5)
    80005ec2:	0017069b          	addiw	a3,a4,1
    80005ec6:	8636                	mv	a2,a3
    80005ec8:	0ad7a023          	sw	a3,160(a5)
    80005ecc:	07f77713          	andi	a4,a4,127
    80005ed0:	97ba                	add	a5,a5,a4
    80005ed2:	4729                	li	a4,10
    80005ed4:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80005ed8:	00080797          	auipc	a5,0x80
    80005edc:	18c7a223          	sw	a2,388(a5) # 8008605c <cons+0x9c>
        wakeup(&cons.r);
    80005ee0:	00080517          	auipc	a0,0x80
    80005ee4:	17850513          	addi	a0,a0,376 # 80086058 <cons+0x98>
    80005ee8:	cf0fb0ef          	jal	800013d8 <wakeup>
    80005eec:	b5c1                	j	80005dac <consoleintr+0x32>

0000000080005eee <consoleinit>:

void
consoleinit(void)
{
    80005eee:	1141                	addi	sp,sp,-16
    80005ef0:	e406                	sd	ra,8(sp)
    80005ef2:	e022                	sd	s0,0(sp)
    80005ef4:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80005ef6:	00003597          	auipc	a1,0x3
    80005efa:	8e258593          	addi	a1,a1,-1822 # 800087d8 <etext+0x7d8>
    80005efe:	00080517          	auipc	a0,0x80
    80005f02:	0c250513          	addi	a0,a0,194 # 80085fc0 <cons>
    80005f06:	686000ef          	jal	8000658c <initlock>

  uartinit();
    80005f0a:	436000ef          	jal	80006340 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80005f0e:	00013797          	auipc	a5,0x13
    80005f12:	bda78793          	addi	a5,a5,-1062 # 80018ae8 <devsw>
    80005f16:	00000717          	auipc	a4,0x0
    80005f1a:	d2e70713          	addi	a4,a4,-722 # 80005c44 <consoleread>
    80005f1e:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80005f20:	00000717          	auipc	a4,0x0
    80005f24:	cb070713          	addi	a4,a4,-848 # 80005bd0 <consolewrite>
    80005f28:	ef98                	sd	a4,24(a5)
}
    80005f2a:	60a2                	ld	ra,8(sp)
    80005f2c:	6402                	ld	s0,0(sp)
    80005f2e:	0141                	addi	sp,sp,16
    80005f30:	8082                	ret

0000000080005f32 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80005f32:	7179                	addi	sp,sp,-48
    80005f34:	f406                	sd	ra,40(sp)
    80005f36:	f022                	sd	s0,32(sp)
    80005f38:	e84a                	sd	s2,16(sp)
    80005f3a:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80005f3c:	c219                	beqz	a2,80005f42 <printint+0x10>
    80005f3e:	08054163          	bltz	a0,80005fc0 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80005f42:	4301                	li	t1,0

  i = 0;
    80005f44:	fd040913          	addi	s2,s0,-48
    x = xx;
    80005f48:	86ca                	mv	a3,s2
  i = 0;
    80005f4a:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005f4c:	00003817          	auipc	a6,0x3
    80005f50:	a3c80813          	addi	a6,a6,-1476 # 80008988 <digits>
    80005f54:	88ba                	mv	a7,a4
    80005f56:	0017061b          	addiw	a2,a4,1
    80005f5a:	8732                	mv	a4,a2
    80005f5c:	02b577b3          	remu	a5,a0,a1
    80005f60:	97c2                	add	a5,a5,a6
    80005f62:	0007c783          	lbu	a5,0(a5)
    80005f66:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005f6a:	87aa                	mv	a5,a0
    80005f6c:	02b55533          	divu	a0,a0,a1
    80005f70:	0685                	addi	a3,a3,1
    80005f72:	feb7f1e3          	bgeu	a5,a1,80005f54 <printint+0x22>

  if(sign)
    80005f76:	00030c63          	beqz	t1,80005f8e <printint+0x5c>
    buf[i++] = '-';
    80005f7a:	fe060793          	addi	a5,a2,-32
    80005f7e:	00878633          	add	a2,a5,s0
    80005f82:	02d00793          	li	a5,45
    80005f86:	fef60823          	sb	a5,-16(a2)
    80005f8a:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80005f8e:	02e05463          	blez	a4,80005fb6 <printint+0x84>
    80005f92:	ec26                	sd	s1,24(sp)
    80005f94:	377d                	addiw	a4,a4,-1
    80005f96:	00e904b3          	add	s1,s2,a4
    80005f9a:	197d                	addi	s2,s2,-1
    80005f9c:	993a                	add	s2,s2,a4
    80005f9e:	1702                	slli	a4,a4,0x20
    80005fa0:	9301                	srli	a4,a4,0x20
    80005fa2:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    80005fa6:	0004c503          	lbu	a0,0(s1)
    80005faa:	d9fff0ef          	jal	80005d48 <consputc>
  while(--i >= 0)
    80005fae:	14fd                	addi	s1,s1,-1
    80005fb0:	ff249be3          	bne	s1,s2,80005fa6 <printint+0x74>
    80005fb4:	64e2                	ld	s1,24(sp)
}
    80005fb6:	70a2                	ld	ra,40(sp)
    80005fb8:	7402                	ld	s0,32(sp)
    80005fba:	6942                	ld	s2,16(sp)
    80005fbc:	6145                	addi	sp,sp,48
    80005fbe:	8082                	ret
    x = -xx;
    80005fc0:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    80005fc4:	4305                	li	t1,1
    x = -xx;
    80005fc6:	bfbd                	j	80005f44 <printint+0x12>

0000000080005fc8 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    80005fc8:	7131                	addi	sp,sp,-192
    80005fca:	fc86                	sd	ra,120(sp)
    80005fcc:	f8a2                	sd	s0,112(sp)
    80005fce:	f0ca                	sd	s2,96(sp)
    80005fd0:	ec6e                	sd	s11,24(sp)
    80005fd2:	0100                	addi	s0,sp,128
    80005fd4:	892a                	mv	s2,a0
    80005fd6:	e40c                	sd	a1,8(s0)
    80005fd8:	e810                	sd	a2,16(s0)
    80005fda:	ec14                	sd	a3,24(s0)
    80005fdc:	f018                	sd	a4,32(s0)
    80005fde:	f41c                	sd	a5,40(s0)
    80005fe0:	03043823          	sd	a6,48(s0)
    80005fe4:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    80005fe8:	00080d97          	auipc	s11,0x80
    80005fec:	098dad83          	lw	s11,152(s11) # 80086080 <pr+0x18>
  if(locking)
    80005ff0:	020d9d63          	bnez	s11,8000602a <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80005ff4:	00840793          	addi	a5,s0,8
    80005ff8:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005ffc:	00054503          	lbu	a0,0(a0)
    80006000:	20050f63          	beqz	a0,8000621e <printf+0x256>
    80006004:	f4a6                	sd	s1,104(sp)
    80006006:	ecce                	sd	s3,88(sp)
    80006008:	e8d2                	sd	s4,80(sp)
    8000600a:	e4d6                	sd	s5,72(sp)
    8000600c:	e0da                	sd	s6,64(sp)
    8000600e:	fc5e                	sd	s7,56(sp)
    80006010:	f862                	sd	s8,48(sp)
    80006012:	f06a                	sd	s10,32(sp)
    80006014:	4a81                	li	s5,0
    if(cx != '%'){
    80006016:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000601a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    8000601e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    80006022:	4b29                	li	s6,10
    if(c0 == 'd'){
    80006024:	06400b93          	li	s7,100
    80006028:	a80d                	j	8000605a <printf+0x92>
    acquire(&pr.lock);
    8000602a:	00080517          	auipc	a0,0x80
    8000602e:	03e50513          	addi	a0,a0,62 # 80086068 <pr>
    80006032:	5e4000ef          	jal	80006616 <acquire>
  va_start(ap, fmt);
    80006036:	00840793          	addi	a5,s0,8
    8000603a:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000603e:	00094503          	lbu	a0,0(s2)
    80006042:	f169                	bnez	a0,80006004 <printf+0x3c>
    80006044:	aae5                	j	8000623c <printf+0x274>
      consputc(cx);
    80006046:	d03ff0ef          	jal	80005d48 <consputc>
      continue;
    8000604a:	84d6                	mv	s1,s5
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000604c:	2485                	addiw	s1,s1,1
    8000604e:	8aa6                	mv	s5,s1
    80006050:	94ca                	add	s1,s1,s2
    80006052:	0004c503          	lbu	a0,0(s1)
    80006056:	1a050a63          	beqz	a0,8000620a <printf+0x242>
    if(cx != '%'){
    8000605a:	ff3516e3          	bne	a0,s3,80006046 <printf+0x7e>
    i++;
    8000605e:	001a879b          	addiw	a5,s5,1
    80006062:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    80006064:	00f90733          	add	a4,s2,a5
    80006068:	00074a03          	lbu	s4,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    8000606c:	1e0a0863          	beqz	s4,8000625c <printf+0x294>
    80006070:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    80006074:	1c068b63          	beqz	a3,8000624a <printf+0x282>
    if(c0 == 'd'){
    80006078:	037a0863          	beq	s4,s7,800060a8 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    8000607c:	f94a0713          	addi	a4,s4,-108
    80006080:	00173713          	seqz	a4,a4
    80006084:	f9c68613          	addi	a2,a3,-100
    80006088:	ee05                	bnez	a2,800060c0 <printf+0xf8>
    8000608a:	cb1d                	beqz	a4,800060c0 <printf+0xf8>
      printint(va_arg(ap, uint64), 10, 1);
    8000608c:	f8843783          	ld	a5,-120(s0)
    80006090:	00878713          	addi	a4,a5,8
    80006094:	f8e43423          	sd	a4,-120(s0)
    80006098:	4605                	li	a2,1
    8000609a:	85da                	mv	a1,s6
    8000609c:	6388                	ld	a0,0(a5)
    8000609e:	e95ff0ef          	jal	80005f32 <printint>
      i += 1;
    800060a2:	002a849b          	addiw	s1,s5,2
    800060a6:	b75d                	j	8000604c <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    800060a8:	f8843783          	ld	a5,-120(s0)
    800060ac:	00878713          	addi	a4,a5,8
    800060b0:	f8e43423          	sd	a4,-120(s0)
    800060b4:	4605                	li	a2,1
    800060b6:	85da                	mv	a1,s6
    800060b8:	4388                	lw	a0,0(a5)
    800060ba:	e79ff0ef          	jal	80005f32 <printint>
    800060be:	b779                	j	8000604c <printf+0x84>
    if(c1) c2 = fmt[i+2] & 0xff;
    800060c0:	97ca                	add	a5,a5,s2
    800060c2:	8636                	mv	a2,a3
    800060c4:	0027c683          	lbu	a3,2(a5)
    800060c8:	a245                	j	80006268 <printf+0x2a0>
      printint(va_arg(ap, uint64), 10, 1);
    800060ca:	f8843783          	ld	a5,-120(s0)
    800060ce:	00878713          	addi	a4,a5,8
    800060d2:	f8e43423          	sd	a4,-120(s0)
    800060d6:	4605                	li	a2,1
    800060d8:	45a9                	li	a1,10
    800060da:	6388                	ld	a0,0(a5)
    800060dc:	e57ff0ef          	jal	80005f32 <printint>
      i += 2;
    800060e0:	003a849b          	addiw	s1,s5,3
    800060e4:	b7a5                	j	8000604c <printf+0x84>
      printint(va_arg(ap, int), 10, 0);
    800060e6:	f8843783          	ld	a5,-120(s0)
    800060ea:	00878713          	addi	a4,a5,8
    800060ee:	f8e43423          	sd	a4,-120(s0)
    800060f2:	4601                	li	a2,0
    800060f4:	85da                	mv	a1,s6
    800060f6:	4388                	lw	a0,0(a5)
    800060f8:	e3bff0ef          	jal	80005f32 <printint>
    800060fc:	bf81                	j	8000604c <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800060fe:	f8843783          	ld	a5,-120(s0)
    80006102:	00878713          	addi	a4,a5,8
    80006106:	f8e43423          	sd	a4,-120(s0)
    8000610a:	4601                	li	a2,0
    8000610c:	85da                	mv	a1,s6
    8000610e:	6388                	ld	a0,0(a5)
    80006110:	e23ff0ef          	jal	80005f32 <printint>
      i += 1;
    80006114:	002a849b          	addiw	s1,s5,2
    80006118:	bf15                	j	8000604c <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    8000611a:	f8843783          	ld	a5,-120(s0)
    8000611e:	00878713          	addi	a4,a5,8
    80006122:	f8e43423          	sd	a4,-120(s0)
    80006126:	4601                	li	a2,0
    80006128:	45a9                	li	a1,10
    8000612a:	6388                	ld	a0,0(a5)
    8000612c:	e07ff0ef          	jal	80005f32 <printint>
      i += 2;
    80006130:	003a849b          	addiw	s1,s5,3
    80006134:	bf21                	j	8000604c <printf+0x84>
      printint(va_arg(ap, int), 16, 0);
    80006136:	f8843783          	ld	a5,-120(s0)
    8000613a:	00878713          	addi	a4,a5,8
    8000613e:	f8e43423          	sd	a4,-120(s0)
    80006142:	4601                	li	a2,0
    80006144:	45c1                	li	a1,16
    80006146:	4388                	lw	a0,0(a5)
    80006148:	debff0ef          	jal	80005f32 <printint>
    8000614c:	b701                	j	8000604c <printf+0x84>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    8000614e:	f8843783          	ld	a5,-120(s0)
    80006152:	00878713          	addi	a4,a5,8
    80006156:	f8e43423          	sd	a4,-120(s0)
    8000615a:	45c1                	li	a1,16
    8000615c:	6388                	ld	a0,0(a5)
    8000615e:	dd5ff0ef          	jal	80005f32 <printint>
      i += 1;
    80006162:	002a849b          	addiw	s1,s5,2
    80006166:	b5dd                	j	8000604c <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80006168:	f8843783          	ld	a5,-120(s0)
    8000616c:	00878713          	addi	a4,a5,8
    80006170:	f8e43423          	sd	a4,-120(s0)
    80006174:	4601                	li	a2,0
    80006176:	45c1                	li	a1,16
    80006178:	6388                	ld	a0,0(a5)
    8000617a:	db9ff0ef          	jal	80005f32 <printint>
      i += 2;
    8000617e:	003a849b          	addiw	s1,s5,3
    80006182:	b5e9                	j	8000604c <printf+0x84>
    80006184:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    80006186:	f8843783          	ld	a5,-120(s0)
    8000618a:	00878713          	addi	a4,a5,8
    8000618e:	f8e43423          	sd	a4,-120(s0)
    80006192:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    80006196:	03000513          	li	a0,48
    8000619a:	bafff0ef          	jal	80005d48 <consputc>
  consputc('x');
    8000619e:	07800513          	li	a0,120
    800061a2:	ba7ff0ef          	jal	80005d48 <consputc>
    800061a6:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800061a8:	00002c97          	auipc	s9,0x2
    800061ac:	7e0c8c93          	addi	s9,s9,2016 # 80008988 <digits>
    800061b0:	03cad793          	srli	a5,s5,0x3c
    800061b4:	97e6                	add	a5,a5,s9
    800061b6:	0007c503          	lbu	a0,0(a5)
    800061ba:	b8fff0ef          	jal	80005d48 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800061be:	0a92                	slli	s5,s5,0x4
    800061c0:	3a7d                	addiw	s4,s4,-1
    800061c2:	fe0a17e3          	bnez	s4,800061b0 <printf+0x1e8>
    800061c6:	7ca2                	ld	s9,40(sp)
    800061c8:	b551                	j	8000604c <printf+0x84>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    800061ca:	f8843783          	ld	a5,-120(s0)
    800061ce:	00878713          	addi	a4,a5,8
    800061d2:	f8e43423          	sd	a4,-120(s0)
    800061d6:	0007ba03          	ld	s4,0(a5)
    800061da:	000a0d63          	beqz	s4,800061f4 <printf+0x22c>
        s = "(null)";
      for(; *s; s++)
    800061de:	000a4503          	lbu	a0,0(s4)
    800061e2:	e60505e3          	beqz	a0,8000604c <printf+0x84>
        consputc(*s);
    800061e6:	b63ff0ef          	jal	80005d48 <consputc>
      for(; *s; s++)
    800061ea:	0a05                	addi	s4,s4,1
    800061ec:	000a4503          	lbu	a0,0(s4)
    800061f0:	f97d                	bnez	a0,800061e6 <printf+0x21e>
    800061f2:	bda9                	j	8000604c <printf+0x84>
        s = "(null)";
    800061f4:	00002a17          	auipc	s4,0x2
    800061f8:	5eca0a13          	addi	s4,s4,1516 # 800087e0 <etext+0x7e0>
      for(; *s; s++)
    800061fc:	02800513          	li	a0,40
    80006200:	b7dd                	j	800061e6 <printf+0x21e>
    } else if(c0 == '%'){
      consputc('%');
    80006202:	8552                	mv	a0,s4
    80006204:	b45ff0ef          	jal	80005d48 <consputc>
    80006208:	b591                	j	8000604c <printf+0x84>
    }
#endif
  }
  va_end(ap);

  if(locking)
    8000620a:	020d9163          	bnez	s11,8000622c <printf+0x264>
    8000620e:	74a6                	ld	s1,104(sp)
    80006210:	69e6                	ld	s3,88(sp)
    80006212:	6a46                	ld	s4,80(sp)
    80006214:	6aa6                	ld	s5,72(sp)
    80006216:	6b06                	ld	s6,64(sp)
    80006218:	7be2                	ld	s7,56(sp)
    8000621a:	7c42                	ld	s8,48(sp)
    8000621c:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    8000621e:	4501                	li	a0,0
    80006220:	70e6                	ld	ra,120(sp)
    80006222:	7446                	ld	s0,112(sp)
    80006224:	7906                	ld	s2,96(sp)
    80006226:	6de2                	ld	s11,24(sp)
    80006228:	6129                	addi	sp,sp,192
    8000622a:	8082                	ret
    8000622c:	74a6                	ld	s1,104(sp)
    8000622e:	69e6                	ld	s3,88(sp)
    80006230:	6a46                	ld	s4,80(sp)
    80006232:	6aa6                	ld	s5,72(sp)
    80006234:	6b06                	ld	s6,64(sp)
    80006236:	7be2                	ld	s7,56(sp)
    80006238:	7c42                	ld	s8,48(sp)
    8000623a:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    8000623c:	00080517          	auipc	a0,0x80
    80006240:	e2c50513          	addi	a0,a0,-468 # 80086068 <pr>
    80006244:	466000ef          	jal	800066aa <release>
    80006248:	bfd9                	j	8000621e <printf+0x256>
    if(c0 == 'd'){
    8000624a:	e57a0fe3          	beq	s4,s7,800060a8 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    8000624e:	f94a0713          	addi	a4,s4,-108
    80006252:	00173713          	seqz	a4,a4
    80006256:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    80006258:	4781                	li	a5,0
    8000625a:	a00d                	j	8000627c <printf+0x2b4>
    } else if(c0 == 'l' && c1 == 'd'){
    8000625c:	f94a0713          	addi	a4,s4,-108
    80006260:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    80006264:	8652                	mv	a2,s4
    80006266:	86d2                	mv	a3,s4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    80006268:	f9460793          	addi	a5,a2,-108
    8000626c:	0017b793          	seqz	a5,a5
    80006270:	8ff9                	and	a5,a5,a4
    80006272:	f9c68593          	addi	a1,a3,-100
    80006276:	e199                	bnez	a1,8000627c <printf+0x2b4>
    80006278:	e40799e3          	bnez	a5,800060ca <printf+0x102>
    } else if(c0 == 'u'){
    8000627c:	e78a05e3          	beq	s4,s8,800060e6 <printf+0x11e>
    } else if(c0 == 'l' && c1 == 'u'){
    80006280:	f8b60593          	addi	a1,a2,-117
    80006284:	e199                	bnez	a1,8000628a <printf+0x2c2>
    80006286:	e6071ce3          	bnez	a4,800060fe <printf+0x136>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    8000628a:	f8b68593          	addi	a1,a3,-117
    8000628e:	e199                	bnez	a1,80006294 <printf+0x2cc>
    80006290:	e80795e3          	bnez	a5,8000611a <printf+0x152>
    } else if(c0 == 'x'){
    80006294:	ebaa01e3          	beq	s4,s10,80006136 <printf+0x16e>
    } else if(c0 == 'l' && c1 == 'x'){
    80006298:	f8860613          	addi	a2,a2,-120
    8000629c:	e219                	bnez	a2,800062a2 <printf+0x2da>
    8000629e:	ea0718e3          	bnez	a4,8000614e <printf+0x186>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800062a2:	f8868693          	addi	a3,a3,-120
    800062a6:	e299                	bnez	a3,800062ac <printf+0x2e4>
    800062a8:	ec0790e3          	bnez	a5,80006168 <printf+0x1a0>
    } else if(c0 == 'p'){
    800062ac:	07000793          	li	a5,112
    800062b0:	ecfa0ae3          	beq	s4,a5,80006184 <printf+0x1bc>
    } else if(c0 == 's'){
    800062b4:	07300793          	li	a5,115
    800062b8:	f0fa09e3          	beq	s4,a5,800061ca <printf+0x202>
    } else if(c0 == '%'){
    800062bc:	02500793          	li	a5,37
    800062c0:	f4fa01e3          	beq	s4,a5,80006202 <printf+0x23a>
    } else if(c0 == 0){
    800062c4:	f40a03e3          	beqz	s4,8000620a <printf+0x242>
      consputc('%');
    800062c8:	02500513          	li	a0,37
    800062cc:	a7dff0ef          	jal	80005d48 <consputc>
      consputc(c0);
    800062d0:	8552                	mv	a0,s4
    800062d2:	a77ff0ef          	jal	80005d48 <consputc>
    800062d6:	bb9d                	j	8000604c <printf+0x84>

00000000800062d8 <panic>:

void
panic(char *s)
{
    800062d8:	1101                	addi	sp,sp,-32
    800062da:	ec06                	sd	ra,24(sp)
    800062dc:	e822                	sd	s0,16(sp)
    800062de:	e426                	sd	s1,8(sp)
    800062e0:	1000                	addi	s0,sp,32
    800062e2:	84aa                	mv	s1,a0
  pr.locking = 0;
    800062e4:	00080797          	auipc	a5,0x80
    800062e8:	d807ae23          	sw	zero,-612(a5) # 80086080 <pr+0x18>
  printf("panic: ");
    800062ec:	00002517          	auipc	a0,0x2
    800062f0:	4fc50513          	addi	a0,a0,1276 # 800087e8 <etext+0x7e8>
    800062f4:	cd5ff0ef          	jal	80005fc8 <printf>
  printf("%s\n", s);
    800062f8:	85a6                	mv	a1,s1
    800062fa:	00002517          	auipc	a0,0x2
    800062fe:	4f650513          	addi	a0,a0,1270 # 800087f0 <etext+0x7f0>
    80006302:	cc7ff0ef          	jal	80005fc8 <printf>
  panicked = 1; // freeze uart output from other CPUs
    80006306:	4785                	li	a5,1
    80006308:	00002717          	auipc	a4,0x2
    8000630c:	72f72623          	sw	a5,1836(a4) # 80008a34 <panicked>
  for(;;)
    80006310:	a001                	j	80006310 <panic+0x38>

0000000080006312 <printfinit>:
    ;
}

void
printfinit(void)
{
    80006312:	1141                	addi	sp,sp,-16
    80006314:	e406                	sd	ra,8(sp)
    80006316:	e022                	sd	s0,0(sp)
    80006318:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    8000631a:	00002597          	auipc	a1,0x2
    8000631e:	4de58593          	addi	a1,a1,1246 # 800087f8 <etext+0x7f8>
    80006322:	00080517          	auipc	a0,0x80
    80006326:	d4650513          	addi	a0,a0,-698 # 80086068 <pr>
    8000632a:	262000ef          	jal	8000658c <initlock>
  pr.locking = 1;
    8000632e:	4785                	li	a5,1
    80006330:	00080717          	auipc	a4,0x80
    80006334:	d4f72823          	sw	a5,-688(a4) # 80086080 <pr+0x18>
}
    80006338:	60a2                	ld	ra,8(sp)
    8000633a:	6402                	ld	s0,0(sp)
    8000633c:	0141                	addi	sp,sp,16
    8000633e:	8082                	ret

0000000080006340 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80006340:	1141                	addi	sp,sp,-16
    80006342:	e406                	sd	ra,8(sp)
    80006344:	e022                	sd	s0,0(sp)
    80006346:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80006348:	100007b7          	lui	a5,0x10000
    8000634c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80006350:	10000737          	lui	a4,0x10000
    80006354:	f8000693          	li	a3,-128
    80006358:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000635c:	468d                	li	a3,3
    8000635e:	10000637          	lui	a2,0x10000
    80006362:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80006366:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000636a:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000636e:	8732                	mv	a4,a2
    80006370:	461d                	li	a2,7
    80006372:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80006376:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    8000637a:	00002597          	auipc	a1,0x2
    8000637e:	48658593          	addi	a1,a1,1158 # 80008800 <etext+0x800>
    80006382:	00080517          	auipc	a0,0x80
    80006386:	d0650513          	addi	a0,a0,-762 # 80086088 <uart_tx_lock>
    8000638a:	202000ef          	jal	8000658c <initlock>
}
    8000638e:	60a2                	ld	ra,8(sp)
    80006390:	6402                	ld	s0,0(sp)
    80006392:	0141                	addi	sp,sp,16
    80006394:	8082                	ret

0000000080006396 <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80006396:	1101                	addi	sp,sp,-32
    80006398:	ec06                	sd	ra,24(sp)
    8000639a:	e822                	sd	s0,16(sp)
    8000639c:	e426                	sd	s1,8(sp)
    8000639e:	1000                	addi	s0,sp,32
    800063a0:	84aa                	mv	s1,a0
  push_off();
    800063a2:	230000ef          	jal	800065d2 <push_off>

  if(panicked){
    800063a6:	00002797          	auipc	a5,0x2
    800063aa:	68e7a783          	lw	a5,1678(a5) # 80008a34 <panicked>
    800063ae:	e795                	bnez	a5,800063da <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800063b0:	10000737          	lui	a4,0x10000
    800063b4:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    800063b6:	00074783          	lbu	a5,0(a4)
    800063ba:	0207f793          	andi	a5,a5,32
    800063be:	dfe5                	beqz	a5,800063b6 <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    800063c0:	0ff4f513          	zext.b	a0,s1
    800063c4:	100007b7          	lui	a5,0x10000
    800063c8:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800063cc:	28e000ef          	jal	8000665a <pop_off>
}
    800063d0:	60e2                	ld	ra,24(sp)
    800063d2:	6442                	ld	s0,16(sp)
    800063d4:	64a2                	ld	s1,8(sp)
    800063d6:	6105                	addi	sp,sp,32
    800063d8:	8082                	ret
    for(;;)
    800063da:	a001                	j	800063da <uartputc_sync+0x44>

00000000800063dc <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800063dc:	00002797          	auipc	a5,0x2
    800063e0:	65c7b783          	ld	a5,1628(a5) # 80008a38 <uart_tx_r>
    800063e4:	00002717          	auipc	a4,0x2
    800063e8:	65c73703          	ld	a4,1628(a4) # 80008a40 <uart_tx_w>
    800063ec:	08f70163          	beq	a4,a5,8000646e <uartstart+0x92>
{
    800063f0:	7139                	addi	sp,sp,-64
    800063f2:	fc06                	sd	ra,56(sp)
    800063f4:	f822                	sd	s0,48(sp)
    800063f6:	f426                	sd	s1,40(sp)
    800063f8:	f04a                	sd	s2,32(sp)
    800063fa:	ec4e                	sd	s3,24(sp)
    800063fc:	e852                	sd	s4,16(sp)
    800063fe:	e456                	sd	s5,8(sp)
    80006400:	e05a                	sd	s6,0(sp)
    80006402:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80006404:	10000937          	lui	s2,0x10000
    80006408:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    8000640a:	00080a97          	auipc	s5,0x80
    8000640e:	c7ea8a93          	addi	s5,s5,-898 # 80086088 <uart_tx_lock>
    uart_tx_r += 1;
    80006412:	00002497          	auipc	s1,0x2
    80006416:	62648493          	addi	s1,s1,1574 # 80008a38 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    8000641a:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    8000641e:	00002997          	auipc	s3,0x2
    80006422:	62298993          	addi	s3,s3,1570 # 80008a40 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80006426:	00094703          	lbu	a4,0(s2)
    8000642a:	02077713          	andi	a4,a4,32
    8000642e:	c715                	beqz	a4,8000645a <uartstart+0x7e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80006430:	01f7f713          	andi	a4,a5,31
    80006434:	9756                	add	a4,a4,s5
    80006436:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    8000643a:	0785                	addi	a5,a5,1
    8000643c:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    8000643e:	8526                	mv	a0,s1
    80006440:	f99fa0ef          	jal	800013d8 <wakeup>
    WriteReg(THR, c);
    80006444:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    80006448:	609c                	ld	a5,0(s1)
    8000644a:	0009b703          	ld	a4,0(s3)
    8000644e:	fcf71ce3          	bne	a4,a5,80006426 <uartstart+0x4a>
      ReadReg(ISR);
    80006452:	100007b7          	lui	a5,0x10000
    80006456:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    8000645a:	70e2                	ld	ra,56(sp)
    8000645c:	7442                	ld	s0,48(sp)
    8000645e:	74a2                	ld	s1,40(sp)
    80006460:	7902                	ld	s2,32(sp)
    80006462:	69e2                	ld	s3,24(sp)
    80006464:	6a42                	ld	s4,16(sp)
    80006466:	6aa2                	ld	s5,8(sp)
    80006468:	6b02                	ld	s6,0(sp)
    8000646a:	6121                	addi	sp,sp,64
    8000646c:	8082                	ret
      ReadReg(ISR);
    8000646e:	100007b7          	lui	a5,0x10000
    80006472:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    80006476:	8082                	ret

0000000080006478 <uartputc>:
{
    80006478:	7179                	addi	sp,sp,-48
    8000647a:	f406                	sd	ra,40(sp)
    8000647c:	f022                	sd	s0,32(sp)
    8000647e:	ec26                	sd	s1,24(sp)
    80006480:	e84a                	sd	s2,16(sp)
    80006482:	e44e                	sd	s3,8(sp)
    80006484:	e052                	sd	s4,0(sp)
    80006486:	1800                	addi	s0,sp,48
    80006488:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    8000648a:	00080517          	auipc	a0,0x80
    8000648e:	bfe50513          	addi	a0,a0,-1026 # 80086088 <uart_tx_lock>
    80006492:	184000ef          	jal	80006616 <acquire>
  if(panicked){
    80006496:	00002797          	auipc	a5,0x2
    8000649a:	59e7a783          	lw	a5,1438(a5) # 80008a34 <panicked>
    8000649e:	e3d1                	bnez	a5,80006522 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800064a0:	00002717          	auipc	a4,0x2
    800064a4:	5a073703          	ld	a4,1440(a4) # 80008a40 <uart_tx_w>
    800064a8:	00002797          	auipc	a5,0x2
    800064ac:	5907b783          	ld	a5,1424(a5) # 80008a38 <uart_tx_r>
    800064b0:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800064b4:	00080997          	auipc	s3,0x80
    800064b8:	bd498993          	addi	s3,s3,-1068 # 80086088 <uart_tx_lock>
    800064bc:	00002497          	auipc	s1,0x2
    800064c0:	57c48493          	addi	s1,s1,1404 # 80008a38 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800064c4:	00002917          	auipc	s2,0x2
    800064c8:	57c90913          	addi	s2,s2,1404 # 80008a40 <uart_tx_w>
    800064cc:	00e79d63          	bne	a5,a4,800064e6 <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800064d0:	85ce                	mv	a1,s3
    800064d2:	8526                	mv	a0,s1
    800064d4:	eb9fa0ef          	jal	8000138c <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800064d8:	00093703          	ld	a4,0(s2)
    800064dc:	609c                	ld	a5,0(s1)
    800064de:	02078793          	addi	a5,a5,32
    800064e2:	fee787e3          	beq	a5,a4,800064d0 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800064e6:	01f77693          	andi	a3,a4,31
    800064ea:	00080797          	auipc	a5,0x80
    800064ee:	b9e78793          	addi	a5,a5,-1122 # 80086088 <uart_tx_lock>
    800064f2:	97b6                	add	a5,a5,a3
    800064f4:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800064f8:	0705                	addi	a4,a4,1
    800064fa:	00002797          	auipc	a5,0x2
    800064fe:	54e7b323          	sd	a4,1350(a5) # 80008a40 <uart_tx_w>
  uartstart();
    80006502:	edbff0ef          	jal	800063dc <uartstart>
  release(&uart_tx_lock);
    80006506:	00080517          	auipc	a0,0x80
    8000650a:	b8250513          	addi	a0,a0,-1150 # 80086088 <uart_tx_lock>
    8000650e:	19c000ef          	jal	800066aa <release>
}
    80006512:	70a2                	ld	ra,40(sp)
    80006514:	7402                	ld	s0,32(sp)
    80006516:	64e2                	ld	s1,24(sp)
    80006518:	6942                	ld	s2,16(sp)
    8000651a:	69a2                	ld	s3,8(sp)
    8000651c:	6a02                	ld	s4,0(sp)
    8000651e:	6145                	addi	sp,sp,48
    80006520:	8082                	ret
    for(;;)
    80006522:	a001                	j	80006522 <uartputc+0xaa>

0000000080006524 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80006524:	1141                	addi	sp,sp,-16
    80006526:	e406                	sd	ra,8(sp)
    80006528:	e022                	sd	s0,0(sp)
    8000652a:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    8000652c:	100007b7          	lui	a5,0x10000
    80006530:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80006534:	8b85                	andi	a5,a5,1
    80006536:	cb89                	beqz	a5,80006548 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80006538:	100007b7          	lui	a5,0x10000
    8000653c:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80006540:	60a2                	ld	ra,8(sp)
    80006542:	6402                	ld	s0,0(sp)
    80006544:	0141                	addi	sp,sp,16
    80006546:	8082                	ret
    return -1;
    80006548:	557d                	li	a0,-1
    8000654a:	bfdd                	j	80006540 <uartgetc+0x1c>

000000008000654c <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000654c:	1101                	addi	sp,sp,-32
    8000654e:	ec06                	sd	ra,24(sp)
    80006550:	e822                	sd	s0,16(sp)
    80006552:	e426                	sd	s1,8(sp)
    80006554:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80006556:	54fd                	li	s1,-1
    int c = uartgetc();
    80006558:	fcdff0ef          	jal	80006524 <uartgetc>
    if(c == -1)
    8000655c:	00950563          	beq	a0,s1,80006566 <uartintr+0x1a>
      break;
    consoleintr(c);
    80006560:	81bff0ef          	jal	80005d7a <consoleintr>
  while(1){
    80006564:	bfd5                	j	80006558 <uartintr+0xc>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80006566:	00080517          	auipc	a0,0x80
    8000656a:	b2250513          	addi	a0,a0,-1246 # 80086088 <uart_tx_lock>
    8000656e:	0a8000ef          	jal	80006616 <acquire>
  uartstart();
    80006572:	e6bff0ef          	jal	800063dc <uartstart>
  release(&uart_tx_lock);
    80006576:	00080517          	auipc	a0,0x80
    8000657a:	b1250513          	addi	a0,a0,-1262 # 80086088 <uart_tx_lock>
    8000657e:	12c000ef          	jal	800066aa <release>
}
    80006582:	60e2                	ld	ra,24(sp)
    80006584:	6442                	ld	s0,16(sp)
    80006586:	64a2                	ld	s1,8(sp)
    80006588:	6105                	addi	sp,sp,32
    8000658a:	8082                	ret

000000008000658c <initlock>:
}
#endif

void
initlock(struct spinlock *lk, char *name)
{
    8000658c:	1141                	addi	sp,sp,-16
    8000658e:	e406                	sd	ra,8(sp)
    80006590:	e022                	sd	s0,0(sp)
    80006592:	0800                	addi	s0,sp,16
  lk->name = name;
    80006594:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80006596:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    8000659a:	00053823          	sd	zero,16(a0)
#ifdef LAB_LOCK
  lk->nts = 0;
  lk->n = 0;
  findslot(lk);
#endif  
}
    8000659e:	60a2                	ld	ra,8(sp)
    800065a0:	6402                	ld	s0,0(sp)
    800065a2:	0141                	addi	sp,sp,16
    800065a4:	8082                	ret

00000000800065a6 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    800065a6:	411c                	lw	a5,0(a0)
    800065a8:	e399                	bnez	a5,800065ae <holding+0x8>
    800065aa:	4501                	li	a0,0
  return r;
}
    800065ac:	8082                	ret
{
    800065ae:	1101                	addi	sp,sp,-32
    800065b0:	ec06                	sd	ra,24(sp)
    800065b2:	e822                	sd	s0,16(sp)
    800065b4:	e426                	sd	s1,8(sp)
    800065b6:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    800065b8:	691c                	ld	a5,16(a0)
    800065ba:	84be                	mv	s1,a5
    800065bc:	fdefa0ef          	jal	80000d9a <mycpu>
    800065c0:	40a48533          	sub	a0,s1,a0
    800065c4:	00153513          	seqz	a0,a0
}
    800065c8:	60e2                	ld	ra,24(sp)
    800065ca:	6442                	ld	s0,16(sp)
    800065cc:	64a2                	ld	s1,8(sp)
    800065ce:	6105                	addi	sp,sp,32
    800065d0:	8082                	ret

00000000800065d2 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    800065d2:	1101                	addi	sp,sp,-32
    800065d4:	ec06                	sd	ra,24(sp)
    800065d6:	e822                	sd	s0,16(sp)
    800065d8:	e426                	sd	s1,8(sp)
    800065da:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800065dc:	100027f3          	csrr	a5,sstatus
    800065e0:	84be                	mv	s1,a5
    800065e2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800065e6:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800065e8:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    800065ec:	faefa0ef          	jal	80000d9a <mycpu>
    800065f0:	5d3c                	lw	a5,120(a0)
    800065f2:	cb99                	beqz	a5,80006608 <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    800065f4:	fa6fa0ef          	jal	80000d9a <mycpu>
    800065f8:	5d3c                	lw	a5,120(a0)
    800065fa:	2785                	addiw	a5,a5,1
    800065fc:	dd3c                	sw	a5,120(a0)
}
    800065fe:	60e2                	ld	ra,24(sp)
    80006600:	6442                	ld	s0,16(sp)
    80006602:	64a2                	ld	s1,8(sp)
    80006604:	6105                	addi	sp,sp,32
    80006606:	8082                	ret
    mycpu()->intena = old;
    80006608:	f92fa0ef          	jal	80000d9a <mycpu>
  return (x & SSTATUS_SIE) != 0;
    8000660c:	0014d793          	srli	a5,s1,0x1
    80006610:	8b85                	andi	a5,a5,1
    80006612:	dd7c                	sw	a5,124(a0)
    80006614:	b7c5                	j	800065f4 <push_off+0x22>

0000000080006616 <acquire>:
{
    80006616:	1101                	addi	sp,sp,-32
    80006618:	ec06                	sd	ra,24(sp)
    8000661a:	e822                	sd	s0,16(sp)
    8000661c:	e426                	sd	s1,8(sp)
    8000661e:	1000                	addi	s0,sp,32
    80006620:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80006622:	fb1ff0ef          	jal	800065d2 <push_off>
  if(holding(lk))
    80006626:	8526                	mv	a0,s1
    80006628:	f7fff0ef          	jal	800065a6 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0) {
    8000662c:	4705                	li	a4,1
  if(holding(lk))
    8000662e:	e105                	bnez	a0,8000664e <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0) {
    80006630:	87ba                	mv	a5,a4
    80006632:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80006636:	2781                	sext.w	a5,a5
    80006638:	ffe5                	bnez	a5,80006630 <acquire+0x1a>
  __sync_synchronize();
    8000663a:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    8000663e:	f5cfa0ef          	jal	80000d9a <mycpu>
    80006642:	e888                	sd	a0,16(s1)
}
    80006644:	60e2                	ld	ra,24(sp)
    80006646:	6442                	ld	s0,16(sp)
    80006648:	64a2                	ld	s1,8(sp)
    8000664a:	6105                	addi	sp,sp,32
    8000664c:	8082                	ret
    panic("acquire");
    8000664e:	00002517          	auipc	a0,0x2
    80006652:	1ba50513          	addi	a0,a0,442 # 80008808 <etext+0x808>
    80006656:	c83ff0ef          	jal	800062d8 <panic>

000000008000665a <pop_off>:

void
pop_off(void)
{
    8000665a:	1141                	addi	sp,sp,-16
    8000665c:	e406                	sd	ra,8(sp)
    8000665e:	e022                	sd	s0,0(sp)
    80006660:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80006662:	f38fa0ef          	jal	80000d9a <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80006666:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000666a:	8b89                	andi	a5,a5,2
  if(intr_get())
    8000666c:	e39d                	bnez	a5,80006692 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    8000666e:	5d3c                	lw	a5,120(a0)
    80006670:	02f05763          	blez	a5,8000669e <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80006674:	37fd                	addiw	a5,a5,-1
    80006676:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80006678:	eb89                	bnez	a5,8000668a <pop_off+0x30>
    8000667a:	5d7c                	lw	a5,124(a0)
    8000667c:	c799                	beqz	a5,8000668a <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000667e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80006682:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80006686:	10079073          	csrw	sstatus,a5
    intr_on();
}
    8000668a:	60a2                	ld	ra,8(sp)
    8000668c:	6402                	ld	s0,0(sp)
    8000668e:	0141                	addi	sp,sp,16
    80006690:	8082                	ret
    panic("pop_off - interruptible");
    80006692:	00002517          	auipc	a0,0x2
    80006696:	17e50513          	addi	a0,a0,382 # 80008810 <etext+0x810>
    8000669a:	c3fff0ef          	jal	800062d8 <panic>
    panic("pop_off");
    8000669e:	00002517          	auipc	a0,0x2
    800066a2:	18a50513          	addi	a0,a0,394 # 80008828 <etext+0x828>
    800066a6:	c33ff0ef          	jal	800062d8 <panic>

00000000800066aa <release>:
{
    800066aa:	1101                	addi	sp,sp,-32
    800066ac:	ec06                	sd	ra,24(sp)
    800066ae:	e822                	sd	s0,16(sp)
    800066b0:	e426                	sd	s1,8(sp)
    800066b2:	1000                	addi	s0,sp,32
    800066b4:	84aa                	mv	s1,a0
  if(!holding(lk))
    800066b6:	ef1ff0ef          	jal	800065a6 <holding>
    800066ba:	c105                	beqz	a0,800066da <release+0x30>
  lk->cpu = 0;
    800066bc:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    800066c0:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    800066c4:	0310000f          	fence	rw,w
    800066c8:	0004a023          	sw	zero,0(s1)
  pop_off();
    800066cc:	f8fff0ef          	jal	8000665a <pop_off>
}
    800066d0:	60e2                	ld	ra,24(sp)
    800066d2:	6442                	ld	s0,16(sp)
    800066d4:	64a2                	ld	s1,8(sp)
    800066d6:	6105                	addi	sp,sp,32
    800066d8:	8082                	ret
    panic("release");
    800066da:	00002517          	auipc	a0,0x2
    800066de:	15650513          	addi	a0,a0,342 # 80008830 <etext+0x830>
    800066e2:	bf7ff0ef          	jal	800062d8 <panic>

00000000800066e6 <atomic_read4>:

// Read a shared 32-bit value without holding a lock
int
atomic_read4(int *addr) {
    800066e6:	1141                	addi	sp,sp,-16
    800066e8:	e406                	sd	ra,8(sp)
    800066ea:	e022                	sd	s0,0(sp)
    800066ec:	0800                	addi	s0,sp,16
  uint32 val;
  __atomic_load(addr, &val, __ATOMIC_SEQ_CST);
    800066ee:	0330000f          	fence	rw,rw
    800066f2:	4108                	lw	a0,0(a0)
    800066f4:	0230000f          	fence	r,rw
  return val;
}
    800066f8:	2501                	sext.w	a0,a0
    800066fa:	60a2                	ld	ra,8(sp)
    800066fc:	6402                	ld	s0,0(sp)
    800066fe:	0141                	addi	sp,sp,16
    80006700:	8082                	ret
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	8282                	jr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0)
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
