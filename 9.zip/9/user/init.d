user/init.o: user/init.c kernel/types.h kernel/stat.h kernel/spinlock.h \
 kernel/sleeplock.h kernel/fs.h kernel/file.h kernel/sleeplock.h \
 kernel/fs.h user/user.h kernel/fcntl.h
