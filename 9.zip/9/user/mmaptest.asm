
user/_mmaptest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <err>:
  exit(0);
}

void
err(char *why)
{
       0:	1101                	addi	sp,sp,-32
       2:	ec06                	sd	ra,24(sp)
       4:	e822                	sd	s0,16(sp)
       6:	e426                	sd	s1,8(sp)
       8:	1000                	addi	s0,sp,32
       a:	84aa                	mv	s1,a0
  printf("mmaptest failure: %s, pid=%d\n", why, getpid());
       c:	7e5000ef          	jal	ff0 <getpid>
      10:	862a                	mv	a2,a0
      12:	85a6                	mv	a1,s1
      14:	00001517          	auipc	a0,0x1
      18:	54c50513          	addi	a0,a0,1356 # 1560 <malloc+0xf8>
      1c:	394010ef          	jal	13b0 <printf>
  exit(1);
      20:	4505                	li	a0,1
      22:	74f000ef          	jal	f70 <exit>

0000000000000026 <_v1>:
//
// check the content of the two mapped pages.
//
void
_v1(char *p)
{
      26:	1141                	addi	sp,sp,-16
      28:	e406                	sd	ra,8(sp)
      2a:	e022                	sd	s0,0(sp)
      2c:	0800                	addi	s0,sp,16
  int i;
  for (i = 0; i < PGSIZE*2; i++) {
      2e:	4581                	li	a1,0
    if (i < PGSIZE + (PGSIZE/2)) {
      30:	6785                	lui	a5,0x1
      32:	7ff78793          	addi	a5,a5,2047 # 17ff <malloc+0x397>
  for (i = 0; i < PGSIZE*2; i++) {
      36:	6689                	lui	a3,0x2
      if (p[i] != 'A') {
      38:	04100713          	li	a4,65
      3c:	a025                	j	64 <_v1+0x3e>
        printf("mismatch at %d, wanted 'A', got 0x%x\n", i, p[i]);
      3e:	00001517          	auipc	a0,0x1
      42:	54a50513          	addi	a0,a0,1354 # 1588 <malloc+0x120>
      46:	36a010ef          	jal	13b0 <printf>
        err("v1 mismatch (1)");
      4a:	00001517          	auipc	a0,0x1
      4e:	56650513          	addi	a0,a0,1382 # 15b0 <malloc+0x148>
      52:	fafff0ef          	jal	0 <err>
      }
    } else {
      if (p[i] != 0) {
      56:	00054603          	lbu	a2,0(a0)
      5a:	ee11                	bnez	a2,76 <_v1+0x50>
  for (i = 0; i < PGSIZE*2; i++) {
      5c:	2585                	addiw	a1,a1,1
      5e:	02d58863          	beq	a1,a3,8e <_v1+0x68>
      62:	0505                	addi	a0,a0,1
    if (i < PGSIZE + (PGSIZE/2)) {
      64:	feb7c9e3          	blt	a5,a1,56 <_v1+0x30>
      if (p[i] != 'A') {
      68:	00054603          	lbu	a2,0(a0)
      6c:	fce619e3          	bne	a2,a4,3e <_v1+0x18>
  for (i = 0; i < PGSIZE*2; i++) {
      70:	2585                	addiw	a1,a1,1
      72:	0505                	addi	a0,a0,1
      74:	bfc5                	j	64 <_v1+0x3e>
        printf("mismatch at %d, wanted zero, got 0x%x\n", i, p[i]);
      76:	00001517          	auipc	a0,0x1
      7a:	54a50513          	addi	a0,a0,1354 # 15c0 <malloc+0x158>
      7e:	332010ef          	jal	13b0 <printf>
        err("v1 mismatch (2)");
      82:	00001517          	auipc	a0,0x1
      86:	56650513          	addi	a0,a0,1382 # 15e8 <malloc+0x180>
      8a:	f77ff0ef          	jal	0 <err>
      }
    }
  }
}
      8e:	60a2                	ld	ra,8(sp)
      90:	6402                	ld	s0,0(sp)
      92:	0141                	addi	sp,sp,16
      94:	8082                	ret

0000000000000096 <makefile>:
// create a file to be mapped, containing
// 1.5 pages of 'A' and half a page of zeros.
//
void
makefile(const char *f)
{
      96:	7179                	addi	sp,sp,-48
      98:	f406                	sd	ra,40(sp)
      9a:	f022                	sd	s0,32(sp)
      9c:	ec26                	sd	s1,24(sp)
      9e:	e84a                	sd	s2,16(sp)
      a0:	e44e                	sd	s3,8(sp)
      a2:	e052                	sd	s4,0(sp)
      a4:	1800                	addi	s0,sp,48
      a6:	84aa                	mv	s1,a0
  int i;
  int n = PGSIZE/BSIZE;

  unlink(f);
      a8:	719000ef          	jal	fc0 <unlink>
  int fd = open(f, O_WRONLY | O_CREATE);
      ac:	20100593          	li	a1,513
      b0:	8526                	mv	a0,s1
      b2:	6ff000ef          	jal	fb0 <open>
  if (fd == -1)
      b6:	57fd                	li	a5,-1
      b8:	04f50b63          	beq	a0,a5,10e <makefile+0x78>
      bc:	89aa                	mv	s3,a0
    err("open");
  memset(buf, 'A', BSIZE);
      be:	40000613          	li	a2,1024
      c2:	04100593          	li	a1,65
      c6:	00002517          	auipc	a0,0x2
      ca:	f4a50513          	addi	a0,a0,-182 # 2010 <buf>
      ce:	4a5000ef          	jal	d72 <memset>
      d2:	4499                	li	s1,6
  // write 1.5 page
  for (i = 0; i < n + n/2; i++) {
    if (write(fd, buf, BSIZE) != BSIZE)
      d4:	40000913          	li	s2,1024
      d8:	00002a17          	auipc	s4,0x2
      dc:	f38a0a13          	addi	s4,s4,-200 # 2010 <buf>
      e0:	864a                	mv	a2,s2
      e2:	85d2                	mv	a1,s4
      e4:	854e                	mv	a0,s3
      e6:	6ab000ef          	jal	f90 <write>
      ea:	03251863          	bne	a0,s2,11a <makefile+0x84>
  for (i = 0; i < n + n/2; i++) {
      ee:	34fd                	addiw	s1,s1,-1
      f0:	f8e5                	bnez	s1,e0 <makefile+0x4a>
      err("write 0 makefile");
  }
  if (close(fd) == -1)
      f2:	854e                	mv	a0,s3
      f4:	6a5000ef          	jal	f98 <close>
      f8:	57fd                	li	a5,-1
      fa:	02f50663          	beq	a0,a5,126 <makefile+0x90>
    err("close");
}
      fe:	70a2                	ld	ra,40(sp)
     100:	7402                	ld	s0,32(sp)
     102:	64e2                	ld	s1,24(sp)
     104:	6942                	ld	s2,16(sp)
     106:	69a2                	ld	s3,8(sp)
     108:	6a02                	ld	s4,0(sp)
     10a:	6145                	addi	sp,sp,48
     10c:	8082                	ret
    err("open");
     10e:	00001517          	auipc	a0,0x1
     112:	4ea50513          	addi	a0,a0,1258 # 15f8 <malloc+0x190>
     116:	eebff0ef          	jal	0 <err>
      err("write 0 makefile");
     11a:	00001517          	auipc	a0,0x1
     11e:	4e650513          	addi	a0,a0,1254 # 1600 <malloc+0x198>
     122:	edfff0ef          	jal	0 <err>
    err("close");
     126:	00001517          	auipc	a0,0x1
     12a:	4f250513          	addi	a0,a0,1266 # 1618 <malloc+0x1b0>
     12e:	ed3ff0ef          	jal	0 <err>

0000000000000132 <mmap_test>:

void
mmap_test(void)
{
     132:	7179                	addi	sp,sp,-48
     134:	f406                	sd	ra,40(sp)
     136:	f022                	sd	s0,32(sp)
     138:	ec26                	sd	s1,24(sp)
     13a:	e84a                	sd	s2,16(sp)
     13c:	e44e                	sd	s3,8(sp)
     13e:	1800                	addi	s0,sp,48
  //
  // create a file with known content, map it into memory, check that
  // the mapped memory has the same bytes as originally written to the
  // file.
  //
  makefile(f);
     140:	00001517          	auipc	a0,0x1
     144:	4e050513          	addi	a0,a0,1248 # 1620 <malloc+0x1b8>
     148:	f4fff0ef          	jal	96 <makefile>
  if ((fd = open(f, O_RDONLY)) == -1)
     14c:	4581                	li	a1,0
     14e:	00001517          	auipc	a0,0x1
     152:	4d250513          	addi	a0,a0,1234 # 1620 <malloc+0x1b8>
     156:	65b000ef          	jal	fb0 <open>
     15a:	57fd                	li	a5,-1
     15c:	4af50763          	beq	a0,a5,60a <mmap_test+0x4d8>
     160:	84aa                	mv	s1,a0
    err("open (1)");

  printf("test basic mmap\n");
     162:	00001517          	auipc	a0,0x1
     166:	4de50513          	addi	a0,a0,1246 # 1640 <malloc+0x1d8>
     16a:	246010ef          	jal	13b0 <printf>
  // same file (of course in this case updates are prohibited
  // due to PROT_READ). the fifth argument is the file descriptor
  // of the file to be mapped. the last argument is the starting
  // offset in the file.
  //
  char *p = mmap(0, PGSIZE*2, PROT_READ, MAP_PRIVATE, fd, 0);
     16e:	4781                	li	a5,0
     170:	8726                	mv	a4,s1
     172:	4689                	li	a3,2
     174:	4605                	li	a2,1
     176:	6589                	lui	a1,0x2
     178:	4501                	li	a0,0
     17a:	697000ef          	jal	1010 <mmap>
     17e:	892a                	mv	s2,a0
  if (p == MAP_FAILED)
     180:	57fd                	li	a5,-1
     182:	48f50a63          	beq	a0,a5,616 <mmap_test+0x4e4>
    err("mmap (1)");
  _v1(p);
     186:	ea1ff0ef          	jal	26 <_v1>
  if (munmap(p, PGSIZE*2) == -1)
     18a:	6589                	lui	a1,0x2
     18c:	854a                	mv	a0,s2
     18e:	68b000ef          	jal	1018 <munmap>
     192:	57fd                	li	a5,-1
     194:	48f50763          	beq	a0,a5,622 <mmap_test+0x4f0>
    err("munmap (1)");

  printf("test basic mmap: OK\n");
     198:	00001517          	auipc	a0,0x1
     19c:	4e050513          	addi	a0,a0,1248 # 1678 <malloc+0x210>
     1a0:	210010ef          	jal	13b0 <printf>

  printf("test mmap private\n");
     1a4:	00001517          	auipc	a0,0x1
     1a8:	4ec50513          	addi	a0,a0,1260 # 1690 <malloc+0x228>
     1ac:	204010ef          	jal	13b0 <printf>
  // should be able to map file opened read-only with private writable
  // mapping
  p = mmap(0, PGSIZE*2, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
     1b0:	4781                	li	a5,0
     1b2:	8726                	mv	a4,s1
     1b4:	4689                	li	a3,2
     1b6:	460d                	li	a2,3
     1b8:	6589                	lui	a1,0x2
     1ba:	4501                	li	a0,0
     1bc:	655000ef          	jal	1010 <mmap>
     1c0:	892a                	mv	s2,a0
  if (p == MAP_FAILED)
     1c2:	57fd                	li	a5,-1
     1c4:	46f50563          	beq	a0,a5,62e <mmap_test+0x4fc>
    err("mmap (2)");
  if (close(fd) == -1)
     1c8:	8526                	mv	a0,s1
     1ca:	5cf000ef          	jal	f98 <close>
     1ce:	57fd                	li	a5,-1
     1d0:	46f50563          	beq	a0,a5,63a <mmap_test+0x508>
    err("close (1)");
  _v1(p);
     1d4:	854a                	mv	a0,s2
     1d6:	e51ff0ef          	jal	26 <_v1>
  for (i = 0; i < PGSIZE*2; i++)
     1da:	87ca                	mv	a5,s2
     1dc:	6709                	lui	a4,0x2
     1de:	974a                	add	a4,a4,s2
    p[i] = 'Z';
     1e0:	05a00693          	li	a3,90
     1e4:	00d78023          	sb	a3,0(a5)
  for (i = 0; i < PGSIZE*2; i++)
     1e8:	0785                	addi	a5,a5,1
     1ea:	fef71de3          	bne	a4,a5,1e4 <mmap_test+0xb2>
  if (munmap(p, PGSIZE*2) == -1)
     1ee:	6589                	lui	a1,0x2
     1f0:	854a                	mv	a0,s2
     1f2:	627000ef          	jal	1018 <munmap>
     1f6:	57fd                	li	a5,-1
     1f8:	44f50763          	beq	a0,a5,646 <mmap_test+0x514>
    err("munmap (2)");
  close(fd);
     1fc:	8526                	mv	a0,s1
     1fe:	59b000ef          	jal	f98 <close>

  // file should not have been modified.
  if((fd = open(f, O_RDONLY)) < 0) err("open");
     202:	4581                	li	a1,0
     204:	00001517          	auipc	a0,0x1
     208:	41c50513          	addi	a0,a0,1052 # 1620 <malloc+0x1b8>
     20c:	5a5000ef          	jal	fb0 <open>
     210:	84aa                	mv	s1,a0
     212:	44054063          	bltz	a0,652 <mmap_test+0x520>
  if(read(fd, buf, PGSIZE) != PGSIZE) err("read");
     216:	6605                	lui	a2,0x1
     218:	00002597          	auipc	a1,0x2
     21c:	df858593          	addi	a1,a1,-520 # 2010 <buf>
     220:	569000ef          	jal	f88 <read>
     224:	6785                	lui	a5,0x1
     226:	42f51c63          	bne	a0,a5,65e <mmap_test+0x52c>
  if(buf[0] != 'A')
     22a:	00002717          	auipc	a4,0x2
     22e:	de674703          	lbu	a4,-538(a4) # 2010 <buf>
     232:	04100793          	li	a5,65
     236:	42f71a63          	bne	a4,a5,66a <mmap_test+0x538>
    err("write to MAP_PRIVATE was written to file");
  if(read(fd, buf, PGSIZE) != PGSIZE/2) err("read");
     23a:	6605                	lui	a2,0x1
     23c:	00002597          	auipc	a1,0x2
     240:	dd458593          	addi	a1,a1,-556 # 2010 <buf>
     244:	8526                	mv	a0,s1
     246:	543000ef          	jal	f88 <read>
     24a:	8005079b          	addiw	a5,a0,-2048
     24e:	42079463          	bnez	a5,676 <mmap_test+0x544>
  if(buf[0] != 'A')
     252:	00002717          	auipc	a4,0x2
     256:	dbe74703          	lbu	a4,-578(a4) # 2010 <buf>
     25a:	04100793          	li	a5,65
     25e:	42f71263          	bne	a4,a5,682 <mmap_test+0x550>
    err("write to MAP_PRIVATE was written to file");
  close(fd);
     262:	8526                	mv	a0,s1
     264:	535000ef          	jal	f98 <close>

  printf("test mmap private: OK\n");
     268:	00001517          	auipc	a0,0x1
     26c:	4a850513          	addi	a0,a0,1192 # 1710 <malloc+0x2a8>
     270:	140010ef          	jal	13b0 <printf>

  printf("test mmap read-only\n");
     274:	00001517          	auipc	a0,0x1
     278:	4b450513          	addi	a0,a0,1204 # 1728 <malloc+0x2c0>
     27c:	134010ef          	jal	13b0 <printf>

  // check that mmap doesn't allow read/write mapping of a
  // file opened read-only.
  if ((fd = open(f, O_RDONLY)) == -1)
     280:	4581                	li	a1,0
     282:	00001517          	auipc	a0,0x1
     286:	39e50513          	addi	a0,a0,926 # 1620 <malloc+0x1b8>
     28a:	527000ef          	jal	fb0 <open>
     28e:	84aa                	mv	s1,a0
     290:	57fd                	li	a5,-1
     292:	3ef50e63          	beq	a0,a5,68e <mmap_test+0x55c>
    err("open (2)");
  p = mmap(0, PGSIZE*2, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
     296:	4781                	li	a5,0
     298:	872a                	mv	a4,a0
     29a:	4685                	li	a3,1
     29c:	460d                	li	a2,3
     29e:	6589                	lui	a1,0x2
     2a0:	4501                	li	a0,0
     2a2:	56f000ef          	jal	1010 <mmap>
  if (p != MAP_FAILED)
     2a6:	57fd                	li	a5,-1
     2a8:	3ef51963          	bne	a0,a5,69a <mmap_test+0x568>
    err("mmap (3)");
  if (close(fd) == -1)
     2ac:	8526                	mv	a0,s1
     2ae:	4eb000ef          	jal	f98 <close>
     2b2:	57fd                	li	a5,-1
     2b4:	3ef50963          	beq	a0,a5,6a6 <mmap_test+0x574>
    err("close (2)");

  printf("test mmap read-only: OK\n");
     2b8:	00001517          	auipc	a0,0x1
     2bc:	4b850513          	addi	a0,a0,1208 # 1770 <malloc+0x308>
     2c0:	0f0010ef          	jal	13b0 <printf>

  printf("test mmap read/write\n");
     2c4:	00001517          	auipc	a0,0x1
     2c8:	4cc50513          	addi	a0,a0,1228 # 1790 <malloc+0x328>
     2cc:	0e4010ef          	jal	13b0 <printf>

  // check that mmap does allow read/write mapping of a
  // file opened read/write.
  if ((fd = open(f, O_RDWR)) == -1)
     2d0:	4589                	li	a1,2
     2d2:	00001517          	auipc	a0,0x1
     2d6:	34e50513          	addi	a0,a0,846 # 1620 <malloc+0x1b8>
     2da:	4d7000ef          	jal	fb0 <open>
     2de:	84aa                	mv	s1,a0
     2e0:	57fd                	li	a5,-1
     2e2:	3cf50863          	beq	a0,a5,6b2 <mmap_test+0x580>
    err("open (3)");
  p = mmap(0, PGSIZE*3, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
     2e6:	4781                	li	a5,0
     2e8:	872a                	mv	a4,a0
     2ea:	4685                	li	a3,1
     2ec:	460d                	li	a2,3
     2ee:	658d                	lui	a1,0x3
     2f0:	4501                	li	a0,0
     2f2:	51f000ef          	jal	1010 <mmap>
     2f6:	892a                	mv	s2,a0
  if (p == MAP_FAILED)
     2f8:	57fd                	li	a5,-1
     2fa:	3cf50263          	beq	a0,a5,6be <mmap_test+0x58c>
    err("mmap (4)");
  if (close(fd) == -1)
     2fe:	8526                	mv	a0,s1
     300:	499000ef          	jal	f98 <close>
     304:	57fd                	li	a5,-1
     306:	3cf50263          	beq	a0,a5,6ca <mmap_test+0x598>
    err("close (3)");

  // check that the mapping still works after close(fd).
  _v1(p);
     30a:	854a                	mv	a0,s2
     30c:	d1bff0ef          	jal	26 <_v1>

  // write the mapped memory.
  for (i = 0; i < PGSIZE; i++)
     310:	6785                	lui	a5,0x1
     312:	97ca                	add	a5,a5,s2
  _v1(p);
     314:	874a                	mv	a4,s2
    p[i] = 'B';
     316:	04200693          	li	a3,66
     31a:	00d70023          	sb	a3,0(a4)
  for (i = 0; i < PGSIZE; i++)
     31e:	0705                	addi	a4,a4,1
     320:	fee79de3          	bne	a5,a4,31a <mmap_test+0x1e8>
     324:	6709                	lui	a4,0x2
     326:	974a                	add	a4,a4,s2
  for (i = PGSIZE; i < PGSIZE*2; i++)
    p[i] = 'C';
     328:	04300693          	li	a3,67
     32c:	00d78023          	sb	a3,0(a5) # 1000 <sleep>
  for (i = PGSIZE; i < PGSIZE*2; i++)
     330:	0785                	addi	a5,a5,1
     332:	fef71de3          	bne	a4,a5,32c <mmap_test+0x1fa>

  // unmap just the first two of three pages of mapped memory.
  if (munmap(p, PGSIZE*2) == -1)
     336:	6589                	lui	a1,0x2
     338:	854a                	mv	a0,s2
     33a:	4df000ef          	jal	1018 <munmap>
     33e:	57fd                	li	a5,-1
     340:	38f50b63          	beq	a0,a5,6d6 <mmap_test+0x5a4>
    err("munmap (3)");

  printf("test mmap read/write: OK\n");
     344:	00001517          	auipc	a0,0x1
     348:	4a450513          	addi	a0,a0,1188 # 17e8 <malloc+0x380>
     34c:	064010ef          	jal	13b0 <printf>

  printf("test mmap dirty\n");
     350:	00001517          	auipc	a0,0x1
     354:	4b850513          	addi	a0,a0,1208 # 1808 <malloc+0x3a0>
     358:	058010ef          	jal	13b0 <printf>

  // check that the writes to the mapped memory were
  // written to the file.
  if ((fd = open(f, O_RDONLY)) == -1)
     35c:	4581                	li	a1,0
     35e:	00001517          	auipc	a0,0x1
     362:	2c250513          	addi	a0,a0,706 # 1620 <malloc+0x1b8>
     366:	44b000ef          	jal	fb0 <open>
     36a:	89aa                	mv	s3,a0
     36c:	57fd                	li	a5,-1
     36e:	36f50a63          	beq	a0,a5,6e2 <mmap_test+0x5b0>
    err("open (4)");
  if(read(fd, buf, PGSIZE) != PGSIZE)
     372:	6605                	lui	a2,0x1
     374:	00002597          	auipc	a1,0x2
     378:	c9c58593          	addi	a1,a1,-868 # 2010 <buf>
     37c:	40d000ef          	jal	f88 <read>
     380:	6785                	lui	a5,0x1
     382:	36f51663          	bne	a0,a5,6ee <mmap_test+0x5bc>
     386:	00002497          	auipc	s1,0x2
     38a:	c8a48493          	addi	s1,s1,-886 # 2010 <buf>
     38e:	00003617          	auipc	a2,0x3
     392:	c8260613          	addi	a2,a2,-894 # 3010 <base>
     396:	87a6                	mv	a5,s1
    err("dirty read #1");
  for (i = 0; i < PGSIZE; i++){
    if (buf[i] != 'B')
     398:	04200693          	li	a3,66
     39c:	0007c703          	lbu	a4,0(a5) # 1000 <sleep>
     3a0:	34d71d63          	bne	a4,a3,6fa <mmap_test+0x5c8>
  for (i = 0; i < PGSIZE; i++){
     3a4:	0785                	addi	a5,a5,1
     3a6:	fec79be3          	bne	a5,a2,39c <mmap_test+0x26a>
      err("file page 0 does not contain modifications");
  }
  if(read(fd, buf, PGSIZE) != PGSIZE/2)
     3aa:	6605                	lui	a2,0x1
     3ac:	00002597          	auipc	a1,0x2
     3b0:	c6458593          	addi	a1,a1,-924 # 2010 <buf>
     3b4:	854e                	mv	a0,s3
     3b6:	3d3000ef          	jal	f88 <read>
     3ba:	8005079b          	addiw	a5,a0,-2048
     3be:	34079463          	bnez	a5,706 <mmap_test+0x5d4>
     3c2:	7ff48713          	addi	a4,s1,2047
     3c6:	0705                	addi	a4,a4,1 # 2001 <freep+0x1>
    err("dirty read #2");
  for (i = 0; i < PGSIZE/2; i++){
    if (buf[i] != 'C')
     3c8:	04300693          	li	a3,67
     3cc:	0004c783          	lbu	a5,0(s1)
     3d0:	34d79163          	bne	a5,a3,712 <mmap_test+0x5e0>
  for (i = 0; i < PGSIZE/2; i++){
     3d4:	0485                	addi	s1,s1,1
     3d6:	fee49be3          	bne	s1,a4,3cc <mmap_test+0x29a>
      err("file page 1 does not contain modifications");
  }
  if (close(fd) == -1)
     3da:	854e                	mv	a0,s3
     3dc:	3bd000ef          	jal	f98 <close>
     3e0:	57fd                	li	a5,-1
     3e2:	32f50e63          	beq	a0,a5,71e <mmap_test+0x5ec>
    err("close (4)");

  printf("test mmap dirty: OK\n");
     3e6:	00001517          	auipc	a0,0x1
     3ea:	4da50513          	addi	a0,a0,1242 # 18c0 <malloc+0x458>
     3ee:	7c3000ef          	jal	13b0 <printf>

  printf("test not-mapped unmap\n");
     3f2:	00001517          	auipc	a0,0x1
     3f6:	4e650513          	addi	a0,a0,1254 # 18d8 <malloc+0x470>
     3fa:	7b7000ef          	jal	13b0 <printf>

  // unmap the rest of the mapped memory.
  if (munmap(p+PGSIZE*2, PGSIZE) == -1)
     3fe:	6585                	lui	a1,0x1
     400:	6509                	lui	a0,0x2
     402:	954a                	add	a0,a0,s2
     404:	415000ef          	jal	1018 <munmap>
     408:	57fd                	li	a5,-1
     40a:	32f50063          	beq	a0,a5,72a <mmap_test+0x5f8>
    err("munmap (4)");

  printf("test not-mapped unmap: OK\n");
     40e:	00001517          	auipc	a0,0x1
     412:	4f250513          	addi	a0,a0,1266 # 1900 <malloc+0x498>
     416:	79b000ef          	jal	13b0 <printf>

  printf("test lazy access\n");
     41a:	00001517          	auipc	a0,0x1
     41e:	50650513          	addi	a0,a0,1286 # 1920 <malloc+0x4b8>
     422:	78f000ef          	jal	13b0 <printf>

  if(unlink(f) != 0) err("unlink");
     426:	00001517          	auipc	a0,0x1
     42a:	1fa50513          	addi	a0,a0,506 # 1620 <malloc+0x1b8>
     42e:	393000ef          	jal	fc0 <unlink>
     432:	30051263          	bnez	a0,736 <mmap_test+0x604>
  makefile(f);
     436:	00001517          	auipc	a0,0x1
     43a:	1ea50513          	addi	a0,a0,490 # 1620 <malloc+0x1b8>
     43e:	c59ff0ef          	jal	96 <makefile>

  if ((fd = open(f, O_RDWR)) == -1)
     442:	4589                	li	a1,2
     444:	00001517          	auipc	a0,0x1
     448:	1dc50513          	addi	a0,a0,476 # 1620 <malloc+0x1b8>
     44c:	365000ef          	jal	fb0 <open>
     450:	892a                	mv	s2,a0
     452:	57fd                	li	a5,-1
     454:	2ef50763          	beq	a0,a5,742 <mmap_test+0x610>
    err("open");
  p = mmap(0, PGSIZE*2, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
     458:	4781                	li	a5,0
     45a:	872a                	mv	a4,a0
     45c:	4685                	li	a3,1
     45e:	460d                	li	a2,3
     460:	6589                	lui	a1,0x2
     462:	4501                	li	a0,0
     464:	3ad000ef          	jal	1010 <mmap>
     468:	84aa                	mv	s1,a0
  if (p == MAP_FAILED)
     46a:	57fd                	li	a5,-1
     46c:	2ef50163          	beq	a0,a5,74e <mmap_test+0x61c>
    err("mmap");
  close(fd);
     470:	854a                	mv	a0,s2
     472:	327000ef          	jal	f98 <close>
  // mmap() should not have read the file at this point,
  // so that the file modification we're about to make
  // ought to be visible to a subsequent read of the
  // mapped memory.

  if((fd = open(f, O_RDWR)) == -1)
     476:	4589                	li	a1,2
     478:	00001517          	auipc	a0,0x1
     47c:	1a850513          	addi	a0,a0,424 # 1620 <malloc+0x1b8>
     480:	331000ef          	jal	fb0 <open>
     484:	892a                	mv	s2,a0
     486:	57fd                	li	a5,-1
     488:	2cf50963          	beq	a0,a5,75a <mmap_test+0x628>
    err("open");
  if(write(fd, "m", 1) != 1)
     48c:	4605                	li	a2,1
     48e:	00001597          	auipc	a1,0x1
     492:	4ba58593          	addi	a1,a1,1210 # 1948 <malloc+0x4e0>
     496:	2fb000ef          	jal	f90 <write>
     49a:	4785                	li	a5,1
     49c:	2cf51563          	bne	a0,a5,766 <mmap_test+0x634>
    err("write");
  close(fd);
     4a0:	854a                	mv	a0,s2
     4a2:	2f7000ef          	jal	f98 <close>

  if(*p != 'm')
     4a6:	0004c703          	lbu	a4,0(s1)
     4aa:	06d00793          	li	a5,109
     4ae:	2cf71263          	bne	a4,a5,772 <mmap_test+0x640>
    err("read was not lazy");

  if(munmap(p, PGSIZE*2) == -1)
     4b2:	6589                	lui	a1,0x2
     4b4:	8526                	mv	a0,s1
     4b6:	363000ef          	jal	1018 <munmap>
     4ba:	57fd                	li	a5,-1
     4bc:	2cf50163          	beq	a0,a5,77e <mmap_test+0x64c>
    err("munmap");

  printf("test lazy access: OK\n");
     4c0:	00001517          	auipc	a0,0x1
     4c4:	4b850513          	addi	a0,a0,1208 # 1978 <malloc+0x510>
     4c8:	6e9000ef          	jal	13b0 <printf>

  printf("test mmap two files\n");
     4cc:	00001517          	auipc	a0,0x1
     4d0:	4c450513          	addi	a0,a0,1220 # 1990 <malloc+0x528>
     4d4:	6dd000ef          	jal	13b0 <printf>

  //
  // mmap two different files at the same time.
  //
  int fd1;
  if((fd1 = open("mmap1", O_RDWR|O_CREATE)) < 0)
     4d8:	20200593          	li	a1,514
     4dc:	00001517          	auipc	a0,0x1
     4e0:	4cc50513          	addi	a0,a0,1228 # 19a8 <malloc+0x540>
     4e4:	2cd000ef          	jal	fb0 <open>
     4e8:	84aa                	mv	s1,a0
     4ea:	2a054063          	bltz	a0,78a <mmap_test+0x658>
    err("open (5)");
  if(write(fd1, "12345", 5) != 5)
     4ee:	4615                	li	a2,5
     4f0:	00001597          	auipc	a1,0x1
     4f4:	4d058593          	addi	a1,a1,1232 # 19c0 <malloc+0x558>
     4f8:	299000ef          	jal	f90 <write>
     4fc:	4795                	li	a5,5
     4fe:	28f51c63          	bne	a0,a5,796 <mmap_test+0x664>
    err("write (1)");
  char *p1 = mmap(0, PGSIZE, PROT_READ, MAP_PRIVATE, fd1, 0);
     502:	4781                	li	a5,0
     504:	8726                	mv	a4,s1
     506:	4689                	li	a3,2
     508:	4605                	li	a2,1
     50a:	6585                	lui	a1,0x1
     50c:	4501                	li	a0,0
     50e:	303000ef          	jal	1010 <mmap>
     512:	89aa                	mv	s3,a0
  if(p1 == MAP_FAILED)
     514:	57fd                	li	a5,-1
     516:	28f50663          	beq	a0,a5,7a2 <mmap_test+0x670>
    err("mmap (5)");
  if (close(fd1) == -1)
     51a:	8526                	mv	a0,s1
     51c:	27d000ef          	jal	f98 <close>
     520:	57fd                	li	a5,-1
     522:	28f50663          	beq	a0,a5,7ae <mmap_test+0x67c>
    err("close (5)");
  if (unlink("mmap1") == -1)
     526:	00001517          	auipc	a0,0x1
     52a:	48250513          	addi	a0,a0,1154 # 19a8 <malloc+0x540>
     52e:	293000ef          	jal	fc0 <unlink>
     532:	57fd                	li	a5,-1
     534:	28f50363          	beq	a0,a5,7ba <mmap_test+0x688>
    err("unlink (1)");

  int fd2;
  if((fd2 = open("mmap2", O_RDWR|O_CREATE)) < 0)
     538:	20200593          	li	a1,514
     53c:	00001517          	auipc	a0,0x1
     540:	4cc50513          	addi	a0,a0,1228 # 1a08 <malloc+0x5a0>
     544:	26d000ef          	jal	fb0 <open>
     548:	892a                	mv	s2,a0
     54a:	26054e63          	bltz	a0,7c6 <mmap_test+0x694>
    err("open (6)");
  if(write(fd2, "67890", 5) != 5)
     54e:	4615                	li	a2,5
     550:	00001597          	auipc	a1,0x1
     554:	4d058593          	addi	a1,a1,1232 # 1a20 <malloc+0x5b8>
     558:	239000ef          	jal	f90 <write>
     55c:	4795                	li	a5,5
     55e:	26f51a63          	bne	a0,a5,7d2 <mmap_test+0x6a0>
    err("write (2)");
  char *p2 = mmap(0, PGSIZE, PROT_READ, MAP_PRIVATE, fd2, 0);
     562:	4781                	li	a5,0
     564:	874a                	mv	a4,s2
     566:	4689                	li	a3,2
     568:	4605                	li	a2,1
     56a:	6585                	lui	a1,0x1
     56c:	4501                	li	a0,0
     56e:	2a3000ef          	jal	1010 <mmap>
     572:	84aa                	mv	s1,a0
  if(p2 == MAP_FAILED)
     574:	57fd                	li	a5,-1
     576:	26f50463          	beq	a0,a5,7de <mmap_test+0x6ac>
    err("mmap (6)");
  if (close(fd2) == -1)
     57a:	854a                	mv	a0,s2
     57c:	21d000ef          	jal	f98 <close>
     580:	57fd                	li	a5,-1
     582:	26f50463          	beq	a0,a5,7ea <mmap_test+0x6b8>
    err("close (6)");
  if (unlink("mmap2") == -1)
     586:	00001517          	auipc	a0,0x1
     58a:	48250513          	addi	a0,a0,1154 # 1a08 <malloc+0x5a0>
     58e:	233000ef          	jal	fc0 <unlink>
     592:	57fd                	li	a5,-1
     594:	26f50163          	beq	a0,a5,7f6 <mmap_test+0x6c4>
    err("unlink (2)");

  if(memcmp(p1, "12345", 5) != 0)
     598:	4615                	li	a2,5
     59a:	00001597          	auipc	a1,0x1
     59e:	42658593          	addi	a1,a1,1062 # 19c0 <malloc+0x558>
     5a2:	854e                	mv	a0,s3
     5a4:	177000ef          	jal	f1a <memcmp>
     5a8:	24051d63          	bnez	a0,802 <mmap_test+0x6d0>
    err("mmap1 mismatch");
  if(memcmp(p2, "67890", 5) != 0)
     5ac:	4615                	li	a2,5
     5ae:	00001597          	auipc	a1,0x1
     5b2:	47258593          	addi	a1,a1,1138 # 1a20 <malloc+0x5b8>
     5b6:	8526                	mv	a0,s1
     5b8:	163000ef          	jal	f1a <memcmp>
     5bc:	24051963          	bnez	a0,80e <mmap_test+0x6dc>
    err("mmap2 mismatch");

  if (munmap(p1, PGSIZE) == -1)
     5c0:	6585                	lui	a1,0x1
     5c2:	854e                	mv	a0,s3
     5c4:	255000ef          	jal	1018 <munmap>
     5c8:	57fd                	li	a5,-1
     5ca:	24f50863          	beq	a0,a5,81a <mmap_test+0x6e8>
    err("munmap (5)");
  if(memcmp(p2, "67890", 5) != 0)
     5ce:	4615                	li	a2,5
     5d0:	00001597          	auipc	a1,0x1
     5d4:	45058593          	addi	a1,a1,1104 # 1a20 <malloc+0x5b8>
     5d8:	8526                	mv	a0,s1
     5da:	141000ef          	jal	f1a <memcmp>
     5de:	24051463          	bnez	a0,826 <mmap_test+0x6f4>
    err("mmap2 mismatch (2)");
  if (munmap(p2, PGSIZE) == -1)
     5e2:	6585                	lui	a1,0x1
     5e4:	8526                	mv	a0,s1
     5e6:	233000ef          	jal	1018 <munmap>
     5ea:	57fd                	li	a5,-1
     5ec:	24f50363          	beq	a0,a5,832 <mmap_test+0x700>
    err("munmap (6)");

  printf("test mmap two files: OK\n");
     5f0:	00001517          	auipc	a0,0x1
     5f4:	4d050513          	addi	a0,a0,1232 # 1ac0 <malloc+0x658>
     5f8:	5b9000ef          	jal	13b0 <printf>
}
     5fc:	70a2                	ld	ra,40(sp)
     5fe:	7402                	ld	s0,32(sp)
     600:	64e2                	ld	s1,24(sp)
     602:	6942                	ld	s2,16(sp)
     604:	69a2                	ld	s3,8(sp)
     606:	6145                	addi	sp,sp,48
     608:	8082                	ret
    err("open (1)");
     60a:	00001517          	auipc	a0,0x1
     60e:	02650513          	addi	a0,a0,38 # 1630 <malloc+0x1c8>
     612:	9efff0ef          	jal	0 <err>
    err("mmap (1)");
     616:	00001517          	auipc	a0,0x1
     61a:	04250513          	addi	a0,a0,66 # 1658 <malloc+0x1f0>
     61e:	9e3ff0ef          	jal	0 <err>
    err("munmap (1)");
     622:	00001517          	auipc	a0,0x1
     626:	04650513          	addi	a0,a0,70 # 1668 <malloc+0x200>
     62a:	9d7ff0ef          	jal	0 <err>
    err("mmap (2)");
     62e:	00001517          	auipc	a0,0x1
     632:	07a50513          	addi	a0,a0,122 # 16a8 <malloc+0x240>
     636:	9cbff0ef          	jal	0 <err>
    err("close (1)");
     63a:	00001517          	auipc	a0,0x1
     63e:	07e50513          	addi	a0,a0,126 # 16b8 <malloc+0x250>
     642:	9bfff0ef          	jal	0 <err>
    err("munmap (2)");
     646:	00001517          	auipc	a0,0x1
     64a:	08250513          	addi	a0,a0,130 # 16c8 <malloc+0x260>
     64e:	9b3ff0ef          	jal	0 <err>
  if((fd = open(f, O_RDONLY)) < 0) err("open");
     652:	00001517          	auipc	a0,0x1
     656:	fa650513          	addi	a0,a0,-90 # 15f8 <malloc+0x190>
     65a:	9a7ff0ef          	jal	0 <err>
  if(read(fd, buf, PGSIZE) != PGSIZE) err("read");
     65e:	00001517          	auipc	a0,0x1
     662:	07a50513          	addi	a0,a0,122 # 16d8 <malloc+0x270>
     666:	99bff0ef          	jal	0 <err>
    err("write to MAP_PRIVATE was written to file");
     66a:	00001517          	auipc	a0,0x1
     66e:	07650513          	addi	a0,a0,118 # 16e0 <malloc+0x278>
     672:	98fff0ef          	jal	0 <err>
  if(read(fd, buf, PGSIZE) != PGSIZE/2) err("read");
     676:	00001517          	auipc	a0,0x1
     67a:	06250513          	addi	a0,a0,98 # 16d8 <malloc+0x270>
     67e:	983ff0ef          	jal	0 <err>
    err("write to MAP_PRIVATE was written to file");
     682:	00001517          	auipc	a0,0x1
     686:	05e50513          	addi	a0,a0,94 # 16e0 <malloc+0x278>
     68a:	977ff0ef          	jal	0 <err>
    err("open (2)");
     68e:	00001517          	auipc	a0,0x1
     692:	0b250513          	addi	a0,a0,178 # 1740 <malloc+0x2d8>
     696:	96bff0ef          	jal	0 <err>
    err("mmap (3)");
     69a:	00001517          	auipc	a0,0x1
     69e:	0b650513          	addi	a0,a0,182 # 1750 <malloc+0x2e8>
     6a2:	95fff0ef          	jal	0 <err>
    err("close (2)");
     6a6:	00001517          	auipc	a0,0x1
     6aa:	0ba50513          	addi	a0,a0,186 # 1760 <malloc+0x2f8>
     6ae:	953ff0ef          	jal	0 <err>
    err("open (3)");
     6b2:	00001517          	auipc	a0,0x1
     6b6:	0f650513          	addi	a0,a0,246 # 17a8 <malloc+0x340>
     6ba:	947ff0ef          	jal	0 <err>
    err("mmap (4)");
     6be:	00001517          	auipc	a0,0x1
     6c2:	0fa50513          	addi	a0,a0,250 # 17b8 <malloc+0x350>
     6c6:	93bff0ef          	jal	0 <err>
    err("close (3)");
     6ca:	00001517          	auipc	a0,0x1
     6ce:	0fe50513          	addi	a0,a0,254 # 17c8 <malloc+0x360>
     6d2:	92fff0ef          	jal	0 <err>
    err("munmap (3)");
     6d6:	00001517          	auipc	a0,0x1
     6da:	10250513          	addi	a0,a0,258 # 17d8 <malloc+0x370>
     6de:	923ff0ef          	jal	0 <err>
    err("open (4)");
     6e2:	00001517          	auipc	a0,0x1
     6e6:	13e50513          	addi	a0,a0,318 # 1820 <malloc+0x3b8>
     6ea:	917ff0ef          	jal	0 <err>
    err("dirty read #1");
     6ee:	00001517          	auipc	a0,0x1
     6f2:	14250513          	addi	a0,a0,322 # 1830 <malloc+0x3c8>
     6f6:	90bff0ef          	jal	0 <err>
      err("file page 0 does not contain modifications");
     6fa:	00001517          	auipc	a0,0x1
     6fe:	14650513          	addi	a0,a0,326 # 1840 <malloc+0x3d8>
     702:	8ffff0ef          	jal	0 <err>
    err("dirty read #2");
     706:	00001517          	auipc	a0,0x1
     70a:	16a50513          	addi	a0,a0,362 # 1870 <malloc+0x408>
     70e:	8f3ff0ef          	jal	0 <err>
      err("file page 1 does not contain modifications");
     712:	00001517          	auipc	a0,0x1
     716:	16e50513          	addi	a0,a0,366 # 1880 <malloc+0x418>
     71a:	8e7ff0ef          	jal	0 <err>
    err("close (4)");
     71e:	00001517          	auipc	a0,0x1
     722:	19250513          	addi	a0,a0,402 # 18b0 <malloc+0x448>
     726:	8dbff0ef          	jal	0 <err>
    err("munmap (4)");
     72a:	00001517          	auipc	a0,0x1
     72e:	1c650513          	addi	a0,a0,454 # 18f0 <malloc+0x488>
     732:	8cfff0ef          	jal	0 <err>
  if(unlink(f) != 0) err("unlink");
     736:	00001517          	auipc	a0,0x1
     73a:	20250513          	addi	a0,a0,514 # 1938 <malloc+0x4d0>
     73e:	8c3ff0ef          	jal	0 <err>
    err("open");
     742:	00001517          	auipc	a0,0x1
     746:	eb650513          	addi	a0,a0,-330 # 15f8 <malloc+0x190>
     74a:	8b7ff0ef          	jal	0 <err>
    err("mmap");
     74e:	00001517          	auipc	a0,0x1
     752:	1f250513          	addi	a0,a0,498 # 1940 <malloc+0x4d8>
     756:	8abff0ef          	jal	0 <err>
    err("open");
     75a:	00001517          	auipc	a0,0x1
     75e:	e9e50513          	addi	a0,a0,-354 # 15f8 <malloc+0x190>
     762:	89fff0ef          	jal	0 <err>
    err("write");
     766:	00001517          	auipc	a0,0x1
     76a:	1ea50513          	addi	a0,a0,490 # 1950 <malloc+0x4e8>
     76e:	893ff0ef          	jal	0 <err>
    err("read was not lazy");
     772:	00001517          	auipc	a0,0x1
     776:	1e650513          	addi	a0,a0,486 # 1958 <malloc+0x4f0>
     77a:	887ff0ef          	jal	0 <err>
    err("munmap");
     77e:	00001517          	auipc	a0,0x1
     782:	1f250513          	addi	a0,a0,498 # 1970 <malloc+0x508>
     786:	87bff0ef          	jal	0 <err>
    err("open (5)");
     78a:	00001517          	auipc	a0,0x1
     78e:	22650513          	addi	a0,a0,550 # 19b0 <malloc+0x548>
     792:	86fff0ef          	jal	0 <err>
    err("write (1)");
     796:	00001517          	auipc	a0,0x1
     79a:	23250513          	addi	a0,a0,562 # 19c8 <malloc+0x560>
     79e:	863ff0ef          	jal	0 <err>
    err("mmap (5)");
     7a2:	00001517          	auipc	a0,0x1
     7a6:	23650513          	addi	a0,a0,566 # 19d8 <malloc+0x570>
     7aa:	857ff0ef          	jal	0 <err>
    err("close (5)");
     7ae:	00001517          	auipc	a0,0x1
     7b2:	23a50513          	addi	a0,a0,570 # 19e8 <malloc+0x580>
     7b6:	84bff0ef          	jal	0 <err>
    err("unlink (1)");
     7ba:	00001517          	auipc	a0,0x1
     7be:	23e50513          	addi	a0,a0,574 # 19f8 <malloc+0x590>
     7c2:	83fff0ef          	jal	0 <err>
    err("open (6)");
     7c6:	00001517          	auipc	a0,0x1
     7ca:	24a50513          	addi	a0,a0,586 # 1a10 <malloc+0x5a8>
     7ce:	833ff0ef          	jal	0 <err>
    err("write (2)");
     7d2:	00001517          	auipc	a0,0x1
     7d6:	25650513          	addi	a0,a0,598 # 1a28 <malloc+0x5c0>
     7da:	827ff0ef          	jal	0 <err>
    err("mmap (6)");
     7de:	00001517          	auipc	a0,0x1
     7e2:	25a50513          	addi	a0,a0,602 # 1a38 <malloc+0x5d0>
     7e6:	81bff0ef          	jal	0 <err>
    err("close (6)");
     7ea:	00001517          	auipc	a0,0x1
     7ee:	25e50513          	addi	a0,a0,606 # 1a48 <malloc+0x5e0>
     7f2:	80fff0ef          	jal	0 <err>
    err("unlink (2)");
     7f6:	00001517          	auipc	a0,0x1
     7fa:	26250513          	addi	a0,a0,610 # 1a58 <malloc+0x5f0>
     7fe:	803ff0ef          	jal	0 <err>
    err("mmap1 mismatch");
     802:	00001517          	auipc	a0,0x1
     806:	26650513          	addi	a0,a0,614 # 1a68 <malloc+0x600>
     80a:	ff6ff0ef          	jal	0 <err>
    err("mmap2 mismatch");
     80e:	00001517          	auipc	a0,0x1
     812:	26a50513          	addi	a0,a0,618 # 1a78 <malloc+0x610>
     816:	feaff0ef          	jal	0 <err>
    err("munmap (5)");
     81a:	00001517          	auipc	a0,0x1
     81e:	26e50513          	addi	a0,a0,622 # 1a88 <malloc+0x620>
     822:	fdeff0ef          	jal	0 <err>
    err("mmap2 mismatch (2)");
     826:	00001517          	auipc	a0,0x1
     82a:	27250513          	addi	a0,a0,626 # 1a98 <malloc+0x630>
     82e:	fd2ff0ef          	jal	0 <err>
    err("munmap (6)");
     832:	00001517          	auipc	a0,0x1
     836:	27e50513          	addi	a0,a0,638 # 1ab0 <malloc+0x648>
     83a:	fc6ff0ef          	jal	0 <err>

000000000000083e <fork_test>:
// mmap a file, then fork.
// check that the child sees the mapped file.
//
void
fork_test(void)
{
     83e:	7179                	addi	sp,sp,-48
     840:	f406                	sd	ra,40(sp)
     842:	f022                	sd	s0,32(sp)
     844:	ec26                	sd	s1,24(sp)
     846:	e84a                	sd	s2,16(sp)
     848:	1800                	addi	s0,sp,48
  int fd;
  int pid;
  const char * const f = "mmap.dur";

  printf("test fork\n");
     84a:	00001517          	auipc	a0,0x1
     84e:	29650513          	addi	a0,a0,662 # 1ae0 <malloc+0x678>
     852:	35f000ef          	jal	13b0 <printf>

  // mmap the file twice.
  makefile(f);
     856:	00001517          	auipc	a0,0x1
     85a:	dca50513          	addi	a0,a0,-566 # 1620 <malloc+0x1b8>
     85e:	839ff0ef          	jal	96 <makefile>
  if ((fd = open(f, O_RDONLY)) == -1)
     862:	4581                	li	a1,0
     864:	00001517          	auipc	a0,0x1
     868:	dbc50513          	addi	a0,a0,-580 # 1620 <malloc+0x1b8>
     86c:	744000ef          	jal	fb0 <open>
     870:	57fd                	li	a5,-1
     872:	06f50e63          	beq	a0,a5,8ee <fork_test+0xb0>
     876:	892a                	mv	s2,a0
    err("open (7)");
  if (unlink(f) == -1)
     878:	00001517          	auipc	a0,0x1
     87c:	da850513          	addi	a0,a0,-600 # 1620 <malloc+0x1b8>
     880:	740000ef          	jal	fc0 <unlink>
     884:	57fd                	li	a5,-1
     886:	06f50a63          	beq	a0,a5,8fa <fork_test+0xbc>
    err("unlink (3)");
  char *p1 = mmap(0, PGSIZE*2, PROT_READ, MAP_SHARED, fd, 0);
     88a:	4781                	li	a5,0
     88c:	874a                	mv	a4,s2
     88e:	4685                	li	a3,1
     890:	8636                	mv	a2,a3
     892:	6589                	lui	a1,0x2
     894:	4501                	li	a0,0
     896:	77a000ef          	jal	1010 <mmap>
     89a:	84aa                	mv	s1,a0
  if (p1 == MAP_FAILED)
     89c:	57fd                	li	a5,-1
     89e:	06f50463          	beq	a0,a5,906 <fork_test+0xc8>
    err("mmap (7)");
  char *p2 = mmap(0, PGSIZE*2, PROT_READ, MAP_SHARED, fd, 0);
     8a2:	4781                	li	a5,0
     8a4:	874a                	mv	a4,s2
     8a6:	4685                	li	a3,1
     8a8:	8636                	mv	a2,a3
     8aa:	6589                	lui	a1,0x2
     8ac:	4501                	li	a0,0
     8ae:	762000ef          	jal	1010 <mmap>
     8b2:	892a                	mv	s2,a0
  if (p2 == MAP_FAILED)
     8b4:	57fd                	li	a5,-1
     8b6:	04f50e63          	beq	a0,a5,912 <fork_test+0xd4>
    err("mmap (8)");

  // read just 2nd page.
  if(*(p1+PGSIZE) != 'A')
     8ba:	6785                	lui	a5,0x1
     8bc:	97a6                	add	a5,a5,s1
     8be:	0007c703          	lbu	a4,0(a5) # 1000 <sleep>
     8c2:	04100793          	li	a5,65
     8c6:	04f71c63          	bne	a4,a5,91e <fork_test+0xe0>
    err("fork mismatch (1)");

  if((pid = fork()) < 0)
     8ca:	69e000ef          	jal	f68 <fork>
     8ce:	04054e63          	bltz	a0,92a <fork_test+0xec>
    err("fork");
  if (pid == 0) {
     8d2:	e925                	bnez	a0,942 <fork_test+0x104>
    _v1(p1);
     8d4:	8526                	mv	a0,s1
     8d6:	f50ff0ef          	jal	26 <_v1>
    if (munmap(p1, PGSIZE) == -1) // just the first page
     8da:	6585                	lui	a1,0x1
     8dc:	8526                	mv	a0,s1
     8de:	73a000ef          	jal	1018 <munmap>
     8e2:	57fd                	li	a5,-1
     8e4:	04f50963          	beq	a0,a5,936 <fork_test+0xf8>
      err("munmap (7)");
    exit(0); // tell the parent that the mapping looks OK.
     8e8:	4501                	li	a0,0
     8ea:	686000ef          	jal	f70 <exit>
    err("open (7)");
     8ee:	00001517          	auipc	a0,0x1
     8f2:	20250513          	addi	a0,a0,514 # 1af0 <malloc+0x688>
     8f6:	f0aff0ef          	jal	0 <err>
    err("unlink (3)");
     8fa:	00001517          	auipc	a0,0x1
     8fe:	20650513          	addi	a0,a0,518 # 1b00 <malloc+0x698>
     902:	efeff0ef          	jal	0 <err>
    err("mmap (7)");
     906:	00001517          	auipc	a0,0x1
     90a:	20a50513          	addi	a0,a0,522 # 1b10 <malloc+0x6a8>
     90e:	ef2ff0ef          	jal	0 <err>
    err("mmap (8)");
     912:	00001517          	auipc	a0,0x1
     916:	20e50513          	addi	a0,a0,526 # 1b20 <malloc+0x6b8>
     91a:	ee6ff0ef          	jal	0 <err>
    err("fork mismatch (1)");
     91e:	00001517          	auipc	a0,0x1
     922:	21250513          	addi	a0,a0,530 # 1b30 <malloc+0x6c8>
     926:	edaff0ef          	jal	0 <err>
    err("fork");
     92a:	00001517          	auipc	a0,0x1
     92e:	21e50513          	addi	a0,a0,542 # 1b48 <malloc+0x6e0>
     932:	eceff0ef          	jal	0 <err>
      err("munmap (7)");
     936:	00001517          	auipc	a0,0x1
     93a:	21a50513          	addi	a0,a0,538 # 1b50 <malloc+0x6e8>
     93e:	ec2ff0ef          	jal	0 <err>
  }

  int status = -1;
     942:	57fd                	li	a5,-1
     944:	fcf42e23          	sw	a5,-36(s0)
  wait(&status);
     948:	fdc40513          	addi	a0,s0,-36
     94c:	62c000ef          	jal	f78 <wait>

  if(status != 0){
     950:	fdc42783          	lw	a5,-36(s0)
     954:	e39d                	bnez	a5,97a <fork_test+0x13c>
    printf("fork_test failed\n");
    exit(1);
  }

  // check that the parent's mappings are still there.
  _v1(p1);
     956:	8526                	mv	a0,s1
     958:	eceff0ef          	jal	26 <_v1>
  _v1(p2);
     95c:	854a                	mv	a0,s2
     95e:	ec8ff0ef          	jal	26 <_v1>

  printf("test fork: OK\n");
     962:	00001517          	auipc	a0,0x1
     966:	21650513          	addi	a0,a0,534 # 1b78 <malloc+0x710>
     96a:	247000ef          	jal	13b0 <printf>
}
     96e:	70a2                	ld	ra,40(sp)
     970:	7402                	ld	s0,32(sp)
     972:	64e2                	ld	s1,24(sp)
     974:	6942                	ld	s2,16(sp)
     976:	6145                	addi	sp,sp,48
     978:	8082                	ret
    printf("fork_test failed\n");
     97a:	00001517          	auipc	a0,0x1
     97e:	1e650513          	addi	a0,a0,486 # 1b60 <malloc+0x6f8>
     982:	22f000ef          	jal	13b0 <printf>
    exit(1);
     986:	4505                	li	a0,1
     988:	5e8000ef          	jal	f70 <exit>

000000000000098c <more_test>:

void
more_test()
{
     98c:	7179                	addi	sp,sp,-48
     98e:	f406                	sd	ra,40(sp)
     990:	f022                	sd	s0,32(sp)
     992:	ec26                	sd	s1,24(sp)
     994:	e84a                	sd	s2,16(sp)
     996:	1800                	addi	s0,sp,48
  int fd, pid;
  char *p;
  const char * const f = "mmap.dur";
  
  printf("test munmap prevents access\n");
     998:	00001517          	auipc	a0,0x1
     99c:	1f050513          	addi	a0,a0,496 # 1b88 <malloc+0x720>
     9a0:	211000ef          	jal	13b0 <printf>
  
  makefile(f);
     9a4:	00001517          	auipc	a0,0x1
     9a8:	c7c50513          	addi	a0,a0,-900 # 1620 <malloc+0x1b8>
     9ac:	eeaff0ef          	jal	96 <makefile>
  if ((fd = open(f, O_RDWR)) == -1)
     9b0:	4589                	li	a1,2
     9b2:	00001517          	auipc	a0,0x1
     9b6:	c6e50513          	addi	a0,a0,-914 # 1620 <malloc+0x1b8>
     9ba:	5f6000ef          	jal	fb0 <open>
     9be:	57fd                	li	a5,-1
     9c0:	06f50e63          	beq	a0,a5,a3c <more_test+0xb0>
     9c4:	892a                	mv	s2,a0
    err("open");
  p = mmap(0, PGSIZE*2, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
     9c6:	4781                	li	a5,0
     9c8:	872a                	mv	a4,a0
     9ca:	4685                	li	a3,1
     9cc:	460d                	li	a2,3
     9ce:	6589                	lui	a1,0x2
     9d0:	4501                	li	a0,0
     9d2:	63e000ef          	jal	1010 <mmap>
     9d6:	84aa                	mv	s1,a0
  if (p == MAP_FAILED)
     9d8:	57fd                	li	a5,-1
     9da:	06f50763          	beq	a0,a5,a48 <more_test+0xbc>
    err("mmap");
  close(fd);
     9de:	854a                	mv	a0,s2
     9e0:	5b8000ef          	jal	f98 <close>

  *p = 'X';
     9e4:	05800793          	li	a5,88
     9e8:	00f48023          	sb	a5,0(s1)
  *(p+PGSIZE) = 'Y';
     9ec:	6785                	lui	a5,0x1
     9ee:	97a6                	add	a5,a5,s1
     9f0:	05900713          	li	a4,89
     9f4:	00e78023          	sb	a4,0(a5) # 1000 <sleep>

  pid = fork();
     9f8:	570000ef          	jal	f68 <fork>
  if(pid < 0) err("fork");
     9fc:	04054c63          	bltz	a0,a54 <more_test+0xc8>
  if(pid == 0){
     a00:	e535                	bnez	a0,a6c <more_test+0xe0>
    *p = 'a';
     a02:	06100793          	li	a5,97
     a06:	00f48023          	sb	a5,0(s1)
    *(p+PGSIZE) = 'b';
     a0a:	6505                	lui	a0,0x1
     a0c:	9526                	add	a0,a0,s1
     a0e:	06200793          	li	a5,98
     a12:	00f50023          	sb	a5,0(a0) # 1000 <sleep>
    if(munmap(p+PGSIZE, PGSIZE) == -1)
     a16:	6585                	lui	a1,0x1
     a18:	600000ef          	jal	1018 <munmap>
     a1c:	57fd                	li	a5,-1
     a1e:	04f50163          	beq	a0,a5,a60 <more_test+0xd4>
      err("munmap");
    // this should cause a fatal fault
    printf("*(p+PGSIZE) = %x\n", *(p+PGSIZE));
     a22:	6785                	lui	a5,0x1
     a24:	97a6                	add	a5,a5,s1
     a26:	0007c583          	lbu	a1,0(a5) # 1000 <sleep>
     a2a:	00001517          	auipc	a0,0x1
     a2e:	17e50513          	addi	a0,a0,382 # 1ba8 <malloc+0x740>
     a32:	17f000ef          	jal	13b0 <printf>
    exit(0);
     a36:	4501                	li	a0,0
     a38:	538000ef          	jal	f70 <exit>
    err("open");
     a3c:	00001517          	auipc	a0,0x1
     a40:	bbc50513          	addi	a0,a0,-1092 # 15f8 <malloc+0x190>
     a44:	dbcff0ef          	jal	0 <err>
    err("mmap");
     a48:	00001517          	auipc	a0,0x1
     a4c:	ef850513          	addi	a0,a0,-264 # 1940 <malloc+0x4d8>
     a50:	db0ff0ef          	jal	0 <err>
  if(pid < 0) err("fork");
     a54:	00001517          	auipc	a0,0x1
     a58:	0f450513          	addi	a0,a0,244 # 1b48 <malloc+0x6e0>
     a5c:	da4ff0ef          	jal	0 <err>
      err("munmap");
     a60:	00001517          	auipc	a0,0x1
     a64:	f1050513          	addi	a0,a0,-240 # 1970 <malloc+0x508>
     a68:	d98ff0ef          	jal	0 <err>
  }
  int st = 0;
     a6c:	fc042e23          	sw	zero,-36(s0)
  wait(&st);
     a70:	fdc40513          	addi	a0,s0,-36
     a74:	504000ef          	jal	f78 <wait>
  if(st != -1)
     a78:	fdc42703          	lw	a4,-36(s0)
     a7c:	57fd                	li	a5,-1
     a7e:	04f71363          	bne	a4,a5,ac4 <more_test+0x138>
    err("child #1 read unmapped memory");

  pid = fork();
     a82:	4e6000ef          	jal	f68 <fork>
  if(pid < 0) err("fork");
     a86:	04054563          	bltz	a0,ad0 <more_test+0x144>
  if(pid == 0){
     a8a:	ed39                	bnez	a0,ae8 <more_test+0x15c>
    *p = 'c';
     a8c:	06300793          	li	a5,99
     a90:	00f48023          	sb	a5,0(s1)
    *(p+PGSIZE) = 'd';
     a94:	6785                	lui	a5,0x1
     a96:	97a6                	add	a5,a5,s1
     a98:	06400713          	li	a4,100
     a9c:	00e78023          	sb	a4,0(a5) # 1000 <sleep>
    if(munmap(p, PGSIZE) == -1)
     aa0:	6585                	lui	a1,0x1
     aa2:	8526                	mv	a0,s1
     aa4:	574000ef          	jal	1018 <munmap>
     aa8:	57fd                	li	a5,-1
     aaa:	02f50963          	beq	a0,a5,adc <more_test+0x150>
      err("munmap");
    // this should cause a fatal fault
    printf("*p = %x\n", *p);
     aae:	0004c583          	lbu	a1,0(s1)
     ab2:	00001517          	auipc	a0,0x1
     ab6:	12e50513          	addi	a0,a0,302 # 1be0 <malloc+0x778>
     aba:	0f7000ef          	jal	13b0 <printf>
    exit(0);
     abe:	4501                	li	a0,0
     ac0:	4b0000ef          	jal	f70 <exit>
    err("child #1 read unmapped memory");
     ac4:	00001517          	auipc	a0,0x1
     ac8:	0fc50513          	addi	a0,a0,252 # 1bc0 <malloc+0x758>
     acc:	d34ff0ef          	jal	0 <err>
  if(pid < 0) err("fork");
     ad0:	00001517          	auipc	a0,0x1
     ad4:	07850513          	addi	a0,a0,120 # 1b48 <malloc+0x6e0>
     ad8:	d28ff0ef          	jal	0 <err>
      err("munmap");
     adc:	00001517          	auipc	a0,0x1
     ae0:	e9450513          	addi	a0,a0,-364 # 1970 <malloc+0x508>
     ae4:	d1cff0ef          	jal	0 <err>
  }
  st = 0;
     ae8:	fc042e23          	sw	zero,-36(s0)
  wait(&st);
     aec:	fdc40513          	addi	a0,s0,-36
     af0:	488000ef          	jal	f78 <wait>
  if(st != -1)
     af4:	fdc42703          	lw	a4,-36(s0)
     af8:	57fd                	li	a5,-1
     afa:	10f71363          	bne	a4,a5,c00 <more_test+0x274>
    err("child #2 read unmapped memory");

  // parent should still be able to access the memory.
  *p = 'P';
     afe:	05000793          	li	a5,80
     b02:	00f48023          	sb	a5,0(s1)
  *(p+PGSIZE) = 'Q';
     b06:	6785                	lui	a5,0x1
     b08:	97a6                	add	a5,a5,s1
     b0a:	05100713          	li	a4,81
     b0e:	00e78023          	sb	a4,0(a5) # 1000 <sleep>

  if(munmap(p, PGSIZE) == -1)
     b12:	6585                	lui	a1,0x1
     b14:	8526                	mv	a0,s1
     b16:	502000ef          	jal	1018 <munmap>
     b1a:	57fd                	li	a5,-1
     b1c:	0ef50863          	beq	a0,a5,c0c <more_test+0x280>
    err("munmap");

  *(p+PGSIZE) = 'R';
     b20:	6785                	lui	a5,0x1
     b22:	00f48533          	add	a0,s1,a5
     b26:	05200793          	li	a5,82
     b2a:	00f50023          	sb	a5,0(a0)
  if(munmap(p+PGSIZE, PGSIZE) == -1)
     b2e:	6585                	lui	a1,0x1
     b30:	4e8000ef          	jal	1018 <munmap>
     b34:	57fd                	li	a5,-1
     b36:	0ef50163          	beq	a0,a5,c18 <more_test+0x28c>
    err("munmap");

  // read the file, check that the first page starts
  // with P and the second page with R.
  fd = open(f, O_RDONLY);
     b3a:	4581                	li	a1,0
     b3c:	00001517          	auipc	a0,0x1
     b40:	ae450513          	addi	a0,a0,-1308 # 1620 <malloc+0x1b8>
     b44:	46c000ef          	jal	fb0 <open>
     b48:	84aa                	mv	s1,a0
  if(fd < 0) err("open");
     b4a:	0c054d63          	bltz	a0,c24 <more_test+0x298>
  if(read(fd, buf, PGSIZE) != PGSIZE) err("read");
     b4e:	6605                	lui	a2,0x1
     b50:	00001597          	auipc	a1,0x1
     b54:	4c058593          	addi	a1,a1,1216 # 2010 <buf>
     b58:	430000ef          	jal	f88 <read>
     b5c:	6785                	lui	a5,0x1
     b5e:	0cf51963          	bne	a0,a5,c30 <more_test+0x2a4>
  if(buf[0] != 'P') err("first byte of file is wrong");
     b62:	00001717          	auipc	a4,0x1
     b66:	4ae74703          	lbu	a4,1198(a4) # 2010 <buf>
     b6a:	05000793          	li	a5,80
     b6e:	0cf71763          	bne	a4,a5,c3c <more_test+0x2b0>
  if(read(fd, buf, PGSIZE) != PGSIZE/2) err("read");
     b72:	6605                	lui	a2,0x1
     b74:	00001597          	auipc	a1,0x1
     b78:	49c58593          	addi	a1,a1,1180 # 2010 <buf>
     b7c:	8526                	mv	a0,s1
     b7e:	40a000ef          	jal	f88 <read>
     b82:	8005051b          	addiw	a0,a0,-2048
     b86:	e169                	bnez	a0,c48 <more_test+0x2bc>
  if(buf[0] != 'R') err("first byte of 2nd page of file is wrong");
     b88:	00001717          	auipc	a4,0x1
     b8c:	48874703          	lbu	a4,1160(a4) # 2010 <buf>
     b90:	05200793          	li	a5,82
     b94:	0cf71063          	bne	a4,a5,c54 <more_test+0x2c8>
  close(fd);
     b98:	8526                	mv	a0,s1
     b9a:	3fe000ef          	jal	f98 <close>

  printf("test munmap prevents access: OK\n");
     b9e:	00001517          	auipc	a0,0x1
     ba2:	0ba50513          	addi	a0,a0,186 # 1c58 <malloc+0x7f0>
     ba6:	00b000ef          	jal	13b0 <printf>

  printf("test writes to read-only mapped memory\n");
     baa:	00001517          	auipc	a0,0x1
     bae:	0d650513          	addi	a0,a0,214 # 1c80 <malloc+0x818>
     bb2:	7fe000ef          	jal	13b0 <printf>

  makefile(f);
     bb6:	00001517          	auipc	a0,0x1
     bba:	a6a50513          	addi	a0,a0,-1430 # 1620 <malloc+0x1b8>
     bbe:	cd8ff0ef          	jal	96 <makefile>

  pid = fork();
     bc2:	3a6000ef          	jal	f68 <fork>
  if(pid < 0) err("fork");
     bc6:	08054d63          	bltz	a0,c60 <more_test+0x2d4>
  if(pid == 0){
     bca:	ed4d                	bnez	a0,c84 <more_test+0x2f8>
    if ((fd = open(f, O_RDWR)) == -1)
     bcc:	4589                	li	a1,2
     bce:	00001517          	auipc	a0,0x1
     bd2:	a5250513          	addi	a0,a0,-1454 # 1620 <malloc+0x1b8>
     bd6:	3da000ef          	jal	fb0 <open>
     bda:	872a                	mv	a4,a0
     bdc:	57fd                	li	a5,-1
     bde:	08f50763          	beq	a0,a5,c6c <more_test+0x2e0>
      err("open");
    p = mmap(0, PGSIZE*2, PROT_READ, MAP_SHARED, fd, 0);
     be2:	4781                	li	a5,0
     be4:	4685                	li	a3,1
     be6:	8636                	mv	a2,a3
     be8:	6589                	lui	a1,0x2
     bea:	4501                	li	a0,0
     bec:	424000ef          	jal	1010 <mmap>
    if (p == MAP_FAILED)
     bf0:	57fd                	li	a5,-1
     bf2:	08f50363          	beq	a0,a5,c78 <more_test+0x2ec>
      err("mmap");
    // this should cause a fatal fault
    *p = 0;
     bf6:	00050023          	sb	zero,0(a0)
    exit(*p);
     bfa:	4501                	li	a0,0
     bfc:	374000ef          	jal	f70 <exit>
    err("child #2 read unmapped memory");
     c00:	00001517          	auipc	a0,0x1
     c04:	ff050513          	addi	a0,a0,-16 # 1bf0 <malloc+0x788>
     c08:	bf8ff0ef          	jal	0 <err>
    err("munmap");
     c0c:	00001517          	auipc	a0,0x1
     c10:	d6450513          	addi	a0,a0,-668 # 1970 <malloc+0x508>
     c14:	becff0ef          	jal	0 <err>
    err("munmap");
     c18:	00001517          	auipc	a0,0x1
     c1c:	d5850513          	addi	a0,a0,-680 # 1970 <malloc+0x508>
     c20:	be0ff0ef          	jal	0 <err>
  if(fd < 0) err("open");
     c24:	00001517          	auipc	a0,0x1
     c28:	9d450513          	addi	a0,a0,-1580 # 15f8 <malloc+0x190>
     c2c:	bd4ff0ef          	jal	0 <err>
  if(read(fd, buf, PGSIZE) != PGSIZE) err("read");
     c30:	00001517          	auipc	a0,0x1
     c34:	aa850513          	addi	a0,a0,-1368 # 16d8 <malloc+0x270>
     c38:	bc8ff0ef          	jal	0 <err>
  if(buf[0] != 'P') err("first byte of file is wrong");
     c3c:	00001517          	auipc	a0,0x1
     c40:	fd450513          	addi	a0,a0,-44 # 1c10 <malloc+0x7a8>
     c44:	bbcff0ef          	jal	0 <err>
  if(read(fd, buf, PGSIZE) != PGSIZE/2) err("read");
     c48:	00001517          	auipc	a0,0x1
     c4c:	a9050513          	addi	a0,a0,-1392 # 16d8 <malloc+0x270>
     c50:	bb0ff0ef          	jal	0 <err>
  if(buf[0] != 'R') err("first byte of 2nd page of file is wrong");
     c54:	00001517          	auipc	a0,0x1
     c58:	fdc50513          	addi	a0,a0,-36 # 1c30 <malloc+0x7c8>
     c5c:	ba4ff0ef          	jal	0 <err>
  if(pid < 0) err("fork");
     c60:	00001517          	auipc	a0,0x1
     c64:	ee850513          	addi	a0,a0,-280 # 1b48 <malloc+0x6e0>
     c68:	b98ff0ef          	jal	0 <err>
      err("open");
     c6c:	00001517          	auipc	a0,0x1
     c70:	98c50513          	addi	a0,a0,-1652 # 15f8 <malloc+0x190>
     c74:	b8cff0ef          	jal	0 <err>
      err("mmap");
     c78:	00001517          	auipc	a0,0x1
     c7c:	cc850513          	addi	a0,a0,-824 # 1940 <malloc+0x4d8>
     c80:	b80ff0ef          	jal	0 <err>
  }

  st = 0;
     c84:	fc042e23          	sw	zero,-36(s0)
  wait(&st);
     c88:	fdc40513          	addi	a0,s0,-36
     c8c:	2ec000ef          	jal	f78 <wait>
  if(st != -1)
     c90:	fdc42703          	lw	a4,-36(s0)
     c94:	57fd                	li	a5,-1
     c96:	00f71e63          	bne	a4,a5,cb2 <more_test+0x326>
    err("child wrote read-only mapping");

  printf("test writes to read-only mapped memory: OK\n");
     c9a:	00001517          	auipc	a0,0x1
     c9e:	02e50513          	addi	a0,a0,46 # 1cc8 <malloc+0x860>
     ca2:	70e000ef          	jal	13b0 <printf>
}
     ca6:	70a2                	ld	ra,40(sp)
     ca8:	7402                	ld	s0,32(sp)
     caa:	64e2                	ld	s1,24(sp)
     cac:	6942                	ld	s2,16(sp)
     cae:	6145                	addi	sp,sp,48
     cb0:	8082                	ret
    err("child wrote read-only mapping");
     cb2:	00001517          	auipc	a0,0x1
     cb6:	ff650513          	addi	a0,a0,-10 # 1ca8 <malloc+0x840>
     cba:	b46ff0ef          	jal	0 <err>

0000000000000cbe <main>:
{
     cbe:	1141                	addi	sp,sp,-16
     cc0:	e406                	sd	ra,8(sp)
     cc2:	e022                	sd	s0,0(sp)
     cc4:	0800                	addi	s0,sp,16
  mmap_test();
     cc6:	c6cff0ef          	jal	132 <mmap_test>
  fork_test();
     cca:	b75ff0ef          	jal	83e <fork_test>
  more_test();
     cce:	cbfff0ef          	jal	98c <more_test>
  printf("mmaptest: all tests succeeded\n");
     cd2:	00001517          	auipc	a0,0x1
     cd6:	02650513          	addi	a0,a0,38 # 1cf8 <malloc+0x890>
     cda:	6d6000ef          	jal	13b0 <printf>
  exit(0);
     cde:	4501                	li	a0,0
     ce0:	290000ef          	jal	f70 <exit>

0000000000000ce4 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
     ce4:	1141                	addi	sp,sp,-16
     ce6:	e406                	sd	ra,8(sp)
     ce8:	e022                	sd	s0,0(sp)
     cea:	0800                	addi	s0,sp,16
  extern int main();
  main();
     cec:	fd3ff0ef          	jal	cbe <main>
  exit(0);
     cf0:	4501                	li	a0,0
     cf2:	27e000ef          	jal	f70 <exit>

0000000000000cf6 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
     cf6:	1141                	addi	sp,sp,-16
     cf8:	e406                	sd	ra,8(sp)
     cfa:	e022                	sd	s0,0(sp)
     cfc:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     cfe:	87aa                	mv	a5,a0
     d00:	0585                	addi	a1,a1,1 # 2001 <freep+0x1>
     d02:	0785                	addi	a5,a5,1 # 1001 <sleep+0x1>
     d04:	fff5c703          	lbu	a4,-1(a1)
     d08:	fee78fa3          	sb	a4,-1(a5)
     d0c:	fb75                	bnez	a4,d00 <strcpy+0xa>
    ;
  return os;
}
     d0e:	60a2                	ld	ra,8(sp)
     d10:	6402                	ld	s0,0(sp)
     d12:	0141                	addi	sp,sp,16
     d14:	8082                	ret

0000000000000d16 <strcmp>:

int
strcmp(const char *p, const char *q)
{
     d16:	1141                	addi	sp,sp,-16
     d18:	e406                	sd	ra,8(sp)
     d1a:	e022                	sd	s0,0(sp)
     d1c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
     d1e:	00054783          	lbu	a5,0(a0)
     d22:	cb91                	beqz	a5,d36 <strcmp+0x20>
     d24:	0005c703          	lbu	a4,0(a1)
     d28:	00f71763          	bne	a4,a5,d36 <strcmp+0x20>
    p++, q++;
     d2c:	0505                	addi	a0,a0,1
     d2e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
     d30:	00054783          	lbu	a5,0(a0)
     d34:	fbe5                	bnez	a5,d24 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
     d36:	0005c503          	lbu	a0,0(a1)
}
     d3a:	40a7853b          	subw	a0,a5,a0
     d3e:	60a2                	ld	ra,8(sp)
     d40:	6402                	ld	s0,0(sp)
     d42:	0141                	addi	sp,sp,16
     d44:	8082                	ret

0000000000000d46 <strlen>:

uint
strlen(const char *s)
{
     d46:	1141                	addi	sp,sp,-16
     d48:	e406                	sd	ra,8(sp)
     d4a:	e022                	sd	s0,0(sp)
     d4c:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
     d4e:	00054783          	lbu	a5,0(a0)
     d52:	cf91                	beqz	a5,d6e <strlen+0x28>
     d54:	00150793          	addi	a5,a0,1
     d58:	86be                	mv	a3,a5
     d5a:	0785                	addi	a5,a5,1
     d5c:	fff7c703          	lbu	a4,-1(a5)
     d60:	ff65                	bnez	a4,d58 <strlen+0x12>
     d62:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
     d66:	60a2                	ld	ra,8(sp)
     d68:	6402                	ld	s0,0(sp)
     d6a:	0141                	addi	sp,sp,16
     d6c:	8082                	ret
  for(n = 0; s[n]; n++)
     d6e:	4501                	li	a0,0
     d70:	bfdd                	j	d66 <strlen+0x20>

0000000000000d72 <memset>:

void*
memset(void *dst, int c, uint n)
{
     d72:	1141                	addi	sp,sp,-16
     d74:	e406                	sd	ra,8(sp)
     d76:	e022                	sd	s0,0(sp)
     d78:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     d7a:	ca19                	beqz	a2,d90 <memset+0x1e>
     d7c:	87aa                	mv	a5,a0
     d7e:	1602                	slli	a2,a2,0x20
     d80:	9201                	srli	a2,a2,0x20
     d82:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
     d86:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
     d8a:	0785                	addi	a5,a5,1
     d8c:	fee79de3          	bne	a5,a4,d86 <memset+0x14>
  }
  return dst;
}
     d90:	60a2                	ld	ra,8(sp)
     d92:	6402                	ld	s0,0(sp)
     d94:	0141                	addi	sp,sp,16
     d96:	8082                	ret

0000000000000d98 <strchr>:

char*
strchr(const char *s, char c)
{
     d98:	1141                	addi	sp,sp,-16
     d9a:	e406                	sd	ra,8(sp)
     d9c:	e022                	sd	s0,0(sp)
     d9e:	0800                	addi	s0,sp,16
  for(; *s; s++)
     da0:	00054783          	lbu	a5,0(a0)
     da4:	cf81                	beqz	a5,dbc <strchr+0x24>
    if(*s == c)
     da6:	00f58763          	beq	a1,a5,db4 <strchr+0x1c>
  for(; *s; s++)
     daa:	0505                	addi	a0,a0,1
     dac:	00054783          	lbu	a5,0(a0)
     db0:	fbfd                	bnez	a5,da6 <strchr+0xe>
      return (char*)s;
  return 0;
     db2:	4501                	li	a0,0
}
     db4:	60a2                	ld	ra,8(sp)
     db6:	6402                	ld	s0,0(sp)
     db8:	0141                	addi	sp,sp,16
     dba:	8082                	ret
  return 0;
     dbc:	4501                	li	a0,0
     dbe:	bfdd                	j	db4 <strchr+0x1c>

0000000000000dc0 <gets>:

char*
gets(char *buf, int max)
{
     dc0:	711d                	addi	sp,sp,-96
     dc2:	ec86                	sd	ra,88(sp)
     dc4:	e8a2                	sd	s0,80(sp)
     dc6:	e4a6                	sd	s1,72(sp)
     dc8:	e0ca                	sd	s2,64(sp)
     dca:	fc4e                	sd	s3,56(sp)
     dcc:	f852                	sd	s4,48(sp)
     dce:	f456                	sd	s5,40(sp)
     dd0:	f05a                	sd	s6,32(sp)
     dd2:	ec5e                	sd	s7,24(sp)
     dd4:	e862                	sd	s8,16(sp)
     dd6:	1080                	addi	s0,sp,96
     dd8:	8baa                	mv	s7,a0
     dda:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     ddc:	892a                	mv	s2,a0
     dde:	4481                	li	s1,0
    cc = read(0, &c, 1);
     de0:	faf40b13          	addi	s6,s0,-81
     de4:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
     de6:	8c26                	mv	s8,s1
     de8:	0014899b          	addiw	s3,s1,1
     dec:	84ce                	mv	s1,s3
     dee:	0349d463          	bge	s3,s4,e16 <gets+0x56>
    cc = read(0, &c, 1);
     df2:	8656                	mv	a2,s5
     df4:	85da                	mv	a1,s6
     df6:	4501                	li	a0,0
     df8:	190000ef          	jal	f88 <read>
    if(cc < 1)
     dfc:	00a05d63          	blez	a0,e16 <gets+0x56>
      break;
    buf[i++] = c;
     e00:	faf44783          	lbu	a5,-81(s0)
     e04:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
     e08:	0905                	addi	s2,s2,1
     e0a:	ff678713          	addi	a4,a5,-10
     e0e:	c319                	beqz	a4,e14 <gets+0x54>
     e10:	17cd                	addi	a5,a5,-13
     e12:	fbf1                	bnez	a5,de6 <gets+0x26>
    buf[i++] = c;
     e14:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
     e16:	9c5e                	add	s8,s8,s7
     e18:	000c0023          	sb	zero,0(s8)
  return buf;
}
     e1c:	855e                	mv	a0,s7
     e1e:	60e6                	ld	ra,88(sp)
     e20:	6446                	ld	s0,80(sp)
     e22:	64a6                	ld	s1,72(sp)
     e24:	6906                	ld	s2,64(sp)
     e26:	79e2                	ld	s3,56(sp)
     e28:	7a42                	ld	s4,48(sp)
     e2a:	7aa2                	ld	s5,40(sp)
     e2c:	7b02                	ld	s6,32(sp)
     e2e:	6be2                	ld	s7,24(sp)
     e30:	6c42                	ld	s8,16(sp)
     e32:	6125                	addi	sp,sp,96
     e34:	8082                	ret

0000000000000e36 <stat>:

int
stat(const char *n, struct stat *st)
{
     e36:	1101                	addi	sp,sp,-32
     e38:	ec06                	sd	ra,24(sp)
     e3a:	e822                	sd	s0,16(sp)
     e3c:	e04a                	sd	s2,0(sp)
     e3e:	1000                	addi	s0,sp,32
     e40:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     e42:	4581                	li	a1,0
     e44:	16c000ef          	jal	fb0 <open>
  if(fd < 0)
     e48:	02054263          	bltz	a0,e6c <stat+0x36>
     e4c:	e426                	sd	s1,8(sp)
     e4e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
     e50:	85ca                	mv	a1,s2
     e52:	176000ef          	jal	fc8 <fstat>
     e56:	892a                	mv	s2,a0
  close(fd);
     e58:	8526                	mv	a0,s1
     e5a:	13e000ef          	jal	f98 <close>
  return r;
     e5e:	64a2                	ld	s1,8(sp)
}
     e60:	854a                	mv	a0,s2
     e62:	60e2                	ld	ra,24(sp)
     e64:	6442                	ld	s0,16(sp)
     e66:	6902                	ld	s2,0(sp)
     e68:	6105                	addi	sp,sp,32
     e6a:	8082                	ret
    return -1;
     e6c:	57fd                	li	a5,-1
     e6e:	893e                	mv	s2,a5
     e70:	bfc5                	j	e60 <stat+0x2a>

0000000000000e72 <atoi>:

int
atoi(const char *s)
{
     e72:	1141                	addi	sp,sp,-16
     e74:	e406                	sd	ra,8(sp)
     e76:	e022                	sd	s0,0(sp)
     e78:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     e7a:	00054683          	lbu	a3,0(a0)
     e7e:	fd06879b          	addiw	a5,a3,-48 # 1fd0 <digits+0x2b0>
     e82:	0ff7f793          	zext.b	a5,a5
     e86:	4625                	li	a2,9
     e88:	02f66963          	bltu	a2,a5,eba <atoi+0x48>
     e8c:	872a                	mv	a4,a0
  n = 0;
     e8e:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
     e90:	0705                	addi	a4,a4,1
     e92:	0025179b          	slliw	a5,a0,0x2
     e96:	9fa9                	addw	a5,a5,a0
     e98:	0017979b          	slliw	a5,a5,0x1
     e9c:	9fb5                	addw	a5,a5,a3
     e9e:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
     ea2:	00074683          	lbu	a3,0(a4)
     ea6:	fd06879b          	addiw	a5,a3,-48
     eaa:	0ff7f793          	zext.b	a5,a5
     eae:	fef671e3          	bgeu	a2,a5,e90 <atoi+0x1e>
  return n;
}
     eb2:	60a2                	ld	ra,8(sp)
     eb4:	6402                	ld	s0,0(sp)
     eb6:	0141                	addi	sp,sp,16
     eb8:	8082                	ret
  n = 0;
     eba:	4501                	li	a0,0
     ebc:	bfdd                	j	eb2 <atoi+0x40>

0000000000000ebe <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     ebe:	1141                	addi	sp,sp,-16
     ec0:	e406                	sd	ra,8(sp)
     ec2:	e022                	sd	s0,0(sp)
     ec4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     ec6:	02b57563          	bgeu	a0,a1,ef0 <memmove+0x32>
    while(n-- > 0)
     eca:	00c05f63          	blez	a2,ee8 <memmove+0x2a>
     ece:	1602                	slli	a2,a2,0x20
     ed0:	9201                	srli	a2,a2,0x20
     ed2:	00c507b3          	add	a5,a0,a2
  dst = vdst;
     ed6:	872a                	mv	a4,a0
      *dst++ = *src++;
     ed8:	0585                	addi	a1,a1,1
     eda:	0705                	addi	a4,a4,1
     edc:	fff5c683          	lbu	a3,-1(a1)
     ee0:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
     ee4:	fee79ae3          	bne	a5,a4,ed8 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
     ee8:	60a2                	ld	ra,8(sp)
     eea:	6402                	ld	s0,0(sp)
     eec:	0141                	addi	sp,sp,16
     eee:	8082                	ret
    while(n-- > 0)
     ef0:	fec05ce3          	blez	a2,ee8 <memmove+0x2a>
    dst += n;
     ef4:	00c50733          	add	a4,a0,a2
    src += n;
     ef8:	95b2                	add	a1,a1,a2
     efa:	fff6079b          	addiw	a5,a2,-1 # fff <sbrk+0x7>
     efe:	1782                	slli	a5,a5,0x20
     f00:	9381                	srli	a5,a5,0x20
     f02:	fff7c793          	not	a5,a5
     f06:	97ba                	add	a5,a5,a4
      *--dst = *--src;
     f08:	15fd                	addi	a1,a1,-1
     f0a:	177d                	addi	a4,a4,-1
     f0c:	0005c683          	lbu	a3,0(a1)
     f10:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
     f14:	fef71ae3          	bne	a4,a5,f08 <memmove+0x4a>
     f18:	bfc1                	j	ee8 <memmove+0x2a>

0000000000000f1a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
     f1a:	1141                	addi	sp,sp,-16
     f1c:	e406                	sd	ra,8(sp)
     f1e:	e022                	sd	s0,0(sp)
     f20:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     f22:	c61d                	beqz	a2,f50 <memcmp+0x36>
     f24:	1602                	slli	a2,a2,0x20
     f26:	9201                	srli	a2,a2,0x20
     f28:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
     f2c:	00054783          	lbu	a5,0(a0)
     f30:	0005c703          	lbu	a4,0(a1)
     f34:	00e79863          	bne	a5,a4,f44 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
     f38:	0505                	addi	a0,a0,1
    p2++;
     f3a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
     f3c:	fed518e3          	bne	a0,a3,f2c <memcmp+0x12>
  }
  return 0;
     f40:	4501                	li	a0,0
     f42:	a019                	j	f48 <memcmp+0x2e>
      return *p1 - *p2;
     f44:	40e7853b          	subw	a0,a5,a4
}
     f48:	60a2                	ld	ra,8(sp)
     f4a:	6402                	ld	s0,0(sp)
     f4c:	0141                	addi	sp,sp,16
     f4e:	8082                	ret
  return 0;
     f50:	4501                	li	a0,0
     f52:	bfdd                	j	f48 <memcmp+0x2e>

0000000000000f54 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
     f54:	1141                	addi	sp,sp,-16
     f56:	e406                	sd	ra,8(sp)
     f58:	e022                	sd	s0,0(sp)
     f5a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
     f5c:	f63ff0ef          	jal	ebe <memmove>
}
     f60:	60a2                	ld	ra,8(sp)
     f62:	6402                	ld	s0,0(sp)
     f64:	0141                	addi	sp,sp,16
     f66:	8082                	ret

0000000000000f68 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
     f68:	4885                	li	a7,1
 ecall
     f6a:	00000073          	ecall
 ret
     f6e:	8082                	ret

0000000000000f70 <exit>:
.global exit
exit:
 li a7, SYS_exit
     f70:	4889                	li	a7,2
 ecall
     f72:	00000073          	ecall
 ret
     f76:	8082                	ret

0000000000000f78 <wait>:
.global wait
wait:
 li a7, SYS_wait
     f78:	488d                	li	a7,3
 ecall
     f7a:	00000073          	ecall
 ret
     f7e:	8082                	ret

0000000000000f80 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
     f80:	4891                	li	a7,4
 ecall
     f82:	00000073          	ecall
 ret
     f86:	8082                	ret

0000000000000f88 <read>:
.global read
read:
 li a7, SYS_read
     f88:	4895                	li	a7,5
 ecall
     f8a:	00000073          	ecall
 ret
     f8e:	8082                	ret

0000000000000f90 <write>:
.global write
write:
 li a7, SYS_write
     f90:	48c1                	li	a7,16
 ecall
     f92:	00000073          	ecall
 ret
     f96:	8082                	ret

0000000000000f98 <close>:
.global close
close:
 li a7, SYS_close
     f98:	48d5                	li	a7,21
 ecall
     f9a:	00000073          	ecall
 ret
     f9e:	8082                	ret

0000000000000fa0 <kill>:
.global kill
kill:
 li a7, SYS_kill
     fa0:	4899                	li	a7,6
 ecall
     fa2:	00000073          	ecall
 ret
     fa6:	8082                	ret

0000000000000fa8 <exec>:
.global exec
exec:
 li a7, SYS_exec
     fa8:	489d                	li	a7,7
 ecall
     faa:	00000073          	ecall
 ret
     fae:	8082                	ret

0000000000000fb0 <open>:
.global open
open:
 li a7, SYS_open
     fb0:	48bd                	li	a7,15
 ecall
     fb2:	00000073          	ecall
 ret
     fb6:	8082                	ret

0000000000000fb8 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
     fb8:	48c5                	li	a7,17
 ecall
     fba:	00000073          	ecall
 ret
     fbe:	8082                	ret

0000000000000fc0 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
     fc0:	48c9                	li	a7,18
 ecall
     fc2:	00000073          	ecall
 ret
     fc6:	8082                	ret

0000000000000fc8 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
     fc8:	48a1                	li	a7,8
 ecall
     fca:	00000073          	ecall
 ret
     fce:	8082                	ret

0000000000000fd0 <link>:
.global link
link:
 li a7, SYS_link
     fd0:	48cd                	li	a7,19
 ecall
     fd2:	00000073          	ecall
 ret
     fd6:	8082                	ret

0000000000000fd8 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
     fd8:	48d1                	li	a7,20
 ecall
     fda:	00000073          	ecall
 ret
     fde:	8082                	ret

0000000000000fe0 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
     fe0:	48a5                	li	a7,9
 ecall
     fe2:	00000073          	ecall
 ret
     fe6:	8082                	ret

0000000000000fe8 <dup>:
.global dup
dup:
 li a7, SYS_dup
     fe8:	48a9                	li	a7,10
 ecall
     fea:	00000073          	ecall
 ret
     fee:	8082                	ret

0000000000000ff0 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
     ff0:	48ad                	li	a7,11
 ecall
     ff2:	00000073          	ecall
 ret
     ff6:	8082                	ret

0000000000000ff8 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
     ff8:	48b1                	li	a7,12
 ecall
     ffa:	00000073          	ecall
 ret
     ffe:	8082                	ret

0000000000001000 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
    1000:	48b5                	li	a7,13
 ecall
    1002:	00000073          	ecall
 ret
    1006:	8082                	ret

0000000000001008 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
    1008:	48b9                	li	a7,14
 ecall
    100a:	00000073          	ecall
 ret
    100e:	8082                	ret

0000000000001010 <mmap>:
.global mmap
mmap:
 li a7, SYS_mmap
    1010:	48d9                	li	a7,22
 ecall
    1012:	00000073          	ecall
 ret
    1016:	8082                	ret

0000000000001018 <munmap>:
.global munmap
munmap:
 li a7, SYS_munmap
    1018:	48dd                	li	a7,23
 ecall
    101a:	00000073          	ecall
 ret
    101e:	8082                	ret

0000000000001020 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
    1020:	1101                	addi	sp,sp,-32
    1022:	ec06                	sd	ra,24(sp)
    1024:	e822                	sd	s0,16(sp)
    1026:	1000                	addi	s0,sp,32
    1028:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
    102c:	4605                	li	a2,1
    102e:	fef40593          	addi	a1,s0,-17
    1032:	f5fff0ef          	jal	f90 <write>
}
    1036:	60e2                	ld	ra,24(sp)
    1038:	6442                	ld	s0,16(sp)
    103a:	6105                	addi	sp,sp,32
    103c:	8082                	ret

000000000000103e <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
    103e:	7139                	addi	sp,sp,-64
    1040:	fc06                	sd	ra,56(sp)
    1042:	f822                	sd	s0,48(sp)
    1044:	f04a                	sd	s2,32(sp)
    1046:	ec4e                	sd	s3,24(sp)
    1048:	0080                	addi	s0,sp,64
    104a:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    104c:	cac9                	beqz	a3,10de <printint+0xa0>
    104e:	01f5d79b          	srliw	a5,a1,0x1f
    1052:	c7d1                	beqz	a5,10de <printint+0xa0>
    neg = 1;
    x = -xx;
    1054:	40b005bb          	negw	a1,a1
    neg = 1;
    1058:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
    105a:	fc040993          	addi	s3,s0,-64
  neg = 0;
    105e:	86ce                	mv	a3,s3
  i = 0;
    1060:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
    1062:	00001817          	auipc	a6,0x1
    1066:	cbe80813          	addi	a6,a6,-834 # 1d20 <digits>
    106a:	88ba                	mv	a7,a4
    106c:	0017051b          	addiw	a0,a4,1
    1070:	872a                	mv	a4,a0
    1072:	02c5f7bb          	remuw	a5,a1,a2
    1076:	1782                	slli	a5,a5,0x20
    1078:	9381                	srli	a5,a5,0x20
    107a:	97c2                	add	a5,a5,a6
    107c:	0007c783          	lbu	a5,0(a5)
    1080:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
    1084:	87ae                	mv	a5,a1
    1086:	02c5d5bb          	divuw	a1,a1,a2
    108a:	0685                	addi	a3,a3,1
    108c:	fcc7ffe3          	bgeu	a5,a2,106a <printint+0x2c>
  if(neg)
    1090:	00030c63          	beqz	t1,10a8 <printint+0x6a>
    buf[i++] = '-';
    1094:	fd050793          	addi	a5,a0,-48
    1098:	00878533          	add	a0,a5,s0
    109c:	02d00793          	li	a5,45
    10a0:	fef50823          	sb	a5,-16(a0)
    10a4:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    10a8:	02e05563          	blez	a4,10d2 <printint+0x94>
    10ac:	f426                	sd	s1,40(sp)
    10ae:	377d                	addiw	a4,a4,-1
    10b0:	00e984b3          	add	s1,s3,a4
    10b4:	19fd                	addi	s3,s3,-1
    10b6:	99ba                	add	s3,s3,a4
    10b8:	1702                	slli	a4,a4,0x20
    10ba:	9301                	srli	a4,a4,0x20
    10bc:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
    10c0:	0004c583          	lbu	a1,0(s1)
    10c4:	854a                	mv	a0,s2
    10c6:	f5bff0ef          	jal	1020 <putc>
  while(--i >= 0)
    10ca:	14fd                	addi	s1,s1,-1
    10cc:	ff349ae3          	bne	s1,s3,10c0 <printint+0x82>
    10d0:	74a2                	ld	s1,40(sp)
}
    10d2:	70e2                	ld	ra,56(sp)
    10d4:	7442                	ld	s0,48(sp)
    10d6:	7902                	ld	s2,32(sp)
    10d8:	69e2                	ld	s3,24(sp)
    10da:	6121                	addi	sp,sp,64
    10dc:	8082                	ret
  neg = 0;
    10de:	4301                	li	t1,0
    10e0:	bfad                	j	105a <printint+0x1c>

00000000000010e2 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
    10e2:	711d                	addi	sp,sp,-96
    10e4:	ec86                	sd	ra,88(sp)
    10e6:	e8a2                	sd	s0,80(sp)
    10e8:	e4a6                	sd	s1,72(sp)
    10ea:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
    10ec:	0005c483          	lbu	s1,0(a1)
    10f0:	20048963          	beqz	s1,1302 <vprintf+0x220>
    10f4:	e0ca                	sd	s2,64(sp)
    10f6:	fc4e                	sd	s3,56(sp)
    10f8:	f852                	sd	s4,48(sp)
    10fa:	f456                	sd	s5,40(sp)
    10fc:	f05a                	sd	s6,32(sp)
    10fe:	ec5e                	sd	s7,24(sp)
    1100:	e862                	sd	s8,16(sp)
    1102:	8b2a                	mv	s6,a0
    1104:	8a2e                	mv	s4,a1
    1106:	8bb2                	mv	s7,a2
  state = 0;
    1108:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
    110a:	4901                	li	s2,0
    110c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
    110e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
    1112:	06400c13          	li	s8,100
    1116:	a00d                	j	1138 <vprintf+0x56>
        putc(fd, c0);
    1118:	85a6                	mv	a1,s1
    111a:	855a                	mv	a0,s6
    111c:	f05ff0ef          	jal	1020 <putc>
    1120:	a019                	j	1126 <vprintf+0x44>
    } else if(state == '%'){
    1122:	03598363          	beq	s3,s5,1148 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
    1126:	0019079b          	addiw	a5,s2,1
    112a:	893e                	mv	s2,a5
    112c:	873e                	mv	a4,a5
    112e:	97d2                	add	a5,a5,s4
    1130:	0007c483          	lbu	s1,0(a5)
    1134:	1c048063          	beqz	s1,12f4 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
    1138:	0004879b          	sext.w	a5,s1
    if(state == 0){
    113c:	fe0993e3          	bnez	s3,1122 <vprintf+0x40>
      if(c0 == '%'){
    1140:	fd579ce3          	bne	a5,s5,1118 <vprintf+0x36>
        state = '%';
    1144:	89be                	mv	s3,a5
    1146:	b7c5                	j	1126 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
    1148:	00ea06b3          	add	a3,s4,a4
    114c:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
    1150:	1a060e63          	beqz	a2,130c <vprintf+0x22a>
      if(c0 == 'd'){
    1154:	03878763          	beq	a5,s8,1182 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
    1158:	f9478693          	addi	a3,a5,-108
    115c:	0016b693          	seqz	a3,a3
    1160:	f9c60593          	addi	a1,a2,-100
    1164:	e99d                	bnez	a1,119a <vprintf+0xb8>
    1166:	ca95                	beqz	a3,119a <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
    1168:	008b8493          	addi	s1,s7,8
    116c:	4685                	li	a3,1
    116e:	4629                	li	a2,10
    1170:	000ba583          	lw	a1,0(s7)
    1174:	855a                	mv	a0,s6
    1176:	ec9ff0ef          	jal	103e <printint>
        i += 1;
    117a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
    117c:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
    117e:	4981                	li	s3,0
    1180:	b75d                	j	1126 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
    1182:	008b8493          	addi	s1,s7,8
    1186:	4685                	li	a3,1
    1188:	4629                	li	a2,10
    118a:	000ba583          	lw	a1,0(s7)
    118e:	855a                	mv	a0,s6
    1190:	eafff0ef          	jal	103e <printint>
    1194:	8ba6                	mv	s7,s1
      state = 0;
    1196:	4981                	li	s3,0
    1198:	b779                	j	1126 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
    119a:	9752                	add	a4,a4,s4
    119c:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    11a0:	f9460713          	addi	a4,a2,-108
    11a4:	00173713          	seqz	a4,a4
    11a8:	8f75                	and	a4,a4,a3
    11aa:	f9c58513          	addi	a0,a1,-100
    11ae:	16051963          	bnez	a0,1320 <vprintf+0x23e>
    11b2:	16070763          	beqz	a4,1320 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
    11b6:	008b8493          	addi	s1,s7,8
    11ba:	4685                	li	a3,1
    11bc:	4629                	li	a2,10
    11be:	000ba583          	lw	a1,0(s7)
    11c2:	855a                	mv	a0,s6
    11c4:	e7bff0ef          	jal	103e <printint>
        i += 2;
    11c8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
    11ca:	8ba6                	mv	s7,s1
      state = 0;
    11cc:	4981                	li	s3,0
        i += 2;
    11ce:	bfa1                	j	1126 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
    11d0:	008b8493          	addi	s1,s7,8
    11d4:	4681                	li	a3,0
    11d6:	4629                	li	a2,10
    11d8:	000ba583          	lw	a1,0(s7)
    11dc:	855a                	mv	a0,s6
    11de:	e61ff0ef          	jal	103e <printint>
    11e2:	8ba6                	mv	s7,s1
      state = 0;
    11e4:	4981                	li	s3,0
    11e6:	b781                	j	1126 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    11e8:	008b8493          	addi	s1,s7,8
    11ec:	4681                	li	a3,0
    11ee:	4629                	li	a2,10
    11f0:	000ba583          	lw	a1,0(s7)
    11f4:	855a                	mv	a0,s6
    11f6:	e49ff0ef          	jal	103e <printint>
        i += 1;
    11fa:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
    11fc:	8ba6                	mv	s7,s1
      state = 0;
    11fe:	4981                	li	s3,0
    1200:	b71d                	j	1126 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    1202:	008b8493          	addi	s1,s7,8
    1206:	4681                	li	a3,0
    1208:	4629                	li	a2,10
    120a:	000ba583          	lw	a1,0(s7)
    120e:	855a                	mv	a0,s6
    1210:	e2fff0ef          	jal	103e <printint>
        i += 2;
    1214:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
    1216:	8ba6                	mv	s7,s1
      state = 0;
    1218:	4981                	li	s3,0
        i += 2;
    121a:	b731                	j	1126 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
    121c:	008b8493          	addi	s1,s7,8
    1220:	4681                	li	a3,0
    1222:	4641                	li	a2,16
    1224:	000ba583          	lw	a1,0(s7)
    1228:	855a                	mv	a0,s6
    122a:	e15ff0ef          	jal	103e <printint>
    122e:	8ba6                	mv	s7,s1
      state = 0;
    1230:	4981                	li	s3,0
    1232:	bdd5                	j	1126 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    1234:	008b8493          	addi	s1,s7,8
    1238:	4681                	li	a3,0
    123a:	4641                	li	a2,16
    123c:	000ba583          	lw	a1,0(s7)
    1240:	855a                	mv	a0,s6
    1242:	dfdff0ef          	jal	103e <printint>
        i += 1;
    1246:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
    1248:	8ba6                	mv	s7,s1
      state = 0;
    124a:	4981                	li	s3,0
    124c:	bde9                	j	1126 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    124e:	008b8493          	addi	s1,s7,8
    1252:	4681                	li	a3,0
    1254:	4641                	li	a2,16
    1256:	000ba583          	lw	a1,0(s7)
    125a:	855a                	mv	a0,s6
    125c:	de3ff0ef          	jal	103e <printint>
        i += 2;
    1260:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
    1262:	8ba6                	mv	s7,s1
      state = 0;
    1264:	4981                	li	s3,0
        i += 2;
    1266:	b5c1                	j	1126 <vprintf+0x44>
    1268:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
    126a:	008b8793          	addi	a5,s7,8
    126e:	8cbe                	mv	s9,a5
    1270:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
    1274:	03000593          	li	a1,48
    1278:	855a                	mv	a0,s6
    127a:	da7ff0ef          	jal	1020 <putc>
  putc(fd, 'x');
    127e:	07800593          	li	a1,120
    1282:	855a                	mv	a0,s6
    1284:	d9dff0ef          	jal	1020 <putc>
    1288:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    128a:	00001b97          	auipc	s7,0x1
    128e:	a96b8b93          	addi	s7,s7,-1386 # 1d20 <digits>
    1292:	03c9d793          	srli	a5,s3,0x3c
    1296:	97de                	add	a5,a5,s7
    1298:	0007c583          	lbu	a1,0(a5)
    129c:	855a                	mv	a0,s6
    129e:	d83ff0ef          	jal	1020 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    12a2:	0992                	slli	s3,s3,0x4
    12a4:	34fd                	addiw	s1,s1,-1
    12a6:	f4f5                	bnez	s1,1292 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
    12a8:	8be6                	mv	s7,s9
      state = 0;
    12aa:	4981                	li	s3,0
    12ac:	6ca2                	ld	s9,8(sp)
    12ae:	bda5                	j	1126 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
    12b0:	008b8993          	addi	s3,s7,8
    12b4:	000bb483          	ld	s1,0(s7)
    12b8:	cc91                	beqz	s1,12d4 <vprintf+0x1f2>
        for(; *s; s++)
    12ba:	0004c583          	lbu	a1,0(s1)
    12be:	c985                	beqz	a1,12ee <vprintf+0x20c>
          putc(fd, *s);
    12c0:	855a                	mv	a0,s6
    12c2:	d5fff0ef          	jal	1020 <putc>
        for(; *s; s++)
    12c6:	0485                	addi	s1,s1,1
    12c8:	0004c583          	lbu	a1,0(s1)
    12cc:	f9f5                	bnez	a1,12c0 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
    12ce:	8bce                	mv	s7,s3
      state = 0;
    12d0:	4981                	li	s3,0
    12d2:	bd91                	j	1126 <vprintf+0x44>
          s = "(null)";
    12d4:	00001497          	auipc	s1,0x1
    12d8:	a4448493          	addi	s1,s1,-1468 # 1d18 <malloc+0x8b0>
        for(; *s; s++)
    12dc:	02800593          	li	a1,40
    12e0:	b7c5                	j	12c0 <vprintf+0x1de>
        putc(fd, '%');
    12e2:	85be                	mv	a1,a5
    12e4:	855a                	mv	a0,s6
    12e6:	d3bff0ef          	jal	1020 <putc>
      state = 0;
    12ea:	4981                	li	s3,0
    12ec:	bd2d                	j	1126 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
    12ee:	8bce                	mv	s7,s3
      state = 0;
    12f0:	4981                	li	s3,0
    12f2:	bd15                	j	1126 <vprintf+0x44>
    12f4:	6906                	ld	s2,64(sp)
    12f6:	79e2                	ld	s3,56(sp)
    12f8:	7a42                	ld	s4,48(sp)
    12fa:	7aa2                	ld	s5,40(sp)
    12fc:	7b02                	ld	s6,32(sp)
    12fe:	6be2                	ld	s7,24(sp)
    1300:	6c42                	ld	s8,16(sp)
    }
  }
}
    1302:	60e6                	ld	ra,88(sp)
    1304:	6446                	ld	s0,80(sp)
    1306:	64a6                	ld	s1,72(sp)
    1308:	6125                	addi	sp,sp,96
    130a:	8082                	ret
      if(c0 == 'd'){
    130c:	06400713          	li	a4,100
    1310:	e6e789e3          	beq	a5,a4,1182 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
    1314:	f9478693          	addi	a3,a5,-108
    1318:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
    131c:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    131e:	4701                	li	a4,0
      } else if(c0 == 'u'){
    1320:	07500513          	li	a0,117
    1324:	eaa786e3          	beq	a5,a0,11d0 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
    1328:	f8b60513          	addi	a0,a2,-117
    132c:	e119                	bnez	a0,1332 <vprintf+0x250>
    132e:	ea069de3          	bnez	a3,11e8 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    1332:	f8b58513          	addi	a0,a1,-117
    1336:	e119                	bnez	a0,133c <vprintf+0x25a>
    1338:	ec0715e3          	bnez	a4,1202 <vprintf+0x120>
      } else if(c0 == 'x'){
    133c:	07800513          	li	a0,120
    1340:	eca78ee3          	beq	a5,a0,121c <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
    1344:	f8860613          	addi	a2,a2,-120
    1348:	e219                	bnez	a2,134e <vprintf+0x26c>
    134a:	ee0695e3          	bnez	a3,1234 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    134e:	f8858593          	addi	a1,a1,-120
    1352:	e199                	bnez	a1,1358 <vprintf+0x276>
    1354:	ee071de3          	bnez	a4,124e <vprintf+0x16c>
      } else if(c0 == 'p'){
    1358:	07000713          	li	a4,112
    135c:	f0e786e3          	beq	a5,a4,1268 <vprintf+0x186>
      } else if(c0 == 's'){
    1360:	07300713          	li	a4,115
    1364:	f4e786e3          	beq	a5,a4,12b0 <vprintf+0x1ce>
      } else if(c0 == '%'){
    1368:	02500713          	li	a4,37
    136c:	f6e78be3          	beq	a5,a4,12e2 <vprintf+0x200>
        putc(fd, '%');
    1370:	02500593          	li	a1,37
    1374:	855a                	mv	a0,s6
    1376:	cabff0ef          	jal	1020 <putc>
        putc(fd, c0);
    137a:	85a6                	mv	a1,s1
    137c:	855a                	mv	a0,s6
    137e:	ca3ff0ef          	jal	1020 <putc>
      state = 0;
    1382:	4981                	li	s3,0
    1384:	b34d                	j	1126 <vprintf+0x44>

0000000000001386 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    1386:	715d                	addi	sp,sp,-80
    1388:	ec06                	sd	ra,24(sp)
    138a:	e822                	sd	s0,16(sp)
    138c:	1000                	addi	s0,sp,32
    138e:	e010                	sd	a2,0(s0)
    1390:	e414                	sd	a3,8(s0)
    1392:	e818                	sd	a4,16(s0)
    1394:	ec1c                	sd	a5,24(s0)
    1396:	03043023          	sd	a6,32(s0)
    139a:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    139e:	8622                	mv	a2,s0
    13a0:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    13a4:	d3fff0ef          	jal	10e2 <vprintf>
}
    13a8:	60e2                	ld	ra,24(sp)
    13aa:	6442                	ld	s0,16(sp)
    13ac:	6161                	addi	sp,sp,80
    13ae:	8082                	ret

00000000000013b0 <printf>:

void
printf(const char *fmt, ...)
{
    13b0:	711d                	addi	sp,sp,-96
    13b2:	ec06                	sd	ra,24(sp)
    13b4:	e822                	sd	s0,16(sp)
    13b6:	1000                	addi	s0,sp,32
    13b8:	e40c                	sd	a1,8(s0)
    13ba:	e810                	sd	a2,16(s0)
    13bc:	ec14                	sd	a3,24(s0)
    13be:	f018                	sd	a4,32(s0)
    13c0:	f41c                	sd	a5,40(s0)
    13c2:	03043823          	sd	a6,48(s0)
    13c6:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    13ca:	00840613          	addi	a2,s0,8
    13ce:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    13d2:	85aa                	mv	a1,a0
    13d4:	4505                	li	a0,1
    13d6:	d0dff0ef          	jal	10e2 <vprintf>
}
    13da:	60e2                	ld	ra,24(sp)
    13dc:	6442                	ld	s0,16(sp)
    13de:	6125                	addi	sp,sp,96
    13e0:	8082                	ret

00000000000013e2 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    13e2:	1141                	addi	sp,sp,-16
    13e4:	e406                	sd	ra,8(sp)
    13e6:	e022                	sd	s0,0(sp)
    13e8:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    13ea:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    13ee:	00001797          	auipc	a5,0x1
    13f2:	c127b783          	ld	a5,-1006(a5) # 2000 <freep>
    13f6:	a039                	j	1404 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    13f8:	6398                	ld	a4,0(a5)
    13fa:	00e7e463          	bltu	a5,a4,1402 <free+0x20>
    13fe:	00e6ea63          	bltu	a3,a4,1412 <free+0x30>
{
    1402:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1404:	fed7fae3          	bgeu	a5,a3,13f8 <free+0x16>
    1408:	6398                	ld	a4,0(a5)
    140a:	00e6e463          	bltu	a3,a4,1412 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    140e:	fee7eae3          	bltu	a5,a4,1402 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
    1412:	ff852583          	lw	a1,-8(a0)
    1416:	6390                	ld	a2,0(a5)
    1418:	02059813          	slli	a6,a1,0x20
    141c:	01c85713          	srli	a4,a6,0x1c
    1420:	9736                	add	a4,a4,a3
    1422:	02e60563          	beq	a2,a4,144c <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    1426:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    142a:	4790                	lw	a2,8(a5)
    142c:	02061593          	slli	a1,a2,0x20
    1430:	01c5d713          	srli	a4,a1,0x1c
    1434:	973e                	add	a4,a4,a5
    1436:	02e68263          	beq	a3,a4,145a <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    143a:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    143c:	00001717          	auipc	a4,0x1
    1440:	bcf73223          	sd	a5,-1084(a4) # 2000 <freep>
}
    1444:	60a2                	ld	ra,8(sp)
    1446:	6402                	ld	s0,0(sp)
    1448:	0141                	addi	sp,sp,16
    144a:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    144c:	4618                	lw	a4,8(a2)
    144e:	9f2d                	addw	a4,a4,a1
    1450:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    1454:	6398                	ld	a4,0(a5)
    1456:	6310                	ld	a2,0(a4)
    1458:	b7f9                	j	1426 <free+0x44>
    p->s.size += bp->s.size;
    145a:	ff852703          	lw	a4,-8(a0)
    145e:	9f31                	addw	a4,a4,a2
    1460:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    1462:	ff053683          	ld	a3,-16(a0)
    1466:	bfd1                	j	143a <free+0x58>

0000000000001468 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1468:	7139                	addi	sp,sp,-64
    146a:	fc06                	sd	ra,56(sp)
    146c:	f822                	sd	s0,48(sp)
    146e:	f04a                	sd	s2,32(sp)
    1470:	ec4e                	sd	s3,24(sp)
    1472:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1474:	02051993          	slli	s3,a0,0x20
    1478:	0209d993          	srli	s3,s3,0x20
    147c:	09bd                	addi	s3,s3,15
    147e:	0049d993          	srli	s3,s3,0x4
    1482:	2985                	addiw	s3,s3,1
    1484:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
    1486:	00001517          	auipc	a0,0x1
    148a:	b7a53503          	ld	a0,-1158(a0) # 2000 <freep>
    148e:	c905                	beqz	a0,14be <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1490:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    1492:	4798                	lw	a4,8(a5)
    1494:	09377663          	bgeu	a4,s3,1520 <malloc+0xb8>
    1498:	f426                	sd	s1,40(sp)
    149a:	e852                	sd	s4,16(sp)
    149c:	e456                	sd	s5,8(sp)
    149e:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
    14a0:	8a4e                	mv	s4,s3
    14a2:	6705                	lui	a4,0x1
    14a4:	00e9f363          	bgeu	s3,a4,14aa <malloc+0x42>
    14a8:	6a05                	lui	s4,0x1
    14aa:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    14ae:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    14b2:	00001497          	auipc	s1,0x1
    14b6:	b4e48493          	addi	s1,s1,-1202 # 2000 <freep>
  if(p == (char*)-1)
    14ba:	5afd                	li	s5,-1
    14bc:	a83d                	j	14fa <malloc+0x92>
    14be:	f426                	sd	s1,40(sp)
    14c0:	e852                	sd	s4,16(sp)
    14c2:	e456                	sd	s5,8(sp)
    14c4:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    14c6:	00002797          	auipc	a5,0x2
    14ca:	b4a78793          	addi	a5,a5,-1206 # 3010 <base>
    14ce:	00001717          	auipc	a4,0x1
    14d2:	b2f73923          	sd	a5,-1230(a4) # 2000 <freep>
    14d6:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    14d8:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    14dc:	b7d1                	j	14a0 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    14de:	6398                	ld	a4,0(a5)
    14e0:	e118                	sd	a4,0(a0)
    14e2:	a899                	j	1538 <malloc+0xd0>
  hp->s.size = nu;
    14e4:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    14e8:	0541                	addi	a0,a0,16
    14ea:	ef9ff0ef          	jal	13e2 <free>
  return freep;
    14ee:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
    14f0:	c125                	beqz	a0,1550 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    14f2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    14f4:	4798                	lw	a4,8(a5)
    14f6:	03277163          	bgeu	a4,s2,1518 <malloc+0xb0>
    if(p == freep)
    14fa:	6098                	ld	a4,0(s1)
    14fc:	853e                	mv	a0,a5
    14fe:	fef71ae3          	bne	a4,a5,14f2 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    1502:	8552                	mv	a0,s4
    1504:	af5ff0ef          	jal	ff8 <sbrk>
  if(p == (char*)-1)
    1508:	fd551ee3          	bne	a0,s5,14e4 <malloc+0x7c>
        return 0;
    150c:	4501                	li	a0,0
    150e:	74a2                	ld	s1,40(sp)
    1510:	6a42                	ld	s4,16(sp)
    1512:	6aa2                	ld	s5,8(sp)
    1514:	6b02                	ld	s6,0(sp)
    1516:	a03d                	j	1544 <malloc+0xdc>
    1518:	74a2                	ld	s1,40(sp)
    151a:	6a42                	ld	s4,16(sp)
    151c:	6aa2                	ld	s5,8(sp)
    151e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
    1520:	fae90fe3          	beq	s2,a4,14de <malloc+0x76>
        p->s.size -= nunits;
    1524:	4137073b          	subw	a4,a4,s3
    1528:	c798                	sw	a4,8(a5)
        p += p->s.size;
    152a:	02071693          	slli	a3,a4,0x20
    152e:	01c6d713          	srli	a4,a3,0x1c
    1532:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    1534:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    1538:	00001717          	auipc	a4,0x1
    153c:	aca73423          	sd	a0,-1336(a4) # 2000 <freep>
      return (void*)(p + 1);
    1540:	01078513          	addi	a0,a5,16
  }
}
    1544:	70e2                	ld	ra,56(sp)
    1546:	7442                	ld	s0,48(sp)
    1548:	7902                	ld	s2,32(sp)
    154a:	69e2                	ld	s3,24(sp)
    154c:	6121                	addi	sp,sp,64
    154e:	8082                	ret
    1550:	74a2                	ld	s1,40(sp)
    1552:	6a42                	ld	s4,16(sp)
    1554:	6aa2                	ld	s5,8(sp)
    1556:	6b02                	ld	s6,0(sp)
    1558:	b7f5                	j	1544 <malloc+0xdc>
