kernel/trap.o: kernel/trap.c kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/riscv.h kernel/spinlock.h kernel/proc.h \
 kernel/defs.h kernel/file.h kernel/sleeplock.h kernel/fs.h \
 kernel/fcntl.h
