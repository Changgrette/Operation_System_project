
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00025117          	auipc	sp,0x25
    80000004:	b3010113          	addi	sp,sp,-1232 # 80024b30 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	240050ef          	jal	80005256 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	0002d797          	auipc	a5,0x2d
    8000002c:	c0878793          	addi	a5,a5,-1016 # 8002cc30 <end>
    80000030:	00f53733          	sltu	a4,a0,a5
    80000034:	47c5                	li	a5,17
    80000036:	07ee                	slli	a5,a5,0x1b
    80000038:	17fd                	addi	a5,a5,-1
    8000003a:	00a7b7b3          	sltu	a5,a5,a0
    8000003e:	8fd9                	or	a5,a5,a4
    80000040:	ef95                	bnez	a5,8000007c <kfree+0x60>
    80000042:	84aa                	mv	s1,a0
    80000044:	03451793          	slli	a5,a0,0x34
    80000048:	eb95                	bnez	a5,8000007c <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    8000004a:	6605                	lui	a2,0x1
    8000004c:	4585                	li	a1,1
    8000004e:	110000ef          	jal	8000015e <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000052:	00008917          	auipc	s2,0x8
    80000056:	8ae90913          	addi	s2,s2,-1874 # 80007900 <kmem>
    8000005a:	854a                	mv	a0,s2
    8000005c:	4b1050ef          	jal	80005d0c <acquire>
  r->next = kmem.freelist;
    80000060:	01893783          	ld	a5,24(s2)
    80000064:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000066:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    8000006a:	854a                	mv	a0,s2
    8000006c:	535050ef          	jal	80005da0 <release>
}
    80000070:	60e2                	ld	ra,24(sp)
    80000072:	6442                	ld	s0,16(sp)
    80000074:	64a2                	ld	s1,8(sp)
    80000076:	6902                	ld	s2,0(sp)
    80000078:	6105                	addi	sp,sp,32
    8000007a:	8082                	ret
    panic("kfree");
    8000007c:	00007517          	auipc	a0,0x7
    80000080:	f8450513          	addi	a0,a0,-124 # 80007000 <etext>
    80000084:	14b050ef          	jal	800059ce <panic>

0000000080000088 <freerange>:
{
    80000088:	7179                	addi	sp,sp,-48
    8000008a:	f406                	sd	ra,40(sp)
    8000008c:	f022                	sd	s0,32(sp)
    8000008e:	ec26                	sd	s1,24(sp)
    80000090:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000092:	6785                	lui	a5,0x1
    80000094:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000098:	00e504b3          	add	s1,a0,a4
    8000009c:	777d                	lui	a4,0xfffff
    8000009e:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000a0:	94be                	add	s1,s1,a5
    800000a2:	0295e263          	bltu	a1,s1,800000c6 <freerange+0x3e>
    800000a6:	e84a                	sd	s2,16(sp)
    800000a8:	e44e                	sd	s3,8(sp)
    800000aa:	e052                	sd	s4,0(sp)
    800000ac:	892e                	mv	s2,a1
    kfree(p);
    800000ae:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000b0:	89be                	mv	s3,a5
    kfree(p);
    800000b2:	01448533          	add	a0,s1,s4
    800000b6:	f67ff0ef          	jal	8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000ba:	94ce                	add	s1,s1,s3
    800000bc:	fe997be3          	bgeu	s2,s1,800000b2 <freerange+0x2a>
    800000c0:	6942                	ld	s2,16(sp)
    800000c2:	69a2                	ld	s3,8(sp)
    800000c4:	6a02                	ld	s4,0(sp)
}
    800000c6:	70a2                	ld	ra,40(sp)
    800000c8:	7402                	ld	s0,32(sp)
    800000ca:	64e2                	ld	s1,24(sp)
    800000cc:	6145                	addi	sp,sp,48
    800000ce:	8082                	ret

00000000800000d0 <kinit>:
{
    800000d0:	1141                	addi	sp,sp,-16
    800000d2:	e406                	sd	ra,8(sp)
    800000d4:	e022                	sd	s0,0(sp)
    800000d6:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d8:	00007597          	auipc	a1,0x7
    800000dc:	f3858593          	addi	a1,a1,-200 # 80007010 <etext+0x10>
    800000e0:	00008517          	auipc	a0,0x8
    800000e4:	82050513          	addi	a0,a0,-2016 # 80007900 <kmem>
    800000e8:	39b050ef          	jal	80005c82 <initlock>
  freerange(end, (void*)PHYSTOP);
    800000ec:	45c5                	li	a1,17
    800000ee:	05ee                	slli	a1,a1,0x1b
    800000f0:	0002d517          	auipc	a0,0x2d
    800000f4:	b4050513          	addi	a0,a0,-1216 # 8002cc30 <end>
    800000f8:	f91ff0ef          	jal	80000088 <freerange>
}
    800000fc:	60a2                	ld	ra,8(sp)
    800000fe:	6402                	ld	s0,0(sp)
    80000100:	0141                	addi	sp,sp,16
    80000102:	8082                	ret

0000000080000104 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000104:	1101                	addi	sp,sp,-32
    80000106:	ec06                	sd	ra,24(sp)
    80000108:	e822                	sd	s0,16(sp)
    8000010a:	e426                	sd	s1,8(sp)
    8000010c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    8000010e:	00007517          	auipc	a0,0x7
    80000112:	7f250513          	addi	a0,a0,2034 # 80007900 <kmem>
    80000116:	3f7050ef          	jal	80005d0c <acquire>
  r = kmem.freelist;
    8000011a:	00007497          	auipc	s1,0x7
    8000011e:	7fe4b483          	ld	s1,2046(s1) # 80007918 <kmem+0x18>
  if(r)
    80000122:	c49d                	beqz	s1,80000150 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000124:	609c                	ld	a5,0(s1)
    80000126:	00007717          	auipc	a4,0x7
    8000012a:	7ef73923          	sd	a5,2034(a4) # 80007918 <kmem+0x18>
  release(&kmem.lock);
    8000012e:	00007517          	auipc	a0,0x7
    80000132:	7d250513          	addi	a0,a0,2002 # 80007900 <kmem>
    80000136:	46b050ef          	jal	80005da0 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    8000013a:	6605                	lui	a2,0x1
    8000013c:	4595                	li	a1,5
    8000013e:	8526                	mv	a0,s1
    80000140:	01e000ef          	jal	8000015e <memset>
  return (void*)r;
}
    80000144:	8526                	mv	a0,s1
    80000146:	60e2                	ld	ra,24(sp)
    80000148:	6442                	ld	s0,16(sp)
    8000014a:	64a2                	ld	s1,8(sp)
    8000014c:	6105                	addi	sp,sp,32
    8000014e:	8082                	ret
  release(&kmem.lock);
    80000150:	00007517          	auipc	a0,0x7
    80000154:	7b050513          	addi	a0,a0,1968 # 80007900 <kmem>
    80000158:	449050ef          	jal	80005da0 <release>
  if(r)
    8000015c:	b7e5                	j	80000144 <kalloc+0x40>

000000008000015e <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000015e:	1141                	addi	sp,sp,-16
    80000160:	e406                	sd	ra,8(sp)
    80000162:	e022                	sd	s0,0(sp)
    80000164:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000166:	ca19                	beqz	a2,8000017c <memset+0x1e>
    80000168:	87aa                	mv	a5,a0
    8000016a:	1602                	slli	a2,a2,0x20
    8000016c:	9201                	srli	a2,a2,0x20
    8000016e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000172:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000176:	0785                	addi	a5,a5,1
    80000178:	fee79de3          	bne	a5,a4,80000172 <memset+0x14>
  }
  return dst;
}
    8000017c:	60a2                	ld	ra,8(sp)
    8000017e:	6402                	ld	s0,0(sp)
    80000180:	0141                	addi	sp,sp,16
    80000182:	8082                	ret

0000000080000184 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000184:	1141                	addi	sp,sp,-16
    80000186:	e406                	sd	ra,8(sp)
    80000188:	e022                	sd	s0,0(sp)
    8000018a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    8000018c:	c61d                	beqz	a2,800001ba <memcmp+0x36>
    8000018e:	1602                	slli	a2,a2,0x20
    80000190:	9201                	srli	a2,a2,0x20
    80000192:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000196:	00054783          	lbu	a5,0(a0)
    8000019a:	0005c703          	lbu	a4,0(a1)
    8000019e:	00e79863          	bne	a5,a4,800001ae <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    800001a2:	0505                	addi	a0,a0,1
    800001a4:	0585                	addi	a1,a1,1
  while(n-- > 0){
    800001a6:	fed518e3          	bne	a0,a3,80000196 <memcmp+0x12>
  }

  return 0;
    800001aa:	4501                	li	a0,0
    800001ac:	a019                	j	800001b2 <memcmp+0x2e>
      return *s1 - *s2;
    800001ae:	40e7853b          	subw	a0,a5,a4
}
    800001b2:	60a2                	ld	ra,8(sp)
    800001b4:	6402                	ld	s0,0(sp)
    800001b6:	0141                	addi	sp,sp,16
    800001b8:	8082                	ret
  return 0;
    800001ba:	4501                	li	a0,0
    800001bc:	bfdd                	j	800001b2 <memcmp+0x2e>

00000000800001be <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001be:	1141                	addi	sp,sp,-16
    800001c0:	e406                	sd	ra,8(sp)
    800001c2:	e022                	sd	s0,0(sp)
    800001c4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001c6:	c205                	beqz	a2,800001e6 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001c8:	02a5e363          	bltu	a1,a0,800001ee <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001cc:	1602                	slli	a2,a2,0x20
    800001ce:	9201                	srli	a2,a2,0x20
    800001d0:	00c587b3          	add	a5,a1,a2
{
    800001d4:	872a                	mv	a4,a0
      *d++ = *s++;
    800001d6:	0585                	addi	a1,a1,1
    800001d8:	0705                	addi	a4,a4,1
    800001da:	fff5c683          	lbu	a3,-1(a1)
    800001de:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001e2:	feb79ae3          	bne	a5,a1,800001d6 <memmove+0x18>

  return dst;
}
    800001e6:	60a2                	ld	ra,8(sp)
    800001e8:	6402                	ld	s0,0(sp)
    800001ea:	0141                	addi	sp,sp,16
    800001ec:	8082                	ret
  if(s < d && s + n > d){
    800001ee:	02061693          	slli	a3,a2,0x20
    800001f2:	9281                	srli	a3,a3,0x20
    800001f4:	00d58733          	add	a4,a1,a3
    800001f8:	fce57ae3          	bgeu	a0,a4,800001cc <memmove+0xe>
    d += n;
    800001fc:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001fe:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000202:	1782                	slli	a5,a5,0x20
    80000204:	9381                	srli	a5,a5,0x20
    80000206:	fff7c793          	not	a5,a5
    8000020a:	97ba                	add	a5,a5,a4
      *--d = *--s;
    8000020c:	177d                	addi	a4,a4,-1
    8000020e:	16fd                	addi	a3,a3,-1
    80000210:	00074603          	lbu	a2,0(a4)
    80000214:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000218:	fee79ae3          	bne	a5,a4,8000020c <memmove+0x4e>
    8000021c:	b7e9                	j	800001e6 <memmove+0x28>

000000008000021e <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    8000021e:	1141                	addi	sp,sp,-16
    80000220:	e406                	sd	ra,8(sp)
    80000222:	e022                	sd	s0,0(sp)
    80000224:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000226:	f99ff0ef          	jal	800001be <memmove>
}
    8000022a:	60a2                	ld	ra,8(sp)
    8000022c:	6402                	ld	s0,0(sp)
    8000022e:	0141                	addi	sp,sp,16
    80000230:	8082                	ret

0000000080000232 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000232:	1141                	addi	sp,sp,-16
    80000234:	e406                	sd	ra,8(sp)
    80000236:	e022                	sd	s0,0(sp)
    80000238:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000023a:	ce11                	beqz	a2,80000256 <strncmp+0x24>
    8000023c:	00054783          	lbu	a5,0(a0)
    80000240:	cf89                	beqz	a5,8000025a <strncmp+0x28>
    80000242:	0005c703          	lbu	a4,0(a1)
    80000246:	00f71a63          	bne	a4,a5,8000025a <strncmp+0x28>
    n--, p++, q++;
    8000024a:	367d                	addiw	a2,a2,-1
    8000024c:	0505                	addi	a0,a0,1
    8000024e:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000250:	f675                	bnez	a2,8000023c <strncmp+0xa>
  if(n == 0)
    return 0;
    80000252:	4501                	li	a0,0
    80000254:	a801                	j	80000264 <strncmp+0x32>
    80000256:	4501                	li	a0,0
    80000258:	a031                	j	80000264 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    8000025a:	00054503          	lbu	a0,0(a0)
    8000025e:	0005c783          	lbu	a5,0(a1)
    80000262:	9d1d                	subw	a0,a0,a5
}
    80000264:	60a2                	ld	ra,8(sp)
    80000266:	6402                	ld	s0,0(sp)
    80000268:	0141                	addi	sp,sp,16
    8000026a:	8082                	ret

000000008000026c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    8000026c:	1141                	addi	sp,sp,-16
    8000026e:	e406                	sd	ra,8(sp)
    80000270:	e022                	sd	s0,0(sp)
    80000272:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000274:	87aa                	mv	a5,a0
    80000276:	a011                	j	8000027a <strncpy+0xe>
    80000278:	8636                	mv	a2,a3
    8000027a:	02c05863          	blez	a2,800002aa <strncpy+0x3e>
    8000027e:	fff6069b          	addiw	a3,a2,-1
    80000282:	8836                	mv	a6,a3
    80000284:	0785                	addi	a5,a5,1
    80000286:	0005c703          	lbu	a4,0(a1)
    8000028a:	fee78fa3          	sb	a4,-1(a5)
    8000028e:	0585                	addi	a1,a1,1
    80000290:	f765                	bnez	a4,80000278 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000292:	873e                	mv	a4,a5
    80000294:	01005b63          	blez	a6,800002aa <strncpy+0x3e>
    80000298:	9fb1                	addw	a5,a5,a2
    8000029a:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    8000029c:	0705                	addi	a4,a4,1
    8000029e:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    800002a2:	40e786bb          	subw	a3,a5,a4
    800002a6:	fed04be3          	bgtz	a3,8000029c <strncpy+0x30>
  return os;
}
    800002aa:	60a2                	ld	ra,8(sp)
    800002ac:	6402                	ld	s0,0(sp)
    800002ae:	0141                	addi	sp,sp,16
    800002b0:	8082                	ret

00000000800002b2 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    800002b2:	1141                	addi	sp,sp,-16
    800002b4:	e406                	sd	ra,8(sp)
    800002b6:	e022                	sd	s0,0(sp)
    800002b8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    800002ba:	02c05363          	blez	a2,800002e0 <safestrcpy+0x2e>
    800002be:	fff6069b          	addiw	a3,a2,-1
    800002c2:	1682                	slli	a3,a3,0x20
    800002c4:	9281                	srli	a3,a3,0x20
    800002c6:	96ae                	add	a3,a3,a1
    800002c8:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002ca:	00d58963          	beq	a1,a3,800002dc <safestrcpy+0x2a>
    800002ce:	0585                	addi	a1,a1,1
    800002d0:	0785                	addi	a5,a5,1
    800002d2:	fff5c703          	lbu	a4,-1(a1)
    800002d6:	fee78fa3          	sb	a4,-1(a5)
    800002da:	fb65                	bnez	a4,800002ca <safestrcpy+0x18>
    ;
  *s = 0;
    800002dc:	00078023          	sb	zero,0(a5)
  return os;
}
    800002e0:	60a2                	ld	ra,8(sp)
    800002e2:	6402                	ld	s0,0(sp)
    800002e4:	0141                	addi	sp,sp,16
    800002e6:	8082                	ret

00000000800002e8 <strlen>:

int
strlen(const char *s)
{
    800002e8:	1141                	addi	sp,sp,-16
    800002ea:	e406                	sd	ra,8(sp)
    800002ec:	e022                	sd	s0,0(sp)
    800002ee:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002f0:	00054783          	lbu	a5,0(a0)
    800002f4:	cf91                	beqz	a5,80000310 <strlen+0x28>
    800002f6:	00150793          	addi	a5,a0,1
    800002fa:	86be                	mv	a3,a5
    800002fc:	0785                	addi	a5,a5,1
    800002fe:	fff7c703          	lbu	a4,-1(a5)
    80000302:	ff65                	bnez	a4,800002fa <strlen+0x12>
    80000304:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000308:	60a2                	ld	ra,8(sp)
    8000030a:	6402                	ld	s0,0(sp)
    8000030c:	0141                	addi	sp,sp,16
    8000030e:	8082                	ret
  for(n = 0; s[n]; n++)
    80000310:	4501                	li	a0,0
    80000312:	bfdd                	j	80000308 <strlen+0x20>

0000000080000314 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000314:	1141                	addi	sp,sp,-16
    80000316:	e406                	sd	ra,8(sp)
    80000318:	e022                	sd	s0,0(sp)
    8000031a:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    8000031c:	215000ef          	jal	80000d30 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000320:	00007717          	auipc	a4,0x7
    80000324:	5b070713          	addi	a4,a4,1456 # 800078d0 <started>
  if(cpuid() == 0){
    80000328:	c51d                	beqz	a0,80000356 <main+0x42>
    while(started == 0)
    8000032a:	431c                	lw	a5,0(a4)
    8000032c:	2781                	sext.w	a5,a5
    8000032e:	dff5                	beqz	a5,8000032a <main+0x16>
      ;
    __sync_synchronize();
    80000330:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000334:	1fd000ef          	jal	80000d30 <cpuid>
    80000338:	85aa                	mv	a1,a0
    8000033a:	00007517          	auipc	a0,0x7
    8000033e:	cfe50513          	addi	a0,a0,-770 # 80007038 <etext+0x38>
    80000342:	37c050ef          	jal	800056be <printf>
    kvminithart();    // turn on paging
    80000346:	080000ef          	jal	800003c6 <kvminithart>
    trapinithart();   // install kernel trap vector
    8000034a:	690010ef          	jal	800019da <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    8000034e:	14b040ef          	jal	80004c98 <plicinithart>
  }

  scheduler();        
    80000352:	6c5000ef          	jal	80001216 <scheduler>
    consoleinit();
    80000356:	28e050ef          	jal	800055e4 <consoleinit>
    printfinit();
    8000035a:	6ae050ef          	jal	80005a08 <printfinit>
    printf("\n");
    8000035e:	00007517          	auipc	a0,0x7
    80000362:	cba50513          	addi	a0,a0,-838 # 80007018 <etext+0x18>
    80000366:	358050ef          	jal	800056be <printf>
    printf("xv6 kernel is booting\n");
    8000036a:	00007517          	auipc	a0,0x7
    8000036e:	cb650513          	addi	a0,a0,-842 # 80007020 <etext+0x20>
    80000372:	34c050ef          	jal	800056be <printf>
    printf("\n");
    80000376:	00007517          	auipc	a0,0x7
    8000037a:	ca250513          	addi	a0,a0,-862 # 80007018 <etext+0x18>
    8000037e:	340050ef          	jal	800056be <printf>
    kinit();         // physical page allocator
    80000382:	d4fff0ef          	jal	800000d0 <kinit>
    kvminit();       // create kernel page table
    80000386:	2cc000ef          	jal	80000652 <kvminit>
    kvminithart();   // turn on paging
    8000038a:	03c000ef          	jal	800003c6 <kvminithart>
    procinit();      // process table
    8000038e:	0f1000ef          	jal	80000c7e <procinit>
    trapinit();      // trap vectors
    80000392:	624010ef          	jal	800019b6 <trapinit>
    trapinithart();  // install kernel trap vector
    80000396:	644010ef          	jal	800019da <trapinithart>
    plicinit();      // set up interrupt controller
    8000039a:	0e5040ef          	jal	80004c7e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    8000039e:	0fb040ef          	jal	80004c98 <plicinithart>
    binit();         // buffer cache
    800003a2:	59f010ef          	jal	80002140 <binit>
    iinit();         // inode table
    800003a6:	35a020ef          	jal	80002700 <iinit>
    fileinit();      // file table
    800003aa:	140030ef          	jal	800034ea <fileinit>
    virtio_disk_init(); // emulated hard disk
    800003ae:	1db040ef          	jal	80004d88 <virtio_disk_init>
    userinit();      // first user process
    800003b2:	449000ef          	jal	80000ffa <userinit>
    __sync_synchronize();
    800003b6:	0330000f          	fence	rw,rw
    started = 1;
    800003ba:	4785                	li	a5,1
    800003bc:	00007717          	auipc	a4,0x7
    800003c0:	50f72a23          	sw	a5,1300(a4) # 800078d0 <started>
    800003c4:	b779                	j	80000352 <main+0x3e>

00000000800003c6 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    800003c6:	1141                	addi	sp,sp,-16
    800003c8:	e406                	sd	ra,8(sp)
    800003ca:	e022                	sd	s0,0(sp)
    800003cc:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800003ce:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    800003d2:	00007797          	auipc	a5,0x7
    800003d6:	5067b783          	ld	a5,1286(a5) # 800078d8 <kernel_pagetable>
    800003da:	83b1                	srli	a5,a5,0xc
    800003dc:	577d                	li	a4,-1
    800003de:	177e                	slli	a4,a4,0x3f
    800003e0:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800003e2:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800003e6:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    800003ea:	60a2                	ld	ra,8(sp)
    800003ec:	6402                	ld	s0,0(sp)
    800003ee:	0141                	addi	sp,sp,16
    800003f0:	8082                	ret

00000000800003f2 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800003f2:	7139                	addi	sp,sp,-64
    800003f4:	fc06                	sd	ra,56(sp)
    800003f6:	f822                	sd	s0,48(sp)
    800003f8:	f426                	sd	s1,40(sp)
    800003fa:	f04a                	sd	s2,32(sp)
    800003fc:	ec4e                	sd	s3,24(sp)
    800003fe:	e852                	sd	s4,16(sp)
    80000400:	e456                	sd	s5,8(sp)
    80000402:	e05a                	sd	s6,0(sp)
    80000404:	0080                	addi	s0,sp,64
    80000406:	84aa                	mv	s1,a0
    80000408:	89ae                	mv	s3,a1
    8000040a:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    8000040c:	57fd                	li	a5,-1
    8000040e:	83e9                	srli	a5,a5,0x1a
    80000410:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000412:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000414:	04b7e263          	bltu	a5,a1,80000458 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000418:	0149d933          	srl	s2,s3,s4
    8000041c:	1ff97913          	andi	s2,s2,511
    80000420:	090e                	slli	s2,s2,0x3
    80000422:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000424:	00093483          	ld	s1,0(s2)
    80000428:	0014f793          	andi	a5,s1,1
    8000042c:	cf85                	beqz	a5,80000464 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    8000042e:	80a9                	srli	s1,s1,0xa
    80000430:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80000432:	3a5d                	addiw	s4,s4,-9
    80000434:	ff5a12e3          	bne	s4,s5,80000418 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000438:	00c9d513          	srli	a0,s3,0xc
    8000043c:	1ff57513          	andi	a0,a0,511
    80000440:	050e                	slli	a0,a0,0x3
    80000442:	9526                	add	a0,a0,s1
}
    80000444:	70e2                	ld	ra,56(sp)
    80000446:	7442                	ld	s0,48(sp)
    80000448:	74a2                	ld	s1,40(sp)
    8000044a:	7902                	ld	s2,32(sp)
    8000044c:	69e2                	ld	s3,24(sp)
    8000044e:	6a42                	ld	s4,16(sp)
    80000450:	6aa2                	ld	s5,8(sp)
    80000452:	6b02                	ld	s6,0(sp)
    80000454:	6121                	addi	sp,sp,64
    80000456:	8082                	ret
    panic("walk");
    80000458:	00007517          	auipc	a0,0x7
    8000045c:	bf850513          	addi	a0,a0,-1032 # 80007050 <etext+0x50>
    80000460:	56e050ef          	jal	800059ce <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000464:	020b0263          	beqz	s6,80000488 <walk+0x96>
    80000468:	c9dff0ef          	jal	80000104 <kalloc>
    8000046c:	84aa                	mv	s1,a0
    8000046e:	d979                	beqz	a0,80000444 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80000470:	6605                	lui	a2,0x1
    80000472:	4581                	li	a1,0
    80000474:	cebff0ef          	jal	8000015e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000478:	00c4d793          	srli	a5,s1,0xc
    8000047c:	07aa                	slli	a5,a5,0xa
    8000047e:	0017e793          	ori	a5,a5,1
    80000482:	00f93023          	sd	a5,0(s2)
    80000486:	b775                	j	80000432 <walk+0x40>
        return 0;
    80000488:	4501                	li	a0,0
    8000048a:	bf6d                	j	80000444 <walk+0x52>

000000008000048c <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000048c:	57fd                	li	a5,-1
    8000048e:	83e9                	srli	a5,a5,0x1a
    80000490:	00b7f463          	bgeu	a5,a1,80000498 <walkaddr+0xc>
    return 0;
    80000494:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000496:	8082                	ret
{
    80000498:	1141                	addi	sp,sp,-16
    8000049a:	e406                	sd	ra,8(sp)
    8000049c:	e022                	sd	s0,0(sp)
    8000049e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    800004a0:	4601                	li	a2,0
    800004a2:	f51ff0ef          	jal	800003f2 <walk>
  if(pte == 0)
    800004a6:	c901                	beqz	a0,800004b6 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    800004a8:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    800004aa:	0117f693          	andi	a3,a5,17
    800004ae:	4745                	li	a4,17
    return 0;
    800004b0:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    800004b2:	00e68663          	beq	a3,a4,800004be <walkaddr+0x32>
}
    800004b6:	60a2                	ld	ra,8(sp)
    800004b8:	6402                	ld	s0,0(sp)
    800004ba:	0141                	addi	sp,sp,16
    800004bc:	8082                	ret
  pa = PTE2PA(*pte);
    800004be:	83a9                	srli	a5,a5,0xa
    800004c0:	00c79513          	slli	a0,a5,0xc
  return pa;
    800004c4:	bfcd                	j	800004b6 <walkaddr+0x2a>

00000000800004c6 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800004c6:	715d                	addi	sp,sp,-80
    800004c8:	e486                	sd	ra,72(sp)
    800004ca:	e0a2                	sd	s0,64(sp)
    800004cc:	fc26                	sd	s1,56(sp)
    800004ce:	f84a                	sd	s2,48(sp)
    800004d0:	f44e                	sd	s3,40(sp)
    800004d2:	f052                	sd	s4,32(sp)
    800004d4:	ec56                	sd	s5,24(sp)
    800004d6:	e85a                	sd	s6,16(sp)
    800004d8:	e45e                	sd	s7,8(sp)
    800004da:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800004dc:	03459793          	slli	a5,a1,0x34
    800004e0:	eba1                	bnez	a5,80000530 <mappages+0x6a>
    800004e2:	8a2a                	mv	s4,a0
    800004e4:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800004e6:	03461793          	slli	a5,a2,0x34
    800004ea:	eba9                	bnez	a5,8000053c <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    800004ec:	ce31                	beqz	a2,80000548 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800004ee:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    800004f2:	80060613          	addi	a2,a2,-2048
    800004f6:	00b60933          	add	s2,a2,a1
  a = va;
    800004fa:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800004fc:	4b05                	li	s6,1
    800004fe:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80000502:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    80000504:	865a                	mv	a2,s6
    80000506:	85a6                	mv	a1,s1
    80000508:	8552                	mv	a0,s4
    8000050a:	ee9ff0ef          	jal	800003f2 <walk>
    8000050e:	c929                	beqz	a0,80000560 <mappages+0x9a>
    if(*pte & PTE_V)
    80000510:	611c                	ld	a5,0(a0)
    80000512:	8b85                	andi	a5,a5,1
    80000514:	e3a1                	bnez	a5,80000554 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000516:	013487b3          	add	a5,s1,s3
    8000051a:	83b1                	srli	a5,a5,0xc
    8000051c:	07aa                	slli	a5,a5,0xa
    8000051e:	0157e7b3          	or	a5,a5,s5
    80000522:	0017e793          	ori	a5,a5,1
    80000526:	e11c                	sd	a5,0(a0)
    if(a == last)
    80000528:	05248863          	beq	s1,s2,80000578 <mappages+0xb2>
    a += PGSIZE;
    8000052c:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    8000052e:	bfd9                	j	80000504 <mappages+0x3e>
    panic("mappages: va not aligned");
    80000530:	00007517          	auipc	a0,0x7
    80000534:	b2850513          	addi	a0,a0,-1240 # 80007058 <etext+0x58>
    80000538:	496050ef          	jal	800059ce <panic>
    panic("mappages: size not aligned");
    8000053c:	00007517          	auipc	a0,0x7
    80000540:	b3c50513          	addi	a0,a0,-1220 # 80007078 <etext+0x78>
    80000544:	48a050ef          	jal	800059ce <panic>
    panic("mappages: size");
    80000548:	00007517          	auipc	a0,0x7
    8000054c:	b5050513          	addi	a0,a0,-1200 # 80007098 <etext+0x98>
    80000550:	47e050ef          	jal	800059ce <panic>
      panic("mappages: remap");
    80000554:	00007517          	auipc	a0,0x7
    80000558:	b5450513          	addi	a0,a0,-1196 # 800070a8 <etext+0xa8>
    8000055c:	472050ef          	jal	800059ce <panic>
      return -1;
    80000560:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80000562:	60a6                	ld	ra,72(sp)
    80000564:	6406                	ld	s0,64(sp)
    80000566:	74e2                	ld	s1,56(sp)
    80000568:	7942                	ld	s2,48(sp)
    8000056a:	79a2                	ld	s3,40(sp)
    8000056c:	7a02                	ld	s4,32(sp)
    8000056e:	6ae2                	ld	s5,24(sp)
    80000570:	6b42                	ld	s6,16(sp)
    80000572:	6ba2                	ld	s7,8(sp)
    80000574:	6161                	addi	sp,sp,80
    80000576:	8082                	ret
  return 0;
    80000578:	4501                	li	a0,0
    8000057a:	b7e5                	j	80000562 <mappages+0x9c>

000000008000057c <kvmmap>:
{
    8000057c:	1141                	addi	sp,sp,-16
    8000057e:	e406                	sd	ra,8(sp)
    80000580:	e022                	sd	s0,0(sp)
    80000582:	0800                	addi	s0,sp,16
    80000584:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000586:	86b2                	mv	a3,a2
    80000588:	863e                	mv	a2,a5
    8000058a:	f3dff0ef          	jal	800004c6 <mappages>
    8000058e:	e509                	bnez	a0,80000598 <kvmmap+0x1c>
}
    80000590:	60a2                	ld	ra,8(sp)
    80000592:	6402                	ld	s0,0(sp)
    80000594:	0141                	addi	sp,sp,16
    80000596:	8082                	ret
    panic("kvmmap");
    80000598:	00007517          	auipc	a0,0x7
    8000059c:	b2050513          	addi	a0,a0,-1248 # 800070b8 <etext+0xb8>
    800005a0:	42e050ef          	jal	800059ce <panic>

00000000800005a4 <kvmmake>:
{
    800005a4:	1101                	addi	sp,sp,-32
    800005a6:	ec06                	sd	ra,24(sp)
    800005a8:	e822                	sd	s0,16(sp)
    800005aa:	e426                	sd	s1,8(sp)
    800005ac:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800005ae:	b57ff0ef          	jal	80000104 <kalloc>
    800005b2:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800005b4:	6605                	lui	a2,0x1
    800005b6:	4581                	li	a1,0
    800005b8:	ba7ff0ef          	jal	8000015e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800005bc:	4719                	li	a4,6
    800005be:	6685                	lui	a3,0x1
    800005c0:	10000637          	lui	a2,0x10000
    800005c4:	85b2                	mv	a1,a2
    800005c6:	8526                	mv	a0,s1
    800005c8:	fb5ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800005cc:	4719                	li	a4,6
    800005ce:	6685                	lui	a3,0x1
    800005d0:	10001637          	lui	a2,0x10001
    800005d4:	85b2                	mv	a1,a2
    800005d6:	8526                	mv	a0,s1
    800005d8:	fa5ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800005dc:	4719                	li	a4,6
    800005de:	040006b7          	lui	a3,0x4000
    800005e2:	0c000637          	lui	a2,0xc000
    800005e6:	85b2                	mv	a1,a2
    800005e8:	8526                	mv	a0,s1
    800005ea:	f93ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800005ee:	4729                	li	a4,10
    800005f0:	80007697          	auipc	a3,0x80007
    800005f4:	a1068693          	addi	a3,a3,-1520 # 7000 <_entry-0x7fff9000>
    800005f8:	4605                	li	a2,1
    800005fa:	067e                	slli	a2,a2,0x1f
    800005fc:	85b2                	mv	a1,a2
    800005fe:	8526                	mv	a0,s1
    80000600:	f7dff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80000604:	4719                	li	a4,6
    80000606:	00007697          	auipc	a3,0x7
    8000060a:	9fa68693          	addi	a3,a3,-1542 # 80007000 <etext>
    8000060e:	47c5                	li	a5,17
    80000610:	07ee                	slli	a5,a5,0x1b
    80000612:	40d786b3          	sub	a3,a5,a3
    80000616:	00007617          	auipc	a2,0x7
    8000061a:	9ea60613          	addi	a2,a2,-1558 # 80007000 <etext>
    8000061e:	85b2                	mv	a1,a2
    80000620:	8526                	mv	a0,s1
    80000622:	f5bff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80000626:	4729                	li	a4,10
    80000628:	6685                	lui	a3,0x1
    8000062a:	00006617          	auipc	a2,0x6
    8000062e:	9d660613          	addi	a2,a2,-1578 # 80006000 <_trampoline>
    80000632:	040005b7          	lui	a1,0x4000
    80000636:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000638:	05b2                	slli	a1,a1,0xc
    8000063a:	8526                	mv	a0,s1
    8000063c:	f41ff0ef          	jal	8000057c <kvmmap>
  proc_mapstacks(kpgtbl);
    80000640:	8526                	mv	a0,s1
    80000642:	59c000ef          	jal	80000bde <proc_mapstacks>
}
    80000646:	8526                	mv	a0,s1
    80000648:	60e2                	ld	ra,24(sp)
    8000064a:	6442                	ld	s0,16(sp)
    8000064c:	64a2                	ld	s1,8(sp)
    8000064e:	6105                	addi	sp,sp,32
    80000650:	8082                	ret

0000000080000652 <kvminit>:
{
    80000652:	1141                	addi	sp,sp,-16
    80000654:	e406                	sd	ra,8(sp)
    80000656:	e022                	sd	s0,0(sp)
    80000658:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000065a:	f4bff0ef          	jal	800005a4 <kvmmake>
    8000065e:	00007797          	auipc	a5,0x7
    80000662:	26a7bd23          	sd	a0,634(a5) # 800078d8 <kernel_pagetable>
}
    80000666:	60a2                	ld	ra,8(sp)
    80000668:	6402                	ld	s0,0(sp)
    8000066a:	0141                	addi	sp,sp,16
    8000066c:	8082                	ret

000000008000066e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000066e:	715d                	addi	sp,sp,-80
    80000670:	e486                	sd	ra,72(sp)
    80000672:	e0a2                	sd	s0,64(sp)
    80000674:	0880                	addi	s0,sp,80
    uint64 a;
    pte_t *pte;

    if((va % PGSIZE) != 0)
    80000676:	03459793          	slli	a5,a1,0x34
    8000067a:	e39d                	bnez	a5,800006a0 <uvmunmap+0x32>
    8000067c:	f84a                	sd	s2,48(sp)
    8000067e:	f44e                	sd	s3,40(sp)
    80000680:	f052                	sd	s4,32(sp)
    80000682:	ec56                	sd	s5,24(sp)
    80000684:	e85a                	sd	s6,16(sp)
    80000686:	e45e                	sd	s7,8(sp)
    80000688:	8a2a                	mv	s4,a0
    8000068a:	892e                	mv	s2,a1
    8000068c:	8b36                	mv	s6,a3
        panic("uvmunmap: not aligned");

    for(a = va; a < va + npages * PGSIZE; a += PGSIZE){
    8000068e:	0632                	slli	a2,a2,0xc
    80000690:	00b609b3          	add	s3,a2,a1
            continue;  // 跳过未分配的页表项

        if((*pte & PTE_V) == 0)
            continue;  // 跳过无效的页表项

        if(PTE_FLAGS(*pte) == PTE_V)
    80000694:	4b85                	li	s7,1
    for(a = va; a < va + npages * PGSIZE; a += PGSIZE){
    80000696:	6a85                	lui	s5,0x1
    80000698:	0735f463          	bgeu	a1,s3,80000700 <uvmunmap+0x92>
    8000069c:	fc26                	sd	s1,56(sp)
    8000069e:	a80d                	j	800006d0 <uvmunmap+0x62>
    800006a0:	fc26                	sd	s1,56(sp)
    800006a2:	f84a                	sd	s2,48(sp)
    800006a4:	f44e                	sd	s3,40(sp)
    800006a6:	f052                	sd	s4,32(sp)
    800006a8:	ec56                	sd	s5,24(sp)
    800006aa:	e85a                	sd	s6,16(sp)
    800006ac:	e45e                	sd	s7,8(sp)
        panic("uvmunmap: not aligned");
    800006ae:	00007517          	auipc	a0,0x7
    800006b2:	a1250513          	addi	a0,a0,-1518 # 800070c0 <etext+0xc0>
    800006b6:	318050ef          	jal	800059ce <panic>
            panic("uvmunmap: not a leaf");
    800006ba:	00007517          	auipc	a0,0x7
    800006be:	a1e50513          	addi	a0,a0,-1506 # 800070d8 <etext+0xd8>
    800006c2:	30c050ef          	jal	800059ce <panic>

        if(do_free){
            uint64 pa = PTE2PA(*pte);
            kfree((void*)pa);
        }
        *pte = 0;
    800006c6:	0004b023          	sd	zero,0(s1)
    for(a = va; a < va + npages * PGSIZE; a += PGSIZE){
    800006ca:	9956                	add	s2,s2,s5
    800006cc:	03397963          	bgeu	s2,s3,800006fe <uvmunmap+0x90>
        if((pte = walk(pagetable, a, 0)) == 0)
    800006d0:	4601                	li	a2,0
    800006d2:	85ca                	mv	a1,s2
    800006d4:	8552                	mv	a0,s4
    800006d6:	d1dff0ef          	jal	800003f2 <walk>
    800006da:	84aa                	mv	s1,a0
    800006dc:	d57d                	beqz	a0,800006ca <uvmunmap+0x5c>
        if((*pte & PTE_V) == 0)
    800006de:	611c                	ld	a5,0(a0)
    800006e0:	0017f713          	andi	a4,a5,1
    800006e4:	d37d                	beqz	a4,800006ca <uvmunmap+0x5c>
        if(PTE_FLAGS(*pte) == PTE_V)
    800006e6:	3ff7f713          	andi	a4,a5,1023
    800006ea:	fd7708e3          	beq	a4,s7,800006ba <uvmunmap+0x4c>
        if(do_free){
    800006ee:	fc0b0ce3          	beqz	s6,800006c6 <uvmunmap+0x58>
            uint64 pa = PTE2PA(*pte);
    800006f2:	83a9                	srli	a5,a5,0xa
            kfree((void*)pa);
    800006f4:	00c79513          	slli	a0,a5,0xc
    800006f8:	925ff0ef          	jal	8000001c <kfree>
    800006fc:	b7e9                	j	800006c6 <uvmunmap+0x58>
    800006fe:	74e2                	ld	s1,56(sp)
    80000700:	7942                	ld	s2,48(sp)
    80000702:	79a2                	ld	s3,40(sp)
    80000704:	7a02                	ld	s4,32(sp)
    80000706:	6ae2                	ld	s5,24(sp)
    80000708:	6b42                	ld	s6,16(sp)
    8000070a:	6ba2                	ld	s7,8(sp)
    }
}
    8000070c:	60a6                	ld	ra,72(sp)
    8000070e:	6406                	ld	s0,64(sp)
    80000710:	6161                	addi	sp,sp,80
    80000712:	8082                	ret

0000000080000714 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80000714:	1101                	addi	sp,sp,-32
    80000716:	ec06                	sd	ra,24(sp)
    80000718:	e822                	sd	s0,16(sp)
    8000071a:	e426                	sd	s1,8(sp)
    8000071c:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000071e:	9e7ff0ef          	jal	80000104 <kalloc>
    80000722:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000724:	c509                	beqz	a0,8000072e <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80000726:	6605                	lui	a2,0x1
    80000728:	4581                	li	a1,0
    8000072a:	a35ff0ef          	jal	8000015e <memset>
  return pagetable;
}
    8000072e:	8526                	mv	a0,s1
    80000730:	60e2                	ld	ra,24(sp)
    80000732:	6442                	ld	s0,16(sp)
    80000734:	64a2                	ld	s1,8(sp)
    80000736:	6105                	addi	sp,sp,32
    80000738:	8082                	ret

000000008000073a <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    8000073a:	7179                	addi	sp,sp,-48
    8000073c:	f406                	sd	ra,40(sp)
    8000073e:	f022                	sd	s0,32(sp)
    80000740:	ec26                	sd	s1,24(sp)
    80000742:	e84a                	sd	s2,16(sp)
    80000744:	e44e                	sd	s3,8(sp)
    80000746:	e052                	sd	s4,0(sp)
    80000748:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    8000074a:	6785                	lui	a5,0x1
    8000074c:	04f67063          	bgeu	a2,a5,8000078c <uvmfirst+0x52>
    80000750:	89aa                	mv	s3,a0
    80000752:	8a2e                	mv	s4,a1
    80000754:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    80000756:	9afff0ef          	jal	80000104 <kalloc>
    8000075a:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    8000075c:	6605                	lui	a2,0x1
    8000075e:	4581                	li	a1,0
    80000760:	9ffff0ef          	jal	8000015e <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    80000764:	4779                	li	a4,30
    80000766:	86ca                	mv	a3,s2
    80000768:	6605                	lui	a2,0x1
    8000076a:	4581                	li	a1,0
    8000076c:	854e                	mv	a0,s3
    8000076e:	d59ff0ef          	jal	800004c6 <mappages>
  memmove(mem, src, sz);
    80000772:	8626                	mv	a2,s1
    80000774:	85d2                	mv	a1,s4
    80000776:	854a                	mv	a0,s2
    80000778:	a47ff0ef          	jal	800001be <memmove>
}
    8000077c:	70a2                	ld	ra,40(sp)
    8000077e:	7402                	ld	s0,32(sp)
    80000780:	64e2                	ld	s1,24(sp)
    80000782:	6942                	ld	s2,16(sp)
    80000784:	69a2                	ld	s3,8(sp)
    80000786:	6a02                	ld	s4,0(sp)
    80000788:	6145                	addi	sp,sp,48
    8000078a:	8082                	ret
    panic("uvmfirst: more than a page");
    8000078c:	00007517          	auipc	a0,0x7
    80000790:	96450513          	addi	a0,a0,-1692 # 800070f0 <etext+0xf0>
    80000794:	23a050ef          	jal	800059ce <panic>

0000000080000798 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80000798:	1101                	addi	sp,sp,-32
    8000079a:	ec06                	sd	ra,24(sp)
    8000079c:	e822                	sd	s0,16(sp)
    8000079e:	e426                	sd	s1,8(sp)
    800007a0:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800007a2:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800007a4:	00b67d63          	bgeu	a2,a1,800007be <uvmdealloc+0x26>
    800007a8:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800007aa:	6785                	lui	a5,0x1
    800007ac:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800007ae:	00f60733          	add	a4,a2,a5
    800007b2:	76fd                	lui	a3,0xfffff
    800007b4:	8f75                	and	a4,a4,a3
    800007b6:	97ae                	add	a5,a5,a1
    800007b8:	8ff5                	and	a5,a5,a3
    800007ba:	00f76863          	bltu	a4,a5,800007ca <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800007be:	8526                	mv	a0,s1
    800007c0:	60e2                	ld	ra,24(sp)
    800007c2:	6442                	ld	s0,16(sp)
    800007c4:	64a2                	ld	s1,8(sp)
    800007c6:	6105                	addi	sp,sp,32
    800007c8:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800007ca:	8f99                	sub	a5,a5,a4
    800007cc:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800007ce:	4685                	li	a3,1
    800007d0:	0007861b          	sext.w	a2,a5
    800007d4:	85ba                	mv	a1,a4
    800007d6:	e99ff0ef          	jal	8000066e <uvmunmap>
    800007da:	b7d5                	j	800007be <uvmdealloc+0x26>

00000000800007dc <uvmalloc>:
  if(newsz < oldsz)
    800007dc:	0ab66163          	bltu	a2,a1,8000087e <uvmalloc+0xa2>
{
    800007e0:	715d                	addi	sp,sp,-80
    800007e2:	e486                	sd	ra,72(sp)
    800007e4:	e0a2                	sd	s0,64(sp)
    800007e6:	f84a                	sd	s2,48(sp)
    800007e8:	f052                	sd	s4,32(sp)
    800007ea:	ec56                	sd	s5,24(sp)
    800007ec:	e45e                	sd	s7,8(sp)
    800007ee:	0880                	addi	s0,sp,80
    800007f0:	8aaa                	mv	s5,a0
    800007f2:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800007f4:	6785                	lui	a5,0x1
    800007f6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800007f8:	95be                	add	a1,a1,a5
    800007fa:	77fd                	lui	a5,0xfffff
    800007fc:	00f5f933          	and	s2,a1,a5
    80000800:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000802:	08c97063          	bgeu	s2,a2,80000882 <uvmalloc+0xa6>
    80000806:	fc26                	sd	s1,56(sp)
    80000808:	f44e                	sd	s3,40(sp)
    8000080a:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    8000080c:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000080e:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80000812:	8f3ff0ef          	jal	80000104 <kalloc>
    80000816:	84aa                	mv	s1,a0
    if(mem == 0){
    80000818:	c50d                	beqz	a0,80000842 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    8000081a:	864e                	mv	a2,s3
    8000081c:	4581                	li	a1,0
    8000081e:	941ff0ef          	jal	8000015e <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000822:	875a                	mv	a4,s6
    80000824:	86a6                	mv	a3,s1
    80000826:	864e                	mv	a2,s3
    80000828:	85ca                	mv	a1,s2
    8000082a:	8556                	mv	a0,s5
    8000082c:	c9bff0ef          	jal	800004c6 <mappages>
    80000830:	e915                	bnez	a0,80000864 <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000832:	994e                	add	s2,s2,s3
    80000834:	fd496fe3          	bltu	s2,s4,80000812 <uvmalloc+0x36>
  return newsz;
    80000838:	8552                	mv	a0,s4
    8000083a:	74e2                	ld	s1,56(sp)
    8000083c:	79a2                	ld	s3,40(sp)
    8000083e:	6b42                	ld	s6,16(sp)
    80000840:	a811                	j	80000854 <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80000842:	865e                	mv	a2,s7
    80000844:	85ca                	mv	a1,s2
    80000846:	8556                	mv	a0,s5
    80000848:	f51ff0ef          	jal	80000798 <uvmdealloc>
      return 0;
    8000084c:	4501                	li	a0,0
    8000084e:	74e2                	ld	s1,56(sp)
    80000850:	79a2                	ld	s3,40(sp)
    80000852:	6b42                	ld	s6,16(sp)
}
    80000854:	60a6                	ld	ra,72(sp)
    80000856:	6406                	ld	s0,64(sp)
    80000858:	7942                	ld	s2,48(sp)
    8000085a:	7a02                	ld	s4,32(sp)
    8000085c:	6ae2                	ld	s5,24(sp)
    8000085e:	6ba2                	ld	s7,8(sp)
    80000860:	6161                	addi	sp,sp,80
    80000862:	8082                	ret
      kfree(mem);
    80000864:	8526                	mv	a0,s1
    80000866:	fb6ff0ef          	jal	8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000086a:	865e                	mv	a2,s7
    8000086c:	85ca                	mv	a1,s2
    8000086e:	8556                	mv	a0,s5
    80000870:	f29ff0ef          	jal	80000798 <uvmdealloc>
      return 0;
    80000874:	4501                	li	a0,0
    80000876:	74e2                	ld	s1,56(sp)
    80000878:	79a2                	ld	s3,40(sp)
    8000087a:	6b42                	ld	s6,16(sp)
    8000087c:	bfe1                	j	80000854 <uvmalloc+0x78>
    return oldsz;
    8000087e:	852e                	mv	a0,a1
}
    80000880:	8082                	ret
  return newsz;
    80000882:	8532                	mv	a0,a2
    80000884:	bfc1                	j	80000854 <uvmalloc+0x78>

0000000080000886 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80000886:	7179                	addi	sp,sp,-48
    80000888:	f406                	sd	ra,40(sp)
    8000088a:	f022                	sd	s0,32(sp)
    8000088c:	ec26                	sd	s1,24(sp)
    8000088e:	e84a                	sd	s2,16(sp)
    80000890:	e44e                	sd	s3,8(sp)
    80000892:	1800                	addi	s0,sp,48
    80000894:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    80000896:	84aa                	mv	s1,a0
    80000898:	6905                	lui	s2,0x1
    8000089a:	992a                	add	s2,s2,a0
    8000089c:	a811                	j	800008b0 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    8000089e:	00007517          	auipc	a0,0x7
    800008a2:	87250513          	addi	a0,a0,-1934 # 80007110 <etext+0x110>
    800008a6:	128050ef          	jal	800059ce <panic>
  for(int i = 0; i < 512; i++){
    800008aa:	04a1                	addi	s1,s1,8
    800008ac:	03248163          	beq	s1,s2,800008ce <freewalk+0x48>
    pte_t pte = pagetable[i];
    800008b0:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800008b2:	0017f713          	andi	a4,a5,1
    800008b6:	db75                	beqz	a4,800008aa <freewalk+0x24>
    800008b8:	00e7f713          	andi	a4,a5,14
    800008bc:	f36d                	bnez	a4,8000089e <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800008be:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800008c0:	00c79513          	slli	a0,a5,0xc
    800008c4:	fc3ff0ef          	jal	80000886 <freewalk>
      pagetable[i] = 0;
    800008c8:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800008cc:	bff9                	j	800008aa <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800008ce:	854e                	mv	a0,s3
    800008d0:	f4cff0ef          	jal	8000001c <kfree>
}
    800008d4:	70a2                	ld	ra,40(sp)
    800008d6:	7402                	ld	s0,32(sp)
    800008d8:	64e2                	ld	s1,24(sp)
    800008da:	6942                	ld	s2,16(sp)
    800008dc:	69a2                	ld	s3,8(sp)
    800008de:	6145                	addi	sp,sp,48
    800008e0:	8082                	ret

00000000800008e2 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800008e2:	1101                	addi	sp,sp,-32
    800008e4:	ec06                	sd	ra,24(sp)
    800008e6:	e822                	sd	s0,16(sp)
    800008e8:	e426                	sd	s1,8(sp)
    800008ea:	1000                	addi	s0,sp,32
    800008ec:	84aa                	mv	s1,a0
  if(sz > 0)
    800008ee:	e989                	bnez	a1,80000900 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800008f0:	8526                	mv	a0,s1
    800008f2:	f95ff0ef          	jal	80000886 <freewalk>
}
    800008f6:	60e2                	ld	ra,24(sp)
    800008f8:	6442                	ld	s0,16(sp)
    800008fa:	64a2                	ld	s1,8(sp)
    800008fc:	6105                	addi	sp,sp,32
    800008fe:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80000900:	6785                	lui	a5,0x1
    80000902:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000904:	95be                	add	a1,a1,a5
    80000906:	4685                	li	a3,1
    80000908:	00c5d613          	srli	a2,a1,0xc
    8000090c:	4581                	li	a1,0
    8000090e:	d61ff0ef          	jal	8000066e <uvmunmap>
    80000912:	bff9                	j	800008f0 <uvmfree+0xe>

0000000080000914 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80000914:	c64d                	beqz	a2,800009be <uvmcopy+0xaa>
{
    80000916:	715d                	addi	sp,sp,-80
    80000918:	e486                	sd	ra,72(sp)
    8000091a:	e0a2                	sd	s0,64(sp)
    8000091c:	fc26                	sd	s1,56(sp)
    8000091e:	f84a                	sd	s2,48(sp)
    80000920:	f44e                	sd	s3,40(sp)
    80000922:	f052                	sd	s4,32(sp)
    80000924:	ec56                	sd	s5,24(sp)
    80000926:	e85a                	sd	s6,16(sp)
    80000928:	e45e                	sd	s7,8(sp)
    8000092a:	0880                	addi	s0,sp,80
    8000092c:	8b2a                	mv	s6,a0
    8000092e:	8aae                	mv	s5,a1
    80000930:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80000932:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80000934:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    80000936:	4601                	li	a2,0
    80000938:	85ca                	mv	a1,s2
    8000093a:	855a                	mv	a0,s6
    8000093c:	ab7ff0ef          	jal	800003f2 <walk>
    80000940:	cd0d                	beqz	a0,8000097a <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    80000942:	00053b83          	ld	s7,0(a0)
    80000946:	001bf793          	andi	a5,s7,1
    8000094a:	cf95                	beqz	a5,80000986 <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    8000094c:	fb8ff0ef          	jal	80000104 <kalloc>
    80000950:	84aa                	mv	s1,a0
    80000952:	c139                	beqz	a0,80000998 <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    80000954:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80000958:	864e                	mv	a2,s3
    8000095a:	05b2                	slli	a1,a1,0xc
    8000095c:	863ff0ef          	jal	800001be <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80000960:	3ffbf713          	andi	a4,s7,1023
    80000964:	86a6                	mv	a3,s1
    80000966:	864e                	mv	a2,s3
    80000968:	85ca                	mv	a1,s2
    8000096a:	8556                	mv	a0,s5
    8000096c:	b5bff0ef          	jal	800004c6 <mappages>
    80000970:	e10d                	bnez	a0,80000992 <uvmcopy+0x7e>
  for(i = 0; i < sz; i += PGSIZE){
    80000972:	994e                	add	s2,s2,s3
    80000974:	fd4961e3          	bltu	s2,s4,80000936 <uvmcopy+0x22>
    80000978:	a805                	j	800009a8 <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    8000097a:	00006517          	auipc	a0,0x6
    8000097e:	7a650513          	addi	a0,a0,1958 # 80007120 <etext+0x120>
    80000982:	04c050ef          	jal	800059ce <panic>
      panic("uvmcopy: page not present");
    80000986:	00006517          	auipc	a0,0x6
    8000098a:	7ba50513          	addi	a0,a0,1978 # 80007140 <etext+0x140>
    8000098e:	040050ef          	jal	800059ce <panic>
      kfree(mem);
    80000992:	8526                	mv	a0,s1
    80000994:	e88ff0ef          	jal	8000001c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80000998:	4685                	li	a3,1
    8000099a:	00c95613          	srli	a2,s2,0xc
    8000099e:	4581                	li	a1,0
    800009a0:	8556                	mv	a0,s5
    800009a2:	ccdff0ef          	jal	8000066e <uvmunmap>
  return -1;
    800009a6:	557d                	li	a0,-1
}
    800009a8:	60a6                	ld	ra,72(sp)
    800009aa:	6406                	ld	s0,64(sp)
    800009ac:	74e2                	ld	s1,56(sp)
    800009ae:	7942                	ld	s2,48(sp)
    800009b0:	79a2                	ld	s3,40(sp)
    800009b2:	7a02                	ld	s4,32(sp)
    800009b4:	6ae2                	ld	s5,24(sp)
    800009b6:	6b42                	ld	s6,16(sp)
    800009b8:	6ba2                	ld	s7,8(sp)
    800009ba:	6161                	addi	sp,sp,80
    800009bc:	8082                	ret
  return 0;
    800009be:	4501                	li	a0,0
}
    800009c0:	8082                	ret

00000000800009c2 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800009c2:	1141                	addi	sp,sp,-16
    800009c4:	e406                	sd	ra,8(sp)
    800009c6:	e022                	sd	s0,0(sp)
    800009c8:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800009ca:	4601                	li	a2,0
    800009cc:	a27ff0ef          	jal	800003f2 <walk>
  if(pte == 0)
    800009d0:	c901                	beqz	a0,800009e0 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800009d2:	611c                	ld	a5,0(a0)
    800009d4:	9bbd                	andi	a5,a5,-17
    800009d6:	e11c                	sd	a5,0(a0)
}
    800009d8:	60a2                	ld	ra,8(sp)
    800009da:	6402                	ld	s0,0(sp)
    800009dc:	0141                	addi	sp,sp,16
    800009de:	8082                	ret
    panic("uvmclear");
    800009e0:	00006517          	auipc	a0,0x6
    800009e4:	78050513          	addi	a0,a0,1920 # 80007160 <etext+0x160>
    800009e8:	7e7040ef          	jal	800059ce <panic>

00000000800009ec <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    800009ec:	c2d9                	beqz	a3,80000a72 <copyout+0x86>
{
    800009ee:	711d                	addi	sp,sp,-96
    800009f0:	ec86                	sd	ra,88(sp)
    800009f2:	e8a2                	sd	s0,80(sp)
    800009f4:	e4a6                	sd	s1,72(sp)
    800009f6:	e0ca                	sd	s2,64(sp)
    800009f8:	fc4e                	sd	s3,56(sp)
    800009fa:	f852                	sd	s4,48(sp)
    800009fc:	f456                	sd	s5,40(sp)
    800009fe:	f05a                	sd	s6,32(sp)
    80000a00:	ec5e                	sd	s7,24(sp)
    80000a02:	e862                	sd	s8,16(sp)
    80000a04:	e466                	sd	s9,8(sp)
    80000a06:	e06a                	sd	s10,0(sp)
    80000a08:	1080                	addi	s0,sp,96
    80000a0a:	8c2a                	mv	s8,a0
    80000a0c:	892e                	mv	s2,a1
    80000a0e:	8ab2                	mv	s5,a2
    80000a10:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80000a12:	7cfd                	lui	s9,0xfffff
    if(va0 >= MAXVA)
    80000a14:	5bfd                	li	s7,-1
    80000a16:	01abdb93          	srli	s7,s7,0x1a
      return -1;
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000a1a:	4d55                	li	s10,21
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    n = PGSIZE - (dstva - va0);
    80000a1c:	6b05                	lui	s6,0x1
    80000a1e:	a015                	j	80000a42 <copyout+0x56>
    pa0 = PTE2PA(*pte);
    80000a20:	83a9                	srli	a5,a5,0xa
    80000a22:	07b2                	slli	a5,a5,0xc
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000a24:	41390533          	sub	a0,s2,s3
    80000a28:	0004861b          	sext.w	a2,s1
    80000a2c:	85d6                	mv	a1,s5
    80000a2e:	953e                	add	a0,a0,a5
    80000a30:	f8eff0ef          	jal	800001be <memmove>

    len -= n;
    80000a34:	409a0a33          	sub	s4,s4,s1
    src += n;
    80000a38:	9aa6                	add	s5,s5,s1
    dstva = va0 + PGSIZE;
    80000a3a:	01698933          	add	s2,s3,s6
  while(len > 0){
    80000a3e:	020a0863          	beqz	s4,80000a6e <copyout+0x82>
    va0 = PGROUNDDOWN(dstva);
    80000a42:	019979b3          	and	s3,s2,s9
    if(va0 >= MAXVA)
    80000a46:	033be863          	bltu	s7,s3,80000a76 <copyout+0x8a>
    pte = walk(pagetable, va0, 0);
    80000a4a:	4601                	li	a2,0
    80000a4c:	85ce                	mv	a1,s3
    80000a4e:	8562                	mv	a0,s8
    80000a50:	9a3ff0ef          	jal	800003f2 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000a54:	c11d                	beqz	a0,80000a7a <copyout+0x8e>
    80000a56:	611c                	ld	a5,0(a0)
    80000a58:	0157f713          	andi	a4,a5,21
    80000a5c:	03a71163          	bne	a4,s10,80000a7e <copyout+0x92>
    n = PGSIZE - (dstva - va0);
    80000a60:	412984b3          	sub	s1,s3,s2
    80000a64:	94da                	add	s1,s1,s6
    if(n > len)
    80000a66:	fa9a7de3          	bgeu	s4,s1,80000a20 <copyout+0x34>
    80000a6a:	84d2                	mv	s1,s4
    80000a6c:	bf55                	j	80000a20 <copyout+0x34>
  }
  return 0;
    80000a6e:	4501                	li	a0,0
    80000a70:	a801                	j	80000a80 <copyout+0x94>
    80000a72:	4501                	li	a0,0
}
    80000a74:	8082                	ret
      return -1;
    80000a76:	557d                	li	a0,-1
    80000a78:	a021                	j	80000a80 <copyout+0x94>
      return -1;
    80000a7a:	557d                	li	a0,-1
    80000a7c:	a011                	j	80000a80 <copyout+0x94>
    80000a7e:	557d                	li	a0,-1
}
    80000a80:	60e6                	ld	ra,88(sp)
    80000a82:	6446                	ld	s0,80(sp)
    80000a84:	64a6                	ld	s1,72(sp)
    80000a86:	6906                	ld	s2,64(sp)
    80000a88:	79e2                	ld	s3,56(sp)
    80000a8a:	7a42                	ld	s4,48(sp)
    80000a8c:	7aa2                	ld	s5,40(sp)
    80000a8e:	7b02                	ld	s6,32(sp)
    80000a90:	6be2                	ld	s7,24(sp)
    80000a92:	6c42                	ld	s8,16(sp)
    80000a94:	6ca2                	ld	s9,8(sp)
    80000a96:	6d02                	ld	s10,0(sp)
    80000a98:	6125                	addi	sp,sp,96
    80000a9a:	8082                	ret

0000000080000a9c <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80000a9c:	c6a5                	beqz	a3,80000b04 <copyin+0x68>
{
    80000a9e:	715d                	addi	sp,sp,-80
    80000aa0:	e486                	sd	ra,72(sp)
    80000aa2:	e0a2                	sd	s0,64(sp)
    80000aa4:	fc26                	sd	s1,56(sp)
    80000aa6:	f84a                	sd	s2,48(sp)
    80000aa8:	f44e                	sd	s3,40(sp)
    80000aaa:	f052                	sd	s4,32(sp)
    80000aac:	ec56                	sd	s5,24(sp)
    80000aae:	e85a                	sd	s6,16(sp)
    80000ab0:	e45e                	sd	s7,8(sp)
    80000ab2:	e062                	sd	s8,0(sp)
    80000ab4:	0880                	addi	s0,sp,80
    80000ab6:	8b2a                	mv	s6,a0
    80000ab8:	8a2e                	mv	s4,a1
    80000aba:	8c32                	mv	s8,a2
    80000abc:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000abe:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000ac0:	6a85                	lui	s5,0x1
    80000ac2:	a00d                	j	80000ae4 <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000ac4:	018505b3          	add	a1,a0,s8
    80000ac8:	0004861b          	sext.w	a2,s1
    80000acc:	412585b3          	sub	a1,a1,s2
    80000ad0:	8552                	mv	a0,s4
    80000ad2:	eecff0ef          	jal	800001be <memmove>

    len -= n;
    80000ad6:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000ada:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000adc:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000ae0:	02098063          	beqz	s3,80000b00 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000ae4:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000ae8:	85ca                	mv	a1,s2
    80000aea:	855a                	mv	a0,s6
    80000aec:	9a1ff0ef          	jal	8000048c <walkaddr>
    if(pa0 == 0)
    80000af0:	cd01                	beqz	a0,80000b08 <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000af2:	418904b3          	sub	s1,s2,s8
    80000af6:	94d6                	add	s1,s1,s5
    if(n > len)
    80000af8:	fc99f6e3          	bgeu	s3,s1,80000ac4 <copyin+0x28>
    80000afc:	84ce                	mv	s1,s3
    80000afe:	b7d9                	j	80000ac4 <copyin+0x28>
  }
  return 0;
    80000b00:	4501                	li	a0,0
    80000b02:	a021                	j	80000b0a <copyin+0x6e>
    80000b04:	4501                	li	a0,0
}
    80000b06:	8082                	ret
      return -1;
    80000b08:	557d                	li	a0,-1
}
    80000b0a:	60a6                	ld	ra,72(sp)
    80000b0c:	6406                	ld	s0,64(sp)
    80000b0e:	74e2                	ld	s1,56(sp)
    80000b10:	7942                	ld	s2,48(sp)
    80000b12:	79a2                	ld	s3,40(sp)
    80000b14:	7a02                	ld	s4,32(sp)
    80000b16:	6ae2                	ld	s5,24(sp)
    80000b18:	6b42                	ld	s6,16(sp)
    80000b1a:	6ba2                	ld	s7,8(sp)
    80000b1c:	6c02                	ld	s8,0(sp)
    80000b1e:	6161                	addi	sp,sp,80
    80000b20:	8082                	ret

0000000080000b22 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000b22:	cac5                	beqz	a3,80000bd2 <copyinstr+0xb0>
{
    80000b24:	715d                	addi	sp,sp,-80
    80000b26:	e486                	sd	ra,72(sp)
    80000b28:	e0a2                	sd	s0,64(sp)
    80000b2a:	fc26                	sd	s1,56(sp)
    80000b2c:	f84a                	sd	s2,48(sp)
    80000b2e:	f44e                	sd	s3,40(sp)
    80000b30:	f052                	sd	s4,32(sp)
    80000b32:	ec56                	sd	s5,24(sp)
    80000b34:	e85a                	sd	s6,16(sp)
    80000b36:	e45e                	sd	s7,8(sp)
    80000b38:	0880                	addi	s0,sp,80
    80000b3a:	8aaa                	mv	s5,a0
    80000b3c:	84ae                	mv	s1,a1
    80000b3e:	8bb2                	mv	s7,a2
    80000b40:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000b42:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000b44:	6a05                	lui	s4,0x1
    80000b46:	a82d                	j	80000b80 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000b48:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80000b4c:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000b4e:	0017c793          	xori	a5,a5,1
    80000b52:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000b56:	60a6                	ld	ra,72(sp)
    80000b58:	6406                	ld	s0,64(sp)
    80000b5a:	74e2                	ld	s1,56(sp)
    80000b5c:	7942                	ld	s2,48(sp)
    80000b5e:	79a2                	ld	s3,40(sp)
    80000b60:	7a02                	ld	s4,32(sp)
    80000b62:	6ae2                	ld	s5,24(sp)
    80000b64:	6b42                	ld	s6,16(sp)
    80000b66:	6ba2                	ld	s7,8(sp)
    80000b68:	6161                	addi	sp,sp,80
    80000b6a:	8082                	ret
    80000b6c:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80000b70:	9726                	add	a4,a4,s1
      --max;
    80000b72:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80000b76:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80000b7a:	04e58463          	beq	a1,a4,80000bc2 <copyinstr+0xa0>
{
    80000b7e:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80000b80:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80000b84:	85ca                	mv	a1,s2
    80000b86:	8556                	mv	a0,s5
    80000b88:	905ff0ef          	jal	8000048c <walkaddr>
    if(pa0 == 0)
    80000b8c:	cd0d                	beqz	a0,80000bc6 <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80000b8e:	417906b3          	sub	a3,s2,s7
    80000b92:	96d2                	add	a3,a3,s4
    if(n > max)
    80000b94:	00d9f363          	bgeu	s3,a3,80000b9a <copyinstr+0x78>
    80000b98:	86ce                	mv	a3,s3
    while(n > 0){
    80000b9a:	ca85                	beqz	a3,80000bca <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80000b9c:	01750633          	add	a2,a0,s7
    80000ba0:	41260633          	sub	a2,a2,s2
    80000ba4:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80000ba6:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80000ba8:	96a6                	add	a3,a3,s1
    80000baa:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000bac:	00f60733          	add	a4,a2,a5
    80000bb0:	00074703          	lbu	a4,0(a4)
    80000bb4:	db51                	beqz	a4,80000b48 <copyinstr+0x26>
        *dst = *p;
    80000bb6:	00e78023          	sb	a4,0(a5)
      dst++;
    80000bba:	0785                	addi	a5,a5,1
    while(n > 0){
    80000bbc:	fed797e3          	bne	a5,a3,80000baa <copyinstr+0x88>
    80000bc0:	b775                	j	80000b6c <copyinstr+0x4a>
    80000bc2:	4781                	li	a5,0
    80000bc4:	b769                	j	80000b4e <copyinstr+0x2c>
      return -1;
    80000bc6:	557d                	li	a0,-1
    80000bc8:	b779                	j	80000b56 <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80000bca:	6b85                	lui	s7,0x1
    80000bcc:	9bca                	add	s7,s7,s2
    80000bce:	87a6                	mv	a5,s1
    80000bd0:	b77d                	j	80000b7e <copyinstr+0x5c>
  int got_null = 0;
    80000bd2:	4781                	li	a5,0
  if(got_null){
    80000bd4:	0017c793          	xori	a5,a5,1
    80000bd8:	40f0053b          	negw	a0,a5
}
    80000bdc:	8082                	ret

0000000080000bde <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000bde:	715d                	addi	sp,sp,-80
    80000be0:	e486                	sd	ra,72(sp)
    80000be2:	e0a2                	sd	s0,64(sp)
    80000be4:	fc26                	sd	s1,56(sp)
    80000be6:	f84a                	sd	s2,48(sp)
    80000be8:	f44e                	sd	s3,40(sp)
    80000bea:	f052                	sd	s4,32(sp)
    80000bec:	ec56                	sd	s5,24(sp)
    80000bee:	e85a                	sd	s6,16(sp)
    80000bf0:	e45e                	sd	s7,8(sp)
    80000bf2:	e062                	sd	s8,0(sp)
    80000bf4:	0880                	addi	s0,sp,80
    80000bf6:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000bf8:	00007497          	auipc	s1,0x7
    80000bfc:	15848493          	addi	s1,s1,344 # 80007d50 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000c00:	8c26                	mv	s8,s1
    80000c02:	334a77b7          	lui	a5,0x334a7
    80000c06:	078a                	slli	a5,a5,0x2
    80000c08:	24578793          	addi	a5,a5,581 # 334a7245 <_entry-0x4cb58dbb>
    80000c0c:	70914937          	lui	s2,0x70914
    80000c10:	f8b90913          	addi	s2,s2,-117 # 70913f8b <_entry-0xf6ec075>
    80000c14:	1902                	slli	s2,s2,0x20
    80000c16:	993e                	add	s2,s2,a5
    80000c18:	040009b7          	lui	s3,0x4000
    80000c1c:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000c1e:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c20:	4b99                	li	s7,6
    80000c22:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c24:	00019a97          	auipc	s5,0x19
    80000c28:	b2ca8a93          	addi	s5,s5,-1236 # 80019750 <tickslock>
    char *pa = kalloc();
    80000c2c:	cd8ff0ef          	jal	80000104 <kalloc>
    80000c30:	862a                	mv	a2,a0
    if(pa == 0)
    80000c32:	c121                	beqz	a0,80000c72 <proc_mapstacks+0x94>
    uint64 va = KSTACK((int) (p - proc));
    80000c34:	418485b3          	sub	a1,s1,s8
    80000c38:	858d                	srai	a1,a1,0x3
    80000c3a:	032585b3          	mul	a1,a1,s2
    80000c3e:	05b6                	slli	a1,a1,0xd
    80000c40:	6789                	lui	a5,0x2
    80000c42:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c44:	875e                	mv	a4,s7
    80000c46:	86da                	mv	a3,s6
    80000c48:	40b985b3          	sub	a1,s3,a1
    80000c4c:	8552                	mv	a0,s4
    80000c4e:	92fff0ef          	jal	8000057c <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c52:	46848493          	addi	s1,s1,1128
    80000c56:	fd549be3          	bne	s1,s5,80000c2c <proc_mapstacks+0x4e>
  }
}
    80000c5a:	60a6                	ld	ra,72(sp)
    80000c5c:	6406                	ld	s0,64(sp)
    80000c5e:	74e2                	ld	s1,56(sp)
    80000c60:	7942                	ld	s2,48(sp)
    80000c62:	79a2                	ld	s3,40(sp)
    80000c64:	7a02                	ld	s4,32(sp)
    80000c66:	6ae2                	ld	s5,24(sp)
    80000c68:	6b42                	ld	s6,16(sp)
    80000c6a:	6ba2                	ld	s7,8(sp)
    80000c6c:	6c02                	ld	s8,0(sp)
    80000c6e:	6161                	addi	sp,sp,80
    80000c70:	8082                	ret
      panic("kalloc");
    80000c72:	00006517          	auipc	a0,0x6
    80000c76:	4fe50513          	addi	a0,a0,1278 # 80007170 <etext+0x170>
    80000c7a:	555040ef          	jal	800059ce <panic>

0000000080000c7e <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000c7e:	7139                	addi	sp,sp,-64
    80000c80:	fc06                	sd	ra,56(sp)
    80000c82:	f822                	sd	s0,48(sp)
    80000c84:	f426                	sd	s1,40(sp)
    80000c86:	f04a                	sd	s2,32(sp)
    80000c88:	ec4e                	sd	s3,24(sp)
    80000c8a:	e852                	sd	s4,16(sp)
    80000c8c:	e456                	sd	s5,8(sp)
    80000c8e:	e05a                	sd	s6,0(sp)
    80000c90:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000c92:	00006597          	auipc	a1,0x6
    80000c96:	4e658593          	addi	a1,a1,1254 # 80007178 <etext+0x178>
    80000c9a:	00007517          	auipc	a0,0x7
    80000c9e:	c8650513          	addi	a0,a0,-890 # 80007920 <pid_lock>
    80000ca2:	7e1040ef          	jal	80005c82 <initlock>
  initlock(&wait_lock, "wait_lock");
    80000ca6:	00006597          	auipc	a1,0x6
    80000caa:	4da58593          	addi	a1,a1,1242 # 80007180 <etext+0x180>
    80000cae:	00007517          	auipc	a0,0x7
    80000cb2:	c8a50513          	addi	a0,a0,-886 # 80007938 <wait_lock>
    80000cb6:	7cd040ef          	jal	80005c82 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cba:	00007497          	auipc	s1,0x7
    80000cbe:	09648493          	addi	s1,s1,150 # 80007d50 <proc>
      initlock(&p->lock, "proc");
    80000cc2:	00006b17          	auipc	s6,0x6
    80000cc6:	4ceb0b13          	addi	s6,s6,1230 # 80007190 <etext+0x190>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000cca:	8aa6                	mv	s5,s1
    80000ccc:	334a77b7          	lui	a5,0x334a7
    80000cd0:	078a                	slli	a5,a5,0x2
    80000cd2:	24578793          	addi	a5,a5,581 # 334a7245 <_entry-0x4cb58dbb>
    80000cd6:	70914937          	lui	s2,0x70914
    80000cda:	f8b90913          	addi	s2,s2,-117 # 70913f8b <_entry-0xf6ec075>
    80000cde:	1902                	slli	s2,s2,0x20
    80000ce0:	993e                	add	s2,s2,a5
    80000ce2:	040009b7          	lui	s3,0x4000
    80000ce6:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000ce8:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cea:	00019a17          	auipc	s4,0x19
    80000cee:	a66a0a13          	addi	s4,s4,-1434 # 80019750 <tickslock>
      initlock(&p->lock, "proc");
    80000cf2:	85da                	mv	a1,s6
    80000cf4:	8526                	mv	a0,s1
    80000cf6:	78d040ef          	jal	80005c82 <initlock>
      p->state = UNUSED;
    80000cfa:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000cfe:	415487b3          	sub	a5,s1,s5
    80000d02:	878d                	srai	a5,a5,0x3
    80000d04:	032787b3          	mul	a5,a5,s2
    80000d08:	07b6                	slli	a5,a5,0xd
    80000d0a:	6709                	lui	a4,0x2
    80000d0c:	9fb9                	addw	a5,a5,a4
    80000d0e:	40f987b3          	sub	a5,s3,a5
    80000d12:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d14:	46848493          	addi	s1,s1,1128
    80000d18:	fd449de3          	bne	s1,s4,80000cf2 <procinit+0x74>
  }
}
    80000d1c:	70e2                	ld	ra,56(sp)
    80000d1e:	7442                	ld	s0,48(sp)
    80000d20:	74a2                	ld	s1,40(sp)
    80000d22:	7902                	ld	s2,32(sp)
    80000d24:	69e2                	ld	s3,24(sp)
    80000d26:	6a42                	ld	s4,16(sp)
    80000d28:	6aa2                	ld	s5,8(sp)
    80000d2a:	6b02                	ld	s6,0(sp)
    80000d2c:	6121                	addi	sp,sp,64
    80000d2e:	8082                	ret

0000000080000d30 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000d30:	1141                	addi	sp,sp,-16
    80000d32:	e406                	sd	ra,8(sp)
    80000d34:	e022                	sd	s0,0(sp)
    80000d36:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000d38:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000d3a:	2501                	sext.w	a0,a0
    80000d3c:	60a2                	ld	ra,8(sp)
    80000d3e:	6402                	ld	s0,0(sp)
    80000d40:	0141                	addi	sp,sp,16
    80000d42:	8082                	ret

0000000080000d44 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000d44:	1141                	addi	sp,sp,-16
    80000d46:	e406                	sd	ra,8(sp)
    80000d48:	e022                	sd	s0,0(sp)
    80000d4a:	0800                	addi	s0,sp,16
    80000d4c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000d4e:	2781                	sext.w	a5,a5
    80000d50:	079e                	slli	a5,a5,0x7
  return c;
}
    80000d52:	00007517          	auipc	a0,0x7
    80000d56:	bfe50513          	addi	a0,a0,-1026 # 80007950 <cpus>
    80000d5a:	953e                	add	a0,a0,a5
    80000d5c:	60a2                	ld	ra,8(sp)
    80000d5e:	6402                	ld	s0,0(sp)
    80000d60:	0141                	addi	sp,sp,16
    80000d62:	8082                	ret

0000000080000d64 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000d64:	1101                	addi	sp,sp,-32
    80000d66:	ec06                	sd	ra,24(sp)
    80000d68:	e822                	sd	s0,16(sp)
    80000d6a:	e426                	sd	s1,8(sp)
    80000d6c:	1000                	addi	s0,sp,32
  push_off();
    80000d6e:	75b040ef          	jal	80005cc8 <push_off>
    80000d72:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000d74:	2781                	sext.w	a5,a5
    80000d76:	079e                	slli	a5,a5,0x7
    80000d78:	00007717          	auipc	a4,0x7
    80000d7c:	ba870713          	addi	a4,a4,-1112 # 80007920 <pid_lock>
    80000d80:	97ba                	add	a5,a5,a4
    80000d82:	7b9c                	ld	a5,48(a5)
    80000d84:	84be                	mv	s1,a5
  pop_off();
    80000d86:	7cb040ef          	jal	80005d50 <pop_off>
  return p;
}
    80000d8a:	8526                	mv	a0,s1
    80000d8c:	60e2                	ld	ra,24(sp)
    80000d8e:	6442                	ld	s0,16(sp)
    80000d90:	64a2                	ld	s1,8(sp)
    80000d92:	6105                	addi	sp,sp,32
    80000d94:	8082                	ret

0000000080000d96 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000d96:	1141                	addi	sp,sp,-16
    80000d98:	e406                	sd	ra,8(sp)
    80000d9a:	e022                	sd	s0,0(sp)
    80000d9c:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000d9e:	fc7ff0ef          	jal	80000d64 <myproc>
    80000da2:	7ff040ef          	jal	80005da0 <release>

  if (first) {
    80000da6:	00007797          	auipc	a5,0x7
    80000daa:	ada7a783          	lw	a5,-1318(a5) # 80007880 <first.1>
    80000dae:	e799                	bnez	a5,80000dbc <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000db0:	447000ef          	jal	800019f6 <usertrapret>
}
    80000db4:	60a2                	ld	ra,8(sp)
    80000db6:	6402                	ld	s0,0(sp)
    80000db8:	0141                	addi	sp,sp,16
    80000dba:	8082                	ret
    fsinit(ROOTDEV);
    80000dbc:	4505                	li	a0,1
    80000dbe:	0d9010ef          	jal	80002696 <fsinit>
    first = 0;
    80000dc2:	00007797          	auipc	a5,0x7
    80000dc6:	aa07af23          	sw	zero,-1346(a5) # 80007880 <first.1>
    __sync_synchronize();
    80000dca:	0330000f          	fence	rw,rw
    80000dce:	b7cd                	j	80000db0 <forkret+0x1a>

0000000080000dd0 <allocpid>:
{
    80000dd0:	1101                	addi	sp,sp,-32
    80000dd2:	ec06                	sd	ra,24(sp)
    80000dd4:	e822                	sd	s0,16(sp)
    80000dd6:	e426                	sd	s1,8(sp)
    80000dd8:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000dda:	00007517          	auipc	a0,0x7
    80000dde:	b4650513          	addi	a0,a0,-1210 # 80007920 <pid_lock>
    80000de2:	72b040ef          	jal	80005d0c <acquire>
  pid = nextpid;
    80000de6:	00007797          	auipc	a5,0x7
    80000dea:	a9e78793          	addi	a5,a5,-1378 # 80007884 <nextpid>
    80000dee:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000df0:	0014871b          	addiw	a4,s1,1
    80000df4:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000df6:	00007517          	auipc	a0,0x7
    80000dfa:	b2a50513          	addi	a0,a0,-1238 # 80007920 <pid_lock>
    80000dfe:	7a3040ef          	jal	80005da0 <release>
}
    80000e02:	8526                	mv	a0,s1
    80000e04:	60e2                	ld	ra,24(sp)
    80000e06:	6442                	ld	s0,16(sp)
    80000e08:	64a2                	ld	s1,8(sp)
    80000e0a:	6105                	addi	sp,sp,32
    80000e0c:	8082                	ret

0000000080000e0e <proc_pagetable>:
{
    80000e0e:	1101                	addi	sp,sp,-32
    80000e10:	ec06                	sd	ra,24(sp)
    80000e12:	e822                	sd	s0,16(sp)
    80000e14:	e426                	sd	s1,8(sp)
    80000e16:	e04a                	sd	s2,0(sp)
    80000e18:	1000                	addi	s0,sp,32
    80000e1a:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000e1c:	8f9ff0ef          	jal	80000714 <uvmcreate>
    80000e20:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000e22:	cd05                	beqz	a0,80000e5a <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000e24:	4729                	li	a4,10
    80000e26:	00005697          	auipc	a3,0x5
    80000e2a:	1da68693          	addi	a3,a3,474 # 80006000 <_trampoline>
    80000e2e:	6605                	lui	a2,0x1
    80000e30:	040005b7          	lui	a1,0x4000
    80000e34:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e36:	05b2                	slli	a1,a1,0xc
    80000e38:	e8eff0ef          	jal	800004c6 <mappages>
    80000e3c:	02054663          	bltz	a0,80000e68 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000e40:	4719                	li	a4,6
    80000e42:	05893683          	ld	a3,88(s2)
    80000e46:	6605                	lui	a2,0x1
    80000e48:	020005b7          	lui	a1,0x2000
    80000e4c:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000e4e:	05b6                	slli	a1,a1,0xd
    80000e50:	8526                	mv	a0,s1
    80000e52:	e74ff0ef          	jal	800004c6 <mappages>
    80000e56:	00054f63          	bltz	a0,80000e74 <proc_pagetable+0x66>
}
    80000e5a:	8526                	mv	a0,s1
    80000e5c:	60e2                	ld	ra,24(sp)
    80000e5e:	6442                	ld	s0,16(sp)
    80000e60:	64a2                	ld	s1,8(sp)
    80000e62:	6902                	ld	s2,0(sp)
    80000e64:	6105                	addi	sp,sp,32
    80000e66:	8082                	ret
    uvmfree(pagetable, 0);
    80000e68:	4581                	li	a1,0
    80000e6a:	8526                	mv	a0,s1
    80000e6c:	a77ff0ef          	jal	800008e2 <uvmfree>
    return 0;
    80000e70:	4481                	li	s1,0
    80000e72:	b7e5                	j	80000e5a <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000e74:	4681                	li	a3,0
    80000e76:	4605                	li	a2,1
    80000e78:	040005b7          	lui	a1,0x4000
    80000e7c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e7e:	05b2                	slli	a1,a1,0xc
    80000e80:	8526                	mv	a0,s1
    80000e82:	fecff0ef          	jal	8000066e <uvmunmap>
    uvmfree(pagetable, 0);
    80000e86:	4581                	li	a1,0
    80000e88:	8526                	mv	a0,s1
    80000e8a:	a59ff0ef          	jal	800008e2 <uvmfree>
    return 0;
    80000e8e:	4481                	li	s1,0
    80000e90:	b7e9                	j	80000e5a <proc_pagetable+0x4c>

0000000080000e92 <proc_freepagetable>:
{
    80000e92:	1101                	addi	sp,sp,-32
    80000e94:	ec06                	sd	ra,24(sp)
    80000e96:	e822                	sd	s0,16(sp)
    80000e98:	e426                	sd	s1,8(sp)
    80000e9a:	e04a                	sd	s2,0(sp)
    80000e9c:	1000                	addi	s0,sp,32
    80000e9e:	84aa                	mv	s1,a0
    80000ea0:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000ea2:	4681                	li	a3,0
    80000ea4:	4605                	li	a2,1
    80000ea6:	040005b7          	lui	a1,0x4000
    80000eaa:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000eac:	05b2                	slli	a1,a1,0xc
    80000eae:	fc0ff0ef          	jal	8000066e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000eb2:	4681                	li	a3,0
    80000eb4:	4605                	li	a2,1
    80000eb6:	020005b7          	lui	a1,0x2000
    80000eba:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000ebc:	05b6                	slli	a1,a1,0xd
    80000ebe:	8526                	mv	a0,s1
    80000ec0:	faeff0ef          	jal	8000066e <uvmunmap>
  uvmfree(pagetable, sz);
    80000ec4:	85ca                	mv	a1,s2
    80000ec6:	8526                	mv	a0,s1
    80000ec8:	a1bff0ef          	jal	800008e2 <uvmfree>
}
    80000ecc:	60e2                	ld	ra,24(sp)
    80000ece:	6442                	ld	s0,16(sp)
    80000ed0:	64a2                	ld	s1,8(sp)
    80000ed2:	6902                	ld	s2,0(sp)
    80000ed4:	6105                	addi	sp,sp,32
    80000ed6:	8082                	ret

0000000080000ed8 <freeproc>:
{
    80000ed8:	1101                	addi	sp,sp,-32
    80000eda:	ec06                	sd	ra,24(sp)
    80000edc:	e822                	sd	s0,16(sp)
    80000ede:	e426                	sd	s1,8(sp)
    80000ee0:	1000                	addi	s0,sp,32
    80000ee2:	84aa                	mv	s1,a0
  if(p->trapframe)
    80000ee4:	6d28                	ld	a0,88(a0)
    80000ee6:	c119                	beqz	a0,80000eec <freeproc+0x14>
    kfree((void*)p->trapframe);
    80000ee8:	934ff0ef          	jal	8000001c <kfree>
  p->trapframe = 0;
    80000eec:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80000ef0:	68a8                	ld	a0,80(s1)
    80000ef2:	c501                	beqz	a0,80000efa <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80000ef4:	64ac                	ld	a1,72(s1)
    80000ef6:	f9dff0ef          	jal	80000e92 <proc_freepagetable>
  p->pagetable = 0;
    80000efa:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80000efe:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80000f02:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80000f06:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80000f0a:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80000f0e:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80000f12:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80000f16:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80000f1a:	0004ac23          	sw	zero,24(s1)
}
    80000f1e:	60e2                	ld	ra,24(sp)
    80000f20:	6442                	ld	s0,16(sp)
    80000f22:	64a2                	ld	s1,8(sp)
    80000f24:	6105                	addi	sp,sp,32
    80000f26:	8082                	ret

0000000080000f28 <allocproc>:
{
    80000f28:	1101                	addi	sp,sp,-32
    80000f2a:	ec06                	sd	ra,24(sp)
    80000f2c:	e822                	sd	s0,16(sp)
    80000f2e:	e426                	sd	s1,8(sp)
    80000f30:	e04a                	sd	s2,0(sp)
    80000f32:	1000                	addi	s0,sp,32
    for(p = proc; p < &proc[NPROC]; p++) {
    80000f34:	00007497          	auipc	s1,0x7
    80000f38:	e1c48493          	addi	s1,s1,-484 # 80007d50 <proc>
    80000f3c:	00019917          	auipc	s2,0x19
    80000f40:	81490913          	addi	s2,s2,-2028 # 80019750 <tickslock>
        acquire(&p->lock);
    80000f44:	8526                	mv	a0,s1
    80000f46:	5c7040ef          	jal	80005d0c <acquire>
        if(p->state == UNUSED) {
    80000f4a:	4c9c                	lw	a5,24(s1)
    80000f4c:	cb91                	beqz	a5,80000f60 <allocproc+0x38>
            release(&p->lock);
    80000f4e:	8526                	mv	a0,s1
    80000f50:	651040ef          	jal	80005da0 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80000f54:	46848493          	addi	s1,s1,1128
    80000f58:	ff2496e3          	bne	s1,s2,80000f44 <allocproc+0x1c>
    return 0;
    80000f5c:	4481                	li	s1,0
    80000f5e:	a0bd                	j	80000fcc <allocproc+0xa4>
    80000f60:	16848793          	addi	a5,s1,360
    80000f64:	46848713          	addi	a4,s1,1128
        p->vmas[i].used = 0;      // 标记为未使用
    80000f68:	0007a023          	sw	zero,0(a5)
        p->vmas[i].addr = 0;      // 起始地址设为0
    80000f6c:	0007b423          	sd	zero,8(a5)
        p->vmas[i].len = 0;       // 长度设为0
    80000f70:	0007b823          	sd	zero,16(a5)
        p->vmas[i].prot = 0;      // 权限设为无
    80000f74:	0007ac23          	sw	zero,24(a5)
        p->vmas[i].flags = 0;     // 标志设为无
    80000f78:	0007ae23          	sw	zero,28(a5)
        p->vmas[i].file = 0;      // 文件指针设为NULL
    80000f7c:	0207b023          	sd	zero,32(a5)
        p->vmas[i].offset = 0;    // 文件偏移设为0
    80000f80:	0207b423          	sd	zero,40(a5)
    for(int i = 0; i < NVMA; i++) {
    80000f84:	03078793          	addi	a5,a5,48
    80000f88:	fee790e3          	bne	a5,a4,80000f68 <allocproc+0x40>
    p->pid = allocpid();
    80000f8c:	e45ff0ef          	jal	80000dd0 <allocpid>
    80000f90:	d888                	sw	a0,48(s1)
    p->state = USED;
    80000f92:	4785                	li	a5,1
    80000f94:	cc9c                	sw	a5,24(s1)
    if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80000f96:	96eff0ef          	jal	80000104 <kalloc>
    80000f9a:	892a                	mv	s2,a0
    80000f9c:	eca8                	sd	a0,88(s1)
    80000f9e:	cd15                	beqz	a0,80000fda <allocproc+0xb2>
    p->pagetable = proc_pagetable(p);
    80000fa0:	8526                	mv	a0,s1
    80000fa2:	e6dff0ef          	jal	80000e0e <proc_pagetable>
    80000fa6:	892a                	mv	s2,a0
    80000fa8:	e8a8                	sd	a0,80(s1)
    if(p->pagetable == 0){
    80000faa:	c121                	beqz	a0,80000fea <allocproc+0xc2>
    memset(&p->context, 0, sizeof(p->context));
    80000fac:	07000613          	li	a2,112
    80000fb0:	4581                	li	a1,0
    80000fb2:	06048513          	addi	a0,s1,96
    80000fb6:	9a8ff0ef          	jal	8000015e <memset>
    p->context.ra = (uint64)forkret;
    80000fba:	00000797          	auipc	a5,0x0
    80000fbe:	ddc78793          	addi	a5,a5,-548 # 80000d96 <forkret>
    80000fc2:	f0bc                	sd	a5,96(s1)
    p->context.sp = p->kstack + PGSIZE;
    80000fc4:	60bc                	ld	a5,64(s1)
    80000fc6:	6705                	lui	a4,0x1
    80000fc8:	97ba                	add	a5,a5,a4
    80000fca:	f4bc                	sd	a5,104(s1)
}
    80000fcc:	8526                	mv	a0,s1
    80000fce:	60e2                	ld	ra,24(sp)
    80000fd0:	6442                	ld	s0,16(sp)
    80000fd2:	64a2                	ld	s1,8(sp)
    80000fd4:	6902                	ld	s2,0(sp)
    80000fd6:	6105                	addi	sp,sp,32
    80000fd8:	8082                	ret
        freeproc(p);
    80000fda:	8526                	mv	a0,s1
    80000fdc:	efdff0ef          	jal	80000ed8 <freeproc>
        release(&p->lock);
    80000fe0:	8526                	mv	a0,s1
    80000fe2:	5bf040ef          	jal	80005da0 <release>
        return 0;
    80000fe6:	84ca                	mv	s1,s2
    80000fe8:	b7d5                	j	80000fcc <allocproc+0xa4>
        freeproc(p);
    80000fea:	8526                	mv	a0,s1
    80000fec:	eedff0ef          	jal	80000ed8 <freeproc>
        release(&p->lock);
    80000ff0:	8526                	mv	a0,s1
    80000ff2:	5af040ef          	jal	80005da0 <release>
        return 0;
    80000ff6:	84ca                	mv	s1,s2
    80000ff8:	bfd1                	j	80000fcc <allocproc+0xa4>

0000000080000ffa <userinit>:
{
    80000ffa:	1101                	addi	sp,sp,-32
    80000ffc:	ec06                	sd	ra,24(sp)
    80000ffe:	e822                	sd	s0,16(sp)
    80001000:	e426                	sd	s1,8(sp)
    80001002:	1000                	addi	s0,sp,32
  p = allocproc();
    80001004:	f25ff0ef          	jal	80000f28 <allocproc>
    80001008:	84aa                	mv	s1,a0
  initproc = p;
    8000100a:	00007797          	auipc	a5,0x7
    8000100e:	8ca7bb23          	sd	a0,-1834(a5) # 800078e0 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001012:	03400613          	li	a2,52
    80001016:	00007597          	auipc	a1,0x7
    8000101a:	87a58593          	addi	a1,a1,-1926 # 80007890 <initcode>
    8000101e:	6928                	ld	a0,80(a0)
    80001020:	f1aff0ef          	jal	8000073a <uvmfirst>
  p->sz = PGSIZE;
    80001024:	6785                	lui	a5,0x1
    80001026:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001028:	6cb8                	ld	a4,88(s1)
    8000102a:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    8000102e:	6cb8                	ld	a4,88(s1)
    80001030:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001032:	4641                	li	a2,16
    80001034:	00006597          	auipc	a1,0x6
    80001038:	16458593          	addi	a1,a1,356 # 80007198 <etext+0x198>
    8000103c:	15848513          	addi	a0,s1,344
    80001040:	a72ff0ef          	jal	800002b2 <safestrcpy>
  p->cwd = namei("/");
    80001044:	00006517          	auipc	a0,0x6
    80001048:	16450513          	addi	a0,a0,356 # 800071a8 <etext+0x1a8>
    8000104c:	773010ef          	jal	80002fbe <namei>
    80001050:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001054:	478d                	li	a5,3
    80001056:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001058:	8526                	mv	a0,s1
    8000105a:	547040ef          	jal	80005da0 <release>
}
    8000105e:	60e2                	ld	ra,24(sp)
    80001060:	6442                	ld	s0,16(sp)
    80001062:	64a2                	ld	s1,8(sp)
    80001064:	6105                	addi	sp,sp,32
    80001066:	8082                	ret

0000000080001068 <growproc>:
{
    80001068:	1101                	addi	sp,sp,-32
    8000106a:	ec06                	sd	ra,24(sp)
    8000106c:	e822                	sd	s0,16(sp)
    8000106e:	e426                	sd	s1,8(sp)
    80001070:	e04a                	sd	s2,0(sp)
    80001072:	1000                	addi	s0,sp,32
    80001074:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001076:	cefff0ef          	jal	80000d64 <myproc>
    8000107a:	84aa                	mv	s1,a0
  sz = p->sz;
    8000107c:	652c                	ld	a1,72(a0)
  if(n > 0){
    8000107e:	01204c63          	bgtz	s2,80001096 <growproc+0x2e>
  } else if(n < 0){
    80001082:	02094463          	bltz	s2,800010aa <growproc+0x42>
  p->sz = sz;
    80001086:	e4ac                	sd	a1,72(s1)
  return 0;
    80001088:	4501                	li	a0,0
}
    8000108a:	60e2                	ld	ra,24(sp)
    8000108c:	6442                	ld	s0,16(sp)
    8000108e:	64a2                	ld	s1,8(sp)
    80001090:	6902                	ld	s2,0(sp)
    80001092:	6105                	addi	sp,sp,32
    80001094:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001096:	4691                	li	a3,4
    80001098:	00b90633          	add	a2,s2,a1
    8000109c:	6928                	ld	a0,80(a0)
    8000109e:	f3eff0ef          	jal	800007dc <uvmalloc>
    800010a2:	85aa                	mv	a1,a0
    800010a4:	f16d                	bnez	a0,80001086 <growproc+0x1e>
      return -1;
    800010a6:	557d                	li	a0,-1
    800010a8:	b7cd                	j	8000108a <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    800010aa:	00b90633          	add	a2,s2,a1
    800010ae:	6928                	ld	a0,80(a0)
    800010b0:	ee8ff0ef          	jal	80000798 <uvmdealloc>
    800010b4:	85aa                	mv	a1,a0
    800010b6:	bfc1                	j	80001086 <growproc+0x1e>

00000000800010b8 <fork>:
{
    800010b8:	7139                	addi	sp,sp,-64
    800010ba:	fc06                	sd	ra,56(sp)
    800010bc:	f822                	sd	s0,48(sp)
    800010be:	f426                	sd	s1,40(sp)
    800010c0:	e456                	sd	s5,8(sp)
    800010c2:	0080                	addi	s0,sp,64
    struct proc *p = myproc();
    800010c4:	ca1ff0ef          	jal	80000d64 <myproc>
    800010c8:	8aaa                	mv	s5,a0
    if((np = allocproc()) == 0){
    800010ca:	e5fff0ef          	jal	80000f28 <allocproc>
    800010ce:	14050263          	beqz	a0,80001212 <fork+0x15a>
    800010d2:	ec4e                	sd	s3,24(sp)
    800010d4:	89aa                	mv	s3,a0
    if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    800010d6:	048ab603          	ld	a2,72(s5)
    800010da:	692c                	ld	a1,80(a0)
    800010dc:	050ab503          	ld	a0,80(s5)
    800010e0:	835ff0ef          	jal	80000914 <uvmcopy>
    800010e4:	04054863          	bltz	a0,80001134 <fork+0x7c>
    800010e8:	f04a                	sd	s2,32(sp)
    800010ea:	e852                	sd	s4,16(sp)
    np->sz = p->sz;
    800010ec:	048ab783          	ld	a5,72(s5)
    800010f0:	04f9b423          	sd	a5,72(s3)
    *(np->trapframe) = *(p->trapframe);
    800010f4:	058ab683          	ld	a3,88(s5)
    800010f8:	87b6                	mv	a5,a3
    800010fa:	0589b703          	ld	a4,88(s3)
    800010fe:	12068693          	addi	a3,a3,288
    80001102:	6388                	ld	a0,0(a5)
    80001104:	678c                	ld	a1,8(a5)
    80001106:	6b90                	ld	a2,16(a5)
    80001108:	e308                	sd	a0,0(a4)
    8000110a:	e70c                	sd	a1,8(a4)
    8000110c:	eb10                	sd	a2,16(a4)
    8000110e:	6f90                	ld	a2,24(a5)
    80001110:	ef10                	sd	a2,24(a4)
    80001112:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    80001116:	02070713          	addi	a4,a4,32
    8000111a:	fed794e3          	bne	a5,a3,80001102 <fork+0x4a>
    np->trapframe->a0 = 0;
    8000111e:	0589b783          	ld	a5,88(s3)
    80001122:	0607b823          	sd	zero,112(a5)
    for(i = 0; i < NOFILE; i++)
    80001126:	0d0a8493          	addi	s1,s5,208
    8000112a:	0d098913          	addi	s2,s3,208
    8000112e:	150a8a13          	addi	s4,s5,336
    80001132:	a831                	j	8000114e <fork+0x96>
        freeproc(np);
    80001134:	854e                	mv	a0,s3
    80001136:	da3ff0ef          	jal	80000ed8 <freeproc>
        release(&np->lock);
    8000113a:	854e                	mv	a0,s3
    8000113c:	465040ef          	jal	80005da0 <release>
        return -1;
    80001140:	54fd                	li	s1,-1
    80001142:	69e2                	ld	s3,24(sp)
    80001144:	a0c1                	j	80001204 <fork+0x14c>
    for(i = 0; i < NOFILE; i++)
    80001146:	04a1                	addi	s1,s1,8
    80001148:	0921                	addi	s2,s2,8
    8000114a:	01448963          	beq	s1,s4,8000115c <fork+0xa4>
        if(p->ofile[i])
    8000114e:	6088                	ld	a0,0(s1)
    80001150:	d97d                	beqz	a0,80001146 <fork+0x8e>
            np->ofile[i] = filedup(p->ofile[i]);
    80001152:	41a020ef          	jal	8000356c <filedup>
    80001156:	00a93023          	sd	a0,0(s2)
    8000115a:	b7f5                	j	80001146 <fork+0x8e>
    np->cwd = idup(p->cwd);
    8000115c:	150ab503          	ld	a0,336(s5)
    80001160:	732010ef          	jal	80002892 <idup>
    80001164:	14a9b823          	sd	a0,336(s3)
    for(i = 0; i < NVMA; i++) {
    80001168:	168a8913          	addi	s2,s5,360
    8000116c:	16898493          	addi	s1,s3,360
    80001170:	46898a13          	addi	s4,s3,1128
    80001174:	a809                	j	80001186 <fork+0xce>
            np->vmas[i].used = 0;              // 确保未使用的VMA标记为0
    80001176:	0004a023          	sw	zero,0(s1)
    for(i = 0; i < NVMA; i++) {
    8000117a:	03090913          	addi	s2,s2,48
    8000117e:	03048493          	addi	s1,s1,48
    80001182:	03448b63          	beq	s1,s4,800011b8 <fork+0x100>
        if(p->vmas[i].used) {
    80001186:	00092783          	lw	a5,0(s2)
    8000118a:	d7f5                	beqz	a5,80001176 <fork+0xbe>
            np->vmas[i] = p->vmas[i];          // 复制VMA结构体
    8000118c:	00093603          	ld	a2,0(s2)
    80001190:	00893683          	ld	a3,8(s2)
    80001194:	01093703          	ld	a4,16(s2)
    80001198:	01893783          	ld	a5,24(s2)
    8000119c:	02093503          	ld	a0,32(s2)
    800011a0:	e090                	sd	a2,0(s1)
    800011a2:	e494                	sd	a3,8(s1)
    800011a4:	e898                	sd	a4,16(s1)
    800011a6:	ec9c                	sd	a5,24(s1)
    800011a8:	f088                	sd	a0,32(s1)
    800011aa:	02893783          	ld	a5,40(s2)
    800011ae:	f49c                	sd	a5,40(s1)
            if(np->vmas[i].file) {
    800011b0:	d569                	beqz	a0,8000117a <fork+0xc2>
                filedup(np->vmas[i].file);       // 增加文件引用计数
    800011b2:	3ba020ef          	jal	8000356c <filedup>
    800011b6:	b7d1                	j	8000117a <fork+0xc2>
    safestrcpy(np->name, p->name, sizeof(p->name));
    800011b8:	4641                	li	a2,16
    800011ba:	158a8593          	addi	a1,s5,344
    800011be:	15898513          	addi	a0,s3,344
    800011c2:	8f0ff0ef          	jal	800002b2 <safestrcpy>
    pid = np->pid;
    800011c6:	0309a483          	lw	s1,48(s3)
    release(&np->lock);
    800011ca:	854e                	mv	a0,s3
    800011cc:	3d5040ef          	jal	80005da0 <release>
    acquire(&wait_lock);
    800011d0:	00006517          	auipc	a0,0x6
    800011d4:	76850513          	addi	a0,a0,1896 # 80007938 <wait_lock>
    800011d8:	335040ef          	jal	80005d0c <acquire>
    np->parent = p;
    800011dc:	0359bc23          	sd	s5,56(s3)
    release(&wait_lock);
    800011e0:	00006517          	auipc	a0,0x6
    800011e4:	75850513          	addi	a0,a0,1880 # 80007938 <wait_lock>
    800011e8:	3b9040ef          	jal	80005da0 <release>
    acquire(&np->lock);
    800011ec:	854e                	mv	a0,s3
    800011ee:	31f040ef          	jal	80005d0c <acquire>
    np->state = RUNNABLE;
    800011f2:	478d                	li	a5,3
    800011f4:	00f9ac23          	sw	a5,24(s3)
    release(&np->lock);
    800011f8:	854e                	mv	a0,s3
    800011fa:	3a7040ef          	jal	80005da0 <release>
    return pid;
    800011fe:	7902                	ld	s2,32(sp)
    80001200:	69e2                	ld	s3,24(sp)
    80001202:	6a42                	ld	s4,16(sp)
}
    80001204:	8526                	mv	a0,s1
    80001206:	70e2                	ld	ra,56(sp)
    80001208:	7442                	ld	s0,48(sp)
    8000120a:	74a2                	ld	s1,40(sp)
    8000120c:	6aa2                	ld	s5,8(sp)
    8000120e:	6121                	addi	sp,sp,64
    80001210:	8082                	ret
        return -1;
    80001212:	54fd                	li	s1,-1
    80001214:	bfc5                	j	80001204 <fork+0x14c>

0000000080001216 <scheduler>:
{
    80001216:	715d                	addi	sp,sp,-80
    80001218:	e486                	sd	ra,72(sp)
    8000121a:	e0a2                	sd	s0,64(sp)
    8000121c:	fc26                	sd	s1,56(sp)
    8000121e:	f84a                	sd	s2,48(sp)
    80001220:	f44e                	sd	s3,40(sp)
    80001222:	f052                	sd	s4,32(sp)
    80001224:	ec56                	sd	s5,24(sp)
    80001226:	e85a                	sd	s6,16(sp)
    80001228:	e45e                	sd	s7,8(sp)
    8000122a:	e062                	sd	s8,0(sp)
    8000122c:	0880                	addi	s0,sp,80
    8000122e:	8792                	mv	a5,tp
  int id = r_tp();
    80001230:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001232:	00779b13          	slli	s6,a5,0x7
    80001236:	00006717          	auipc	a4,0x6
    8000123a:	6ea70713          	addi	a4,a4,1770 # 80007920 <pid_lock>
    8000123e:	975a                	add	a4,a4,s6
    80001240:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001244:	00006717          	auipc	a4,0x6
    80001248:	71470713          	addi	a4,a4,1812 # 80007958 <cpus+0x8>
    8000124c:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    8000124e:	4c11                	li	s8,4
        c->proc = p;
    80001250:	079e                	slli	a5,a5,0x7
    80001252:	00006a17          	auipc	s4,0x6
    80001256:	6cea0a13          	addi	s4,s4,1742 # 80007920 <pid_lock>
    8000125a:	9a3e                	add	s4,s4,a5
        found = 1;
    8000125c:	4b85                	li	s7,1
    8000125e:	a0a9                	j	800012a8 <scheduler+0x92>
      release(&p->lock);
    80001260:	8526                	mv	a0,s1
    80001262:	33f040ef          	jal	80005da0 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001266:	46848493          	addi	s1,s1,1128
    8000126a:	03248563          	beq	s1,s2,80001294 <scheduler+0x7e>
      acquire(&p->lock);
    8000126e:	8526                	mv	a0,s1
    80001270:	29d040ef          	jal	80005d0c <acquire>
      if(p->state == RUNNABLE) {
    80001274:	4c9c                	lw	a5,24(s1)
    80001276:	ff3795e3          	bne	a5,s3,80001260 <scheduler+0x4a>
        p->state = RUNNING;
    8000127a:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    8000127e:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001282:	06048593          	addi	a1,s1,96
    80001286:	855a                	mv	a0,s6
    80001288:	6c4000ef          	jal	8000194c <swtch>
        c->proc = 0;
    8000128c:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001290:	8ade                	mv	s5,s7
    80001292:	b7f9                	j	80001260 <scheduler+0x4a>
    if(found == 0) {
    80001294:	000a9a63          	bnez	s5,800012a8 <scheduler+0x92>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001298:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000129c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800012a0:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    800012a4:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800012a8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800012ac:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800012b0:	10079073          	csrw	sstatus,a5
    int found = 0;
    800012b4:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    800012b6:	00007497          	auipc	s1,0x7
    800012ba:	a9a48493          	addi	s1,s1,-1382 # 80007d50 <proc>
      if(p->state == RUNNABLE) {
    800012be:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    800012c0:	00018917          	auipc	s2,0x18
    800012c4:	49090913          	addi	s2,s2,1168 # 80019750 <tickslock>
    800012c8:	b75d                	j	8000126e <scheduler+0x58>

00000000800012ca <sched>:
{
    800012ca:	7179                	addi	sp,sp,-48
    800012cc:	f406                	sd	ra,40(sp)
    800012ce:	f022                	sd	s0,32(sp)
    800012d0:	ec26                	sd	s1,24(sp)
    800012d2:	e84a                	sd	s2,16(sp)
    800012d4:	e44e                	sd	s3,8(sp)
    800012d6:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    800012d8:	a8dff0ef          	jal	80000d64 <myproc>
    800012dc:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    800012de:	1bf040ef          	jal	80005c9c <holding>
    800012e2:	c935                	beqz	a0,80001356 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    800012e4:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    800012e6:	2781                	sext.w	a5,a5
    800012e8:	079e                	slli	a5,a5,0x7
    800012ea:	00006717          	auipc	a4,0x6
    800012ee:	63670713          	addi	a4,a4,1590 # 80007920 <pid_lock>
    800012f2:	97ba                	add	a5,a5,a4
    800012f4:	0a87a703          	lw	a4,168(a5)
    800012f8:	4785                	li	a5,1
    800012fa:	06f71463          	bne	a4,a5,80001362 <sched+0x98>
  if(p->state == RUNNING)
    800012fe:	4c98                	lw	a4,24(s1)
    80001300:	4791                	li	a5,4
    80001302:	06f70663          	beq	a4,a5,8000136e <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001306:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000130a:	8b89                	andi	a5,a5,2
  if(intr_get())
    8000130c:	e7bd                	bnez	a5,8000137a <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000130e:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001310:	00006917          	auipc	s2,0x6
    80001314:	61090913          	addi	s2,s2,1552 # 80007920 <pid_lock>
    80001318:	2781                	sext.w	a5,a5
    8000131a:	079e                	slli	a5,a5,0x7
    8000131c:	97ca                	add	a5,a5,s2
    8000131e:	0ac7a983          	lw	s3,172(a5)
    80001322:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001324:	2781                	sext.w	a5,a5
    80001326:	079e                	slli	a5,a5,0x7
    80001328:	07a1                	addi	a5,a5,8
    8000132a:	00006597          	auipc	a1,0x6
    8000132e:	62658593          	addi	a1,a1,1574 # 80007950 <cpus>
    80001332:	95be                	add	a1,a1,a5
    80001334:	06048513          	addi	a0,s1,96
    80001338:	614000ef          	jal	8000194c <swtch>
    8000133c:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    8000133e:	2781                	sext.w	a5,a5
    80001340:	079e                	slli	a5,a5,0x7
    80001342:	993e                	add	s2,s2,a5
    80001344:	0b392623          	sw	s3,172(s2)
}
    80001348:	70a2                	ld	ra,40(sp)
    8000134a:	7402                	ld	s0,32(sp)
    8000134c:	64e2                	ld	s1,24(sp)
    8000134e:	6942                	ld	s2,16(sp)
    80001350:	69a2                	ld	s3,8(sp)
    80001352:	6145                	addi	sp,sp,48
    80001354:	8082                	ret
    panic("sched p->lock");
    80001356:	00006517          	auipc	a0,0x6
    8000135a:	e5a50513          	addi	a0,a0,-422 # 800071b0 <etext+0x1b0>
    8000135e:	670040ef          	jal	800059ce <panic>
    panic("sched locks");
    80001362:	00006517          	auipc	a0,0x6
    80001366:	e5e50513          	addi	a0,a0,-418 # 800071c0 <etext+0x1c0>
    8000136a:	664040ef          	jal	800059ce <panic>
    panic("sched running");
    8000136e:	00006517          	auipc	a0,0x6
    80001372:	e6250513          	addi	a0,a0,-414 # 800071d0 <etext+0x1d0>
    80001376:	658040ef          	jal	800059ce <panic>
    panic("sched interruptible");
    8000137a:	00006517          	auipc	a0,0x6
    8000137e:	e6650513          	addi	a0,a0,-410 # 800071e0 <etext+0x1e0>
    80001382:	64c040ef          	jal	800059ce <panic>

0000000080001386 <yield>:
{
    80001386:	1101                	addi	sp,sp,-32
    80001388:	ec06                	sd	ra,24(sp)
    8000138a:	e822                	sd	s0,16(sp)
    8000138c:	e426                	sd	s1,8(sp)
    8000138e:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001390:	9d5ff0ef          	jal	80000d64 <myproc>
    80001394:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001396:	177040ef          	jal	80005d0c <acquire>
  p->state = RUNNABLE;
    8000139a:	478d                	li	a5,3
    8000139c:	cc9c                	sw	a5,24(s1)
  sched();
    8000139e:	f2dff0ef          	jal	800012ca <sched>
  release(&p->lock);
    800013a2:	8526                	mv	a0,s1
    800013a4:	1fd040ef          	jal	80005da0 <release>
}
    800013a8:	60e2                	ld	ra,24(sp)
    800013aa:	6442                	ld	s0,16(sp)
    800013ac:	64a2                	ld	s1,8(sp)
    800013ae:	6105                	addi	sp,sp,32
    800013b0:	8082                	ret

00000000800013b2 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    800013b2:	7179                	addi	sp,sp,-48
    800013b4:	f406                	sd	ra,40(sp)
    800013b6:	f022                	sd	s0,32(sp)
    800013b8:	ec26                	sd	s1,24(sp)
    800013ba:	e84a                	sd	s2,16(sp)
    800013bc:	e44e                	sd	s3,8(sp)
    800013be:	1800                	addi	s0,sp,48
    800013c0:	89aa                	mv	s3,a0
    800013c2:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800013c4:	9a1ff0ef          	jal	80000d64 <myproc>
    800013c8:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    800013ca:	143040ef          	jal	80005d0c <acquire>
  release(lk);
    800013ce:	854a                	mv	a0,s2
    800013d0:	1d1040ef          	jal	80005da0 <release>

  // Go to sleep.
  p->chan = chan;
    800013d4:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    800013d8:	4789                	li	a5,2
    800013da:	cc9c                	sw	a5,24(s1)

  sched();
    800013dc:	eefff0ef          	jal	800012ca <sched>

  // Tidy up.
  p->chan = 0;
    800013e0:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    800013e4:	8526                	mv	a0,s1
    800013e6:	1bb040ef          	jal	80005da0 <release>
  acquire(lk);
    800013ea:	854a                	mv	a0,s2
    800013ec:	121040ef          	jal	80005d0c <acquire>
}
    800013f0:	70a2                	ld	ra,40(sp)
    800013f2:	7402                	ld	s0,32(sp)
    800013f4:	64e2                	ld	s1,24(sp)
    800013f6:	6942                	ld	s2,16(sp)
    800013f8:	69a2                	ld	s3,8(sp)
    800013fa:	6145                	addi	sp,sp,48
    800013fc:	8082                	ret

00000000800013fe <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800013fe:	7139                	addi	sp,sp,-64
    80001400:	fc06                	sd	ra,56(sp)
    80001402:	f822                	sd	s0,48(sp)
    80001404:	f426                	sd	s1,40(sp)
    80001406:	f04a                	sd	s2,32(sp)
    80001408:	ec4e                	sd	s3,24(sp)
    8000140a:	e852                	sd	s4,16(sp)
    8000140c:	e456                	sd	s5,8(sp)
    8000140e:	0080                	addi	s0,sp,64
    80001410:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001412:	00007497          	auipc	s1,0x7
    80001416:	93e48493          	addi	s1,s1,-1730 # 80007d50 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    8000141a:	4989                	li	s3,2
        p->state = RUNNABLE;
    8000141c:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    8000141e:	00018917          	auipc	s2,0x18
    80001422:	33290913          	addi	s2,s2,818 # 80019750 <tickslock>
    80001426:	a801                	j	80001436 <wakeup+0x38>
      }
      release(&p->lock);
    80001428:	8526                	mv	a0,s1
    8000142a:	177040ef          	jal	80005da0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000142e:	46848493          	addi	s1,s1,1128
    80001432:	03248263          	beq	s1,s2,80001456 <wakeup+0x58>
    if(p != myproc()){
    80001436:	92fff0ef          	jal	80000d64 <myproc>
    8000143a:	fe950ae3          	beq	a0,s1,8000142e <wakeup+0x30>
      acquire(&p->lock);
    8000143e:	8526                	mv	a0,s1
    80001440:	0cd040ef          	jal	80005d0c <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001444:	4c9c                	lw	a5,24(s1)
    80001446:	ff3791e3          	bne	a5,s3,80001428 <wakeup+0x2a>
    8000144a:	709c                	ld	a5,32(s1)
    8000144c:	fd479ee3          	bne	a5,s4,80001428 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001450:	0154ac23          	sw	s5,24(s1)
    80001454:	bfd1                	j	80001428 <wakeup+0x2a>
    }
  }
}
    80001456:	70e2                	ld	ra,56(sp)
    80001458:	7442                	ld	s0,48(sp)
    8000145a:	74a2                	ld	s1,40(sp)
    8000145c:	7902                	ld	s2,32(sp)
    8000145e:	69e2                	ld	s3,24(sp)
    80001460:	6a42                	ld	s4,16(sp)
    80001462:	6aa2                	ld	s5,8(sp)
    80001464:	6121                	addi	sp,sp,64
    80001466:	8082                	ret

0000000080001468 <reparent>:
{
    80001468:	7179                	addi	sp,sp,-48
    8000146a:	f406                	sd	ra,40(sp)
    8000146c:	f022                	sd	s0,32(sp)
    8000146e:	ec26                	sd	s1,24(sp)
    80001470:	e84a                	sd	s2,16(sp)
    80001472:	e44e                	sd	s3,8(sp)
    80001474:	e052                	sd	s4,0(sp)
    80001476:	1800                	addi	s0,sp,48
    80001478:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000147a:	00007497          	auipc	s1,0x7
    8000147e:	8d648493          	addi	s1,s1,-1834 # 80007d50 <proc>
      pp->parent = initproc;
    80001482:	00006a17          	auipc	s4,0x6
    80001486:	45ea0a13          	addi	s4,s4,1118 # 800078e0 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000148a:	00018997          	auipc	s3,0x18
    8000148e:	2c698993          	addi	s3,s3,710 # 80019750 <tickslock>
    80001492:	a029                	j	8000149c <reparent+0x34>
    80001494:	46848493          	addi	s1,s1,1128
    80001498:	01348b63          	beq	s1,s3,800014ae <reparent+0x46>
    if(pp->parent == p){
    8000149c:	7c9c                	ld	a5,56(s1)
    8000149e:	ff279be3          	bne	a5,s2,80001494 <reparent+0x2c>
      pp->parent = initproc;
    800014a2:	000a3503          	ld	a0,0(s4)
    800014a6:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    800014a8:	f57ff0ef          	jal	800013fe <wakeup>
    800014ac:	b7e5                	j	80001494 <reparent+0x2c>
}
    800014ae:	70a2                	ld	ra,40(sp)
    800014b0:	7402                	ld	s0,32(sp)
    800014b2:	64e2                	ld	s1,24(sp)
    800014b4:	6942                	ld	s2,16(sp)
    800014b6:	69a2                	ld	s3,8(sp)
    800014b8:	6a02                	ld	s4,0(sp)
    800014ba:	6145                	addi	sp,sp,48
    800014bc:	8082                	ret

00000000800014be <exit>:
{
    800014be:	7175                	addi	sp,sp,-144
    800014c0:	e506                	sd	ra,136(sp)
    800014c2:	e122                	sd	s0,128(sp)
    800014c4:	fca6                	sd	s1,120(sp)
    800014c6:	f8ca                	sd	s2,112(sp)
    800014c8:	f4ce                	sd	s3,104(sp)
    800014ca:	0900                	addi	s0,sp,144
    800014cc:	f8a43423          	sd	a0,-120(s0)
    struct proc *p = myproc();
    800014d0:	895ff0ef          	jal	80000d64 <myproc>
    800014d4:	89aa                	mv	s3,a0
    if(p == initproc)
    800014d6:	00006797          	auipc	a5,0x6
    800014da:	40a7b783          	ld	a5,1034(a5) # 800078e0 <initproc>
    800014de:	0d050493          	addi	s1,a0,208
    800014e2:	15050913          	addi	s2,a0,336
    800014e6:	00a78b63          	beq	a5,a0,800014fc <exit+0x3e>
    800014ea:	f0d2                	sd	s4,96(sp)
    800014ec:	ecd6                	sd	s5,88(sp)
    800014ee:	e8da                	sd	s6,80(sp)
    800014f0:	e4de                	sd	s7,72(sp)
    800014f2:	e0e2                	sd	s8,64(sp)
    800014f4:	fc66                	sd	s9,56(sp)
    800014f6:	f86a                	sd	s10,48(sp)
    800014f8:	f46e                	sd	s11,40(sp)
    800014fa:	a015                	j	8000151e <exit+0x60>
    800014fc:	f0d2                	sd	s4,96(sp)
    800014fe:	ecd6                	sd	s5,88(sp)
    80001500:	e8da                	sd	s6,80(sp)
    80001502:	e4de                	sd	s7,72(sp)
    80001504:	e0e2                	sd	s8,64(sp)
    80001506:	fc66                	sd	s9,56(sp)
    80001508:	f86a                	sd	s10,48(sp)
    8000150a:	f46e                	sd	s11,40(sp)
        panic("init exiting");
    8000150c:	00006517          	auipc	a0,0x6
    80001510:	cec50513          	addi	a0,a0,-788 # 800071f8 <etext+0x1f8>
    80001514:	4ba040ef          	jal	800059ce <panic>
    for(int fd = 0; fd < NOFILE; fd++){
    80001518:	04a1                	addi	s1,s1,8
    8000151a:	01248963          	beq	s1,s2,8000152c <exit+0x6e>
        if(p->ofile[fd]){
    8000151e:	6088                	ld	a0,0(s1)
    80001520:	dd65                	beqz	a0,80001518 <exit+0x5a>
            fileclose(f);
    80001522:	090020ef          	jal	800035b2 <fileclose>
            p->ofile[fd] = 0;
    80001526:	0004b023          	sd	zero,0(s1)
    8000152a:	b7fd                	j	80001518 <exit+0x5a>
    8000152c:	16898493          	addi	s1,s3,360
    80001530:	46898a93          	addi	s5,s3,1128
            if(p->vmas[i].flags == MAP_SHARED) {
    80001534:	4b05                	li	s6,1
    80001536:	a06d                	j	800015e0 <exit+0x122>
                        uint64 pa = PTE2PA(*pte);
    80001538:	00abd613          	srli	a2,s7,0xa
    8000153c:	0632                	slli	a2,a2,0xc
                        writei(p->vmas[i].file->ip, 1, pa + KERNBASE, off, min(PGSIZE, p->vmas[i].len - off));
    8000153e:	02093783          	ld	a5,32(s2)
    80001542:	2701                	sext.w	a4,a4
    80001544:	f8042683          	lw	a3,-128(s0)
    80001548:	f7843583          	ld	a1,-136(s0)
    8000154c:	962e                	add	a2,a2,a1
    8000154e:	85ee                	mv	a1,s11
    80001550:	6f88                	ld	a0,24(a5)
    80001552:	6c2010ef          	jal	80002c14 <writei>
                        iunlock(p->vmas[i].file->ip);
    80001556:	02093783          	ld	a5,32(s2)
    8000155a:	6f88                	ld	a0,24(a5)
    8000155c:	41a010ef          	jal	80002976 <iunlock>
                for(uint64 va = p->vmas[i].addr; va < p->vmas[i].addr + p->vmas[i].len; va += PGSIZE) {
    80001560:	9a62                	add	s4,s4,s8
    80001562:	00893783          	ld	a5,8(s2)
    80001566:	01093703          	ld	a4,16(s2)
    8000156a:	97ba                	add	a5,a5,a4
    8000156c:	04fa7463          	bgeu	s4,a5,800015b4 <exit+0xf6>
                    pte_t *pte = walk(p->pagetable, va, 0);
    80001570:	4601                	li	a2,0
    80001572:	85d2                	mv	a1,s4
    80001574:	0509b503          	ld	a0,80(s3)
    80001578:	e7bfe0ef          	jal	800003f2 <walk>
                    if(pte && (*pte & PTE_V) && (*pte & PTE_D)) {  // 检查页面有效且被修改
    8000157c:	d175                	beqz	a0,80001560 <exit+0xa2>
    8000157e:	00053b83          	ld	s7,0(a0)
    80001582:	081bf793          	andi	a5,s7,129
    80001586:	fda79de3          	bne	a5,s10,80001560 <exit+0xa2>
                        uint64 off = va - p->vmas[i].addr;
    8000158a:	00893c83          	ld	s9,8(s2)
    8000158e:	419a07b3          	sub	a5,s4,s9
    80001592:	f8f43023          	sd	a5,-128(s0)
                        ilock(p->vmas[i].file->ip);
    80001596:	02093783          	ld	a5,32(s2)
    8000159a:	6f88                	ld	a0,24(a5)
    8000159c:	32c010ef          	jal	800028c8 <ilock>
                        writei(p->vmas[i].file->ip, 1, pa + KERNBASE, off, min(PGSIZE, p->vmas[i].len - off));
    800015a0:	01093783          	ld	a5,16(s2)
    800015a4:	00fc8733          	add	a4,s9,a5
    800015a8:	41470733          	sub	a4,a4,s4
    800015ac:	f8ec76e3          	bgeu	s8,a4,80001538 <exit+0x7a>
    800015b0:	6705                	lui	a4,0x1
    800015b2:	b759                	j	80001538 <exit+0x7a>
                end_op();
    800015b4:	43d010ef          	jal	800031f0 <end_op>
            uvmunmap(p->pagetable, p->vmas[i].addr, p->vmas[i].len / PGSIZE, 1);
    800015b8:	01093603          	ld	a2,16(s2)
    800015bc:	86da                	mv	a3,s6
    800015be:	8231                	srli	a2,a2,0xc
    800015c0:	00893583          	ld	a1,8(s2)
    800015c4:	0509b503          	ld	a0,80(s3)
    800015c8:	8a6ff0ef          	jal	8000066e <uvmunmap>
            fileclose(p->vmas[i].file);
    800015cc:	02093503          	ld	a0,32(s2)
    800015d0:	7e3010ef          	jal	800035b2 <fileclose>
            p->vmas[i].used = 0;
    800015d4:	00092023          	sw	zero,0(s2)
    for(int i = 0; i < NVMA; i++) {
    800015d8:	03048493          	addi	s1,s1,48
    800015dc:	03548963          	beq	s1,s5,8000160e <exit+0x150>
        if(p->vmas[i].used) {
    800015e0:	8926                	mv	s2,s1
    800015e2:	409c                	lw	a5,0(s1)
    800015e4:	dbf5                	beqz	a5,800015d8 <exit+0x11a>
            if(p->vmas[i].flags == MAP_SHARED) {
    800015e6:	4cdc                	lw	a5,28(s1)
    800015e8:	fd6798e3          	bne	a5,s6,800015b8 <exit+0xfa>
                begin_op();
    800015ec:	395010ef          	jal	80003180 <begin_op>
                for(uint64 va = p->vmas[i].addr; va < p->vmas[i].addr + p->vmas[i].len; va += PGSIZE) {
    800015f0:	0084ba03          	ld	s4,8(s1)
    800015f4:	689c                	ld	a5,16(s1)
    800015f6:	97d2                	add	a5,a5,s4
    800015f8:	fafa7ee3          	bgeu	s4,a5,800015b4 <exit+0xf6>
                    if(pte && (*pte & PTE_V) && (*pte & PTE_D)) {  // 检查页面有效且被修改
    800015fc:	08100d13          	li	s10,129
                        writei(p->vmas[i].file->ip, 1, pa + KERNBASE, off, min(PGSIZE, p->vmas[i].len - off));
    80001600:	6c05                	lui	s8,0x1
    80001602:	4d85                	li	s11,1
    80001604:	01fd9793          	slli	a5,s11,0x1f
    80001608:	f6f43c23          	sd	a5,-136(s0)
    8000160c:	b795                	j	80001570 <exit+0xb2>
    begin_op();
    8000160e:	373010ef          	jal	80003180 <begin_op>
    iput(p->cwd);
    80001612:	1509b503          	ld	a0,336(s3)
    80001616:	434010ef          	jal	80002a4a <iput>
    end_op();
    8000161a:	3d7010ef          	jal	800031f0 <end_op>
    p->cwd = 0;
    8000161e:	1409b823          	sd	zero,336(s3)
    acquire(&wait_lock);
    80001622:	00006517          	auipc	a0,0x6
    80001626:	31650513          	addi	a0,a0,790 # 80007938 <wait_lock>
    8000162a:	6e2040ef          	jal	80005d0c <acquire>
    reparent(p);
    8000162e:	854e                	mv	a0,s3
    80001630:	e39ff0ef          	jal	80001468 <reparent>
    wakeup(p->parent);
    80001634:	0389b503          	ld	a0,56(s3)
    80001638:	dc7ff0ef          	jal	800013fe <wakeup>
    acquire(&p->lock);
    8000163c:	854e                	mv	a0,s3
    8000163e:	6ce040ef          	jal	80005d0c <acquire>
    p->xstate = status;
    80001642:	f8843783          	ld	a5,-120(s0)
    80001646:	02f9a623          	sw	a5,44(s3)
    p->state = ZOMBIE;
    8000164a:	4795                	li	a5,5
    8000164c:	00f9ac23          	sw	a5,24(s3)
    release(&wait_lock);
    80001650:	00006517          	auipc	a0,0x6
    80001654:	2e850513          	addi	a0,a0,744 # 80007938 <wait_lock>
    80001658:	748040ef          	jal	80005da0 <release>
    sched();
    8000165c:	c6fff0ef          	jal	800012ca <sched>
    panic("zombie exit");
    80001660:	00006517          	auipc	a0,0x6
    80001664:	ba850513          	addi	a0,a0,-1112 # 80007208 <etext+0x208>
    80001668:	366040ef          	jal	800059ce <panic>

000000008000166c <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    8000166c:	7179                	addi	sp,sp,-48
    8000166e:	f406                	sd	ra,40(sp)
    80001670:	f022                	sd	s0,32(sp)
    80001672:	ec26                	sd	s1,24(sp)
    80001674:	e84a                	sd	s2,16(sp)
    80001676:	e44e                	sd	s3,8(sp)
    80001678:	1800                	addi	s0,sp,48
    8000167a:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    8000167c:	00006497          	auipc	s1,0x6
    80001680:	6d448493          	addi	s1,s1,1748 # 80007d50 <proc>
    80001684:	00018997          	auipc	s3,0x18
    80001688:	0cc98993          	addi	s3,s3,204 # 80019750 <tickslock>
    acquire(&p->lock);
    8000168c:	8526                	mv	a0,s1
    8000168e:	67e040ef          	jal	80005d0c <acquire>
    if(p->pid == pid){
    80001692:	589c                	lw	a5,48(s1)
    80001694:	01278b63          	beq	a5,s2,800016aa <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80001698:	8526                	mv	a0,s1
    8000169a:	706040ef          	jal	80005da0 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    8000169e:	46848493          	addi	s1,s1,1128
    800016a2:	ff3495e3          	bne	s1,s3,8000168c <kill+0x20>
  }
  return -1;
    800016a6:	557d                	li	a0,-1
    800016a8:	a819                	j	800016be <kill+0x52>
      p->killed = 1;
    800016aa:	4785                	li	a5,1
    800016ac:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800016ae:	4c98                	lw	a4,24(s1)
    800016b0:	4789                	li	a5,2
    800016b2:	00f70d63          	beq	a4,a5,800016cc <kill+0x60>
      release(&p->lock);
    800016b6:	8526                	mv	a0,s1
    800016b8:	6e8040ef          	jal	80005da0 <release>
      return 0;
    800016bc:	4501                	li	a0,0
}
    800016be:	70a2                	ld	ra,40(sp)
    800016c0:	7402                	ld	s0,32(sp)
    800016c2:	64e2                	ld	s1,24(sp)
    800016c4:	6942                	ld	s2,16(sp)
    800016c6:	69a2                	ld	s3,8(sp)
    800016c8:	6145                	addi	sp,sp,48
    800016ca:	8082                	ret
        p->state = RUNNABLE;
    800016cc:	478d                	li	a5,3
    800016ce:	cc9c                	sw	a5,24(s1)
    800016d0:	b7dd                	j	800016b6 <kill+0x4a>

00000000800016d2 <setkilled>:

void
setkilled(struct proc *p)
{
    800016d2:	1101                	addi	sp,sp,-32
    800016d4:	ec06                	sd	ra,24(sp)
    800016d6:	e822                	sd	s0,16(sp)
    800016d8:	e426                	sd	s1,8(sp)
    800016da:	1000                	addi	s0,sp,32
    800016dc:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800016de:	62e040ef          	jal	80005d0c <acquire>
  p->killed = 1;
    800016e2:	4785                	li	a5,1
    800016e4:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800016e6:	8526                	mv	a0,s1
    800016e8:	6b8040ef          	jal	80005da0 <release>
}
    800016ec:	60e2                	ld	ra,24(sp)
    800016ee:	6442                	ld	s0,16(sp)
    800016f0:	64a2                	ld	s1,8(sp)
    800016f2:	6105                	addi	sp,sp,32
    800016f4:	8082                	ret

00000000800016f6 <killed>:

int
killed(struct proc *p)
{
    800016f6:	1101                	addi	sp,sp,-32
    800016f8:	ec06                	sd	ra,24(sp)
    800016fa:	e822                	sd	s0,16(sp)
    800016fc:	e426                	sd	s1,8(sp)
    800016fe:	e04a                	sd	s2,0(sp)
    80001700:	1000                	addi	s0,sp,32
    80001702:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80001704:	608040ef          	jal	80005d0c <acquire>
  k = p->killed;
    80001708:	549c                	lw	a5,40(s1)
    8000170a:	893e                	mv	s2,a5
  release(&p->lock);
    8000170c:	8526                	mv	a0,s1
    8000170e:	692040ef          	jal	80005da0 <release>
  return k;
}
    80001712:	854a                	mv	a0,s2
    80001714:	60e2                	ld	ra,24(sp)
    80001716:	6442                	ld	s0,16(sp)
    80001718:	64a2                	ld	s1,8(sp)
    8000171a:	6902                	ld	s2,0(sp)
    8000171c:	6105                	addi	sp,sp,32
    8000171e:	8082                	ret

0000000080001720 <wait>:
{
    80001720:	715d                	addi	sp,sp,-80
    80001722:	e486                	sd	ra,72(sp)
    80001724:	e0a2                	sd	s0,64(sp)
    80001726:	fc26                	sd	s1,56(sp)
    80001728:	f84a                	sd	s2,48(sp)
    8000172a:	f44e                	sd	s3,40(sp)
    8000172c:	f052                	sd	s4,32(sp)
    8000172e:	ec56                	sd	s5,24(sp)
    80001730:	e85a                	sd	s6,16(sp)
    80001732:	e45e                	sd	s7,8(sp)
    80001734:	0880                	addi	s0,sp,80
    80001736:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    80001738:	e2cff0ef          	jal	80000d64 <myproc>
    8000173c:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000173e:	00006517          	auipc	a0,0x6
    80001742:	1fa50513          	addi	a0,a0,506 # 80007938 <wait_lock>
    80001746:	5c6040ef          	jal	80005d0c <acquire>
        if(pp->state == ZOMBIE){
    8000174a:	4a15                	li	s4,5
        havekids = 1;
    8000174c:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000174e:	00018997          	auipc	s3,0x18
    80001752:	00298993          	addi	s3,s3,2 # 80019750 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80001756:	00006b17          	auipc	s6,0x6
    8000175a:	1e2b0b13          	addi	s6,s6,482 # 80007938 <wait_lock>
    8000175e:	a869                	j	800017f8 <wait+0xd8>
          pid = pp->pid;
    80001760:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80001764:	000b8c63          	beqz	s7,8000177c <wait+0x5c>
    80001768:	4691                	li	a3,4
    8000176a:	02c48613          	addi	a2,s1,44
    8000176e:	85de                	mv	a1,s7
    80001770:	05093503          	ld	a0,80(s2)
    80001774:	a78ff0ef          	jal	800009ec <copyout>
    80001778:	02054a63          	bltz	a0,800017ac <wait+0x8c>
          freeproc(pp);
    8000177c:	8526                	mv	a0,s1
    8000177e:	f5aff0ef          	jal	80000ed8 <freeproc>
          release(&pp->lock);
    80001782:	8526                	mv	a0,s1
    80001784:	61c040ef          	jal	80005da0 <release>
          release(&wait_lock);
    80001788:	00006517          	auipc	a0,0x6
    8000178c:	1b050513          	addi	a0,a0,432 # 80007938 <wait_lock>
    80001790:	610040ef          	jal	80005da0 <release>
}
    80001794:	854e                	mv	a0,s3
    80001796:	60a6                	ld	ra,72(sp)
    80001798:	6406                	ld	s0,64(sp)
    8000179a:	74e2                	ld	s1,56(sp)
    8000179c:	7942                	ld	s2,48(sp)
    8000179e:	79a2                	ld	s3,40(sp)
    800017a0:	7a02                	ld	s4,32(sp)
    800017a2:	6ae2                	ld	s5,24(sp)
    800017a4:	6b42                	ld	s6,16(sp)
    800017a6:	6ba2                	ld	s7,8(sp)
    800017a8:	6161                	addi	sp,sp,80
    800017aa:	8082                	ret
            release(&pp->lock);
    800017ac:	8526                	mv	a0,s1
    800017ae:	5f2040ef          	jal	80005da0 <release>
            release(&wait_lock);
    800017b2:	00006517          	auipc	a0,0x6
    800017b6:	18650513          	addi	a0,a0,390 # 80007938 <wait_lock>
    800017ba:	5e6040ef          	jal	80005da0 <release>
            return -1;
    800017be:	59fd                	li	s3,-1
    800017c0:	bfd1                	j	80001794 <wait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800017c2:	46848493          	addi	s1,s1,1128
    800017c6:	03348063          	beq	s1,s3,800017e6 <wait+0xc6>
      if(pp->parent == p){
    800017ca:	7c9c                	ld	a5,56(s1)
    800017cc:	ff279be3          	bne	a5,s2,800017c2 <wait+0xa2>
        acquire(&pp->lock);
    800017d0:	8526                	mv	a0,s1
    800017d2:	53a040ef          	jal	80005d0c <acquire>
        if(pp->state == ZOMBIE){
    800017d6:	4c9c                	lw	a5,24(s1)
    800017d8:	f94784e3          	beq	a5,s4,80001760 <wait+0x40>
        release(&pp->lock);
    800017dc:	8526                	mv	a0,s1
    800017de:	5c2040ef          	jal	80005da0 <release>
        havekids = 1;
    800017e2:	8756                	mv	a4,s5
    800017e4:	bff9                	j	800017c2 <wait+0xa2>
    if(!havekids || killed(p)){
    800017e6:	cf19                	beqz	a4,80001804 <wait+0xe4>
    800017e8:	854a                	mv	a0,s2
    800017ea:	f0dff0ef          	jal	800016f6 <killed>
    800017ee:	e919                	bnez	a0,80001804 <wait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800017f0:	85da                	mv	a1,s6
    800017f2:	854a                	mv	a0,s2
    800017f4:	bbfff0ef          	jal	800013b2 <sleep>
    havekids = 0;
    800017f8:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800017fa:	00006497          	auipc	s1,0x6
    800017fe:	55648493          	addi	s1,s1,1366 # 80007d50 <proc>
    80001802:	b7e1                	j	800017ca <wait+0xaa>
      release(&wait_lock);
    80001804:	00006517          	auipc	a0,0x6
    80001808:	13450513          	addi	a0,a0,308 # 80007938 <wait_lock>
    8000180c:	594040ef          	jal	80005da0 <release>
      return -1;
    80001810:	59fd                	li	s3,-1
    80001812:	b749                	j	80001794 <wait+0x74>

0000000080001814 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80001814:	7179                	addi	sp,sp,-48
    80001816:	f406                	sd	ra,40(sp)
    80001818:	f022                	sd	s0,32(sp)
    8000181a:	ec26                	sd	s1,24(sp)
    8000181c:	e84a                	sd	s2,16(sp)
    8000181e:	e44e                	sd	s3,8(sp)
    80001820:	e052                	sd	s4,0(sp)
    80001822:	1800                	addi	s0,sp,48
    80001824:	84aa                	mv	s1,a0
    80001826:	8a2e                	mv	s4,a1
    80001828:	89b2                	mv	s3,a2
    8000182a:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000182c:	d38ff0ef          	jal	80000d64 <myproc>
  if(user_dst){
    80001830:	cc99                	beqz	s1,8000184e <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80001832:	86ca                	mv	a3,s2
    80001834:	864e                	mv	a2,s3
    80001836:	85d2                	mv	a1,s4
    80001838:	6928                	ld	a0,80(a0)
    8000183a:	9b2ff0ef          	jal	800009ec <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    8000183e:	70a2                	ld	ra,40(sp)
    80001840:	7402                	ld	s0,32(sp)
    80001842:	64e2                	ld	s1,24(sp)
    80001844:	6942                	ld	s2,16(sp)
    80001846:	69a2                	ld	s3,8(sp)
    80001848:	6a02                	ld	s4,0(sp)
    8000184a:	6145                	addi	sp,sp,48
    8000184c:	8082                	ret
    memmove((char *)dst, src, len);
    8000184e:	0009061b          	sext.w	a2,s2
    80001852:	85ce                	mv	a1,s3
    80001854:	8552                	mv	a0,s4
    80001856:	969fe0ef          	jal	800001be <memmove>
    return 0;
    8000185a:	8526                	mv	a0,s1
    8000185c:	b7cd                	j	8000183e <either_copyout+0x2a>

000000008000185e <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000185e:	7179                	addi	sp,sp,-48
    80001860:	f406                	sd	ra,40(sp)
    80001862:	f022                	sd	s0,32(sp)
    80001864:	ec26                	sd	s1,24(sp)
    80001866:	e84a                	sd	s2,16(sp)
    80001868:	e44e                	sd	s3,8(sp)
    8000186a:	e052                	sd	s4,0(sp)
    8000186c:	1800                	addi	s0,sp,48
    8000186e:	8a2a                	mv	s4,a0
    80001870:	84ae                	mv	s1,a1
    80001872:	89b2                	mv	s3,a2
    80001874:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80001876:	ceeff0ef          	jal	80000d64 <myproc>
  if(user_src){
    8000187a:	cc99                	beqz	s1,80001898 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    8000187c:	86ca                	mv	a3,s2
    8000187e:	864e                	mv	a2,s3
    80001880:	85d2                	mv	a1,s4
    80001882:	6928                	ld	a0,80(a0)
    80001884:	a18ff0ef          	jal	80000a9c <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80001888:	70a2                	ld	ra,40(sp)
    8000188a:	7402                	ld	s0,32(sp)
    8000188c:	64e2                	ld	s1,24(sp)
    8000188e:	6942                	ld	s2,16(sp)
    80001890:	69a2                	ld	s3,8(sp)
    80001892:	6a02                	ld	s4,0(sp)
    80001894:	6145                	addi	sp,sp,48
    80001896:	8082                	ret
    memmove(dst, (char*)src, len);
    80001898:	0009061b          	sext.w	a2,s2
    8000189c:	85ce                	mv	a1,s3
    8000189e:	8552                	mv	a0,s4
    800018a0:	91ffe0ef          	jal	800001be <memmove>
    return 0;
    800018a4:	8526                	mv	a0,s1
    800018a6:	b7cd                	j	80001888 <either_copyin+0x2a>

00000000800018a8 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800018a8:	715d                	addi	sp,sp,-80
    800018aa:	e486                	sd	ra,72(sp)
    800018ac:	e0a2                	sd	s0,64(sp)
    800018ae:	fc26                	sd	s1,56(sp)
    800018b0:	f84a                	sd	s2,48(sp)
    800018b2:	f44e                	sd	s3,40(sp)
    800018b4:	f052                	sd	s4,32(sp)
    800018b6:	ec56                	sd	s5,24(sp)
    800018b8:	e85a                	sd	s6,16(sp)
    800018ba:	e45e                	sd	s7,8(sp)
    800018bc:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800018be:	00005517          	auipc	a0,0x5
    800018c2:	75a50513          	addi	a0,a0,1882 # 80007018 <etext+0x18>
    800018c6:	5f9030ef          	jal	800056be <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800018ca:	00006497          	auipc	s1,0x6
    800018ce:	5de48493          	addi	s1,s1,1502 # 80007ea8 <proc+0x158>
    800018d2:	00018917          	auipc	s2,0x18
    800018d6:	fd690913          	addi	s2,s2,-42 # 800198a8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800018da:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800018dc:	00006997          	auipc	s3,0x6
    800018e0:	93c98993          	addi	s3,s3,-1732 # 80007218 <etext+0x218>
    printf("%d %s %s", p->pid, state, p->name);
    800018e4:	00006a97          	auipc	s5,0x6
    800018e8:	93ca8a93          	addi	s5,s5,-1732 # 80007220 <etext+0x220>
    printf("\n");
    800018ec:	00005a17          	auipc	s4,0x5
    800018f0:	72ca0a13          	addi	s4,s4,1836 # 80007018 <etext+0x18>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800018f4:	00006b97          	auipc	s7,0x6
    800018f8:	e64b8b93          	addi	s7,s7,-412 # 80007758 <states.0>
    800018fc:	a829                	j	80001916 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800018fe:	ed86a583          	lw	a1,-296(a3)
    80001902:	8556                	mv	a0,s5
    80001904:	5bb030ef          	jal	800056be <printf>
    printf("\n");
    80001908:	8552                	mv	a0,s4
    8000190a:	5b5030ef          	jal	800056be <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000190e:	46848493          	addi	s1,s1,1128
    80001912:	03248263          	beq	s1,s2,80001936 <procdump+0x8e>
    if(p->state == UNUSED)
    80001916:	86a6                	mv	a3,s1
    80001918:	ec04a783          	lw	a5,-320(s1)
    8000191c:	dbed                	beqz	a5,8000190e <procdump+0x66>
      state = "???";
    8000191e:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001920:	fcfb6fe3          	bltu	s6,a5,800018fe <procdump+0x56>
    80001924:	02079713          	slli	a4,a5,0x20
    80001928:	01d75793          	srli	a5,a4,0x1d
    8000192c:	97de                	add	a5,a5,s7
    8000192e:	6390                	ld	a2,0(a5)
    80001930:	f679                	bnez	a2,800018fe <procdump+0x56>
      state = "???";
    80001932:	864e                	mv	a2,s3
    80001934:	b7e9                	j	800018fe <procdump+0x56>
  }
}
    80001936:	60a6                	ld	ra,72(sp)
    80001938:	6406                	ld	s0,64(sp)
    8000193a:	74e2                	ld	s1,56(sp)
    8000193c:	7942                	ld	s2,48(sp)
    8000193e:	79a2                	ld	s3,40(sp)
    80001940:	7a02                	ld	s4,32(sp)
    80001942:	6ae2                	ld	s5,24(sp)
    80001944:	6b42                	ld	s6,16(sp)
    80001946:	6ba2                	ld	s7,8(sp)
    80001948:	6161                	addi	sp,sp,80
    8000194a:	8082                	ret

000000008000194c <swtch>:
    8000194c:	00153023          	sd	ra,0(a0)
    80001950:	00253423          	sd	sp,8(a0)
    80001954:	e900                	sd	s0,16(a0)
    80001956:	ed04                	sd	s1,24(a0)
    80001958:	03253023          	sd	s2,32(a0)
    8000195c:	03353423          	sd	s3,40(a0)
    80001960:	03453823          	sd	s4,48(a0)
    80001964:	03553c23          	sd	s5,56(a0)
    80001968:	05653023          	sd	s6,64(a0)
    8000196c:	05753423          	sd	s7,72(a0)
    80001970:	05853823          	sd	s8,80(a0)
    80001974:	05953c23          	sd	s9,88(a0)
    80001978:	07a53023          	sd	s10,96(a0)
    8000197c:	07b53423          	sd	s11,104(a0)
    80001980:	0005b083          	ld	ra,0(a1)
    80001984:	0085b103          	ld	sp,8(a1)
    80001988:	6980                	ld	s0,16(a1)
    8000198a:	6d84                	ld	s1,24(a1)
    8000198c:	0205b903          	ld	s2,32(a1)
    80001990:	0285b983          	ld	s3,40(a1)
    80001994:	0305ba03          	ld	s4,48(a1)
    80001998:	0385ba83          	ld	s5,56(a1)
    8000199c:	0405bb03          	ld	s6,64(a1)
    800019a0:	0485bb83          	ld	s7,72(a1)
    800019a4:	0505bc03          	ld	s8,80(a1)
    800019a8:	0585bc83          	ld	s9,88(a1)
    800019ac:	0605bd03          	ld	s10,96(a1)
    800019b0:	0685bd83          	ld	s11,104(a1)
    800019b4:	8082                	ret

00000000800019b6 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800019b6:	1141                	addi	sp,sp,-16
    800019b8:	e406                	sd	ra,8(sp)
    800019ba:	e022                	sd	s0,0(sp)
    800019bc:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800019be:	00006597          	auipc	a1,0x6
    800019c2:	8a258593          	addi	a1,a1,-1886 # 80007260 <etext+0x260>
    800019c6:	00018517          	auipc	a0,0x18
    800019ca:	d8a50513          	addi	a0,a0,-630 # 80019750 <tickslock>
    800019ce:	2b4040ef          	jal	80005c82 <initlock>
}
    800019d2:	60a2                	ld	ra,8(sp)
    800019d4:	6402                	ld	s0,0(sp)
    800019d6:	0141                	addi	sp,sp,16
    800019d8:	8082                	ret

00000000800019da <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800019da:	1141                	addi	sp,sp,-16
    800019dc:	e406                	sd	ra,8(sp)
    800019de:	e022                	sd	s0,0(sp)
    800019e0:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    800019e2:	00003797          	auipc	a5,0x3
    800019e6:	23e78793          	addi	a5,a5,574 # 80004c20 <kernelvec>
    800019ea:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800019ee:	60a2                	ld	ra,8(sp)
    800019f0:	6402                	ld	s0,0(sp)
    800019f2:	0141                	addi	sp,sp,16
    800019f4:	8082                	ret

00000000800019f6 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    800019f6:	1141                	addi	sp,sp,-16
    800019f8:	e406                	sd	ra,8(sp)
    800019fa:	e022                	sd	s0,0(sp)
    800019fc:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800019fe:	b66ff0ef          	jal	80000d64 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a02:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001a06:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001a08:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80001a0c:	00004697          	auipc	a3,0x4
    80001a10:	5f468693          	addi	a3,a3,1524 # 80006000 <_trampoline>
    80001a14:	00004717          	auipc	a4,0x4
    80001a18:	5ec70713          	addi	a4,a4,1516 # 80006000 <_trampoline>
    80001a1c:	8f15                	sub	a4,a4,a3
    80001a1e:	040007b7          	lui	a5,0x4000
    80001a22:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80001a24:	07b2                	slli	a5,a5,0xc
    80001a26:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001a28:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80001a2c:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80001a2e:	18002673          	csrr	a2,satp
    80001a32:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80001a34:	6d30                	ld	a2,88(a0)
    80001a36:	6138                	ld	a4,64(a0)
    80001a38:	6585                	lui	a1,0x1
    80001a3a:	972e                	add	a4,a4,a1
    80001a3c:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80001a3e:	6d38                	ld	a4,88(a0)
    80001a40:	00000617          	auipc	a2,0x0
    80001a44:	11460613          	addi	a2,a2,276 # 80001b54 <usertrap>
    80001a48:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80001a4a:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80001a4c:	8612                	mv	a2,tp
    80001a4e:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a50:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80001a54:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80001a58:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001a5c:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80001a60:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001a62:	6f18                	ld	a4,24(a4)
    80001a64:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001a68:	6928                	ld	a0,80(a0)
    80001a6a:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001a6c:	00004717          	auipc	a4,0x4
    80001a70:	63070713          	addi	a4,a4,1584 # 8000609c <userret>
    80001a74:	8f15                	sub	a4,a4,a3
    80001a76:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001a78:	577d                	li	a4,-1
    80001a7a:	177e                	slli	a4,a4,0x3f
    80001a7c:	8d59                	or	a0,a0,a4
    80001a7e:	9782                	jalr	a5
}
    80001a80:	60a2                	ld	ra,8(sp)
    80001a82:	6402                	ld	s0,0(sp)
    80001a84:	0141                	addi	sp,sp,16
    80001a86:	8082                	ret

0000000080001a88 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001a88:	1141                	addi	sp,sp,-16
    80001a8a:	e406                	sd	ra,8(sp)
    80001a8c:	e022                	sd	s0,0(sp)
    80001a8e:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80001a90:	aa0ff0ef          	jal	80000d30 <cpuid>
    80001a94:	cd11                	beqz	a0,80001ab0 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001a96:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001a9a:	000f4737          	lui	a4,0xf4
    80001a9e:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80001aa2:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80001aa4:	14d79073          	csrw	stimecmp,a5
}
    80001aa8:	60a2                	ld	ra,8(sp)
    80001aaa:	6402                	ld	s0,0(sp)
    80001aac:	0141                	addi	sp,sp,16
    80001aae:	8082                	ret
    acquire(&tickslock);
    80001ab0:	00018517          	auipc	a0,0x18
    80001ab4:	ca050513          	addi	a0,a0,-864 # 80019750 <tickslock>
    80001ab8:	254040ef          	jal	80005d0c <acquire>
    ticks++;
    80001abc:	00006717          	auipc	a4,0x6
    80001ac0:	e2c70713          	addi	a4,a4,-468 # 800078e8 <ticks>
    80001ac4:	431c                	lw	a5,0(a4)
    80001ac6:	2785                	addiw	a5,a5,1
    80001ac8:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80001aca:	853a                	mv	a0,a4
    80001acc:	933ff0ef          	jal	800013fe <wakeup>
    release(&tickslock);
    80001ad0:	00018517          	auipc	a0,0x18
    80001ad4:	c8050513          	addi	a0,a0,-896 # 80019750 <tickslock>
    80001ad8:	2c8040ef          	jal	80005da0 <release>
    80001adc:	bf6d                	j	80001a96 <clockintr+0xe>

0000000080001ade <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001ade:	1101                	addi	sp,sp,-32
    80001ae0:	ec06                	sd	ra,24(sp)
    80001ae2:	e822                	sd	s0,16(sp)
    80001ae4:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001ae6:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001aea:	57fd                	li	a5,-1
    80001aec:	17fe                	slli	a5,a5,0x3f
    80001aee:	07a5                	addi	a5,a5,9
    80001af0:	00f70c63          	beq	a4,a5,80001b08 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80001af4:	57fd                	li	a5,-1
    80001af6:	17fe                	slli	a5,a5,0x3f
    80001af8:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001afa:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001afc:	04f70863          	beq	a4,a5,80001b4c <devintr+0x6e>
  }
}
    80001b00:	60e2                	ld	ra,24(sp)
    80001b02:	6442                	ld	s0,16(sp)
    80001b04:	6105                	addi	sp,sp,32
    80001b06:	8082                	ret
    80001b08:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80001b0a:	1c2030ef          	jal	80004ccc <plic_claim>
    80001b0e:	872a                	mv	a4,a0
    80001b10:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001b12:	47a9                	li	a5,10
    80001b14:	00f50963          	beq	a0,a5,80001b26 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    80001b18:	4785                	li	a5,1
    80001b1a:	00f50963          	beq	a0,a5,80001b2c <devintr+0x4e>
    return 1;
    80001b1e:	4505                	li	a0,1
    } else if(irq){
    80001b20:	eb09                	bnez	a4,80001b32 <devintr+0x54>
    80001b22:	64a2                	ld	s1,8(sp)
    80001b24:	bff1                	j	80001b00 <devintr+0x22>
      uartintr();
    80001b26:	11c040ef          	jal	80005c42 <uartintr>
    if(irq)
    80001b2a:	a819                	j	80001b40 <devintr+0x62>
      virtio_disk_intr();
    80001b2c:	636030ef          	jal	80005162 <virtio_disk_intr>
    if(irq)
    80001b30:	a801                	j	80001b40 <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    80001b32:	85ba                	mv	a1,a4
    80001b34:	00005517          	auipc	a0,0x5
    80001b38:	73450513          	addi	a0,a0,1844 # 80007268 <etext+0x268>
    80001b3c:	383030ef          	jal	800056be <printf>
      plic_complete(irq);
    80001b40:	8526                	mv	a0,s1
    80001b42:	1aa030ef          	jal	80004cec <plic_complete>
    return 1;
    80001b46:	4505                	li	a0,1
    80001b48:	64a2                	ld	s1,8(sp)
    80001b4a:	bf5d                	j	80001b00 <devintr+0x22>
    clockintr();
    80001b4c:	f3dff0ef          	jal	80001a88 <clockintr>
    return 2;
    80001b50:	4509                	li	a0,2
    80001b52:	b77d                	j	80001b00 <devintr+0x22>

0000000080001b54 <usertrap>:
{
    80001b54:	7139                	addi	sp,sp,-64
    80001b56:	fc06                	sd	ra,56(sp)
    80001b58:	f822                	sd	s0,48(sp)
    80001b5a:	0080                	addi	s0,sp,64
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b5c:	100027f3          	csrr	a5,sstatus
    if((r_sstatus() & SSTATUS_SPP) != 0)
    80001b60:	1007f793          	andi	a5,a5,256
    80001b64:	e3bd                	bnez	a5,80001bca <usertrap+0x76>
    80001b66:	f426                	sd	s1,40(sp)
    80001b68:	f04a                	sd	s2,32(sp)
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001b6a:	00003797          	auipc	a5,0x3
    80001b6e:	0b678793          	addi	a5,a5,182 # 80004c20 <kernelvec>
    80001b72:	10579073          	csrw	stvec,a5
    struct proc *p = myproc();
    80001b76:	9eeff0ef          	jal	80000d64 <myproc>
    80001b7a:	892a                	mv	s2,a0
    p->trapframe->epc = r_sepc();
    80001b7c:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b7e:	14102773          	csrr	a4,sepc
    80001b82:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001b84:	14202773          	csrr	a4,scause
    if(r_scause() == 8){
    80001b88:	47a1                	li	a5,8
    80001b8a:	04f70c63          	beq	a4,a5,80001be2 <usertrap+0x8e>
    } else if((which_dev = devintr()) != 0){
    80001b8e:	f51ff0ef          	jal	80001ade <devintr>
    80001b92:	84aa                	mv	s1,a0
    80001b94:	1a051263          	bnez	a0,80001d38 <usertrap+0x1e4>
    80001b98:	14202773          	csrr	a4,scause
    } else if(r_scause() == 13 || r_scause() == 15) {
    80001b9c:	47b5                	li	a5,13
    80001b9e:	00f70763          	beq	a4,a5,80001bac <usertrap+0x58>
    80001ba2:	14202773          	csrr	a4,scause
    80001ba6:	47bd                	li	a5,15
    80001ba8:	16f71063          	bne	a4,a5,80001d08 <usertrap+0x1b4>
    80001bac:	ec4e                	sd	s3,24(sp)
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001bae:	143029f3          	csrr	s3,stval
        if (va >= p->sz) {
    80001bb2:	04893703          	ld	a4,72(s2)
    80001bb6:	16890793          	addi	a5,s2,360
        for (int i = 0; i < NVMA; i++) {
    80001bba:	46c1                	li	a3,16
        if (va >= p->sz) {
    80001bbc:	06e9e963          	bltu	s3,a4,80001c2e <usertrap+0xda>
            p->killed = 1;
    80001bc0:	4785                	li	a5,1
    80001bc2:	02f92423          	sw	a5,40(s2)
            goto killed;
    80001bc6:	69e2                	ld	s3,24(sp)
    80001bc8:	a82d                	j	80001c02 <usertrap+0xae>
    80001bca:	f426                	sd	s1,40(sp)
    80001bcc:	f04a                	sd	s2,32(sp)
    80001bce:	ec4e                	sd	s3,24(sp)
    80001bd0:	e852                	sd	s4,16(sp)
    80001bd2:	e456                	sd	s5,8(sp)
    80001bd4:	e05a                	sd	s6,0(sp)
        panic("usertrap: not from user mode");
    80001bd6:	00005517          	auipc	a0,0x5
    80001bda:	6b250513          	addi	a0,a0,1714 # 80007288 <etext+0x288>
    80001bde:	5f1030ef          	jal	800059ce <panic>
        if(killed(p))
    80001be2:	b15ff0ef          	jal	800016f6 <killed>
    80001be6:	e91d                	bnez	a0,80001c1c <usertrap+0xc8>
        p->trapframe->epc += 4;
    80001be8:	05893703          	ld	a4,88(s2)
    80001bec:	6f1c                	ld	a5,24(a4)
    80001bee:	0791                	addi	a5,a5,4
    80001bf0:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001bf2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001bf6:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001bfa:	10079073          	csrw	sstatus,a5
        syscall();
    80001bfe:	334000ef          	jal	80001f32 <syscall>
    if(killed(p))
    80001c02:	854a                	mv	a0,s2
    80001c04:	af3ff0ef          	jal	800016f6 <killed>
    80001c08:	12051d63          	bnez	a0,80001d42 <usertrap+0x1ee>
    usertrapret();
    80001c0c:	debff0ef          	jal	800019f6 <usertrapret>
    80001c10:	74a2                	ld	s1,40(sp)
    80001c12:	7902                	ld	s2,32(sp)
}
    80001c14:	70e2                	ld	ra,56(sp)
    80001c16:	7442                	ld	s0,48(sp)
    80001c18:	6121                	addi	sp,sp,64
    80001c1a:	8082                	ret
            exit(-1);
    80001c1c:	557d                	li	a0,-1
    80001c1e:	8a1ff0ef          	jal	800014be <exit>
    80001c22:	b7d9                	j	80001be8 <usertrap+0x94>
        for (int i = 0; i < NVMA; i++) {
    80001c24:	2485                	addiw	s1,s1,1
    80001c26:	03078793          	addi	a5,a5,48
    80001c2a:	08d48563          	beq	s1,a3,80001cb4 <usertrap+0x160>
            if (p->vmas[i].used &&
    80001c2e:	4398                	lw	a4,0(a5)
    80001c30:	db75                	beqz	a4,80001c24 <usertrap+0xd0>
                va >= p->vmas[i].addr &&
    80001c32:	6798                	ld	a4,8(a5)
            if (p->vmas[i].used &&
    80001c34:	fee9e8e3          	bltu	s3,a4,80001c24 <usertrap+0xd0>
                va < p->vmas[i].addr + p->vmas[i].len) {
    80001c38:	6b90                	ld	a2,16(a5)
    80001c3a:	9732                	add	a4,a4,a2
                va >= p->vmas[i].addr &&
    80001c3c:	fee9f4e3          	bgeu	s3,a4,80001c24 <usertrap+0xd0>
                vv = &p->vmas[i];
    80001c40:	00149793          	slli	a5,s1,0x1
    80001c44:	94be                	add	s1,s1,a5
    80001c46:	0492                	slli	s1,s1,0x4
    80001c48:	16848493          	addi	s1,s1,360
    80001c4c:	94ca                	add	s1,s1,s2
        if (vv == 0) {
    80001c4e:	c0bd                	beqz	s1,80001cb4 <usertrap+0x160>
    80001c50:	e456                	sd	s5,8(sp)
        char *mem = kalloc();
    80001c52:	cb2fe0ef          	jal	80000104 <kalloc>
    80001c56:	8aaa                	mv	s5,a0
        if (mem == 0) {
    80001c58:	c13d                	beqz	a0,80001cbe <usertrap+0x16a>
    80001c5a:	e852                	sd	s4,16(sp)
    80001c5c:	e05a                	sd	s6,0(sp)
        memset(mem, 0, PGSIZE);
    80001c5e:	6605                	lui	a2,0x1
    80001c60:	4581                	li	a1,0
    80001c62:	cfcfe0ef          	jal	8000015e <memset>
        uint64 off = PGROUNDDOWN(va) - vv->addr;
    80001c66:	77fd                	lui	a5,0xfffff
    80001c68:	00f9f9b3          	and	s3,s3,a5
        int n = vv->file->ip->size - off;
    80001c6c:	709c                	ld	a5,32(s1)
    80001c6e:	6f88                	ld	a0,24(a5)
        uint64 off = PGROUNDDOWN(va) - vv->addr;
    80001c70:	649c                	ld	a5,8(s1)
        int n = vv->file->ip->size - off;
    80001c72:	40f987bb          	subw	a5,s3,a5
    80001c76:	873e                	mv	a4,a5
    80001c78:	8b3e                	mv	s6,a5
    80001c7a:	457c                	lw	a5,76(a0)
    80001c7c:	9f99                	subw	a5,a5,a4
    80001c7e:	8a3e                	mv	s4,a5
        if (n > 0) {
    80001c80:	04f04563          	bgtz	a5,80001cca <usertrap+0x176>
        if (vv->prot & PROT_READ) perm |= PTE_R;
    80001c84:	4c9c                	lw	a5,24(s1)
    80001c86:	0017f693          	andi	a3,a5,1
    80001c8a:	4749                	li	a4,18
    80001c8c:	e291                	bnez	a3,80001c90 <usertrap+0x13c>
        int perm = PTE_U;
    80001c8e:	4741                	li	a4,16
        if (vv->prot & PROT_WRITE) perm |= PTE_W;
    80001c90:	8b89                	andi	a5,a5,2
    80001c92:	c399                	beqz	a5,80001c98 <usertrap+0x144>
    80001c94:	00476713          	ori	a4,a4,4
        if (mappages(p->pagetable, PGROUNDDOWN(va), PGSIZE, (uint64)mem, perm) < 0) {
    80001c98:	86d6                	mv	a3,s5
    80001c9a:	6605                	lui	a2,0x1
    80001c9c:	85ce                	mv	a1,s3
    80001c9e:	05093503          	ld	a0,80(s2)
    80001ca2:	825fe0ef          	jal	800004c6 <mappages>
    80001ca6:	04054663          	bltz	a0,80001cf2 <usertrap+0x19e>
    80001caa:	69e2                	ld	s3,24(sp)
    80001cac:	6a42                	ld	s4,16(sp)
    80001cae:	6aa2                	ld	s5,8(sp)
    80001cb0:	6b02                	ld	s6,0(sp)
    80001cb2:	bf81                	j	80001c02 <usertrap+0xae>
            p->killed = 1;
    80001cb4:	4785                	li	a5,1
    80001cb6:	02f92423          	sw	a5,40(s2)
            goto killed;
    80001cba:	69e2                	ld	s3,24(sp)
    80001cbc:	b799                	j	80001c02 <usertrap+0xae>
            p->killed = 1;
    80001cbe:	4785                	li	a5,1
    80001cc0:	02f92423          	sw	a5,40(s2)
            goto killed;
    80001cc4:	69e2                	ld	s3,24(sp)
    80001cc6:	6aa2                	ld	s5,8(sp)
    80001cc8:	bf2d                	j	80001c02 <usertrap+0xae>
            ilock(vv->file->ip);
    80001cca:	3ff000ef          	jal	800028c8 <ilock>
            readi(vv->file->ip, 0, (uint64)mem, off, min(PGSIZE, n));
    80001cce:	8752                	mv	a4,s4
    80001cd0:	6785                	lui	a5,0x1
    80001cd2:	0147d363          	bge	a5,s4,80001cd8 <usertrap+0x184>
    80001cd6:	6705                	lui	a4,0x1
    80001cd8:	709c                	ld	a5,32(s1)
    80001cda:	2701                	sext.w	a4,a4
    80001cdc:	86da                	mv	a3,s6
    80001cde:	8656                	mv	a2,s5
    80001ce0:	4581                	li	a1,0
    80001ce2:	6f88                	ld	a0,24(a5)
    80001ce4:	63f000ef          	jal	80002b22 <readi>
            iunlock(vv->file->ip);
    80001ce8:	709c                	ld	a5,32(s1)
    80001cea:	6f88                	ld	a0,24(a5)
    80001cec:	48b000ef          	jal	80002976 <iunlock>
    80001cf0:	bf51                	j	80001c84 <usertrap+0x130>
            kfree(mem);
    80001cf2:	8556                	mv	a0,s5
    80001cf4:	b28fe0ef          	jal	8000001c <kfree>
            p->killed = 1;
    80001cf8:	4785                	li	a5,1
    80001cfa:	02f92423          	sw	a5,40(s2)
            goto killed;
    80001cfe:	69e2                	ld	s3,24(sp)
    80001d00:	6a42                	ld	s4,16(sp)
    80001d02:	6aa2                	ld	s5,8(sp)
    80001d04:	6b02                	ld	s6,0(sp)
    80001d06:	bdf5                	j	80001c02 <usertrap+0xae>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001d08:	142025f3          	csrr	a1,scause
        printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001d0c:	03092603          	lw	a2,48(s2)
    80001d10:	00005517          	auipc	a0,0x5
    80001d14:	59850513          	addi	a0,a0,1432 # 800072a8 <etext+0x2a8>
    80001d18:	1a7030ef          	jal	800056be <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001d1c:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001d20:	14302673          	csrr	a2,stval
        printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001d24:	00005517          	auipc	a0,0x5
    80001d28:	5b450513          	addi	a0,a0,1460 # 800072d8 <etext+0x2d8>
    80001d2c:	193030ef          	jal	800056be <printf>
        setkilled(p);
    80001d30:	854a                	mv	a0,s2
    80001d32:	9a1ff0ef          	jal	800016d2 <setkilled>
    80001d36:	b5f1                	j	80001c02 <usertrap+0xae>
    if(killed(p))
    80001d38:	854a                	mv	a0,s2
    80001d3a:	9bdff0ef          	jal	800016f6 <killed>
    80001d3e:	c511                	beqz	a0,80001d4a <usertrap+0x1f6>
    80001d40:	a011                	j	80001d44 <usertrap+0x1f0>
    80001d42:	4481                	li	s1,0
        exit(-1);
    80001d44:	557d                	li	a0,-1
    80001d46:	f78ff0ef          	jal	800014be <exit>
    if(which_dev == 2)
    80001d4a:	4789                	li	a5,2
    80001d4c:	ecf490e3          	bne	s1,a5,80001c0c <usertrap+0xb8>
        yield();
    80001d50:	e36ff0ef          	jal	80001386 <yield>
    80001d54:	bd65                	j	80001c0c <usertrap+0xb8>

0000000080001d56 <kerneltrap>:
{
    80001d56:	7179                	addi	sp,sp,-48
    80001d58:	f406                	sd	ra,40(sp)
    80001d5a:	f022                	sd	s0,32(sp)
    80001d5c:	ec26                	sd	s1,24(sp)
    80001d5e:	e84a                	sd	s2,16(sp)
    80001d60:	e44e                	sd	s3,8(sp)
    80001d62:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001d64:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001d68:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001d6c:	142027f3          	csrr	a5,scause
    80001d70:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80001d72:	1004f793          	andi	a5,s1,256
    80001d76:	c795                	beqz	a5,80001da2 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001d78:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001d7c:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001d7e:	eb85                	bnez	a5,80001dae <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80001d80:	d5fff0ef          	jal	80001ade <devintr>
    80001d84:	c91d                	beqz	a0,80001dba <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80001d86:	4789                	li	a5,2
    80001d88:	04f50a63          	beq	a0,a5,80001ddc <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001d8c:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001d90:	10049073          	csrw	sstatus,s1
}
    80001d94:	70a2                	ld	ra,40(sp)
    80001d96:	7402                	ld	s0,32(sp)
    80001d98:	64e2                	ld	s1,24(sp)
    80001d9a:	6942                	ld	s2,16(sp)
    80001d9c:	69a2                	ld	s3,8(sp)
    80001d9e:	6145                	addi	sp,sp,48
    80001da0:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001da2:	00005517          	auipc	a0,0x5
    80001da6:	55e50513          	addi	a0,a0,1374 # 80007300 <etext+0x300>
    80001daa:	425030ef          	jal	800059ce <panic>
    panic("kerneltrap: interrupts enabled");
    80001dae:	00005517          	auipc	a0,0x5
    80001db2:	57a50513          	addi	a0,a0,1402 # 80007328 <etext+0x328>
    80001db6:	419030ef          	jal	800059ce <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001dba:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001dbe:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001dc2:	85ce                	mv	a1,s3
    80001dc4:	00005517          	auipc	a0,0x5
    80001dc8:	58450513          	addi	a0,a0,1412 # 80007348 <etext+0x348>
    80001dcc:	0f3030ef          	jal	800056be <printf>
    panic("kerneltrap");
    80001dd0:	00005517          	auipc	a0,0x5
    80001dd4:	5a050513          	addi	a0,a0,1440 # 80007370 <etext+0x370>
    80001dd8:	3f7030ef          	jal	800059ce <panic>
  if(which_dev == 2 && myproc() != 0)
    80001ddc:	f89fe0ef          	jal	80000d64 <myproc>
    80001de0:	d555                	beqz	a0,80001d8c <kerneltrap+0x36>
    yield();
    80001de2:	da4ff0ef          	jal	80001386 <yield>
    80001de6:	b75d                	j	80001d8c <kerneltrap+0x36>

0000000080001de8 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001de8:	1101                	addi	sp,sp,-32
    80001dea:	ec06                	sd	ra,24(sp)
    80001dec:	e822                	sd	s0,16(sp)
    80001dee:	e426                	sd	s1,8(sp)
    80001df0:	1000                	addi	s0,sp,32
    80001df2:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001df4:	f71fe0ef          	jal	80000d64 <myproc>
  switch (n) {
    80001df8:	4795                	li	a5,5
    80001dfa:	0497e163          	bltu	a5,s1,80001e3c <argraw+0x54>
    80001dfe:	048a                	slli	s1,s1,0x2
    80001e00:	00006717          	auipc	a4,0x6
    80001e04:	98870713          	addi	a4,a4,-1656 # 80007788 <states.0+0x30>
    80001e08:	94ba                	add	s1,s1,a4
    80001e0a:	409c                	lw	a5,0(s1)
    80001e0c:	97ba                	add	a5,a5,a4
    80001e0e:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001e10:	6d3c                	ld	a5,88(a0)
    80001e12:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001e14:	60e2                	ld	ra,24(sp)
    80001e16:	6442                	ld	s0,16(sp)
    80001e18:	64a2                	ld	s1,8(sp)
    80001e1a:	6105                	addi	sp,sp,32
    80001e1c:	8082                	ret
    return p->trapframe->a1;
    80001e1e:	6d3c                	ld	a5,88(a0)
    80001e20:	7fa8                	ld	a0,120(a5)
    80001e22:	bfcd                	j	80001e14 <argraw+0x2c>
    return p->trapframe->a2;
    80001e24:	6d3c                	ld	a5,88(a0)
    80001e26:	63c8                	ld	a0,128(a5)
    80001e28:	b7f5                	j	80001e14 <argraw+0x2c>
    return p->trapframe->a3;
    80001e2a:	6d3c                	ld	a5,88(a0)
    80001e2c:	67c8                	ld	a0,136(a5)
    80001e2e:	b7dd                	j	80001e14 <argraw+0x2c>
    return p->trapframe->a4;
    80001e30:	6d3c                	ld	a5,88(a0)
    80001e32:	6bc8                	ld	a0,144(a5)
    80001e34:	b7c5                	j	80001e14 <argraw+0x2c>
    return p->trapframe->a5;
    80001e36:	6d3c                	ld	a5,88(a0)
    80001e38:	6fc8                	ld	a0,152(a5)
    80001e3a:	bfe9                	j	80001e14 <argraw+0x2c>
  panic("argraw");
    80001e3c:	00005517          	auipc	a0,0x5
    80001e40:	54450513          	addi	a0,a0,1348 # 80007380 <etext+0x380>
    80001e44:	38b030ef          	jal	800059ce <panic>

0000000080001e48 <fetchaddr>:
{
    80001e48:	1101                	addi	sp,sp,-32
    80001e4a:	ec06                	sd	ra,24(sp)
    80001e4c:	e822                	sd	s0,16(sp)
    80001e4e:	e426                	sd	s1,8(sp)
    80001e50:	e04a                	sd	s2,0(sp)
    80001e52:	1000                	addi	s0,sp,32
    80001e54:	84aa                	mv	s1,a0
    80001e56:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001e58:	f0dfe0ef          	jal	80000d64 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001e5c:	653c                	ld	a5,72(a0)
    80001e5e:	02f4f663          	bgeu	s1,a5,80001e8a <fetchaddr+0x42>
    80001e62:	00848713          	addi	a4,s1,8
    80001e66:	02e7e463          	bltu	a5,a4,80001e8e <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001e6a:	46a1                	li	a3,8
    80001e6c:	8626                	mv	a2,s1
    80001e6e:	85ca                	mv	a1,s2
    80001e70:	6928                	ld	a0,80(a0)
    80001e72:	c2bfe0ef          	jal	80000a9c <copyin>
    80001e76:	00a03533          	snez	a0,a0
    80001e7a:	40a0053b          	negw	a0,a0
}
    80001e7e:	60e2                	ld	ra,24(sp)
    80001e80:	6442                	ld	s0,16(sp)
    80001e82:	64a2                	ld	s1,8(sp)
    80001e84:	6902                	ld	s2,0(sp)
    80001e86:	6105                	addi	sp,sp,32
    80001e88:	8082                	ret
    return -1;
    80001e8a:	557d                	li	a0,-1
    80001e8c:	bfcd                	j	80001e7e <fetchaddr+0x36>
    80001e8e:	557d                	li	a0,-1
    80001e90:	b7fd                	j	80001e7e <fetchaddr+0x36>

0000000080001e92 <fetchstr>:
{
    80001e92:	7179                	addi	sp,sp,-48
    80001e94:	f406                	sd	ra,40(sp)
    80001e96:	f022                	sd	s0,32(sp)
    80001e98:	ec26                	sd	s1,24(sp)
    80001e9a:	e84a                	sd	s2,16(sp)
    80001e9c:	e44e                	sd	s3,8(sp)
    80001e9e:	1800                	addi	s0,sp,48
    80001ea0:	89aa                	mv	s3,a0
    80001ea2:	84ae                	mv	s1,a1
    80001ea4:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80001ea6:	ebffe0ef          	jal	80000d64 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001eaa:	86ca                	mv	a3,s2
    80001eac:	864e                	mv	a2,s3
    80001eae:	85a6                	mv	a1,s1
    80001eb0:	6928                	ld	a0,80(a0)
    80001eb2:	c71fe0ef          	jal	80000b22 <copyinstr>
    80001eb6:	00054c63          	bltz	a0,80001ece <fetchstr+0x3c>
  return strlen(buf);
    80001eba:	8526                	mv	a0,s1
    80001ebc:	c2cfe0ef          	jal	800002e8 <strlen>
}
    80001ec0:	70a2                	ld	ra,40(sp)
    80001ec2:	7402                	ld	s0,32(sp)
    80001ec4:	64e2                	ld	s1,24(sp)
    80001ec6:	6942                	ld	s2,16(sp)
    80001ec8:	69a2                	ld	s3,8(sp)
    80001eca:	6145                	addi	sp,sp,48
    80001ecc:	8082                	ret
    return -1;
    80001ece:	557d                	li	a0,-1
    80001ed0:	bfc5                	j	80001ec0 <fetchstr+0x2e>

0000000080001ed2 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001ed2:	1101                	addi	sp,sp,-32
    80001ed4:	ec06                	sd	ra,24(sp)
    80001ed6:	e822                	sd	s0,16(sp)
    80001ed8:	e426                	sd	s1,8(sp)
    80001eda:	1000                	addi	s0,sp,32
    80001edc:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001ede:	f0bff0ef          	jal	80001de8 <argraw>
    80001ee2:	c088                	sw	a0,0(s1)
}
    80001ee4:	60e2                	ld	ra,24(sp)
    80001ee6:	6442                	ld	s0,16(sp)
    80001ee8:	64a2                	ld	s1,8(sp)
    80001eea:	6105                	addi	sp,sp,32
    80001eec:	8082                	ret

0000000080001eee <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001eee:	1101                	addi	sp,sp,-32
    80001ef0:	ec06                	sd	ra,24(sp)
    80001ef2:	e822                	sd	s0,16(sp)
    80001ef4:	e426                	sd	s1,8(sp)
    80001ef6:	1000                	addi	s0,sp,32
    80001ef8:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001efa:	eefff0ef          	jal	80001de8 <argraw>
    80001efe:	e088                	sd	a0,0(s1)
}
    80001f00:	60e2                	ld	ra,24(sp)
    80001f02:	6442                	ld	s0,16(sp)
    80001f04:	64a2                	ld	s1,8(sp)
    80001f06:	6105                	addi	sp,sp,32
    80001f08:	8082                	ret

0000000080001f0a <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001f0a:	1101                	addi	sp,sp,-32
    80001f0c:	ec06                	sd	ra,24(sp)
    80001f0e:	e822                	sd	s0,16(sp)
    80001f10:	e426                	sd	s1,8(sp)
    80001f12:	e04a                	sd	s2,0(sp)
    80001f14:	1000                	addi	s0,sp,32
    80001f16:	892e                	mv	s2,a1
    80001f18:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80001f1a:	ecfff0ef          	jal	80001de8 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80001f1e:	8626                	mv	a2,s1
    80001f20:	85ca                	mv	a1,s2
    80001f22:	f71ff0ef          	jal	80001e92 <fetchstr>
}
    80001f26:	60e2                	ld	ra,24(sp)
    80001f28:	6442                	ld	s0,16(sp)
    80001f2a:	64a2                	ld	s1,8(sp)
    80001f2c:	6902                	ld	s2,0(sp)
    80001f2e:	6105                	addi	sp,sp,32
    80001f30:	8082                	ret

0000000080001f32 <syscall>:
[SYS_munmap] sys_munmap,
};

void
syscall(void)
{
    80001f32:	1101                	addi	sp,sp,-32
    80001f34:	ec06                	sd	ra,24(sp)
    80001f36:	e822                	sd	s0,16(sp)
    80001f38:	e426                	sd	s1,8(sp)
    80001f3a:	e04a                	sd	s2,0(sp)
    80001f3c:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001f3e:	e27fe0ef          	jal	80000d64 <myproc>
    80001f42:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001f44:	05853903          	ld	s2,88(a0)
    80001f48:	0a893783          	ld	a5,168(s2)
    80001f4c:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001f50:	37fd                	addiw	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001f52:	4759                	li	a4,22
    80001f54:	00f76f63          	bltu	a4,a5,80001f72 <syscall+0x40>
    80001f58:	00369713          	slli	a4,a3,0x3
    80001f5c:	00006797          	auipc	a5,0x6
    80001f60:	84478793          	addi	a5,a5,-1980 # 800077a0 <syscalls>
    80001f64:	97ba                	add	a5,a5,a4
    80001f66:	639c                	ld	a5,0(a5)
    80001f68:	c789                	beqz	a5,80001f72 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001f6a:	9782                	jalr	a5
    80001f6c:	06a93823          	sd	a0,112(s2)
    80001f70:	a829                	j	80001f8a <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001f72:	15848613          	addi	a2,s1,344
    80001f76:	588c                	lw	a1,48(s1)
    80001f78:	00005517          	auipc	a0,0x5
    80001f7c:	41050513          	addi	a0,a0,1040 # 80007388 <etext+0x388>
    80001f80:	73e030ef          	jal	800056be <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001f84:	6cbc                	ld	a5,88(s1)
    80001f86:	577d                	li	a4,-1
    80001f88:	fbb8                	sd	a4,112(a5)
  }
}
    80001f8a:	60e2                	ld	ra,24(sp)
    80001f8c:	6442                	ld	s0,16(sp)
    80001f8e:	64a2                	ld	s1,8(sp)
    80001f90:	6902                	ld	s2,0(sp)
    80001f92:	6105                	addi	sp,sp,32
    80001f94:	8082                	ret

0000000080001f96 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001f96:	1101                	addi	sp,sp,-32
    80001f98:	ec06                	sd	ra,24(sp)
    80001f9a:	e822                	sd	s0,16(sp)
    80001f9c:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001f9e:	fec40593          	addi	a1,s0,-20
    80001fa2:	4501                	li	a0,0
    80001fa4:	f2fff0ef          	jal	80001ed2 <argint>
  exit(n);
    80001fa8:	fec42503          	lw	a0,-20(s0)
    80001fac:	d12ff0ef          	jal	800014be <exit>
  return 0;  // not reached
}
    80001fb0:	4501                	li	a0,0
    80001fb2:	60e2                	ld	ra,24(sp)
    80001fb4:	6442                	ld	s0,16(sp)
    80001fb6:	6105                	addi	sp,sp,32
    80001fb8:	8082                	ret

0000000080001fba <sys_getpid>:

uint64
sys_getpid(void)
{
    80001fba:	1141                	addi	sp,sp,-16
    80001fbc:	e406                	sd	ra,8(sp)
    80001fbe:	e022                	sd	s0,0(sp)
    80001fc0:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001fc2:	da3fe0ef          	jal	80000d64 <myproc>
}
    80001fc6:	5908                	lw	a0,48(a0)
    80001fc8:	60a2                	ld	ra,8(sp)
    80001fca:	6402                	ld	s0,0(sp)
    80001fcc:	0141                	addi	sp,sp,16
    80001fce:	8082                	ret

0000000080001fd0 <sys_fork>:

uint64
sys_fork(void)
{
    80001fd0:	1141                	addi	sp,sp,-16
    80001fd2:	e406                	sd	ra,8(sp)
    80001fd4:	e022                	sd	s0,0(sp)
    80001fd6:	0800                	addi	s0,sp,16
  return fork();
    80001fd8:	8e0ff0ef          	jal	800010b8 <fork>
}
    80001fdc:	60a2                	ld	ra,8(sp)
    80001fde:	6402                	ld	s0,0(sp)
    80001fe0:	0141                	addi	sp,sp,16
    80001fe2:	8082                	ret

0000000080001fe4 <sys_wait>:

uint64
sys_wait(void)
{
    80001fe4:	1101                	addi	sp,sp,-32
    80001fe6:	ec06                	sd	ra,24(sp)
    80001fe8:	e822                	sd	s0,16(sp)
    80001fea:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001fec:	fe840593          	addi	a1,s0,-24
    80001ff0:	4501                	li	a0,0
    80001ff2:	efdff0ef          	jal	80001eee <argaddr>
  return wait(p);
    80001ff6:	fe843503          	ld	a0,-24(s0)
    80001ffa:	f26ff0ef          	jal	80001720 <wait>
}
    80001ffe:	60e2                	ld	ra,24(sp)
    80002000:	6442                	ld	s0,16(sp)
    80002002:	6105                	addi	sp,sp,32
    80002004:	8082                	ret

0000000080002006 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002006:	7179                	addi	sp,sp,-48
    80002008:	f406                	sd	ra,40(sp)
    8000200a:	f022                	sd	s0,32(sp)
    8000200c:	ec26                	sd	s1,24(sp)
    8000200e:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002010:	fdc40593          	addi	a1,s0,-36
    80002014:	4501                	li	a0,0
    80002016:	ebdff0ef          	jal	80001ed2 <argint>
  addr = myproc()->sz;
    8000201a:	d4bfe0ef          	jal	80000d64 <myproc>
    8000201e:	653c                	ld	a5,72(a0)
    80002020:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80002022:	fdc42503          	lw	a0,-36(s0)
    80002026:	842ff0ef          	jal	80001068 <growproc>
    8000202a:	00054863          	bltz	a0,8000203a <sys_sbrk+0x34>
    return -1;
  return addr;
}
    8000202e:	8526                	mv	a0,s1
    80002030:	70a2                	ld	ra,40(sp)
    80002032:	7402                	ld	s0,32(sp)
    80002034:	64e2                	ld	s1,24(sp)
    80002036:	6145                	addi	sp,sp,48
    80002038:	8082                	ret
    return -1;
    8000203a:	57fd                	li	a5,-1
    8000203c:	84be                	mv	s1,a5
    8000203e:	bfc5                	j	8000202e <sys_sbrk+0x28>

0000000080002040 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002040:	7139                	addi	sp,sp,-64
    80002042:	fc06                	sd	ra,56(sp)
    80002044:	f822                	sd	s0,48(sp)
    80002046:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002048:	fcc40593          	addi	a1,s0,-52
    8000204c:	4501                	li	a0,0
    8000204e:	e85ff0ef          	jal	80001ed2 <argint>
  if(n < 0)
    80002052:	fcc42783          	lw	a5,-52(s0)
    80002056:	0607c863          	bltz	a5,800020c6 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    8000205a:	00017517          	auipc	a0,0x17
    8000205e:	6f650513          	addi	a0,a0,1782 # 80019750 <tickslock>
    80002062:	4ab030ef          	jal	80005d0c <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002066:	fcc42783          	lw	a5,-52(s0)
    8000206a:	c3b9                	beqz	a5,800020b0 <sys_sleep+0x70>
    8000206c:	f426                	sd	s1,40(sp)
    8000206e:	f04a                	sd	s2,32(sp)
    80002070:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002072:	00006997          	auipc	s3,0x6
    80002076:	8769a983          	lw	s3,-1930(s3) # 800078e8 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    8000207a:	00017917          	auipc	s2,0x17
    8000207e:	6d690913          	addi	s2,s2,1750 # 80019750 <tickslock>
    80002082:	00006497          	auipc	s1,0x6
    80002086:	86648493          	addi	s1,s1,-1946 # 800078e8 <ticks>
    if(killed(myproc())){
    8000208a:	cdbfe0ef          	jal	80000d64 <myproc>
    8000208e:	e68ff0ef          	jal	800016f6 <killed>
    80002092:	ed0d                	bnez	a0,800020cc <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80002094:	85ca                	mv	a1,s2
    80002096:	8526                	mv	a0,s1
    80002098:	b1aff0ef          	jal	800013b2 <sleep>
  while(ticks - ticks0 < n){
    8000209c:	409c                	lw	a5,0(s1)
    8000209e:	413787bb          	subw	a5,a5,s3
    800020a2:	fcc42703          	lw	a4,-52(s0)
    800020a6:	fee7e2e3          	bltu	a5,a4,8000208a <sys_sleep+0x4a>
    800020aa:	74a2                	ld	s1,40(sp)
    800020ac:	7902                	ld	s2,32(sp)
    800020ae:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    800020b0:	00017517          	auipc	a0,0x17
    800020b4:	6a050513          	addi	a0,a0,1696 # 80019750 <tickslock>
    800020b8:	4e9030ef          	jal	80005da0 <release>
  return 0;
    800020bc:	4501                	li	a0,0
}
    800020be:	70e2                	ld	ra,56(sp)
    800020c0:	7442                	ld	s0,48(sp)
    800020c2:	6121                	addi	sp,sp,64
    800020c4:	8082                	ret
    n = 0;
    800020c6:	fc042623          	sw	zero,-52(s0)
    800020ca:	bf41                	j	8000205a <sys_sleep+0x1a>
      release(&tickslock);
    800020cc:	00017517          	auipc	a0,0x17
    800020d0:	68450513          	addi	a0,a0,1668 # 80019750 <tickslock>
    800020d4:	4cd030ef          	jal	80005da0 <release>
      return -1;
    800020d8:	557d                	li	a0,-1
    800020da:	74a2                	ld	s1,40(sp)
    800020dc:	7902                	ld	s2,32(sp)
    800020de:	69e2                	ld	s3,24(sp)
    800020e0:	bff9                	j	800020be <sys_sleep+0x7e>

00000000800020e2 <sys_kill>:

uint64
sys_kill(void)
{
    800020e2:	1101                	addi	sp,sp,-32
    800020e4:	ec06                	sd	ra,24(sp)
    800020e6:	e822                	sd	s0,16(sp)
    800020e8:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    800020ea:	fec40593          	addi	a1,s0,-20
    800020ee:	4501                	li	a0,0
    800020f0:	de3ff0ef          	jal	80001ed2 <argint>
  return kill(pid);
    800020f4:	fec42503          	lw	a0,-20(s0)
    800020f8:	d74ff0ef          	jal	8000166c <kill>
}
    800020fc:	60e2                	ld	ra,24(sp)
    800020fe:	6442                	ld	s0,16(sp)
    80002100:	6105                	addi	sp,sp,32
    80002102:	8082                	ret

0000000080002104 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002104:	1101                	addi	sp,sp,-32
    80002106:	ec06                	sd	ra,24(sp)
    80002108:	e822                	sd	s0,16(sp)
    8000210a:	e426                	sd	s1,8(sp)
    8000210c:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    8000210e:	00017517          	auipc	a0,0x17
    80002112:	64250513          	addi	a0,a0,1602 # 80019750 <tickslock>
    80002116:	3f7030ef          	jal	80005d0c <acquire>
  xticks = ticks;
    8000211a:	00005797          	auipc	a5,0x5
    8000211e:	7ce7a783          	lw	a5,1998(a5) # 800078e8 <ticks>
    80002122:	84be                	mv	s1,a5
  release(&tickslock);
    80002124:	00017517          	auipc	a0,0x17
    80002128:	62c50513          	addi	a0,a0,1580 # 80019750 <tickslock>
    8000212c:	475030ef          	jal	80005da0 <release>
  return xticks;
}
    80002130:	02049513          	slli	a0,s1,0x20
    80002134:	9101                	srli	a0,a0,0x20
    80002136:	60e2                	ld	ra,24(sp)
    80002138:	6442                	ld	s0,16(sp)
    8000213a:	64a2                	ld	s1,8(sp)
    8000213c:	6105                	addi	sp,sp,32
    8000213e:	8082                	ret

0000000080002140 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002140:	7179                	addi	sp,sp,-48
    80002142:	f406                	sd	ra,40(sp)
    80002144:	f022                	sd	s0,32(sp)
    80002146:	ec26                	sd	s1,24(sp)
    80002148:	e84a                	sd	s2,16(sp)
    8000214a:	e44e                	sd	s3,8(sp)
    8000214c:	e052                	sd	s4,0(sp)
    8000214e:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002150:	00005597          	auipc	a1,0x5
    80002154:	25858593          	addi	a1,a1,600 # 800073a8 <etext+0x3a8>
    80002158:	00017517          	auipc	a0,0x17
    8000215c:	61050513          	addi	a0,a0,1552 # 80019768 <bcache>
    80002160:	323030ef          	jal	80005c82 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002164:	0001f797          	auipc	a5,0x1f
    80002168:	60478793          	addi	a5,a5,1540 # 80021768 <bcache+0x8000>
    8000216c:	00020717          	auipc	a4,0x20
    80002170:	86470713          	addi	a4,a4,-1948 # 800219d0 <bcache+0x8268>
    80002174:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002178:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000217c:	00017497          	auipc	s1,0x17
    80002180:	60448493          	addi	s1,s1,1540 # 80019780 <bcache+0x18>
    b->next = bcache.head.next;
    80002184:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002186:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002188:	00005a17          	auipc	s4,0x5
    8000218c:	228a0a13          	addi	s4,s4,552 # 800073b0 <etext+0x3b0>
    b->next = bcache.head.next;
    80002190:	2b893783          	ld	a5,696(s2)
    80002194:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002196:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    8000219a:	85d2                	mv	a1,s4
    8000219c:	01048513          	addi	a0,s1,16
    800021a0:	24c010ef          	jal	800033ec <initsleeplock>
    bcache.head.next->prev = b;
    800021a4:	2b893783          	ld	a5,696(s2)
    800021a8:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    800021aa:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    800021ae:	45848493          	addi	s1,s1,1112
    800021b2:	fd349fe3          	bne	s1,s3,80002190 <binit+0x50>
  }
}
    800021b6:	70a2                	ld	ra,40(sp)
    800021b8:	7402                	ld	s0,32(sp)
    800021ba:	64e2                	ld	s1,24(sp)
    800021bc:	6942                	ld	s2,16(sp)
    800021be:	69a2                	ld	s3,8(sp)
    800021c0:	6a02                	ld	s4,0(sp)
    800021c2:	6145                	addi	sp,sp,48
    800021c4:	8082                	ret

00000000800021c6 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    800021c6:	7179                	addi	sp,sp,-48
    800021c8:	f406                	sd	ra,40(sp)
    800021ca:	f022                	sd	s0,32(sp)
    800021cc:	ec26                	sd	s1,24(sp)
    800021ce:	e84a                	sd	s2,16(sp)
    800021d0:	e44e                	sd	s3,8(sp)
    800021d2:	1800                	addi	s0,sp,48
    800021d4:	892a                	mv	s2,a0
    800021d6:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    800021d8:	00017517          	auipc	a0,0x17
    800021dc:	59050513          	addi	a0,a0,1424 # 80019768 <bcache>
    800021e0:	32d030ef          	jal	80005d0c <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    800021e4:	00020497          	auipc	s1,0x20
    800021e8:	83c4b483          	ld	s1,-1988(s1) # 80021a20 <bcache+0x82b8>
    800021ec:	0001f797          	auipc	a5,0x1f
    800021f0:	7e478793          	addi	a5,a5,2020 # 800219d0 <bcache+0x8268>
    800021f4:	02f48b63          	beq	s1,a5,8000222a <bread+0x64>
    800021f8:	873e                	mv	a4,a5
    800021fa:	a021                	j	80002202 <bread+0x3c>
    800021fc:	68a4                	ld	s1,80(s1)
    800021fe:	02e48663          	beq	s1,a4,8000222a <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002202:	449c                	lw	a5,8(s1)
    80002204:	ff279ce3          	bne	a5,s2,800021fc <bread+0x36>
    80002208:	44dc                	lw	a5,12(s1)
    8000220a:	ff3799e3          	bne	a5,s3,800021fc <bread+0x36>
      b->refcnt++;
    8000220e:	40bc                	lw	a5,64(s1)
    80002210:	2785                	addiw	a5,a5,1
    80002212:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002214:	00017517          	auipc	a0,0x17
    80002218:	55450513          	addi	a0,a0,1364 # 80019768 <bcache>
    8000221c:	385030ef          	jal	80005da0 <release>
      acquiresleep(&b->lock);
    80002220:	01048513          	addi	a0,s1,16
    80002224:	1fe010ef          	jal	80003422 <acquiresleep>
      return b;
    80002228:	a889                	j	8000227a <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    8000222a:	0001f497          	auipc	s1,0x1f
    8000222e:	7ee4b483          	ld	s1,2030(s1) # 80021a18 <bcache+0x82b0>
    80002232:	0001f797          	auipc	a5,0x1f
    80002236:	79e78793          	addi	a5,a5,1950 # 800219d0 <bcache+0x8268>
    8000223a:	00f48863          	beq	s1,a5,8000224a <bread+0x84>
    8000223e:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002240:	40bc                	lw	a5,64(s1)
    80002242:	cb91                	beqz	a5,80002256 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002244:	64a4                	ld	s1,72(s1)
    80002246:	fee49de3          	bne	s1,a4,80002240 <bread+0x7a>
  panic("bget: no buffers");
    8000224a:	00005517          	auipc	a0,0x5
    8000224e:	16e50513          	addi	a0,a0,366 # 800073b8 <etext+0x3b8>
    80002252:	77c030ef          	jal	800059ce <panic>
      b->dev = dev;
    80002256:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    8000225a:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    8000225e:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002262:	4785                	li	a5,1
    80002264:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002266:	00017517          	auipc	a0,0x17
    8000226a:	50250513          	addi	a0,a0,1282 # 80019768 <bcache>
    8000226e:	333030ef          	jal	80005da0 <release>
      acquiresleep(&b->lock);
    80002272:	01048513          	addi	a0,s1,16
    80002276:	1ac010ef          	jal	80003422 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    8000227a:	409c                	lw	a5,0(s1)
    8000227c:	cb89                	beqz	a5,8000228e <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000227e:	8526                	mv	a0,s1
    80002280:	70a2                	ld	ra,40(sp)
    80002282:	7402                	ld	s0,32(sp)
    80002284:	64e2                	ld	s1,24(sp)
    80002286:	6942                	ld	s2,16(sp)
    80002288:	69a2                	ld	s3,8(sp)
    8000228a:	6145                	addi	sp,sp,48
    8000228c:	8082                	ret
    virtio_disk_rw(b, 0);
    8000228e:	4581                	li	a1,0
    80002290:	8526                	mv	a0,s1
    80002292:	4bf020ef          	jal	80004f50 <virtio_disk_rw>
    b->valid = 1;
    80002296:	4785                	li	a5,1
    80002298:	c09c                	sw	a5,0(s1)
  return b;
    8000229a:	b7d5                	j	8000227e <bread+0xb8>

000000008000229c <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000229c:	1101                	addi	sp,sp,-32
    8000229e:	ec06                	sd	ra,24(sp)
    800022a0:	e822                	sd	s0,16(sp)
    800022a2:	e426                	sd	s1,8(sp)
    800022a4:	1000                	addi	s0,sp,32
    800022a6:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    800022a8:	0541                	addi	a0,a0,16
    800022aa:	1f6010ef          	jal	800034a0 <holdingsleep>
    800022ae:	c911                	beqz	a0,800022c2 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    800022b0:	4585                	li	a1,1
    800022b2:	8526                	mv	a0,s1
    800022b4:	49d020ef          	jal	80004f50 <virtio_disk_rw>
}
    800022b8:	60e2                	ld	ra,24(sp)
    800022ba:	6442                	ld	s0,16(sp)
    800022bc:	64a2                	ld	s1,8(sp)
    800022be:	6105                	addi	sp,sp,32
    800022c0:	8082                	ret
    panic("bwrite");
    800022c2:	00005517          	auipc	a0,0x5
    800022c6:	10e50513          	addi	a0,a0,270 # 800073d0 <etext+0x3d0>
    800022ca:	704030ef          	jal	800059ce <panic>

00000000800022ce <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    800022ce:	1101                	addi	sp,sp,-32
    800022d0:	ec06                	sd	ra,24(sp)
    800022d2:	e822                	sd	s0,16(sp)
    800022d4:	e426                	sd	s1,8(sp)
    800022d6:	e04a                	sd	s2,0(sp)
    800022d8:	1000                	addi	s0,sp,32
    800022da:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    800022dc:	01050913          	addi	s2,a0,16
    800022e0:	854a                	mv	a0,s2
    800022e2:	1be010ef          	jal	800034a0 <holdingsleep>
    800022e6:	c125                	beqz	a0,80002346 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    800022e8:	854a                	mv	a0,s2
    800022ea:	17e010ef          	jal	80003468 <releasesleep>

  acquire(&bcache.lock);
    800022ee:	00017517          	auipc	a0,0x17
    800022f2:	47a50513          	addi	a0,a0,1146 # 80019768 <bcache>
    800022f6:	217030ef          	jal	80005d0c <acquire>
  b->refcnt--;
    800022fa:	40bc                	lw	a5,64(s1)
    800022fc:	37fd                	addiw	a5,a5,-1
    800022fe:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002300:	e79d                	bnez	a5,8000232e <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002302:	68b8                	ld	a4,80(s1)
    80002304:	64bc                	ld	a5,72(s1)
    80002306:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002308:	68b8                	ld	a4,80(s1)
    8000230a:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    8000230c:	0001f797          	auipc	a5,0x1f
    80002310:	45c78793          	addi	a5,a5,1116 # 80021768 <bcache+0x8000>
    80002314:	2b87b703          	ld	a4,696(a5)
    80002318:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    8000231a:	0001f717          	auipc	a4,0x1f
    8000231e:	6b670713          	addi	a4,a4,1718 # 800219d0 <bcache+0x8268>
    80002322:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002324:	2b87b703          	ld	a4,696(a5)
    80002328:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    8000232a:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    8000232e:	00017517          	auipc	a0,0x17
    80002332:	43a50513          	addi	a0,a0,1082 # 80019768 <bcache>
    80002336:	26b030ef          	jal	80005da0 <release>
}
    8000233a:	60e2                	ld	ra,24(sp)
    8000233c:	6442                	ld	s0,16(sp)
    8000233e:	64a2                	ld	s1,8(sp)
    80002340:	6902                	ld	s2,0(sp)
    80002342:	6105                	addi	sp,sp,32
    80002344:	8082                	ret
    panic("brelse");
    80002346:	00005517          	auipc	a0,0x5
    8000234a:	09250513          	addi	a0,a0,146 # 800073d8 <etext+0x3d8>
    8000234e:	680030ef          	jal	800059ce <panic>

0000000080002352 <bpin>:

void
bpin(struct buf *b) {
    80002352:	1101                	addi	sp,sp,-32
    80002354:	ec06                	sd	ra,24(sp)
    80002356:	e822                	sd	s0,16(sp)
    80002358:	e426                	sd	s1,8(sp)
    8000235a:	1000                	addi	s0,sp,32
    8000235c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000235e:	00017517          	auipc	a0,0x17
    80002362:	40a50513          	addi	a0,a0,1034 # 80019768 <bcache>
    80002366:	1a7030ef          	jal	80005d0c <acquire>
  b->refcnt++;
    8000236a:	40bc                	lw	a5,64(s1)
    8000236c:	2785                	addiw	a5,a5,1
    8000236e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002370:	00017517          	auipc	a0,0x17
    80002374:	3f850513          	addi	a0,a0,1016 # 80019768 <bcache>
    80002378:	229030ef          	jal	80005da0 <release>
}
    8000237c:	60e2                	ld	ra,24(sp)
    8000237e:	6442                	ld	s0,16(sp)
    80002380:	64a2                	ld	s1,8(sp)
    80002382:	6105                	addi	sp,sp,32
    80002384:	8082                	ret

0000000080002386 <bunpin>:

void
bunpin(struct buf *b) {
    80002386:	1101                	addi	sp,sp,-32
    80002388:	ec06                	sd	ra,24(sp)
    8000238a:	e822                	sd	s0,16(sp)
    8000238c:	e426                	sd	s1,8(sp)
    8000238e:	1000                	addi	s0,sp,32
    80002390:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002392:	00017517          	auipc	a0,0x17
    80002396:	3d650513          	addi	a0,a0,982 # 80019768 <bcache>
    8000239a:	173030ef          	jal	80005d0c <acquire>
  b->refcnt--;
    8000239e:	40bc                	lw	a5,64(s1)
    800023a0:	37fd                	addiw	a5,a5,-1
    800023a2:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800023a4:	00017517          	auipc	a0,0x17
    800023a8:	3c450513          	addi	a0,a0,964 # 80019768 <bcache>
    800023ac:	1f5030ef          	jal	80005da0 <release>
}
    800023b0:	60e2                	ld	ra,24(sp)
    800023b2:	6442                	ld	s0,16(sp)
    800023b4:	64a2                	ld	s1,8(sp)
    800023b6:	6105                	addi	sp,sp,32
    800023b8:	8082                	ret

00000000800023ba <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    800023ba:	1101                	addi	sp,sp,-32
    800023bc:	ec06                	sd	ra,24(sp)
    800023be:	e822                	sd	s0,16(sp)
    800023c0:	e426                	sd	s1,8(sp)
    800023c2:	e04a                	sd	s2,0(sp)
    800023c4:	1000                	addi	s0,sp,32
    800023c6:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    800023c8:	00d5d79b          	srliw	a5,a1,0xd
    800023cc:	00020597          	auipc	a1,0x20
    800023d0:	a785a583          	lw	a1,-1416(a1) # 80021e44 <sb+0x1c>
    800023d4:	9dbd                	addw	a1,a1,a5
    800023d6:	df1ff0ef          	jal	800021c6 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    800023da:	0074f713          	andi	a4,s1,7
    800023de:	4785                	li	a5,1
    800023e0:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    800023e4:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    800023e6:	90d9                	srli	s1,s1,0x36
    800023e8:	00950733          	add	a4,a0,s1
    800023ec:	05874703          	lbu	a4,88(a4)
    800023f0:	00e7f6b3          	and	a3,a5,a4
    800023f4:	c29d                	beqz	a3,8000241a <bfree+0x60>
    800023f6:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800023f8:	94aa                	add	s1,s1,a0
    800023fa:	fff7c793          	not	a5,a5
    800023fe:	8f7d                	and	a4,a4,a5
    80002400:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002404:	717000ef          	jal	8000331a <log_write>
  brelse(bp);
    80002408:	854a                	mv	a0,s2
    8000240a:	ec5ff0ef          	jal	800022ce <brelse>
}
    8000240e:	60e2                	ld	ra,24(sp)
    80002410:	6442                	ld	s0,16(sp)
    80002412:	64a2                	ld	s1,8(sp)
    80002414:	6902                	ld	s2,0(sp)
    80002416:	6105                	addi	sp,sp,32
    80002418:	8082                	ret
    panic("freeing free block");
    8000241a:	00005517          	auipc	a0,0x5
    8000241e:	fc650513          	addi	a0,a0,-58 # 800073e0 <etext+0x3e0>
    80002422:	5ac030ef          	jal	800059ce <panic>

0000000080002426 <balloc>:
{
    80002426:	715d                	addi	sp,sp,-80
    80002428:	e486                	sd	ra,72(sp)
    8000242a:	e0a2                	sd	s0,64(sp)
    8000242c:	fc26                	sd	s1,56(sp)
    8000242e:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002430:	00020797          	auipc	a5,0x20
    80002434:	9fc7a783          	lw	a5,-1540(a5) # 80021e2c <sb+0x4>
    80002438:	0e078263          	beqz	a5,8000251c <balloc+0xf6>
    8000243c:	f84a                	sd	s2,48(sp)
    8000243e:	f44e                	sd	s3,40(sp)
    80002440:	f052                	sd	s4,32(sp)
    80002442:	ec56                	sd	s5,24(sp)
    80002444:	e85a                	sd	s6,16(sp)
    80002446:	e45e                	sd	s7,8(sp)
    80002448:	e062                	sd	s8,0(sp)
    8000244a:	8baa                	mv	s7,a0
    8000244c:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    8000244e:	00020b17          	auipc	s6,0x20
    80002452:	9dab0b13          	addi	s6,s6,-1574 # 80021e28 <sb>
      m = 1 << (bi % 8);
    80002456:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002458:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    8000245a:	6c09                	lui	s8,0x2
    8000245c:	a09d                	j	800024c2 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    8000245e:	97ca                	add	a5,a5,s2
    80002460:	8e55                	or	a2,a2,a3
    80002462:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002466:	854a                	mv	a0,s2
    80002468:	6b3000ef          	jal	8000331a <log_write>
        brelse(bp);
    8000246c:	854a                	mv	a0,s2
    8000246e:	e61ff0ef          	jal	800022ce <brelse>
  bp = bread(dev, bno);
    80002472:	85a6                	mv	a1,s1
    80002474:	855e                	mv	a0,s7
    80002476:	d51ff0ef          	jal	800021c6 <bread>
    8000247a:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    8000247c:	40000613          	li	a2,1024
    80002480:	4581                	li	a1,0
    80002482:	05850513          	addi	a0,a0,88
    80002486:	cd9fd0ef          	jal	8000015e <memset>
  log_write(bp);
    8000248a:	854a                	mv	a0,s2
    8000248c:	68f000ef          	jal	8000331a <log_write>
  brelse(bp);
    80002490:	854a                	mv	a0,s2
    80002492:	e3dff0ef          	jal	800022ce <brelse>
}
    80002496:	7942                	ld	s2,48(sp)
    80002498:	79a2                	ld	s3,40(sp)
    8000249a:	7a02                	ld	s4,32(sp)
    8000249c:	6ae2                	ld	s5,24(sp)
    8000249e:	6b42                	ld	s6,16(sp)
    800024a0:	6ba2                	ld	s7,8(sp)
    800024a2:	6c02                	ld	s8,0(sp)
}
    800024a4:	8526                	mv	a0,s1
    800024a6:	60a6                	ld	ra,72(sp)
    800024a8:	6406                	ld	s0,64(sp)
    800024aa:	74e2                	ld	s1,56(sp)
    800024ac:	6161                	addi	sp,sp,80
    800024ae:	8082                	ret
    brelse(bp);
    800024b0:	854a                	mv	a0,s2
    800024b2:	e1dff0ef          	jal	800022ce <brelse>
  for(b = 0; b < sb.size; b += BPB){
    800024b6:	015c0abb          	addw	s5,s8,s5
    800024ba:	004b2783          	lw	a5,4(s6)
    800024be:	04faf863          	bgeu	s5,a5,8000250e <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    800024c2:	40dad59b          	sraiw	a1,s5,0xd
    800024c6:	01cb2783          	lw	a5,28(s6)
    800024ca:	9dbd                	addw	a1,a1,a5
    800024cc:	855e                	mv	a0,s7
    800024ce:	cf9ff0ef          	jal	800021c6 <bread>
    800024d2:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800024d4:	004b2503          	lw	a0,4(s6)
    800024d8:	84d6                	mv	s1,s5
    800024da:	4701                	li	a4,0
    800024dc:	fca4fae3          	bgeu	s1,a0,800024b0 <balloc+0x8a>
      m = 1 << (bi % 8);
    800024e0:	00777693          	andi	a3,a4,7
    800024e4:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800024e8:	41f7579b          	sraiw	a5,a4,0x1f
    800024ec:	01d7d79b          	srliw	a5,a5,0x1d
    800024f0:	9fb9                	addw	a5,a5,a4
    800024f2:	4037d79b          	sraiw	a5,a5,0x3
    800024f6:	00f90633          	add	a2,s2,a5
    800024fa:	05864603          	lbu	a2,88(a2) # 1058 <_entry-0x7fffefa8>
    800024fe:	00c6f5b3          	and	a1,a3,a2
    80002502:	ddb1                	beqz	a1,8000245e <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002504:	2705                	addiw	a4,a4,1
    80002506:	2485                	addiw	s1,s1,1
    80002508:	fd471ae3          	bne	a4,s4,800024dc <balloc+0xb6>
    8000250c:	b755                	j	800024b0 <balloc+0x8a>
    8000250e:	7942                	ld	s2,48(sp)
    80002510:	79a2                	ld	s3,40(sp)
    80002512:	7a02                	ld	s4,32(sp)
    80002514:	6ae2                	ld	s5,24(sp)
    80002516:	6b42                	ld	s6,16(sp)
    80002518:	6ba2                	ld	s7,8(sp)
    8000251a:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    8000251c:	00005517          	auipc	a0,0x5
    80002520:	edc50513          	addi	a0,a0,-292 # 800073f8 <etext+0x3f8>
    80002524:	19a030ef          	jal	800056be <printf>
  return 0;
    80002528:	4481                	li	s1,0
    8000252a:	bfad                	j	800024a4 <balloc+0x7e>

000000008000252c <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000252c:	7179                	addi	sp,sp,-48
    8000252e:	f406                	sd	ra,40(sp)
    80002530:	f022                	sd	s0,32(sp)
    80002532:	ec26                	sd	s1,24(sp)
    80002534:	e84a                	sd	s2,16(sp)
    80002536:	e44e                	sd	s3,8(sp)
    80002538:	1800                	addi	s0,sp,48
    8000253a:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    8000253c:	47ad                	li	a5,11
    8000253e:	02b7e363          	bltu	a5,a1,80002564 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80002542:	02059793          	slli	a5,a1,0x20
    80002546:	01e7d593          	srli	a1,a5,0x1e
    8000254a:	00b509b3          	add	s3,a0,a1
    8000254e:	0509a483          	lw	s1,80(s3)
    80002552:	e0b5                	bnez	s1,800025b6 <bmap+0x8a>
      addr = balloc(ip->dev);
    80002554:	4108                	lw	a0,0(a0)
    80002556:	ed1ff0ef          	jal	80002426 <balloc>
    8000255a:	84aa                	mv	s1,a0
      if(addr == 0)
    8000255c:	cd29                	beqz	a0,800025b6 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    8000255e:	04a9a823          	sw	a0,80(s3)
    80002562:	a891                	j	800025b6 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002564:	ff45879b          	addiw	a5,a1,-12
    80002568:	873e                	mv	a4,a5
    8000256a:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    8000256c:	0ff00793          	li	a5,255
    80002570:	06e7e763          	bltu	a5,a4,800025de <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002574:	08052483          	lw	s1,128(a0)
    80002578:	e891                	bnez	s1,8000258c <bmap+0x60>
      addr = balloc(ip->dev);
    8000257a:	4108                	lw	a0,0(a0)
    8000257c:	eabff0ef          	jal	80002426 <balloc>
    80002580:	84aa                	mv	s1,a0
      if(addr == 0)
    80002582:	c915                	beqz	a0,800025b6 <bmap+0x8a>
    80002584:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002586:	08a92023          	sw	a0,128(s2)
    8000258a:	a011                	j	8000258e <bmap+0x62>
    8000258c:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000258e:	85a6                	mv	a1,s1
    80002590:	00092503          	lw	a0,0(s2)
    80002594:	c33ff0ef          	jal	800021c6 <bread>
    80002598:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    8000259a:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000259e:	02099713          	slli	a4,s3,0x20
    800025a2:	01e75593          	srli	a1,a4,0x1e
    800025a6:	97ae                	add	a5,a5,a1
    800025a8:	89be                	mv	s3,a5
    800025aa:	4384                	lw	s1,0(a5)
    800025ac:	cc89                	beqz	s1,800025c6 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    800025ae:	8552                	mv	a0,s4
    800025b0:	d1fff0ef          	jal	800022ce <brelse>
    return addr;
    800025b4:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    800025b6:	8526                	mv	a0,s1
    800025b8:	70a2                	ld	ra,40(sp)
    800025ba:	7402                	ld	s0,32(sp)
    800025bc:	64e2                	ld	s1,24(sp)
    800025be:	6942                	ld	s2,16(sp)
    800025c0:	69a2                	ld	s3,8(sp)
    800025c2:	6145                	addi	sp,sp,48
    800025c4:	8082                	ret
      addr = balloc(ip->dev);
    800025c6:	00092503          	lw	a0,0(s2)
    800025ca:	e5dff0ef          	jal	80002426 <balloc>
    800025ce:	84aa                	mv	s1,a0
      if(addr){
    800025d0:	dd79                	beqz	a0,800025ae <bmap+0x82>
        a[bn] = addr;
    800025d2:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    800025d6:	8552                	mv	a0,s4
    800025d8:	543000ef          	jal	8000331a <log_write>
    800025dc:	bfc9                	j	800025ae <bmap+0x82>
    800025de:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800025e0:	00005517          	auipc	a0,0x5
    800025e4:	e3050513          	addi	a0,a0,-464 # 80007410 <etext+0x410>
    800025e8:	3e6030ef          	jal	800059ce <panic>

00000000800025ec <iget>:
{
    800025ec:	7179                	addi	sp,sp,-48
    800025ee:	f406                	sd	ra,40(sp)
    800025f0:	f022                	sd	s0,32(sp)
    800025f2:	ec26                	sd	s1,24(sp)
    800025f4:	e84a                	sd	s2,16(sp)
    800025f6:	e44e                	sd	s3,8(sp)
    800025f8:	e052                	sd	s4,0(sp)
    800025fa:	1800                	addi	s0,sp,48
    800025fc:	892a                	mv	s2,a0
    800025fe:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80002600:	00020517          	auipc	a0,0x20
    80002604:	84850513          	addi	a0,a0,-1976 # 80021e48 <itable>
    80002608:	704030ef          	jal	80005d0c <acquire>
  empty = 0;
    8000260c:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000260e:	00020497          	auipc	s1,0x20
    80002612:	85248493          	addi	s1,s1,-1966 # 80021e60 <itable+0x18>
    80002616:	00021697          	auipc	a3,0x21
    8000261a:	2da68693          	addi	a3,a3,730 # 800238f0 <log>
    8000261e:	a809                	j	80002630 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002620:	e781                	bnez	a5,80002628 <iget+0x3c>
    80002622:	00099363          	bnez	s3,80002628 <iget+0x3c>
      empty = ip;
    80002626:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002628:	08848493          	addi	s1,s1,136
    8000262c:	02d48563          	beq	s1,a3,80002656 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80002630:	449c                	lw	a5,8(s1)
    80002632:	fef057e3          	blez	a5,80002620 <iget+0x34>
    80002636:	4098                	lw	a4,0(s1)
    80002638:	ff2718e3          	bne	a4,s2,80002628 <iget+0x3c>
    8000263c:	40d8                	lw	a4,4(s1)
    8000263e:	ff4715e3          	bne	a4,s4,80002628 <iget+0x3c>
      ip->ref++;
    80002642:	2785                	addiw	a5,a5,1
    80002644:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002646:	00020517          	auipc	a0,0x20
    8000264a:	80250513          	addi	a0,a0,-2046 # 80021e48 <itable>
    8000264e:	752030ef          	jal	80005da0 <release>
      return ip;
    80002652:	89a6                	mv	s3,s1
    80002654:	a015                	j	80002678 <iget+0x8c>
  if(empty == 0)
    80002656:	02098a63          	beqz	s3,8000268a <iget+0x9e>
  ip->dev = dev;
    8000265a:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    8000265e:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80002662:	4785                	li	a5,1
    80002664:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    80002668:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    8000266c:	0001f517          	auipc	a0,0x1f
    80002670:	7dc50513          	addi	a0,a0,2012 # 80021e48 <itable>
    80002674:	72c030ef          	jal	80005da0 <release>
}
    80002678:	854e                	mv	a0,s3
    8000267a:	70a2                	ld	ra,40(sp)
    8000267c:	7402                	ld	s0,32(sp)
    8000267e:	64e2                	ld	s1,24(sp)
    80002680:	6942                	ld	s2,16(sp)
    80002682:	69a2                	ld	s3,8(sp)
    80002684:	6a02                	ld	s4,0(sp)
    80002686:	6145                	addi	sp,sp,48
    80002688:	8082                	ret
    panic("iget: no inodes");
    8000268a:	00005517          	auipc	a0,0x5
    8000268e:	d9e50513          	addi	a0,a0,-610 # 80007428 <etext+0x428>
    80002692:	33c030ef          	jal	800059ce <panic>

0000000080002696 <fsinit>:
fsinit(int dev) {
    80002696:	1101                	addi	sp,sp,-32
    80002698:	ec06                	sd	ra,24(sp)
    8000269a:	e822                	sd	s0,16(sp)
    8000269c:	e426                	sd	s1,8(sp)
    8000269e:	e04a                	sd	s2,0(sp)
    800026a0:	1000                	addi	s0,sp,32
    800026a2:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    800026a4:	4585                	li	a1,1
    800026a6:	b21ff0ef          	jal	800021c6 <bread>
    800026aa:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    800026ac:	02000613          	li	a2,32
    800026b0:	05850593          	addi	a1,a0,88
    800026b4:	0001f517          	auipc	a0,0x1f
    800026b8:	77450513          	addi	a0,a0,1908 # 80021e28 <sb>
    800026bc:	b03fd0ef          	jal	800001be <memmove>
  brelse(bp);
    800026c0:	8526                	mv	a0,s1
    800026c2:	c0dff0ef          	jal	800022ce <brelse>
  if(sb.magic != FSMAGIC)
    800026c6:	0001f717          	auipc	a4,0x1f
    800026ca:	76272703          	lw	a4,1890(a4) # 80021e28 <sb>
    800026ce:	102037b7          	lui	a5,0x10203
    800026d2:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800026d6:	00f71f63          	bne	a4,a5,800026f4 <fsinit+0x5e>
  initlog(dev, &sb);
    800026da:	0001f597          	auipc	a1,0x1f
    800026de:	74e58593          	addi	a1,a1,1870 # 80021e28 <sb>
    800026e2:	854a                	mv	a0,s2
    800026e4:	219000ef          	jal	800030fc <initlog>
}
    800026e8:	60e2                	ld	ra,24(sp)
    800026ea:	6442                	ld	s0,16(sp)
    800026ec:	64a2                	ld	s1,8(sp)
    800026ee:	6902                	ld	s2,0(sp)
    800026f0:	6105                	addi	sp,sp,32
    800026f2:	8082                	ret
    panic("invalid file system");
    800026f4:	00005517          	auipc	a0,0x5
    800026f8:	d4450513          	addi	a0,a0,-700 # 80007438 <etext+0x438>
    800026fc:	2d2030ef          	jal	800059ce <panic>

0000000080002700 <iinit>:
{
    80002700:	7179                	addi	sp,sp,-48
    80002702:	f406                	sd	ra,40(sp)
    80002704:	f022                	sd	s0,32(sp)
    80002706:	ec26                	sd	s1,24(sp)
    80002708:	e84a                	sd	s2,16(sp)
    8000270a:	e44e                	sd	s3,8(sp)
    8000270c:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000270e:	00005597          	auipc	a1,0x5
    80002712:	d4258593          	addi	a1,a1,-702 # 80007450 <etext+0x450>
    80002716:	0001f517          	auipc	a0,0x1f
    8000271a:	73250513          	addi	a0,a0,1842 # 80021e48 <itable>
    8000271e:	564030ef          	jal	80005c82 <initlock>
  for(i = 0; i < NINODE; i++) {
    80002722:	0001f497          	auipc	s1,0x1f
    80002726:	74e48493          	addi	s1,s1,1870 # 80021e70 <itable+0x28>
    8000272a:	00021997          	auipc	s3,0x21
    8000272e:	1d698993          	addi	s3,s3,470 # 80023900 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80002732:	00005917          	auipc	s2,0x5
    80002736:	d2690913          	addi	s2,s2,-730 # 80007458 <etext+0x458>
    8000273a:	85ca                	mv	a1,s2
    8000273c:	8526                	mv	a0,s1
    8000273e:	4af000ef          	jal	800033ec <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80002742:	08848493          	addi	s1,s1,136
    80002746:	ff349ae3          	bne	s1,s3,8000273a <iinit+0x3a>
}
    8000274a:	70a2                	ld	ra,40(sp)
    8000274c:	7402                	ld	s0,32(sp)
    8000274e:	64e2                	ld	s1,24(sp)
    80002750:	6942                	ld	s2,16(sp)
    80002752:	69a2                	ld	s3,8(sp)
    80002754:	6145                	addi	sp,sp,48
    80002756:	8082                	ret

0000000080002758 <ialloc>:
{
    80002758:	7139                	addi	sp,sp,-64
    8000275a:	fc06                	sd	ra,56(sp)
    8000275c:	f822                	sd	s0,48(sp)
    8000275e:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80002760:	0001f717          	auipc	a4,0x1f
    80002764:	6d472703          	lw	a4,1748(a4) # 80021e34 <sb+0xc>
    80002768:	4785                	li	a5,1
    8000276a:	06e7f063          	bgeu	a5,a4,800027ca <ialloc+0x72>
    8000276e:	f426                	sd	s1,40(sp)
    80002770:	f04a                	sd	s2,32(sp)
    80002772:	ec4e                	sd	s3,24(sp)
    80002774:	e852                	sd	s4,16(sp)
    80002776:	e456                	sd	s5,8(sp)
    80002778:	e05a                	sd	s6,0(sp)
    8000277a:	8aaa                	mv	s5,a0
    8000277c:	8b2e                	mv	s6,a1
    8000277e:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80002780:	0001fa17          	auipc	s4,0x1f
    80002784:	6a8a0a13          	addi	s4,s4,1704 # 80021e28 <sb>
    80002788:	00495593          	srli	a1,s2,0x4
    8000278c:	018a2783          	lw	a5,24(s4)
    80002790:	9dbd                	addw	a1,a1,a5
    80002792:	8556                	mv	a0,s5
    80002794:	a33ff0ef          	jal	800021c6 <bread>
    80002798:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    8000279a:	05850993          	addi	s3,a0,88
    8000279e:	00f97793          	andi	a5,s2,15
    800027a2:	079a                	slli	a5,a5,0x6
    800027a4:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800027a6:	00099783          	lh	a5,0(s3)
    800027aa:	cb9d                	beqz	a5,800027e0 <ialloc+0x88>
    brelse(bp);
    800027ac:	b23ff0ef          	jal	800022ce <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800027b0:	0905                	addi	s2,s2,1
    800027b2:	00ca2703          	lw	a4,12(s4)
    800027b6:	0009079b          	sext.w	a5,s2
    800027ba:	fce7e7e3          	bltu	a5,a4,80002788 <ialloc+0x30>
    800027be:	74a2                	ld	s1,40(sp)
    800027c0:	7902                	ld	s2,32(sp)
    800027c2:	69e2                	ld	s3,24(sp)
    800027c4:	6a42                	ld	s4,16(sp)
    800027c6:	6aa2                	ld	s5,8(sp)
    800027c8:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800027ca:	00005517          	auipc	a0,0x5
    800027ce:	c9650513          	addi	a0,a0,-874 # 80007460 <etext+0x460>
    800027d2:	6ed020ef          	jal	800056be <printf>
  return 0;
    800027d6:	4501                	li	a0,0
}
    800027d8:	70e2                	ld	ra,56(sp)
    800027da:	7442                	ld	s0,48(sp)
    800027dc:	6121                	addi	sp,sp,64
    800027de:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800027e0:	04000613          	li	a2,64
    800027e4:	4581                	li	a1,0
    800027e6:	854e                	mv	a0,s3
    800027e8:	977fd0ef          	jal	8000015e <memset>
      dip->type = type;
    800027ec:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800027f0:	8526                	mv	a0,s1
    800027f2:	329000ef          	jal	8000331a <log_write>
      brelse(bp);
    800027f6:	8526                	mv	a0,s1
    800027f8:	ad7ff0ef          	jal	800022ce <brelse>
      return iget(dev, inum);
    800027fc:	0009059b          	sext.w	a1,s2
    80002800:	8556                	mv	a0,s5
    80002802:	debff0ef          	jal	800025ec <iget>
    80002806:	74a2                	ld	s1,40(sp)
    80002808:	7902                	ld	s2,32(sp)
    8000280a:	69e2                	ld	s3,24(sp)
    8000280c:	6a42                	ld	s4,16(sp)
    8000280e:	6aa2                	ld	s5,8(sp)
    80002810:	6b02                	ld	s6,0(sp)
    80002812:	b7d9                	j	800027d8 <ialloc+0x80>

0000000080002814 <iupdate>:
{
    80002814:	1101                	addi	sp,sp,-32
    80002816:	ec06                	sd	ra,24(sp)
    80002818:	e822                	sd	s0,16(sp)
    8000281a:	e426                	sd	s1,8(sp)
    8000281c:	e04a                	sd	s2,0(sp)
    8000281e:	1000                	addi	s0,sp,32
    80002820:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002822:	415c                	lw	a5,4(a0)
    80002824:	0047d79b          	srliw	a5,a5,0x4
    80002828:	0001f597          	auipc	a1,0x1f
    8000282c:	6185a583          	lw	a1,1560(a1) # 80021e40 <sb+0x18>
    80002830:	9dbd                	addw	a1,a1,a5
    80002832:	4108                	lw	a0,0(a0)
    80002834:	993ff0ef          	jal	800021c6 <bread>
    80002838:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000283a:	05850793          	addi	a5,a0,88
    8000283e:	40d8                	lw	a4,4(s1)
    80002840:	8b3d                	andi	a4,a4,15
    80002842:	071a                	slli	a4,a4,0x6
    80002844:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80002846:	04449703          	lh	a4,68(s1)
    8000284a:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000284e:	04649703          	lh	a4,70(s1)
    80002852:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80002856:	04849703          	lh	a4,72(s1)
    8000285a:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000285e:	04a49703          	lh	a4,74(s1)
    80002862:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80002866:	44f8                	lw	a4,76(s1)
    80002868:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000286a:	03400613          	li	a2,52
    8000286e:	05048593          	addi	a1,s1,80
    80002872:	00c78513          	addi	a0,a5,12
    80002876:	949fd0ef          	jal	800001be <memmove>
  log_write(bp);
    8000287a:	854a                	mv	a0,s2
    8000287c:	29f000ef          	jal	8000331a <log_write>
  brelse(bp);
    80002880:	854a                	mv	a0,s2
    80002882:	a4dff0ef          	jal	800022ce <brelse>
}
    80002886:	60e2                	ld	ra,24(sp)
    80002888:	6442                	ld	s0,16(sp)
    8000288a:	64a2                	ld	s1,8(sp)
    8000288c:	6902                	ld	s2,0(sp)
    8000288e:	6105                	addi	sp,sp,32
    80002890:	8082                	ret

0000000080002892 <idup>:
{
    80002892:	1101                	addi	sp,sp,-32
    80002894:	ec06                	sd	ra,24(sp)
    80002896:	e822                	sd	s0,16(sp)
    80002898:	e426                	sd	s1,8(sp)
    8000289a:	1000                	addi	s0,sp,32
    8000289c:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000289e:	0001f517          	auipc	a0,0x1f
    800028a2:	5aa50513          	addi	a0,a0,1450 # 80021e48 <itable>
    800028a6:	466030ef          	jal	80005d0c <acquire>
  ip->ref++;
    800028aa:	449c                	lw	a5,8(s1)
    800028ac:	2785                	addiw	a5,a5,1
    800028ae:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800028b0:	0001f517          	auipc	a0,0x1f
    800028b4:	59850513          	addi	a0,a0,1432 # 80021e48 <itable>
    800028b8:	4e8030ef          	jal	80005da0 <release>
}
    800028bc:	8526                	mv	a0,s1
    800028be:	60e2                	ld	ra,24(sp)
    800028c0:	6442                	ld	s0,16(sp)
    800028c2:	64a2                	ld	s1,8(sp)
    800028c4:	6105                	addi	sp,sp,32
    800028c6:	8082                	ret

00000000800028c8 <ilock>:
{
    800028c8:	1101                	addi	sp,sp,-32
    800028ca:	ec06                	sd	ra,24(sp)
    800028cc:	e822                	sd	s0,16(sp)
    800028ce:	e426                	sd	s1,8(sp)
    800028d0:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800028d2:	cd19                	beqz	a0,800028f0 <ilock+0x28>
    800028d4:	84aa                	mv	s1,a0
    800028d6:	451c                	lw	a5,8(a0)
    800028d8:	00f05c63          	blez	a5,800028f0 <ilock+0x28>
  acquiresleep(&ip->lock);
    800028dc:	0541                	addi	a0,a0,16
    800028de:	345000ef          	jal	80003422 <acquiresleep>
  if(ip->valid == 0){
    800028e2:	40bc                	lw	a5,64(s1)
    800028e4:	cf89                	beqz	a5,800028fe <ilock+0x36>
}
    800028e6:	60e2                	ld	ra,24(sp)
    800028e8:	6442                	ld	s0,16(sp)
    800028ea:	64a2                	ld	s1,8(sp)
    800028ec:	6105                	addi	sp,sp,32
    800028ee:	8082                	ret
    800028f0:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800028f2:	00005517          	auipc	a0,0x5
    800028f6:	b8650513          	addi	a0,a0,-1146 # 80007478 <etext+0x478>
    800028fa:	0d4030ef          	jal	800059ce <panic>
    800028fe:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002900:	40dc                	lw	a5,4(s1)
    80002902:	0047d79b          	srliw	a5,a5,0x4
    80002906:	0001f597          	auipc	a1,0x1f
    8000290a:	53a5a583          	lw	a1,1338(a1) # 80021e40 <sb+0x18>
    8000290e:	9dbd                	addw	a1,a1,a5
    80002910:	4088                	lw	a0,0(s1)
    80002912:	8b5ff0ef          	jal	800021c6 <bread>
    80002916:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80002918:	05850593          	addi	a1,a0,88
    8000291c:	40dc                	lw	a5,4(s1)
    8000291e:	8bbd                	andi	a5,a5,15
    80002920:	079a                	slli	a5,a5,0x6
    80002922:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80002924:	00059783          	lh	a5,0(a1)
    80002928:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000292c:	00259783          	lh	a5,2(a1)
    80002930:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80002934:	00459783          	lh	a5,4(a1)
    80002938:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000293c:	00659783          	lh	a5,6(a1)
    80002940:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80002944:	459c                	lw	a5,8(a1)
    80002946:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80002948:	03400613          	li	a2,52
    8000294c:	05b1                	addi	a1,a1,12
    8000294e:	05048513          	addi	a0,s1,80
    80002952:	86dfd0ef          	jal	800001be <memmove>
    brelse(bp);
    80002956:	854a                	mv	a0,s2
    80002958:	977ff0ef          	jal	800022ce <brelse>
    ip->valid = 1;
    8000295c:	4785                	li	a5,1
    8000295e:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80002960:	04449783          	lh	a5,68(s1)
    80002964:	c399                	beqz	a5,8000296a <ilock+0xa2>
    80002966:	6902                	ld	s2,0(sp)
    80002968:	bfbd                	j	800028e6 <ilock+0x1e>
      panic("ilock: no type");
    8000296a:	00005517          	auipc	a0,0x5
    8000296e:	b1650513          	addi	a0,a0,-1258 # 80007480 <etext+0x480>
    80002972:	05c030ef          	jal	800059ce <panic>

0000000080002976 <iunlock>:
{
    80002976:	1101                	addi	sp,sp,-32
    80002978:	ec06                	sd	ra,24(sp)
    8000297a:	e822                	sd	s0,16(sp)
    8000297c:	e426                	sd	s1,8(sp)
    8000297e:	e04a                	sd	s2,0(sp)
    80002980:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80002982:	c505                	beqz	a0,800029aa <iunlock+0x34>
    80002984:	84aa                	mv	s1,a0
    80002986:	01050913          	addi	s2,a0,16
    8000298a:	854a                	mv	a0,s2
    8000298c:	315000ef          	jal	800034a0 <holdingsleep>
    80002990:	cd09                	beqz	a0,800029aa <iunlock+0x34>
    80002992:	449c                	lw	a5,8(s1)
    80002994:	00f05b63          	blez	a5,800029aa <iunlock+0x34>
  releasesleep(&ip->lock);
    80002998:	854a                	mv	a0,s2
    8000299a:	2cf000ef          	jal	80003468 <releasesleep>
}
    8000299e:	60e2                	ld	ra,24(sp)
    800029a0:	6442                	ld	s0,16(sp)
    800029a2:	64a2                	ld	s1,8(sp)
    800029a4:	6902                	ld	s2,0(sp)
    800029a6:	6105                	addi	sp,sp,32
    800029a8:	8082                	ret
    panic("iunlock");
    800029aa:	00005517          	auipc	a0,0x5
    800029ae:	ae650513          	addi	a0,a0,-1306 # 80007490 <etext+0x490>
    800029b2:	01c030ef          	jal	800059ce <panic>

00000000800029b6 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800029b6:	7179                	addi	sp,sp,-48
    800029b8:	f406                	sd	ra,40(sp)
    800029ba:	f022                	sd	s0,32(sp)
    800029bc:	ec26                	sd	s1,24(sp)
    800029be:	e84a                	sd	s2,16(sp)
    800029c0:	e44e                	sd	s3,8(sp)
    800029c2:	1800                	addi	s0,sp,48
    800029c4:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800029c6:	05050493          	addi	s1,a0,80
    800029ca:	08050913          	addi	s2,a0,128
    800029ce:	a021                	j	800029d6 <itrunc+0x20>
    800029d0:	0491                	addi	s1,s1,4
    800029d2:	01248b63          	beq	s1,s2,800029e8 <itrunc+0x32>
    if(ip->addrs[i]){
    800029d6:	408c                	lw	a1,0(s1)
    800029d8:	dde5                	beqz	a1,800029d0 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800029da:	0009a503          	lw	a0,0(s3)
    800029de:	9ddff0ef          	jal	800023ba <bfree>
      ip->addrs[i] = 0;
    800029e2:	0004a023          	sw	zero,0(s1)
    800029e6:	b7ed                	j	800029d0 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800029e8:	0809a583          	lw	a1,128(s3)
    800029ec:	ed89                	bnez	a1,80002a06 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800029ee:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800029f2:	854e                	mv	a0,s3
    800029f4:	e21ff0ef          	jal	80002814 <iupdate>
}
    800029f8:	70a2                	ld	ra,40(sp)
    800029fa:	7402                	ld	s0,32(sp)
    800029fc:	64e2                	ld	s1,24(sp)
    800029fe:	6942                	ld	s2,16(sp)
    80002a00:	69a2                	ld	s3,8(sp)
    80002a02:	6145                	addi	sp,sp,48
    80002a04:	8082                	ret
    80002a06:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80002a08:	0009a503          	lw	a0,0(s3)
    80002a0c:	fbaff0ef          	jal	800021c6 <bread>
    80002a10:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80002a12:	05850493          	addi	s1,a0,88
    80002a16:	45850913          	addi	s2,a0,1112
    80002a1a:	a021                	j	80002a22 <itrunc+0x6c>
    80002a1c:	0491                	addi	s1,s1,4
    80002a1e:	01248963          	beq	s1,s2,80002a30 <itrunc+0x7a>
      if(a[j])
    80002a22:	408c                	lw	a1,0(s1)
    80002a24:	dde5                	beqz	a1,80002a1c <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80002a26:	0009a503          	lw	a0,0(s3)
    80002a2a:	991ff0ef          	jal	800023ba <bfree>
    80002a2e:	b7fd                	j	80002a1c <itrunc+0x66>
    brelse(bp);
    80002a30:	8552                	mv	a0,s4
    80002a32:	89dff0ef          	jal	800022ce <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80002a36:	0809a583          	lw	a1,128(s3)
    80002a3a:	0009a503          	lw	a0,0(s3)
    80002a3e:	97dff0ef          	jal	800023ba <bfree>
    ip->addrs[NDIRECT] = 0;
    80002a42:	0809a023          	sw	zero,128(s3)
    80002a46:	6a02                	ld	s4,0(sp)
    80002a48:	b75d                	j	800029ee <itrunc+0x38>

0000000080002a4a <iput>:
{
    80002a4a:	1101                	addi	sp,sp,-32
    80002a4c:	ec06                	sd	ra,24(sp)
    80002a4e:	e822                	sd	s0,16(sp)
    80002a50:	e426                	sd	s1,8(sp)
    80002a52:	1000                	addi	s0,sp,32
    80002a54:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002a56:	0001f517          	auipc	a0,0x1f
    80002a5a:	3f250513          	addi	a0,a0,1010 # 80021e48 <itable>
    80002a5e:	2ae030ef          	jal	80005d0c <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a62:	4498                	lw	a4,8(s1)
    80002a64:	4785                	li	a5,1
    80002a66:	02f70063          	beq	a4,a5,80002a86 <iput+0x3c>
  ip->ref--;
    80002a6a:	449c                	lw	a5,8(s1)
    80002a6c:	37fd                	addiw	a5,a5,-1
    80002a6e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002a70:	0001f517          	auipc	a0,0x1f
    80002a74:	3d850513          	addi	a0,a0,984 # 80021e48 <itable>
    80002a78:	328030ef          	jal	80005da0 <release>
}
    80002a7c:	60e2                	ld	ra,24(sp)
    80002a7e:	6442                	ld	s0,16(sp)
    80002a80:	64a2                	ld	s1,8(sp)
    80002a82:	6105                	addi	sp,sp,32
    80002a84:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a86:	40bc                	lw	a5,64(s1)
    80002a88:	d3ed                	beqz	a5,80002a6a <iput+0x20>
    80002a8a:	04a49783          	lh	a5,74(s1)
    80002a8e:	fff1                	bnez	a5,80002a6a <iput+0x20>
    80002a90:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80002a92:	01048793          	addi	a5,s1,16
    80002a96:	893e                	mv	s2,a5
    80002a98:	853e                	mv	a0,a5
    80002a9a:	189000ef          	jal	80003422 <acquiresleep>
    release(&itable.lock);
    80002a9e:	0001f517          	auipc	a0,0x1f
    80002aa2:	3aa50513          	addi	a0,a0,938 # 80021e48 <itable>
    80002aa6:	2fa030ef          	jal	80005da0 <release>
    itrunc(ip);
    80002aaa:	8526                	mv	a0,s1
    80002aac:	f0bff0ef          	jal	800029b6 <itrunc>
    ip->type = 0;
    80002ab0:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002ab4:	8526                	mv	a0,s1
    80002ab6:	d5fff0ef          	jal	80002814 <iupdate>
    ip->valid = 0;
    80002aba:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002abe:	854a                	mv	a0,s2
    80002ac0:	1a9000ef          	jal	80003468 <releasesleep>
    acquire(&itable.lock);
    80002ac4:	0001f517          	auipc	a0,0x1f
    80002ac8:	38450513          	addi	a0,a0,900 # 80021e48 <itable>
    80002acc:	240030ef          	jal	80005d0c <acquire>
    80002ad0:	6902                	ld	s2,0(sp)
    80002ad2:	bf61                	j	80002a6a <iput+0x20>

0000000080002ad4 <iunlockput>:
{
    80002ad4:	1101                	addi	sp,sp,-32
    80002ad6:	ec06                	sd	ra,24(sp)
    80002ad8:	e822                	sd	s0,16(sp)
    80002ada:	e426                	sd	s1,8(sp)
    80002adc:	1000                	addi	s0,sp,32
    80002ade:	84aa                	mv	s1,a0
  iunlock(ip);
    80002ae0:	e97ff0ef          	jal	80002976 <iunlock>
  iput(ip);
    80002ae4:	8526                	mv	a0,s1
    80002ae6:	f65ff0ef          	jal	80002a4a <iput>
}
    80002aea:	60e2                	ld	ra,24(sp)
    80002aec:	6442                	ld	s0,16(sp)
    80002aee:	64a2                	ld	s1,8(sp)
    80002af0:	6105                	addi	sp,sp,32
    80002af2:	8082                	ret

0000000080002af4 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002af4:	1141                	addi	sp,sp,-16
    80002af6:	e406                	sd	ra,8(sp)
    80002af8:	e022                	sd	s0,0(sp)
    80002afa:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80002afc:	411c                	lw	a5,0(a0)
    80002afe:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002b00:	415c                	lw	a5,4(a0)
    80002b02:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002b04:	04451783          	lh	a5,68(a0)
    80002b08:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80002b0c:	04a51783          	lh	a5,74(a0)
    80002b10:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002b14:	04c56783          	lwu	a5,76(a0)
    80002b18:	e99c                	sd	a5,16(a1)
}
    80002b1a:	60a2                	ld	ra,8(sp)
    80002b1c:	6402                	ld	s0,0(sp)
    80002b1e:	0141                	addi	sp,sp,16
    80002b20:	8082                	ret

0000000080002b22 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002b22:	457c                	lw	a5,76(a0)
    80002b24:	0ed7e663          	bltu	a5,a3,80002c10 <readi+0xee>
{
    80002b28:	7159                	addi	sp,sp,-112
    80002b2a:	f486                	sd	ra,104(sp)
    80002b2c:	f0a2                	sd	s0,96(sp)
    80002b2e:	eca6                	sd	s1,88(sp)
    80002b30:	e0d2                	sd	s4,64(sp)
    80002b32:	fc56                	sd	s5,56(sp)
    80002b34:	f85a                	sd	s6,48(sp)
    80002b36:	f45e                	sd	s7,40(sp)
    80002b38:	1880                	addi	s0,sp,112
    80002b3a:	8b2a                	mv	s6,a0
    80002b3c:	8bae                	mv	s7,a1
    80002b3e:	8a32                	mv	s4,a2
    80002b40:	84b6                	mv	s1,a3
    80002b42:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80002b44:	9f35                	addw	a4,a4,a3
    return 0;
    80002b46:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002b48:	0ad76b63          	bltu	a4,a3,80002bfe <readi+0xdc>
    80002b4c:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80002b4e:	00e7f463          	bgeu	a5,a4,80002b56 <readi+0x34>
    n = ip->size - off;
    80002b52:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b56:	080a8b63          	beqz	s5,80002bec <readi+0xca>
    80002b5a:	e8ca                	sd	s2,80(sp)
    80002b5c:	f062                	sd	s8,32(sp)
    80002b5e:	ec66                	sd	s9,24(sp)
    80002b60:	e86a                	sd	s10,16(sp)
    80002b62:	e46e                	sd	s11,8(sp)
    80002b64:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b66:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002b6a:	5c7d                	li	s8,-1
    80002b6c:	a80d                	j	80002b9e <readi+0x7c>
    80002b6e:	020d1d93          	slli	s11,s10,0x20
    80002b72:	020ddd93          	srli	s11,s11,0x20
    80002b76:	05890613          	addi	a2,s2,88
    80002b7a:	86ee                	mv	a3,s11
    80002b7c:	963e                	add	a2,a2,a5
    80002b7e:	85d2                	mv	a1,s4
    80002b80:	855e                	mv	a0,s7
    80002b82:	c93fe0ef          	jal	80001814 <either_copyout>
    80002b86:	05850363          	beq	a0,s8,80002bcc <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002b8a:	854a                	mv	a0,s2
    80002b8c:	f42ff0ef          	jal	800022ce <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b90:	013d09bb          	addw	s3,s10,s3
    80002b94:	009d04bb          	addw	s1,s10,s1
    80002b98:	9a6e                	add	s4,s4,s11
    80002b9a:	0559f363          	bgeu	s3,s5,80002be0 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002b9e:	00a4d59b          	srliw	a1,s1,0xa
    80002ba2:	855a                	mv	a0,s6
    80002ba4:	989ff0ef          	jal	8000252c <bmap>
    80002ba8:	85aa                	mv	a1,a0
    if(addr == 0)
    80002baa:	c139                	beqz	a0,80002bf0 <readi+0xce>
    bp = bread(ip->dev, addr);
    80002bac:	000b2503          	lw	a0,0(s6)
    80002bb0:	e16ff0ef          	jal	800021c6 <bread>
    80002bb4:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002bb6:	3ff4f793          	andi	a5,s1,1023
    80002bba:	40fc873b          	subw	a4,s9,a5
    80002bbe:	413a86bb          	subw	a3,s5,s3
    80002bc2:	8d3a                	mv	s10,a4
    80002bc4:	fae6f5e3          	bgeu	a3,a4,80002b6e <readi+0x4c>
    80002bc8:	8d36                	mv	s10,a3
    80002bca:	b755                	j	80002b6e <readi+0x4c>
      brelse(bp);
    80002bcc:	854a                	mv	a0,s2
    80002bce:	f00ff0ef          	jal	800022ce <brelse>
      tot = -1;
    80002bd2:	59fd                	li	s3,-1
      break;
    80002bd4:	6946                	ld	s2,80(sp)
    80002bd6:	7c02                	ld	s8,32(sp)
    80002bd8:	6ce2                	ld	s9,24(sp)
    80002bda:	6d42                	ld	s10,16(sp)
    80002bdc:	6da2                	ld	s11,8(sp)
    80002bde:	a831                	j	80002bfa <readi+0xd8>
    80002be0:	6946                	ld	s2,80(sp)
    80002be2:	7c02                	ld	s8,32(sp)
    80002be4:	6ce2                	ld	s9,24(sp)
    80002be6:	6d42                	ld	s10,16(sp)
    80002be8:	6da2                	ld	s11,8(sp)
    80002bea:	a801                	j	80002bfa <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002bec:	89d6                	mv	s3,s5
    80002bee:	a031                	j	80002bfa <readi+0xd8>
    80002bf0:	6946                	ld	s2,80(sp)
    80002bf2:	7c02                	ld	s8,32(sp)
    80002bf4:	6ce2                	ld	s9,24(sp)
    80002bf6:	6d42                	ld	s10,16(sp)
    80002bf8:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80002bfa:	854e                	mv	a0,s3
    80002bfc:	69a6                	ld	s3,72(sp)
}
    80002bfe:	70a6                	ld	ra,104(sp)
    80002c00:	7406                	ld	s0,96(sp)
    80002c02:	64e6                	ld	s1,88(sp)
    80002c04:	6a06                	ld	s4,64(sp)
    80002c06:	7ae2                	ld	s5,56(sp)
    80002c08:	7b42                	ld	s6,48(sp)
    80002c0a:	7ba2                	ld	s7,40(sp)
    80002c0c:	6165                	addi	sp,sp,112
    80002c0e:	8082                	ret
    return 0;
    80002c10:	4501                	li	a0,0
}
    80002c12:	8082                	ret

0000000080002c14 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002c14:	457c                	lw	a5,76(a0)
    80002c16:	0ed7eb63          	bltu	a5,a3,80002d0c <writei+0xf8>
{
    80002c1a:	7159                	addi	sp,sp,-112
    80002c1c:	f486                	sd	ra,104(sp)
    80002c1e:	f0a2                	sd	s0,96(sp)
    80002c20:	e8ca                	sd	s2,80(sp)
    80002c22:	e0d2                	sd	s4,64(sp)
    80002c24:	fc56                	sd	s5,56(sp)
    80002c26:	f85a                	sd	s6,48(sp)
    80002c28:	f45e                	sd	s7,40(sp)
    80002c2a:	1880                	addi	s0,sp,112
    80002c2c:	8aaa                	mv	s5,a0
    80002c2e:	8bae                	mv	s7,a1
    80002c30:	8a32                	mv	s4,a2
    80002c32:	8936                	mv	s2,a3
    80002c34:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80002c36:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80002c3a:	00043737          	lui	a4,0x43
    80002c3e:	0cf76963          	bltu	a4,a5,80002d10 <writei+0xfc>
    80002c42:	0cd7e763          	bltu	a5,a3,80002d10 <writei+0xfc>
    80002c46:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c48:	0a0b0a63          	beqz	s6,80002cfc <writei+0xe8>
    80002c4c:	eca6                	sd	s1,88(sp)
    80002c4e:	f062                	sd	s8,32(sp)
    80002c50:	ec66                	sd	s9,24(sp)
    80002c52:	e86a                	sd	s10,16(sp)
    80002c54:	e46e                	sd	s11,8(sp)
    80002c56:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002c58:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002c5c:	5c7d                	li	s8,-1
    80002c5e:	a825                	j	80002c96 <writei+0x82>
    80002c60:	020d1d93          	slli	s11,s10,0x20
    80002c64:	020ddd93          	srli	s11,s11,0x20
    80002c68:	05848513          	addi	a0,s1,88
    80002c6c:	86ee                	mv	a3,s11
    80002c6e:	8652                	mv	a2,s4
    80002c70:	85de                	mv	a1,s7
    80002c72:	953e                	add	a0,a0,a5
    80002c74:	bebfe0ef          	jal	8000185e <either_copyin>
    80002c78:	05850663          	beq	a0,s8,80002cc4 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002c7c:	8526                	mv	a0,s1
    80002c7e:	69c000ef          	jal	8000331a <log_write>
    brelse(bp);
    80002c82:	8526                	mv	a0,s1
    80002c84:	e4aff0ef          	jal	800022ce <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c88:	013d09bb          	addw	s3,s10,s3
    80002c8c:	012d093b          	addw	s2,s10,s2
    80002c90:	9a6e                	add	s4,s4,s11
    80002c92:	0369fc63          	bgeu	s3,s6,80002cca <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80002c96:	00a9559b          	srliw	a1,s2,0xa
    80002c9a:	8556                	mv	a0,s5
    80002c9c:	891ff0ef          	jal	8000252c <bmap>
    80002ca0:	85aa                	mv	a1,a0
    if(addr == 0)
    80002ca2:	c505                	beqz	a0,80002cca <writei+0xb6>
    bp = bread(ip->dev, addr);
    80002ca4:	000aa503          	lw	a0,0(s5)
    80002ca8:	d1eff0ef          	jal	800021c6 <bread>
    80002cac:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002cae:	3ff97793          	andi	a5,s2,1023
    80002cb2:	40fc873b          	subw	a4,s9,a5
    80002cb6:	413b06bb          	subw	a3,s6,s3
    80002cba:	8d3a                	mv	s10,a4
    80002cbc:	fae6f2e3          	bgeu	a3,a4,80002c60 <writei+0x4c>
    80002cc0:	8d36                	mv	s10,a3
    80002cc2:	bf79                	j	80002c60 <writei+0x4c>
      brelse(bp);
    80002cc4:	8526                	mv	a0,s1
    80002cc6:	e08ff0ef          	jal	800022ce <brelse>
  }

  if(off > ip->size)
    80002cca:	04caa783          	lw	a5,76(s5)
    80002cce:	0327f963          	bgeu	a5,s2,80002d00 <writei+0xec>
    ip->size = off;
    80002cd2:	052aa623          	sw	s2,76(s5)
    80002cd6:	64e6                	ld	s1,88(sp)
    80002cd8:	7c02                	ld	s8,32(sp)
    80002cda:	6ce2                	ld	s9,24(sp)
    80002cdc:	6d42                	ld	s10,16(sp)
    80002cde:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002ce0:	8556                	mv	a0,s5
    80002ce2:	b33ff0ef          	jal	80002814 <iupdate>

  return tot;
    80002ce6:	854e                	mv	a0,s3
    80002ce8:	69a6                	ld	s3,72(sp)
}
    80002cea:	70a6                	ld	ra,104(sp)
    80002cec:	7406                	ld	s0,96(sp)
    80002cee:	6946                	ld	s2,80(sp)
    80002cf0:	6a06                	ld	s4,64(sp)
    80002cf2:	7ae2                	ld	s5,56(sp)
    80002cf4:	7b42                	ld	s6,48(sp)
    80002cf6:	7ba2                	ld	s7,40(sp)
    80002cf8:	6165                	addi	sp,sp,112
    80002cfa:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002cfc:	89da                	mv	s3,s6
    80002cfe:	b7cd                	j	80002ce0 <writei+0xcc>
    80002d00:	64e6                	ld	s1,88(sp)
    80002d02:	7c02                	ld	s8,32(sp)
    80002d04:	6ce2                	ld	s9,24(sp)
    80002d06:	6d42                	ld	s10,16(sp)
    80002d08:	6da2                	ld	s11,8(sp)
    80002d0a:	bfd9                	j	80002ce0 <writei+0xcc>
    return -1;
    80002d0c:	557d                	li	a0,-1
}
    80002d0e:	8082                	ret
    return -1;
    80002d10:	557d                	li	a0,-1
    80002d12:	bfe1                	j	80002cea <writei+0xd6>

0000000080002d14 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002d14:	1141                	addi	sp,sp,-16
    80002d16:	e406                	sd	ra,8(sp)
    80002d18:	e022                	sd	s0,0(sp)
    80002d1a:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002d1c:	4639                	li	a2,14
    80002d1e:	d14fd0ef          	jal	80000232 <strncmp>
}
    80002d22:	60a2                	ld	ra,8(sp)
    80002d24:	6402                	ld	s0,0(sp)
    80002d26:	0141                	addi	sp,sp,16
    80002d28:	8082                	ret

0000000080002d2a <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002d2a:	711d                	addi	sp,sp,-96
    80002d2c:	ec86                	sd	ra,88(sp)
    80002d2e:	e8a2                	sd	s0,80(sp)
    80002d30:	e4a6                	sd	s1,72(sp)
    80002d32:	e0ca                	sd	s2,64(sp)
    80002d34:	fc4e                	sd	s3,56(sp)
    80002d36:	f852                	sd	s4,48(sp)
    80002d38:	f456                	sd	s5,40(sp)
    80002d3a:	f05a                	sd	s6,32(sp)
    80002d3c:	ec5e                	sd	s7,24(sp)
    80002d3e:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002d40:	04451703          	lh	a4,68(a0)
    80002d44:	4785                	li	a5,1
    80002d46:	00f71f63          	bne	a4,a5,80002d64 <dirlookup+0x3a>
    80002d4a:	892a                	mv	s2,a0
    80002d4c:	8aae                	mv	s5,a1
    80002d4e:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d50:	457c                	lw	a5,76(a0)
    80002d52:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d54:	fa040a13          	addi	s4,s0,-96
    80002d58:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80002d5a:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002d5e:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d60:	e39d                	bnez	a5,80002d86 <dirlookup+0x5c>
    80002d62:	a8b9                	j	80002dc0 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80002d64:	00004517          	auipc	a0,0x4
    80002d68:	73450513          	addi	a0,a0,1844 # 80007498 <etext+0x498>
    80002d6c:	463020ef          	jal	800059ce <panic>
      panic("dirlookup read");
    80002d70:	00004517          	auipc	a0,0x4
    80002d74:	74050513          	addi	a0,a0,1856 # 800074b0 <etext+0x4b0>
    80002d78:	457020ef          	jal	800059ce <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d7c:	24c1                	addiw	s1,s1,16
    80002d7e:	04c92783          	lw	a5,76(s2)
    80002d82:	02f4fe63          	bgeu	s1,a5,80002dbe <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d86:	874e                	mv	a4,s3
    80002d88:	86a6                	mv	a3,s1
    80002d8a:	8652                	mv	a2,s4
    80002d8c:	4581                	li	a1,0
    80002d8e:	854a                	mv	a0,s2
    80002d90:	d93ff0ef          	jal	80002b22 <readi>
    80002d94:	fd351ee3          	bne	a0,s3,80002d70 <dirlookup+0x46>
    if(de.inum == 0)
    80002d98:	fa045783          	lhu	a5,-96(s0)
    80002d9c:	d3e5                	beqz	a5,80002d7c <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80002d9e:	85da                	mv	a1,s6
    80002da0:	8556                	mv	a0,s5
    80002da2:	f73ff0ef          	jal	80002d14 <namecmp>
    80002da6:	f979                	bnez	a0,80002d7c <dirlookup+0x52>
      if(poff)
    80002da8:	000b8463          	beqz	s7,80002db0 <dirlookup+0x86>
        *poff = off;
    80002dac:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80002db0:	fa045583          	lhu	a1,-96(s0)
    80002db4:	00092503          	lw	a0,0(s2)
    80002db8:	835ff0ef          	jal	800025ec <iget>
    80002dbc:	a011                	j	80002dc0 <dirlookup+0x96>
  return 0;
    80002dbe:	4501                	li	a0,0
}
    80002dc0:	60e6                	ld	ra,88(sp)
    80002dc2:	6446                	ld	s0,80(sp)
    80002dc4:	64a6                	ld	s1,72(sp)
    80002dc6:	6906                	ld	s2,64(sp)
    80002dc8:	79e2                	ld	s3,56(sp)
    80002dca:	7a42                	ld	s4,48(sp)
    80002dcc:	7aa2                	ld	s5,40(sp)
    80002dce:	7b02                	ld	s6,32(sp)
    80002dd0:	6be2                	ld	s7,24(sp)
    80002dd2:	6125                	addi	sp,sp,96
    80002dd4:	8082                	ret

0000000080002dd6 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002dd6:	711d                	addi	sp,sp,-96
    80002dd8:	ec86                	sd	ra,88(sp)
    80002dda:	e8a2                	sd	s0,80(sp)
    80002ddc:	e4a6                	sd	s1,72(sp)
    80002dde:	e0ca                	sd	s2,64(sp)
    80002de0:	fc4e                	sd	s3,56(sp)
    80002de2:	f852                	sd	s4,48(sp)
    80002de4:	f456                	sd	s5,40(sp)
    80002de6:	f05a                	sd	s6,32(sp)
    80002de8:	ec5e                	sd	s7,24(sp)
    80002dea:	e862                	sd	s8,16(sp)
    80002dec:	e466                	sd	s9,8(sp)
    80002dee:	e06a                	sd	s10,0(sp)
    80002df0:	1080                	addi	s0,sp,96
    80002df2:	84aa                	mv	s1,a0
    80002df4:	8b2e                	mv	s6,a1
    80002df6:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002df8:	00054703          	lbu	a4,0(a0)
    80002dfc:	02f00793          	li	a5,47
    80002e00:	00f70f63          	beq	a4,a5,80002e1e <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002e04:	f61fd0ef          	jal	80000d64 <myproc>
    80002e08:	15053503          	ld	a0,336(a0)
    80002e0c:	a87ff0ef          	jal	80002892 <idup>
    80002e10:	8a2a                	mv	s4,a0
  while(*path == '/')
    80002e12:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80002e16:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80002e18:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002e1a:	4b85                	li	s7,1
    80002e1c:	a879                	j	80002eba <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80002e1e:	4585                	li	a1,1
    80002e20:	852e                	mv	a0,a1
    80002e22:	fcaff0ef          	jal	800025ec <iget>
    80002e26:	8a2a                	mv	s4,a0
    80002e28:	b7ed                	j	80002e12 <namex+0x3c>
      iunlockput(ip);
    80002e2a:	8552                	mv	a0,s4
    80002e2c:	ca9ff0ef          	jal	80002ad4 <iunlockput>
      return 0;
    80002e30:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002e32:	8552                	mv	a0,s4
    80002e34:	60e6                	ld	ra,88(sp)
    80002e36:	6446                	ld	s0,80(sp)
    80002e38:	64a6                	ld	s1,72(sp)
    80002e3a:	6906                	ld	s2,64(sp)
    80002e3c:	79e2                	ld	s3,56(sp)
    80002e3e:	7a42                	ld	s4,48(sp)
    80002e40:	7aa2                	ld	s5,40(sp)
    80002e42:	7b02                	ld	s6,32(sp)
    80002e44:	6be2                	ld	s7,24(sp)
    80002e46:	6c42                	ld	s8,16(sp)
    80002e48:	6ca2                	ld	s9,8(sp)
    80002e4a:	6d02                	ld	s10,0(sp)
    80002e4c:	6125                	addi	sp,sp,96
    80002e4e:	8082                	ret
      iunlock(ip);
    80002e50:	8552                	mv	a0,s4
    80002e52:	b25ff0ef          	jal	80002976 <iunlock>
      return ip;
    80002e56:	bff1                	j	80002e32 <namex+0x5c>
      iunlockput(ip);
    80002e58:	8552                	mv	a0,s4
    80002e5a:	c7bff0ef          	jal	80002ad4 <iunlockput>
      return 0;
    80002e5e:	8a4a                	mv	s4,s2
    80002e60:	bfc9                	j	80002e32 <namex+0x5c>
  len = path - s;
    80002e62:	40990633          	sub	a2,s2,s1
    80002e66:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80002e6a:	09ac5463          	bge	s8,s10,80002ef2 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80002e6e:	8666                	mv	a2,s9
    80002e70:	85a6                	mv	a1,s1
    80002e72:	8556                	mv	a0,s5
    80002e74:	b4afd0ef          	jal	800001be <memmove>
    80002e78:	84ca                	mv	s1,s2
  while(*path == '/')
    80002e7a:	0004c783          	lbu	a5,0(s1)
    80002e7e:	01379763          	bne	a5,s3,80002e8c <namex+0xb6>
    path++;
    80002e82:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e84:	0004c783          	lbu	a5,0(s1)
    80002e88:	ff378de3          	beq	a5,s3,80002e82 <namex+0xac>
    ilock(ip);
    80002e8c:	8552                	mv	a0,s4
    80002e8e:	a3bff0ef          	jal	800028c8 <ilock>
    if(ip->type != T_DIR){
    80002e92:	044a1783          	lh	a5,68(s4)
    80002e96:	f9779ae3          	bne	a5,s7,80002e2a <namex+0x54>
    if(nameiparent && *path == '\0'){
    80002e9a:	000b0563          	beqz	s6,80002ea4 <namex+0xce>
    80002e9e:	0004c783          	lbu	a5,0(s1)
    80002ea2:	d7dd                	beqz	a5,80002e50 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002ea4:	4601                	li	a2,0
    80002ea6:	85d6                	mv	a1,s5
    80002ea8:	8552                	mv	a0,s4
    80002eaa:	e81ff0ef          	jal	80002d2a <dirlookup>
    80002eae:	892a                	mv	s2,a0
    80002eb0:	d545                	beqz	a0,80002e58 <namex+0x82>
    iunlockput(ip);
    80002eb2:	8552                	mv	a0,s4
    80002eb4:	c21ff0ef          	jal	80002ad4 <iunlockput>
    ip = next;
    80002eb8:	8a4a                	mv	s4,s2
  while(*path == '/')
    80002eba:	0004c783          	lbu	a5,0(s1)
    80002ebe:	01379763          	bne	a5,s3,80002ecc <namex+0xf6>
    path++;
    80002ec2:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002ec4:	0004c783          	lbu	a5,0(s1)
    80002ec8:	ff378de3          	beq	a5,s3,80002ec2 <namex+0xec>
  if(*path == 0)
    80002ecc:	cf8d                	beqz	a5,80002f06 <namex+0x130>
  while(*path != '/' && *path != 0)
    80002ece:	0004c783          	lbu	a5,0(s1)
    80002ed2:	fd178713          	addi	a4,a5,-47
    80002ed6:	cb19                	beqz	a4,80002eec <namex+0x116>
    80002ed8:	cb91                	beqz	a5,80002eec <namex+0x116>
    80002eda:	8926                	mv	s2,s1
    path++;
    80002edc:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80002ede:	00094783          	lbu	a5,0(s2)
    80002ee2:	fd178713          	addi	a4,a5,-47
    80002ee6:	df35                	beqz	a4,80002e62 <namex+0x8c>
    80002ee8:	fbf5                	bnez	a5,80002edc <namex+0x106>
    80002eea:	bfa5                	j	80002e62 <namex+0x8c>
    80002eec:	8926                	mv	s2,s1
  len = path - s;
    80002eee:	4d01                	li	s10,0
    80002ef0:	4601                	li	a2,0
    memmove(name, s, len);
    80002ef2:	2601                	sext.w	a2,a2
    80002ef4:	85a6                	mv	a1,s1
    80002ef6:	8556                	mv	a0,s5
    80002ef8:	ac6fd0ef          	jal	800001be <memmove>
    name[len] = 0;
    80002efc:	9d56                	add	s10,s10,s5
    80002efe:	000d0023          	sb	zero,0(s10)
    80002f02:	84ca                	mv	s1,s2
    80002f04:	bf9d                	j	80002e7a <namex+0xa4>
  if(nameiparent){
    80002f06:	f20b06e3          	beqz	s6,80002e32 <namex+0x5c>
    iput(ip);
    80002f0a:	8552                	mv	a0,s4
    80002f0c:	b3fff0ef          	jal	80002a4a <iput>
    return 0;
    80002f10:	4a01                	li	s4,0
    80002f12:	b705                	j	80002e32 <namex+0x5c>

0000000080002f14 <dirlink>:
{
    80002f14:	715d                	addi	sp,sp,-80
    80002f16:	e486                	sd	ra,72(sp)
    80002f18:	e0a2                	sd	s0,64(sp)
    80002f1a:	f84a                	sd	s2,48(sp)
    80002f1c:	ec56                	sd	s5,24(sp)
    80002f1e:	e85a                	sd	s6,16(sp)
    80002f20:	0880                	addi	s0,sp,80
    80002f22:	892a                	mv	s2,a0
    80002f24:	8aae                	mv	s5,a1
    80002f26:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002f28:	4601                	li	a2,0
    80002f2a:	e01ff0ef          	jal	80002d2a <dirlookup>
    80002f2e:	ed1d                	bnez	a0,80002f6c <dirlink+0x58>
    80002f30:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002f32:	04c92483          	lw	s1,76(s2)
    80002f36:	c4b9                	beqz	s1,80002f84 <dirlink+0x70>
    80002f38:	f44e                	sd	s3,40(sp)
    80002f3a:	f052                	sd	s4,32(sp)
    80002f3c:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002f3e:	fb040a13          	addi	s4,s0,-80
    80002f42:	49c1                	li	s3,16
    80002f44:	874e                	mv	a4,s3
    80002f46:	86a6                	mv	a3,s1
    80002f48:	8652                	mv	a2,s4
    80002f4a:	4581                	li	a1,0
    80002f4c:	854a                	mv	a0,s2
    80002f4e:	bd5ff0ef          	jal	80002b22 <readi>
    80002f52:	03351163          	bne	a0,s3,80002f74 <dirlink+0x60>
    if(de.inum == 0)
    80002f56:	fb045783          	lhu	a5,-80(s0)
    80002f5a:	c39d                	beqz	a5,80002f80 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002f5c:	24c1                	addiw	s1,s1,16
    80002f5e:	04c92783          	lw	a5,76(s2)
    80002f62:	fef4e1e3          	bltu	s1,a5,80002f44 <dirlink+0x30>
    80002f66:	79a2                	ld	s3,40(sp)
    80002f68:	7a02                	ld	s4,32(sp)
    80002f6a:	a829                	j	80002f84 <dirlink+0x70>
    iput(ip);
    80002f6c:	adfff0ef          	jal	80002a4a <iput>
    return -1;
    80002f70:	557d                	li	a0,-1
    80002f72:	a83d                	j	80002fb0 <dirlink+0x9c>
      panic("dirlink read");
    80002f74:	00004517          	auipc	a0,0x4
    80002f78:	54c50513          	addi	a0,a0,1356 # 800074c0 <etext+0x4c0>
    80002f7c:	253020ef          	jal	800059ce <panic>
    80002f80:	79a2                	ld	s3,40(sp)
    80002f82:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80002f84:	4639                	li	a2,14
    80002f86:	85d6                	mv	a1,s5
    80002f88:	fb240513          	addi	a0,s0,-78
    80002f8c:	ae0fd0ef          	jal	8000026c <strncpy>
  de.inum = inum;
    80002f90:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002f94:	4741                	li	a4,16
    80002f96:	86a6                	mv	a3,s1
    80002f98:	fb040613          	addi	a2,s0,-80
    80002f9c:	4581                	li	a1,0
    80002f9e:	854a                	mv	a0,s2
    80002fa0:	c75ff0ef          	jal	80002c14 <writei>
    80002fa4:	1541                	addi	a0,a0,-16
    80002fa6:	00a03533          	snez	a0,a0
    80002faa:	40a0053b          	negw	a0,a0
    80002fae:	74e2                	ld	s1,56(sp)
}
    80002fb0:	60a6                	ld	ra,72(sp)
    80002fb2:	6406                	ld	s0,64(sp)
    80002fb4:	7942                	ld	s2,48(sp)
    80002fb6:	6ae2                	ld	s5,24(sp)
    80002fb8:	6b42                	ld	s6,16(sp)
    80002fba:	6161                	addi	sp,sp,80
    80002fbc:	8082                	ret

0000000080002fbe <namei>:

struct inode*
namei(char *path)
{
    80002fbe:	1101                	addi	sp,sp,-32
    80002fc0:	ec06                	sd	ra,24(sp)
    80002fc2:	e822                	sd	s0,16(sp)
    80002fc4:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002fc6:	fe040613          	addi	a2,s0,-32
    80002fca:	4581                	li	a1,0
    80002fcc:	e0bff0ef          	jal	80002dd6 <namex>
}
    80002fd0:	60e2                	ld	ra,24(sp)
    80002fd2:	6442                	ld	s0,16(sp)
    80002fd4:	6105                	addi	sp,sp,32
    80002fd6:	8082                	ret

0000000080002fd8 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002fd8:	1141                	addi	sp,sp,-16
    80002fda:	e406                	sd	ra,8(sp)
    80002fdc:	e022                	sd	s0,0(sp)
    80002fde:	0800                	addi	s0,sp,16
    80002fe0:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002fe2:	4585                	li	a1,1
    80002fe4:	df3ff0ef          	jal	80002dd6 <namex>
}
    80002fe8:	60a2                	ld	ra,8(sp)
    80002fea:	6402                	ld	s0,0(sp)
    80002fec:	0141                	addi	sp,sp,16
    80002fee:	8082                	ret

0000000080002ff0 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002ff0:	1101                	addi	sp,sp,-32
    80002ff2:	ec06                	sd	ra,24(sp)
    80002ff4:	e822                	sd	s0,16(sp)
    80002ff6:	e426                	sd	s1,8(sp)
    80002ff8:	e04a                	sd	s2,0(sp)
    80002ffa:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002ffc:	00021917          	auipc	s2,0x21
    80003000:	8f490913          	addi	s2,s2,-1804 # 800238f0 <log>
    80003004:	01892583          	lw	a1,24(s2)
    80003008:	02892503          	lw	a0,40(s2)
    8000300c:	9baff0ef          	jal	800021c6 <bread>
    80003010:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003012:	02c92603          	lw	a2,44(s2)
    80003016:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003018:	00c05f63          	blez	a2,80003036 <write_head+0x46>
    8000301c:	00021717          	auipc	a4,0x21
    80003020:	90470713          	addi	a4,a4,-1788 # 80023920 <log+0x30>
    80003024:	87aa                	mv	a5,a0
    80003026:	060a                	slli	a2,a2,0x2
    80003028:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    8000302a:	4314                	lw	a3,0(a4)
    8000302c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    8000302e:	0711                	addi	a4,a4,4
    80003030:	0791                	addi	a5,a5,4
    80003032:	fec79ce3          	bne	a5,a2,8000302a <write_head+0x3a>
  }
  bwrite(buf);
    80003036:	8526                	mv	a0,s1
    80003038:	a64ff0ef          	jal	8000229c <bwrite>
  brelse(buf);
    8000303c:	8526                	mv	a0,s1
    8000303e:	a90ff0ef          	jal	800022ce <brelse>
}
    80003042:	60e2                	ld	ra,24(sp)
    80003044:	6442                	ld	s0,16(sp)
    80003046:	64a2                	ld	s1,8(sp)
    80003048:	6902                	ld	s2,0(sp)
    8000304a:	6105                	addi	sp,sp,32
    8000304c:	8082                	ret

000000008000304e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    8000304e:	00021797          	auipc	a5,0x21
    80003052:	8ce7a783          	lw	a5,-1842(a5) # 8002391c <log+0x2c>
    80003056:	0af05263          	blez	a5,800030fa <install_trans+0xac>
{
    8000305a:	715d                	addi	sp,sp,-80
    8000305c:	e486                	sd	ra,72(sp)
    8000305e:	e0a2                	sd	s0,64(sp)
    80003060:	fc26                	sd	s1,56(sp)
    80003062:	f84a                	sd	s2,48(sp)
    80003064:	f44e                	sd	s3,40(sp)
    80003066:	f052                	sd	s4,32(sp)
    80003068:	ec56                	sd	s5,24(sp)
    8000306a:	e85a                	sd	s6,16(sp)
    8000306c:	e45e                	sd	s7,8(sp)
    8000306e:	0880                	addi	s0,sp,80
    80003070:	8b2a                	mv	s6,a0
    80003072:	00021a97          	auipc	s5,0x21
    80003076:	8aea8a93          	addi	s5,s5,-1874 # 80023920 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000307a:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000307c:	00021997          	auipc	s3,0x21
    80003080:	87498993          	addi	s3,s3,-1932 # 800238f0 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003084:	40000b93          	li	s7,1024
    80003088:	a829                	j	800030a2 <install_trans+0x54>
    brelse(lbuf);
    8000308a:	854a                	mv	a0,s2
    8000308c:	a42ff0ef          	jal	800022ce <brelse>
    brelse(dbuf);
    80003090:	8526                	mv	a0,s1
    80003092:	a3cff0ef          	jal	800022ce <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003096:	2a05                	addiw	s4,s4,1
    80003098:	0a91                	addi	s5,s5,4
    8000309a:	02c9a783          	lw	a5,44(s3)
    8000309e:	04fa5363          	bge	s4,a5,800030e4 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800030a2:	0189a583          	lw	a1,24(s3)
    800030a6:	014585bb          	addw	a1,a1,s4
    800030aa:	2585                	addiw	a1,a1,1
    800030ac:	0289a503          	lw	a0,40(s3)
    800030b0:	916ff0ef          	jal	800021c6 <bread>
    800030b4:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    800030b6:	000aa583          	lw	a1,0(s5)
    800030ba:	0289a503          	lw	a0,40(s3)
    800030be:	908ff0ef          	jal	800021c6 <bread>
    800030c2:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    800030c4:	865e                	mv	a2,s7
    800030c6:	05890593          	addi	a1,s2,88
    800030ca:	05850513          	addi	a0,a0,88
    800030ce:	8f0fd0ef          	jal	800001be <memmove>
    bwrite(dbuf);  // write dst to disk
    800030d2:	8526                	mv	a0,s1
    800030d4:	9c8ff0ef          	jal	8000229c <bwrite>
    if(recovering == 0)
    800030d8:	fa0b19e3          	bnez	s6,8000308a <install_trans+0x3c>
      bunpin(dbuf);
    800030dc:	8526                	mv	a0,s1
    800030de:	aa8ff0ef          	jal	80002386 <bunpin>
    800030e2:	b765                	j	8000308a <install_trans+0x3c>
}
    800030e4:	60a6                	ld	ra,72(sp)
    800030e6:	6406                	ld	s0,64(sp)
    800030e8:	74e2                	ld	s1,56(sp)
    800030ea:	7942                	ld	s2,48(sp)
    800030ec:	79a2                	ld	s3,40(sp)
    800030ee:	7a02                	ld	s4,32(sp)
    800030f0:	6ae2                	ld	s5,24(sp)
    800030f2:	6b42                	ld	s6,16(sp)
    800030f4:	6ba2                	ld	s7,8(sp)
    800030f6:	6161                	addi	sp,sp,80
    800030f8:	8082                	ret
    800030fa:	8082                	ret

00000000800030fc <initlog>:
{
    800030fc:	7179                	addi	sp,sp,-48
    800030fe:	f406                	sd	ra,40(sp)
    80003100:	f022                	sd	s0,32(sp)
    80003102:	ec26                	sd	s1,24(sp)
    80003104:	e84a                	sd	s2,16(sp)
    80003106:	e44e                	sd	s3,8(sp)
    80003108:	1800                	addi	s0,sp,48
    8000310a:	892a                	mv	s2,a0
    8000310c:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    8000310e:	00020497          	auipc	s1,0x20
    80003112:	7e248493          	addi	s1,s1,2018 # 800238f0 <log>
    80003116:	00004597          	auipc	a1,0x4
    8000311a:	3ba58593          	addi	a1,a1,954 # 800074d0 <etext+0x4d0>
    8000311e:	8526                	mv	a0,s1
    80003120:	363020ef          	jal	80005c82 <initlock>
  log.start = sb->logstart;
    80003124:	0149a583          	lw	a1,20(s3)
    80003128:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    8000312a:	0109a783          	lw	a5,16(s3)
    8000312e:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003130:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003134:	854a                	mv	a0,s2
    80003136:	890ff0ef          	jal	800021c6 <bread>
  log.lh.n = lh->n;
    8000313a:	4d30                	lw	a2,88(a0)
    8000313c:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    8000313e:	00c05f63          	blez	a2,8000315c <initlog+0x60>
    80003142:	87aa                	mv	a5,a0
    80003144:	00020717          	auipc	a4,0x20
    80003148:	7dc70713          	addi	a4,a4,2012 # 80023920 <log+0x30>
    8000314c:	060a                	slli	a2,a2,0x2
    8000314e:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003150:	4ff4                	lw	a3,92(a5)
    80003152:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003154:	0791                	addi	a5,a5,4
    80003156:	0711                	addi	a4,a4,4
    80003158:	fec79ce3          	bne	a5,a2,80003150 <initlog+0x54>
  brelse(buf);
    8000315c:	972ff0ef          	jal	800022ce <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003160:	4505                	li	a0,1
    80003162:	eedff0ef          	jal	8000304e <install_trans>
  log.lh.n = 0;
    80003166:	00020797          	auipc	a5,0x20
    8000316a:	7a07ab23          	sw	zero,1974(a5) # 8002391c <log+0x2c>
  write_head(); // clear the log
    8000316e:	e83ff0ef          	jal	80002ff0 <write_head>
}
    80003172:	70a2                	ld	ra,40(sp)
    80003174:	7402                	ld	s0,32(sp)
    80003176:	64e2                	ld	s1,24(sp)
    80003178:	6942                	ld	s2,16(sp)
    8000317a:	69a2                	ld	s3,8(sp)
    8000317c:	6145                	addi	sp,sp,48
    8000317e:	8082                	ret

0000000080003180 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003180:	1101                	addi	sp,sp,-32
    80003182:	ec06                	sd	ra,24(sp)
    80003184:	e822                	sd	s0,16(sp)
    80003186:	e426                	sd	s1,8(sp)
    80003188:	e04a                	sd	s2,0(sp)
    8000318a:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000318c:	00020517          	auipc	a0,0x20
    80003190:	76450513          	addi	a0,a0,1892 # 800238f0 <log>
    80003194:	379020ef          	jal	80005d0c <acquire>
  while(1){
    if(log.committing){
    80003198:	00020497          	auipc	s1,0x20
    8000319c:	75848493          	addi	s1,s1,1880 # 800238f0 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    800031a0:	4979                	li	s2,30
    800031a2:	a029                	j	800031ac <begin_op+0x2c>
      sleep(&log, &log.lock);
    800031a4:	85a6                	mv	a1,s1
    800031a6:	8526                	mv	a0,s1
    800031a8:	a0afe0ef          	jal	800013b2 <sleep>
    if(log.committing){
    800031ac:	50dc                	lw	a5,36(s1)
    800031ae:	fbfd                	bnez	a5,800031a4 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    800031b0:	5098                	lw	a4,32(s1)
    800031b2:	2705                	addiw	a4,a4,1
    800031b4:	0027179b          	slliw	a5,a4,0x2
    800031b8:	9fb9                	addw	a5,a5,a4
    800031ba:	0017979b          	slliw	a5,a5,0x1
    800031be:	54d4                	lw	a3,44(s1)
    800031c0:	9fb5                	addw	a5,a5,a3
    800031c2:	00f95763          	bge	s2,a5,800031d0 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    800031c6:	85a6                	mv	a1,s1
    800031c8:	8526                	mv	a0,s1
    800031ca:	9e8fe0ef          	jal	800013b2 <sleep>
    800031ce:	bff9                	j	800031ac <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    800031d0:	00020797          	auipc	a5,0x20
    800031d4:	74e7a023          	sw	a4,1856(a5) # 80023910 <log+0x20>
      release(&log.lock);
    800031d8:	00020517          	auipc	a0,0x20
    800031dc:	71850513          	addi	a0,a0,1816 # 800238f0 <log>
    800031e0:	3c1020ef          	jal	80005da0 <release>
      break;
    }
  }
}
    800031e4:	60e2                	ld	ra,24(sp)
    800031e6:	6442                	ld	s0,16(sp)
    800031e8:	64a2                	ld	s1,8(sp)
    800031ea:	6902                	ld	s2,0(sp)
    800031ec:	6105                	addi	sp,sp,32
    800031ee:	8082                	ret

00000000800031f0 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    800031f0:	7139                	addi	sp,sp,-64
    800031f2:	fc06                	sd	ra,56(sp)
    800031f4:	f822                	sd	s0,48(sp)
    800031f6:	f426                	sd	s1,40(sp)
    800031f8:	f04a                	sd	s2,32(sp)
    800031fa:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    800031fc:	00020497          	auipc	s1,0x20
    80003200:	6f448493          	addi	s1,s1,1780 # 800238f0 <log>
    80003204:	8526                	mv	a0,s1
    80003206:	307020ef          	jal	80005d0c <acquire>
  log.outstanding -= 1;
    8000320a:	509c                	lw	a5,32(s1)
    8000320c:	37fd                	addiw	a5,a5,-1
    8000320e:	893e                	mv	s2,a5
    80003210:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80003212:	50dc                	lw	a5,36(s1)
    80003214:	e7b1                	bnez	a5,80003260 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80003216:	04091e63          	bnez	s2,80003272 <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    8000321a:	00020497          	auipc	s1,0x20
    8000321e:	6d648493          	addi	s1,s1,1750 # 800238f0 <log>
    80003222:	4785                	li	a5,1
    80003224:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003226:	8526                	mv	a0,s1
    80003228:	379020ef          	jal	80005da0 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    8000322c:	54dc                	lw	a5,44(s1)
    8000322e:	06f04463          	bgtz	a5,80003296 <end_op+0xa6>
    acquire(&log.lock);
    80003232:	00020517          	auipc	a0,0x20
    80003236:	6be50513          	addi	a0,a0,1726 # 800238f0 <log>
    8000323a:	2d3020ef          	jal	80005d0c <acquire>
    log.committing = 0;
    8000323e:	00020797          	auipc	a5,0x20
    80003242:	6c07ab23          	sw	zero,1750(a5) # 80023914 <log+0x24>
    wakeup(&log);
    80003246:	00020517          	auipc	a0,0x20
    8000324a:	6aa50513          	addi	a0,a0,1706 # 800238f0 <log>
    8000324e:	9b0fe0ef          	jal	800013fe <wakeup>
    release(&log.lock);
    80003252:	00020517          	auipc	a0,0x20
    80003256:	69e50513          	addi	a0,a0,1694 # 800238f0 <log>
    8000325a:	347020ef          	jal	80005da0 <release>
}
    8000325e:	a035                	j	8000328a <end_op+0x9a>
    80003260:	ec4e                	sd	s3,24(sp)
    80003262:	e852                	sd	s4,16(sp)
    80003264:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003266:	00004517          	auipc	a0,0x4
    8000326a:	27250513          	addi	a0,a0,626 # 800074d8 <etext+0x4d8>
    8000326e:	760020ef          	jal	800059ce <panic>
    wakeup(&log);
    80003272:	00020517          	auipc	a0,0x20
    80003276:	67e50513          	addi	a0,a0,1662 # 800238f0 <log>
    8000327a:	984fe0ef          	jal	800013fe <wakeup>
  release(&log.lock);
    8000327e:	00020517          	auipc	a0,0x20
    80003282:	67250513          	addi	a0,a0,1650 # 800238f0 <log>
    80003286:	31b020ef          	jal	80005da0 <release>
}
    8000328a:	70e2                	ld	ra,56(sp)
    8000328c:	7442                	ld	s0,48(sp)
    8000328e:	74a2                	ld	s1,40(sp)
    80003290:	7902                	ld	s2,32(sp)
    80003292:	6121                	addi	sp,sp,64
    80003294:	8082                	ret
    80003296:	ec4e                	sd	s3,24(sp)
    80003298:	e852                	sd	s4,16(sp)
    8000329a:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    8000329c:	00020a97          	auipc	s5,0x20
    800032a0:	684a8a93          	addi	s5,s5,1668 # 80023920 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    800032a4:	00020a17          	auipc	s4,0x20
    800032a8:	64ca0a13          	addi	s4,s4,1612 # 800238f0 <log>
    800032ac:	018a2583          	lw	a1,24(s4)
    800032b0:	012585bb          	addw	a1,a1,s2
    800032b4:	2585                	addiw	a1,a1,1
    800032b6:	028a2503          	lw	a0,40(s4)
    800032ba:	f0dfe0ef          	jal	800021c6 <bread>
    800032be:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    800032c0:	000aa583          	lw	a1,0(s5)
    800032c4:	028a2503          	lw	a0,40(s4)
    800032c8:	efffe0ef          	jal	800021c6 <bread>
    800032cc:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    800032ce:	40000613          	li	a2,1024
    800032d2:	05850593          	addi	a1,a0,88
    800032d6:	05848513          	addi	a0,s1,88
    800032da:	ee5fc0ef          	jal	800001be <memmove>
    bwrite(to);  // write the log
    800032de:	8526                	mv	a0,s1
    800032e0:	fbdfe0ef          	jal	8000229c <bwrite>
    brelse(from);
    800032e4:	854e                	mv	a0,s3
    800032e6:	fe9fe0ef          	jal	800022ce <brelse>
    brelse(to);
    800032ea:	8526                	mv	a0,s1
    800032ec:	fe3fe0ef          	jal	800022ce <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800032f0:	2905                	addiw	s2,s2,1
    800032f2:	0a91                	addi	s5,s5,4
    800032f4:	02ca2783          	lw	a5,44(s4)
    800032f8:	faf94ae3          	blt	s2,a5,800032ac <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800032fc:	cf5ff0ef          	jal	80002ff0 <write_head>
    install_trans(0); // Now install writes to home locations
    80003300:	4501                	li	a0,0
    80003302:	d4dff0ef          	jal	8000304e <install_trans>
    log.lh.n = 0;
    80003306:	00020797          	auipc	a5,0x20
    8000330a:	6007ab23          	sw	zero,1558(a5) # 8002391c <log+0x2c>
    write_head();    // Erase the transaction from the log
    8000330e:	ce3ff0ef          	jal	80002ff0 <write_head>
    80003312:	69e2                	ld	s3,24(sp)
    80003314:	6a42                	ld	s4,16(sp)
    80003316:	6aa2                	ld	s5,8(sp)
    80003318:	bf29                	j	80003232 <end_op+0x42>

000000008000331a <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000331a:	1101                	addi	sp,sp,-32
    8000331c:	ec06                	sd	ra,24(sp)
    8000331e:	e822                	sd	s0,16(sp)
    80003320:	e426                	sd	s1,8(sp)
    80003322:	1000                	addi	s0,sp,32
    80003324:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003326:	00020517          	auipc	a0,0x20
    8000332a:	5ca50513          	addi	a0,a0,1482 # 800238f0 <log>
    8000332e:	1df020ef          	jal	80005d0c <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003332:	00020617          	auipc	a2,0x20
    80003336:	5ea62603          	lw	a2,1514(a2) # 8002391c <log+0x2c>
    8000333a:	47f5                	li	a5,29
    8000333c:	06c7c463          	blt	a5,a2,800033a4 <log_write+0x8a>
    80003340:	00020797          	auipc	a5,0x20
    80003344:	5cc7a783          	lw	a5,1484(a5) # 8002390c <log+0x1c>
    80003348:	37fd                	addiw	a5,a5,-1
    8000334a:	04f65d63          	bge	a2,a5,800033a4 <log_write+0x8a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000334e:	00020797          	auipc	a5,0x20
    80003352:	5c27a783          	lw	a5,1474(a5) # 80023910 <log+0x20>
    80003356:	04f05d63          	blez	a5,800033b0 <log_write+0x96>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    8000335a:	4781                	li	a5,0
    8000335c:	06c05063          	blez	a2,800033bc <log_write+0xa2>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003360:	44cc                	lw	a1,12(s1)
    80003362:	00020717          	auipc	a4,0x20
    80003366:	5be70713          	addi	a4,a4,1470 # 80023920 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    8000336a:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000336c:	4314                	lw	a3,0(a4)
    8000336e:	04b68763          	beq	a3,a1,800033bc <log_write+0xa2>
  for (i = 0; i < log.lh.n; i++) {
    80003372:	2785                	addiw	a5,a5,1
    80003374:	0711                	addi	a4,a4,4
    80003376:	fef61be3          	bne	a2,a5,8000336c <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    8000337a:	060a                	slli	a2,a2,0x2
    8000337c:	02060613          	addi	a2,a2,32
    80003380:	00020797          	auipc	a5,0x20
    80003384:	57078793          	addi	a5,a5,1392 # 800238f0 <log>
    80003388:	97b2                	add	a5,a5,a2
    8000338a:	44d8                	lw	a4,12(s1)
    8000338c:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    8000338e:	8526                	mv	a0,s1
    80003390:	fc3fe0ef          	jal	80002352 <bpin>
    log.lh.n++;
    80003394:	00020717          	auipc	a4,0x20
    80003398:	55c70713          	addi	a4,a4,1372 # 800238f0 <log>
    8000339c:	575c                	lw	a5,44(a4)
    8000339e:	2785                	addiw	a5,a5,1
    800033a0:	d75c                	sw	a5,44(a4)
    800033a2:	a815                	j	800033d6 <log_write+0xbc>
    panic("too big a transaction");
    800033a4:	00004517          	auipc	a0,0x4
    800033a8:	14450513          	addi	a0,a0,324 # 800074e8 <etext+0x4e8>
    800033ac:	622020ef          	jal	800059ce <panic>
    panic("log_write outside of trans");
    800033b0:	00004517          	auipc	a0,0x4
    800033b4:	15050513          	addi	a0,a0,336 # 80007500 <etext+0x500>
    800033b8:	616020ef          	jal	800059ce <panic>
  log.lh.block[i] = b->blockno;
    800033bc:	00279693          	slli	a3,a5,0x2
    800033c0:	02068693          	addi	a3,a3,32
    800033c4:	00020717          	auipc	a4,0x20
    800033c8:	52c70713          	addi	a4,a4,1324 # 800238f0 <log>
    800033cc:	9736                	add	a4,a4,a3
    800033ce:	44d4                	lw	a3,12(s1)
    800033d0:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    800033d2:	faf60ee3          	beq	a2,a5,8000338e <log_write+0x74>
  }
  release(&log.lock);
    800033d6:	00020517          	auipc	a0,0x20
    800033da:	51a50513          	addi	a0,a0,1306 # 800238f0 <log>
    800033de:	1c3020ef          	jal	80005da0 <release>
}
    800033e2:	60e2                	ld	ra,24(sp)
    800033e4:	6442                	ld	s0,16(sp)
    800033e6:	64a2                	ld	s1,8(sp)
    800033e8:	6105                	addi	sp,sp,32
    800033ea:	8082                	ret

00000000800033ec <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800033ec:	1101                	addi	sp,sp,-32
    800033ee:	ec06                	sd	ra,24(sp)
    800033f0:	e822                	sd	s0,16(sp)
    800033f2:	e426                	sd	s1,8(sp)
    800033f4:	e04a                	sd	s2,0(sp)
    800033f6:	1000                	addi	s0,sp,32
    800033f8:	84aa                	mv	s1,a0
    800033fa:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800033fc:	00004597          	auipc	a1,0x4
    80003400:	12458593          	addi	a1,a1,292 # 80007520 <etext+0x520>
    80003404:	0521                	addi	a0,a0,8
    80003406:	07d020ef          	jal	80005c82 <initlock>
  lk->name = name;
    8000340a:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000340e:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003412:	0204a423          	sw	zero,40(s1)
}
    80003416:	60e2                	ld	ra,24(sp)
    80003418:	6442                	ld	s0,16(sp)
    8000341a:	64a2                	ld	s1,8(sp)
    8000341c:	6902                	ld	s2,0(sp)
    8000341e:	6105                	addi	sp,sp,32
    80003420:	8082                	ret

0000000080003422 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003422:	1101                	addi	sp,sp,-32
    80003424:	ec06                	sd	ra,24(sp)
    80003426:	e822                	sd	s0,16(sp)
    80003428:	e426                	sd	s1,8(sp)
    8000342a:	e04a                	sd	s2,0(sp)
    8000342c:	1000                	addi	s0,sp,32
    8000342e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003430:	00850913          	addi	s2,a0,8
    80003434:	854a                	mv	a0,s2
    80003436:	0d7020ef          	jal	80005d0c <acquire>
  while (lk->locked) {
    8000343a:	409c                	lw	a5,0(s1)
    8000343c:	c799                	beqz	a5,8000344a <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    8000343e:	85ca                	mv	a1,s2
    80003440:	8526                	mv	a0,s1
    80003442:	f71fd0ef          	jal	800013b2 <sleep>
  while (lk->locked) {
    80003446:	409c                	lw	a5,0(s1)
    80003448:	fbfd                	bnez	a5,8000343e <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000344a:	4785                	li	a5,1
    8000344c:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    8000344e:	917fd0ef          	jal	80000d64 <myproc>
    80003452:	591c                	lw	a5,48(a0)
    80003454:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003456:	854a                	mv	a0,s2
    80003458:	149020ef          	jal	80005da0 <release>
}
    8000345c:	60e2                	ld	ra,24(sp)
    8000345e:	6442                	ld	s0,16(sp)
    80003460:	64a2                	ld	s1,8(sp)
    80003462:	6902                	ld	s2,0(sp)
    80003464:	6105                	addi	sp,sp,32
    80003466:	8082                	ret

0000000080003468 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003468:	1101                	addi	sp,sp,-32
    8000346a:	ec06                	sd	ra,24(sp)
    8000346c:	e822                	sd	s0,16(sp)
    8000346e:	e426                	sd	s1,8(sp)
    80003470:	e04a                	sd	s2,0(sp)
    80003472:	1000                	addi	s0,sp,32
    80003474:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003476:	00850913          	addi	s2,a0,8
    8000347a:	854a                	mv	a0,s2
    8000347c:	091020ef          	jal	80005d0c <acquire>
  lk->locked = 0;
    80003480:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003484:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003488:	8526                	mv	a0,s1
    8000348a:	f75fd0ef          	jal	800013fe <wakeup>
  release(&lk->lk);
    8000348e:	854a                	mv	a0,s2
    80003490:	111020ef          	jal	80005da0 <release>
}
    80003494:	60e2                	ld	ra,24(sp)
    80003496:	6442                	ld	s0,16(sp)
    80003498:	64a2                	ld	s1,8(sp)
    8000349a:	6902                	ld	s2,0(sp)
    8000349c:	6105                	addi	sp,sp,32
    8000349e:	8082                	ret

00000000800034a0 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800034a0:	7179                	addi	sp,sp,-48
    800034a2:	f406                	sd	ra,40(sp)
    800034a4:	f022                	sd	s0,32(sp)
    800034a6:	ec26                	sd	s1,24(sp)
    800034a8:	e84a                	sd	s2,16(sp)
    800034aa:	1800                	addi	s0,sp,48
    800034ac:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    800034ae:	00850913          	addi	s2,a0,8
    800034b2:	854a                	mv	a0,s2
    800034b4:	059020ef          	jal	80005d0c <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800034b8:	409c                	lw	a5,0(s1)
    800034ba:	ef81                	bnez	a5,800034d2 <holdingsleep+0x32>
    800034bc:	4481                	li	s1,0
  release(&lk->lk);
    800034be:	854a                	mv	a0,s2
    800034c0:	0e1020ef          	jal	80005da0 <release>
  return r;
}
    800034c4:	8526                	mv	a0,s1
    800034c6:	70a2                	ld	ra,40(sp)
    800034c8:	7402                	ld	s0,32(sp)
    800034ca:	64e2                	ld	s1,24(sp)
    800034cc:	6942                	ld	s2,16(sp)
    800034ce:	6145                	addi	sp,sp,48
    800034d0:	8082                	ret
    800034d2:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800034d4:	0284a983          	lw	s3,40(s1)
    800034d8:	88dfd0ef          	jal	80000d64 <myproc>
    800034dc:	5904                	lw	s1,48(a0)
    800034de:	413484b3          	sub	s1,s1,s3
    800034e2:	0014b493          	seqz	s1,s1
    800034e6:	69a2                	ld	s3,8(sp)
    800034e8:	bfd9                	j	800034be <holdingsleep+0x1e>

00000000800034ea <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800034ea:	1141                	addi	sp,sp,-16
    800034ec:	e406                	sd	ra,8(sp)
    800034ee:	e022                	sd	s0,0(sp)
    800034f0:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800034f2:	00004597          	auipc	a1,0x4
    800034f6:	03e58593          	addi	a1,a1,62 # 80007530 <etext+0x530>
    800034fa:	00020517          	auipc	a0,0x20
    800034fe:	53e50513          	addi	a0,a0,1342 # 80023a38 <ftable>
    80003502:	780020ef          	jal	80005c82 <initlock>
}
    80003506:	60a2                	ld	ra,8(sp)
    80003508:	6402                	ld	s0,0(sp)
    8000350a:	0141                	addi	sp,sp,16
    8000350c:	8082                	ret

000000008000350e <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000350e:	1101                	addi	sp,sp,-32
    80003510:	ec06                	sd	ra,24(sp)
    80003512:	e822                	sd	s0,16(sp)
    80003514:	e426                	sd	s1,8(sp)
    80003516:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003518:	00020517          	auipc	a0,0x20
    8000351c:	52050513          	addi	a0,a0,1312 # 80023a38 <ftable>
    80003520:	7ec020ef          	jal	80005d0c <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003524:	00020497          	auipc	s1,0x20
    80003528:	52c48493          	addi	s1,s1,1324 # 80023a50 <ftable+0x18>
    8000352c:	00021717          	auipc	a4,0x21
    80003530:	4c470713          	addi	a4,a4,1220 # 800249f0 <disk>
    if(f->ref == 0){
    80003534:	40dc                	lw	a5,4(s1)
    80003536:	cf89                	beqz	a5,80003550 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003538:	02848493          	addi	s1,s1,40
    8000353c:	fee49ce3          	bne	s1,a4,80003534 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003540:	00020517          	auipc	a0,0x20
    80003544:	4f850513          	addi	a0,a0,1272 # 80023a38 <ftable>
    80003548:	059020ef          	jal	80005da0 <release>
  return 0;
    8000354c:	4481                	li	s1,0
    8000354e:	a809                	j	80003560 <filealloc+0x52>
      f->ref = 1;
    80003550:	4785                	li	a5,1
    80003552:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003554:	00020517          	auipc	a0,0x20
    80003558:	4e450513          	addi	a0,a0,1252 # 80023a38 <ftable>
    8000355c:	045020ef          	jal	80005da0 <release>
}
    80003560:	8526                	mv	a0,s1
    80003562:	60e2                	ld	ra,24(sp)
    80003564:	6442                	ld	s0,16(sp)
    80003566:	64a2                	ld	s1,8(sp)
    80003568:	6105                	addi	sp,sp,32
    8000356a:	8082                	ret

000000008000356c <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    8000356c:	1101                	addi	sp,sp,-32
    8000356e:	ec06                	sd	ra,24(sp)
    80003570:	e822                	sd	s0,16(sp)
    80003572:	e426                	sd	s1,8(sp)
    80003574:	1000                	addi	s0,sp,32
    80003576:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003578:	00020517          	auipc	a0,0x20
    8000357c:	4c050513          	addi	a0,a0,1216 # 80023a38 <ftable>
    80003580:	78c020ef          	jal	80005d0c <acquire>
  if(f->ref < 1)
    80003584:	40dc                	lw	a5,4(s1)
    80003586:	02f05063          	blez	a5,800035a6 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000358a:	2785                	addiw	a5,a5,1
    8000358c:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000358e:	00020517          	auipc	a0,0x20
    80003592:	4aa50513          	addi	a0,a0,1194 # 80023a38 <ftable>
    80003596:	00b020ef          	jal	80005da0 <release>
  return f;
}
    8000359a:	8526                	mv	a0,s1
    8000359c:	60e2                	ld	ra,24(sp)
    8000359e:	6442                	ld	s0,16(sp)
    800035a0:	64a2                	ld	s1,8(sp)
    800035a2:	6105                	addi	sp,sp,32
    800035a4:	8082                	ret
    panic("filedup");
    800035a6:	00004517          	auipc	a0,0x4
    800035aa:	f9250513          	addi	a0,a0,-110 # 80007538 <etext+0x538>
    800035ae:	420020ef          	jal	800059ce <panic>

00000000800035b2 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800035b2:	7139                	addi	sp,sp,-64
    800035b4:	fc06                	sd	ra,56(sp)
    800035b6:	f822                	sd	s0,48(sp)
    800035b8:	f426                	sd	s1,40(sp)
    800035ba:	0080                	addi	s0,sp,64
    800035bc:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800035be:	00020517          	auipc	a0,0x20
    800035c2:	47a50513          	addi	a0,a0,1146 # 80023a38 <ftable>
    800035c6:	746020ef          	jal	80005d0c <acquire>
  if(f->ref < 1)
    800035ca:	40dc                	lw	a5,4(s1)
    800035cc:	04f05a63          	blez	a5,80003620 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    800035d0:	37fd                	addiw	a5,a5,-1
    800035d2:	c0dc                	sw	a5,4(s1)
    800035d4:	06f04063          	bgtz	a5,80003634 <fileclose+0x82>
    800035d8:	f04a                	sd	s2,32(sp)
    800035da:	ec4e                	sd	s3,24(sp)
    800035dc:	e852                	sd	s4,16(sp)
    800035de:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800035e0:	0004a903          	lw	s2,0(s1)
    800035e4:	0094c783          	lbu	a5,9(s1)
    800035e8:	89be                	mv	s3,a5
    800035ea:	689c                	ld	a5,16(s1)
    800035ec:	8a3e                	mv	s4,a5
    800035ee:	6c9c                	ld	a5,24(s1)
    800035f0:	8abe                	mv	s5,a5
  f->ref = 0;
    800035f2:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800035f6:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800035fa:	00020517          	auipc	a0,0x20
    800035fe:	43e50513          	addi	a0,a0,1086 # 80023a38 <ftable>
    80003602:	79e020ef          	jal	80005da0 <release>

  if(ff.type == FD_PIPE){
    80003606:	4785                	li	a5,1
    80003608:	04f90163          	beq	s2,a5,8000364a <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000360c:	ffe9079b          	addiw	a5,s2,-2
    80003610:	4705                	li	a4,1
    80003612:	04f77563          	bgeu	a4,a5,8000365c <fileclose+0xaa>
    80003616:	7902                	ld	s2,32(sp)
    80003618:	69e2                	ld	s3,24(sp)
    8000361a:	6a42                	ld	s4,16(sp)
    8000361c:	6aa2                	ld	s5,8(sp)
    8000361e:	a00d                	j	80003640 <fileclose+0x8e>
    80003620:	f04a                	sd	s2,32(sp)
    80003622:	ec4e                	sd	s3,24(sp)
    80003624:	e852                	sd	s4,16(sp)
    80003626:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80003628:	00004517          	auipc	a0,0x4
    8000362c:	f1850513          	addi	a0,a0,-232 # 80007540 <etext+0x540>
    80003630:	39e020ef          	jal	800059ce <panic>
    release(&ftable.lock);
    80003634:	00020517          	auipc	a0,0x20
    80003638:	40450513          	addi	a0,a0,1028 # 80023a38 <ftable>
    8000363c:	764020ef          	jal	80005da0 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80003640:	70e2                	ld	ra,56(sp)
    80003642:	7442                	ld	s0,48(sp)
    80003644:	74a2                	ld	s1,40(sp)
    80003646:	6121                	addi	sp,sp,64
    80003648:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    8000364a:	85ce                	mv	a1,s3
    8000364c:	8552                	mv	a0,s4
    8000364e:	348000ef          	jal	80003996 <pipeclose>
    80003652:	7902                	ld	s2,32(sp)
    80003654:	69e2                	ld	s3,24(sp)
    80003656:	6a42                	ld	s4,16(sp)
    80003658:	6aa2                	ld	s5,8(sp)
    8000365a:	b7dd                	j	80003640 <fileclose+0x8e>
    begin_op();
    8000365c:	b25ff0ef          	jal	80003180 <begin_op>
    iput(ff.ip);
    80003660:	8556                	mv	a0,s5
    80003662:	be8ff0ef          	jal	80002a4a <iput>
    end_op();
    80003666:	b8bff0ef          	jal	800031f0 <end_op>
    8000366a:	7902                	ld	s2,32(sp)
    8000366c:	69e2                	ld	s3,24(sp)
    8000366e:	6a42                	ld	s4,16(sp)
    80003670:	6aa2                	ld	s5,8(sp)
    80003672:	b7f9                	j	80003640 <fileclose+0x8e>

0000000080003674 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80003674:	715d                	addi	sp,sp,-80
    80003676:	e486                	sd	ra,72(sp)
    80003678:	e0a2                	sd	s0,64(sp)
    8000367a:	fc26                	sd	s1,56(sp)
    8000367c:	f052                	sd	s4,32(sp)
    8000367e:	0880                	addi	s0,sp,80
    80003680:	84aa                	mv	s1,a0
    80003682:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80003684:	ee0fd0ef          	jal	80000d64 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003688:	409c                	lw	a5,0(s1)
    8000368a:	37f9                	addiw	a5,a5,-2
    8000368c:	4705                	li	a4,1
    8000368e:	04f76263          	bltu	a4,a5,800036d2 <filestat+0x5e>
    80003692:	f84a                	sd	s2,48(sp)
    80003694:	f44e                	sd	s3,40(sp)
    80003696:	89aa                	mv	s3,a0
    ilock(f->ip);
    80003698:	6c88                	ld	a0,24(s1)
    8000369a:	a2eff0ef          	jal	800028c8 <ilock>
    stati(f->ip, &st);
    8000369e:	fb840913          	addi	s2,s0,-72
    800036a2:	85ca                	mv	a1,s2
    800036a4:	6c88                	ld	a0,24(s1)
    800036a6:	c4eff0ef          	jal	80002af4 <stati>
    iunlock(f->ip);
    800036aa:	6c88                	ld	a0,24(s1)
    800036ac:	acaff0ef          	jal	80002976 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800036b0:	46e1                	li	a3,24
    800036b2:	864a                	mv	a2,s2
    800036b4:	85d2                	mv	a1,s4
    800036b6:	0509b503          	ld	a0,80(s3)
    800036ba:	b32fd0ef          	jal	800009ec <copyout>
    800036be:	41f5551b          	sraiw	a0,a0,0x1f
    800036c2:	7942                	ld	s2,48(sp)
    800036c4:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800036c6:	60a6                	ld	ra,72(sp)
    800036c8:	6406                	ld	s0,64(sp)
    800036ca:	74e2                	ld	s1,56(sp)
    800036cc:	7a02                	ld	s4,32(sp)
    800036ce:	6161                	addi	sp,sp,80
    800036d0:	8082                	ret
  return -1;
    800036d2:	557d                	li	a0,-1
    800036d4:	bfcd                	j	800036c6 <filestat+0x52>

00000000800036d6 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800036d6:	7179                	addi	sp,sp,-48
    800036d8:	f406                	sd	ra,40(sp)
    800036da:	f022                	sd	s0,32(sp)
    800036dc:	e84a                	sd	s2,16(sp)
    800036de:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800036e0:	00854783          	lbu	a5,8(a0)
    800036e4:	cfd1                	beqz	a5,80003780 <fileread+0xaa>
    800036e6:	ec26                	sd	s1,24(sp)
    800036e8:	e44e                	sd	s3,8(sp)
    800036ea:	84aa                	mv	s1,a0
    800036ec:	892e                	mv	s2,a1
    800036ee:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    800036f0:	411c                	lw	a5,0(a0)
    800036f2:	4705                	li	a4,1
    800036f4:	04e78363          	beq	a5,a4,8000373a <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800036f8:	470d                	li	a4,3
    800036fa:	04e78763          	beq	a5,a4,80003748 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800036fe:	4709                	li	a4,2
    80003700:	06e79a63          	bne	a5,a4,80003774 <fileread+0x9e>
    ilock(f->ip);
    80003704:	6d08                	ld	a0,24(a0)
    80003706:	9c2ff0ef          	jal	800028c8 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000370a:	874e                	mv	a4,s3
    8000370c:	5094                	lw	a3,32(s1)
    8000370e:	864a                	mv	a2,s2
    80003710:	4585                	li	a1,1
    80003712:	6c88                	ld	a0,24(s1)
    80003714:	c0eff0ef          	jal	80002b22 <readi>
    80003718:	892a                	mv	s2,a0
    8000371a:	00a05563          	blez	a0,80003724 <fileread+0x4e>
      f->off += r;
    8000371e:	509c                	lw	a5,32(s1)
    80003720:	9fa9                	addw	a5,a5,a0
    80003722:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80003724:	6c88                	ld	a0,24(s1)
    80003726:	a50ff0ef          	jal	80002976 <iunlock>
    8000372a:	64e2                	ld	s1,24(sp)
    8000372c:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000372e:	854a                	mv	a0,s2
    80003730:	70a2                	ld	ra,40(sp)
    80003732:	7402                	ld	s0,32(sp)
    80003734:	6942                	ld	s2,16(sp)
    80003736:	6145                	addi	sp,sp,48
    80003738:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000373a:	6908                	ld	a0,16(a0)
    8000373c:	3b0000ef          	jal	80003aec <piperead>
    80003740:	892a                	mv	s2,a0
    80003742:	64e2                	ld	s1,24(sp)
    80003744:	69a2                	ld	s3,8(sp)
    80003746:	b7e5                	j	8000372e <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80003748:	02451783          	lh	a5,36(a0)
    8000374c:	03079693          	slli	a3,a5,0x30
    80003750:	92c1                	srli	a3,a3,0x30
    80003752:	4725                	li	a4,9
    80003754:	02d76963          	bltu	a4,a3,80003786 <fileread+0xb0>
    80003758:	0792                	slli	a5,a5,0x4
    8000375a:	00020717          	auipc	a4,0x20
    8000375e:	23e70713          	addi	a4,a4,574 # 80023998 <devsw>
    80003762:	97ba                	add	a5,a5,a4
    80003764:	639c                	ld	a5,0(a5)
    80003766:	c78d                	beqz	a5,80003790 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80003768:	4505                	li	a0,1
    8000376a:	9782                	jalr	a5
    8000376c:	892a                	mv	s2,a0
    8000376e:	64e2                	ld	s1,24(sp)
    80003770:	69a2                	ld	s3,8(sp)
    80003772:	bf75                	j	8000372e <fileread+0x58>
    panic("fileread");
    80003774:	00004517          	auipc	a0,0x4
    80003778:	ddc50513          	addi	a0,a0,-548 # 80007550 <etext+0x550>
    8000377c:	252020ef          	jal	800059ce <panic>
    return -1;
    80003780:	57fd                	li	a5,-1
    80003782:	893e                	mv	s2,a5
    80003784:	b76d                	j	8000372e <fileread+0x58>
      return -1;
    80003786:	57fd                	li	a5,-1
    80003788:	893e                	mv	s2,a5
    8000378a:	64e2                	ld	s1,24(sp)
    8000378c:	69a2                	ld	s3,8(sp)
    8000378e:	b745                	j	8000372e <fileread+0x58>
    80003790:	57fd                	li	a5,-1
    80003792:	893e                	mv	s2,a5
    80003794:	64e2                	ld	s1,24(sp)
    80003796:	69a2                	ld	s3,8(sp)
    80003798:	bf59                	j	8000372e <fileread+0x58>

000000008000379a <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    8000379a:	00954783          	lbu	a5,9(a0)
    8000379e:	10078f63          	beqz	a5,800038bc <filewrite+0x122>
{
    800037a2:	711d                	addi	sp,sp,-96
    800037a4:	ec86                	sd	ra,88(sp)
    800037a6:	e8a2                	sd	s0,80(sp)
    800037a8:	e0ca                	sd	s2,64(sp)
    800037aa:	f456                	sd	s5,40(sp)
    800037ac:	f05a                	sd	s6,32(sp)
    800037ae:	1080                	addi	s0,sp,96
    800037b0:	892a                	mv	s2,a0
    800037b2:	8b2e                	mv	s6,a1
    800037b4:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    800037b6:	411c                	lw	a5,0(a0)
    800037b8:	4705                	li	a4,1
    800037ba:	02e78a63          	beq	a5,a4,800037ee <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800037be:	470d                	li	a4,3
    800037c0:	02e78b63          	beq	a5,a4,800037f6 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800037c4:	4709                	li	a4,2
    800037c6:	0ce79f63          	bne	a5,a4,800038a4 <filewrite+0x10a>
    800037ca:	f852                	sd	s4,48(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800037cc:	0ac05a63          	blez	a2,80003880 <filewrite+0xe6>
    800037d0:	e4a6                	sd	s1,72(sp)
    800037d2:	fc4e                	sd	s3,56(sp)
    800037d4:	ec5e                	sd	s7,24(sp)
    800037d6:	e862                	sd	s8,16(sp)
    800037d8:	e466                	sd	s9,8(sp)
    int i = 0;
    800037da:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    800037dc:	6b85                	lui	s7,0x1
    800037de:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800037e2:	6785                	lui	a5,0x1
    800037e4:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800037e8:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800037ea:	4c05                	li	s8,1
    800037ec:	a8ad                	j	80003866 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800037ee:	6908                	ld	a0,16(a0)
    800037f0:	204000ef          	jal	800039f4 <pipewrite>
    800037f4:	a04d                	j	80003896 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800037f6:	02451783          	lh	a5,36(a0)
    800037fa:	03079693          	slli	a3,a5,0x30
    800037fe:	92c1                	srli	a3,a3,0x30
    80003800:	4725                	li	a4,9
    80003802:	0ad76f63          	bltu	a4,a3,800038c0 <filewrite+0x126>
    80003806:	0792                	slli	a5,a5,0x4
    80003808:	00020717          	auipc	a4,0x20
    8000380c:	19070713          	addi	a4,a4,400 # 80023998 <devsw>
    80003810:	97ba                	add	a5,a5,a4
    80003812:	679c                	ld	a5,8(a5)
    80003814:	cbc5                	beqz	a5,800038c4 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    80003816:	4505                	li	a0,1
    80003818:	9782                	jalr	a5
    8000381a:	a8b5                	j	80003896 <filewrite+0xfc>
      if(n1 > max)
    8000381c:	2981                	sext.w	s3,s3
      begin_op();
    8000381e:	963ff0ef          	jal	80003180 <begin_op>
      ilock(f->ip);
    80003822:	01893503          	ld	a0,24(s2)
    80003826:	8a2ff0ef          	jal	800028c8 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000382a:	874e                	mv	a4,s3
    8000382c:	02092683          	lw	a3,32(s2)
    80003830:	016a0633          	add	a2,s4,s6
    80003834:	85e2                	mv	a1,s8
    80003836:	01893503          	ld	a0,24(s2)
    8000383a:	bdaff0ef          	jal	80002c14 <writei>
    8000383e:	84aa                	mv	s1,a0
    80003840:	00a05763          	blez	a0,8000384e <filewrite+0xb4>
        f->off += r;
    80003844:	02092783          	lw	a5,32(s2)
    80003848:	9fa9                	addw	a5,a5,a0
    8000384a:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000384e:	01893503          	ld	a0,24(s2)
    80003852:	924ff0ef          	jal	80002976 <iunlock>
      end_op();
    80003856:	99bff0ef          	jal	800031f0 <end_op>

      if(r != n1){
    8000385a:	02999563          	bne	s3,s1,80003884 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    8000385e:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80003862:	015a5963          	bge	s4,s5,80003874 <filewrite+0xda>
      int n1 = n - i;
    80003866:	414a87bb          	subw	a5,s5,s4
    8000386a:	89be                	mv	s3,a5
      if(n1 > max)
    8000386c:	fafbd8e3          	bge	s7,a5,8000381c <filewrite+0x82>
    80003870:	89e6                	mv	s3,s9
    80003872:	b76d                	j	8000381c <filewrite+0x82>
    80003874:	64a6                	ld	s1,72(sp)
    80003876:	79e2                	ld	s3,56(sp)
    80003878:	6be2                	ld	s7,24(sp)
    8000387a:	6c42                	ld	s8,16(sp)
    8000387c:	6ca2                	ld	s9,8(sp)
    8000387e:	a801                	j	8000388e <filewrite+0xf4>
    int i = 0;
    80003880:	4a01                	li	s4,0
    80003882:	a031                	j	8000388e <filewrite+0xf4>
    80003884:	64a6                	ld	s1,72(sp)
    80003886:	79e2                	ld	s3,56(sp)
    80003888:	6be2                	ld	s7,24(sp)
    8000388a:	6c42                	ld	s8,16(sp)
    8000388c:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    8000388e:	034a9d63          	bne	s5,s4,800038c8 <filewrite+0x12e>
    80003892:	8556                	mv	a0,s5
    80003894:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80003896:	60e6                	ld	ra,88(sp)
    80003898:	6446                	ld	s0,80(sp)
    8000389a:	6906                	ld	s2,64(sp)
    8000389c:	7aa2                	ld	s5,40(sp)
    8000389e:	7b02                	ld	s6,32(sp)
    800038a0:	6125                	addi	sp,sp,96
    800038a2:	8082                	ret
    800038a4:	e4a6                	sd	s1,72(sp)
    800038a6:	fc4e                	sd	s3,56(sp)
    800038a8:	f852                	sd	s4,48(sp)
    800038aa:	ec5e                	sd	s7,24(sp)
    800038ac:	e862                	sd	s8,16(sp)
    800038ae:	e466                	sd	s9,8(sp)
    panic("filewrite");
    800038b0:	00004517          	auipc	a0,0x4
    800038b4:	cb050513          	addi	a0,a0,-848 # 80007560 <etext+0x560>
    800038b8:	116020ef          	jal	800059ce <panic>
    return -1;
    800038bc:	557d                	li	a0,-1
}
    800038be:	8082                	ret
      return -1;
    800038c0:	557d                	li	a0,-1
    800038c2:	bfd1                	j	80003896 <filewrite+0xfc>
    800038c4:	557d                	li	a0,-1
    800038c6:	bfc1                	j	80003896 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    800038c8:	557d                	li	a0,-1
    800038ca:	7a42                	ld	s4,48(sp)
    800038cc:	b7e9                	j	80003896 <filewrite+0xfc>

00000000800038ce <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800038ce:	7179                	addi	sp,sp,-48
    800038d0:	f406                	sd	ra,40(sp)
    800038d2:	f022                	sd	s0,32(sp)
    800038d4:	ec26                	sd	s1,24(sp)
    800038d6:	e052                	sd	s4,0(sp)
    800038d8:	1800                	addi	s0,sp,48
    800038da:	84aa                	mv	s1,a0
    800038dc:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800038de:	0005b023          	sd	zero,0(a1)
    800038e2:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800038e6:	c29ff0ef          	jal	8000350e <filealloc>
    800038ea:	e088                	sd	a0,0(s1)
    800038ec:	c549                	beqz	a0,80003976 <pipealloc+0xa8>
    800038ee:	c21ff0ef          	jal	8000350e <filealloc>
    800038f2:	00aa3023          	sd	a0,0(s4)
    800038f6:	cd25                	beqz	a0,8000396e <pipealloc+0xa0>
    800038f8:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800038fa:	80bfc0ef          	jal	80000104 <kalloc>
    800038fe:	892a                	mv	s2,a0
    80003900:	c12d                	beqz	a0,80003962 <pipealloc+0x94>
    80003902:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80003904:	4985                	li	s3,1
    80003906:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000390a:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000390e:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80003912:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80003916:	00004597          	auipc	a1,0x4
    8000391a:	c5a58593          	addi	a1,a1,-934 # 80007570 <etext+0x570>
    8000391e:	364020ef          	jal	80005c82 <initlock>
  (*f0)->type = FD_PIPE;
    80003922:	609c                	ld	a5,0(s1)
    80003924:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80003928:	609c                	ld	a5,0(s1)
    8000392a:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000392e:	609c                	ld	a5,0(s1)
    80003930:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80003934:	609c                	ld	a5,0(s1)
    80003936:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    8000393a:	000a3783          	ld	a5,0(s4)
    8000393e:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80003942:	000a3783          	ld	a5,0(s4)
    80003946:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    8000394a:	000a3783          	ld	a5,0(s4)
    8000394e:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80003952:	000a3783          	ld	a5,0(s4)
    80003956:	0127b823          	sd	s2,16(a5)
  return 0;
    8000395a:	4501                	li	a0,0
    8000395c:	6942                	ld	s2,16(sp)
    8000395e:	69a2                	ld	s3,8(sp)
    80003960:	a01d                	j	80003986 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80003962:	6088                	ld	a0,0(s1)
    80003964:	c119                	beqz	a0,8000396a <pipealloc+0x9c>
    80003966:	6942                	ld	s2,16(sp)
    80003968:	a029                	j	80003972 <pipealloc+0xa4>
    8000396a:	6942                	ld	s2,16(sp)
    8000396c:	a029                	j	80003976 <pipealloc+0xa8>
    8000396e:	6088                	ld	a0,0(s1)
    80003970:	c10d                	beqz	a0,80003992 <pipealloc+0xc4>
    fileclose(*f0);
    80003972:	c41ff0ef          	jal	800035b2 <fileclose>
  if(*f1)
    80003976:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    8000397a:	557d                	li	a0,-1
  if(*f1)
    8000397c:	c789                	beqz	a5,80003986 <pipealloc+0xb8>
    fileclose(*f1);
    8000397e:	853e                	mv	a0,a5
    80003980:	c33ff0ef          	jal	800035b2 <fileclose>
  return -1;
    80003984:	557d                	li	a0,-1
}
    80003986:	70a2                	ld	ra,40(sp)
    80003988:	7402                	ld	s0,32(sp)
    8000398a:	64e2                	ld	s1,24(sp)
    8000398c:	6a02                	ld	s4,0(sp)
    8000398e:	6145                	addi	sp,sp,48
    80003990:	8082                	ret
  return -1;
    80003992:	557d                	li	a0,-1
    80003994:	bfcd                	j	80003986 <pipealloc+0xb8>

0000000080003996 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80003996:	1101                	addi	sp,sp,-32
    80003998:	ec06                	sd	ra,24(sp)
    8000399a:	e822                	sd	s0,16(sp)
    8000399c:	e426                	sd	s1,8(sp)
    8000399e:	e04a                	sd	s2,0(sp)
    800039a0:	1000                	addi	s0,sp,32
    800039a2:	84aa                	mv	s1,a0
    800039a4:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800039a6:	366020ef          	jal	80005d0c <acquire>
  if(writable){
    800039aa:	02090763          	beqz	s2,800039d8 <pipeclose+0x42>
    pi->writeopen = 0;
    800039ae:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800039b2:	21848513          	addi	a0,s1,536
    800039b6:	a49fd0ef          	jal	800013fe <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800039ba:	2204a783          	lw	a5,544(s1)
    800039be:	e781                	bnez	a5,800039c6 <pipeclose+0x30>
    800039c0:	2244a783          	lw	a5,548(s1)
    800039c4:	c38d                	beqz	a5,800039e6 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    800039c6:	8526                	mv	a0,s1
    800039c8:	3d8020ef          	jal	80005da0 <release>
}
    800039cc:	60e2                	ld	ra,24(sp)
    800039ce:	6442                	ld	s0,16(sp)
    800039d0:	64a2                	ld	s1,8(sp)
    800039d2:	6902                	ld	s2,0(sp)
    800039d4:	6105                	addi	sp,sp,32
    800039d6:	8082                	ret
    pi->readopen = 0;
    800039d8:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800039dc:	21c48513          	addi	a0,s1,540
    800039e0:	a1ffd0ef          	jal	800013fe <wakeup>
    800039e4:	bfd9                	j	800039ba <pipeclose+0x24>
    release(&pi->lock);
    800039e6:	8526                	mv	a0,s1
    800039e8:	3b8020ef          	jal	80005da0 <release>
    kfree((char*)pi);
    800039ec:	8526                	mv	a0,s1
    800039ee:	e2efc0ef          	jal	8000001c <kfree>
    800039f2:	bfe9                	j	800039cc <pipeclose+0x36>

00000000800039f4 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800039f4:	7159                	addi	sp,sp,-112
    800039f6:	f486                	sd	ra,104(sp)
    800039f8:	f0a2                	sd	s0,96(sp)
    800039fa:	eca6                	sd	s1,88(sp)
    800039fc:	e8ca                	sd	s2,80(sp)
    800039fe:	e4ce                	sd	s3,72(sp)
    80003a00:	e0d2                	sd	s4,64(sp)
    80003a02:	fc56                	sd	s5,56(sp)
    80003a04:	1880                	addi	s0,sp,112
    80003a06:	84aa                	mv	s1,a0
    80003a08:	8aae                	mv	s5,a1
    80003a0a:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80003a0c:	b58fd0ef          	jal	80000d64 <myproc>
    80003a10:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80003a12:	8526                	mv	a0,s1
    80003a14:	2f8020ef          	jal	80005d0c <acquire>
  while(i < n){
    80003a18:	0d405263          	blez	s4,80003adc <pipewrite+0xe8>
    80003a1c:	f85a                	sd	s6,48(sp)
    80003a1e:	f45e                	sd	s7,40(sp)
    80003a20:	f062                	sd	s8,32(sp)
    80003a22:	ec66                	sd	s9,24(sp)
    80003a24:	e86a                	sd	s10,16(sp)
  int i = 0;
    80003a26:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003a28:	f9f40c13          	addi	s8,s0,-97
    80003a2c:	4b85                	li	s7,1
    80003a2e:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80003a30:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80003a34:	21c48c93          	addi	s9,s1,540
    80003a38:	a82d                	j	80003a72 <pipewrite+0x7e>
      release(&pi->lock);
    80003a3a:	8526                	mv	a0,s1
    80003a3c:	364020ef          	jal	80005da0 <release>
      return -1;
    80003a40:	597d                	li	s2,-1
    80003a42:	7b42                	ld	s6,48(sp)
    80003a44:	7ba2                	ld	s7,40(sp)
    80003a46:	7c02                	ld	s8,32(sp)
    80003a48:	6ce2                	ld	s9,24(sp)
    80003a4a:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80003a4c:	854a                	mv	a0,s2
    80003a4e:	70a6                	ld	ra,104(sp)
    80003a50:	7406                	ld	s0,96(sp)
    80003a52:	64e6                	ld	s1,88(sp)
    80003a54:	6946                	ld	s2,80(sp)
    80003a56:	69a6                	ld	s3,72(sp)
    80003a58:	6a06                	ld	s4,64(sp)
    80003a5a:	7ae2                	ld	s5,56(sp)
    80003a5c:	6165                	addi	sp,sp,112
    80003a5e:	8082                	ret
      wakeup(&pi->nread);
    80003a60:	856a                	mv	a0,s10
    80003a62:	99dfd0ef          	jal	800013fe <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80003a66:	85a6                	mv	a1,s1
    80003a68:	8566                	mv	a0,s9
    80003a6a:	949fd0ef          	jal	800013b2 <sleep>
  while(i < n){
    80003a6e:	05495a63          	bge	s2,s4,80003ac2 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80003a72:	2204a783          	lw	a5,544(s1)
    80003a76:	d3f1                	beqz	a5,80003a3a <pipewrite+0x46>
    80003a78:	854e                	mv	a0,s3
    80003a7a:	c7dfd0ef          	jal	800016f6 <killed>
    80003a7e:	fd55                	bnez	a0,80003a3a <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80003a80:	2184a783          	lw	a5,536(s1)
    80003a84:	21c4a703          	lw	a4,540(s1)
    80003a88:	2007879b          	addiw	a5,a5,512
    80003a8c:	fcf70ae3          	beq	a4,a5,80003a60 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003a90:	86de                	mv	a3,s7
    80003a92:	01590633          	add	a2,s2,s5
    80003a96:	85e2                	mv	a1,s8
    80003a98:	0509b503          	ld	a0,80(s3)
    80003a9c:	800fd0ef          	jal	80000a9c <copyin>
    80003aa0:	05650063          	beq	a0,s6,80003ae0 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80003aa4:	21c4a783          	lw	a5,540(s1)
    80003aa8:	0017871b          	addiw	a4,a5,1
    80003aac:	20e4ae23          	sw	a4,540(s1)
    80003ab0:	1ff7f793          	andi	a5,a5,511
    80003ab4:	97a6                	add	a5,a5,s1
    80003ab6:	f9f44703          	lbu	a4,-97(s0)
    80003aba:	00e78c23          	sb	a4,24(a5)
      i++;
    80003abe:	2905                	addiw	s2,s2,1
    80003ac0:	b77d                	j	80003a6e <pipewrite+0x7a>
    80003ac2:	7b42                	ld	s6,48(sp)
    80003ac4:	7ba2                	ld	s7,40(sp)
    80003ac6:	7c02                	ld	s8,32(sp)
    80003ac8:	6ce2                	ld	s9,24(sp)
    80003aca:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80003acc:	21848513          	addi	a0,s1,536
    80003ad0:	92ffd0ef          	jal	800013fe <wakeup>
  release(&pi->lock);
    80003ad4:	8526                	mv	a0,s1
    80003ad6:	2ca020ef          	jal	80005da0 <release>
  return i;
    80003ada:	bf8d                	j	80003a4c <pipewrite+0x58>
  int i = 0;
    80003adc:	4901                	li	s2,0
    80003ade:	b7fd                	j	80003acc <pipewrite+0xd8>
    80003ae0:	7b42                	ld	s6,48(sp)
    80003ae2:	7ba2                	ld	s7,40(sp)
    80003ae4:	7c02                	ld	s8,32(sp)
    80003ae6:	6ce2                	ld	s9,24(sp)
    80003ae8:	6d42                	ld	s10,16(sp)
    80003aea:	b7cd                	j	80003acc <pipewrite+0xd8>

0000000080003aec <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80003aec:	711d                	addi	sp,sp,-96
    80003aee:	ec86                	sd	ra,88(sp)
    80003af0:	e8a2                	sd	s0,80(sp)
    80003af2:	e4a6                	sd	s1,72(sp)
    80003af4:	e0ca                	sd	s2,64(sp)
    80003af6:	fc4e                	sd	s3,56(sp)
    80003af8:	f852                	sd	s4,48(sp)
    80003afa:	f456                	sd	s5,40(sp)
    80003afc:	1080                	addi	s0,sp,96
    80003afe:	84aa                	mv	s1,a0
    80003b00:	892e                	mv	s2,a1
    80003b02:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80003b04:	a60fd0ef          	jal	80000d64 <myproc>
    80003b08:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80003b0a:	8526                	mv	a0,s1
    80003b0c:	200020ef          	jal	80005d0c <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003b10:	2184a703          	lw	a4,536(s1)
    80003b14:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003b18:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003b1c:	02f71763          	bne	a4,a5,80003b4a <piperead+0x5e>
    80003b20:	2244a783          	lw	a5,548(s1)
    80003b24:	cf85                	beqz	a5,80003b5c <piperead+0x70>
    if(killed(pr)){
    80003b26:	8552                	mv	a0,s4
    80003b28:	bcffd0ef          	jal	800016f6 <killed>
    80003b2c:	e11d                	bnez	a0,80003b52 <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003b2e:	85a6                	mv	a1,s1
    80003b30:	854e                	mv	a0,s3
    80003b32:	881fd0ef          	jal	800013b2 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003b36:	2184a703          	lw	a4,536(s1)
    80003b3a:	21c4a783          	lw	a5,540(s1)
    80003b3e:	fef701e3          	beq	a4,a5,80003b20 <piperead+0x34>
    80003b42:	f05a                	sd	s6,32(sp)
    80003b44:	ec5e                	sd	s7,24(sp)
    80003b46:	e862                	sd	s8,16(sp)
    80003b48:	a829                	j	80003b62 <piperead+0x76>
    80003b4a:	f05a                	sd	s6,32(sp)
    80003b4c:	ec5e                	sd	s7,24(sp)
    80003b4e:	e862                	sd	s8,16(sp)
    80003b50:	a809                	j	80003b62 <piperead+0x76>
      release(&pi->lock);
    80003b52:	8526                	mv	a0,s1
    80003b54:	24c020ef          	jal	80005da0 <release>
      return -1;
    80003b58:	59fd                	li	s3,-1
    80003b5a:	a09d                	j	80003bc0 <piperead+0xd4>
    80003b5c:	f05a                	sd	s6,32(sp)
    80003b5e:	ec5e                	sd	s7,24(sp)
    80003b60:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003b62:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003b64:	faf40c13          	addi	s8,s0,-81
    80003b68:	4b85                	li	s7,1
    80003b6a:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003b6c:	05505063          	blez	s5,80003bac <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    80003b70:	2184a783          	lw	a5,536(s1)
    80003b74:	21c4a703          	lw	a4,540(s1)
    80003b78:	02f70a63          	beq	a4,a5,80003bac <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003b7c:	0017871b          	addiw	a4,a5,1
    80003b80:	20e4ac23          	sw	a4,536(s1)
    80003b84:	1ff7f793          	andi	a5,a5,511
    80003b88:	97a6                	add	a5,a5,s1
    80003b8a:	0187c783          	lbu	a5,24(a5)
    80003b8e:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003b92:	86de                	mv	a3,s7
    80003b94:	8662                	mv	a2,s8
    80003b96:	85ca                	mv	a1,s2
    80003b98:	050a3503          	ld	a0,80(s4)
    80003b9c:	e51fc0ef          	jal	800009ec <copyout>
    80003ba0:	01650663          	beq	a0,s6,80003bac <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003ba4:	2985                	addiw	s3,s3,1
    80003ba6:	0905                	addi	s2,s2,1
    80003ba8:	fd3a94e3          	bne	s5,s3,80003b70 <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003bac:	21c48513          	addi	a0,s1,540
    80003bb0:	84ffd0ef          	jal	800013fe <wakeup>
  release(&pi->lock);
    80003bb4:	8526                	mv	a0,s1
    80003bb6:	1ea020ef          	jal	80005da0 <release>
    80003bba:	7b02                	ld	s6,32(sp)
    80003bbc:	6be2                	ld	s7,24(sp)
    80003bbe:	6c42                	ld	s8,16(sp)
  return i;
}
    80003bc0:	854e                	mv	a0,s3
    80003bc2:	60e6                	ld	ra,88(sp)
    80003bc4:	6446                	ld	s0,80(sp)
    80003bc6:	64a6                	ld	s1,72(sp)
    80003bc8:	6906                	ld	s2,64(sp)
    80003bca:	79e2                	ld	s3,56(sp)
    80003bcc:	7a42                	ld	s4,48(sp)
    80003bce:	7aa2                	ld	s5,40(sp)
    80003bd0:	6125                	addi	sp,sp,96
    80003bd2:	8082                	ret

0000000080003bd4 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003bd4:	1141                	addi	sp,sp,-16
    80003bd6:	e406                	sd	ra,8(sp)
    80003bd8:	e022                	sd	s0,0(sp)
    80003bda:	0800                	addi	s0,sp,16
    80003bdc:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003bde:	0035151b          	slliw	a0,a0,0x3
    80003be2:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80003be4:	8b89                	andi	a5,a5,2
    80003be6:	c399                	beqz	a5,80003bec <flags2perm+0x18>
      perm |= PTE_W;
    80003be8:	00456513          	ori	a0,a0,4
    return perm;
}
    80003bec:	60a2                	ld	ra,8(sp)
    80003bee:	6402                	ld	s0,0(sp)
    80003bf0:	0141                	addi	sp,sp,16
    80003bf2:	8082                	ret

0000000080003bf4 <exec>:

int
exec(char *path, char **argv)
{
    80003bf4:	de010113          	addi	sp,sp,-544
    80003bf8:	20113c23          	sd	ra,536(sp)
    80003bfc:	20813823          	sd	s0,528(sp)
    80003c00:	20913423          	sd	s1,520(sp)
    80003c04:	21213023          	sd	s2,512(sp)
    80003c08:	1400                	addi	s0,sp,544
    80003c0a:	892a                	mv	s2,a0
    80003c0c:	dea43823          	sd	a0,-528(s0)
    80003c10:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80003c14:	950fd0ef          	jal	80000d64 <myproc>
    80003c18:	84aa                	mv	s1,a0

  begin_op();
    80003c1a:	d66ff0ef          	jal	80003180 <begin_op>

  if((ip = namei(path)) == 0){
    80003c1e:	854a                	mv	a0,s2
    80003c20:	b9eff0ef          	jal	80002fbe <namei>
    80003c24:	cd21                	beqz	a0,80003c7c <exec+0x88>
    80003c26:	fbd2                	sd	s4,496(sp)
    80003c28:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80003c2a:	c9ffe0ef          	jal	800028c8 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80003c2e:	04000713          	li	a4,64
    80003c32:	4681                	li	a3,0
    80003c34:	e5040613          	addi	a2,s0,-432
    80003c38:	4581                	li	a1,0
    80003c3a:	8552                	mv	a0,s4
    80003c3c:	ee7fe0ef          	jal	80002b22 <readi>
    80003c40:	04000793          	li	a5,64
    80003c44:	00f51a63          	bne	a0,a5,80003c58 <exec+0x64>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80003c48:	e5042703          	lw	a4,-432(s0)
    80003c4c:	464c47b7          	lui	a5,0x464c4
    80003c50:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003c54:	02f70863          	beq	a4,a5,80003c84 <exec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003c58:	8552                	mv	a0,s4
    80003c5a:	e7bfe0ef          	jal	80002ad4 <iunlockput>
    end_op();
    80003c5e:	d92ff0ef          	jal	800031f0 <end_op>
  }
  return -1;
    80003c62:	557d                	li	a0,-1
    80003c64:	7a5e                	ld	s4,496(sp)
}
    80003c66:	21813083          	ld	ra,536(sp)
    80003c6a:	21013403          	ld	s0,528(sp)
    80003c6e:	20813483          	ld	s1,520(sp)
    80003c72:	20013903          	ld	s2,512(sp)
    80003c76:	22010113          	addi	sp,sp,544
    80003c7a:	8082                	ret
    end_op();
    80003c7c:	d74ff0ef          	jal	800031f0 <end_op>
    return -1;
    80003c80:	557d                	li	a0,-1
    80003c82:	b7d5                	j	80003c66 <exec+0x72>
    80003c84:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80003c86:	8526                	mv	a0,s1
    80003c88:	986fd0ef          	jal	80000e0e <proc_pagetable>
    80003c8c:	8b2a                	mv	s6,a0
    80003c8e:	26050f63          	beqz	a0,80003f0c <exec+0x318>
    80003c92:	ffce                	sd	s3,504(sp)
    80003c94:	f7d6                	sd	s5,488(sp)
    80003c96:	efde                	sd	s7,472(sp)
    80003c98:	ebe2                	sd	s8,464(sp)
    80003c9a:	e7e6                	sd	s9,456(sp)
    80003c9c:	e3ea                	sd	s10,448(sp)
    80003c9e:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003ca0:	e8845783          	lhu	a5,-376(s0)
    80003ca4:	0e078963          	beqz	a5,80003d96 <exec+0x1a2>
    80003ca8:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003cac:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003cae:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003cb0:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80003cb4:	6c85                	lui	s9,0x1
    80003cb6:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80003cba:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80003cbe:	6a85                	lui	s5,0x1
    80003cc0:	a085                	j	80003d20 <exec+0x12c>
      panic("loadseg: address should exist");
    80003cc2:	00004517          	auipc	a0,0x4
    80003cc6:	8b650513          	addi	a0,a0,-1866 # 80007578 <etext+0x578>
    80003cca:	505010ef          	jal	800059ce <panic>
    if(sz - i < PGSIZE)
    80003cce:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003cd0:	874a                	mv	a4,s2
    80003cd2:	009b86bb          	addw	a3,s7,s1
    80003cd6:	4581                	li	a1,0
    80003cd8:	8552                	mv	a0,s4
    80003cda:	e49fe0ef          	jal	80002b22 <readi>
    80003cde:	22a91b63          	bne	s2,a0,80003f14 <exec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    80003ce2:	009a84bb          	addw	s1,s5,s1
    80003ce6:	0334f263          	bgeu	s1,s3,80003d0a <exec+0x116>
    pa = walkaddr(pagetable, va + i);
    80003cea:	02049593          	slli	a1,s1,0x20
    80003cee:	9181                	srli	a1,a1,0x20
    80003cf0:	95e2                	add	a1,a1,s8
    80003cf2:	855a                	mv	a0,s6
    80003cf4:	f98fc0ef          	jal	8000048c <walkaddr>
    80003cf8:	862a                	mv	a2,a0
    if(pa == 0)
    80003cfa:	d561                	beqz	a0,80003cc2 <exec+0xce>
    if(sz - i < PGSIZE)
    80003cfc:	409987bb          	subw	a5,s3,s1
    80003d00:	893e                	mv	s2,a5
    80003d02:	fcfcf6e3          	bgeu	s9,a5,80003cce <exec+0xda>
    80003d06:	8956                	mv	s2,s5
    80003d08:	b7d9                	j	80003cce <exec+0xda>
    sz = sz1;
    80003d0a:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003d0e:	2d05                	addiw	s10,s10,1
    80003d10:	e0843783          	ld	a5,-504(s0)
    80003d14:	0387869b          	addiw	a3,a5,56
    80003d18:	e8845783          	lhu	a5,-376(s0)
    80003d1c:	06fd5e63          	bge	s10,a5,80003d98 <exec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003d20:	e0d43423          	sd	a3,-504(s0)
    80003d24:	876e                	mv	a4,s11
    80003d26:	e1840613          	addi	a2,s0,-488
    80003d2a:	4581                	li	a1,0
    80003d2c:	8552                	mv	a0,s4
    80003d2e:	df5fe0ef          	jal	80002b22 <readi>
    80003d32:	1db51f63          	bne	a0,s11,80003f10 <exec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80003d36:	e1842783          	lw	a5,-488(s0)
    80003d3a:	4705                	li	a4,1
    80003d3c:	fce799e3          	bne	a5,a4,80003d0e <exec+0x11a>
    if(ph.memsz < ph.filesz)
    80003d40:	e4043483          	ld	s1,-448(s0)
    80003d44:	e3843783          	ld	a5,-456(s0)
    80003d48:	1ef4e463          	bltu	s1,a5,80003f30 <exec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003d4c:	e2843783          	ld	a5,-472(s0)
    80003d50:	94be                	add	s1,s1,a5
    80003d52:	1ef4e263          	bltu	s1,a5,80003f36 <exec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80003d56:	de843703          	ld	a4,-536(s0)
    80003d5a:	8ff9                	and	a5,a5,a4
    80003d5c:	1e079063          	bnez	a5,80003f3c <exec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003d60:	e1c42503          	lw	a0,-484(s0)
    80003d64:	e71ff0ef          	jal	80003bd4 <flags2perm>
    80003d68:	86aa                	mv	a3,a0
    80003d6a:	8626                	mv	a2,s1
    80003d6c:	85ca                	mv	a1,s2
    80003d6e:	855a                	mv	a0,s6
    80003d70:	a6dfc0ef          	jal	800007dc <uvmalloc>
    80003d74:	dea43c23          	sd	a0,-520(s0)
    80003d78:	1c050563          	beqz	a0,80003f42 <exec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003d7c:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003d80:	00098863          	beqz	s3,80003d90 <exec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003d84:	e2843c03          	ld	s8,-472(s0)
    80003d88:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003d8c:	4481                	li	s1,0
    80003d8e:	bfb1                	j	80003cea <exec+0xf6>
    sz = sz1;
    80003d90:	df843903          	ld	s2,-520(s0)
    80003d94:	bfad                	j	80003d0e <exec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003d96:	4901                	li	s2,0
  iunlockput(ip);
    80003d98:	8552                	mv	a0,s4
    80003d9a:	d3bfe0ef          	jal	80002ad4 <iunlockput>
  end_op();
    80003d9e:	c52ff0ef          	jal	800031f0 <end_op>
  p = myproc();
    80003da2:	fc3fc0ef          	jal	80000d64 <myproc>
    80003da6:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80003da8:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003dac:	6985                	lui	s3,0x1
    80003dae:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80003db0:	99ca                	add	s3,s3,s2
    80003db2:	77fd                	lui	a5,0xfffff
    80003db4:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003db8:	4691                	li	a3,4
    80003dba:	6609                	lui	a2,0x2
    80003dbc:	964e                	add	a2,a2,s3
    80003dbe:	85ce                	mv	a1,s3
    80003dc0:	855a                	mv	a0,s6
    80003dc2:	a1bfc0ef          	jal	800007dc <uvmalloc>
    80003dc6:	8a2a                	mv	s4,a0
    80003dc8:	e105                	bnez	a0,80003de8 <exec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80003dca:	85ce                	mv	a1,s3
    80003dcc:	855a                	mv	a0,s6
    80003dce:	8c4fd0ef          	jal	80000e92 <proc_freepagetable>
  return -1;
    80003dd2:	557d                	li	a0,-1
    80003dd4:	79fe                	ld	s3,504(sp)
    80003dd6:	7a5e                	ld	s4,496(sp)
    80003dd8:	7abe                	ld	s5,488(sp)
    80003dda:	7b1e                	ld	s6,480(sp)
    80003ddc:	6bfe                	ld	s7,472(sp)
    80003dde:	6c5e                	ld	s8,464(sp)
    80003de0:	6cbe                	ld	s9,456(sp)
    80003de2:	6d1e                	ld	s10,448(sp)
    80003de4:	7dfa                	ld	s11,440(sp)
    80003de6:	b541                	j	80003c66 <exec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003de8:	75f9                	lui	a1,0xffffe
    80003dea:	95aa                	add	a1,a1,a0
    80003dec:	855a                	mv	a0,s6
    80003dee:	bd5fc0ef          	jal	800009c2 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003df2:	800a0b93          	addi	s7,s4,-2048
    80003df6:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80003dfa:	e0043783          	ld	a5,-512(s0)
    80003dfe:	6388                	ld	a0,0(a5)
  sp = sz;
    80003e00:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80003e02:	4481                	li	s1,0
    ustack[argc] = sp;
    80003e04:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80003e08:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80003e0c:	cd21                	beqz	a0,80003e64 <exec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80003e0e:	cdafc0ef          	jal	800002e8 <strlen>
    80003e12:	0015079b          	addiw	a5,a0,1
    80003e16:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003e1a:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80003e1e:	13796563          	bltu	s2,s7,80003f48 <exec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003e22:	e0043d83          	ld	s11,-512(s0)
    80003e26:	000db983          	ld	s3,0(s11)
    80003e2a:	854e                	mv	a0,s3
    80003e2c:	cbcfc0ef          	jal	800002e8 <strlen>
    80003e30:	0015069b          	addiw	a3,a0,1
    80003e34:	864e                	mv	a2,s3
    80003e36:	85ca                	mv	a1,s2
    80003e38:	855a                	mv	a0,s6
    80003e3a:	bb3fc0ef          	jal	800009ec <copyout>
    80003e3e:	10054763          	bltz	a0,80003f4c <exec+0x358>
    ustack[argc] = sp;
    80003e42:	00349793          	slli	a5,s1,0x3
    80003e46:	97e6                	add	a5,a5,s9
    80003e48:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffd23d0>
  for(argc = 0; argv[argc]; argc++) {
    80003e4c:	0485                	addi	s1,s1,1
    80003e4e:	008d8793          	addi	a5,s11,8
    80003e52:	e0f43023          	sd	a5,-512(s0)
    80003e56:	008db503          	ld	a0,8(s11)
    80003e5a:	c509                	beqz	a0,80003e64 <exec+0x270>
    if(argc >= MAXARG)
    80003e5c:	fb8499e3          	bne	s1,s8,80003e0e <exec+0x21a>
  sz = sz1;
    80003e60:	89d2                	mv	s3,s4
    80003e62:	b7a5                	j	80003dca <exec+0x1d6>
  ustack[argc] = 0;
    80003e64:	00349793          	slli	a5,s1,0x3
    80003e68:	f9078793          	addi	a5,a5,-112
    80003e6c:	97a2                	add	a5,a5,s0
    80003e6e:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80003e72:	00349693          	slli	a3,s1,0x3
    80003e76:	06a1                	addi	a3,a3,8
    80003e78:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003e7c:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80003e80:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80003e82:	f57964e3          	bltu	s2,s7,80003dca <exec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003e86:	e9040613          	addi	a2,s0,-368
    80003e8a:	85ca                	mv	a1,s2
    80003e8c:	855a                	mv	a0,s6
    80003e8e:	b5ffc0ef          	jal	800009ec <copyout>
    80003e92:	f2054ce3          	bltz	a0,80003dca <exec+0x1d6>
  p->trapframe->a1 = sp;
    80003e96:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80003e9a:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003e9e:	df043783          	ld	a5,-528(s0)
    80003ea2:	0007c703          	lbu	a4,0(a5)
    80003ea6:	cf11                	beqz	a4,80003ec2 <exec+0x2ce>
    80003ea8:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003eaa:	02f00693          	li	a3,47
    80003eae:	a029                	j	80003eb8 <exec+0x2c4>
  for(last=s=path; *s; s++)
    80003eb0:	0785                	addi	a5,a5,1
    80003eb2:	fff7c703          	lbu	a4,-1(a5)
    80003eb6:	c711                	beqz	a4,80003ec2 <exec+0x2ce>
    if(*s == '/')
    80003eb8:	fed71ce3          	bne	a4,a3,80003eb0 <exec+0x2bc>
      last = s+1;
    80003ebc:	def43823          	sd	a5,-528(s0)
    80003ec0:	bfc5                	j	80003eb0 <exec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80003ec2:	4641                	li	a2,16
    80003ec4:	df043583          	ld	a1,-528(s0)
    80003ec8:	158a8513          	addi	a0,s5,344
    80003ecc:	be6fc0ef          	jal	800002b2 <safestrcpy>
  oldpagetable = p->pagetable;
    80003ed0:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80003ed4:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80003ed8:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003edc:	058ab783          	ld	a5,88(s5)
    80003ee0:	e6843703          	ld	a4,-408(s0)
    80003ee4:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003ee6:	058ab783          	ld	a5,88(s5)
    80003eea:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003eee:	85ea                	mv	a1,s10
    80003ef0:	fa3fc0ef          	jal	80000e92 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003ef4:	0004851b          	sext.w	a0,s1
    80003ef8:	79fe                	ld	s3,504(sp)
    80003efa:	7a5e                	ld	s4,496(sp)
    80003efc:	7abe                	ld	s5,488(sp)
    80003efe:	7b1e                	ld	s6,480(sp)
    80003f00:	6bfe                	ld	s7,472(sp)
    80003f02:	6c5e                	ld	s8,464(sp)
    80003f04:	6cbe                	ld	s9,456(sp)
    80003f06:	6d1e                	ld	s10,448(sp)
    80003f08:	7dfa                	ld	s11,440(sp)
    80003f0a:	bbb1                	j	80003c66 <exec+0x72>
    80003f0c:	7b1e                	ld	s6,480(sp)
    80003f0e:	b3a9                	j	80003c58 <exec+0x64>
    80003f10:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003f14:	df843583          	ld	a1,-520(s0)
    80003f18:	855a                	mv	a0,s6
    80003f1a:	f79fc0ef          	jal	80000e92 <proc_freepagetable>
  if(ip){
    80003f1e:	79fe                	ld	s3,504(sp)
    80003f20:	7abe                	ld	s5,488(sp)
    80003f22:	7b1e                	ld	s6,480(sp)
    80003f24:	6bfe                	ld	s7,472(sp)
    80003f26:	6c5e                	ld	s8,464(sp)
    80003f28:	6cbe                	ld	s9,456(sp)
    80003f2a:	6d1e                	ld	s10,448(sp)
    80003f2c:	7dfa                	ld	s11,440(sp)
    80003f2e:	b32d                	j	80003c58 <exec+0x64>
    80003f30:	df243c23          	sd	s2,-520(s0)
    80003f34:	b7c5                	j	80003f14 <exec+0x320>
    80003f36:	df243c23          	sd	s2,-520(s0)
    80003f3a:	bfe9                	j	80003f14 <exec+0x320>
    80003f3c:	df243c23          	sd	s2,-520(s0)
    80003f40:	bfd1                	j	80003f14 <exec+0x320>
    80003f42:	df243c23          	sd	s2,-520(s0)
    80003f46:	b7f9                	j	80003f14 <exec+0x320>
  sz = sz1;
    80003f48:	89d2                	mv	s3,s4
    80003f4a:	b541                	j	80003dca <exec+0x1d6>
    80003f4c:	89d2                	mv	s3,s4
    80003f4e:	bdb5                	j	80003dca <exec+0x1d6>

0000000080003f50 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003f50:	7179                	addi	sp,sp,-48
    80003f52:	f406                	sd	ra,40(sp)
    80003f54:	f022                	sd	s0,32(sp)
    80003f56:	ec26                	sd	s1,24(sp)
    80003f58:	e84a                	sd	s2,16(sp)
    80003f5a:	1800                	addi	s0,sp,48
    80003f5c:	892e                	mv	s2,a1
    80003f5e:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003f60:	fdc40593          	addi	a1,s0,-36
    80003f64:	f6ffd0ef          	jal	80001ed2 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003f68:	fdc42703          	lw	a4,-36(s0)
    80003f6c:	47bd                	li	a5,15
    80003f6e:	02e7ea63          	bltu	a5,a4,80003fa2 <argfd+0x52>
    80003f72:	df3fc0ef          	jal	80000d64 <myproc>
    80003f76:	fdc42703          	lw	a4,-36(s0)
    80003f7a:	00371793          	slli	a5,a4,0x3
    80003f7e:	0d078793          	addi	a5,a5,208
    80003f82:	953e                	add	a0,a0,a5
    80003f84:	611c                	ld	a5,0(a0)
    80003f86:	c385                	beqz	a5,80003fa6 <argfd+0x56>
    return -1;
  if(pfd)
    80003f88:	00090463          	beqz	s2,80003f90 <argfd+0x40>
    *pfd = fd;
    80003f8c:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003f90:	4501                	li	a0,0
  if(pf)
    80003f92:	c091                	beqz	s1,80003f96 <argfd+0x46>
    *pf = f;
    80003f94:	e09c                	sd	a5,0(s1)
}
    80003f96:	70a2                	ld	ra,40(sp)
    80003f98:	7402                	ld	s0,32(sp)
    80003f9a:	64e2                	ld	s1,24(sp)
    80003f9c:	6942                	ld	s2,16(sp)
    80003f9e:	6145                	addi	sp,sp,48
    80003fa0:	8082                	ret
    return -1;
    80003fa2:	557d                	li	a0,-1
    80003fa4:	bfcd                	j	80003f96 <argfd+0x46>
    80003fa6:	557d                	li	a0,-1
    80003fa8:	b7fd                	j	80003f96 <argfd+0x46>

0000000080003faa <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003faa:	1101                	addi	sp,sp,-32
    80003fac:	ec06                	sd	ra,24(sp)
    80003fae:	e822                	sd	s0,16(sp)
    80003fb0:	e426                	sd	s1,8(sp)
    80003fb2:	1000                	addi	s0,sp,32
    80003fb4:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003fb6:	daffc0ef          	jal	80000d64 <myproc>
    80003fba:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003fbc:	0d050793          	addi	a5,a0,208
    80003fc0:	4501                	li	a0,0
    80003fc2:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003fc4:	6398                	ld	a4,0(a5)
    80003fc6:	cb19                	beqz	a4,80003fdc <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003fc8:	2505                	addiw	a0,a0,1
    80003fca:	07a1                	addi	a5,a5,8
    80003fcc:	fed51ce3          	bne	a0,a3,80003fc4 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003fd0:	557d                	li	a0,-1
}
    80003fd2:	60e2                	ld	ra,24(sp)
    80003fd4:	6442                	ld	s0,16(sp)
    80003fd6:	64a2                	ld	s1,8(sp)
    80003fd8:	6105                	addi	sp,sp,32
    80003fda:	8082                	ret
      p->ofile[fd] = f;
    80003fdc:	00351793          	slli	a5,a0,0x3
    80003fe0:	0d078793          	addi	a5,a5,208
    80003fe4:	963e                	add	a2,a2,a5
    80003fe6:	e204                	sd	s1,0(a2)
      return fd;
    80003fe8:	b7ed                	j	80003fd2 <fdalloc+0x28>

0000000080003fea <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003fea:	715d                	addi	sp,sp,-80
    80003fec:	e486                	sd	ra,72(sp)
    80003fee:	e0a2                	sd	s0,64(sp)
    80003ff0:	fc26                	sd	s1,56(sp)
    80003ff2:	f84a                	sd	s2,48(sp)
    80003ff4:	f44e                	sd	s3,40(sp)
    80003ff6:	f052                	sd	s4,32(sp)
    80003ff8:	ec56                	sd	s5,24(sp)
    80003ffa:	e85a                	sd	s6,16(sp)
    80003ffc:	0880                	addi	s0,sp,80
    80003ffe:	892e                	mv	s2,a1
    80004000:	8a2e                	mv	s4,a1
    80004002:	8ab2                	mv	s5,a2
    80004004:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004006:	fb040593          	addi	a1,s0,-80
    8000400a:	fcffe0ef          	jal	80002fd8 <nameiparent>
    8000400e:	84aa                	mv	s1,a0
    80004010:	10050763          	beqz	a0,8000411e <create+0x134>
    return 0;

  ilock(dp);
    80004014:	8b5fe0ef          	jal	800028c8 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004018:	4601                	li	a2,0
    8000401a:	fb040593          	addi	a1,s0,-80
    8000401e:	8526                	mv	a0,s1
    80004020:	d0bfe0ef          	jal	80002d2a <dirlookup>
    80004024:	89aa                	mv	s3,a0
    80004026:	c131                	beqz	a0,8000406a <create+0x80>
    iunlockput(dp);
    80004028:	8526                	mv	a0,s1
    8000402a:	aabfe0ef          	jal	80002ad4 <iunlockput>
    ilock(ip);
    8000402e:	854e                	mv	a0,s3
    80004030:	899fe0ef          	jal	800028c8 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004034:	4789                	li	a5,2
    80004036:	02f91563          	bne	s2,a5,80004060 <create+0x76>
    8000403a:	0449d783          	lhu	a5,68(s3)
    8000403e:	37f9                	addiw	a5,a5,-2
    80004040:	17c2                	slli	a5,a5,0x30
    80004042:	93c1                	srli	a5,a5,0x30
    80004044:	4705                	li	a4,1
    80004046:	00f76d63          	bltu	a4,a5,80004060 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    8000404a:	854e                	mv	a0,s3
    8000404c:	60a6                	ld	ra,72(sp)
    8000404e:	6406                	ld	s0,64(sp)
    80004050:	74e2                	ld	s1,56(sp)
    80004052:	7942                	ld	s2,48(sp)
    80004054:	79a2                	ld	s3,40(sp)
    80004056:	7a02                	ld	s4,32(sp)
    80004058:	6ae2                	ld	s5,24(sp)
    8000405a:	6b42                	ld	s6,16(sp)
    8000405c:	6161                	addi	sp,sp,80
    8000405e:	8082                	ret
    iunlockput(ip);
    80004060:	854e                	mv	a0,s3
    80004062:	a73fe0ef          	jal	80002ad4 <iunlockput>
    return 0;
    80004066:	4981                	li	s3,0
    80004068:	b7cd                	j	8000404a <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    8000406a:	85ca                	mv	a1,s2
    8000406c:	4088                	lw	a0,0(s1)
    8000406e:	eeafe0ef          	jal	80002758 <ialloc>
    80004072:	892a                	mv	s2,a0
    80004074:	cd15                	beqz	a0,800040b0 <create+0xc6>
  ilock(ip);
    80004076:	853fe0ef          	jal	800028c8 <ilock>
  ip->major = major;
    8000407a:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    8000407e:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004082:	4785                	li	a5,1
    80004084:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004088:	854a                	mv	a0,s2
    8000408a:	f8afe0ef          	jal	80002814 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    8000408e:	4705                	li	a4,1
    80004090:	02ea0463          	beq	s4,a4,800040b8 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004094:	00492603          	lw	a2,4(s2)
    80004098:	fb040593          	addi	a1,s0,-80
    8000409c:	8526                	mv	a0,s1
    8000409e:	e77fe0ef          	jal	80002f14 <dirlink>
    800040a2:	06054263          	bltz	a0,80004106 <create+0x11c>
  iunlockput(dp);
    800040a6:	8526                	mv	a0,s1
    800040a8:	a2dfe0ef          	jal	80002ad4 <iunlockput>
  return ip;
    800040ac:	89ca                	mv	s3,s2
    800040ae:	bf71                	j	8000404a <create+0x60>
    iunlockput(dp);
    800040b0:	8526                	mv	a0,s1
    800040b2:	a23fe0ef          	jal	80002ad4 <iunlockput>
    return 0;
    800040b6:	bf51                	j	8000404a <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    800040b8:	00492603          	lw	a2,4(s2)
    800040bc:	00003597          	auipc	a1,0x3
    800040c0:	4dc58593          	addi	a1,a1,1244 # 80007598 <etext+0x598>
    800040c4:	854a                	mv	a0,s2
    800040c6:	e4ffe0ef          	jal	80002f14 <dirlink>
    800040ca:	02054e63          	bltz	a0,80004106 <create+0x11c>
    800040ce:	40d0                	lw	a2,4(s1)
    800040d0:	00003597          	auipc	a1,0x3
    800040d4:	4d058593          	addi	a1,a1,1232 # 800075a0 <etext+0x5a0>
    800040d8:	854a                	mv	a0,s2
    800040da:	e3bfe0ef          	jal	80002f14 <dirlink>
    800040de:	02054463          	bltz	a0,80004106 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    800040e2:	00492603          	lw	a2,4(s2)
    800040e6:	fb040593          	addi	a1,s0,-80
    800040ea:	8526                	mv	a0,s1
    800040ec:	e29fe0ef          	jal	80002f14 <dirlink>
    800040f0:	00054b63          	bltz	a0,80004106 <create+0x11c>
    dp->nlink++;  // for ".."
    800040f4:	04a4d783          	lhu	a5,74(s1)
    800040f8:	2785                	addiw	a5,a5,1
    800040fa:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800040fe:	8526                	mv	a0,s1
    80004100:	f14fe0ef          	jal	80002814 <iupdate>
    80004104:	b74d                	j	800040a6 <create+0xbc>
  ip->nlink = 0;
    80004106:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    8000410a:	854a                	mv	a0,s2
    8000410c:	f08fe0ef          	jal	80002814 <iupdate>
  iunlockput(ip);
    80004110:	854a                	mv	a0,s2
    80004112:	9c3fe0ef          	jal	80002ad4 <iunlockput>
  iunlockput(dp);
    80004116:	8526                	mv	a0,s1
    80004118:	9bdfe0ef          	jal	80002ad4 <iunlockput>
  return 0;
    8000411c:	b73d                	j	8000404a <create+0x60>
    return 0;
    8000411e:	89aa                	mv	s3,a0
    80004120:	b72d                	j	8000404a <create+0x60>

0000000080004122 <sys_dup>:
{
    80004122:	7179                	addi	sp,sp,-48
    80004124:	f406                	sd	ra,40(sp)
    80004126:	f022                	sd	s0,32(sp)
    80004128:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    8000412a:	fd840613          	addi	a2,s0,-40
    8000412e:	4581                	li	a1,0
    80004130:	4501                	li	a0,0
    80004132:	e1fff0ef          	jal	80003f50 <argfd>
    return -1;
    80004136:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004138:	02054363          	bltz	a0,8000415e <sys_dup+0x3c>
    8000413c:	ec26                	sd	s1,24(sp)
    8000413e:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004140:	fd843483          	ld	s1,-40(s0)
    80004144:	8526                	mv	a0,s1
    80004146:	e65ff0ef          	jal	80003faa <fdalloc>
    8000414a:	892a                	mv	s2,a0
    return -1;
    8000414c:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    8000414e:	00054d63          	bltz	a0,80004168 <sys_dup+0x46>
  filedup(f);
    80004152:	8526                	mv	a0,s1
    80004154:	c18ff0ef          	jal	8000356c <filedup>
  return fd;
    80004158:	87ca                	mv	a5,s2
    8000415a:	64e2                	ld	s1,24(sp)
    8000415c:	6942                	ld	s2,16(sp)
}
    8000415e:	853e                	mv	a0,a5
    80004160:	70a2                	ld	ra,40(sp)
    80004162:	7402                	ld	s0,32(sp)
    80004164:	6145                	addi	sp,sp,48
    80004166:	8082                	ret
    80004168:	64e2                	ld	s1,24(sp)
    8000416a:	6942                	ld	s2,16(sp)
    8000416c:	bfcd                	j	8000415e <sys_dup+0x3c>

000000008000416e <sys_read>:
{
    8000416e:	7179                	addi	sp,sp,-48
    80004170:	f406                	sd	ra,40(sp)
    80004172:	f022                	sd	s0,32(sp)
    80004174:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004176:	fd840593          	addi	a1,s0,-40
    8000417a:	4505                	li	a0,1
    8000417c:	d73fd0ef          	jal	80001eee <argaddr>
  argint(2, &n);
    80004180:	fe440593          	addi	a1,s0,-28
    80004184:	4509                	li	a0,2
    80004186:	d4dfd0ef          	jal	80001ed2 <argint>
  if(argfd(0, 0, &f) < 0)
    8000418a:	fe840613          	addi	a2,s0,-24
    8000418e:	4581                	li	a1,0
    80004190:	4501                	li	a0,0
    80004192:	dbfff0ef          	jal	80003f50 <argfd>
    80004196:	87aa                	mv	a5,a0
    return -1;
    80004198:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000419a:	0007ca63          	bltz	a5,800041ae <sys_read+0x40>
  return fileread(f, p, n);
    8000419e:	fe442603          	lw	a2,-28(s0)
    800041a2:	fd843583          	ld	a1,-40(s0)
    800041a6:	fe843503          	ld	a0,-24(s0)
    800041aa:	d2cff0ef          	jal	800036d6 <fileread>
}
    800041ae:	70a2                	ld	ra,40(sp)
    800041b0:	7402                	ld	s0,32(sp)
    800041b2:	6145                	addi	sp,sp,48
    800041b4:	8082                	ret

00000000800041b6 <sys_write>:
{
    800041b6:	7179                	addi	sp,sp,-48
    800041b8:	f406                	sd	ra,40(sp)
    800041ba:	f022                	sd	s0,32(sp)
    800041bc:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800041be:	fd840593          	addi	a1,s0,-40
    800041c2:	4505                	li	a0,1
    800041c4:	d2bfd0ef          	jal	80001eee <argaddr>
  argint(2, &n);
    800041c8:	fe440593          	addi	a1,s0,-28
    800041cc:	4509                	li	a0,2
    800041ce:	d05fd0ef          	jal	80001ed2 <argint>
  if(argfd(0, 0, &f) < 0)
    800041d2:	fe840613          	addi	a2,s0,-24
    800041d6:	4581                	li	a1,0
    800041d8:	4501                	li	a0,0
    800041da:	d77ff0ef          	jal	80003f50 <argfd>
    800041de:	87aa                	mv	a5,a0
    return -1;
    800041e0:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800041e2:	0007ca63          	bltz	a5,800041f6 <sys_write+0x40>
  return filewrite(f, p, n);
    800041e6:	fe442603          	lw	a2,-28(s0)
    800041ea:	fd843583          	ld	a1,-40(s0)
    800041ee:	fe843503          	ld	a0,-24(s0)
    800041f2:	da8ff0ef          	jal	8000379a <filewrite>
}
    800041f6:	70a2                	ld	ra,40(sp)
    800041f8:	7402                	ld	s0,32(sp)
    800041fa:	6145                	addi	sp,sp,48
    800041fc:	8082                	ret

00000000800041fe <sys_close>:
{
    800041fe:	1101                	addi	sp,sp,-32
    80004200:	ec06                	sd	ra,24(sp)
    80004202:	e822                	sd	s0,16(sp)
    80004204:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004206:	fe040613          	addi	a2,s0,-32
    8000420a:	fec40593          	addi	a1,s0,-20
    8000420e:	4501                	li	a0,0
    80004210:	d41ff0ef          	jal	80003f50 <argfd>
    return -1;
    80004214:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004216:	02054163          	bltz	a0,80004238 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    8000421a:	b4bfc0ef          	jal	80000d64 <myproc>
    8000421e:	fec42783          	lw	a5,-20(s0)
    80004222:	078e                	slli	a5,a5,0x3
    80004224:	0d078793          	addi	a5,a5,208
    80004228:	953e                	add	a0,a0,a5
    8000422a:	00053023          	sd	zero,0(a0)
  fileclose(f);
    8000422e:	fe043503          	ld	a0,-32(s0)
    80004232:	b80ff0ef          	jal	800035b2 <fileclose>
  return 0;
    80004236:	4781                	li	a5,0
}
    80004238:	853e                	mv	a0,a5
    8000423a:	60e2                	ld	ra,24(sp)
    8000423c:	6442                	ld	s0,16(sp)
    8000423e:	6105                	addi	sp,sp,32
    80004240:	8082                	ret

0000000080004242 <sys_fstat>:
{
    80004242:	1101                	addi	sp,sp,-32
    80004244:	ec06                	sd	ra,24(sp)
    80004246:	e822                	sd	s0,16(sp)
    80004248:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    8000424a:	fe040593          	addi	a1,s0,-32
    8000424e:	4505                	li	a0,1
    80004250:	c9ffd0ef          	jal	80001eee <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004254:	fe840613          	addi	a2,s0,-24
    80004258:	4581                	li	a1,0
    8000425a:	4501                	li	a0,0
    8000425c:	cf5ff0ef          	jal	80003f50 <argfd>
    80004260:	87aa                	mv	a5,a0
    return -1;
    80004262:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004264:	0007c863          	bltz	a5,80004274 <sys_fstat+0x32>
  return filestat(f, st);
    80004268:	fe043583          	ld	a1,-32(s0)
    8000426c:	fe843503          	ld	a0,-24(s0)
    80004270:	c04ff0ef          	jal	80003674 <filestat>
}
    80004274:	60e2                	ld	ra,24(sp)
    80004276:	6442                	ld	s0,16(sp)
    80004278:	6105                	addi	sp,sp,32
    8000427a:	8082                	ret

000000008000427c <sys_link>:
{
    8000427c:	7169                	addi	sp,sp,-304
    8000427e:	f606                	sd	ra,296(sp)
    80004280:	f222                	sd	s0,288(sp)
    80004282:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004284:	08000613          	li	a2,128
    80004288:	ed040593          	addi	a1,s0,-304
    8000428c:	4501                	li	a0,0
    8000428e:	c7dfd0ef          	jal	80001f0a <argstr>
    return -1;
    80004292:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004294:	0c054e63          	bltz	a0,80004370 <sys_link+0xf4>
    80004298:	08000613          	li	a2,128
    8000429c:	f5040593          	addi	a1,s0,-176
    800042a0:	4505                	li	a0,1
    800042a2:	c69fd0ef          	jal	80001f0a <argstr>
    return -1;
    800042a6:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800042a8:	0c054463          	bltz	a0,80004370 <sys_link+0xf4>
    800042ac:	ee26                	sd	s1,280(sp)
  begin_op();
    800042ae:	ed3fe0ef          	jal	80003180 <begin_op>
  if((ip = namei(old)) == 0){
    800042b2:	ed040513          	addi	a0,s0,-304
    800042b6:	d09fe0ef          	jal	80002fbe <namei>
    800042ba:	84aa                	mv	s1,a0
    800042bc:	c53d                	beqz	a0,8000432a <sys_link+0xae>
  ilock(ip);
    800042be:	e0afe0ef          	jal	800028c8 <ilock>
  if(ip->type == T_DIR){
    800042c2:	04449703          	lh	a4,68(s1)
    800042c6:	4785                	li	a5,1
    800042c8:	06f70663          	beq	a4,a5,80004334 <sys_link+0xb8>
    800042cc:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    800042ce:	04a4d783          	lhu	a5,74(s1)
    800042d2:	2785                	addiw	a5,a5,1
    800042d4:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800042d8:	8526                	mv	a0,s1
    800042da:	d3afe0ef          	jal	80002814 <iupdate>
  iunlock(ip);
    800042de:	8526                	mv	a0,s1
    800042e0:	e96fe0ef          	jal	80002976 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800042e4:	fd040593          	addi	a1,s0,-48
    800042e8:	f5040513          	addi	a0,s0,-176
    800042ec:	cedfe0ef          	jal	80002fd8 <nameiparent>
    800042f0:	892a                	mv	s2,a0
    800042f2:	cd21                	beqz	a0,8000434a <sys_link+0xce>
  ilock(dp);
    800042f4:	dd4fe0ef          	jal	800028c8 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800042f8:	854a                	mv	a0,s2
    800042fa:	00092703          	lw	a4,0(s2)
    800042fe:	409c                	lw	a5,0(s1)
    80004300:	04f71263          	bne	a4,a5,80004344 <sys_link+0xc8>
    80004304:	40d0                	lw	a2,4(s1)
    80004306:	fd040593          	addi	a1,s0,-48
    8000430a:	c0bfe0ef          	jal	80002f14 <dirlink>
    8000430e:	02054b63          	bltz	a0,80004344 <sys_link+0xc8>
  iunlockput(dp);
    80004312:	854a                	mv	a0,s2
    80004314:	fc0fe0ef          	jal	80002ad4 <iunlockput>
  iput(ip);
    80004318:	8526                	mv	a0,s1
    8000431a:	f30fe0ef          	jal	80002a4a <iput>
  end_op();
    8000431e:	ed3fe0ef          	jal	800031f0 <end_op>
  return 0;
    80004322:	4781                	li	a5,0
    80004324:	64f2                	ld	s1,280(sp)
    80004326:	6952                	ld	s2,272(sp)
    80004328:	a0a1                	j	80004370 <sys_link+0xf4>
    end_op();
    8000432a:	ec7fe0ef          	jal	800031f0 <end_op>
    return -1;
    8000432e:	57fd                	li	a5,-1
    80004330:	64f2                	ld	s1,280(sp)
    80004332:	a83d                	j	80004370 <sys_link+0xf4>
    iunlockput(ip);
    80004334:	8526                	mv	a0,s1
    80004336:	f9efe0ef          	jal	80002ad4 <iunlockput>
    end_op();
    8000433a:	eb7fe0ef          	jal	800031f0 <end_op>
    return -1;
    8000433e:	57fd                	li	a5,-1
    80004340:	64f2                	ld	s1,280(sp)
    80004342:	a03d                	j	80004370 <sys_link+0xf4>
    iunlockput(dp);
    80004344:	854a                	mv	a0,s2
    80004346:	f8efe0ef          	jal	80002ad4 <iunlockput>
  ilock(ip);
    8000434a:	8526                	mv	a0,s1
    8000434c:	d7cfe0ef          	jal	800028c8 <ilock>
  ip->nlink--;
    80004350:	04a4d783          	lhu	a5,74(s1)
    80004354:	37fd                	addiw	a5,a5,-1
    80004356:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000435a:	8526                	mv	a0,s1
    8000435c:	cb8fe0ef          	jal	80002814 <iupdate>
  iunlockput(ip);
    80004360:	8526                	mv	a0,s1
    80004362:	f72fe0ef          	jal	80002ad4 <iunlockput>
  end_op();
    80004366:	e8bfe0ef          	jal	800031f0 <end_op>
  return -1;
    8000436a:	57fd                	li	a5,-1
    8000436c:	64f2                	ld	s1,280(sp)
    8000436e:	6952                	ld	s2,272(sp)
}
    80004370:	853e                	mv	a0,a5
    80004372:	70b2                	ld	ra,296(sp)
    80004374:	7412                	ld	s0,288(sp)
    80004376:	6155                	addi	sp,sp,304
    80004378:	8082                	ret

000000008000437a <sys_unlink>:
{
    8000437a:	7151                	addi	sp,sp,-240
    8000437c:	f586                	sd	ra,232(sp)
    8000437e:	f1a2                	sd	s0,224(sp)
    80004380:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004382:	08000613          	li	a2,128
    80004386:	f3040593          	addi	a1,s0,-208
    8000438a:	4501                	li	a0,0
    8000438c:	b7ffd0ef          	jal	80001f0a <argstr>
    80004390:	14054d63          	bltz	a0,800044ea <sys_unlink+0x170>
    80004394:	eda6                	sd	s1,216(sp)
  begin_op();
    80004396:	debfe0ef          	jal	80003180 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    8000439a:	fb040593          	addi	a1,s0,-80
    8000439e:	f3040513          	addi	a0,s0,-208
    800043a2:	c37fe0ef          	jal	80002fd8 <nameiparent>
    800043a6:	84aa                	mv	s1,a0
    800043a8:	c955                	beqz	a0,8000445c <sys_unlink+0xe2>
  ilock(dp);
    800043aa:	d1efe0ef          	jal	800028c8 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800043ae:	00003597          	auipc	a1,0x3
    800043b2:	1ea58593          	addi	a1,a1,490 # 80007598 <etext+0x598>
    800043b6:	fb040513          	addi	a0,s0,-80
    800043ba:	95bfe0ef          	jal	80002d14 <namecmp>
    800043be:	10050b63          	beqz	a0,800044d4 <sys_unlink+0x15a>
    800043c2:	00003597          	auipc	a1,0x3
    800043c6:	1de58593          	addi	a1,a1,478 # 800075a0 <etext+0x5a0>
    800043ca:	fb040513          	addi	a0,s0,-80
    800043ce:	947fe0ef          	jal	80002d14 <namecmp>
    800043d2:	10050163          	beqz	a0,800044d4 <sys_unlink+0x15a>
    800043d6:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    800043d8:	f2c40613          	addi	a2,s0,-212
    800043dc:	fb040593          	addi	a1,s0,-80
    800043e0:	8526                	mv	a0,s1
    800043e2:	949fe0ef          	jal	80002d2a <dirlookup>
    800043e6:	892a                	mv	s2,a0
    800043e8:	0e050563          	beqz	a0,800044d2 <sys_unlink+0x158>
    800043ec:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800043ee:	cdafe0ef          	jal	800028c8 <ilock>
  if(ip->nlink < 1)
    800043f2:	04a91783          	lh	a5,74(s2)
    800043f6:	06f05863          	blez	a5,80004466 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800043fa:	04491703          	lh	a4,68(s2)
    800043fe:	4785                	li	a5,1
    80004400:	06f70963          	beq	a4,a5,80004472 <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80004404:	fc040993          	addi	s3,s0,-64
    80004408:	4641                	li	a2,16
    8000440a:	4581                	li	a1,0
    8000440c:	854e                	mv	a0,s3
    8000440e:	d51fb0ef          	jal	8000015e <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004412:	4741                	li	a4,16
    80004414:	f2c42683          	lw	a3,-212(s0)
    80004418:	864e                	mv	a2,s3
    8000441a:	4581                	li	a1,0
    8000441c:	8526                	mv	a0,s1
    8000441e:	ff6fe0ef          	jal	80002c14 <writei>
    80004422:	47c1                	li	a5,16
    80004424:	08f51863          	bne	a0,a5,800044b4 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    80004428:	04491703          	lh	a4,68(s2)
    8000442c:	4785                	li	a5,1
    8000442e:	08f70963          	beq	a4,a5,800044c0 <sys_unlink+0x146>
  iunlockput(dp);
    80004432:	8526                	mv	a0,s1
    80004434:	ea0fe0ef          	jal	80002ad4 <iunlockput>
  ip->nlink--;
    80004438:	04a95783          	lhu	a5,74(s2)
    8000443c:	37fd                	addiw	a5,a5,-1
    8000443e:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004442:	854a                	mv	a0,s2
    80004444:	bd0fe0ef          	jal	80002814 <iupdate>
  iunlockput(ip);
    80004448:	854a                	mv	a0,s2
    8000444a:	e8afe0ef          	jal	80002ad4 <iunlockput>
  end_op();
    8000444e:	da3fe0ef          	jal	800031f0 <end_op>
  return 0;
    80004452:	4501                	li	a0,0
    80004454:	64ee                	ld	s1,216(sp)
    80004456:	694e                	ld	s2,208(sp)
    80004458:	69ae                	ld	s3,200(sp)
    8000445a:	a061                	j	800044e2 <sys_unlink+0x168>
    end_op();
    8000445c:	d95fe0ef          	jal	800031f0 <end_op>
    return -1;
    80004460:	557d                	li	a0,-1
    80004462:	64ee                	ld	s1,216(sp)
    80004464:	a8bd                	j	800044e2 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004466:	00003517          	auipc	a0,0x3
    8000446a:	14250513          	addi	a0,a0,322 # 800075a8 <etext+0x5a8>
    8000446e:	560010ef          	jal	800059ce <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004472:	04c92703          	lw	a4,76(s2)
    80004476:	02000793          	li	a5,32
    8000447a:	f8e7f5e3          	bgeu	a5,a4,80004404 <sys_unlink+0x8a>
    8000447e:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004480:	4741                	li	a4,16
    80004482:	86ce                	mv	a3,s3
    80004484:	f1840613          	addi	a2,s0,-232
    80004488:	4581                	li	a1,0
    8000448a:	854a                	mv	a0,s2
    8000448c:	e96fe0ef          	jal	80002b22 <readi>
    80004490:	47c1                	li	a5,16
    80004492:	00f51b63          	bne	a0,a5,800044a8 <sys_unlink+0x12e>
    if(de.inum != 0)
    80004496:	f1845783          	lhu	a5,-232(s0)
    8000449a:	ebb1                	bnez	a5,800044ee <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000449c:	29c1                	addiw	s3,s3,16
    8000449e:	04c92783          	lw	a5,76(s2)
    800044a2:	fcf9efe3          	bltu	s3,a5,80004480 <sys_unlink+0x106>
    800044a6:	bfb9                	j	80004404 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    800044a8:	00003517          	auipc	a0,0x3
    800044ac:	11850513          	addi	a0,a0,280 # 800075c0 <etext+0x5c0>
    800044b0:	51e010ef          	jal	800059ce <panic>
    panic("unlink: writei");
    800044b4:	00003517          	auipc	a0,0x3
    800044b8:	12450513          	addi	a0,a0,292 # 800075d8 <etext+0x5d8>
    800044bc:	512010ef          	jal	800059ce <panic>
    dp->nlink--;
    800044c0:	04a4d783          	lhu	a5,74(s1)
    800044c4:	37fd                	addiw	a5,a5,-1
    800044c6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800044ca:	8526                	mv	a0,s1
    800044cc:	b48fe0ef          	jal	80002814 <iupdate>
    800044d0:	b78d                	j	80004432 <sys_unlink+0xb8>
    800044d2:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800044d4:	8526                	mv	a0,s1
    800044d6:	dfefe0ef          	jal	80002ad4 <iunlockput>
  end_op();
    800044da:	d17fe0ef          	jal	800031f0 <end_op>
  return -1;
    800044de:	557d                	li	a0,-1
    800044e0:	64ee                	ld	s1,216(sp)
}
    800044e2:	70ae                	ld	ra,232(sp)
    800044e4:	740e                	ld	s0,224(sp)
    800044e6:	616d                	addi	sp,sp,240
    800044e8:	8082                	ret
    return -1;
    800044ea:	557d                	li	a0,-1
    800044ec:	bfdd                	j	800044e2 <sys_unlink+0x168>
    iunlockput(ip);
    800044ee:	854a                	mv	a0,s2
    800044f0:	de4fe0ef          	jal	80002ad4 <iunlockput>
    goto bad;
    800044f4:	694e                	ld	s2,208(sp)
    800044f6:	69ae                	ld	s3,200(sp)
    800044f8:	bff1                	j	800044d4 <sys_unlink+0x15a>

00000000800044fa <sys_open>:

uint64
sys_open(void)
{
    800044fa:	7131                	addi	sp,sp,-192
    800044fc:	fd06                	sd	ra,184(sp)
    800044fe:	f922                	sd	s0,176(sp)
    80004500:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004502:	f4c40593          	addi	a1,s0,-180
    80004506:	4505                	li	a0,1
    80004508:	9cbfd0ef          	jal	80001ed2 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000450c:	08000613          	li	a2,128
    80004510:	f5040593          	addi	a1,s0,-176
    80004514:	4501                	li	a0,0
    80004516:	9f5fd0ef          	jal	80001f0a <argstr>
    8000451a:	87aa                	mv	a5,a0
    return -1;
    8000451c:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000451e:	0a07c363          	bltz	a5,800045c4 <sys_open+0xca>
    80004522:	f526                	sd	s1,168(sp)

  begin_op();
    80004524:	c5dfe0ef          	jal	80003180 <begin_op>

  if(omode & O_CREATE){
    80004528:	f4c42783          	lw	a5,-180(s0)
    8000452c:	2007f793          	andi	a5,a5,512
    80004530:	c3dd                	beqz	a5,800045d6 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    80004532:	4681                	li	a3,0
    80004534:	4601                	li	a2,0
    80004536:	4589                	li	a1,2
    80004538:	f5040513          	addi	a0,s0,-176
    8000453c:	aafff0ef          	jal	80003fea <create>
    80004540:	84aa                	mv	s1,a0
    if(ip == 0){
    80004542:	c549                	beqz	a0,800045cc <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004544:	04449703          	lh	a4,68(s1)
    80004548:	478d                	li	a5,3
    8000454a:	00f71763          	bne	a4,a5,80004558 <sys_open+0x5e>
    8000454e:	0464d703          	lhu	a4,70(s1)
    80004552:	47a5                	li	a5,9
    80004554:	0ae7ee63          	bltu	a5,a4,80004610 <sys_open+0x116>
    80004558:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000455a:	fb5fe0ef          	jal	8000350e <filealloc>
    8000455e:	892a                	mv	s2,a0
    80004560:	c561                	beqz	a0,80004628 <sys_open+0x12e>
    80004562:	ed4e                	sd	s3,152(sp)
    80004564:	a47ff0ef          	jal	80003faa <fdalloc>
    80004568:	89aa                	mv	s3,a0
    8000456a:	0a054b63          	bltz	a0,80004620 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000456e:	04449703          	lh	a4,68(s1)
    80004572:	478d                	li	a5,3
    80004574:	0cf70363          	beq	a4,a5,8000463a <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004578:	4789                	li	a5,2
    8000457a:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    8000457e:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004582:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004586:	f4c42783          	lw	a5,-180(s0)
    8000458a:	0017f713          	andi	a4,a5,1
    8000458e:	00174713          	xori	a4,a4,1
    80004592:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004596:	0037f713          	andi	a4,a5,3
    8000459a:	00e03733          	snez	a4,a4
    8000459e:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    800045a2:	4007f793          	andi	a5,a5,1024
    800045a6:	c791                	beqz	a5,800045b2 <sys_open+0xb8>
    800045a8:	04449703          	lh	a4,68(s1)
    800045ac:	4789                	li	a5,2
    800045ae:	08f70d63          	beq	a4,a5,80004648 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    800045b2:	8526                	mv	a0,s1
    800045b4:	bc2fe0ef          	jal	80002976 <iunlock>
  end_op();
    800045b8:	c39fe0ef          	jal	800031f0 <end_op>

  return fd;
    800045bc:	854e                	mv	a0,s3
    800045be:	74aa                	ld	s1,168(sp)
    800045c0:	790a                	ld	s2,160(sp)
    800045c2:	69ea                	ld	s3,152(sp)
}
    800045c4:	70ea                	ld	ra,184(sp)
    800045c6:	744a                	ld	s0,176(sp)
    800045c8:	6129                	addi	sp,sp,192
    800045ca:	8082                	ret
      end_op();
    800045cc:	c25fe0ef          	jal	800031f0 <end_op>
      return -1;
    800045d0:	557d                	li	a0,-1
    800045d2:	74aa                	ld	s1,168(sp)
    800045d4:	bfc5                	j	800045c4 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    800045d6:	f5040513          	addi	a0,s0,-176
    800045da:	9e5fe0ef          	jal	80002fbe <namei>
    800045de:	84aa                	mv	s1,a0
    800045e0:	c11d                	beqz	a0,80004606 <sys_open+0x10c>
    ilock(ip);
    800045e2:	ae6fe0ef          	jal	800028c8 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800045e6:	04449703          	lh	a4,68(s1)
    800045ea:	4785                	li	a5,1
    800045ec:	f4f71ce3          	bne	a4,a5,80004544 <sys_open+0x4a>
    800045f0:	f4c42783          	lw	a5,-180(s0)
    800045f4:	d3b5                	beqz	a5,80004558 <sys_open+0x5e>
      iunlockput(ip);
    800045f6:	8526                	mv	a0,s1
    800045f8:	cdcfe0ef          	jal	80002ad4 <iunlockput>
      end_op();
    800045fc:	bf5fe0ef          	jal	800031f0 <end_op>
      return -1;
    80004600:	557d                	li	a0,-1
    80004602:	74aa                	ld	s1,168(sp)
    80004604:	b7c1                	j	800045c4 <sys_open+0xca>
      end_op();
    80004606:	bebfe0ef          	jal	800031f0 <end_op>
      return -1;
    8000460a:	557d                	li	a0,-1
    8000460c:	74aa                	ld	s1,168(sp)
    8000460e:	bf5d                	j	800045c4 <sys_open+0xca>
    iunlockput(ip);
    80004610:	8526                	mv	a0,s1
    80004612:	cc2fe0ef          	jal	80002ad4 <iunlockput>
    end_op();
    80004616:	bdbfe0ef          	jal	800031f0 <end_op>
    return -1;
    8000461a:	557d                	li	a0,-1
    8000461c:	74aa                	ld	s1,168(sp)
    8000461e:	b75d                	j	800045c4 <sys_open+0xca>
      fileclose(f);
    80004620:	854a                	mv	a0,s2
    80004622:	f91fe0ef          	jal	800035b2 <fileclose>
    80004626:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80004628:	8526                	mv	a0,s1
    8000462a:	caafe0ef          	jal	80002ad4 <iunlockput>
    end_op();
    8000462e:	bc3fe0ef          	jal	800031f0 <end_op>
    return -1;
    80004632:	557d                	li	a0,-1
    80004634:	74aa                	ld	s1,168(sp)
    80004636:	790a                	ld	s2,160(sp)
    80004638:	b771                	j	800045c4 <sys_open+0xca>
    f->type = FD_DEVICE;
    8000463a:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    8000463e:	04649783          	lh	a5,70(s1)
    80004642:	02f91223          	sh	a5,36(s2)
    80004646:	bf35                	j	80004582 <sys_open+0x88>
    itrunc(ip);
    80004648:	8526                	mv	a0,s1
    8000464a:	b6cfe0ef          	jal	800029b6 <itrunc>
    8000464e:	b795                	j	800045b2 <sys_open+0xb8>

0000000080004650 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004650:	7175                	addi	sp,sp,-144
    80004652:	e506                	sd	ra,136(sp)
    80004654:	e122                	sd	s0,128(sp)
    80004656:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004658:	b29fe0ef          	jal	80003180 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000465c:	08000613          	li	a2,128
    80004660:	f7040593          	addi	a1,s0,-144
    80004664:	4501                	li	a0,0
    80004666:	8a5fd0ef          	jal	80001f0a <argstr>
    8000466a:	02054363          	bltz	a0,80004690 <sys_mkdir+0x40>
    8000466e:	4681                	li	a3,0
    80004670:	4601                	li	a2,0
    80004672:	4585                	li	a1,1
    80004674:	f7040513          	addi	a0,s0,-144
    80004678:	973ff0ef          	jal	80003fea <create>
    8000467c:	c911                	beqz	a0,80004690 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000467e:	c56fe0ef          	jal	80002ad4 <iunlockput>
  end_op();
    80004682:	b6ffe0ef          	jal	800031f0 <end_op>
  return 0;
    80004686:	4501                	li	a0,0
}
    80004688:	60aa                	ld	ra,136(sp)
    8000468a:	640a                	ld	s0,128(sp)
    8000468c:	6149                	addi	sp,sp,144
    8000468e:	8082                	ret
    end_op();
    80004690:	b61fe0ef          	jal	800031f0 <end_op>
    return -1;
    80004694:	557d                	li	a0,-1
    80004696:	bfcd                	j	80004688 <sys_mkdir+0x38>

0000000080004698 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004698:	7135                	addi	sp,sp,-160
    8000469a:	ed06                	sd	ra,152(sp)
    8000469c:	e922                	sd	s0,144(sp)
    8000469e:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800046a0:	ae1fe0ef          	jal	80003180 <begin_op>
  argint(1, &major);
    800046a4:	f6c40593          	addi	a1,s0,-148
    800046a8:	4505                	li	a0,1
    800046aa:	829fd0ef          	jal	80001ed2 <argint>
  argint(2, &minor);
    800046ae:	f6840593          	addi	a1,s0,-152
    800046b2:	4509                	li	a0,2
    800046b4:	81ffd0ef          	jal	80001ed2 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800046b8:	08000613          	li	a2,128
    800046bc:	f7040593          	addi	a1,s0,-144
    800046c0:	4501                	li	a0,0
    800046c2:	849fd0ef          	jal	80001f0a <argstr>
    800046c6:	02054563          	bltz	a0,800046f0 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800046ca:	f6841683          	lh	a3,-152(s0)
    800046ce:	f6c41603          	lh	a2,-148(s0)
    800046d2:	458d                	li	a1,3
    800046d4:	f7040513          	addi	a0,s0,-144
    800046d8:	913ff0ef          	jal	80003fea <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800046dc:	c911                	beqz	a0,800046f0 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800046de:	bf6fe0ef          	jal	80002ad4 <iunlockput>
  end_op();
    800046e2:	b0ffe0ef          	jal	800031f0 <end_op>
  return 0;
    800046e6:	4501                	li	a0,0
}
    800046e8:	60ea                	ld	ra,152(sp)
    800046ea:	644a                	ld	s0,144(sp)
    800046ec:	610d                	addi	sp,sp,160
    800046ee:	8082                	ret
    end_op();
    800046f0:	b01fe0ef          	jal	800031f0 <end_op>
    return -1;
    800046f4:	557d                	li	a0,-1
    800046f6:	bfcd                	j	800046e8 <sys_mknod+0x50>

00000000800046f8 <sys_chdir>:

uint64
sys_chdir(void)
{
    800046f8:	7135                	addi	sp,sp,-160
    800046fa:	ed06                	sd	ra,152(sp)
    800046fc:	e922                	sd	s0,144(sp)
    800046fe:	e14a                	sd	s2,128(sp)
    80004700:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80004702:	e62fc0ef          	jal	80000d64 <myproc>
    80004706:	892a                	mv	s2,a0
  
  begin_op();
    80004708:	a79fe0ef          	jal	80003180 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    8000470c:	08000613          	li	a2,128
    80004710:	f6040593          	addi	a1,s0,-160
    80004714:	4501                	li	a0,0
    80004716:	ff4fd0ef          	jal	80001f0a <argstr>
    8000471a:	04054363          	bltz	a0,80004760 <sys_chdir+0x68>
    8000471e:	e526                	sd	s1,136(sp)
    80004720:	f6040513          	addi	a0,s0,-160
    80004724:	89bfe0ef          	jal	80002fbe <namei>
    80004728:	84aa                	mv	s1,a0
    8000472a:	c915                	beqz	a0,8000475e <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    8000472c:	99cfe0ef          	jal	800028c8 <ilock>
  if(ip->type != T_DIR){
    80004730:	04449703          	lh	a4,68(s1)
    80004734:	4785                	li	a5,1
    80004736:	02f71963          	bne	a4,a5,80004768 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000473a:	8526                	mv	a0,s1
    8000473c:	a3afe0ef          	jal	80002976 <iunlock>
  iput(p->cwd);
    80004740:	15093503          	ld	a0,336(s2)
    80004744:	b06fe0ef          	jal	80002a4a <iput>
  end_op();
    80004748:	aa9fe0ef          	jal	800031f0 <end_op>
  p->cwd = ip;
    8000474c:	14993823          	sd	s1,336(s2)
  return 0;
    80004750:	4501                	li	a0,0
    80004752:	64aa                	ld	s1,136(sp)
}
    80004754:	60ea                	ld	ra,152(sp)
    80004756:	644a                	ld	s0,144(sp)
    80004758:	690a                	ld	s2,128(sp)
    8000475a:	610d                	addi	sp,sp,160
    8000475c:	8082                	ret
    8000475e:	64aa                	ld	s1,136(sp)
    end_op();
    80004760:	a91fe0ef          	jal	800031f0 <end_op>
    return -1;
    80004764:	557d                	li	a0,-1
    80004766:	b7fd                	j	80004754 <sys_chdir+0x5c>
    iunlockput(ip);
    80004768:	8526                	mv	a0,s1
    8000476a:	b6afe0ef          	jal	80002ad4 <iunlockput>
    end_op();
    8000476e:	a83fe0ef          	jal	800031f0 <end_op>
    return -1;
    80004772:	557d                	li	a0,-1
    80004774:	64aa                	ld	s1,136(sp)
    80004776:	bff9                	j	80004754 <sys_chdir+0x5c>

0000000080004778 <sys_exec>:

uint64
sys_exec(void)
{
    80004778:	7105                	addi	sp,sp,-480
    8000477a:	ef86                	sd	ra,472(sp)
    8000477c:	eba2                	sd	s0,464(sp)
    8000477e:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004780:	e2840593          	addi	a1,s0,-472
    80004784:	4505                	li	a0,1
    80004786:	f68fd0ef          	jal	80001eee <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    8000478a:	08000613          	li	a2,128
    8000478e:	f3040593          	addi	a1,s0,-208
    80004792:	4501                	li	a0,0
    80004794:	f76fd0ef          	jal	80001f0a <argstr>
    80004798:	87aa                	mv	a5,a0
    return -1;
    8000479a:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    8000479c:	0e07c063          	bltz	a5,8000487c <sys_exec+0x104>
    800047a0:	e7a6                	sd	s1,456(sp)
    800047a2:	e3ca                	sd	s2,448(sp)
    800047a4:	ff4e                	sd	s3,440(sp)
    800047a6:	fb52                	sd	s4,432(sp)
    800047a8:	f756                	sd	s5,424(sp)
    800047aa:	f35a                	sd	s6,416(sp)
    800047ac:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    800047ae:	e3040a13          	addi	s4,s0,-464
    800047b2:	10000613          	li	a2,256
    800047b6:	4581                	li	a1,0
    800047b8:	8552                	mv	a0,s4
    800047ba:	9a5fb0ef          	jal	8000015e <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800047be:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    800047c0:	89d2                	mv	s3,s4
    800047c2:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800047c4:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800047c8:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    800047ca:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800047ce:	00391513          	slli	a0,s2,0x3
    800047d2:	85d6                	mv	a1,s5
    800047d4:	e2843783          	ld	a5,-472(s0)
    800047d8:	953e                	add	a0,a0,a5
    800047da:	e6efd0ef          	jal	80001e48 <fetchaddr>
    800047de:	02054663          	bltz	a0,8000480a <sys_exec+0x92>
    if(uarg == 0){
    800047e2:	e2043783          	ld	a5,-480(s0)
    800047e6:	c7a1                	beqz	a5,8000482e <sys_exec+0xb6>
    argv[i] = kalloc();
    800047e8:	91dfb0ef          	jal	80000104 <kalloc>
    800047ec:	85aa                	mv	a1,a0
    800047ee:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800047f2:	cd01                	beqz	a0,8000480a <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800047f4:	865a                	mv	a2,s6
    800047f6:	e2043503          	ld	a0,-480(s0)
    800047fa:	e98fd0ef          	jal	80001e92 <fetchstr>
    800047fe:	00054663          	bltz	a0,8000480a <sys_exec+0x92>
    if(i >= NELEM(argv)){
    80004802:	0905                	addi	s2,s2,1
    80004804:	09a1                	addi	s3,s3,8
    80004806:	fd7914e3          	bne	s2,s7,800047ce <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000480a:	100a0a13          	addi	s4,s4,256
    8000480e:	6088                	ld	a0,0(s1)
    80004810:	cd31                	beqz	a0,8000486c <sys_exec+0xf4>
    kfree(argv[i]);
    80004812:	80bfb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004816:	04a1                	addi	s1,s1,8
    80004818:	ff449be3          	bne	s1,s4,8000480e <sys_exec+0x96>
  return -1;
    8000481c:	557d                	li	a0,-1
    8000481e:	64be                	ld	s1,456(sp)
    80004820:	691e                	ld	s2,448(sp)
    80004822:	79fa                	ld	s3,440(sp)
    80004824:	7a5a                	ld	s4,432(sp)
    80004826:	7aba                	ld	s5,424(sp)
    80004828:	7b1a                	ld	s6,416(sp)
    8000482a:	6bfa                	ld	s7,408(sp)
    8000482c:	a881                	j	8000487c <sys_exec+0x104>
      argv[i] = 0;
    8000482e:	0009079b          	sext.w	a5,s2
    80004832:	e3040593          	addi	a1,s0,-464
    80004836:	078e                	slli	a5,a5,0x3
    80004838:	97ae                	add	a5,a5,a1
    8000483a:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    8000483e:	f3040513          	addi	a0,s0,-208
    80004842:	bb2ff0ef          	jal	80003bf4 <exec>
    80004846:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004848:	100a0a13          	addi	s4,s4,256
    8000484c:	6088                	ld	a0,0(s1)
    8000484e:	c511                	beqz	a0,8000485a <sys_exec+0xe2>
    kfree(argv[i]);
    80004850:	fccfb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004854:	04a1                	addi	s1,s1,8
    80004856:	ff449be3          	bne	s1,s4,8000484c <sys_exec+0xd4>
  return ret;
    8000485a:	854a                	mv	a0,s2
    8000485c:	64be                	ld	s1,456(sp)
    8000485e:	691e                	ld	s2,448(sp)
    80004860:	79fa                	ld	s3,440(sp)
    80004862:	7a5a                	ld	s4,432(sp)
    80004864:	7aba                	ld	s5,424(sp)
    80004866:	7b1a                	ld	s6,416(sp)
    80004868:	6bfa                	ld	s7,408(sp)
    8000486a:	a809                	j	8000487c <sys_exec+0x104>
  return -1;
    8000486c:	557d                	li	a0,-1
    8000486e:	64be                	ld	s1,456(sp)
    80004870:	691e                	ld	s2,448(sp)
    80004872:	79fa                	ld	s3,440(sp)
    80004874:	7a5a                	ld	s4,432(sp)
    80004876:	7aba                	ld	s5,424(sp)
    80004878:	7b1a                	ld	s6,416(sp)
    8000487a:	6bfa                	ld	s7,408(sp)
}
    8000487c:	60fe                	ld	ra,472(sp)
    8000487e:	645e                	ld	s0,464(sp)
    80004880:	613d                	addi	sp,sp,480
    80004882:	8082                	ret

0000000080004884 <sys_pipe>:

uint64
sys_pipe(void)
{
    80004884:	7139                	addi	sp,sp,-64
    80004886:	fc06                	sd	ra,56(sp)
    80004888:	f822                	sd	s0,48(sp)
    8000488a:	f426                	sd	s1,40(sp)
    8000488c:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000488e:	cd6fc0ef          	jal	80000d64 <myproc>
    80004892:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80004894:	fd840593          	addi	a1,s0,-40
    80004898:	4501                	li	a0,0
    8000489a:	e54fd0ef          	jal	80001eee <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000489e:	fc840593          	addi	a1,s0,-56
    800048a2:	fd040513          	addi	a0,s0,-48
    800048a6:	828ff0ef          	jal	800038ce <pipealloc>
    return -1;
    800048aa:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800048ac:	0a054763          	bltz	a0,8000495a <sys_pipe+0xd6>
  fd0 = -1;
    800048b0:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800048b4:	fd043503          	ld	a0,-48(s0)
    800048b8:	ef2ff0ef          	jal	80003faa <fdalloc>
    800048bc:	fca42223          	sw	a0,-60(s0)
    800048c0:	08054463          	bltz	a0,80004948 <sys_pipe+0xc4>
    800048c4:	fc843503          	ld	a0,-56(s0)
    800048c8:	ee2ff0ef          	jal	80003faa <fdalloc>
    800048cc:	fca42023          	sw	a0,-64(s0)
    800048d0:	06054263          	bltz	a0,80004934 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800048d4:	4691                	li	a3,4
    800048d6:	fc440613          	addi	a2,s0,-60
    800048da:	fd843583          	ld	a1,-40(s0)
    800048de:	68a8                	ld	a0,80(s1)
    800048e0:	90cfc0ef          	jal	800009ec <copyout>
    800048e4:	00054e63          	bltz	a0,80004900 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800048e8:	4691                	li	a3,4
    800048ea:	fc040613          	addi	a2,s0,-64
    800048ee:	fd843583          	ld	a1,-40(s0)
    800048f2:	95b6                	add	a1,a1,a3
    800048f4:	68a8                	ld	a0,80(s1)
    800048f6:	8f6fc0ef          	jal	800009ec <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800048fa:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800048fc:	04055f63          	bgez	a0,8000495a <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    80004900:	fc442783          	lw	a5,-60(s0)
    80004904:	078e                	slli	a5,a5,0x3
    80004906:	0d078793          	addi	a5,a5,208
    8000490a:	97a6                	add	a5,a5,s1
    8000490c:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80004910:	fc042783          	lw	a5,-64(s0)
    80004914:	078e                	slli	a5,a5,0x3
    80004916:	0d078793          	addi	a5,a5,208
    8000491a:	97a6                	add	a5,a5,s1
    8000491c:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80004920:	fd043503          	ld	a0,-48(s0)
    80004924:	c8ffe0ef          	jal	800035b2 <fileclose>
    fileclose(wf);
    80004928:	fc843503          	ld	a0,-56(s0)
    8000492c:	c87fe0ef          	jal	800035b2 <fileclose>
    return -1;
    80004930:	57fd                	li	a5,-1
    80004932:	a025                	j	8000495a <sys_pipe+0xd6>
    if(fd0 >= 0)
    80004934:	fc442783          	lw	a5,-60(s0)
    80004938:	0007c863          	bltz	a5,80004948 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    8000493c:	078e                	slli	a5,a5,0x3
    8000493e:	0d078793          	addi	a5,a5,208
    80004942:	97a6                	add	a5,a5,s1
    80004944:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80004948:	fd043503          	ld	a0,-48(s0)
    8000494c:	c67fe0ef          	jal	800035b2 <fileclose>
    fileclose(wf);
    80004950:	fc843503          	ld	a0,-56(s0)
    80004954:	c5ffe0ef          	jal	800035b2 <fileclose>
    return -1;
    80004958:	57fd                	li	a5,-1
}
    8000495a:	853e                	mv	a0,a5
    8000495c:	70e2                	ld	ra,56(sp)
    8000495e:	7442                	ld	s0,48(sp)
    80004960:	74a2                	ld	s1,40(sp)
    80004962:	6121                	addi	sp,sp,64
    80004964:	8082                	ret

0000000080004966 <sys_mmap>:
uint64 sys_mmap(void) {
    80004966:	7139                	addi	sp,sp,-64
    80004968:	fc06                	sd	ra,56(sp)
    8000496a:	f822                	sd	s0,48(sp)
    8000496c:	0080                	addi	s0,sp,64
    uint64 addr;
    uint64 len;
    int prot, flags, fd;

    // 修复参数获取方式
    argaddr(0, &addr);
    8000496e:	fd840593          	addi	a1,s0,-40
    80004972:	4501                	li	a0,0
    80004974:	d7afd0ef          	jal	80001eee <argaddr>
    argaddr(1, &len);
    80004978:	fd040593          	addi	a1,s0,-48
    8000497c:	4505                	li	a0,1
    8000497e:	d70fd0ef          	jal	80001eee <argaddr>
    argint(2, &prot);
    80004982:	fcc40593          	addi	a1,s0,-52
    80004986:	4509                	li	a0,2
    80004988:	d4afd0ef          	jal	80001ed2 <argint>
    argint(3, &flags);
    8000498c:	fc840593          	addi	a1,s0,-56
    80004990:	450d                	li	a0,3
    80004992:	d40fd0ef          	jal	80001ed2 <argint>
    argint(4, &fd);
    80004996:	fc440593          	addi	a1,s0,-60
    8000499a:	4511                	li	a0,4
    8000499c:	d36fd0ef          	jal	80001ed2 <argint>

    // 只处理addr=0的情况
    if (addr != 0) {
    800049a0:	fd843783          	ld	a5,-40(s0)
        return -1;
    800049a4:	557d                	li	a0,-1
    if (addr != 0) {
    800049a6:	efc5                	bnez	a5,80004a5e <sys_mmap+0xf8>
    800049a8:	f04a                	sd	s2,32(sp)
    }

    struct proc *p = myproc();
    800049aa:	bbafc0ef          	jal	80000d64 <myproc>
    800049ae:	892a                	mv	s2,a0
    struct file *f = p->ofile[fd];
    800049b0:	fc442783          	lw	a5,-60(s0)
    800049b4:	078e                	slli	a5,a5,0x3
    800049b6:	0d078793          	addi	a5,a5,208
    800049ba:	97aa                	add	a5,a5,a0
    800049bc:	638c                	ld	a1,0(a5)
    if (f == 0) {
    800049be:	c5c5                	beqz	a1,80004a66 <sys_mmap+0x100>
        return -1;
    }

    // 检查权限
    if ((prot & PROT_READ) && !f->readable) {
    800049c0:	fcc42783          	lw	a5,-52(s0)
    800049c4:	0017f713          	andi	a4,a5,1
    800049c8:	c709                	beqz	a4,800049d2 <sys_mmap+0x6c>
    800049ca:	0085c703          	lbu	a4,8(a1)
        return -1;
    800049ce:	557d                	li	a0,-1
    if ((prot & PROT_READ) && !f->readable) {
    800049d0:	c355                	beqz	a4,80004a74 <sys_mmap+0x10e>
    }
    if ((prot & PROT_WRITE) && (flags & MAP_SHARED) && !f->writable) {
    800049d2:	8b89                	andi	a5,a5,2
    800049d4:	c789                	beqz	a5,800049de <sys_mmap+0x78>
    800049d6:	fc842783          	lw	a5,-56(s0)
    800049da:	8b85                	andi	a5,a5,1
    800049dc:	ef99                	bnez	a5,800049fa <sys_mmap+0x94>
        return -1;
    }

    // 查找空闲VMA
    struct vma *vv = 0;
    for (int i = 0; i < NVMA; i++) {
    800049de:	16890713          	addi	a4,s2,360
uint64 sys_mmap(void) {
    800049e2:	4781                	li	a5,0
    for (int i = 0; i < NVMA; i++) {
    800049e4:	4641                	li	a2,16
        if (p->vmas[i].used == 0) {
    800049e6:	4314                	lw	a3,0(a4)
    800049e8:	ce99                	beqz	a3,80004a06 <sys_mmap+0xa0>
    for (int i = 0; i < NVMA; i++) {
    800049ea:	2785                	addiw	a5,a5,1
    800049ec:	03070713          	addi	a4,a4,48
    800049f0:	fec79be3          	bne	a5,a2,800049e6 <sys_mmap+0x80>
            vv = &p->vmas[i];
            break;
        }
    }
    if (vv == 0) {
        return -1;
    800049f4:	557d                	li	a0,-1
    800049f6:	7902                	ld	s2,32(sp)
    800049f8:	a09d                	j	80004a5e <sys_mmap+0xf8>
    if ((prot & PROT_WRITE) && (flags & MAP_SHARED) && !f->writable) {
    800049fa:	0095c783          	lbu	a5,9(a1)
        return -1;
    800049fe:	557d                	li	a0,-1
    if ((prot & PROT_WRITE) && (flags & MAP_SHARED) && !f->writable) {
    80004a00:	fff9                	bnez	a5,800049de <sys_mmap+0x78>
    80004a02:	7902                	ld	s2,32(sp)
    80004a04:	a8a9                	j	80004a5e <sys_mmap+0xf8>
    80004a06:	f426                	sd	s1,40(sp)
            vv = &p->vmas[i];
    80004a08:	00179493          	slli	s1,a5,0x1
    80004a0c:	94be                	add	s1,s1,a5
    80004a0e:	0492                	slli	s1,s1,0x4
    80004a10:	16848493          	addi	s1,s1,360
    80004a14:	94ca                	add	s1,s1,s2
    if (vv == 0) {
    80004a16:	c8b9                	beqz	s1,80004a6c <sys_mmap+0x106>
    }

    // 设置VMA
    vv->used = 1;
    80004a18:	4785                	li	a5,1
    80004a1a:	c09c                	sw	a5,0(s1)
    vv->addr = p->sz;           // 从当前进程大小开始
    80004a1c:	04893783          	ld	a5,72(s2)
    80004a20:	e49c                	sd	a5,8(s1)
    vv->len = len;
    80004a22:	fd043783          	ld	a5,-48(s0)
    80004a26:	e89c                	sd	a5,16(s1)
    vv->prot = prot;
    80004a28:	fcc42783          	lw	a5,-52(s0)
    80004a2c:	cc9c                	sw	a5,24(s1)
    vv->flags = flags;
    80004a2e:	fc842783          	lw	a5,-56(s0)
    80004a32:	ccdc                	sw	a5,28(s1)
    vv->file = filedup(f);      // 增加文件引用计数
    80004a34:	852e                	mv	a0,a1
    80004a36:	b37fe0ef          	jal	8000356c <filedup>
    80004a3a:	f088                	sd	a0,32(s1)
    vv->offset = 0;
    80004a3c:	0204b423          	sd	zero,40(s1)

    // 更新进程大小（页对齐）
    p->sz = PGROUNDUP(p->sz + len);
    80004a40:	fd043783          	ld	a5,-48(s0)
    80004a44:	6705                	lui	a4,0x1
    80004a46:	177d                	addi	a4,a4,-1 # fff <_entry-0x7ffff001>
    80004a48:	97ba                	add	a5,a5,a4
    80004a4a:	04893703          	ld	a4,72(s2)
    80004a4e:	97ba                	add	a5,a5,a4
    80004a50:	777d                	lui	a4,0xfffff
    80004a52:	8ff9                	and	a5,a5,a4
    80004a54:	04f93423          	sd	a5,72(s2)
    return vv->addr;  // 返回映射地址
    80004a58:	6488                	ld	a0,8(s1)
    80004a5a:	74a2                	ld	s1,40(sp)
    80004a5c:	7902                	ld	s2,32(sp)
}
    80004a5e:	70e2                	ld	ra,56(sp)
    80004a60:	7442                	ld	s0,48(sp)
    80004a62:	6121                	addi	sp,sp,64
    80004a64:	8082                	ret
        return -1;
    80004a66:	557d                	li	a0,-1
    80004a68:	7902                	ld	s2,32(sp)
    80004a6a:	bfd5                	j	80004a5e <sys_mmap+0xf8>
        return -1;
    80004a6c:	557d                	li	a0,-1
    80004a6e:	74a2                	ld	s1,40(sp)
    80004a70:	7902                	ld	s2,32(sp)
    80004a72:	b7f5                	j	80004a5e <sys_mmap+0xf8>
    80004a74:	7902                	ld	s2,32(sp)
    80004a76:	b7e5                	j	80004a5e <sys_mmap+0xf8>

0000000080004a78 <sys_munmap>:

uint64 sys_munmap(void) {
    80004a78:	711d                	addi	sp,sp,-96
    80004a7a:	ec86                	sd	ra,88(sp)
    80004a7c:	e8a2                	sd	s0,80(sp)
    80004a7e:	e0ca                	sd	s2,64(sp)
    80004a80:	1080                	addi	s0,sp,96
    uint64 addr;
    uint64 len;

    // 获取参数
    argaddr(0, &addr);
    80004a82:	fa840593          	addi	a1,s0,-88
    80004a86:	4501                	li	a0,0
    80004a88:	c66fd0ef          	jal	80001eee <argaddr>
    argaddr(1, &len);
    80004a8c:	fa040593          	addi	a1,s0,-96
    80004a90:	4505                	li	a0,1
    80004a92:	c5cfd0ef          	jal	80001eee <argaddr>

    struct proc *p = myproc();
    80004a96:	acefc0ef          	jal	80000d64 <myproc>
    80004a9a:	892a                	mv	s2,a0
    struct vma *vv = 0;

    // 查找匹配的VMA
    for (int i = 0; i < NVMA; i++) {
        if (p->vmas[i].used &&
            addr >= p->vmas[i].addr &&
    80004a9c:	fa843583          	ld	a1,-88(s0)
    80004aa0:	16850793          	addi	a5,a0,360
    for (int i = 0; i < NVMA; i++) {
    80004aa4:	4701                	li	a4,0
    80004aa6:	4641                	li	a2,16
    80004aa8:	a031                	j	80004ab4 <sys_munmap+0x3c>
    80004aaa:	2705                	addiw	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffd23d1>
    80004aac:	03078793          	addi	a5,a5,48
    80004ab0:	06c70463          	beq	a4,a2,80004b18 <sys_munmap+0xa0>
        if (p->vmas[i].used &&
    80004ab4:	4394                	lw	a3,0(a5)
    80004ab6:	daf5                	beqz	a3,80004aaa <sys_munmap+0x32>
            addr >= p->vmas[i].addr &&
    80004ab8:	6794                	ld	a3,8(a5)
        if (p->vmas[i].used &&
    80004aba:	fed5e8e3          	bltu	a1,a3,80004aaa <sys_munmap+0x32>
            addr < p->vmas[i].addr + p->vmas[i].len) {
    80004abe:	6b88                	ld	a0,16(a5)
    80004ac0:	96aa                	add	a3,a3,a0
            addr >= p->vmas[i].addr &&
    80004ac2:	fed5f4e3          	bgeu	a1,a3,80004aaa <sys_munmap+0x32>
    80004ac6:	e4a6                	sd	s1,72(sp)
            vv = &p->vmas[i];
    80004ac8:	00171493          	slli	s1,a4,0x1
    80004acc:	94ba                	add	s1,s1,a4
    80004ace:	0492                	slli	s1,s1,0x4
    80004ad0:	16848493          	addi	s1,s1,360
    80004ad4:	94ca                	add	s1,s1,s2
            break;
        }
    }
    if (vv == 0) {
    80004ad6:	14048063          	beqz	s1,80004c16 <sys_munmap+0x19e>
        return -1;
    }

    // 写回修改（MAP_SHARED）
    if (vv->flags == MAP_SHARED) {
    80004ada:	4cd8                	lw	a4,28(s1)
    80004adc:	4785                	li	a5,1
    80004ade:	04f70363          	beq	a4,a5,80004b24 <sys_munmap+0xac>
        // 结束文件系统事务
        end_op();
    }

    // 解除映射
    uvmunmap(p->pagetable, addr, len / PGSIZE, 1);
    80004ae2:	4685                	li	a3,1
    80004ae4:	fa043603          	ld	a2,-96(s0)
    80004ae8:	8231                	srli	a2,a2,0xc
    80004aea:	fa843583          	ld	a1,-88(s0)
    80004aee:	05093503          	ld	a0,80(s2)
    80004af2:	b7dfb0ef          	jal	8000066e <uvmunmap>

    // 更新VMA
    if (addr == vv->addr && len == vv->len) {
    80004af6:	649c                	ld	a5,8(s1)
    80004af8:	fa843703          	ld	a4,-88(s0)
    80004afc:	0ce78a63          	beq	a5,a4,80004bd0 <sys_munmap+0x158>
    } else if (addr == vv->addr) {
        // 开头部分
        vv->addr += len;
        vv->len -= len;
        vv->offset += len;
    } else if (addr + len == vv->addr + vv->len) {
    80004b00:	fa043603          	ld	a2,-96(s0)
    80004b04:	6894                	ld	a3,16(s1)
    80004b06:	9732                	add	a4,a4,a2
    80004b08:	97b6                	add	a5,a5,a3
    80004b0a:	0ef71a63          	bne	a4,a5,80004bfe <sys_munmap+0x186>
        // 结尾部分
        vv->len -= len;
    80004b0e:	8e91                	sub	a3,a3,a2
    80004b10:	e894                	sd	a3,16(s1)
    } else {
        panic("munmap middle");
    }
    return 0;
    80004b12:	4501                	li	a0,0
    80004b14:	64a6                	ld	s1,72(sp)
    80004b16:	a011                	j	80004b1a <sys_munmap+0xa2>
        return -1;
    80004b18:	557d                	li	a0,-1
    80004b1a:	60e6                	ld	ra,88(sp)
    80004b1c:	6446                	ld	s0,80(sp)
    80004b1e:	6906                	ld	s2,64(sp)
    80004b20:	6125                	addi	sp,sp,96
    80004b22:	8082                	ret
    80004b24:	fc4e                	sd	s3,56(sp)
        begin_op();
    80004b26:	e5afe0ef          	jal	80003180 <begin_op>
        for (uint64 va = addr; va < addr + len; va += PGSIZE) {
    80004b2a:	fa843983          	ld	s3,-88(s0)
    80004b2e:	fa043783          	ld	a5,-96(s0)
    80004b32:	97ce                	add	a5,a5,s3
    80004b34:	08f9fa63          	bgeu	s3,a5,80004bc8 <sys_munmap+0x150>
    80004b38:	f852                	sd	s4,48(sp)
    80004b3a:	f456                	sd	s5,40(sp)
    80004b3c:	f05a                	sd	s6,32(sp)
    80004b3e:	ec5e                	sd	s7,24(sp)
    80004b40:	e862                	sd	s8,16(sp)
                writei(vv->file->ip, 1, pa + KERNBASE, off, min(PGSIZE, vv->file->ip->size - off));
    80004b42:	6a05                	lui	s4,0x1
    80004b44:	4785                	li	a5,1
    80004b46:	07fe                	slli	a5,a5,0x1f
    80004b48:	8c3e                	mv	s8,a5
    80004b4a:	a03d                	j	80004b78 <sys_munmap+0x100>
                uint64 pa = PTE2PA(*pte);
    80004b4c:	00aad613          	srli	a2,s5,0xa
    80004b50:	0632                	slli	a2,a2,0xc
                writei(vv->file->ip, 1, pa + KERNBASE, off, min(PGSIZE, vv->file->ip->size - off));
    80004b52:	2701                	sext.w	a4,a4
    80004b54:	000b869b          	sext.w	a3,s7
    80004b58:	9662                	add	a2,a2,s8
    80004b5a:	4585                	li	a1,1
    80004b5c:	8b8fe0ef          	jal	80002c14 <writei>
                iunlock(vv->file->ip);
    80004b60:	709c                	ld	a5,32(s1)
    80004b62:	6f88                	ld	a0,24(a5)
    80004b64:	e13fd0ef          	jal	80002976 <iunlock>
        for (uint64 va = addr; va < addr + len; va += PGSIZE) {
    80004b68:	99d2                	add	s3,s3,s4
    80004b6a:	fa843783          	ld	a5,-88(s0)
    80004b6e:	fa043703          	ld	a4,-96(s0)
    80004b72:	97ba                	add	a5,a5,a4
    80004b74:	04f9f563          	bgeu	s3,a5,80004bbe <sys_munmap+0x146>
            pte_t *pte = walk(p->pagetable, va, 0);
    80004b78:	4601                	li	a2,0
    80004b7a:	85ce                	mv	a1,s3
    80004b7c:	05093503          	ld	a0,80(s2)
    80004b80:	873fb0ef          	jal	800003f2 <walk>
            if (pte && (*pte & PTE_V) && (*pte & PTE_D)) {
    80004b84:	d175                	beqz	a0,80004b68 <sys_munmap+0xf0>
    80004b86:	00053a83          	ld	s5,0(a0)
    80004b8a:	081af793          	andi	a5,s5,129
    80004b8e:	08100713          	li	a4,129
    80004b92:	fce79be3          	bne	a5,a4,80004b68 <sys_munmap+0xf0>
                uint64 off = va - vv->addr;
    80004b96:	0084bb03          	ld	s6,8(s1)
    80004b9a:	416987b3          	sub	a5,s3,s6
    80004b9e:	8bbe                	mv	s7,a5
                ilock(vv->file->ip);
    80004ba0:	709c                	ld	a5,32(s1)
    80004ba2:	6f88                	ld	a0,24(a5)
    80004ba4:	d25fd0ef          	jal	800028c8 <ilock>
                writei(vv->file->ip, 1, pa + KERNBASE, off, min(PGSIZE, vv->file->ip->size - off));
    80004ba8:	709c                	ld	a5,32(s1)
    80004baa:	6f88                	ld	a0,24(a5)
    80004bac:	04c56703          	lwu	a4,76(a0)
    80004bb0:	975a                	add	a4,a4,s6
    80004bb2:	41370733          	sub	a4,a4,s3
    80004bb6:	f8ea7be3          	bgeu	s4,a4,80004b4c <sys_munmap+0xd4>
    80004bba:	6705                	lui	a4,0x1
    80004bbc:	bf41                	j	80004b4c <sys_munmap+0xd4>
    80004bbe:	7a42                	ld	s4,48(sp)
    80004bc0:	7aa2                	ld	s5,40(sp)
    80004bc2:	7b02                	ld	s6,32(sp)
    80004bc4:	6be2                	ld	s7,24(sp)
    80004bc6:	6c42                	ld	s8,16(sp)
        end_op();
    80004bc8:	e28fe0ef          	jal	800031f0 <end_op>
    80004bcc:	79e2                	ld	s3,56(sp)
    80004bce:	bf11                	j	80004ae2 <sys_munmap+0x6a>
    if (addr == vv->addr && len == vv->len) {
    80004bd0:	6894                	ld	a3,16(s1)
    80004bd2:	fa043703          	ld	a4,-96(s0)
    80004bd6:	00e68c63          	beq	a3,a4,80004bee <sys_munmap+0x176>
        vv->addr += len;
    80004bda:	97ba                	add	a5,a5,a4
    80004bdc:	e49c                	sd	a5,8(s1)
        vv->len -= len;
    80004bde:	8e99                	sub	a3,a3,a4
    80004be0:	e894                	sd	a3,16(s1)
        vv->offset += len;
    80004be2:	749c                	ld	a5,40(s1)
    80004be4:	97ba                	add	a5,a5,a4
    80004be6:	f49c                	sd	a5,40(s1)
    return 0;
    80004be8:	4501                	li	a0,0
    80004bea:	64a6                	ld	s1,72(sp)
    80004bec:	b73d                	j	80004b1a <sys_munmap+0xa2>
        fileclose(vv->file);
    80004bee:	7088                	ld	a0,32(s1)
    80004bf0:	9c3fe0ef          	jal	800035b2 <fileclose>
        vv->used = 0;
    80004bf4:	0004a023          	sw	zero,0(s1)
    return 0;
    80004bf8:	4501                	li	a0,0
        vv->used = 0;
    80004bfa:	64a6                	ld	s1,72(sp)
    80004bfc:	bf39                	j	80004b1a <sys_munmap+0xa2>
    80004bfe:	fc4e                	sd	s3,56(sp)
    80004c00:	f852                	sd	s4,48(sp)
    80004c02:	f456                	sd	s5,40(sp)
    80004c04:	f05a                	sd	s6,32(sp)
    80004c06:	ec5e                	sd	s7,24(sp)
    80004c08:	e862                	sd	s8,16(sp)
        panic("munmap middle");
    80004c0a:	00003517          	auipc	a0,0x3
    80004c0e:	9de50513          	addi	a0,a0,-1570 # 800075e8 <etext+0x5e8>
    80004c12:	5bd000ef          	jal	800059ce <panic>
        return -1;
    80004c16:	557d                	li	a0,-1
    80004c18:	64a6                	ld	s1,72(sp)
    80004c1a:	b701                	j	80004b1a <sys_munmap+0xa2>
    80004c1c:	0000                	unimp
	...

0000000080004c20 <kernelvec>:
    80004c20:	7111                	addi	sp,sp,-256
    80004c22:	e006                	sd	ra,0(sp)
    80004c24:	e40a                	sd	sp,8(sp)
    80004c26:	e80e                	sd	gp,16(sp)
    80004c28:	ec12                	sd	tp,24(sp)
    80004c2a:	f016                	sd	t0,32(sp)
    80004c2c:	f41a                	sd	t1,40(sp)
    80004c2e:	f81e                	sd	t2,48(sp)
    80004c30:	e4aa                	sd	a0,72(sp)
    80004c32:	e8ae                	sd	a1,80(sp)
    80004c34:	ecb2                	sd	a2,88(sp)
    80004c36:	f0b6                	sd	a3,96(sp)
    80004c38:	f4ba                	sd	a4,104(sp)
    80004c3a:	f8be                	sd	a5,112(sp)
    80004c3c:	fcc2                	sd	a6,120(sp)
    80004c3e:	e146                	sd	a7,128(sp)
    80004c40:	edf2                	sd	t3,216(sp)
    80004c42:	f1f6                	sd	t4,224(sp)
    80004c44:	f5fa                	sd	t5,232(sp)
    80004c46:	f9fe                	sd	t6,240(sp)
    80004c48:	90efd0ef          	jal	80001d56 <kerneltrap>
    80004c4c:	6082                	ld	ra,0(sp)
    80004c4e:	6122                	ld	sp,8(sp)
    80004c50:	61c2                	ld	gp,16(sp)
    80004c52:	7282                	ld	t0,32(sp)
    80004c54:	7322                	ld	t1,40(sp)
    80004c56:	73c2                	ld	t2,48(sp)
    80004c58:	6526                	ld	a0,72(sp)
    80004c5a:	65c6                	ld	a1,80(sp)
    80004c5c:	6666                	ld	a2,88(sp)
    80004c5e:	7686                	ld	a3,96(sp)
    80004c60:	7726                	ld	a4,104(sp)
    80004c62:	77c6                	ld	a5,112(sp)
    80004c64:	7866                	ld	a6,120(sp)
    80004c66:	688a                	ld	a7,128(sp)
    80004c68:	6e6e                	ld	t3,216(sp)
    80004c6a:	7e8e                	ld	t4,224(sp)
    80004c6c:	7f2e                	ld	t5,232(sp)
    80004c6e:	7fce                	ld	t6,240(sp)
    80004c70:	6111                	addi	sp,sp,256
    80004c72:	10200073          	sret
    80004c76:	00000013          	nop
    80004c7a:	00000013          	nop

0000000080004c7e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80004c7e:	1141                	addi	sp,sp,-16
    80004c80:	e406                	sd	ra,8(sp)
    80004c82:	e022                	sd	s0,0(sp)
    80004c84:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004c86:	0c000737          	lui	a4,0xc000
    80004c8a:	4785                	li	a5,1
    80004c8c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    80004c8e:	c35c                	sw	a5,4(a4)
}
    80004c90:	60a2                	ld	ra,8(sp)
    80004c92:	6402                	ld	s0,0(sp)
    80004c94:	0141                	addi	sp,sp,16
    80004c96:	8082                	ret

0000000080004c98 <plicinithart>:

void
plicinithart(void)
{
    80004c98:	1141                	addi	sp,sp,-16
    80004c9a:	e406                	sd	ra,8(sp)
    80004c9c:	e022                	sd	s0,0(sp)
    80004c9e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004ca0:	890fc0ef          	jal	80000d30 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80004ca4:	0085171b          	slliw	a4,a0,0x8
    80004ca8:	0c0027b7          	lui	a5,0xc002
    80004cac:	97ba                	add	a5,a5,a4
    80004cae:	40200713          	li	a4,1026
    80004cb2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80004cb6:	00d5151b          	slliw	a0,a0,0xd
    80004cba:	0c2017b7          	lui	a5,0xc201
    80004cbe:	97aa                	add	a5,a5,a0
    80004cc0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80004cc4:	60a2                	ld	ra,8(sp)
    80004cc6:	6402                	ld	s0,0(sp)
    80004cc8:	0141                	addi	sp,sp,16
    80004cca:	8082                	ret

0000000080004ccc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80004ccc:	1141                	addi	sp,sp,-16
    80004cce:	e406                	sd	ra,8(sp)
    80004cd0:	e022                	sd	s0,0(sp)
    80004cd2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004cd4:	85cfc0ef          	jal	80000d30 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80004cd8:	00d5151b          	slliw	a0,a0,0xd
    80004cdc:	0c2017b7          	lui	a5,0xc201
    80004ce0:	97aa                	add	a5,a5,a0
  return irq;
}
    80004ce2:	43c8                	lw	a0,4(a5)
    80004ce4:	60a2                	ld	ra,8(sp)
    80004ce6:	6402                	ld	s0,0(sp)
    80004ce8:	0141                	addi	sp,sp,16
    80004cea:	8082                	ret

0000000080004cec <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80004cec:	1101                	addi	sp,sp,-32
    80004cee:	ec06                	sd	ra,24(sp)
    80004cf0:	e822                	sd	s0,16(sp)
    80004cf2:	e426                	sd	s1,8(sp)
    80004cf4:	1000                	addi	s0,sp,32
    80004cf6:	84aa                	mv	s1,a0
  int hart = cpuid();
    80004cf8:	838fc0ef          	jal	80000d30 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80004cfc:	00d5179b          	slliw	a5,a0,0xd
    80004d00:	0c201737          	lui	a4,0xc201
    80004d04:	97ba                	add	a5,a5,a4
    80004d06:	c3c4                	sw	s1,4(a5)
}
    80004d08:	60e2                	ld	ra,24(sp)
    80004d0a:	6442                	ld	s0,16(sp)
    80004d0c:	64a2                	ld	s1,8(sp)
    80004d0e:	6105                	addi	sp,sp,32
    80004d10:	8082                	ret

0000000080004d12 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80004d12:	1141                	addi	sp,sp,-16
    80004d14:	e406                	sd	ra,8(sp)
    80004d16:	e022                	sd	s0,0(sp)
    80004d18:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80004d1a:	479d                	li	a5,7
    80004d1c:	04a7ca63          	blt	a5,a0,80004d70 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80004d20:	00020797          	auipc	a5,0x20
    80004d24:	cd078793          	addi	a5,a5,-816 # 800249f0 <disk>
    80004d28:	97aa                	add	a5,a5,a0
    80004d2a:	0187c783          	lbu	a5,24(a5)
    80004d2e:	e7b9                	bnez	a5,80004d7c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80004d30:	00451693          	slli	a3,a0,0x4
    80004d34:	00020797          	auipc	a5,0x20
    80004d38:	cbc78793          	addi	a5,a5,-836 # 800249f0 <disk>
    80004d3c:	6398                	ld	a4,0(a5)
    80004d3e:	9736                	add	a4,a4,a3
    80004d40:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80004d44:	6398                	ld	a4,0(a5)
    80004d46:	9736                	add	a4,a4,a3
    80004d48:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80004d4c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80004d50:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004d54:	97aa                	add	a5,a5,a0
    80004d56:	4705                	li	a4,1
    80004d58:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80004d5c:	00020517          	auipc	a0,0x20
    80004d60:	cac50513          	addi	a0,a0,-852 # 80024a08 <disk+0x18>
    80004d64:	e9afc0ef          	jal	800013fe <wakeup>
}
    80004d68:	60a2                	ld	ra,8(sp)
    80004d6a:	6402                	ld	s0,0(sp)
    80004d6c:	0141                	addi	sp,sp,16
    80004d6e:	8082                	ret
    panic("free_desc 1");
    80004d70:	00003517          	auipc	a0,0x3
    80004d74:	88850513          	addi	a0,a0,-1912 # 800075f8 <etext+0x5f8>
    80004d78:	457000ef          	jal	800059ce <panic>
    panic("free_desc 2");
    80004d7c:	00003517          	auipc	a0,0x3
    80004d80:	88c50513          	addi	a0,a0,-1908 # 80007608 <etext+0x608>
    80004d84:	44b000ef          	jal	800059ce <panic>

0000000080004d88 <virtio_disk_init>:
{
    80004d88:	1101                	addi	sp,sp,-32
    80004d8a:	ec06                	sd	ra,24(sp)
    80004d8c:	e822                	sd	s0,16(sp)
    80004d8e:	e426                	sd	s1,8(sp)
    80004d90:	e04a                	sd	s2,0(sp)
    80004d92:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004d94:	00003597          	auipc	a1,0x3
    80004d98:	88458593          	addi	a1,a1,-1916 # 80007618 <etext+0x618>
    80004d9c:	00020517          	auipc	a0,0x20
    80004da0:	d7c50513          	addi	a0,a0,-644 # 80024b18 <disk+0x128>
    80004da4:	6df000ef          	jal	80005c82 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004da8:	100017b7          	lui	a5,0x10001
    80004dac:	4398                	lw	a4,0(a5)
    80004dae:	2701                	sext.w	a4,a4
    80004db0:	747277b7          	lui	a5,0x74727
    80004db4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80004db8:	14f71863          	bne	a4,a5,80004f08 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004dbc:	100017b7          	lui	a5,0x10001
    80004dc0:	43dc                	lw	a5,4(a5)
    80004dc2:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004dc4:	4709                	li	a4,2
    80004dc6:	14e79163          	bne	a5,a4,80004f08 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004dca:	100017b7          	lui	a5,0x10001
    80004dce:	479c                	lw	a5,8(a5)
    80004dd0:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004dd2:	12e79b63          	bne	a5,a4,80004f08 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80004dd6:	100017b7          	lui	a5,0x10001
    80004dda:	47d8                	lw	a4,12(a5)
    80004ddc:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004dde:	554d47b7          	lui	a5,0x554d4
    80004de2:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80004de6:	12f71163          	bne	a4,a5,80004f08 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004dea:	100017b7          	lui	a5,0x10001
    80004dee:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004df2:	4705                	li	a4,1
    80004df4:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004df6:	470d                	li	a4,3
    80004df8:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80004dfa:	10001737          	lui	a4,0x10001
    80004dfe:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80004e00:	c7ffe6b7          	lui	a3,0xc7ffe
    80004e04:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fd1b2f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80004e08:	8f75                	and	a4,a4,a3
    80004e0a:	100016b7          	lui	a3,0x10001
    80004e0e:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004e10:	472d                	li	a4,11
    80004e12:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004e14:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80004e18:	439c                	lw	a5,0(a5)
    80004e1a:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80004e1e:	8ba1                	andi	a5,a5,8
    80004e20:	0e078a63          	beqz	a5,80004f14 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80004e24:	100017b7          	lui	a5,0x10001
    80004e28:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80004e2c:	43fc                	lw	a5,68(a5)
    80004e2e:	2781                	sext.w	a5,a5
    80004e30:	0e079863          	bnez	a5,80004f20 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80004e34:	100017b7          	lui	a5,0x10001
    80004e38:	5bdc                	lw	a5,52(a5)
    80004e3a:	2781                	sext.w	a5,a5
  if(max == 0)
    80004e3c:	0e078863          	beqz	a5,80004f2c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80004e40:	471d                	li	a4,7
    80004e42:	0ef77b63          	bgeu	a4,a5,80004f38 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80004e46:	abefb0ef          	jal	80000104 <kalloc>
    80004e4a:	00020497          	auipc	s1,0x20
    80004e4e:	ba648493          	addi	s1,s1,-1114 # 800249f0 <disk>
    80004e52:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004e54:	ab0fb0ef          	jal	80000104 <kalloc>
    80004e58:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004e5a:	aaafb0ef          	jal	80000104 <kalloc>
    80004e5e:	87aa                	mv	a5,a0
    80004e60:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004e62:	6088                	ld	a0,0(s1)
    80004e64:	0e050063          	beqz	a0,80004f44 <virtio_disk_init+0x1bc>
    80004e68:	00020717          	auipc	a4,0x20
    80004e6c:	b9073703          	ld	a4,-1136(a4) # 800249f8 <disk+0x8>
    80004e70:	cb71                	beqz	a4,80004f44 <virtio_disk_init+0x1bc>
    80004e72:	cbe9                	beqz	a5,80004f44 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80004e74:	6605                	lui	a2,0x1
    80004e76:	4581                	li	a1,0
    80004e78:	ae6fb0ef          	jal	8000015e <memset>
  memset(disk.avail, 0, PGSIZE);
    80004e7c:	00020497          	auipc	s1,0x20
    80004e80:	b7448493          	addi	s1,s1,-1164 # 800249f0 <disk>
    80004e84:	6605                	lui	a2,0x1
    80004e86:	4581                	li	a1,0
    80004e88:	6488                	ld	a0,8(s1)
    80004e8a:	ad4fb0ef          	jal	8000015e <memset>
  memset(disk.used, 0, PGSIZE);
    80004e8e:	6605                	lui	a2,0x1
    80004e90:	4581                	li	a1,0
    80004e92:	6888                	ld	a0,16(s1)
    80004e94:	acafb0ef          	jal	8000015e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004e98:	100017b7          	lui	a5,0x10001
    80004e9c:	4721                	li	a4,8
    80004e9e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004ea0:	4098                	lw	a4,0(s1)
    80004ea2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004ea6:	40d8                	lw	a4,4(s1)
    80004ea8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80004eac:	649c                	ld	a5,8(s1)
    80004eae:	0007869b          	sext.w	a3,a5
    80004eb2:	10001737          	lui	a4,0x10001
    80004eb6:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80004eba:	9781                	srai	a5,a5,0x20
    80004ebc:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80004ec0:	689c                	ld	a5,16(s1)
    80004ec2:	0007869b          	sext.w	a3,a5
    80004ec6:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80004eca:	9781                	srai	a5,a5,0x20
    80004ecc:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80004ed0:	4785                	li	a5,1
    80004ed2:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80004ed4:	00f48c23          	sb	a5,24(s1)
    80004ed8:	00f48ca3          	sb	a5,25(s1)
    80004edc:	00f48d23          	sb	a5,26(s1)
    80004ee0:	00f48da3          	sb	a5,27(s1)
    80004ee4:	00f48e23          	sb	a5,28(s1)
    80004ee8:	00f48ea3          	sb	a5,29(s1)
    80004eec:	00f48f23          	sb	a5,30(s1)
    80004ef0:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80004ef4:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80004ef8:	07272823          	sw	s2,112(a4)
}
    80004efc:	60e2                	ld	ra,24(sp)
    80004efe:	6442                	ld	s0,16(sp)
    80004f00:	64a2                	ld	s1,8(sp)
    80004f02:	6902                	ld	s2,0(sp)
    80004f04:	6105                	addi	sp,sp,32
    80004f06:	8082                	ret
    panic("could not find virtio disk");
    80004f08:	00002517          	auipc	a0,0x2
    80004f0c:	72050513          	addi	a0,a0,1824 # 80007628 <etext+0x628>
    80004f10:	2bf000ef          	jal	800059ce <panic>
    panic("virtio disk FEATURES_OK unset");
    80004f14:	00002517          	auipc	a0,0x2
    80004f18:	73450513          	addi	a0,a0,1844 # 80007648 <etext+0x648>
    80004f1c:	2b3000ef          	jal	800059ce <panic>
    panic("virtio disk should not be ready");
    80004f20:	00002517          	auipc	a0,0x2
    80004f24:	74850513          	addi	a0,a0,1864 # 80007668 <etext+0x668>
    80004f28:	2a7000ef          	jal	800059ce <panic>
    panic("virtio disk has no queue 0");
    80004f2c:	00002517          	auipc	a0,0x2
    80004f30:	75c50513          	addi	a0,a0,1884 # 80007688 <etext+0x688>
    80004f34:	29b000ef          	jal	800059ce <panic>
    panic("virtio disk max queue too short");
    80004f38:	00002517          	auipc	a0,0x2
    80004f3c:	77050513          	addi	a0,a0,1904 # 800076a8 <etext+0x6a8>
    80004f40:	28f000ef          	jal	800059ce <panic>
    panic("virtio disk kalloc");
    80004f44:	00002517          	auipc	a0,0x2
    80004f48:	78450513          	addi	a0,a0,1924 # 800076c8 <etext+0x6c8>
    80004f4c:	283000ef          	jal	800059ce <panic>

0000000080004f50 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004f50:	711d                	addi	sp,sp,-96
    80004f52:	ec86                	sd	ra,88(sp)
    80004f54:	e8a2                	sd	s0,80(sp)
    80004f56:	e4a6                	sd	s1,72(sp)
    80004f58:	e0ca                	sd	s2,64(sp)
    80004f5a:	fc4e                	sd	s3,56(sp)
    80004f5c:	f852                	sd	s4,48(sp)
    80004f5e:	f456                	sd	s5,40(sp)
    80004f60:	f05a                	sd	s6,32(sp)
    80004f62:	ec5e                	sd	s7,24(sp)
    80004f64:	e862                	sd	s8,16(sp)
    80004f66:	1080                	addi	s0,sp,96
    80004f68:	89aa                	mv	s3,a0
    80004f6a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004f6c:	00c52b83          	lw	s7,12(a0)
    80004f70:	001b9b9b          	slliw	s7,s7,0x1
    80004f74:	1b82                	slli	s7,s7,0x20
    80004f76:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80004f7a:	00020517          	auipc	a0,0x20
    80004f7e:	b9e50513          	addi	a0,a0,-1122 # 80024b18 <disk+0x128>
    80004f82:	58b000ef          	jal	80005d0c <acquire>
  for(int i = 0; i < NUM; i++){
    80004f86:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004f88:	00020a97          	auipc	s5,0x20
    80004f8c:	a68a8a93          	addi	s5,s5,-1432 # 800249f0 <disk>
  for(int i = 0; i < 3; i++){
    80004f90:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80004f92:	5c7d                	li	s8,-1
    80004f94:	a095                	j	80004ff8 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80004f96:	00fa8733          	add	a4,s5,a5
    80004f9a:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004f9e:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004fa0:	0207c563          	bltz	a5,80004fca <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80004fa4:	2905                	addiw	s2,s2,1
    80004fa6:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80004fa8:	05490c63          	beq	s2,s4,80005000 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    80004fac:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004fae:	00020717          	auipc	a4,0x20
    80004fb2:	a4270713          	addi	a4,a4,-1470 # 800249f0 <disk>
    80004fb6:	4781                	li	a5,0
    if(disk.free[i]){
    80004fb8:	01874683          	lbu	a3,24(a4)
    80004fbc:	fee9                	bnez	a3,80004f96 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80004fbe:	2785                	addiw	a5,a5,1
    80004fc0:	0705                	addi	a4,a4,1
    80004fc2:	fe979be3          	bne	a5,s1,80004fb8 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80004fc6:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80004fca:	01205d63          	blez	s2,80004fe4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004fce:	fa042503          	lw	a0,-96(s0)
    80004fd2:	d41ff0ef          	jal	80004d12 <free_desc>
      for(int j = 0; j < i; j++)
    80004fd6:	4785                	li	a5,1
    80004fd8:	0127d663          	bge	a5,s2,80004fe4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004fdc:	fa442503          	lw	a0,-92(s0)
    80004fe0:	d33ff0ef          	jal	80004d12 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004fe4:	00020597          	auipc	a1,0x20
    80004fe8:	b3458593          	addi	a1,a1,-1228 # 80024b18 <disk+0x128>
    80004fec:	00020517          	auipc	a0,0x20
    80004ff0:	a1c50513          	addi	a0,a0,-1508 # 80024a08 <disk+0x18>
    80004ff4:	bbefc0ef          	jal	800013b2 <sleep>
  for(int i = 0; i < 3; i++){
    80004ff8:	fa040613          	addi	a2,s0,-96
    80004ffc:	4901                	li	s2,0
    80004ffe:	b77d                	j	80004fac <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005000:	fa042503          	lw	a0,-96(s0)
    80005004:	00451693          	slli	a3,a0,0x4

  if(write)
    80005008:	00020797          	auipc	a5,0x20
    8000500c:	9e878793          	addi	a5,a5,-1560 # 800249f0 <disk>
    80005010:	00451713          	slli	a4,a0,0x4
    80005014:	0a070713          	addi	a4,a4,160
    80005018:	973e                	add	a4,a4,a5
    8000501a:	01603633          	snez	a2,s6
    8000501e:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005020:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005024:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005028:	6398                	ld	a4,0(a5)
    8000502a:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000502c:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005030:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005032:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005034:	6390                	ld	a2,0(a5)
    80005036:	00d60833          	add	a6,a2,a3
    8000503a:	4741                	li	a4,16
    8000503c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005040:	4585                	li	a1,1
    80005042:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80005046:	fa442703          	lw	a4,-92(s0)
    8000504a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    8000504e:	0712                	slli	a4,a4,0x4
    80005050:	963a                	add	a2,a2,a4
    80005052:	05898813          	addi	a6,s3,88
    80005056:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    8000505a:	0007b883          	ld	a7,0(a5)
    8000505e:	9746                	add	a4,a4,a7
    80005060:	40000613          	li	a2,1024
    80005064:	c710                	sw	a2,8(a4)
  if(write)
    80005066:	001b3613          	seqz	a2,s6
    8000506a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000506e:	8e4d                	or	a2,a2,a1
    80005070:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005074:	fa842603          	lw	a2,-88(s0)
    80005078:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000507c:	00451813          	slli	a6,a0,0x4
    80005080:	02080813          	addi	a6,a6,32
    80005084:	983e                	add	a6,a6,a5
    80005086:	577d                	li	a4,-1
    80005088:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000508c:	0612                	slli	a2,a2,0x4
    8000508e:	98b2                	add	a7,a7,a2
    80005090:	03068713          	addi	a4,a3,48
    80005094:	973e                	add	a4,a4,a5
    80005096:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    8000509a:	6398                	ld	a4,0(a5)
    8000509c:	9732                	add	a4,a4,a2
    8000509e:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    800050a0:	4689                	li	a3,2
    800050a2:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    800050a6:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    800050aa:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    800050ae:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    800050b2:	6794                	ld	a3,8(a5)
    800050b4:	0026d703          	lhu	a4,2(a3)
    800050b8:	8b1d                	andi	a4,a4,7
    800050ba:	0706                	slli	a4,a4,0x1
    800050bc:	96ba                	add	a3,a3,a4
    800050be:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    800050c2:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    800050c6:	6798                	ld	a4,8(a5)
    800050c8:	00275783          	lhu	a5,2(a4)
    800050cc:	2785                	addiw	a5,a5,1
    800050ce:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    800050d2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    800050d6:	100017b7          	lui	a5,0x10001
    800050da:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    800050de:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    800050e2:	00020917          	auipc	s2,0x20
    800050e6:	a3690913          	addi	s2,s2,-1482 # 80024b18 <disk+0x128>
  while(b->disk == 1) {
    800050ea:	84ae                	mv	s1,a1
    800050ec:	00b79a63          	bne	a5,a1,80005100 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    800050f0:	85ca                	mv	a1,s2
    800050f2:	854e                	mv	a0,s3
    800050f4:	abefc0ef          	jal	800013b2 <sleep>
  while(b->disk == 1) {
    800050f8:	0049a783          	lw	a5,4(s3)
    800050fc:	fe978ae3          	beq	a5,s1,800050f0 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005100:	fa042903          	lw	s2,-96(s0)
    80005104:	00491713          	slli	a4,s2,0x4
    80005108:	02070713          	addi	a4,a4,32
    8000510c:	00020797          	auipc	a5,0x20
    80005110:	8e478793          	addi	a5,a5,-1820 # 800249f0 <disk>
    80005114:	97ba                	add	a5,a5,a4
    80005116:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    8000511a:	00020997          	auipc	s3,0x20
    8000511e:	8d698993          	addi	s3,s3,-1834 # 800249f0 <disk>
    80005122:	00491713          	slli	a4,s2,0x4
    80005126:	0009b783          	ld	a5,0(s3)
    8000512a:	97ba                	add	a5,a5,a4
    8000512c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005130:	854a                	mv	a0,s2
    80005132:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005136:	bddff0ef          	jal	80004d12 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    8000513a:	8885                	andi	s1,s1,1
    8000513c:	f0fd                	bnez	s1,80005122 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000513e:	00020517          	auipc	a0,0x20
    80005142:	9da50513          	addi	a0,a0,-1574 # 80024b18 <disk+0x128>
    80005146:	45b000ef          	jal	80005da0 <release>
}
    8000514a:	60e6                	ld	ra,88(sp)
    8000514c:	6446                	ld	s0,80(sp)
    8000514e:	64a6                	ld	s1,72(sp)
    80005150:	6906                	ld	s2,64(sp)
    80005152:	79e2                	ld	s3,56(sp)
    80005154:	7a42                	ld	s4,48(sp)
    80005156:	7aa2                	ld	s5,40(sp)
    80005158:	7b02                	ld	s6,32(sp)
    8000515a:	6be2                	ld	s7,24(sp)
    8000515c:	6c42                	ld	s8,16(sp)
    8000515e:	6125                	addi	sp,sp,96
    80005160:	8082                	ret

0000000080005162 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005162:	1101                	addi	sp,sp,-32
    80005164:	ec06                	sd	ra,24(sp)
    80005166:	e822                	sd	s0,16(sp)
    80005168:	e426                	sd	s1,8(sp)
    8000516a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000516c:	00020497          	auipc	s1,0x20
    80005170:	88448493          	addi	s1,s1,-1916 # 800249f0 <disk>
    80005174:	00020517          	auipc	a0,0x20
    80005178:	9a450513          	addi	a0,a0,-1628 # 80024b18 <disk+0x128>
    8000517c:	391000ef          	jal	80005d0c <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005180:	100017b7          	lui	a5,0x10001
    80005184:	53bc                	lw	a5,96(a5)
    80005186:	8b8d                	andi	a5,a5,3
    80005188:	10001737          	lui	a4,0x10001
    8000518c:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    8000518e:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005192:	689c                	ld	a5,16(s1)
    80005194:	0204d703          	lhu	a4,32(s1)
    80005198:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    8000519c:	04f70863          	beq	a4,a5,800051ec <virtio_disk_intr+0x8a>
    __sync_synchronize();
    800051a0:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    800051a4:	6898                	ld	a4,16(s1)
    800051a6:	0204d783          	lhu	a5,32(s1)
    800051aa:	8b9d                	andi	a5,a5,7
    800051ac:	078e                	slli	a5,a5,0x3
    800051ae:	97ba                	add	a5,a5,a4
    800051b0:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    800051b2:	00479713          	slli	a4,a5,0x4
    800051b6:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    800051ba:	9726                	add	a4,a4,s1
    800051bc:	01074703          	lbu	a4,16(a4)
    800051c0:	e329                	bnez	a4,80005202 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    800051c2:	0792                	slli	a5,a5,0x4
    800051c4:	02078793          	addi	a5,a5,32
    800051c8:	97a6                	add	a5,a5,s1
    800051ca:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    800051cc:	00052223          	sw	zero,4(a0)
    wakeup(b);
    800051d0:	a2efc0ef          	jal	800013fe <wakeup>

    disk.used_idx += 1;
    800051d4:	0204d783          	lhu	a5,32(s1)
    800051d8:	2785                	addiw	a5,a5,1
    800051da:	17c2                	slli	a5,a5,0x30
    800051dc:	93c1                	srli	a5,a5,0x30
    800051de:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    800051e2:	6898                	ld	a4,16(s1)
    800051e4:	00275703          	lhu	a4,2(a4)
    800051e8:	faf71ce3          	bne	a4,a5,800051a0 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    800051ec:	00020517          	auipc	a0,0x20
    800051f0:	92c50513          	addi	a0,a0,-1748 # 80024b18 <disk+0x128>
    800051f4:	3ad000ef          	jal	80005da0 <release>
}
    800051f8:	60e2                	ld	ra,24(sp)
    800051fa:	6442                	ld	s0,16(sp)
    800051fc:	64a2                	ld	s1,8(sp)
    800051fe:	6105                	addi	sp,sp,32
    80005200:	8082                	ret
      panic("virtio_disk_intr status");
    80005202:	00002517          	auipc	a0,0x2
    80005206:	4de50513          	addi	a0,a0,1246 # 800076e0 <etext+0x6e0>
    8000520a:	7c4000ef          	jal	800059ce <panic>

000000008000520e <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000520e:	1141                	addi	sp,sp,-16
    80005210:	e406                	sd	ra,8(sp)
    80005212:	e022                	sd	s0,0(sp)
    80005214:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80005216:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    8000521a:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    8000521e:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80005222:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80005226:	577d                	li	a4,-1
    80005228:	177e                	slli	a4,a4,0x3f
    8000522a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000522c:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80005230:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80005234:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80005238:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    8000523c:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80005240:	000f4737          	lui	a4,0xf4
    80005244:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80005248:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    8000524a:	14d79073          	csrw	stimecmp,a5
}
    8000524e:	60a2                	ld	ra,8(sp)
    80005250:	6402                	ld	s0,0(sp)
    80005252:	0141                	addi	sp,sp,16
    80005254:	8082                	ret

0000000080005256 <start>:
{
    80005256:	1141                	addi	sp,sp,-16
    80005258:	e406                	sd	ra,8(sp)
    8000525a:	e022                	sd	s0,0(sp)
    8000525c:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000525e:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80005262:	7779                	lui	a4,0xffffe
    80005264:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffd1bcf>
    80005268:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000526a:	6705                	lui	a4,0x1
    8000526c:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80005270:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80005272:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80005276:	ffffb797          	auipc	a5,0xffffb
    8000527a:	09e78793          	addi	a5,a5,158 # 80000314 <main>
    8000527e:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80005282:	4781                	li	a5,0
    80005284:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80005288:	67c1                	lui	a5,0x10
    8000528a:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000528c:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80005290:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80005294:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80005298:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    8000529c:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800052a0:	57fd                	li	a5,-1
    800052a2:	83a9                	srli	a5,a5,0xa
    800052a4:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800052a8:	47bd                	li	a5,15
    800052aa:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800052ae:	f61ff0ef          	jal	8000520e <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800052b2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800052b6:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    800052b8:	823e                	mv	tp,a5
  asm volatile("mret");
    800052ba:	30200073          	mret
}
    800052be:	60a2                	ld	ra,8(sp)
    800052c0:	6402                	ld	s0,0(sp)
    800052c2:	0141                	addi	sp,sp,16
    800052c4:	8082                	ret

00000000800052c6 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800052c6:	711d                	addi	sp,sp,-96
    800052c8:	ec86                	sd	ra,88(sp)
    800052ca:	e8a2                	sd	s0,80(sp)
    800052cc:	e0ca                	sd	s2,64(sp)
    800052ce:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    800052d0:	04c05763          	blez	a2,8000531e <consolewrite+0x58>
    800052d4:	e4a6                	sd	s1,72(sp)
    800052d6:	fc4e                	sd	s3,56(sp)
    800052d8:	f852                	sd	s4,48(sp)
    800052da:	f456                	sd	s5,40(sp)
    800052dc:	f05a                	sd	s6,32(sp)
    800052de:	ec5e                	sd	s7,24(sp)
    800052e0:	8a2a                	mv	s4,a0
    800052e2:	84ae                	mv	s1,a1
    800052e4:	89b2                	mv	s3,a2
    800052e6:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    800052e8:	faf40b93          	addi	s7,s0,-81
    800052ec:	4b05                	li	s6,1
    800052ee:	5afd                	li	s5,-1
    800052f0:	86da                	mv	a3,s6
    800052f2:	8626                	mv	a2,s1
    800052f4:	85d2                	mv	a1,s4
    800052f6:	855e                	mv	a0,s7
    800052f8:	d66fc0ef          	jal	8000185e <either_copyin>
    800052fc:	03550363          	beq	a0,s5,80005322 <consolewrite+0x5c>
      break;
    uartputc(c);
    80005300:	faf44503          	lbu	a0,-81(s0)
    80005304:	06b000ef          	jal	80005b6e <uartputc>
  for(i = 0; i < n; i++){
    80005308:	2905                	addiw	s2,s2,1
    8000530a:	0485                	addi	s1,s1,1
    8000530c:	ff2992e3          	bne	s3,s2,800052f0 <consolewrite+0x2a>
    80005310:	64a6                	ld	s1,72(sp)
    80005312:	79e2                	ld	s3,56(sp)
    80005314:	7a42                	ld	s4,48(sp)
    80005316:	7aa2                	ld	s5,40(sp)
    80005318:	7b02                	ld	s6,32(sp)
    8000531a:	6be2                	ld	s7,24(sp)
    8000531c:	a809                	j	8000532e <consolewrite+0x68>
    8000531e:	4901                	li	s2,0
    80005320:	a039                	j	8000532e <consolewrite+0x68>
    80005322:	64a6                	ld	s1,72(sp)
    80005324:	79e2                	ld	s3,56(sp)
    80005326:	7a42                	ld	s4,48(sp)
    80005328:	7aa2                	ld	s5,40(sp)
    8000532a:	7b02                	ld	s6,32(sp)
    8000532c:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    8000532e:	854a                	mv	a0,s2
    80005330:	60e6                	ld	ra,88(sp)
    80005332:	6446                	ld	s0,80(sp)
    80005334:	6906                	ld	s2,64(sp)
    80005336:	6125                	addi	sp,sp,96
    80005338:	8082                	ret

000000008000533a <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000533a:	711d                	addi	sp,sp,-96
    8000533c:	ec86                	sd	ra,88(sp)
    8000533e:	e8a2                	sd	s0,80(sp)
    80005340:	e4a6                	sd	s1,72(sp)
    80005342:	e0ca                	sd	s2,64(sp)
    80005344:	fc4e                	sd	s3,56(sp)
    80005346:	f852                	sd	s4,48(sp)
    80005348:	f05a                	sd	s6,32(sp)
    8000534a:	ec5e                	sd	s7,24(sp)
    8000534c:	1080                	addi	s0,sp,96
    8000534e:	8b2a                	mv	s6,a0
    80005350:	8a2e                	mv	s4,a1
    80005352:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80005354:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80005356:	00027517          	auipc	a0,0x27
    8000535a:	7da50513          	addi	a0,a0,2010 # 8002cb30 <cons>
    8000535e:	1af000ef          	jal	80005d0c <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80005362:	00027497          	auipc	s1,0x27
    80005366:	7ce48493          	addi	s1,s1,1998 # 8002cb30 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    8000536a:	00028917          	auipc	s2,0x28
    8000536e:	85e90913          	addi	s2,s2,-1954 # 8002cbc8 <cons+0x98>
  while(n > 0){
    80005372:	0b305b63          	blez	s3,80005428 <consoleread+0xee>
    while(cons.r == cons.w){
    80005376:	0984a783          	lw	a5,152(s1)
    8000537a:	09c4a703          	lw	a4,156(s1)
    8000537e:	0af71063          	bne	a4,a5,8000541e <consoleread+0xe4>
      if(killed(myproc())){
    80005382:	9e3fb0ef          	jal	80000d64 <myproc>
    80005386:	b70fc0ef          	jal	800016f6 <killed>
    8000538a:	e12d                	bnez	a0,800053ec <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    8000538c:	85a6                	mv	a1,s1
    8000538e:	854a                	mv	a0,s2
    80005390:	822fc0ef          	jal	800013b2 <sleep>
    while(cons.r == cons.w){
    80005394:	0984a783          	lw	a5,152(s1)
    80005398:	09c4a703          	lw	a4,156(s1)
    8000539c:	fef703e3          	beq	a4,a5,80005382 <consoleread+0x48>
    800053a0:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800053a2:	00027717          	auipc	a4,0x27
    800053a6:	78e70713          	addi	a4,a4,1934 # 8002cb30 <cons>
    800053aa:	0017869b          	addiw	a3,a5,1
    800053ae:	08d72c23          	sw	a3,152(a4)
    800053b2:	07f7f693          	andi	a3,a5,127
    800053b6:	9736                	add	a4,a4,a3
    800053b8:	01874703          	lbu	a4,24(a4)
    800053bc:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800053c0:	4691                	li	a3,4
    800053c2:	04da8663          	beq	s5,a3,8000540e <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800053c6:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800053ca:	4685                	li	a3,1
    800053cc:	faf40613          	addi	a2,s0,-81
    800053d0:	85d2                	mv	a1,s4
    800053d2:	855a                	mv	a0,s6
    800053d4:	c40fc0ef          	jal	80001814 <either_copyout>
    800053d8:	57fd                	li	a5,-1
    800053da:	04f50663          	beq	a0,a5,80005426 <consoleread+0xec>
      break;

    dst++;
    800053de:	0a05                	addi	s4,s4,1 # 1001 <_entry-0x7fffefff>
    --n;
    800053e0:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    800053e2:	47a9                	li	a5,10
    800053e4:	04fa8b63          	beq	s5,a5,8000543a <consoleread+0x100>
    800053e8:	7aa2                	ld	s5,40(sp)
    800053ea:	b761                	j	80005372 <consoleread+0x38>
        release(&cons.lock);
    800053ec:	00027517          	auipc	a0,0x27
    800053f0:	74450513          	addi	a0,a0,1860 # 8002cb30 <cons>
    800053f4:	1ad000ef          	jal	80005da0 <release>
        return -1;
    800053f8:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    800053fa:	60e6                	ld	ra,88(sp)
    800053fc:	6446                	ld	s0,80(sp)
    800053fe:	64a6                	ld	s1,72(sp)
    80005400:	6906                	ld	s2,64(sp)
    80005402:	79e2                	ld	s3,56(sp)
    80005404:	7a42                	ld	s4,48(sp)
    80005406:	7b02                	ld	s6,32(sp)
    80005408:	6be2                	ld	s7,24(sp)
    8000540a:	6125                	addi	sp,sp,96
    8000540c:	8082                	ret
      if(n < target){
    8000540e:	0179fa63          	bgeu	s3,s7,80005422 <consoleread+0xe8>
        cons.r--;
    80005412:	00027717          	auipc	a4,0x27
    80005416:	7af72b23          	sw	a5,1974(a4) # 8002cbc8 <cons+0x98>
    8000541a:	7aa2                	ld	s5,40(sp)
    8000541c:	a031                	j	80005428 <consoleread+0xee>
    8000541e:	f456                	sd	s5,40(sp)
    80005420:	b749                	j	800053a2 <consoleread+0x68>
    80005422:	7aa2                	ld	s5,40(sp)
    80005424:	a011                	j	80005428 <consoleread+0xee>
    80005426:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80005428:	00027517          	auipc	a0,0x27
    8000542c:	70850513          	addi	a0,a0,1800 # 8002cb30 <cons>
    80005430:	171000ef          	jal	80005da0 <release>
  return target - n;
    80005434:	413b853b          	subw	a0,s7,s3
    80005438:	b7c9                	j	800053fa <consoleread+0xc0>
    8000543a:	7aa2                	ld	s5,40(sp)
    8000543c:	b7f5                	j	80005428 <consoleread+0xee>

000000008000543e <consputc>:
{
    8000543e:	1141                	addi	sp,sp,-16
    80005440:	e406                	sd	ra,8(sp)
    80005442:	e022                	sd	s0,0(sp)
    80005444:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80005446:	10000793          	li	a5,256
    8000544a:	00f50863          	beq	a0,a5,8000545a <consputc+0x1c>
    uartputc_sync(c);
    8000544e:	63e000ef          	jal	80005a8c <uartputc_sync>
}
    80005452:	60a2                	ld	ra,8(sp)
    80005454:	6402                	ld	s0,0(sp)
    80005456:	0141                	addi	sp,sp,16
    80005458:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000545a:	4521                	li	a0,8
    8000545c:	630000ef          	jal	80005a8c <uartputc_sync>
    80005460:	02000513          	li	a0,32
    80005464:	628000ef          	jal	80005a8c <uartputc_sync>
    80005468:	4521                	li	a0,8
    8000546a:	622000ef          	jal	80005a8c <uartputc_sync>
    8000546e:	b7d5                	j	80005452 <consputc+0x14>

0000000080005470 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80005470:	1101                	addi	sp,sp,-32
    80005472:	ec06                	sd	ra,24(sp)
    80005474:	e822                	sd	s0,16(sp)
    80005476:	e426                	sd	s1,8(sp)
    80005478:	1000                	addi	s0,sp,32
    8000547a:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    8000547c:	00027517          	auipc	a0,0x27
    80005480:	6b450513          	addi	a0,a0,1716 # 8002cb30 <cons>
    80005484:	089000ef          	jal	80005d0c <acquire>

  switch(c){
    80005488:	47d5                	li	a5,21
    8000548a:	08f48d63          	beq	s1,a5,80005524 <consoleintr+0xb4>
    8000548e:	0297c563          	blt	a5,s1,800054b8 <consoleintr+0x48>
    80005492:	47a1                	li	a5,8
    80005494:	0ef48263          	beq	s1,a5,80005578 <consoleintr+0x108>
    80005498:	47c1                	li	a5,16
    8000549a:	10f49363          	bne	s1,a5,800055a0 <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    8000549e:	c0afc0ef          	jal	800018a8 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800054a2:	00027517          	auipc	a0,0x27
    800054a6:	68e50513          	addi	a0,a0,1678 # 8002cb30 <cons>
    800054aa:	0f7000ef          	jal	80005da0 <release>
}
    800054ae:	60e2                	ld	ra,24(sp)
    800054b0:	6442                	ld	s0,16(sp)
    800054b2:	64a2                	ld	s1,8(sp)
    800054b4:	6105                	addi	sp,sp,32
    800054b6:	8082                	ret
  switch(c){
    800054b8:	07f00793          	li	a5,127
    800054bc:	0af48e63          	beq	s1,a5,80005578 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800054c0:	00027717          	auipc	a4,0x27
    800054c4:	67070713          	addi	a4,a4,1648 # 8002cb30 <cons>
    800054c8:	0a072783          	lw	a5,160(a4)
    800054cc:	09872703          	lw	a4,152(a4)
    800054d0:	9f99                	subw	a5,a5,a4
    800054d2:	07f00713          	li	a4,127
    800054d6:	fcf766e3          	bltu	a4,a5,800054a2 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    800054da:	47b5                	li	a5,13
    800054dc:	0cf48563          	beq	s1,a5,800055a6 <consoleintr+0x136>
      consputc(c);
    800054e0:	8526                	mv	a0,s1
    800054e2:	f5dff0ef          	jal	8000543e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800054e6:	00027717          	auipc	a4,0x27
    800054ea:	64a70713          	addi	a4,a4,1610 # 8002cb30 <cons>
    800054ee:	0a072683          	lw	a3,160(a4)
    800054f2:	0016879b          	addiw	a5,a3,1
    800054f6:	863e                	mv	a2,a5
    800054f8:	0af72023          	sw	a5,160(a4)
    800054fc:	07f6f693          	andi	a3,a3,127
    80005500:	9736                	add	a4,a4,a3
    80005502:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80005506:	ff648713          	addi	a4,s1,-10
    8000550a:	c371                	beqz	a4,800055ce <consoleintr+0x15e>
    8000550c:	14f1                	addi	s1,s1,-4
    8000550e:	c0e1                	beqz	s1,800055ce <consoleintr+0x15e>
    80005510:	00027717          	auipc	a4,0x27
    80005514:	6b872703          	lw	a4,1720(a4) # 8002cbc8 <cons+0x98>
    80005518:	9f99                	subw	a5,a5,a4
    8000551a:	08000713          	li	a4,128
    8000551e:	f8e792e3          	bne	a5,a4,800054a2 <consoleintr+0x32>
    80005522:	a075                	j	800055ce <consoleintr+0x15e>
    80005524:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80005526:	00027717          	auipc	a4,0x27
    8000552a:	60a70713          	addi	a4,a4,1546 # 8002cb30 <cons>
    8000552e:	0a072783          	lw	a5,160(a4)
    80005532:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005536:	00027497          	auipc	s1,0x27
    8000553a:	5fa48493          	addi	s1,s1,1530 # 8002cb30 <cons>
    while(cons.e != cons.w &&
    8000553e:	4929                	li	s2,10
    80005540:	02f70863          	beq	a4,a5,80005570 <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005544:	37fd                	addiw	a5,a5,-1
    80005546:	07f7f713          	andi	a4,a5,127
    8000554a:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000554c:	01874703          	lbu	a4,24(a4)
    80005550:	03270263          	beq	a4,s2,80005574 <consoleintr+0x104>
      cons.e--;
    80005554:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005558:	10000513          	li	a0,256
    8000555c:	ee3ff0ef          	jal	8000543e <consputc>
    while(cons.e != cons.w &&
    80005560:	0a04a783          	lw	a5,160(s1)
    80005564:	09c4a703          	lw	a4,156(s1)
    80005568:	fcf71ee3          	bne	a4,a5,80005544 <consoleintr+0xd4>
    8000556c:	6902                	ld	s2,0(sp)
    8000556e:	bf15                	j	800054a2 <consoleintr+0x32>
    80005570:	6902                	ld	s2,0(sp)
    80005572:	bf05                	j	800054a2 <consoleintr+0x32>
    80005574:	6902                	ld	s2,0(sp)
    80005576:	b735                	j	800054a2 <consoleintr+0x32>
    if(cons.e != cons.w){
    80005578:	00027717          	auipc	a4,0x27
    8000557c:	5b870713          	addi	a4,a4,1464 # 8002cb30 <cons>
    80005580:	0a072783          	lw	a5,160(a4)
    80005584:	09c72703          	lw	a4,156(a4)
    80005588:	f0f70de3          	beq	a4,a5,800054a2 <consoleintr+0x32>
      cons.e--;
    8000558c:	37fd                	addiw	a5,a5,-1
    8000558e:	00027717          	auipc	a4,0x27
    80005592:	64f72123          	sw	a5,1602(a4) # 8002cbd0 <cons+0xa0>
      consputc(BACKSPACE);
    80005596:	10000513          	li	a0,256
    8000559a:	ea5ff0ef          	jal	8000543e <consputc>
    8000559e:	b711                	j	800054a2 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800055a0:	f00481e3          	beqz	s1,800054a2 <consoleintr+0x32>
    800055a4:	bf31                	j	800054c0 <consoleintr+0x50>
      consputc(c);
    800055a6:	4529                	li	a0,10
    800055a8:	e97ff0ef          	jal	8000543e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800055ac:	00027797          	auipc	a5,0x27
    800055b0:	58478793          	addi	a5,a5,1412 # 8002cb30 <cons>
    800055b4:	0a07a703          	lw	a4,160(a5)
    800055b8:	0017069b          	addiw	a3,a4,1
    800055bc:	8636                	mv	a2,a3
    800055be:	0ad7a023          	sw	a3,160(a5)
    800055c2:	07f77713          	andi	a4,a4,127
    800055c6:	97ba                	add	a5,a5,a4
    800055c8:	4729                	li	a4,10
    800055ca:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800055ce:	00027797          	auipc	a5,0x27
    800055d2:	5ec7af23          	sw	a2,1534(a5) # 8002cbcc <cons+0x9c>
        wakeup(&cons.r);
    800055d6:	00027517          	auipc	a0,0x27
    800055da:	5f250513          	addi	a0,a0,1522 # 8002cbc8 <cons+0x98>
    800055de:	e21fb0ef          	jal	800013fe <wakeup>
    800055e2:	b5c1                	j	800054a2 <consoleintr+0x32>

00000000800055e4 <consoleinit>:

void
consoleinit(void)
{
    800055e4:	1141                	addi	sp,sp,-16
    800055e6:	e406                	sd	ra,8(sp)
    800055e8:	e022                	sd	s0,0(sp)
    800055ea:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800055ec:	00002597          	auipc	a1,0x2
    800055f0:	10c58593          	addi	a1,a1,268 # 800076f8 <etext+0x6f8>
    800055f4:	00027517          	auipc	a0,0x27
    800055f8:	53c50513          	addi	a0,a0,1340 # 8002cb30 <cons>
    800055fc:	686000ef          	jal	80005c82 <initlock>

  uartinit();
    80005600:	436000ef          	jal	80005a36 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80005604:	0001e797          	auipc	a5,0x1e
    80005608:	39478793          	addi	a5,a5,916 # 80023998 <devsw>
    8000560c:	00000717          	auipc	a4,0x0
    80005610:	d2e70713          	addi	a4,a4,-722 # 8000533a <consoleread>
    80005614:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80005616:	00000717          	auipc	a4,0x0
    8000561a:	cb070713          	addi	a4,a4,-848 # 800052c6 <consolewrite>
    8000561e:	ef98                	sd	a4,24(a5)
}
    80005620:	60a2                	ld	ra,8(sp)
    80005622:	6402                	ld	s0,0(sp)
    80005624:	0141                	addi	sp,sp,16
    80005626:	8082                	ret

0000000080005628 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80005628:	7179                	addi	sp,sp,-48
    8000562a:	f406                	sd	ra,40(sp)
    8000562c:	f022                	sd	s0,32(sp)
    8000562e:	e84a                	sd	s2,16(sp)
    80005630:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80005632:	c219                	beqz	a2,80005638 <printint+0x10>
    80005634:	08054163          	bltz	a0,800056b6 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80005638:	4301                	li	t1,0

  i = 0;
    8000563a:	fd040913          	addi	s2,s0,-48
    x = xx;
    8000563e:	86ca                	mv	a3,s2
  i = 0;
    80005640:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005642:	00002817          	auipc	a6,0x2
    80005646:	21e80813          	addi	a6,a6,542 # 80007860 <digits>
    8000564a:	88ba                	mv	a7,a4
    8000564c:	0017061b          	addiw	a2,a4,1
    80005650:	8732                	mv	a4,a2
    80005652:	02b577b3          	remu	a5,a0,a1
    80005656:	97c2                	add	a5,a5,a6
    80005658:	0007c783          	lbu	a5,0(a5)
    8000565c:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005660:	87aa                	mv	a5,a0
    80005662:	02b55533          	divu	a0,a0,a1
    80005666:	0685                	addi	a3,a3,1
    80005668:	feb7f1e3          	bgeu	a5,a1,8000564a <printint+0x22>

  if(sign)
    8000566c:	00030c63          	beqz	t1,80005684 <printint+0x5c>
    buf[i++] = '-';
    80005670:	fe060793          	addi	a5,a2,-32
    80005674:	00878633          	add	a2,a5,s0
    80005678:	02d00793          	li	a5,45
    8000567c:	fef60823          	sb	a5,-16(a2)
    80005680:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80005684:	02e05463          	blez	a4,800056ac <printint+0x84>
    80005688:	ec26                	sd	s1,24(sp)
    8000568a:	377d                	addiw	a4,a4,-1
    8000568c:	00e904b3          	add	s1,s2,a4
    80005690:	197d                	addi	s2,s2,-1
    80005692:	993a                	add	s2,s2,a4
    80005694:	1702                	slli	a4,a4,0x20
    80005696:	9301                	srli	a4,a4,0x20
    80005698:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    8000569c:	0004c503          	lbu	a0,0(s1)
    800056a0:	d9fff0ef          	jal	8000543e <consputc>
  while(--i >= 0)
    800056a4:	14fd                	addi	s1,s1,-1
    800056a6:	ff249be3          	bne	s1,s2,8000569c <printint+0x74>
    800056aa:	64e2                	ld	s1,24(sp)
}
    800056ac:	70a2                	ld	ra,40(sp)
    800056ae:	7402                	ld	s0,32(sp)
    800056b0:	6942                	ld	s2,16(sp)
    800056b2:	6145                	addi	sp,sp,48
    800056b4:	8082                	ret
    x = -xx;
    800056b6:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800056ba:	4305                	li	t1,1
    x = -xx;
    800056bc:	bfbd                	j	8000563a <printint+0x12>

00000000800056be <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800056be:	7131                	addi	sp,sp,-192
    800056c0:	fc86                	sd	ra,120(sp)
    800056c2:	f8a2                	sd	s0,112(sp)
    800056c4:	f0ca                	sd	s2,96(sp)
    800056c6:	ec6e                	sd	s11,24(sp)
    800056c8:	0100                	addi	s0,sp,128
    800056ca:	892a                	mv	s2,a0
    800056cc:	e40c                	sd	a1,8(s0)
    800056ce:	e810                	sd	a2,16(s0)
    800056d0:	ec14                	sd	a3,24(s0)
    800056d2:	f018                	sd	a4,32(s0)
    800056d4:	f41c                	sd	a5,40(s0)
    800056d6:	03043823          	sd	a6,48(s0)
    800056da:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800056de:	00027d97          	auipc	s11,0x27
    800056e2:	512dad83          	lw	s11,1298(s11) # 8002cbf0 <pr+0x18>
  if(locking)
    800056e6:	020d9d63          	bnez	s11,80005720 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800056ea:	00840793          	addi	a5,s0,8
    800056ee:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800056f2:	00054503          	lbu	a0,0(a0)
    800056f6:	20050f63          	beqz	a0,80005914 <printf+0x256>
    800056fa:	f4a6                	sd	s1,104(sp)
    800056fc:	ecce                	sd	s3,88(sp)
    800056fe:	e8d2                	sd	s4,80(sp)
    80005700:	e4d6                	sd	s5,72(sp)
    80005702:	e0da                	sd	s6,64(sp)
    80005704:	fc5e                	sd	s7,56(sp)
    80005706:	f862                	sd	s8,48(sp)
    80005708:	f06a                	sd	s10,32(sp)
    8000570a:	4a81                	li	s5,0
    if(cx != '%'){
    8000570c:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80005710:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80005714:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    80005718:	4b29                	li	s6,10
    if(c0 == 'd'){
    8000571a:	06400b93          	li	s7,100
    8000571e:	a80d                	j	80005750 <printf+0x92>
    acquire(&pr.lock);
    80005720:	00027517          	auipc	a0,0x27
    80005724:	4b850513          	addi	a0,a0,1208 # 8002cbd8 <pr>
    80005728:	5e4000ef          	jal	80005d0c <acquire>
  va_start(ap, fmt);
    8000572c:	00840793          	addi	a5,s0,8
    80005730:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005734:	00094503          	lbu	a0,0(s2)
    80005738:	f169                	bnez	a0,800056fa <printf+0x3c>
    8000573a:	aae5                	j	80005932 <printf+0x274>
      consputc(cx);
    8000573c:	d03ff0ef          	jal	8000543e <consputc>
      continue;
    80005740:	84d6                	mv	s1,s5
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005742:	2485                	addiw	s1,s1,1
    80005744:	8aa6                	mv	s5,s1
    80005746:	94ca                	add	s1,s1,s2
    80005748:	0004c503          	lbu	a0,0(s1)
    8000574c:	1a050a63          	beqz	a0,80005900 <printf+0x242>
    if(cx != '%'){
    80005750:	ff3516e3          	bne	a0,s3,8000573c <printf+0x7e>
    i++;
    80005754:	001a879b          	addiw	a5,s5,1
    80005758:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000575a:	00f90733          	add	a4,s2,a5
    8000575e:	00074a03          	lbu	s4,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005762:	1e0a0863          	beqz	s4,80005952 <printf+0x294>
    80005766:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000576a:	1c068b63          	beqz	a3,80005940 <printf+0x282>
    if(c0 == 'd'){
    8000576e:	037a0863          	beq	s4,s7,8000579e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005772:	f94a0713          	addi	a4,s4,-108
    80005776:	00173713          	seqz	a4,a4
    8000577a:	f9c68613          	addi	a2,a3,-100
    8000577e:	ee05                	bnez	a2,800057b6 <printf+0xf8>
    80005780:	cb1d                	beqz	a4,800057b6 <printf+0xf8>
      printint(va_arg(ap, uint64), 10, 1);
    80005782:	f8843783          	ld	a5,-120(s0)
    80005786:	00878713          	addi	a4,a5,8
    8000578a:	f8e43423          	sd	a4,-120(s0)
    8000578e:	4605                	li	a2,1
    80005790:	85da                	mv	a1,s6
    80005792:	6388                	ld	a0,0(a5)
    80005794:	e95ff0ef          	jal	80005628 <printint>
      i += 1;
    80005798:	002a849b          	addiw	s1,s5,2
    8000579c:	b75d                	j	80005742 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    8000579e:	f8843783          	ld	a5,-120(s0)
    800057a2:	00878713          	addi	a4,a5,8
    800057a6:	f8e43423          	sd	a4,-120(s0)
    800057aa:	4605                	li	a2,1
    800057ac:	85da                	mv	a1,s6
    800057ae:	4388                	lw	a0,0(a5)
    800057b0:	e79ff0ef          	jal	80005628 <printint>
    800057b4:	b779                	j	80005742 <printf+0x84>
    if(c1) c2 = fmt[i+2] & 0xff;
    800057b6:	97ca                	add	a5,a5,s2
    800057b8:	8636                	mv	a2,a3
    800057ba:	0027c683          	lbu	a3,2(a5)
    800057be:	a245                	j	8000595e <printf+0x2a0>
      printint(va_arg(ap, uint64), 10, 1);
    800057c0:	f8843783          	ld	a5,-120(s0)
    800057c4:	00878713          	addi	a4,a5,8
    800057c8:	f8e43423          	sd	a4,-120(s0)
    800057cc:	4605                	li	a2,1
    800057ce:	45a9                	li	a1,10
    800057d0:	6388                	ld	a0,0(a5)
    800057d2:	e57ff0ef          	jal	80005628 <printint>
      i += 2;
    800057d6:	003a849b          	addiw	s1,s5,3
    800057da:	b7a5                	j	80005742 <printf+0x84>
      printint(va_arg(ap, int), 10, 0);
    800057dc:	f8843783          	ld	a5,-120(s0)
    800057e0:	00878713          	addi	a4,a5,8
    800057e4:	f8e43423          	sd	a4,-120(s0)
    800057e8:	4601                	li	a2,0
    800057ea:	85da                	mv	a1,s6
    800057ec:	4388                	lw	a0,0(a5)
    800057ee:	e3bff0ef          	jal	80005628 <printint>
    800057f2:	bf81                	j	80005742 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800057f4:	f8843783          	ld	a5,-120(s0)
    800057f8:	00878713          	addi	a4,a5,8
    800057fc:	f8e43423          	sd	a4,-120(s0)
    80005800:	4601                	li	a2,0
    80005802:	85da                	mv	a1,s6
    80005804:	6388                	ld	a0,0(a5)
    80005806:	e23ff0ef          	jal	80005628 <printint>
      i += 1;
    8000580a:	002a849b          	addiw	s1,s5,2
    8000580e:	bf15                	j	80005742 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    80005810:	f8843783          	ld	a5,-120(s0)
    80005814:	00878713          	addi	a4,a5,8
    80005818:	f8e43423          	sd	a4,-120(s0)
    8000581c:	4601                	li	a2,0
    8000581e:	45a9                	li	a1,10
    80005820:	6388                	ld	a0,0(a5)
    80005822:	e07ff0ef          	jal	80005628 <printint>
      i += 2;
    80005826:	003a849b          	addiw	s1,s5,3
    8000582a:	bf21                	j	80005742 <printf+0x84>
      printint(va_arg(ap, int), 16, 0);
    8000582c:	f8843783          	ld	a5,-120(s0)
    80005830:	00878713          	addi	a4,a5,8
    80005834:	f8e43423          	sd	a4,-120(s0)
    80005838:	4601                	li	a2,0
    8000583a:	45c1                	li	a1,16
    8000583c:	4388                	lw	a0,0(a5)
    8000583e:	debff0ef          	jal	80005628 <printint>
    80005842:	b701                	j	80005742 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80005844:	f8843783          	ld	a5,-120(s0)
    80005848:	00878713          	addi	a4,a5,8
    8000584c:	f8e43423          	sd	a4,-120(s0)
    80005850:	45c1                	li	a1,16
    80005852:	6388                	ld	a0,0(a5)
    80005854:	dd5ff0ef          	jal	80005628 <printint>
      i += 1;
    80005858:	002a849b          	addiw	s1,s5,2
    8000585c:	b5dd                	j	80005742 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    8000585e:	f8843783          	ld	a5,-120(s0)
    80005862:	00878713          	addi	a4,a5,8
    80005866:	f8e43423          	sd	a4,-120(s0)
    8000586a:	4601                	li	a2,0
    8000586c:	45c1                	li	a1,16
    8000586e:	6388                	ld	a0,0(a5)
    80005870:	db9ff0ef          	jal	80005628 <printint>
      i += 2;
    80005874:	003a849b          	addiw	s1,s5,3
    80005878:	b5e9                	j	80005742 <printf+0x84>
    8000587a:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    8000587c:	f8843783          	ld	a5,-120(s0)
    80005880:	00878713          	addi	a4,a5,8
    80005884:	f8e43423          	sd	a4,-120(s0)
    80005888:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    8000588c:	03000513          	li	a0,48
    80005890:	bafff0ef          	jal	8000543e <consputc>
  consputc('x');
    80005894:	07800513          	li	a0,120
    80005898:	ba7ff0ef          	jal	8000543e <consputc>
    8000589c:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000589e:	00002c97          	auipc	s9,0x2
    800058a2:	fc2c8c93          	addi	s9,s9,-62 # 80007860 <digits>
    800058a6:	03cad793          	srli	a5,s5,0x3c
    800058aa:	97e6                	add	a5,a5,s9
    800058ac:	0007c503          	lbu	a0,0(a5)
    800058b0:	b8fff0ef          	jal	8000543e <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800058b4:	0a92                	slli	s5,s5,0x4
    800058b6:	3a7d                	addiw	s4,s4,-1
    800058b8:	fe0a17e3          	bnez	s4,800058a6 <printf+0x1e8>
    800058bc:	7ca2                	ld	s9,40(sp)
    800058be:	b551                	j	80005742 <printf+0x84>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    800058c0:	f8843783          	ld	a5,-120(s0)
    800058c4:	00878713          	addi	a4,a5,8
    800058c8:	f8e43423          	sd	a4,-120(s0)
    800058cc:	0007ba03          	ld	s4,0(a5)
    800058d0:	000a0d63          	beqz	s4,800058ea <printf+0x22c>
        s = "(null)";
      for(; *s; s++)
    800058d4:	000a4503          	lbu	a0,0(s4)
    800058d8:	e60505e3          	beqz	a0,80005742 <printf+0x84>
        consputc(*s);
    800058dc:	b63ff0ef          	jal	8000543e <consputc>
      for(; *s; s++)
    800058e0:	0a05                	addi	s4,s4,1
    800058e2:	000a4503          	lbu	a0,0(s4)
    800058e6:	f97d                	bnez	a0,800058dc <printf+0x21e>
    800058e8:	bda9                	j	80005742 <printf+0x84>
        s = "(null)";
    800058ea:	00002a17          	auipc	s4,0x2
    800058ee:	e16a0a13          	addi	s4,s4,-490 # 80007700 <etext+0x700>
      for(; *s; s++)
    800058f2:	02800513          	li	a0,40
    800058f6:	b7dd                	j	800058dc <printf+0x21e>
    } else if(c0 == '%'){
      consputc('%');
    800058f8:	8552                	mv	a0,s4
    800058fa:	b45ff0ef          	jal	8000543e <consputc>
    800058fe:	b591                	j	80005742 <printf+0x84>
    }
#endif
  }
  va_end(ap);

  if(locking)
    80005900:	020d9163          	bnez	s11,80005922 <printf+0x264>
    80005904:	74a6                	ld	s1,104(sp)
    80005906:	69e6                	ld	s3,88(sp)
    80005908:	6a46                	ld	s4,80(sp)
    8000590a:	6aa6                	ld	s5,72(sp)
    8000590c:	6b06                	ld	s6,64(sp)
    8000590e:	7be2                	ld	s7,56(sp)
    80005910:	7c42                	ld	s8,48(sp)
    80005912:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    80005914:	4501                	li	a0,0
    80005916:	70e6                	ld	ra,120(sp)
    80005918:	7446                	ld	s0,112(sp)
    8000591a:	7906                	ld	s2,96(sp)
    8000591c:	6de2                	ld	s11,24(sp)
    8000591e:	6129                	addi	sp,sp,192
    80005920:	8082                	ret
    80005922:	74a6                	ld	s1,104(sp)
    80005924:	69e6                	ld	s3,88(sp)
    80005926:	6a46                	ld	s4,80(sp)
    80005928:	6aa6                	ld	s5,72(sp)
    8000592a:	6b06                	ld	s6,64(sp)
    8000592c:	7be2                	ld	s7,56(sp)
    8000592e:	7c42                	ld	s8,48(sp)
    80005930:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80005932:	00027517          	auipc	a0,0x27
    80005936:	2a650513          	addi	a0,a0,678 # 8002cbd8 <pr>
    8000593a:	466000ef          	jal	80005da0 <release>
    8000593e:	bfd9                	j	80005914 <printf+0x256>
    if(c0 == 'd'){
    80005940:	e57a0fe3          	beq	s4,s7,8000579e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005944:	f94a0713          	addi	a4,s4,-108
    80005948:	00173713          	seqz	a4,a4
    8000594c:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000594e:	4781                	li	a5,0
    80005950:	a00d                	j	80005972 <printf+0x2b4>
    } else if(c0 == 'l' && c1 == 'd'){
    80005952:	f94a0713          	addi	a4,s4,-108
    80005956:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    8000595a:	8652                	mv	a2,s4
    8000595c:	86d2                	mv	a3,s4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000595e:	f9460793          	addi	a5,a2,-108
    80005962:	0017b793          	seqz	a5,a5
    80005966:	8ff9                	and	a5,a5,a4
    80005968:	f9c68593          	addi	a1,a3,-100
    8000596c:	e199                	bnez	a1,80005972 <printf+0x2b4>
    8000596e:	e40799e3          	bnez	a5,800057c0 <printf+0x102>
    } else if(c0 == 'u'){
    80005972:	e78a05e3          	beq	s4,s8,800057dc <printf+0x11e>
    } else if(c0 == 'l' && c1 == 'u'){
    80005976:	f8b60593          	addi	a1,a2,-117
    8000597a:	e199                	bnez	a1,80005980 <printf+0x2c2>
    8000597c:	e6071ce3          	bnez	a4,800057f4 <printf+0x136>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005980:	f8b68593          	addi	a1,a3,-117
    80005984:	e199                	bnez	a1,8000598a <printf+0x2cc>
    80005986:	e80795e3          	bnez	a5,80005810 <printf+0x152>
    } else if(c0 == 'x'){
    8000598a:	ebaa01e3          	beq	s4,s10,8000582c <printf+0x16e>
    } else if(c0 == 'l' && c1 == 'x'){
    8000598e:	f8860613          	addi	a2,a2,-120
    80005992:	e219                	bnez	a2,80005998 <printf+0x2da>
    80005994:	ea0718e3          	bnez	a4,80005844 <printf+0x186>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    80005998:	f8868693          	addi	a3,a3,-120
    8000599c:	e299                	bnez	a3,800059a2 <printf+0x2e4>
    8000599e:	ec0790e3          	bnez	a5,8000585e <printf+0x1a0>
    } else if(c0 == 'p'){
    800059a2:	07000793          	li	a5,112
    800059a6:	ecfa0ae3          	beq	s4,a5,8000587a <printf+0x1bc>
    } else if(c0 == 's'){
    800059aa:	07300793          	li	a5,115
    800059ae:	f0fa09e3          	beq	s4,a5,800058c0 <printf+0x202>
    } else if(c0 == '%'){
    800059b2:	02500793          	li	a5,37
    800059b6:	f4fa01e3          	beq	s4,a5,800058f8 <printf+0x23a>
    } else if(c0 == 0){
    800059ba:	f40a03e3          	beqz	s4,80005900 <printf+0x242>
      consputc('%');
    800059be:	02500513          	li	a0,37
    800059c2:	a7dff0ef          	jal	8000543e <consputc>
      consputc(c0);
    800059c6:	8552                	mv	a0,s4
    800059c8:	a77ff0ef          	jal	8000543e <consputc>
    800059cc:	bb9d                	j	80005742 <printf+0x84>

00000000800059ce <panic>:

void
panic(char *s)
{
    800059ce:	1101                	addi	sp,sp,-32
    800059d0:	ec06                	sd	ra,24(sp)
    800059d2:	e822                	sd	s0,16(sp)
    800059d4:	e426                	sd	s1,8(sp)
    800059d6:	1000                	addi	s0,sp,32
    800059d8:	84aa                	mv	s1,a0
  pr.locking = 0;
    800059da:	00027797          	auipc	a5,0x27
    800059de:	2007ab23          	sw	zero,534(a5) # 8002cbf0 <pr+0x18>
  printf("panic: ");
    800059e2:	00002517          	auipc	a0,0x2
    800059e6:	d2650513          	addi	a0,a0,-730 # 80007708 <etext+0x708>
    800059ea:	cd5ff0ef          	jal	800056be <printf>
  printf("%s\n", s);
    800059ee:	85a6                	mv	a1,s1
    800059f0:	00002517          	auipc	a0,0x2
    800059f4:	d2050513          	addi	a0,a0,-736 # 80007710 <etext+0x710>
    800059f8:	cc7ff0ef          	jal	800056be <printf>
  panicked = 1; // freeze uart output from other CPUs
    800059fc:	4785                	li	a5,1
    800059fe:	00002717          	auipc	a4,0x2
    80005a02:	eef72723          	sw	a5,-274(a4) # 800078ec <panicked>
  for(;;)
    80005a06:	a001                	j	80005a06 <panic+0x38>

0000000080005a08 <printfinit>:
    ;
}

void
printfinit(void)
{
    80005a08:	1141                	addi	sp,sp,-16
    80005a0a:	e406                	sd	ra,8(sp)
    80005a0c:	e022                	sd	s0,0(sp)
    80005a0e:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80005a10:	00002597          	auipc	a1,0x2
    80005a14:	d0858593          	addi	a1,a1,-760 # 80007718 <etext+0x718>
    80005a18:	00027517          	auipc	a0,0x27
    80005a1c:	1c050513          	addi	a0,a0,448 # 8002cbd8 <pr>
    80005a20:	262000ef          	jal	80005c82 <initlock>
  pr.locking = 1;
    80005a24:	4785                	li	a5,1
    80005a26:	00027717          	auipc	a4,0x27
    80005a2a:	1cf72523          	sw	a5,458(a4) # 8002cbf0 <pr+0x18>
}
    80005a2e:	60a2                	ld	ra,8(sp)
    80005a30:	6402                	ld	s0,0(sp)
    80005a32:	0141                	addi	sp,sp,16
    80005a34:	8082                	ret

0000000080005a36 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80005a36:	1141                	addi	sp,sp,-16
    80005a38:	e406                	sd	ra,8(sp)
    80005a3a:	e022                	sd	s0,0(sp)
    80005a3c:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80005a3e:	100007b7          	lui	a5,0x10000
    80005a42:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80005a46:	10000737          	lui	a4,0x10000
    80005a4a:	f8000693          	li	a3,-128
    80005a4e:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005a52:	468d                	li	a3,3
    80005a54:	10000637          	lui	a2,0x10000
    80005a58:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80005a5c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80005a60:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80005a64:	8732                	mv	a4,a2
    80005a66:	461d                	li	a2,7
    80005a68:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80005a6c:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80005a70:	00002597          	auipc	a1,0x2
    80005a74:	cb058593          	addi	a1,a1,-848 # 80007720 <etext+0x720>
    80005a78:	00027517          	auipc	a0,0x27
    80005a7c:	18050513          	addi	a0,a0,384 # 8002cbf8 <uart_tx_lock>
    80005a80:	202000ef          	jal	80005c82 <initlock>
}
    80005a84:	60a2                	ld	ra,8(sp)
    80005a86:	6402                	ld	s0,0(sp)
    80005a88:	0141                	addi	sp,sp,16
    80005a8a:	8082                	ret

0000000080005a8c <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80005a8c:	1101                	addi	sp,sp,-32
    80005a8e:	ec06                	sd	ra,24(sp)
    80005a90:	e822                	sd	s0,16(sp)
    80005a92:	e426                	sd	s1,8(sp)
    80005a94:	1000                	addi	s0,sp,32
    80005a96:	84aa                	mv	s1,a0
  push_off();
    80005a98:	230000ef          	jal	80005cc8 <push_off>

  if(panicked){
    80005a9c:	00002797          	auipc	a5,0x2
    80005aa0:	e507a783          	lw	a5,-432(a5) # 800078ec <panicked>
    80005aa4:	e795                	bnez	a5,80005ad0 <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80005aa6:	10000737          	lui	a4,0x10000
    80005aaa:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80005aac:	00074783          	lbu	a5,0(a4)
    80005ab0:	0207f793          	andi	a5,a5,32
    80005ab4:	dfe5                	beqz	a5,80005aac <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    80005ab6:	0ff4f513          	zext.b	a0,s1
    80005aba:	100007b7          	lui	a5,0x10000
    80005abe:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80005ac2:	28e000ef          	jal	80005d50 <pop_off>
}
    80005ac6:	60e2                	ld	ra,24(sp)
    80005ac8:	6442                	ld	s0,16(sp)
    80005aca:	64a2                	ld	s1,8(sp)
    80005acc:	6105                	addi	sp,sp,32
    80005ace:	8082                	ret
    for(;;)
    80005ad0:	a001                	j	80005ad0 <uartputc_sync+0x44>

0000000080005ad2 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80005ad2:	00002797          	auipc	a5,0x2
    80005ad6:	e1e7b783          	ld	a5,-482(a5) # 800078f0 <uart_tx_r>
    80005ada:	00002717          	auipc	a4,0x2
    80005ade:	e1e73703          	ld	a4,-482(a4) # 800078f8 <uart_tx_w>
    80005ae2:	08f70163          	beq	a4,a5,80005b64 <uartstart+0x92>
{
    80005ae6:	7139                	addi	sp,sp,-64
    80005ae8:	fc06                	sd	ra,56(sp)
    80005aea:	f822                	sd	s0,48(sp)
    80005aec:	f426                	sd	s1,40(sp)
    80005aee:	f04a                	sd	s2,32(sp)
    80005af0:	ec4e                	sd	s3,24(sp)
    80005af2:	e852                	sd	s4,16(sp)
    80005af4:	e456                	sd	s5,8(sp)
    80005af6:	e05a                	sd	s6,0(sp)
    80005af8:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005afa:	10000937          	lui	s2,0x10000
    80005afe:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005b00:	00027a97          	auipc	s5,0x27
    80005b04:	0f8a8a93          	addi	s5,s5,248 # 8002cbf8 <uart_tx_lock>
    uart_tx_r += 1;
    80005b08:	00002497          	auipc	s1,0x2
    80005b0c:	de848493          	addi	s1,s1,-536 # 800078f0 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    80005b10:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80005b14:	00002997          	auipc	s3,0x2
    80005b18:	de498993          	addi	s3,s3,-540 # 800078f8 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005b1c:	00094703          	lbu	a4,0(s2)
    80005b20:	02077713          	andi	a4,a4,32
    80005b24:	c715                	beqz	a4,80005b50 <uartstart+0x7e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005b26:	01f7f713          	andi	a4,a5,31
    80005b2a:	9756                	add	a4,a4,s5
    80005b2c:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    80005b30:	0785                	addi	a5,a5,1
    80005b32:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80005b34:	8526                	mv	a0,s1
    80005b36:	8c9fb0ef          	jal	800013fe <wakeup>
    WriteReg(THR, c);
    80005b3a:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    80005b3e:	609c                	ld	a5,0(s1)
    80005b40:	0009b703          	ld	a4,0(s3)
    80005b44:	fcf71ce3          	bne	a4,a5,80005b1c <uartstart+0x4a>
      ReadReg(ISR);
    80005b48:	100007b7          	lui	a5,0x10000
    80005b4c:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005b50:	70e2                	ld	ra,56(sp)
    80005b52:	7442                	ld	s0,48(sp)
    80005b54:	74a2                	ld	s1,40(sp)
    80005b56:	7902                	ld	s2,32(sp)
    80005b58:	69e2                	ld	s3,24(sp)
    80005b5a:	6a42                	ld	s4,16(sp)
    80005b5c:	6aa2                	ld	s5,8(sp)
    80005b5e:	6b02                	ld	s6,0(sp)
    80005b60:	6121                	addi	sp,sp,64
    80005b62:	8082                	ret
      ReadReg(ISR);
    80005b64:	100007b7          	lui	a5,0x10000
    80005b68:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    80005b6c:	8082                	ret

0000000080005b6e <uartputc>:
{
    80005b6e:	7179                	addi	sp,sp,-48
    80005b70:	f406                	sd	ra,40(sp)
    80005b72:	f022                	sd	s0,32(sp)
    80005b74:	ec26                	sd	s1,24(sp)
    80005b76:	e84a                	sd	s2,16(sp)
    80005b78:	e44e                	sd	s3,8(sp)
    80005b7a:	e052                	sd	s4,0(sp)
    80005b7c:	1800                	addi	s0,sp,48
    80005b7e:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    80005b80:	00027517          	auipc	a0,0x27
    80005b84:	07850513          	addi	a0,a0,120 # 8002cbf8 <uart_tx_lock>
    80005b88:	184000ef          	jal	80005d0c <acquire>
  if(panicked){
    80005b8c:	00002797          	auipc	a5,0x2
    80005b90:	d607a783          	lw	a5,-672(a5) # 800078ec <panicked>
    80005b94:	e3d1                	bnez	a5,80005c18 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80005b96:	00002717          	auipc	a4,0x2
    80005b9a:	d6273703          	ld	a4,-670(a4) # 800078f8 <uart_tx_w>
    80005b9e:	00002797          	auipc	a5,0x2
    80005ba2:	d527b783          	ld	a5,-686(a5) # 800078f0 <uart_tx_r>
    80005ba6:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    80005baa:	00027997          	auipc	s3,0x27
    80005bae:	04e98993          	addi	s3,s3,78 # 8002cbf8 <uart_tx_lock>
    80005bb2:	00002497          	auipc	s1,0x2
    80005bb6:	d3e48493          	addi	s1,s1,-706 # 800078f0 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80005bba:	00002917          	auipc	s2,0x2
    80005bbe:	d3e90913          	addi	s2,s2,-706 # 800078f8 <uart_tx_w>
    80005bc2:	00e79d63          	bne	a5,a4,80005bdc <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    80005bc6:	85ce                	mv	a1,s3
    80005bc8:	8526                	mv	a0,s1
    80005bca:	fe8fb0ef          	jal	800013b2 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80005bce:	00093703          	ld	a4,0(s2)
    80005bd2:	609c                	ld	a5,0(s1)
    80005bd4:	02078793          	addi	a5,a5,32
    80005bd8:	fee787e3          	beq	a5,a4,80005bc6 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    80005bdc:	01f77693          	andi	a3,a4,31
    80005be0:	00027797          	auipc	a5,0x27
    80005be4:	01878793          	addi	a5,a5,24 # 8002cbf8 <uart_tx_lock>
    80005be8:	97b6                	add	a5,a5,a3
    80005bea:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80005bee:	0705                	addi	a4,a4,1
    80005bf0:	00002797          	auipc	a5,0x2
    80005bf4:	d0e7b423          	sd	a4,-760(a5) # 800078f8 <uart_tx_w>
  uartstart();
    80005bf8:	edbff0ef          	jal	80005ad2 <uartstart>
  release(&uart_tx_lock);
    80005bfc:	00027517          	auipc	a0,0x27
    80005c00:	ffc50513          	addi	a0,a0,-4 # 8002cbf8 <uart_tx_lock>
    80005c04:	19c000ef          	jal	80005da0 <release>
}
    80005c08:	70a2                	ld	ra,40(sp)
    80005c0a:	7402                	ld	s0,32(sp)
    80005c0c:	64e2                	ld	s1,24(sp)
    80005c0e:	6942                	ld	s2,16(sp)
    80005c10:	69a2                	ld	s3,8(sp)
    80005c12:	6a02                	ld	s4,0(sp)
    80005c14:	6145                	addi	sp,sp,48
    80005c16:	8082                	ret
    for(;;)
    80005c18:	a001                	j	80005c18 <uartputc+0xaa>

0000000080005c1a <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80005c1a:	1141                	addi	sp,sp,-16
    80005c1c:	e406                	sd	ra,8(sp)
    80005c1e:	e022                	sd	s0,0(sp)
    80005c20:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80005c22:	100007b7          	lui	a5,0x10000
    80005c26:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80005c2a:	8b85                	andi	a5,a5,1
    80005c2c:	cb89                	beqz	a5,80005c3e <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80005c2e:	100007b7          	lui	a5,0x10000
    80005c32:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80005c36:	60a2                	ld	ra,8(sp)
    80005c38:	6402                	ld	s0,0(sp)
    80005c3a:	0141                	addi	sp,sp,16
    80005c3c:	8082                	ret
    return -1;
    80005c3e:	557d                	li	a0,-1
    80005c40:	bfdd                	j	80005c36 <uartgetc+0x1c>

0000000080005c42 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80005c42:	1101                	addi	sp,sp,-32
    80005c44:	ec06                	sd	ra,24(sp)
    80005c46:	e822                	sd	s0,16(sp)
    80005c48:	e426                	sd	s1,8(sp)
    80005c4a:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80005c4c:	54fd                	li	s1,-1
    int c = uartgetc();
    80005c4e:	fcdff0ef          	jal	80005c1a <uartgetc>
    if(c == -1)
    80005c52:	00950563          	beq	a0,s1,80005c5c <uartintr+0x1a>
      break;
    consoleintr(c);
    80005c56:	81bff0ef          	jal	80005470 <consoleintr>
  while(1){
    80005c5a:	bfd5                	j	80005c4e <uartintr+0xc>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80005c5c:	00027517          	auipc	a0,0x27
    80005c60:	f9c50513          	addi	a0,a0,-100 # 8002cbf8 <uart_tx_lock>
    80005c64:	0a8000ef          	jal	80005d0c <acquire>
  uartstart();
    80005c68:	e6bff0ef          	jal	80005ad2 <uartstart>
  release(&uart_tx_lock);
    80005c6c:	00027517          	auipc	a0,0x27
    80005c70:	f8c50513          	addi	a0,a0,-116 # 8002cbf8 <uart_tx_lock>
    80005c74:	12c000ef          	jal	80005da0 <release>
}
    80005c78:	60e2                	ld	ra,24(sp)
    80005c7a:	6442                	ld	s0,16(sp)
    80005c7c:	64a2                	ld	s1,8(sp)
    80005c7e:	6105                	addi	sp,sp,32
    80005c80:	8082                	ret

0000000080005c82 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80005c82:	1141                	addi	sp,sp,-16
    80005c84:	e406                	sd	ra,8(sp)
    80005c86:	e022                	sd	s0,0(sp)
    80005c88:	0800                	addi	s0,sp,16
  lk->name = name;
    80005c8a:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80005c8c:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80005c90:	00053823          	sd	zero,16(a0)
}
    80005c94:	60a2                	ld	ra,8(sp)
    80005c96:	6402                	ld	s0,0(sp)
    80005c98:	0141                	addi	sp,sp,16
    80005c9a:	8082                	ret

0000000080005c9c <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80005c9c:	411c                	lw	a5,0(a0)
    80005c9e:	e399                	bnez	a5,80005ca4 <holding+0x8>
    80005ca0:	4501                	li	a0,0
  return r;
}
    80005ca2:	8082                	ret
{
    80005ca4:	1101                	addi	sp,sp,-32
    80005ca6:	ec06                	sd	ra,24(sp)
    80005ca8:	e822                	sd	s0,16(sp)
    80005caa:	e426                	sd	s1,8(sp)
    80005cac:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80005cae:	691c                	ld	a5,16(a0)
    80005cb0:	84be                	mv	s1,a5
    80005cb2:	892fb0ef          	jal	80000d44 <mycpu>
    80005cb6:	40a48533          	sub	a0,s1,a0
    80005cba:	00153513          	seqz	a0,a0
}
    80005cbe:	60e2                	ld	ra,24(sp)
    80005cc0:	6442                	ld	s0,16(sp)
    80005cc2:	64a2                	ld	s1,8(sp)
    80005cc4:	6105                	addi	sp,sp,32
    80005cc6:	8082                	ret

0000000080005cc8 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80005cc8:	1101                	addi	sp,sp,-32
    80005cca:	ec06                	sd	ra,24(sp)
    80005ccc:	e822                	sd	s0,16(sp)
    80005cce:	e426                	sd	s1,8(sp)
    80005cd0:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005cd2:	100027f3          	csrr	a5,sstatus
    80005cd6:	84be                	mv	s1,a5
    80005cd8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80005cdc:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80005cde:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80005ce2:	862fb0ef          	jal	80000d44 <mycpu>
    80005ce6:	5d3c                	lw	a5,120(a0)
    80005ce8:	cb99                	beqz	a5,80005cfe <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80005cea:	85afb0ef          	jal	80000d44 <mycpu>
    80005cee:	5d3c                	lw	a5,120(a0)
    80005cf0:	2785                	addiw	a5,a5,1
    80005cf2:	dd3c                	sw	a5,120(a0)
}
    80005cf4:	60e2                	ld	ra,24(sp)
    80005cf6:	6442                	ld	s0,16(sp)
    80005cf8:	64a2                	ld	s1,8(sp)
    80005cfa:	6105                	addi	sp,sp,32
    80005cfc:	8082                	ret
    mycpu()->intena = old;
    80005cfe:	846fb0ef          	jal	80000d44 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80005d02:	0014d793          	srli	a5,s1,0x1
    80005d06:	8b85                	andi	a5,a5,1
    80005d08:	dd7c                	sw	a5,124(a0)
    80005d0a:	b7c5                	j	80005cea <push_off+0x22>

0000000080005d0c <acquire>:
{
    80005d0c:	1101                	addi	sp,sp,-32
    80005d0e:	ec06                	sd	ra,24(sp)
    80005d10:	e822                	sd	s0,16(sp)
    80005d12:	e426                	sd	s1,8(sp)
    80005d14:	1000                	addi	s0,sp,32
    80005d16:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80005d18:	fb1ff0ef          	jal	80005cc8 <push_off>
  if(holding(lk))
    80005d1c:	8526                	mv	a0,s1
    80005d1e:	f7fff0ef          	jal	80005c9c <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005d22:	4705                	li	a4,1
  if(holding(lk))
    80005d24:	e105                	bnez	a0,80005d44 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005d26:	87ba                	mv	a5,a4
    80005d28:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80005d2c:	2781                	sext.w	a5,a5
    80005d2e:	ffe5                	bnez	a5,80005d26 <acquire+0x1a>
  __sync_synchronize();
    80005d30:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80005d34:	810fb0ef          	jal	80000d44 <mycpu>
    80005d38:	e888                	sd	a0,16(s1)
}
    80005d3a:	60e2                	ld	ra,24(sp)
    80005d3c:	6442                	ld	s0,16(sp)
    80005d3e:	64a2                	ld	s1,8(sp)
    80005d40:	6105                	addi	sp,sp,32
    80005d42:	8082                	ret
    panic("acquire");
    80005d44:	00002517          	auipc	a0,0x2
    80005d48:	9e450513          	addi	a0,a0,-1564 # 80007728 <etext+0x728>
    80005d4c:	c83ff0ef          	jal	800059ce <panic>

0000000080005d50 <pop_off>:

void
pop_off(void)
{
    80005d50:	1141                	addi	sp,sp,-16
    80005d52:	e406                	sd	ra,8(sp)
    80005d54:	e022                	sd	s0,0(sp)
    80005d56:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005d58:	fedfa0ef          	jal	80000d44 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005d5c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80005d60:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005d62:	e39d                	bnez	a5,80005d88 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005d64:	5d3c                	lw	a5,120(a0)
    80005d66:	02f05763          	blez	a5,80005d94 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80005d6a:	37fd                	addiw	a5,a5,-1
    80005d6c:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80005d6e:	eb89                	bnez	a5,80005d80 <pop_off+0x30>
    80005d70:	5d7c                	lw	a5,124(a0)
    80005d72:	c799                	beqz	a5,80005d80 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005d74:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80005d78:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80005d7c:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80005d80:	60a2                	ld	ra,8(sp)
    80005d82:	6402                	ld	s0,0(sp)
    80005d84:	0141                	addi	sp,sp,16
    80005d86:	8082                	ret
    panic("pop_off - interruptible");
    80005d88:	00002517          	auipc	a0,0x2
    80005d8c:	9a850513          	addi	a0,a0,-1624 # 80007730 <etext+0x730>
    80005d90:	c3fff0ef          	jal	800059ce <panic>
    panic("pop_off");
    80005d94:	00002517          	auipc	a0,0x2
    80005d98:	9b450513          	addi	a0,a0,-1612 # 80007748 <etext+0x748>
    80005d9c:	c33ff0ef          	jal	800059ce <panic>

0000000080005da0 <release>:
{
    80005da0:	1101                	addi	sp,sp,-32
    80005da2:	ec06                	sd	ra,24(sp)
    80005da4:	e822                	sd	s0,16(sp)
    80005da6:	e426                	sd	s1,8(sp)
    80005da8:	1000                	addi	s0,sp,32
    80005daa:	84aa                	mv	s1,a0
  if(!holding(lk))
    80005dac:	ef1ff0ef          	jal	80005c9c <holding>
    80005db0:	c105                	beqz	a0,80005dd0 <release+0x30>
  lk->cpu = 0;
    80005db2:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80005db6:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80005dba:	0310000f          	fence	rw,w
    80005dbe:	0004a023          	sw	zero,0(s1)
  pop_off();
    80005dc2:	f8fff0ef          	jal	80005d50 <pop_off>
}
    80005dc6:	60e2                	ld	ra,24(sp)
    80005dc8:	6442                	ld	s0,16(sp)
    80005dca:	64a2                	ld	s1,8(sp)
    80005dcc:	6105                	addi	sp,sp,32
    80005dce:	8082                	ret
    panic("release");
    80005dd0:	00002517          	auipc	a0,0x2
    80005dd4:	98050513          	addi	a0,a0,-1664 # 80007750 <etext+0x750>
    80005dd8:	bf7ff0ef          	jal	800059ce <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
