
user/_zombie:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  if(fork() > 0)
   8:	29a000ef          	jal	2a2 <fork>
   c:	00a04563          	bgtz	a0,16 <main+0x16>
    sleep(5);  // Let child exit before parent.
  exit(0);
  10:	4501                	li	a0,0
  12:	298000ef          	jal	2aa <exit>
    sleep(5);  // Let child exit before parent.
  16:	4515                	li	a0,5
  18:	322000ef          	jal	33a <sleep>
  1c:	bfd5                	j	10 <main+0x10>

000000000000001e <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  1e:	1141                	addi	sp,sp,-16
  20:	e406                	sd	ra,8(sp)
  22:	e022                	sd	s0,0(sp)
  24:	0800                	addi	s0,sp,16
  extern int main();
  main();
  26:	fdbff0ef          	jal	0 <main>
  exit(0);
  2a:	4501                	li	a0,0
  2c:	27e000ef          	jal	2aa <exit>

0000000000000030 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  30:	1141                	addi	sp,sp,-16
  32:	e406                	sd	ra,8(sp)
  34:	e022                	sd	s0,0(sp)
  36:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  38:	87aa                	mv	a5,a0
  3a:	0585                	addi	a1,a1,1
  3c:	0785                	addi	a5,a5,1
  3e:	fff5c703          	lbu	a4,-1(a1)
  42:	fee78fa3          	sb	a4,-1(a5)
  46:	fb75                	bnez	a4,3a <strcpy+0xa>
    ;
  return os;
}
  48:	60a2                	ld	ra,8(sp)
  4a:	6402                	ld	s0,0(sp)
  4c:	0141                	addi	sp,sp,16
  4e:	8082                	ret

0000000000000050 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  50:	1141                	addi	sp,sp,-16
  52:	e406                	sd	ra,8(sp)
  54:	e022                	sd	s0,0(sp)
  56:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  58:	00054783          	lbu	a5,0(a0)
  5c:	cb91                	beqz	a5,70 <strcmp+0x20>
  5e:	0005c703          	lbu	a4,0(a1)
  62:	00f71763          	bne	a4,a5,70 <strcmp+0x20>
    p++, q++;
  66:	0505                	addi	a0,a0,1
  68:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  6a:	00054783          	lbu	a5,0(a0)
  6e:	fbe5                	bnez	a5,5e <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  70:	0005c503          	lbu	a0,0(a1)
}
  74:	40a7853b          	subw	a0,a5,a0
  78:	60a2                	ld	ra,8(sp)
  7a:	6402                	ld	s0,0(sp)
  7c:	0141                	addi	sp,sp,16
  7e:	8082                	ret

0000000000000080 <strlen>:

uint
strlen(const char *s)
{
  80:	1141                	addi	sp,sp,-16
  82:	e406                	sd	ra,8(sp)
  84:	e022                	sd	s0,0(sp)
  86:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  88:	00054783          	lbu	a5,0(a0)
  8c:	cf91                	beqz	a5,a8 <strlen+0x28>
  8e:	00150793          	addi	a5,a0,1
  92:	86be                	mv	a3,a5
  94:	0785                	addi	a5,a5,1
  96:	fff7c703          	lbu	a4,-1(a5)
  9a:	ff65                	bnez	a4,92 <strlen+0x12>
  9c:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  a0:	60a2                	ld	ra,8(sp)
  a2:	6402                	ld	s0,0(sp)
  a4:	0141                	addi	sp,sp,16
  a6:	8082                	ret
  for(n = 0; s[n]; n++)
  a8:	4501                	li	a0,0
  aa:	bfdd                	j	a0 <strlen+0x20>

00000000000000ac <memset>:

void*
memset(void *dst, int c, uint n)
{
  ac:	1141                	addi	sp,sp,-16
  ae:	e406                	sd	ra,8(sp)
  b0:	e022                	sd	s0,0(sp)
  b2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  b4:	ca19                	beqz	a2,ca <memset+0x1e>
  b6:	87aa                	mv	a5,a0
  b8:	1602                	slli	a2,a2,0x20
  ba:	9201                	srli	a2,a2,0x20
  bc:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  c0:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  c4:	0785                	addi	a5,a5,1
  c6:	fee79de3          	bne	a5,a4,c0 <memset+0x14>
  }
  return dst;
}
  ca:	60a2                	ld	ra,8(sp)
  cc:	6402                	ld	s0,0(sp)
  ce:	0141                	addi	sp,sp,16
  d0:	8082                	ret

00000000000000d2 <strchr>:

char*
strchr(const char *s, char c)
{
  d2:	1141                	addi	sp,sp,-16
  d4:	e406                	sd	ra,8(sp)
  d6:	e022                	sd	s0,0(sp)
  d8:	0800                	addi	s0,sp,16
  for(; *s; s++)
  da:	00054783          	lbu	a5,0(a0)
  de:	cf81                	beqz	a5,f6 <strchr+0x24>
    if(*s == c)
  e0:	00f58763          	beq	a1,a5,ee <strchr+0x1c>
  for(; *s; s++)
  e4:	0505                	addi	a0,a0,1
  e6:	00054783          	lbu	a5,0(a0)
  ea:	fbfd                	bnez	a5,e0 <strchr+0xe>
      return (char*)s;
  return 0;
  ec:	4501                	li	a0,0
}
  ee:	60a2                	ld	ra,8(sp)
  f0:	6402                	ld	s0,0(sp)
  f2:	0141                	addi	sp,sp,16
  f4:	8082                	ret
  return 0;
  f6:	4501                	li	a0,0
  f8:	bfdd                	j	ee <strchr+0x1c>

00000000000000fa <gets>:

char*
gets(char *buf, int max)
{
  fa:	711d                	addi	sp,sp,-96
  fc:	ec86                	sd	ra,88(sp)
  fe:	e8a2                	sd	s0,80(sp)
 100:	e4a6                	sd	s1,72(sp)
 102:	e0ca                	sd	s2,64(sp)
 104:	fc4e                	sd	s3,56(sp)
 106:	f852                	sd	s4,48(sp)
 108:	f456                	sd	s5,40(sp)
 10a:	f05a                	sd	s6,32(sp)
 10c:	ec5e                	sd	s7,24(sp)
 10e:	e862                	sd	s8,16(sp)
 110:	1080                	addi	s0,sp,96
 112:	8baa                	mv	s7,a0
 114:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 116:	892a                	mv	s2,a0
 118:	4481                	li	s1,0
    cc = read(0, &c, 1);
 11a:	faf40b13          	addi	s6,s0,-81
 11e:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 120:	8c26                	mv	s8,s1
 122:	0014899b          	addiw	s3,s1,1
 126:	84ce                	mv	s1,s3
 128:	0349d463          	bge	s3,s4,150 <gets+0x56>
    cc = read(0, &c, 1);
 12c:	8656                	mv	a2,s5
 12e:	85da                	mv	a1,s6
 130:	4501                	li	a0,0
 132:	190000ef          	jal	2c2 <read>
    if(cc < 1)
 136:	00a05d63          	blez	a0,150 <gets+0x56>
      break;
    buf[i++] = c;
 13a:	faf44783          	lbu	a5,-81(s0)
 13e:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 142:	0905                	addi	s2,s2,1
 144:	ff678713          	addi	a4,a5,-10
 148:	c319                	beqz	a4,14e <gets+0x54>
 14a:	17cd                	addi	a5,a5,-13
 14c:	fbf1                	bnez	a5,120 <gets+0x26>
    buf[i++] = c;
 14e:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 150:	9c5e                	add	s8,s8,s7
 152:	000c0023          	sb	zero,0(s8)
  return buf;
}
 156:	855e                	mv	a0,s7
 158:	60e6                	ld	ra,88(sp)
 15a:	6446                	ld	s0,80(sp)
 15c:	64a6                	ld	s1,72(sp)
 15e:	6906                	ld	s2,64(sp)
 160:	79e2                	ld	s3,56(sp)
 162:	7a42                	ld	s4,48(sp)
 164:	7aa2                	ld	s5,40(sp)
 166:	7b02                	ld	s6,32(sp)
 168:	6be2                	ld	s7,24(sp)
 16a:	6c42                	ld	s8,16(sp)
 16c:	6125                	addi	sp,sp,96
 16e:	8082                	ret

0000000000000170 <stat>:

int
stat(const char *n, struct stat *st)
{
 170:	1101                	addi	sp,sp,-32
 172:	ec06                	sd	ra,24(sp)
 174:	e822                	sd	s0,16(sp)
 176:	e04a                	sd	s2,0(sp)
 178:	1000                	addi	s0,sp,32
 17a:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 17c:	4581                	li	a1,0
 17e:	16c000ef          	jal	2ea <open>
  if(fd < 0)
 182:	02054263          	bltz	a0,1a6 <stat+0x36>
 186:	e426                	sd	s1,8(sp)
 188:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 18a:	85ca                	mv	a1,s2
 18c:	176000ef          	jal	302 <fstat>
 190:	892a                	mv	s2,a0
  close(fd);
 192:	8526                	mv	a0,s1
 194:	13e000ef          	jal	2d2 <close>
  return r;
 198:	64a2                	ld	s1,8(sp)
}
 19a:	854a                	mv	a0,s2
 19c:	60e2                	ld	ra,24(sp)
 19e:	6442                	ld	s0,16(sp)
 1a0:	6902                	ld	s2,0(sp)
 1a2:	6105                	addi	sp,sp,32
 1a4:	8082                	ret
    return -1;
 1a6:	57fd                	li	a5,-1
 1a8:	893e                	mv	s2,a5
 1aa:	bfc5                	j	19a <stat+0x2a>

00000000000001ac <atoi>:

int
atoi(const char *s)
{
 1ac:	1141                	addi	sp,sp,-16
 1ae:	e406                	sd	ra,8(sp)
 1b0:	e022                	sd	s0,0(sp)
 1b2:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1b4:	00054683          	lbu	a3,0(a0)
 1b8:	fd06879b          	addiw	a5,a3,-48
 1bc:	0ff7f793          	zext.b	a5,a5
 1c0:	4625                	li	a2,9
 1c2:	02f66963          	bltu	a2,a5,1f4 <atoi+0x48>
 1c6:	872a                	mv	a4,a0
  n = 0;
 1c8:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 1ca:	0705                	addi	a4,a4,1
 1cc:	0025179b          	slliw	a5,a0,0x2
 1d0:	9fa9                	addw	a5,a5,a0
 1d2:	0017979b          	slliw	a5,a5,0x1
 1d6:	9fb5                	addw	a5,a5,a3
 1d8:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1dc:	00074683          	lbu	a3,0(a4)
 1e0:	fd06879b          	addiw	a5,a3,-48
 1e4:	0ff7f793          	zext.b	a5,a5
 1e8:	fef671e3          	bgeu	a2,a5,1ca <atoi+0x1e>
  return n;
}
 1ec:	60a2                	ld	ra,8(sp)
 1ee:	6402                	ld	s0,0(sp)
 1f0:	0141                	addi	sp,sp,16
 1f2:	8082                	ret
  n = 0;
 1f4:	4501                	li	a0,0
 1f6:	bfdd                	j	1ec <atoi+0x40>

00000000000001f8 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1f8:	1141                	addi	sp,sp,-16
 1fa:	e406                	sd	ra,8(sp)
 1fc:	e022                	sd	s0,0(sp)
 1fe:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 200:	02b57563          	bgeu	a0,a1,22a <memmove+0x32>
    while(n-- > 0)
 204:	00c05f63          	blez	a2,222 <memmove+0x2a>
 208:	1602                	slli	a2,a2,0x20
 20a:	9201                	srli	a2,a2,0x20
 20c:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 210:	872a                	mv	a4,a0
      *dst++ = *src++;
 212:	0585                	addi	a1,a1,1
 214:	0705                	addi	a4,a4,1
 216:	fff5c683          	lbu	a3,-1(a1)
 21a:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 21e:	fee79ae3          	bne	a5,a4,212 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 222:	60a2                	ld	ra,8(sp)
 224:	6402                	ld	s0,0(sp)
 226:	0141                	addi	sp,sp,16
 228:	8082                	ret
    while(n-- > 0)
 22a:	fec05ce3          	blez	a2,222 <memmove+0x2a>
    dst += n;
 22e:	00c50733          	add	a4,a0,a2
    src += n;
 232:	95b2                	add	a1,a1,a2
 234:	fff6079b          	addiw	a5,a2,-1
 238:	1782                	slli	a5,a5,0x20
 23a:	9381                	srli	a5,a5,0x20
 23c:	fff7c793          	not	a5,a5
 240:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 242:	15fd                	addi	a1,a1,-1
 244:	177d                	addi	a4,a4,-1
 246:	0005c683          	lbu	a3,0(a1)
 24a:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 24e:	fef71ae3          	bne	a4,a5,242 <memmove+0x4a>
 252:	bfc1                	j	222 <memmove+0x2a>

0000000000000254 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 254:	1141                	addi	sp,sp,-16
 256:	e406                	sd	ra,8(sp)
 258:	e022                	sd	s0,0(sp)
 25a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 25c:	c61d                	beqz	a2,28a <memcmp+0x36>
 25e:	1602                	slli	a2,a2,0x20
 260:	9201                	srli	a2,a2,0x20
 262:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 266:	00054783          	lbu	a5,0(a0)
 26a:	0005c703          	lbu	a4,0(a1)
 26e:	00e79863          	bne	a5,a4,27e <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 272:	0505                	addi	a0,a0,1
    p2++;
 274:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 276:	fed518e3          	bne	a0,a3,266 <memcmp+0x12>
  }
  return 0;
 27a:	4501                	li	a0,0
 27c:	a019                	j	282 <memcmp+0x2e>
      return *p1 - *p2;
 27e:	40e7853b          	subw	a0,a5,a4
}
 282:	60a2                	ld	ra,8(sp)
 284:	6402                	ld	s0,0(sp)
 286:	0141                	addi	sp,sp,16
 288:	8082                	ret
  return 0;
 28a:	4501                	li	a0,0
 28c:	bfdd                	j	282 <memcmp+0x2e>

000000000000028e <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 28e:	1141                	addi	sp,sp,-16
 290:	e406                	sd	ra,8(sp)
 292:	e022                	sd	s0,0(sp)
 294:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 296:	f63ff0ef          	jal	1f8 <memmove>
}
 29a:	60a2                	ld	ra,8(sp)
 29c:	6402                	ld	s0,0(sp)
 29e:	0141                	addi	sp,sp,16
 2a0:	8082                	ret

00000000000002a2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2a2:	4885                	li	a7,1
 ecall
 2a4:	00000073          	ecall
 ret
 2a8:	8082                	ret

00000000000002aa <exit>:
.global exit
exit:
 li a7, SYS_exit
 2aa:	4889                	li	a7,2
 ecall
 2ac:	00000073          	ecall
 ret
 2b0:	8082                	ret

00000000000002b2 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2b2:	488d                	li	a7,3
 ecall
 2b4:	00000073          	ecall
 ret
 2b8:	8082                	ret

00000000000002ba <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2ba:	4891                	li	a7,4
 ecall
 2bc:	00000073          	ecall
 ret
 2c0:	8082                	ret

00000000000002c2 <read>:
.global read
read:
 li a7, SYS_read
 2c2:	4895                	li	a7,5
 ecall
 2c4:	00000073          	ecall
 ret
 2c8:	8082                	ret

00000000000002ca <write>:
.global write
write:
 li a7, SYS_write
 2ca:	48c1                	li	a7,16
 ecall
 2cc:	00000073          	ecall
 ret
 2d0:	8082                	ret

00000000000002d2 <close>:
.global close
close:
 li a7, SYS_close
 2d2:	48d5                	li	a7,21
 ecall
 2d4:	00000073          	ecall
 ret
 2d8:	8082                	ret

00000000000002da <kill>:
.global kill
kill:
 li a7, SYS_kill
 2da:	4899                	li	a7,6
 ecall
 2dc:	00000073          	ecall
 ret
 2e0:	8082                	ret

00000000000002e2 <exec>:
.global exec
exec:
 li a7, SYS_exec
 2e2:	489d                	li	a7,7
 ecall
 2e4:	00000073          	ecall
 ret
 2e8:	8082                	ret

00000000000002ea <open>:
.global open
open:
 li a7, SYS_open
 2ea:	48bd                	li	a7,15
 ecall
 2ec:	00000073          	ecall
 ret
 2f0:	8082                	ret

00000000000002f2 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 2f2:	48c5                	li	a7,17
 ecall
 2f4:	00000073          	ecall
 ret
 2f8:	8082                	ret

00000000000002fa <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 2fa:	48c9                	li	a7,18
 ecall
 2fc:	00000073          	ecall
 ret
 300:	8082                	ret

0000000000000302 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 302:	48a1                	li	a7,8
 ecall
 304:	00000073          	ecall
 ret
 308:	8082                	ret

000000000000030a <link>:
.global link
link:
 li a7, SYS_link
 30a:	48cd                	li	a7,19
 ecall
 30c:	00000073          	ecall
 ret
 310:	8082                	ret

0000000000000312 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 312:	48d1                	li	a7,20
 ecall
 314:	00000073          	ecall
 ret
 318:	8082                	ret

000000000000031a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 31a:	48a5                	li	a7,9
 ecall
 31c:	00000073          	ecall
 ret
 320:	8082                	ret

0000000000000322 <dup>:
.global dup
dup:
 li a7, SYS_dup
 322:	48a9                	li	a7,10
 ecall
 324:	00000073          	ecall
 ret
 328:	8082                	ret

000000000000032a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 32a:	48ad                	li	a7,11
 ecall
 32c:	00000073          	ecall
 ret
 330:	8082                	ret

0000000000000332 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 332:	48b1                	li	a7,12
 ecall
 334:	00000073          	ecall
 ret
 338:	8082                	ret

000000000000033a <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 33a:	48b5                	li	a7,13
 ecall
 33c:	00000073          	ecall
 ret
 340:	8082                	ret

0000000000000342 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 342:	48b9                	li	a7,14
 ecall
 344:	00000073          	ecall
 ret
 348:	8082                	ret

000000000000034a <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 34a:	1101                	addi	sp,sp,-32
 34c:	ec06                	sd	ra,24(sp)
 34e:	e822                	sd	s0,16(sp)
 350:	1000                	addi	s0,sp,32
 352:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 356:	4605                	li	a2,1
 358:	fef40593          	addi	a1,s0,-17
 35c:	f6fff0ef          	jal	2ca <write>
}
 360:	60e2                	ld	ra,24(sp)
 362:	6442                	ld	s0,16(sp)
 364:	6105                	addi	sp,sp,32
 366:	8082                	ret

0000000000000368 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 368:	7139                	addi	sp,sp,-64
 36a:	fc06                	sd	ra,56(sp)
 36c:	f822                	sd	s0,48(sp)
 36e:	f04a                	sd	s2,32(sp)
 370:	ec4e                	sd	s3,24(sp)
 372:	0080                	addi	s0,sp,64
 374:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 376:	cac9                	beqz	a3,408 <printint+0xa0>
 378:	01f5d79b          	srliw	a5,a1,0x1f
 37c:	c7d1                	beqz	a5,408 <printint+0xa0>
    neg = 1;
    x = -xx;
 37e:	40b005bb          	negw	a1,a1
    neg = 1;
 382:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 384:	fc040993          	addi	s3,s0,-64
  neg = 0;
 388:	86ce                	mv	a3,s3
  i = 0;
 38a:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 38c:	00000817          	auipc	a6,0x0
 390:	50c80813          	addi	a6,a6,1292 # 898 <digits>
 394:	88ba                	mv	a7,a4
 396:	0017051b          	addiw	a0,a4,1
 39a:	872a                	mv	a4,a0
 39c:	02c5f7bb          	remuw	a5,a1,a2
 3a0:	1782                	slli	a5,a5,0x20
 3a2:	9381                	srli	a5,a5,0x20
 3a4:	97c2                	add	a5,a5,a6
 3a6:	0007c783          	lbu	a5,0(a5)
 3aa:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 3ae:	87ae                	mv	a5,a1
 3b0:	02c5d5bb          	divuw	a1,a1,a2
 3b4:	0685                	addi	a3,a3,1
 3b6:	fcc7ffe3          	bgeu	a5,a2,394 <printint+0x2c>
  if(neg)
 3ba:	00030c63          	beqz	t1,3d2 <printint+0x6a>
    buf[i++] = '-';
 3be:	fd050793          	addi	a5,a0,-48
 3c2:	00878533          	add	a0,a5,s0
 3c6:	02d00793          	li	a5,45
 3ca:	fef50823          	sb	a5,-16(a0)
 3ce:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 3d2:	02e05563          	blez	a4,3fc <printint+0x94>
 3d6:	f426                	sd	s1,40(sp)
 3d8:	377d                	addiw	a4,a4,-1
 3da:	00e984b3          	add	s1,s3,a4
 3de:	19fd                	addi	s3,s3,-1
 3e0:	99ba                	add	s3,s3,a4
 3e2:	1702                	slli	a4,a4,0x20
 3e4:	9301                	srli	a4,a4,0x20
 3e6:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 3ea:	0004c583          	lbu	a1,0(s1)
 3ee:	854a                	mv	a0,s2
 3f0:	f5bff0ef          	jal	34a <putc>
  while(--i >= 0)
 3f4:	14fd                	addi	s1,s1,-1
 3f6:	ff349ae3          	bne	s1,s3,3ea <printint+0x82>
 3fa:	74a2                	ld	s1,40(sp)
}
 3fc:	70e2                	ld	ra,56(sp)
 3fe:	7442                	ld	s0,48(sp)
 400:	7902                	ld	s2,32(sp)
 402:	69e2                	ld	s3,24(sp)
 404:	6121                	addi	sp,sp,64
 406:	8082                	ret
  neg = 0;
 408:	4301                	li	t1,0
 40a:	bfad                	j	384 <printint+0x1c>

000000000000040c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 40c:	711d                	addi	sp,sp,-96
 40e:	ec86                	sd	ra,88(sp)
 410:	e8a2                	sd	s0,80(sp)
 412:	e4a6                	sd	s1,72(sp)
 414:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 416:	0005c483          	lbu	s1,0(a1)
 41a:	20048963          	beqz	s1,62c <vprintf+0x220>
 41e:	e0ca                	sd	s2,64(sp)
 420:	fc4e                	sd	s3,56(sp)
 422:	f852                	sd	s4,48(sp)
 424:	f456                	sd	s5,40(sp)
 426:	f05a                	sd	s6,32(sp)
 428:	ec5e                	sd	s7,24(sp)
 42a:	e862                	sd	s8,16(sp)
 42c:	8b2a                	mv	s6,a0
 42e:	8a2e                	mv	s4,a1
 430:	8bb2                	mv	s7,a2
  state = 0;
 432:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 434:	4901                	li	s2,0
 436:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 438:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 43c:	06400c13          	li	s8,100
 440:	a00d                	j	462 <vprintf+0x56>
        putc(fd, c0);
 442:	85a6                	mv	a1,s1
 444:	855a                	mv	a0,s6
 446:	f05ff0ef          	jal	34a <putc>
 44a:	a019                	j	450 <vprintf+0x44>
    } else if(state == '%'){
 44c:	03598363          	beq	s3,s5,472 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 450:	0019079b          	addiw	a5,s2,1
 454:	893e                	mv	s2,a5
 456:	873e                	mv	a4,a5
 458:	97d2                	add	a5,a5,s4
 45a:	0007c483          	lbu	s1,0(a5)
 45e:	1c048063          	beqz	s1,61e <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 462:	0004879b          	sext.w	a5,s1
    if(state == 0){
 466:	fe0993e3          	bnez	s3,44c <vprintf+0x40>
      if(c0 == '%'){
 46a:	fd579ce3          	bne	a5,s5,442 <vprintf+0x36>
        state = '%';
 46e:	89be                	mv	s3,a5
 470:	b7c5                	j	450 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 472:	00ea06b3          	add	a3,s4,a4
 476:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 47a:	1a060e63          	beqz	a2,636 <vprintf+0x22a>
      if(c0 == 'd'){
 47e:	03878763          	beq	a5,s8,4ac <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 482:	f9478693          	addi	a3,a5,-108
 486:	0016b693          	seqz	a3,a3
 48a:	f9c60593          	addi	a1,a2,-100
 48e:	e99d                	bnez	a1,4c4 <vprintf+0xb8>
 490:	ca95                	beqz	a3,4c4 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 492:	008b8493          	addi	s1,s7,8
 496:	4685                	li	a3,1
 498:	4629                	li	a2,10
 49a:	000ba583          	lw	a1,0(s7)
 49e:	855a                	mv	a0,s6
 4a0:	ec9ff0ef          	jal	368 <printint>
        i += 1;
 4a4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 4a6:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 4a8:	4981                	li	s3,0
 4aa:	b75d                	j	450 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 4ac:	008b8493          	addi	s1,s7,8
 4b0:	4685                	li	a3,1
 4b2:	4629                	li	a2,10
 4b4:	000ba583          	lw	a1,0(s7)
 4b8:	855a                	mv	a0,s6
 4ba:	eafff0ef          	jal	368 <printint>
 4be:	8ba6                	mv	s7,s1
      state = 0;
 4c0:	4981                	li	s3,0
 4c2:	b779                	j	450 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 4c4:	9752                	add	a4,a4,s4
 4c6:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4ca:	f9460713          	addi	a4,a2,-108
 4ce:	00173713          	seqz	a4,a4
 4d2:	8f75                	and	a4,a4,a3
 4d4:	f9c58513          	addi	a0,a1,-100
 4d8:	16051963          	bnez	a0,64a <vprintf+0x23e>
 4dc:	16070763          	beqz	a4,64a <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 4e0:	008b8493          	addi	s1,s7,8
 4e4:	4685                	li	a3,1
 4e6:	4629                	li	a2,10
 4e8:	000ba583          	lw	a1,0(s7)
 4ec:	855a                	mv	a0,s6
 4ee:	e7bff0ef          	jal	368 <printint>
        i += 2;
 4f2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 4f4:	8ba6                	mv	s7,s1
      state = 0;
 4f6:	4981                	li	s3,0
        i += 2;
 4f8:	bfa1                	j	450 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 4fa:	008b8493          	addi	s1,s7,8
 4fe:	4681                	li	a3,0
 500:	4629                	li	a2,10
 502:	000ba583          	lw	a1,0(s7)
 506:	855a                	mv	a0,s6
 508:	e61ff0ef          	jal	368 <printint>
 50c:	8ba6                	mv	s7,s1
      state = 0;
 50e:	4981                	li	s3,0
 510:	b781                	j	450 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 512:	008b8493          	addi	s1,s7,8
 516:	4681                	li	a3,0
 518:	4629                	li	a2,10
 51a:	000ba583          	lw	a1,0(s7)
 51e:	855a                	mv	a0,s6
 520:	e49ff0ef          	jal	368 <printint>
        i += 1;
 524:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 526:	8ba6                	mv	s7,s1
      state = 0;
 528:	4981                	li	s3,0
 52a:	b71d                	j	450 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 52c:	008b8493          	addi	s1,s7,8
 530:	4681                	li	a3,0
 532:	4629                	li	a2,10
 534:	000ba583          	lw	a1,0(s7)
 538:	855a                	mv	a0,s6
 53a:	e2fff0ef          	jal	368 <printint>
        i += 2;
 53e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 540:	8ba6                	mv	s7,s1
      state = 0;
 542:	4981                	li	s3,0
        i += 2;
 544:	b731                	j	450 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 546:	008b8493          	addi	s1,s7,8
 54a:	4681                	li	a3,0
 54c:	4641                	li	a2,16
 54e:	000ba583          	lw	a1,0(s7)
 552:	855a                	mv	a0,s6
 554:	e15ff0ef          	jal	368 <printint>
 558:	8ba6                	mv	s7,s1
      state = 0;
 55a:	4981                	li	s3,0
 55c:	bdd5                	j	450 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 55e:	008b8493          	addi	s1,s7,8
 562:	4681                	li	a3,0
 564:	4641                	li	a2,16
 566:	000ba583          	lw	a1,0(s7)
 56a:	855a                	mv	a0,s6
 56c:	dfdff0ef          	jal	368 <printint>
        i += 1;
 570:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 572:	8ba6                	mv	s7,s1
      state = 0;
 574:	4981                	li	s3,0
 576:	bde9                	j	450 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 578:	008b8493          	addi	s1,s7,8
 57c:	4681                	li	a3,0
 57e:	4641                	li	a2,16
 580:	000ba583          	lw	a1,0(s7)
 584:	855a                	mv	a0,s6
 586:	de3ff0ef          	jal	368 <printint>
        i += 2;
 58a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 58c:	8ba6                	mv	s7,s1
      state = 0;
 58e:	4981                	li	s3,0
        i += 2;
 590:	b5c1                	j	450 <vprintf+0x44>
 592:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 594:	008b8793          	addi	a5,s7,8
 598:	8cbe                	mv	s9,a5
 59a:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 59e:	03000593          	li	a1,48
 5a2:	855a                	mv	a0,s6
 5a4:	da7ff0ef          	jal	34a <putc>
  putc(fd, 'x');
 5a8:	07800593          	li	a1,120
 5ac:	855a                	mv	a0,s6
 5ae:	d9dff0ef          	jal	34a <putc>
 5b2:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5b4:	00000b97          	auipc	s7,0x0
 5b8:	2e4b8b93          	addi	s7,s7,740 # 898 <digits>
 5bc:	03c9d793          	srli	a5,s3,0x3c
 5c0:	97de                	add	a5,a5,s7
 5c2:	0007c583          	lbu	a1,0(a5)
 5c6:	855a                	mv	a0,s6
 5c8:	d83ff0ef          	jal	34a <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 5cc:	0992                	slli	s3,s3,0x4
 5ce:	34fd                	addiw	s1,s1,-1
 5d0:	f4f5                	bnez	s1,5bc <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 5d2:	8be6                	mv	s7,s9
      state = 0;
 5d4:	4981                	li	s3,0
 5d6:	6ca2                	ld	s9,8(sp)
 5d8:	bda5                	j	450 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 5da:	008b8993          	addi	s3,s7,8
 5de:	000bb483          	ld	s1,0(s7)
 5e2:	cc91                	beqz	s1,5fe <vprintf+0x1f2>
        for(; *s; s++)
 5e4:	0004c583          	lbu	a1,0(s1)
 5e8:	c985                	beqz	a1,618 <vprintf+0x20c>
          putc(fd, *s);
 5ea:	855a                	mv	a0,s6
 5ec:	d5fff0ef          	jal	34a <putc>
        for(; *s; s++)
 5f0:	0485                	addi	s1,s1,1
 5f2:	0004c583          	lbu	a1,0(s1)
 5f6:	f9f5                	bnez	a1,5ea <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 5f8:	8bce                	mv	s7,s3
      state = 0;
 5fa:	4981                	li	s3,0
 5fc:	bd91                	j	450 <vprintf+0x44>
          s = "(null)";
 5fe:	00000497          	auipc	s1,0x0
 602:	29248493          	addi	s1,s1,658 # 890 <malloc+0xfe>
        for(; *s; s++)
 606:	02800593          	li	a1,40
 60a:	b7c5                	j	5ea <vprintf+0x1de>
        putc(fd, '%');
 60c:	85be                	mv	a1,a5
 60e:	855a                	mv	a0,s6
 610:	d3bff0ef          	jal	34a <putc>
      state = 0;
 614:	4981                	li	s3,0
 616:	bd2d                	j	450 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 618:	8bce                	mv	s7,s3
      state = 0;
 61a:	4981                	li	s3,0
 61c:	bd15                	j	450 <vprintf+0x44>
 61e:	6906                	ld	s2,64(sp)
 620:	79e2                	ld	s3,56(sp)
 622:	7a42                	ld	s4,48(sp)
 624:	7aa2                	ld	s5,40(sp)
 626:	7b02                	ld	s6,32(sp)
 628:	6be2                	ld	s7,24(sp)
 62a:	6c42                	ld	s8,16(sp)
    }
  }
}
 62c:	60e6                	ld	ra,88(sp)
 62e:	6446                	ld	s0,80(sp)
 630:	64a6                	ld	s1,72(sp)
 632:	6125                	addi	sp,sp,96
 634:	8082                	ret
      if(c0 == 'd'){
 636:	06400713          	li	a4,100
 63a:	e6e789e3          	beq	a5,a4,4ac <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 63e:	f9478693          	addi	a3,a5,-108
 642:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 646:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 648:	4701                	li	a4,0
      } else if(c0 == 'u'){
 64a:	07500513          	li	a0,117
 64e:	eaa786e3          	beq	a5,a0,4fa <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 652:	f8b60513          	addi	a0,a2,-117
 656:	e119                	bnez	a0,65c <vprintf+0x250>
 658:	ea069de3          	bnez	a3,512 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 65c:	f8b58513          	addi	a0,a1,-117
 660:	e119                	bnez	a0,666 <vprintf+0x25a>
 662:	ec0715e3          	bnez	a4,52c <vprintf+0x120>
      } else if(c0 == 'x'){
 666:	07800513          	li	a0,120
 66a:	eca78ee3          	beq	a5,a0,546 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 66e:	f8860613          	addi	a2,a2,-120
 672:	e219                	bnez	a2,678 <vprintf+0x26c>
 674:	ee0695e3          	bnez	a3,55e <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 678:	f8858593          	addi	a1,a1,-120
 67c:	e199                	bnez	a1,682 <vprintf+0x276>
 67e:	ee071de3          	bnez	a4,578 <vprintf+0x16c>
      } else if(c0 == 'p'){
 682:	07000713          	li	a4,112
 686:	f0e786e3          	beq	a5,a4,592 <vprintf+0x186>
      } else if(c0 == 's'){
 68a:	07300713          	li	a4,115
 68e:	f4e786e3          	beq	a5,a4,5da <vprintf+0x1ce>
      } else if(c0 == '%'){
 692:	02500713          	li	a4,37
 696:	f6e78be3          	beq	a5,a4,60c <vprintf+0x200>
        putc(fd, '%');
 69a:	02500593          	li	a1,37
 69e:	855a                	mv	a0,s6
 6a0:	cabff0ef          	jal	34a <putc>
        putc(fd, c0);
 6a4:	85a6                	mv	a1,s1
 6a6:	855a                	mv	a0,s6
 6a8:	ca3ff0ef          	jal	34a <putc>
      state = 0;
 6ac:	4981                	li	s3,0
 6ae:	b34d                	j	450 <vprintf+0x44>

00000000000006b0 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6b0:	715d                	addi	sp,sp,-80
 6b2:	ec06                	sd	ra,24(sp)
 6b4:	e822                	sd	s0,16(sp)
 6b6:	1000                	addi	s0,sp,32
 6b8:	e010                	sd	a2,0(s0)
 6ba:	e414                	sd	a3,8(s0)
 6bc:	e818                	sd	a4,16(s0)
 6be:	ec1c                	sd	a5,24(s0)
 6c0:	03043023          	sd	a6,32(s0)
 6c4:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6c8:	8622                	mv	a2,s0
 6ca:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 6ce:	d3fff0ef          	jal	40c <vprintf>
}
 6d2:	60e2                	ld	ra,24(sp)
 6d4:	6442                	ld	s0,16(sp)
 6d6:	6161                	addi	sp,sp,80
 6d8:	8082                	ret

00000000000006da <printf>:

void
printf(const char *fmt, ...)
{
 6da:	711d                	addi	sp,sp,-96
 6dc:	ec06                	sd	ra,24(sp)
 6de:	e822                	sd	s0,16(sp)
 6e0:	1000                	addi	s0,sp,32
 6e2:	e40c                	sd	a1,8(s0)
 6e4:	e810                	sd	a2,16(s0)
 6e6:	ec14                	sd	a3,24(s0)
 6e8:	f018                	sd	a4,32(s0)
 6ea:	f41c                	sd	a5,40(s0)
 6ec:	03043823          	sd	a6,48(s0)
 6f0:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 6f4:	00840613          	addi	a2,s0,8
 6f8:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 6fc:	85aa                	mv	a1,a0
 6fe:	4505                	li	a0,1
 700:	d0dff0ef          	jal	40c <vprintf>
}
 704:	60e2                	ld	ra,24(sp)
 706:	6442                	ld	s0,16(sp)
 708:	6125                	addi	sp,sp,96
 70a:	8082                	ret

000000000000070c <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 70c:	1141                	addi	sp,sp,-16
 70e:	e406                	sd	ra,8(sp)
 710:	e022                	sd	s0,0(sp)
 712:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 714:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 718:	00001797          	auipc	a5,0x1
 71c:	8e87b783          	ld	a5,-1816(a5) # 1000 <freep>
 720:	a039                	j	72e <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 722:	6398                	ld	a4,0(a5)
 724:	00e7e463          	bltu	a5,a4,72c <free+0x20>
 728:	00e6ea63          	bltu	a3,a4,73c <free+0x30>
{
 72c:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 72e:	fed7fae3          	bgeu	a5,a3,722 <free+0x16>
 732:	6398                	ld	a4,0(a5)
 734:	00e6e463          	bltu	a3,a4,73c <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 738:	fee7eae3          	bltu	a5,a4,72c <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 73c:	ff852583          	lw	a1,-8(a0)
 740:	6390                	ld	a2,0(a5)
 742:	02059813          	slli	a6,a1,0x20
 746:	01c85713          	srli	a4,a6,0x1c
 74a:	9736                	add	a4,a4,a3
 74c:	02e60563          	beq	a2,a4,776 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 750:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 754:	4790                	lw	a2,8(a5)
 756:	02061593          	slli	a1,a2,0x20
 75a:	01c5d713          	srli	a4,a1,0x1c
 75e:	973e                	add	a4,a4,a5
 760:	02e68263          	beq	a3,a4,784 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 764:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 766:	00001717          	auipc	a4,0x1
 76a:	88f73d23          	sd	a5,-1894(a4) # 1000 <freep>
}
 76e:	60a2                	ld	ra,8(sp)
 770:	6402                	ld	s0,0(sp)
 772:	0141                	addi	sp,sp,16
 774:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 776:	4618                	lw	a4,8(a2)
 778:	9f2d                	addw	a4,a4,a1
 77a:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 77e:	6398                	ld	a4,0(a5)
 780:	6310                	ld	a2,0(a4)
 782:	b7f9                	j	750 <free+0x44>
    p->s.size += bp->s.size;
 784:	ff852703          	lw	a4,-8(a0)
 788:	9f31                	addw	a4,a4,a2
 78a:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 78c:	ff053683          	ld	a3,-16(a0)
 790:	bfd1                	j	764 <free+0x58>

0000000000000792 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 792:	7139                	addi	sp,sp,-64
 794:	fc06                	sd	ra,56(sp)
 796:	f822                	sd	s0,48(sp)
 798:	f04a                	sd	s2,32(sp)
 79a:	ec4e                	sd	s3,24(sp)
 79c:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 79e:	02051993          	slli	s3,a0,0x20
 7a2:	0209d993          	srli	s3,s3,0x20
 7a6:	09bd                	addi	s3,s3,15
 7a8:	0049d993          	srli	s3,s3,0x4
 7ac:	2985                	addiw	s3,s3,1
 7ae:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7b0:	00001517          	auipc	a0,0x1
 7b4:	85053503          	ld	a0,-1968(a0) # 1000 <freep>
 7b8:	c905                	beqz	a0,7e8 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7ba:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7bc:	4798                	lw	a4,8(a5)
 7be:	09377663          	bgeu	a4,s3,84a <malloc+0xb8>
 7c2:	f426                	sd	s1,40(sp)
 7c4:	e852                	sd	s4,16(sp)
 7c6:	e456                	sd	s5,8(sp)
 7c8:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 7ca:	8a4e                	mv	s4,s3
 7cc:	6705                	lui	a4,0x1
 7ce:	00e9f363          	bgeu	s3,a4,7d4 <malloc+0x42>
 7d2:	6a05                	lui	s4,0x1
 7d4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 7d8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7dc:	00001497          	auipc	s1,0x1
 7e0:	82448493          	addi	s1,s1,-2012 # 1000 <freep>
  if(p == (char*)-1)
 7e4:	5afd                	li	s5,-1
 7e6:	a83d                	j	824 <malloc+0x92>
 7e8:	f426                	sd	s1,40(sp)
 7ea:	e852                	sd	s4,16(sp)
 7ec:	e456                	sd	s5,8(sp)
 7ee:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 7f0:	00001797          	auipc	a5,0x1
 7f4:	82078793          	addi	a5,a5,-2016 # 1010 <base>
 7f8:	00001717          	auipc	a4,0x1
 7fc:	80f73423          	sd	a5,-2040(a4) # 1000 <freep>
 800:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 802:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 806:	b7d1                	j	7ca <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 808:	6398                	ld	a4,0(a5)
 80a:	e118                	sd	a4,0(a0)
 80c:	a899                	j	862 <malloc+0xd0>
  hp->s.size = nu;
 80e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 812:	0541                	addi	a0,a0,16
 814:	ef9ff0ef          	jal	70c <free>
  return freep;
 818:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 81a:	c125                	beqz	a0,87a <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 81c:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 81e:	4798                	lw	a4,8(a5)
 820:	03277163          	bgeu	a4,s2,842 <malloc+0xb0>
    if(p == freep)
 824:	6098                	ld	a4,0(s1)
 826:	853e                	mv	a0,a5
 828:	fef71ae3          	bne	a4,a5,81c <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 82c:	8552                	mv	a0,s4
 82e:	b05ff0ef          	jal	332 <sbrk>
  if(p == (char*)-1)
 832:	fd551ee3          	bne	a0,s5,80e <malloc+0x7c>
        return 0;
 836:	4501                	li	a0,0
 838:	74a2                	ld	s1,40(sp)
 83a:	6a42                	ld	s4,16(sp)
 83c:	6aa2                	ld	s5,8(sp)
 83e:	6b02                	ld	s6,0(sp)
 840:	a03d                	j	86e <malloc+0xdc>
 842:	74a2                	ld	s1,40(sp)
 844:	6a42                	ld	s4,16(sp)
 846:	6aa2                	ld	s5,8(sp)
 848:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 84a:	fae90fe3          	beq	s2,a4,808 <malloc+0x76>
        p->s.size -= nunits;
 84e:	4137073b          	subw	a4,a4,s3
 852:	c798                	sw	a4,8(a5)
        p += p->s.size;
 854:	02071693          	slli	a3,a4,0x20
 858:	01c6d713          	srli	a4,a3,0x1c
 85c:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 85e:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 862:	00000717          	auipc	a4,0x0
 866:	78a73f23          	sd	a0,1950(a4) # 1000 <freep>
      return (void*)(p + 1);
 86a:	01078513          	addi	a0,a5,16
  }
}
 86e:	70e2                	ld	ra,56(sp)
 870:	7442                	ld	s0,48(sp)
 872:	7902                	ld	s2,32(sp)
 874:	69e2                	ld	s3,24(sp)
 876:	6121                	addi	sp,sp,64
 878:	8082                	ret
 87a:	74a2                	ld	s1,40(sp)
 87c:	6a42                	ld	s4,16(sp)
 87e:	6aa2                	ld	s5,8(sp)
 880:	6b02                	ld	s6,0(sp)
 882:	b7f5                	j	86e <malloc+0xdc>
