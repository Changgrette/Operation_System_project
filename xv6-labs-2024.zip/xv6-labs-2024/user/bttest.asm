
user/_bttest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  sleep(1);
   8:	4505                	li	a0,1
   a:	326000ef          	jal	330 <sleep>
  exit(0);
   e:	4501                	li	a0,0
  10:	290000ef          	jal	2a0 <exit>

0000000000000014 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  14:	1141                	addi	sp,sp,-16
  16:	e406                	sd	ra,8(sp)
  18:	e022                	sd	s0,0(sp)
  1a:	0800                	addi	s0,sp,16
  extern int main();
  main();
  1c:	fe5ff0ef          	jal	0 <main>
  exit(0);
  20:	4501                	li	a0,0
  22:	27e000ef          	jal	2a0 <exit>

0000000000000026 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  26:	1141                	addi	sp,sp,-16
  28:	e406                	sd	ra,8(sp)
  2a:	e022                	sd	s0,0(sp)
  2c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  2e:	87aa                	mv	a5,a0
  30:	0585                	addi	a1,a1,1
  32:	0785                	addi	a5,a5,1
  34:	fff5c703          	lbu	a4,-1(a1)
  38:	fee78fa3          	sb	a4,-1(a5)
  3c:	fb75                	bnez	a4,30 <strcpy+0xa>
    ;
  return os;
}
  3e:	60a2                	ld	ra,8(sp)
  40:	6402                	ld	s0,0(sp)
  42:	0141                	addi	sp,sp,16
  44:	8082                	ret

0000000000000046 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  46:	1141                	addi	sp,sp,-16
  48:	e406                	sd	ra,8(sp)
  4a:	e022                	sd	s0,0(sp)
  4c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  4e:	00054783          	lbu	a5,0(a0)
  52:	cb91                	beqz	a5,66 <strcmp+0x20>
  54:	0005c703          	lbu	a4,0(a1)
  58:	00f71763          	bne	a4,a5,66 <strcmp+0x20>
    p++, q++;
  5c:	0505                	addi	a0,a0,1
  5e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  60:	00054783          	lbu	a5,0(a0)
  64:	fbe5                	bnez	a5,54 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  66:	0005c503          	lbu	a0,0(a1)
}
  6a:	40a7853b          	subw	a0,a5,a0
  6e:	60a2                	ld	ra,8(sp)
  70:	6402                	ld	s0,0(sp)
  72:	0141                	addi	sp,sp,16
  74:	8082                	ret

0000000000000076 <strlen>:

uint
strlen(const char *s)
{
  76:	1141                	addi	sp,sp,-16
  78:	e406                	sd	ra,8(sp)
  7a:	e022                	sd	s0,0(sp)
  7c:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  7e:	00054783          	lbu	a5,0(a0)
  82:	cf91                	beqz	a5,9e <strlen+0x28>
  84:	00150793          	addi	a5,a0,1
  88:	86be                	mv	a3,a5
  8a:	0785                	addi	a5,a5,1
  8c:	fff7c703          	lbu	a4,-1(a5)
  90:	ff65                	bnez	a4,88 <strlen+0x12>
  92:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  96:	60a2                	ld	ra,8(sp)
  98:	6402                	ld	s0,0(sp)
  9a:	0141                	addi	sp,sp,16
  9c:	8082                	ret
  for(n = 0; s[n]; n++)
  9e:	4501                	li	a0,0
  a0:	bfdd                	j	96 <strlen+0x20>

00000000000000a2 <memset>:

void*
memset(void *dst, int c, uint n)
{
  a2:	1141                	addi	sp,sp,-16
  a4:	e406                	sd	ra,8(sp)
  a6:	e022                	sd	s0,0(sp)
  a8:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  aa:	ca19                	beqz	a2,c0 <memset+0x1e>
  ac:	87aa                	mv	a5,a0
  ae:	1602                	slli	a2,a2,0x20
  b0:	9201                	srli	a2,a2,0x20
  b2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  b6:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  ba:	0785                	addi	a5,a5,1
  bc:	fee79de3          	bne	a5,a4,b6 <memset+0x14>
  }
  return dst;
}
  c0:	60a2                	ld	ra,8(sp)
  c2:	6402                	ld	s0,0(sp)
  c4:	0141                	addi	sp,sp,16
  c6:	8082                	ret

00000000000000c8 <strchr>:

char*
strchr(const char *s, char c)
{
  c8:	1141                	addi	sp,sp,-16
  ca:	e406                	sd	ra,8(sp)
  cc:	e022                	sd	s0,0(sp)
  ce:	0800                	addi	s0,sp,16
  for(; *s; s++)
  d0:	00054783          	lbu	a5,0(a0)
  d4:	cf81                	beqz	a5,ec <strchr+0x24>
    if(*s == c)
  d6:	00f58763          	beq	a1,a5,e4 <strchr+0x1c>
  for(; *s; s++)
  da:	0505                	addi	a0,a0,1
  dc:	00054783          	lbu	a5,0(a0)
  e0:	fbfd                	bnez	a5,d6 <strchr+0xe>
      return (char*)s;
  return 0;
  e2:	4501                	li	a0,0
}
  e4:	60a2                	ld	ra,8(sp)
  e6:	6402                	ld	s0,0(sp)
  e8:	0141                	addi	sp,sp,16
  ea:	8082                	ret
  return 0;
  ec:	4501                	li	a0,0
  ee:	bfdd                	j	e4 <strchr+0x1c>

00000000000000f0 <gets>:

char*
gets(char *buf, int max)
{
  f0:	711d                	addi	sp,sp,-96
  f2:	ec86                	sd	ra,88(sp)
  f4:	e8a2                	sd	s0,80(sp)
  f6:	e4a6                	sd	s1,72(sp)
  f8:	e0ca                	sd	s2,64(sp)
  fa:	fc4e                	sd	s3,56(sp)
  fc:	f852                	sd	s4,48(sp)
  fe:	f456                	sd	s5,40(sp)
 100:	f05a                	sd	s6,32(sp)
 102:	ec5e                	sd	s7,24(sp)
 104:	e862                	sd	s8,16(sp)
 106:	1080                	addi	s0,sp,96
 108:	8baa                	mv	s7,a0
 10a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 10c:	892a                	mv	s2,a0
 10e:	4481                	li	s1,0
    cc = read(0, &c, 1);
 110:	faf40b13          	addi	s6,s0,-81
 114:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 116:	8c26                	mv	s8,s1
 118:	0014899b          	addiw	s3,s1,1
 11c:	84ce                	mv	s1,s3
 11e:	0349d463          	bge	s3,s4,146 <gets+0x56>
    cc = read(0, &c, 1);
 122:	8656                	mv	a2,s5
 124:	85da                	mv	a1,s6
 126:	4501                	li	a0,0
 128:	190000ef          	jal	2b8 <read>
    if(cc < 1)
 12c:	00a05d63          	blez	a0,146 <gets+0x56>
      break;
    buf[i++] = c;
 130:	faf44783          	lbu	a5,-81(s0)
 134:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 138:	0905                	addi	s2,s2,1
 13a:	ff678713          	addi	a4,a5,-10
 13e:	c319                	beqz	a4,144 <gets+0x54>
 140:	17cd                	addi	a5,a5,-13
 142:	fbf1                	bnez	a5,116 <gets+0x26>
    buf[i++] = c;
 144:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 146:	9c5e                	add	s8,s8,s7
 148:	000c0023          	sb	zero,0(s8)
  return buf;
}
 14c:	855e                	mv	a0,s7
 14e:	60e6                	ld	ra,88(sp)
 150:	6446                	ld	s0,80(sp)
 152:	64a6                	ld	s1,72(sp)
 154:	6906                	ld	s2,64(sp)
 156:	79e2                	ld	s3,56(sp)
 158:	7a42                	ld	s4,48(sp)
 15a:	7aa2                	ld	s5,40(sp)
 15c:	7b02                	ld	s6,32(sp)
 15e:	6be2                	ld	s7,24(sp)
 160:	6c42                	ld	s8,16(sp)
 162:	6125                	addi	sp,sp,96
 164:	8082                	ret

0000000000000166 <stat>:

int
stat(const char *n, struct stat *st)
{
 166:	1101                	addi	sp,sp,-32
 168:	ec06                	sd	ra,24(sp)
 16a:	e822                	sd	s0,16(sp)
 16c:	e04a                	sd	s2,0(sp)
 16e:	1000                	addi	s0,sp,32
 170:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 172:	4581                	li	a1,0
 174:	16c000ef          	jal	2e0 <open>
  if(fd < 0)
 178:	02054263          	bltz	a0,19c <stat+0x36>
 17c:	e426                	sd	s1,8(sp)
 17e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 180:	85ca                	mv	a1,s2
 182:	176000ef          	jal	2f8 <fstat>
 186:	892a                	mv	s2,a0
  close(fd);
 188:	8526                	mv	a0,s1
 18a:	13e000ef          	jal	2c8 <close>
  return r;
 18e:	64a2                	ld	s1,8(sp)
}
 190:	854a                	mv	a0,s2
 192:	60e2                	ld	ra,24(sp)
 194:	6442                	ld	s0,16(sp)
 196:	6902                	ld	s2,0(sp)
 198:	6105                	addi	sp,sp,32
 19a:	8082                	ret
    return -1;
 19c:	57fd                	li	a5,-1
 19e:	893e                	mv	s2,a5
 1a0:	bfc5                	j	190 <stat+0x2a>

00000000000001a2 <atoi>:

int
atoi(const char *s)
{
 1a2:	1141                	addi	sp,sp,-16
 1a4:	e406                	sd	ra,8(sp)
 1a6:	e022                	sd	s0,0(sp)
 1a8:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1aa:	00054683          	lbu	a3,0(a0)
 1ae:	fd06879b          	addiw	a5,a3,-48
 1b2:	0ff7f793          	zext.b	a5,a5
 1b6:	4625                	li	a2,9
 1b8:	02f66963          	bltu	a2,a5,1ea <atoi+0x48>
 1bc:	872a                	mv	a4,a0
  n = 0;
 1be:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 1c0:	0705                	addi	a4,a4,1
 1c2:	0025179b          	slliw	a5,a0,0x2
 1c6:	9fa9                	addw	a5,a5,a0
 1c8:	0017979b          	slliw	a5,a5,0x1
 1cc:	9fb5                	addw	a5,a5,a3
 1ce:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1d2:	00074683          	lbu	a3,0(a4)
 1d6:	fd06879b          	addiw	a5,a3,-48
 1da:	0ff7f793          	zext.b	a5,a5
 1de:	fef671e3          	bgeu	a2,a5,1c0 <atoi+0x1e>
  return n;
}
 1e2:	60a2                	ld	ra,8(sp)
 1e4:	6402                	ld	s0,0(sp)
 1e6:	0141                	addi	sp,sp,16
 1e8:	8082                	ret
  n = 0;
 1ea:	4501                	li	a0,0
 1ec:	bfdd                	j	1e2 <atoi+0x40>

00000000000001ee <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1ee:	1141                	addi	sp,sp,-16
 1f0:	e406                	sd	ra,8(sp)
 1f2:	e022                	sd	s0,0(sp)
 1f4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 1f6:	02b57563          	bgeu	a0,a1,220 <memmove+0x32>
    while(n-- > 0)
 1fa:	00c05f63          	blez	a2,218 <memmove+0x2a>
 1fe:	1602                	slli	a2,a2,0x20
 200:	9201                	srli	a2,a2,0x20
 202:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 206:	872a                	mv	a4,a0
      *dst++ = *src++;
 208:	0585                	addi	a1,a1,1
 20a:	0705                	addi	a4,a4,1
 20c:	fff5c683          	lbu	a3,-1(a1)
 210:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 214:	fee79ae3          	bne	a5,a4,208 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 218:	60a2                	ld	ra,8(sp)
 21a:	6402                	ld	s0,0(sp)
 21c:	0141                	addi	sp,sp,16
 21e:	8082                	ret
    while(n-- > 0)
 220:	fec05ce3          	blez	a2,218 <memmove+0x2a>
    dst += n;
 224:	00c50733          	add	a4,a0,a2
    src += n;
 228:	95b2                	add	a1,a1,a2
 22a:	fff6079b          	addiw	a5,a2,-1
 22e:	1782                	slli	a5,a5,0x20
 230:	9381                	srli	a5,a5,0x20
 232:	fff7c793          	not	a5,a5
 236:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 238:	15fd                	addi	a1,a1,-1
 23a:	177d                	addi	a4,a4,-1
 23c:	0005c683          	lbu	a3,0(a1)
 240:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 244:	fef71ae3          	bne	a4,a5,238 <memmove+0x4a>
 248:	bfc1                	j	218 <memmove+0x2a>

000000000000024a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 24a:	1141                	addi	sp,sp,-16
 24c:	e406                	sd	ra,8(sp)
 24e:	e022                	sd	s0,0(sp)
 250:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 252:	c61d                	beqz	a2,280 <memcmp+0x36>
 254:	1602                	slli	a2,a2,0x20
 256:	9201                	srli	a2,a2,0x20
 258:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 25c:	00054783          	lbu	a5,0(a0)
 260:	0005c703          	lbu	a4,0(a1)
 264:	00e79863          	bne	a5,a4,274 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 268:	0505                	addi	a0,a0,1
    p2++;
 26a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 26c:	fed518e3          	bne	a0,a3,25c <memcmp+0x12>
  }
  return 0;
 270:	4501                	li	a0,0
 272:	a019                	j	278 <memcmp+0x2e>
      return *p1 - *p2;
 274:	40e7853b          	subw	a0,a5,a4
}
 278:	60a2                	ld	ra,8(sp)
 27a:	6402                	ld	s0,0(sp)
 27c:	0141                	addi	sp,sp,16
 27e:	8082                	ret
  return 0;
 280:	4501                	li	a0,0
 282:	bfdd                	j	278 <memcmp+0x2e>

0000000000000284 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 284:	1141                	addi	sp,sp,-16
 286:	e406                	sd	ra,8(sp)
 288:	e022                	sd	s0,0(sp)
 28a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 28c:	f63ff0ef          	jal	1ee <memmove>
}
 290:	60a2                	ld	ra,8(sp)
 292:	6402                	ld	s0,0(sp)
 294:	0141                	addi	sp,sp,16
 296:	8082                	ret

0000000000000298 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 298:	4885                	li	a7,1
 ecall
 29a:	00000073          	ecall
 ret
 29e:	8082                	ret

00000000000002a0 <exit>:
.global exit
exit:
 li a7, SYS_exit
 2a0:	4889                	li	a7,2
 ecall
 2a2:	00000073          	ecall
 ret
 2a6:	8082                	ret

00000000000002a8 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2a8:	488d                	li	a7,3
 ecall
 2aa:	00000073          	ecall
 ret
 2ae:	8082                	ret

00000000000002b0 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2b0:	4891                	li	a7,4
 ecall
 2b2:	00000073          	ecall
 ret
 2b6:	8082                	ret

00000000000002b8 <read>:
.global read
read:
 li a7, SYS_read
 2b8:	4895                	li	a7,5
 ecall
 2ba:	00000073          	ecall
 ret
 2be:	8082                	ret

00000000000002c0 <write>:
.global write
write:
 li a7, SYS_write
 2c0:	48c1                	li	a7,16
 ecall
 2c2:	00000073          	ecall
 ret
 2c6:	8082                	ret

00000000000002c8 <close>:
.global close
close:
 li a7, SYS_close
 2c8:	48d5                	li	a7,21
 ecall
 2ca:	00000073          	ecall
 ret
 2ce:	8082                	ret

00000000000002d0 <kill>:
.global kill
kill:
 li a7, SYS_kill
 2d0:	4899                	li	a7,6
 ecall
 2d2:	00000073          	ecall
 ret
 2d6:	8082                	ret

00000000000002d8 <exec>:
.global exec
exec:
 li a7, SYS_exec
 2d8:	489d                	li	a7,7
 ecall
 2da:	00000073          	ecall
 ret
 2de:	8082                	ret

00000000000002e0 <open>:
.global open
open:
 li a7, SYS_open
 2e0:	48bd                	li	a7,15
 ecall
 2e2:	00000073          	ecall
 ret
 2e6:	8082                	ret

00000000000002e8 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 2e8:	48c5                	li	a7,17
 ecall
 2ea:	00000073          	ecall
 ret
 2ee:	8082                	ret

00000000000002f0 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 2f0:	48c9                	li	a7,18
 ecall
 2f2:	00000073          	ecall
 ret
 2f6:	8082                	ret

00000000000002f8 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 2f8:	48a1                	li	a7,8
 ecall
 2fa:	00000073          	ecall
 ret
 2fe:	8082                	ret

0000000000000300 <link>:
.global link
link:
 li a7, SYS_link
 300:	48cd                	li	a7,19
 ecall
 302:	00000073          	ecall
 ret
 306:	8082                	ret

0000000000000308 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 308:	48d1                	li	a7,20
 ecall
 30a:	00000073          	ecall
 ret
 30e:	8082                	ret

0000000000000310 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 310:	48a5                	li	a7,9
 ecall
 312:	00000073          	ecall
 ret
 316:	8082                	ret

0000000000000318 <dup>:
.global dup
dup:
 li a7, SYS_dup
 318:	48a9                	li	a7,10
 ecall
 31a:	00000073          	ecall
 ret
 31e:	8082                	ret

0000000000000320 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 320:	48ad                	li	a7,11
 ecall
 322:	00000073          	ecall
 ret
 326:	8082                	ret

0000000000000328 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 328:	48b1                	li	a7,12
 ecall
 32a:	00000073          	ecall
 ret
 32e:	8082                	ret

0000000000000330 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 330:	48b5                	li	a7,13
 ecall
 332:	00000073          	ecall
 ret
 336:	8082                	ret

0000000000000338 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 338:	48b9                	li	a7,14
 ecall
 33a:	00000073          	ecall
 ret
 33e:	8082                	ret

0000000000000340 <sigalarm>:
.global sigalarm
sigalarm:
 li a7, SYS_sigalarm
 340:	48d9                	li	a7,22
 ecall
 342:	00000073          	ecall
 ret
 346:	8082                	ret

0000000000000348 <sigreturn>:
.global sigreturn
sigreturn:
 li a7, SYS_sigreturn
 348:	48dd                	li	a7,23
 ecall
 34a:	00000073          	ecall
 ret
 34e:	8082                	ret

0000000000000350 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 350:	1101                	addi	sp,sp,-32
 352:	ec06                	sd	ra,24(sp)
 354:	e822                	sd	s0,16(sp)
 356:	1000                	addi	s0,sp,32
 358:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 35c:	4605                	li	a2,1
 35e:	fef40593          	addi	a1,s0,-17
 362:	f5fff0ef          	jal	2c0 <write>
}
 366:	60e2                	ld	ra,24(sp)
 368:	6442                	ld	s0,16(sp)
 36a:	6105                	addi	sp,sp,32
 36c:	8082                	ret

000000000000036e <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 36e:	7139                	addi	sp,sp,-64
 370:	fc06                	sd	ra,56(sp)
 372:	f822                	sd	s0,48(sp)
 374:	f04a                	sd	s2,32(sp)
 376:	ec4e                	sd	s3,24(sp)
 378:	0080                	addi	s0,sp,64
 37a:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 37c:	cac9                	beqz	a3,40e <printint+0xa0>
 37e:	01f5d79b          	srliw	a5,a1,0x1f
 382:	c7d1                	beqz	a5,40e <printint+0xa0>
    neg = 1;
    x = -xx;
 384:	40b005bb          	negw	a1,a1
    neg = 1;
 388:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 38a:	fc040993          	addi	s3,s0,-64
  neg = 0;
 38e:	86ce                	mv	a3,s3
  i = 0;
 390:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 392:	00000817          	auipc	a6,0x0
 396:	50680813          	addi	a6,a6,1286 # 898 <digits>
 39a:	88ba                	mv	a7,a4
 39c:	0017051b          	addiw	a0,a4,1
 3a0:	872a                	mv	a4,a0
 3a2:	02c5f7bb          	remuw	a5,a1,a2
 3a6:	1782                	slli	a5,a5,0x20
 3a8:	9381                	srli	a5,a5,0x20
 3aa:	97c2                	add	a5,a5,a6
 3ac:	0007c783          	lbu	a5,0(a5)
 3b0:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 3b4:	87ae                	mv	a5,a1
 3b6:	02c5d5bb          	divuw	a1,a1,a2
 3ba:	0685                	addi	a3,a3,1
 3bc:	fcc7ffe3          	bgeu	a5,a2,39a <printint+0x2c>
  if(neg)
 3c0:	00030c63          	beqz	t1,3d8 <printint+0x6a>
    buf[i++] = '-';
 3c4:	fd050793          	addi	a5,a0,-48
 3c8:	00878533          	add	a0,a5,s0
 3cc:	02d00793          	li	a5,45
 3d0:	fef50823          	sb	a5,-16(a0)
 3d4:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 3d8:	02e05563          	blez	a4,402 <printint+0x94>
 3dc:	f426                	sd	s1,40(sp)
 3de:	377d                	addiw	a4,a4,-1
 3e0:	00e984b3          	add	s1,s3,a4
 3e4:	19fd                	addi	s3,s3,-1
 3e6:	99ba                	add	s3,s3,a4
 3e8:	1702                	slli	a4,a4,0x20
 3ea:	9301                	srli	a4,a4,0x20
 3ec:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 3f0:	0004c583          	lbu	a1,0(s1)
 3f4:	854a                	mv	a0,s2
 3f6:	f5bff0ef          	jal	350 <putc>
  while(--i >= 0)
 3fa:	14fd                	addi	s1,s1,-1
 3fc:	ff349ae3          	bne	s1,s3,3f0 <printint+0x82>
 400:	74a2                	ld	s1,40(sp)
}
 402:	70e2                	ld	ra,56(sp)
 404:	7442                	ld	s0,48(sp)
 406:	7902                	ld	s2,32(sp)
 408:	69e2                	ld	s3,24(sp)
 40a:	6121                	addi	sp,sp,64
 40c:	8082                	ret
  neg = 0;
 40e:	4301                	li	t1,0
 410:	bfad                	j	38a <printint+0x1c>

0000000000000412 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 412:	711d                	addi	sp,sp,-96
 414:	ec86                	sd	ra,88(sp)
 416:	e8a2                	sd	s0,80(sp)
 418:	e4a6                	sd	s1,72(sp)
 41a:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 41c:	0005c483          	lbu	s1,0(a1)
 420:	20048963          	beqz	s1,632 <vprintf+0x220>
 424:	e0ca                	sd	s2,64(sp)
 426:	fc4e                	sd	s3,56(sp)
 428:	f852                	sd	s4,48(sp)
 42a:	f456                	sd	s5,40(sp)
 42c:	f05a                	sd	s6,32(sp)
 42e:	ec5e                	sd	s7,24(sp)
 430:	e862                	sd	s8,16(sp)
 432:	8b2a                	mv	s6,a0
 434:	8a2e                	mv	s4,a1
 436:	8bb2                	mv	s7,a2
  state = 0;
 438:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 43a:	4901                	li	s2,0
 43c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 43e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 442:	06400c13          	li	s8,100
 446:	a00d                	j	468 <vprintf+0x56>
        putc(fd, c0);
 448:	85a6                	mv	a1,s1
 44a:	855a                	mv	a0,s6
 44c:	f05ff0ef          	jal	350 <putc>
 450:	a019                	j	456 <vprintf+0x44>
    } else if(state == '%'){
 452:	03598363          	beq	s3,s5,478 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 456:	0019079b          	addiw	a5,s2,1
 45a:	893e                	mv	s2,a5
 45c:	873e                	mv	a4,a5
 45e:	97d2                	add	a5,a5,s4
 460:	0007c483          	lbu	s1,0(a5)
 464:	1c048063          	beqz	s1,624 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 468:	0004879b          	sext.w	a5,s1
    if(state == 0){
 46c:	fe0993e3          	bnez	s3,452 <vprintf+0x40>
      if(c0 == '%'){
 470:	fd579ce3          	bne	a5,s5,448 <vprintf+0x36>
        state = '%';
 474:	89be                	mv	s3,a5
 476:	b7c5                	j	456 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 478:	00ea06b3          	add	a3,s4,a4
 47c:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 480:	1a060e63          	beqz	a2,63c <vprintf+0x22a>
      if(c0 == 'd'){
 484:	03878763          	beq	a5,s8,4b2 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 488:	f9478693          	addi	a3,a5,-108
 48c:	0016b693          	seqz	a3,a3
 490:	f9c60593          	addi	a1,a2,-100
 494:	e99d                	bnez	a1,4ca <vprintf+0xb8>
 496:	ca95                	beqz	a3,4ca <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 498:	008b8493          	addi	s1,s7,8
 49c:	4685                	li	a3,1
 49e:	4629                	li	a2,10
 4a0:	000ba583          	lw	a1,0(s7)
 4a4:	855a                	mv	a0,s6
 4a6:	ec9ff0ef          	jal	36e <printint>
        i += 1;
 4aa:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 4ac:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 4ae:	4981                	li	s3,0
 4b0:	b75d                	j	456 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 4b2:	008b8493          	addi	s1,s7,8
 4b6:	4685                	li	a3,1
 4b8:	4629                	li	a2,10
 4ba:	000ba583          	lw	a1,0(s7)
 4be:	855a                	mv	a0,s6
 4c0:	eafff0ef          	jal	36e <printint>
 4c4:	8ba6                	mv	s7,s1
      state = 0;
 4c6:	4981                	li	s3,0
 4c8:	b779                	j	456 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 4ca:	9752                	add	a4,a4,s4
 4cc:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4d0:	f9460713          	addi	a4,a2,-108
 4d4:	00173713          	seqz	a4,a4
 4d8:	8f75                	and	a4,a4,a3
 4da:	f9c58513          	addi	a0,a1,-100
 4de:	16051963          	bnez	a0,650 <vprintf+0x23e>
 4e2:	16070763          	beqz	a4,650 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 4e6:	008b8493          	addi	s1,s7,8
 4ea:	4685                	li	a3,1
 4ec:	4629                	li	a2,10
 4ee:	000ba583          	lw	a1,0(s7)
 4f2:	855a                	mv	a0,s6
 4f4:	e7bff0ef          	jal	36e <printint>
        i += 2;
 4f8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 4fa:	8ba6                	mv	s7,s1
      state = 0;
 4fc:	4981                	li	s3,0
        i += 2;
 4fe:	bfa1                	j	456 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 500:	008b8493          	addi	s1,s7,8
 504:	4681                	li	a3,0
 506:	4629                	li	a2,10
 508:	000ba583          	lw	a1,0(s7)
 50c:	855a                	mv	a0,s6
 50e:	e61ff0ef          	jal	36e <printint>
 512:	8ba6                	mv	s7,s1
      state = 0;
 514:	4981                	li	s3,0
 516:	b781                	j	456 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 518:	008b8493          	addi	s1,s7,8
 51c:	4681                	li	a3,0
 51e:	4629                	li	a2,10
 520:	000ba583          	lw	a1,0(s7)
 524:	855a                	mv	a0,s6
 526:	e49ff0ef          	jal	36e <printint>
        i += 1;
 52a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 52c:	8ba6                	mv	s7,s1
      state = 0;
 52e:	4981                	li	s3,0
 530:	b71d                	j	456 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 532:	008b8493          	addi	s1,s7,8
 536:	4681                	li	a3,0
 538:	4629                	li	a2,10
 53a:	000ba583          	lw	a1,0(s7)
 53e:	855a                	mv	a0,s6
 540:	e2fff0ef          	jal	36e <printint>
        i += 2;
 544:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 546:	8ba6                	mv	s7,s1
      state = 0;
 548:	4981                	li	s3,0
        i += 2;
 54a:	b731                	j	456 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 54c:	008b8493          	addi	s1,s7,8
 550:	4681                	li	a3,0
 552:	4641                	li	a2,16
 554:	000ba583          	lw	a1,0(s7)
 558:	855a                	mv	a0,s6
 55a:	e15ff0ef          	jal	36e <printint>
 55e:	8ba6                	mv	s7,s1
      state = 0;
 560:	4981                	li	s3,0
 562:	bdd5                	j	456 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 564:	008b8493          	addi	s1,s7,8
 568:	4681                	li	a3,0
 56a:	4641                	li	a2,16
 56c:	000ba583          	lw	a1,0(s7)
 570:	855a                	mv	a0,s6
 572:	dfdff0ef          	jal	36e <printint>
        i += 1;
 576:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 578:	8ba6                	mv	s7,s1
      state = 0;
 57a:	4981                	li	s3,0
 57c:	bde9                	j	456 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 57e:	008b8493          	addi	s1,s7,8
 582:	4681                	li	a3,0
 584:	4641                	li	a2,16
 586:	000ba583          	lw	a1,0(s7)
 58a:	855a                	mv	a0,s6
 58c:	de3ff0ef          	jal	36e <printint>
        i += 2;
 590:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 592:	8ba6                	mv	s7,s1
      state = 0;
 594:	4981                	li	s3,0
        i += 2;
 596:	b5c1                	j	456 <vprintf+0x44>
 598:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 59a:	008b8793          	addi	a5,s7,8
 59e:	8cbe                	mv	s9,a5
 5a0:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 5a4:	03000593          	li	a1,48
 5a8:	855a                	mv	a0,s6
 5aa:	da7ff0ef          	jal	350 <putc>
  putc(fd, 'x');
 5ae:	07800593          	li	a1,120
 5b2:	855a                	mv	a0,s6
 5b4:	d9dff0ef          	jal	350 <putc>
 5b8:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5ba:	00000b97          	auipc	s7,0x0
 5be:	2deb8b93          	addi	s7,s7,734 # 898 <digits>
 5c2:	03c9d793          	srli	a5,s3,0x3c
 5c6:	97de                	add	a5,a5,s7
 5c8:	0007c583          	lbu	a1,0(a5)
 5cc:	855a                	mv	a0,s6
 5ce:	d83ff0ef          	jal	350 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 5d2:	0992                	slli	s3,s3,0x4
 5d4:	34fd                	addiw	s1,s1,-1
 5d6:	f4f5                	bnez	s1,5c2 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 5d8:	8be6                	mv	s7,s9
      state = 0;
 5da:	4981                	li	s3,0
 5dc:	6ca2                	ld	s9,8(sp)
 5de:	bda5                	j	456 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 5e0:	008b8993          	addi	s3,s7,8
 5e4:	000bb483          	ld	s1,0(s7)
 5e8:	cc91                	beqz	s1,604 <vprintf+0x1f2>
        for(; *s; s++)
 5ea:	0004c583          	lbu	a1,0(s1)
 5ee:	c985                	beqz	a1,61e <vprintf+0x20c>
          putc(fd, *s);
 5f0:	855a                	mv	a0,s6
 5f2:	d5fff0ef          	jal	350 <putc>
        for(; *s; s++)
 5f6:	0485                	addi	s1,s1,1
 5f8:	0004c583          	lbu	a1,0(s1)
 5fc:	f9f5                	bnez	a1,5f0 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 5fe:	8bce                	mv	s7,s3
      state = 0;
 600:	4981                	li	s3,0
 602:	bd91                	j	456 <vprintf+0x44>
          s = "(null)";
 604:	00000497          	auipc	s1,0x0
 608:	28c48493          	addi	s1,s1,652 # 890 <malloc+0xf8>
        for(; *s; s++)
 60c:	02800593          	li	a1,40
 610:	b7c5                	j	5f0 <vprintf+0x1de>
        putc(fd, '%');
 612:	85be                	mv	a1,a5
 614:	855a                	mv	a0,s6
 616:	d3bff0ef          	jal	350 <putc>
      state = 0;
 61a:	4981                	li	s3,0
 61c:	bd2d                	j	456 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 61e:	8bce                	mv	s7,s3
      state = 0;
 620:	4981                	li	s3,0
 622:	bd15                	j	456 <vprintf+0x44>
 624:	6906                	ld	s2,64(sp)
 626:	79e2                	ld	s3,56(sp)
 628:	7a42                	ld	s4,48(sp)
 62a:	7aa2                	ld	s5,40(sp)
 62c:	7b02                	ld	s6,32(sp)
 62e:	6be2                	ld	s7,24(sp)
 630:	6c42                	ld	s8,16(sp)
    }
  }
}
 632:	60e6                	ld	ra,88(sp)
 634:	6446                	ld	s0,80(sp)
 636:	64a6                	ld	s1,72(sp)
 638:	6125                	addi	sp,sp,96
 63a:	8082                	ret
      if(c0 == 'd'){
 63c:	06400713          	li	a4,100
 640:	e6e789e3          	beq	a5,a4,4b2 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 644:	f9478693          	addi	a3,a5,-108
 648:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 64c:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 64e:	4701                	li	a4,0
      } else if(c0 == 'u'){
 650:	07500513          	li	a0,117
 654:	eaa786e3          	beq	a5,a0,500 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 658:	f8b60513          	addi	a0,a2,-117
 65c:	e119                	bnez	a0,662 <vprintf+0x250>
 65e:	ea069de3          	bnez	a3,518 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 662:	f8b58513          	addi	a0,a1,-117
 666:	e119                	bnez	a0,66c <vprintf+0x25a>
 668:	ec0715e3          	bnez	a4,532 <vprintf+0x120>
      } else if(c0 == 'x'){
 66c:	07800513          	li	a0,120
 670:	eca78ee3          	beq	a5,a0,54c <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 674:	f8860613          	addi	a2,a2,-120
 678:	e219                	bnez	a2,67e <vprintf+0x26c>
 67a:	ee0695e3          	bnez	a3,564 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 67e:	f8858593          	addi	a1,a1,-120
 682:	e199                	bnez	a1,688 <vprintf+0x276>
 684:	ee071de3          	bnez	a4,57e <vprintf+0x16c>
      } else if(c0 == 'p'){
 688:	07000713          	li	a4,112
 68c:	f0e786e3          	beq	a5,a4,598 <vprintf+0x186>
      } else if(c0 == 's'){
 690:	07300713          	li	a4,115
 694:	f4e786e3          	beq	a5,a4,5e0 <vprintf+0x1ce>
      } else if(c0 == '%'){
 698:	02500713          	li	a4,37
 69c:	f6e78be3          	beq	a5,a4,612 <vprintf+0x200>
        putc(fd, '%');
 6a0:	02500593          	li	a1,37
 6a4:	855a                	mv	a0,s6
 6a6:	cabff0ef          	jal	350 <putc>
        putc(fd, c0);
 6aa:	85a6                	mv	a1,s1
 6ac:	855a                	mv	a0,s6
 6ae:	ca3ff0ef          	jal	350 <putc>
      state = 0;
 6b2:	4981                	li	s3,0
 6b4:	b34d                	j	456 <vprintf+0x44>

00000000000006b6 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6b6:	715d                	addi	sp,sp,-80
 6b8:	ec06                	sd	ra,24(sp)
 6ba:	e822                	sd	s0,16(sp)
 6bc:	1000                	addi	s0,sp,32
 6be:	e010                	sd	a2,0(s0)
 6c0:	e414                	sd	a3,8(s0)
 6c2:	e818                	sd	a4,16(s0)
 6c4:	ec1c                	sd	a5,24(s0)
 6c6:	03043023          	sd	a6,32(s0)
 6ca:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6ce:	8622                	mv	a2,s0
 6d0:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 6d4:	d3fff0ef          	jal	412 <vprintf>
}
 6d8:	60e2                	ld	ra,24(sp)
 6da:	6442                	ld	s0,16(sp)
 6dc:	6161                	addi	sp,sp,80
 6de:	8082                	ret

00000000000006e0 <printf>:

void
printf(const char *fmt, ...)
{
 6e0:	711d                	addi	sp,sp,-96
 6e2:	ec06                	sd	ra,24(sp)
 6e4:	e822                	sd	s0,16(sp)
 6e6:	1000                	addi	s0,sp,32
 6e8:	e40c                	sd	a1,8(s0)
 6ea:	e810                	sd	a2,16(s0)
 6ec:	ec14                	sd	a3,24(s0)
 6ee:	f018                	sd	a4,32(s0)
 6f0:	f41c                	sd	a5,40(s0)
 6f2:	03043823          	sd	a6,48(s0)
 6f6:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 6fa:	00840613          	addi	a2,s0,8
 6fe:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 702:	85aa                	mv	a1,a0
 704:	4505                	li	a0,1
 706:	d0dff0ef          	jal	412 <vprintf>
}
 70a:	60e2                	ld	ra,24(sp)
 70c:	6442                	ld	s0,16(sp)
 70e:	6125                	addi	sp,sp,96
 710:	8082                	ret

0000000000000712 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 712:	1141                	addi	sp,sp,-16
 714:	e406                	sd	ra,8(sp)
 716:	e022                	sd	s0,0(sp)
 718:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 71a:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 71e:	00001797          	auipc	a5,0x1
 722:	8e27b783          	ld	a5,-1822(a5) # 1000 <freep>
 726:	a039                	j	734 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 728:	6398                	ld	a4,0(a5)
 72a:	00e7e463          	bltu	a5,a4,732 <free+0x20>
 72e:	00e6ea63          	bltu	a3,a4,742 <free+0x30>
{
 732:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 734:	fed7fae3          	bgeu	a5,a3,728 <free+0x16>
 738:	6398                	ld	a4,0(a5)
 73a:	00e6e463          	bltu	a3,a4,742 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 73e:	fee7eae3          	bltu	a5,a4,732 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 742:	ff852583          	lw	a1,-8(a0)
 746:	6390                	ld	a2,0(a5)
 748:	02059813          	slli	a6,a1,0x20
 74c:	01c85713          	srli	a4,a6,0x1c
 750:	9736                	add	a4,a4,a3
 752:	02e60563          	beq	a2,a4,77c <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 756:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 75a:	4790                	lw	a2,8(a5)
 75c:	02061593          	slli	a1,a2,0x20
 760:	01c5d713          	srli	a4,a1,0x1c
 764:	973e                	add	a4,a4,a5
 766:	02e68263          	beq	a3,a4,78a <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 76a:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 76c:	00001717          	auipc	a4,0x1
 770:	88f73a23          	sd	a5,-1900(a4) # 1000 <freep>
}
 774:	60a2                	ld	ra,8(sp)
 776:	6402                	ld	s0,0(sp)
 778:	0141                	addi	sp,sp,16
 77a:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 77c:	4618                	lw	a4,8(a2)
 77e:	9f2d                	addw	a4,a4,a1
 780:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 784:	6398                	ld	a4,0(a5)
 786:	6310                	ld	a2,0(a4)
 788:	b7f9                	j	756 <free+0x44>
    p->s.size += bp->s.size;
 78a:	ff852703          	lw	a4,-8(a0)
 78e:	9f31                	addw	a4,a4,a2
 790:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 792:	ff053683          	ld	a3,-16(a0)
 796:	bfd1                	j	76a <free+0x58>

0000000000000798 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 798:	7139                	addi	sp,sp,-64
 79a:	fc06                	sd	ra,56(sp)
 79c:	f822                	sd	s0,48(sp)
 79e:	f04a                	sd	s2,32(sp)
 7a0:	ec4e                	sd	s3,24(sp)
 7a2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7a4:	02051993          	slli	s3,a0,0x20
 7a8:	0209d993          	srli	s3,s3,0x20
 7ac:	09bd                	addi	s3,s3,15
 7ae:	0049d993          	srli	s3,s3,0x4
 7b2:	2985                	addiw	s3,s3,1
 7b4:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7b6:	00001517          	auipc	a0,0x1
 7ba:	84a53503          	ld	a0,-1974(a0) # 1000 <freep>
 7be:	c905                	beqz	a0,7ee <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7c0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7c2:	4798                	lw	a4,8(a5)
 7c4:	09377663          	bgeu	a4,s3,850 <malloc+0xb8>
 7c8:	f426                	sd	s1,40(sp)
 7ca:	e852                	sd	s4,16(sp)
 7cc:	e456                	sd	s5,8(sp)
 7ce:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 7d0:	8a4e                	mv	s4,s3
 7d2:	6705                	lui	a4,0x1
 7d4:	00e9f363          	bgeu	s3,a4,7da <malloc+0x42>
 7d8:	6a05                	lui	s4,0x1
 7da:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 7de:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7e2:	00001497          	auipc	s1,0x1
 7e6:	81e48493          	addi	s1,s1,-2018 # 1000 <freep>
  if(p == (char*)-1)
 7ea:	5afd                	li	s5,-1
 7ec:	a83d                	j	82a <malloc+0x92>
 7ee:	f426                	sd	s1,40(sp)
 7f0:	e852                	sd	s4,16(sp)
 7f2:	e456                	sd	s5,8(sp)
 7f4:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 7f6:	00001797          	auipc	a5,0x1
 7fa:	81a78793          	addi	a5,a5,-2022 # 1010 <base>
 7fe:	00001717          	auipc	a4,0x1
 802:	80f73123          	sd	a5,-2046(a4) # 1000 <freep>
 806:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 808:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 80c:	b7d1                	j	7d0 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 80e:	6398                	ld	a4,0(a5)
 810:	e118                	sd	a4,0(a0)
 812:	a899                	j	868 <malloc+0xd0>
  hp->s.size = nu;
 814:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 818:	0541                	addi	a0,a0,16
 81a:	ef9ff0ef          	jal	712 <free>
  return freep;
 81e:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 820:	c125                	beqz	a0,880 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 822:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 824:	4798                	lw	a4,8(a5)
 826:	03277163          	bgeu	a4,s2,848 <malloc+0xb0>
    if(p == freep)
 82a:	6098                	ld	a4,0(s1)
 82c:	853e                	mv	a0,a5
 82e:	fef71ae3          	bne	a4,a5,822 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 832:	8552                	mv	a0,s4
 834:	af5ff0ef          	jal	328 <sbrk>
  if(p == (char*)-1)
 838:	fd551ee3          	bne	a0,s5,814 <malloc+0x7c>
        return 0;
 83c:	4501                	li	a0,0
 83e:	74a2                	ld	s1,40(sp)
 840:	6a42                	ld	s4,16(sp)
 842:	6aa2                	ld	s5,8(sp)
 844:	6b02                	ld	s6,0(sp)
 846:	a03d                	j	874 <malloc+0xdc>
 848:	74a2                	ld	s1,40(sp)
 84a:	6a42                	ld	s4,16(sp)
 84c:	6aa2                	ld	s5,8(sp)
 84e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 850:	fae90fe3          	beq	s2,a4,80e <malloc+0x76>
        p->s.size -= nunits;
 854:	4137073b          	subw	a4,a4,s3
 858:	c798                	sw	a4,8(a5)
        p += p->s.size;
 85a:	02071693          	slli	a3,a4,0x20
 85e:	01c6d713          	srli	a4,a3,0x1c
 862:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 864:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 868:	00000717          	auipc	a4,0x0
 86c:	78a73c23          	sd	a0,1944(a4) # 1000 <freep>
      return (void*)(p + 1);
 870:	01078513          	addi	a0,a5,16
  }
}
 874:	70e2                	ld	ra,56(sp)
 876:	7442                	ld	s0,48(sp)
 878:	7902                	ld	s2,32(sp)
 87a:	69e2                	ld	s3,24(sp)
 87c:	6121                	addi	sp,sp,64
 87e:	8082                	ret
 880:	74a2                	ld	s1,40(sp)
 882:	6a42                	ld	s4,16(sp)
 884:	6aa2                	ld	s5,8(sp)
 886:	6b02                	ld	s6,0(sp)
 888:	b7f5                	j	874 <malloc+0xdc>
