
user/_ls:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <fmtname>:
#include "kernel/fs.h"
#include "kernel/fcntl.h"

char*
fmtname(char *path)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	1000                	addi	s0,sp,32
   a:	84aa                	mv	s1,a0
  static char buf[DIRSIZ+1];
  char *p;

  // Find first character after last slash.
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
   c:	2ae000ef          	jal	2ba <strlen>
  10:	02051793          	slli	a5,a0,0x20
  14:	9381                	srli	a5,a5,0x20
  16:	97a6                	add	a5,a5,s1
  18:	02f00693          	li	a3,47
  1c:	0097e963          	bltu	a5,s1,2e <fmtname+0x2e>
  20:	0007c703          	lbu	a4,0(a5)
  24:	00d70563          	beq	a4,a3,2e <fmtname+0x2e>
  28:	17fd                	addi	a5,a5,-1
  2a:	fe97fbe3          	bgeu	a5,s1,20 <fmtname+0x20>
    ;
  p++;
  2e:	00178493          	addi	s1,a5,1

  // Return blank-padded name.
  if(strlen(p) >= DIRSIZ)
  32:	8526                	mv	a0,s1
  34:	286000ef          	jal	2ba <strlen>
  38:	47b5                	li	a5,13
  3a:	00a7f863          	bgeu	a5,a0,4a <fmtname+0x4a>
    return p;
  memmove(buf, p, strlen(p));
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  return buf;
}
  3e:	8526                	mv	a0,s1
  40:	60e2                	ld	ra,24(sp)
  42:	6442                	ld	s0,16(sp)
  44:	64a2                	ld	s1,8(sp)
  46:	6105                	addi	sp,sp,32
  48:	8082                	ret
  4a:	e04a                	sd	s2,0(sp)
  memmove(buf, p, strlen(p));
  4c:	8526                	mv	a0,s1
  4e:	26c000ef          	jal	2ba <strlen>
  52:	862a                	mv	a2,a0
  54:	85a6                	mv	a1,s1
  56:	00001517          	auipc	a0,0x1
  5a:	fba50513          	addi	a0,a0,-70 # 1010 <buf.0>
  5e:	3d4000ef          	jal	432 <memmove>
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  62:	8526                	mv	a0,s1
  64:	256000ef          	jal	2ba <strlen>
  68:	892a                	mv	s2,a0
  6a:	8526                	mv	a0,s1
  6c:	24e000ef          	jal	2ba <strlen>
  70:	02091793          	slli	a5,s2,0x20
  74:	9381                	srli	a5,a5,0x20
  76:	4639                	li	a2,14
  78:	9e09                	subw	a2,a2,a0
  7a:	02000593          	li	a1,32
  7e:	00001517          	auipc	a0,0x1
  82:	f9250513          	addi	a0,a0,-110 # 1010 <buf.0>
  86:	953e                	add	a0,a0,a5
  88:	25e000ef          	jal	2e6 <memset>
  return buf;
  8c:	00001497          	auipc	s1,0x1
  90:	f8448493          	addi	s1,s1,-124 # 1010 <buf.0>
  94:	6902                	ld	s2,0(sp)
  96:	b765                	j	3e <fmtname+0x3e>

0000000000000098 <ls>:

void
ls(char *path)
{
  98:	da010113          	addi	sp,sp,-608
  9c:	24113c23          	sd	ra,600(sp)
  a0:	24813823          	sd	s0,592(sp)
  a4:	25213023          	sd	s2,576(sp)
  a8:	1480                	addi	s0,sp,608
  aa:	892a                	mv	s2,a0
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;

  if((fd = open(path, O_RDONLY)) < 0){
  ac:	4581                	li	a1,0
  ae:	490000ef          	jal	53e <open>
  b2:	06054363          	bltz	a0,118 <ls+0x80>
  b6:	24913423          	sd	s1,584(sp)
  ba:	84aa                	mv	s1,a0
    fprintf(2, "ls: cannot open %s\n", path);
    return;
  }

  if(fstat(fd, &st) < 0){
  bc:	da840593          	addi	a1,s0,-600
  c0:	496000ef          	jal	556 <fstat>
  c4:	06054363          	bltz	a0,12a <ls+0x92>
    fprintf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }

  switch(st.type){
  c8:	db041783          	lh	a5,-592(s0)
  cc:	4705                	li	a4,1
  ce:	06e78c63          	beq	a5,a4,146 <ls+0xae>
  d2:	37f9                	addiw	a5,a5,-2
  d4:	17c2                	slli	a5,a5,0x30
  d6:	93c1                	srli	a5,a5,0x30
  d8:	02f76263          	bltu	a4,a5,fc <ls+0x64>
  case T_DEVICE:
  case T_FILE:
    printf("%s %d %d %d\n", fmtname(path), st.type, st.ino, (int) st.size);
  dc:	854a                	mv	a0,s2
  de:	f23ff0ef          	jal	0 <fmtname>
  e2:	85aa                	mv	a1,a0
  e4:	db842703          	lw	a4,-584(s0)
  e8:	dac42683          	lw	a3,-596(s0)
  ec:	db041603          	lh	a2,-592(s0)
  f0:	00001517          	auipc	a0,0x1
  f4:	a5050513          	addi	a0,a0,-1456 # b40 <malloc+0x124>
  f8:	06d000ef          	jal	964 <printf>
      }
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
    }
    break;
  }
  close(fd);
  fc:	8526                	mv	a0,s1
  fe:	428000ef          	jal	526 <close>
 102:	24813483          	ld	s1,584(sp)
}
 106:	25813083          	ld	ra,600(sp)
 10a:	25013403          	ld	s0,592(sp)
 10e:	24013903          	ld	s2,576(sp)
 112:	26010113          	addi	sp,sp,608
 116:	8082                	ret
    fprintf(2, "ls: cannot open %s\n", path);
 118:	864a                	mv	a2,s2
 11a:	00001597          	auipc	a1,0x1
 11e:	9f658593          	addi	a1,a1,-1546 # b10 <malloc+0xf4>
 122:	4509                	li	a0,2
 124:	017000ef          	jal	93a <fprintf>
    return;
 128:	bff9                	j	106 <ls+0x6e>
    fprintf(2, "ls: cannot stat %s\n", path);
 12a:	864a                	mv	a2,s2
 12c:	00001597          	auipc	a1,0x1
 130:	9fc58593          	addi	a1,a1,-1540 # b28 <malloc+0x10c>
 134:	4509                	li	a0,2
 136:	005000ef          	jal	93a <fprintf>
    close(fd);
 13a:	8526                	mv	a0,s1
 13c:	3ea000ef          	jal	526 <close>
    return;
 140:	24813483          	ld	s1,584(sp)
 144:	b7c9                	j	106 <ls+0x6e>
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 146:	854a                	mv	a0,s2
 148:	172000ef          	jal	2ba <strlen>
 14c:	2541                	addiw	a0,a0,16
 14e:	20000793          	li	a5,512
 152:	00a7f963          	bgeu	a5,a0,164 <ls+0xcc>
      printf("ls: path too long\n");
 156:	00001517          	auipc	a0,0x1
 15a:	9fa50513          	addi	a0,a0,-1542 # b50 <malloc+0x134>
 15e:	007000ef          	jal	964 <printf>
      break;
 162:	bf69                	j	fc <ls+0x64>
 164:	23313c23          	sd	s3,568(sp)
    strcpy(buf, path);
 168:	85ca                	mv	a1,s2
 16a:	dd040513          	addi	a0,s0,-560
 16e:	0fc000ef          	jal	26a <strcpy>
    p = buf+strlen(buf);
 172:	dd040513          	addi	a0,s0,-560
 176:	144000ef          	jal	2ba <strlen>
 17a:	1502                	slli	a0,a0,0x20
 17c:	9101                	srli	a0,a0,0x20
 17e:	dd040793          	addi	a5,s0,-560
 182:	00a78733          	add	a4,a5,a0
 186:	893a                	mv	s2,a4
    *p++ = '/';
 188:	00170793          	addi	a5,a4,1
 18c:	89be                	mv	s3,a5
 18e:	02f00793          	li	a5,47
 192:	00f70023          	sb	a5,0(a4)
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 196:	a809                	j	1a8 <ls+0x110>
        printf("ls: cannot stat %s\n", buf);
 198:	dd040593          	addi	a1,s0,-560
 19c:	00001517          	auipc	a0,0x1
 1a0:	98c50513          	addi	a0,a0,-1652 # b28 <malloc+0x10c>
 1a4:	7c0000ef          	jal	964 <printf>
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 1a8:	4641                	li	a2,16
 1aa:	dc040593          	addi	a1,s0,-576
 1ae:	8526                	mv	a0,s1
 1b0:	366000ef          	jal	516 <read>
 1b4:	47c1                	li	a5,16
 1b6:	04f51763          	bne	a0,a5,204 <ls+0x16c>
      if(de.inum == 0)
 1ba:	dc045783          	lhu	a5,-576(s0)
 1be:	d7ed                	beqz	a5,1a8 <ls+0x110>
      memmove(p, de.name, DIRSIZ);
 1c0:	4639                	li	a2,14
 1c2:	dc240593          	addi	a1,s0,-574
 1c6:	854e                	mv	a0,s3
 1c8:	26a000ef          	jal	432 <memmove>
      p[DIRSIZ] = 0;
 1cc:	000907a3          	sb	zero,15(s2)
      if(stat(buf, &st) < 0){
 1d0:	da840593          	addi	a1,s0,-600
 1d4:	dd040513          	addi	a0,s0,-560
 1d8:	1d2000ef          	jal	3aa <stat>
 1dc:	fa054ee3          	bltz	a0,198 <ls+0x100>
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
 1e0:	dd040513          	addi	a0,s0,-560
 1e4:	e1dff0ef          	jal	0 <fmtname>
 1e8:	85aa                	mv	a1,a0
 1ea:	db842703          	lw	a4,-584(s0)
 1ee:	dac42683          	lw	a3,-596(s0)
 1f2:	db041603          	lh	a2,-592(s0)
 1f6:	00001517          	auipc	a0,0x1
 1fa:	94a50513          	addi	a0,a0,-1718 # b40 <malloc+0x124>
 1fe:	766000ef          	jal	964 <printf>
 202:	b75d                	j	1a8 <ls+0x110>
 204:	23813983          	ld	s3,568(sp)
 208:	bdd5                	j	fc <ls+0x64>

000000000000020a <main>:

int
main(int argc, char *argv[])
{
 20a:	1101                	addi	sp,sp,-32
 20c:	ec06                	sd	ra,24(sp)
 20e:	e822                	sd	s0,16(sp)
 210:	1000                	addi	s0,sp,32
  int i;

  if(argc < 2){
 212:	4785                	li	a5,1
 214:	02a7d763          	bge	a5,a0,242 <main+0x38>
 218:	e426                	sd	s1,8(sp)
 21a:	e04a                	sd	s2,0(sp)
 21c:	00858493          	addi	s1,a1,8
 220:	ffe5091b          	addiw	s2,a0,-2
 224:	02091793          	slli	a5,s2,0x20
 228:	01d7d913          	srli	s2,a5,0x1d
 22c:	05c1                	addi	a1,a1,16
 22e:	992e                	add	s2,s2,a1
    ls(".");
    exit(0);
  }
  for(i=1; i<argc; i++)
    ls(argv[i]);
 230:	6088                	ld	a0,0(s1)
 232:	e67ff0ef          	jal	98 <ls>
  for(i=1; i<argc; i++)
 236:	04a1                	addi	s1,s1,8
 238:	ff249ce3          	bne	s1,s2,230 <main+0x26>
  exit(0);
 23c:	4501                	li	a0,0
 23e:	2c0000ef          	jal	4fe <exit>
 242:	e426                	sd	s1,8(sp)
 244:	e04a                	sd	s2,0(sp)
    ls(".");
 246:	00001517          	auipc	a0,0x1
 24a:	92250513          	addi	a0,a0,-1758 # b68 <malloc+0x14c>
 24e:	e4bff0ef          	jal	98 <ls>
    exit(0);
 252:	4501                	li	a0,0
 254:	2aa000ef          	jal	4fe <exit>

0000000000000258 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 258:	1141                	addi	sp,sp,-16
 25a:	e406                	sd	ra,8(sp)
 25c:	e022                	sd	s0,0(sp)
 25e:	0800                	addi	s0,sp,16
  extern int main();
  main();
 260:	fabff0ef          	jal	20a <main>
  exit(0);
 264:	4501                	li	a0,0
 266:	298000ef          	jal	4fe <exit>

000000000000026a <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 26a:	1141                	addi	sp,sp,-16
 26c:	e406                	sd	ra,8(sp)
 26e:	e022                	sd	s0,0(sp)
 270:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 272:	87aa                	mv	a5,a0
 274:	0585                	addi	a1,a1,1
 276:	0785                	addi	a5,a5,1
 278:	fff5c703          	lbu	a4,-1(a1)
 27c:	fee78fa3          	sb	a4,-1(a5)
 280:	fb75                	bnez	a4,274 <strcpy+0xa>
    ;
  return os;
}
 282:	60a2                	ld	ra,8(sp)
 284:	6402                	ld	s0,0(sp)
 286:	0141                	addi	sp,sp,16
 288:	8082                	ret

000000000000028a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 28a:	1141                	addi	sp,sp,-16
 28c:	e406                	sd	ra,8(sp)
 28e:	e022                	sd	s0,0(sp)
 290:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 292:	00054783          	lbu	a5,0(a0)
 296:	cb91                	beqz	a5,2aa <strcmp+0x20>
 298:	0005c703          	lbu	a4,0(a1)
 29c:	00f71763          	bne	a4,a5,2aa <strcmp+0x20>
    p++, q++;
 2a0:	0505                	addi	a0,a0,1
 2a2:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2a4:	00054783          	lbu	a5,0(a0)
 2a8:	fbe5                	bnez	a5,298 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 2aa:	0005c503          	lbu	a0,0(a1)
}
 2ae:	40a7853b          	subw	a0,a5,a0
 2b2:	60a2                	ld	ra,8(sp)
 2b4:	6402                	ld	s0,0(sp)
 2b6:	0141                	addi	sp,sp,16
 2b8:	8082                	ret

00000000000002ba <strlen>:

uint
strlen(const char *s)
{
 2ba:	1141                	addi	sp,sp,-16
 2bc:	e406                	sd	ra,8(sp)
 2be:	e022                	sd	s0,0(sp)
 2c0:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2c2:	00054783          	lbu	a5,0(a0)
 2c6:	cf91                	beqz	a5,2e2 <strlen+0x28>
 2c8:	00150793          	addi	a5,a0,1
 2cc:	86be                	mv	a3,a5
 2ce:	0785                	addi	a5,a5,1
 2d0:	fff7c703          	lbu	a4,-1(a5)
 2d4:	ff65                	bnez	a4,2cc <strlen+0x12>
 2d6:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 2da:	60a2                	ld	ra,8(sp)
 2dc:	6402                	ld	s0,0(sp)
 2de:	0141                	addi	sp,sp,16
 2e0:	8082                	ret
  for(n = 0; s[n]; n++)
 2e2:	4501                	li	a0,0
 2e4:	bfdd                	j	2da <strlen+0x20>

00000000000002e6 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2e6:	1141                	addi	sp,sp,-16
 2e8:	e406                	sd	ra,8(sp)
 2ea:	e022                	sd	s0,0(sp)
 2ec:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2ee:	ca19                	beqz	a2,304 <memset+0x1e>
 2f0:	87aa                	mv	a5,a0
 2f2:	1602                	slli	a2,a2,0x20
 2f4:	9201                	srli	a2,a2,0x20
 2f6:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2fa:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2fe:	0785                	addi	a5,a5,1
 300:	fee79de3          	bne	a5,a4,2fa <memset+0x14>
  }
  return dst;
}
 304:	60a2                	ld	ra,8(sp)
 306:	6402                	ld	s0,0(sp)
 308:	0141                	addi	sp,sp,16
 30a:	8082                	ret

000000000000030c <strchr>:

char*
strchr(const char *s, char c)
{
 30c:	1141                	addi	sp,sp,-16
 30e:	e406                	sd	ra,8(sp)
 310:	e022                	sd	s0,0(sp)
 312:	0800                	addi	s0,sp,16
  for(; *s; s++)
 314:	00054783          	lbu	a5,0(a0)
 318:	cf81                	beqz	a5,330 <strchr+0x24>
    if(*s == c)
 31a:	00f58763          	beq	a1,a5,328 <strchr+0x1c>
  for(; *s; s++)
 31e:	0505                	addi	a0,a0,1
 320:	00054783          	lbu	a5,0(a0)
 324:	fbfd                	bnez	a5,31a <strchr+0xe>
      return (char*)s;
  return 0;
 326:	4501                	li	a0,0
}
 328:	60a2                	ld	ra,8(sp)
 32a:	6402                	ld	s0,0(sp)
 32c:	0141                	addi	sp,sp,16
 32e:	8082                	ret
  return 0;
 330:	4501                	li	a0,0
 332:	bfdd                	j	328 <strchr+0x1c>

0000000000000334 <gets>:

char*
gets(char *buf, int max)
{
 334:	711d                	addi	sp,sp,-96
 336:	ec86                	sd	ra,88(sp)
 338:	e8a2                	sd	s0,80(sp)
 33a:	e4a6                	sd	s1,72(sp)
 33c:	e0ca                	sd	s2,64(sp)
 33e:	fc4e                	sd	s3,56(sp)
 340:	f852                	sd	s4,48(sp)
 342:	f456                	sd	s5,40(sp)
 344:	f05a                	sd	s6,32(sp)
 346:	ec5e                	sd	s7,24(sp)
 348:	e862                	sd	s8,16(sp)
 34a:	1080                	addi	s0,sp,96
 34c:	8baa                	mv	s7,a0
 34e:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 350:	892a                	mv	s2,a0
 352:	4481                	li	s1,0
    cc = read(0, &c, 1);
 354:	faf40b13          	addi	s6,s0,-81
 358:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 35a:	8c26                	mv	s8,s1
 35c:	0014899b          	addiw	s3,s1,1
 360:	84ce                	mv	s1,s3
 362:	0349d463          	bge	s3,s4,38a <gets+0x56>
    cc = read(0, &c, 1);
 366:	8656                	mv	a2,s5
 368:	85da                	mv	a1,s6
 36a:	4501                	li	a0,0
 36c:	1aa000ef          	jal	516 <read>
    if(cc < 1)
 370:	00a05d63          	blez	a0,38a <gets+0x56>
      break;
    buf[i++] = c;
 374:	faf44783          	lbu	a5,-81(s0)
 378:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 37c:	0905                	addi	s2,s2,1
 37e:	ff678713          	addi	a4,a5,-10
 382:	c319                	beqz	a4,388 <gets+0x54>
 384:	17cd                	addi	a5,a5,-13
 386:	fbf1                	bnez	a5,35a <gets+0x26>
    buf[i++] = c;
 388:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 38a:	9c5e                	add	s8,s8,s7
 38c:	000c0023          	sb	zero,0(s8)
  return buf;
}
 390:	855e                	mv	a0,s7
 392:	60e6                	ld	ra,88(sp)
 394:	6446                	ld	s0,80(sp)
 396:	64a6                	ld	s1,72(sp)
 398:	6906                	ld	s2,64(sp)
 39a:	79e2                	ld	s3,56(sp)
 39c:	7a42                	ld	s4,48(sp)
 39e:	7aa2                	ld	s5,40(sp)
 3a0:	7b02                	ld	s6,32(sp)
 3a2:	6be2                	ld	s7,24(sp)
 3a4:	6c42                	ld	s8,16(sp)
 3a6:	6125                	addi	sp,sp,96
 3a8:	8082                	ret

00000000000003aa <stat>:

int
stat(const char *n, struct stat *st)
{
 3aa:	1101                	addi	sp,sp,-32
 3ac:	ec06                	sd	ra,24(sp)
 3ae:	e822                	sd	s0,16(sp)
 3b0:	e04a                	sd	s2,0(sp)
 3b2:	1000                	addi	s0,sp,32
 3b4:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3b6:	4581                	li	a1,0
 3b8:	186000ef          	jal	53e <open>
  if(fd < 0)
 3bc:	02054263          	bltz	a0,3e0 <stat+0x36>
 3c0:	e426                	sd	s1,8(sp)
 3c2:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3c4:	85ca                	mv	a1,s2
 3c6:	190000ef          	jal	556 <fstat>
 3ca:	892a                	mv	s2,a0
  close(fd);
 3cc:	8526                	mv	a0,s1
 3ce:	158000ef          	jal	526 <close>
  return r;
 3d2:	64a2                	ld	s1,8(sp)
}
 3d4:	854a                	mv	a0,s2
 3d6:	60e2                	ld	ra,24(sp)
 3d8:	6442                	ld	s0,16(sp)
 3da:	6902                	ld	s2,0(sp)
 3dc:	6105                	addi	sp,sp,32
 3de:	8082                	ret
    return -1;
 3e0:	57fd                	li	a5,-1
 3e2:	893e                	mv	s2,a5
 3e4:	bfc5                	j	3d4 <stat+0x2a>

00000000000003e6 <atoi>:

int
atoi(const char *s)
{
 3e6:	1141                	addi	sp,sp,-16
 3e8:	e406                	sd	ra,8(sp)
 3ea:	e022                	sd	s0,0(sp)
 3ec:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3ee:	00054683          	lbu	a3,0(a0)
 3f2:	fd06879b          	addiw	a5,a3,-48
 3f6:	0ff7f793          	zext.b	a5,a5
 3fa:	4625                	li	a2,9
 3fc:	02f66963          	bltu	a2,a5,42e <atoi+0x48>
 400:	872a                	mv	a4,a0
  n = 0;
 402:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 404:	0705                	addi	a4,a4,1
 406:	0025179b          	slliw	a5,a0,0x2
 40a:	9fa9                	addw	a5,a5,a0
 40c:	0017979b          	slliw	a5,a5,0x1
 410:	9fb5                	addw	a5,a5,a3
 412:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 416:	00074683          	lbu	a3,0(a4)
 41a:	fd06879b          	addiw	a5,a3,-48
 41e:	0ff7f793          	zext.b	a5,a5
 422:	fef671e3          	bgeu	a2,a5,404 <atoi+0x1e>
  return n;
}
 426:	60a2                	ld	ra,8(sp)
 428:	6402                	ld	s0,0(sp)
 42a:	0141                	addi	sp,sp,16
 42c:	8082                	ret
  n = 0;
 42e:	4501                	li	a0,0
 430:	bfdd                	j	426 <atoi+0x40>

0000000000000432 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 432:	1141                	addi	sp,sp,-16
 434:	e406                	sd	ra,8(sp)
 436:	e022                	sd	s0,0(sp)
 438:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 43a:	02b57563          	bgeu	a0,a1,464 <memmove+0x32>
    while(n-- > 0)
 43e:	00c05f63          	blez	a2,45c <memmove+0x2a>
 442:	1602                	slli	a2,a2,0x20
 444:	9201                	srli	a2,a2,0x20
 446:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 44a:	872a                	mv	a4,a0
      *dst++ = *src++;
 44c:	0585                	addi	a1,a1,1
 44e:	0705                	addi	a4,a4,1
 450:	fff5c683          	lbu	a3,-1(a1)
 454:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 458:	fee79ae3          	bne	a5,a4,44c <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 45c:	60a2                	ld	ra,8(sp)
 45e:	6402                	ld	s0,0(sp)
 460:	0141                	addi	sp,sp,16
 462:	8082                	ret
    while(n-- > 0)
 464:	fec05ce3          	blez	a2,45c <memmove+0x2a>
    dst += n;
 468:	00c50733          	add	a4,a0,a2
    src += n;
 46c:	95b2                	add	a1,a1,a2
 46e:	fff6079b          	addiw	a5,a2,-1
 472:	1782                	slli	a5,a5,0x20
 474:	9381                	srli	a5,a5,0x20
 476:	fff7c793          	not	a5,a5
 47a:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 47c:	15fd                	addi	a1,a1,-1
 47e:	177d                	addi	a4,a4,-1
 480:	0005c683          	lbu	a3,0(a1)
 484:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 488:	fef71ae3          	bne	a4,a5,47c <memmove+0x4a>
 48c:	bfc1                	j	45c <memmove+0x2a>

000000000000048e <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 48e:	1141                	addi	sp,sp,-16
 490:	e406                	sd	ra,8(sp)
 492:	e022                	sd	s0,0(sp)
 494:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 496:	c61d                	beqz	a2,4c4 <memcmp+0x36>
 498:	1602                	slli	a2,a2,0x20
 49a:	9201                	srli	a2,a2,0x20
 49c:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 4a0:	00054783          	lbu	a5,0(a0)
 4a4:	0005c703          	lbu	a4,0(a1)
 4a8:	00e79863          	bne	a5,a4,4b8 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 4ac:	0505                	addi	a0,a0,1
    p2++;
 4ae:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4b0:	fed518e3          	bne	a0,a3,4a0 <memcmp+0x12>
  }
  return 0;
 4b4:	4501                	li	a0,0
 4b6:	a019                	j	4bc <memcmp+0x2e>
      return *p1 - *p2;
 4b8:	40e7853b          	subw	a0,a5,a4
}
 4bc:	60a2                	ld	ra,8(sp)
 4be:	6402                	ld	s0,0(sp)
 4c0:	0141                	addi	sp,sp,16
 4c2:	8082                	ret
  return 0;
 4c4:	4501                	li	a0,0
 4c6:	bfdd                	j	4bc <memcmp+0x2e>

00000000000004c8 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4c8:	1141                	addi	sp,sp,-16
 4ca:	e406                	sd	ra,8(sp)
 4cc:	e022                	sd	s0,0(sp)
 4ce:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4d0:	f63ff0ef          	jal	432 <memmove>
}
 4d4:	60a2                	ld	ra,8(sp)
 4d6:	6402                	ld	s0,0(sp)
 4d8:	0141                	addi	sp,sp,16
 4da:	8082                	ret

00000000000004dc <ugetpid>:

#ifdef LAB_PGTBL
int
ugetpid(void)
{
 4dc:	1141                	addi	sp,sp,-16
 4de:	e406                	sd	ra,8(sp)
 4e0:	e022                	sd	s0,0(sp)
 4e2:	0800                	addi	s0,sp,16
  struct usyscall *u = (struct usyscall *)USYSCALL;
  return u->pid;
 4e4:	040007b7          	lui	a5,0x4000
 4e8:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3ffefdd>
 4ea:	07b2                	slli	a5,a5,0xc
}
 4ec:	4388                	lw	a0,0(a5)
 4ee:	60a2                	ld	ra,8(sp)
 4f0:	6402                	ld	s0,0(sp)
 4f2:	0141                	addi	sp,sp,16
 4f4:	8082                	ret

00000000000004f6 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4f6:	4885                	li	a7,1
 ecall
 4f8:	00000073          	ecall
 ret
 4fc:	8082                	ret

00000000000004fe <exit>:
.global exit
exit:
 li a7, SYS_exit
 4fe:	4889                	li	a7,2
 ecall
 500:	00000073          	ecall
 ret
 504:	8082                	ret

0000000000000506 <wait>:
.global wait
wait:
 li a7, SYS_wait
 506:	488d                	li	a7,3
 ecall
 508:	00000073          	ecall
 ret
 50c:	8082                	ret

000000000000050e <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 50e:	4891                	li	a7,4
 ecall
 510:	00000073          	ecall
 ret
 514:	8082                	ret

0000000000000516 <read>:
.global read
read:
 li a7, SYS_read
 516:	4895                	li	a7,5
 ecall
 518:	00000073          	ecall
 ret
 51c:	8082                	ret

000000000000051e <write>:
.global write
write:
 li a7, SYS_write
 51e:	48c1                	li	a7,16
 ecall
 520:	00000073          	ecall
 ret
 524:	8082                	ret

0000000000000526 <close>:
.global close
close:
 li a7, SYS_close
 526:	48d5                	li	a7,21
 ecall
 528:	00000073          	ecall
 ret
 52c:	8082                	ret

000000000000052e <kill>:
.global kill
kill:
 li a7, SYS_kill
 52e:	4899                	li	a7,6
 ecall
 530:	00000073          	ecall
 ret
 534:	8082                	ret

0000000000000536 <exec>:
.global exec
exec:
 li a7, SYS_exec
 536:	489d                	li	a7,7
 ecall
 538:	00000073          	ecall
 ret
 53c:	8082                	ret

000000000000053e <open>:
.global open
open:
 li a7, SYS_open
 53e:	48bd                	li	a7,15
 ecall
 540:	00000073          	ecall
 ret
 544:	8082                	ret

0000000000000546 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 546:	48c5                	li	a7,17
 ecall
 548:	00000073          	ecall
 ret
 54c:	8082                	ret

000000000000054e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 54e:	48c9                	li	a7,18
 ecall
 550:	00000073          	ecall
 ret
 554:	8082                	ret

0000000000000556 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 556:	48a1                	li	a7,8
 ecall
 558:	00000073          	ecall
 ret
 55c:	8082                	ret

000000000000055e <link>:
.global link
link:
 li a7, SYS_link
 55e:	48cd                	li	a7,19
 ecall
 560:	00000073          	ecall
 ret
 564:	8082                	ret

0000000000000566 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 566:	48d1                	li	a7,20
 ecall
 568:	00000073          	ecall
 ret
 56c:	8082                	ret

000000000000056e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 56e:	48a5                	li	a7,9
 ecall
 570:	00000073          	ecall
 ret
 574:	8082                	ret

0000000000000576 <dup>:
.global dup
dup:
 li a7, SYS_dup
 576:	48a9                	li	a7,10
 ecall
 578:	00000073          	ecall
 ret
 57c:	8082                	ret

000000000000057e <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 57e:	48ad                	li	a7,11
 ecall
 580:	00000073          	ecall
 ret
 584:	8082                	ret

0000000000000586 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 586:	48b1                	li	a7,12
 ecall
 588:	00000073          	ecall
 ret
 58c:	8082                	ret

000000000000058e <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 58e:	48b5                	li	a7,13
 ecall
 590:	00000073          	ecall
 ret
 594:	8082                	ret

0000000000000596 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 596:	48b9                	li	a7,14
 ecall
 598:	00000073          	ecall
 ret
 59c:	8082                	ret

000000000000059e <bind>:
.global bind
bind:
 li a7, SYS_bind
 59e:	48f5                	li	a7,29
 ecall
 5a0:	00000073          	ecall
 ret
 5a4:	8082                	ret

00000000000005a6 <unbind>:
.global unbind
unbind:
 li a7, SYS_unbind
 5a6:	48f9                	li	a7,30
 ecall
 5a8:	00000073          	ecall
 ret
 5ac:	8082                	ret

00000000000005ae <send>:
.global send
send:
 li a7, SYS_send
 5ae:	48fd                	li	a7,31
 ecall
 5b0:	00000073          	ecall
 ret
 5b4:	8082                	ret

00000000000005b6 <recv>:
.global recv
recv:
 li a7, SYS_recv
 5b6:	02000893          	li	a7,32
 ecall
 5ba:	00000073          	ecall
 ret
 5be:	8082                	ret

00000000000005c0 <pgpte>:
.global pgpte
pgpte:
 li a7, SYS_pgpte
 5c0:	02100893          	li	a7,33
 ecall
 5c4:	00000073          	ecall
 ret
 5c8:	8082                	ret

00000000000005ca <kpgtbl>:
.global kpgtbl
kpgtbl:
 li a7, SYS_kpgtbl
 5ca:	02200893          	li	a7,34
 ecall
 5ce:	00000073          	ecall
 ret
 5d2:	8082                	ret

00000000000005d4 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 5d4:	1101                	addi	sp,sp,-32
 5d6:	ec06                	sd	ra,24(sp)
 5d8:	e822                	sd	s0,16(sp)
 5da:	1000                	addi	s0,sp,32
 5dc:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 5e0:	4605                	li	a2,1
 5e2:	fef40593          	addi	a1,s0,-17
 5e6:	f39ff0ef          	jal	51e <write>
}
 5ea:	60e2                	ld	ra,24(sp)
 5ec:	6442                	ld	s0,16(sp)
 5ee:	6105                	addi	sp,sp,32
 5f0:	8082                	ret

00000000000005f2 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 5f2:	7139                	addi	sp,sp,-64
 5f4:	fc06                	sd	ra,56(sp)
 5f6:	f822                	sd	s0,48(sp)
 5f8:	f04a                	sd	s2,32(sp)
 5fa:	ec4e                	sd	s3,24(sp)
 5fc:	0080                	addi	s0,sp,64
 5fe:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 600:	cac9                	beqz	a3,692 <printint+0xa0>
 602:	01f5d79b          	srliw	a5,a1,0x1f
 606:	c7d1                	beqz	a5,692 <printint+0xa0>
    neg = 1;
    x = -xx;
 608:	40b005bb          	negw	a1,a1
    neg = 1;
 60c:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 60e:	fc040993          	addi	s3,s0,-64
  neg = 0;
 612:	86ce                	mv	a3,s3
  i = 0;
 614:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 616:	00000817          	auipc	a6,0x0
 61a:	56280813          	addi	a6,a6,1378 # b78 <digits>
 61e:	88ba                	mv	a7,a4
 620:	0017051b          	addiw	a0,a4,1
 624:	872a                	mv	a4,a0
 626:	02c5f7bb          	remuw	a5,a1,a2
 62a:	1782                	slli	a5,a5,0x20
 62c:	9381                	srli	a5,a5,0x20
 62e:	97c2                	add	a5,a5,a6
 630:	0007c783          	lbu	a5,0(a5)
 634:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 638:	87ae                	mv	a5,a1
 63a:	02c5d5bb          	divuw	a1,a1,a2
 63e:	0685                	addi	a3,a3,1
 640:	fcc7ffe3          	bgeu	a5,a2,61e <printint+0x2c>
  if(neg)
 644:	00030c63          	beqz	t1,65c <printint+0x6a>
    buf[i++] = '-';
 648:	fd050793          	addi	a5,a0,-48
 64c:	00878533          	add	a0,a5,s0
 650:	02d00793          	li	a5,45
 654:	fef50823          	sb	a5,-16(a0)
 658:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 65c:	02e05563          	blez	a4,686 <printint+0x94>
 660:	f426                	sd	s1,40(sp)
 662:	377d                	addiw	a4,a4,-1
 664:	00e984b3          	add	s1,s3,a4
 668:	19fd                	addi	s3,s3,-1
 66a:	99ba                	add	s3,s3,a4
 66c:	1702                	slli	a4,a4,0x20
 66e:	9301                	srli	a4,a4,0x20
 670:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 674:	0004c583          	lbu	a1,0(s1)
 678:	854a                	mv	a0,s2
 67a:	f5bff0ef          	jal	5d4 <putc>
  while(--i >= 0)
 67e:	14fd                	addi	s1,s1,-1
 680:	ff349ae3          	bne	s1,s3,674 <printint+0x82>
 684:	74a2                	ld	s1,40(sp)
}
 686:	70e2                	ld	ra,56(sp)
 688:	7442                	ld	s0,48(sp)
 68a:	7902                	ld	s2,32(sp)
 68c:	69e2                	ld	s3,24(sp)
 68e:	6121                	addi	sp,sp,64
 690:	8082                	ret
  neg = 0;
 692:	4301                	li	t1,0
 694:	bfad                	j	60e <printint+0x1c>

0000000000000696 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 696:	711d                	addi	sp,sp,-96
 698:	ec86                	sd	ra,88(sp)
 69a:	e8a2                	sd	s0,80(sp)
 69c:	e4a6                	sd	s1,72(sp)
 69e:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 6a0:	0005c483          	lbu	s1,0(a1)
 6a4:	20048963          	beqz	s1,8b6 <vprintf+0x220>
 6a8:	e0ca                	sd	s2,64(sp)
 6aa:	fc4e                	sd	s3,56(sp)
 6ac:	f852                	sd	s4,48(sp)
 6ae:	f456                	sd	s5,40(sp)
 6b0:	f05a                	sd	s6,32(sp)
 6b2:	ec5e                	sd	s7,24(sp)
 6b4:	e862                	sd	s8,16(sp)
 6b6:	8b2a                	mv	s6,a0
 6b8:	8a2e                	mv	s4,a1
 6ba:	8bb2                	mv	s7,a2
  state = 0;
 6bc:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 6be:	4901                	li	s2,0
 6c0:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 6c2:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 6c6:	06400c13          	li	s8,100
 6ca:	a00d                	j	6ec <vprintf+0x56>
        putc(fd, c0);
 6cc:	85a6                	mv	a1,s1
 6ce:	855a                	mv	a0,s6
 6d0:	f05ff0ef          	jal	5d4 <putc>
 6d4:	a019                	j	6da <vprintf+0x44>
    } else if(state == '%'){
 6d6:	03598363          	beq	s3,s5,6fc <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 6da:	0019079b          	addiw	a5,s2,1
 6de:	893e                	mv	s2,a5
 6e0:	873e                	mv	a4,a5
 6e2:	97d2                	add	a5,a5,s4
 6e4:	0007c483          	lbu	s1,0(a5)
 6e8:	1c048063          	beqz	s1,8a8 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 6ec:	0004879b          	sext.w	a5,s1
    if(state == 0){
 6f0:	fe0993e3          	bnez	s3,6d6 <vprintf+0x40>
      if(c0 == '%'){
 6f4:	fd579ce3          	bne	a5,s5,6cc <vprintf+0x36>
        state = '%';
 6f8:	89be                	mv	s3,a5
 6fa:	b7c5                	j	6da <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 6fc:	00ea06b3          	add	a3,s4,a4
 700:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 704:	1a060e63          	beqz	a2,8c0 <vprintf+0x22a>
      if(c0 == 'd'){
 708:	03878763          	beq	a5,s8,736 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 70c:	f9478693          	addi	a3,a5,-108
 710:	0016b693          	seqz	a3,a3
 714:	f9c60593          	addi	a1,a2,-100
 718:	e99d                	bnez	a1,74e <vprintf+0xb8>
 71a:	ca95                	beqz	a3,74e <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 71c:	008b8493          	addi	s1,s7,8
 720:	4685                	li	a3,1
 722:	4629                	li	a2,10
 724:	000ba583          	lw	a1,0(s7)
 728:	855a                	mv	a0,s6
 72a:	ec9ff0ef          	jal	5f2 <printint>
        i += 1;
 72e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 730:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 732:	4981                	li	s3,0
 734:	b75d                	j	6da <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 736:	008b8493          	addi	s1,s7,8
 73a:	4685                	li	a3,1
 73c:	4629                	li	a2,10
 73e:	000ba583          	lw	a1,0(s7)
 742:	855a                	mv	a0,s6
 744:	eafff0ef          	jal	5f2 <printint>
 748:	8ba6                	mv	s7,s1
      state = 0;
 74a:	4981                	li	s3,0
 74c:	b779                	j	6da <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 74e:	9752                	add	a4,a4,s4
 750:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 754:	f9460713          	addi	a4,a2,-108
 758:	00173713          	seqz	a4,a4
 75c:	8f75                	and	a4,a4,a3
 75e:	f9c58513          	addi	a0,a1,-100
 762:	16051963          	bnez	a0,8d4 <vprintf+0x23e>
 766:	16070763          	beqz	a4,8d4 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 76a:	008b8493          	addi	s1,s7,8
 76e:	4685                	li	a3,1
 770:	4629                	li	a2,10
 772:	000ba583          	lw	a1,0(s7)
 776:	855a                	mv	a0,s6
 778:	e7bff0ef          	jal	5f2 <printint>
        i += 2;
 77c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 77e:	8ba6                	mv	s7,s1
      state = 0;
 780:	4981                	li	s3,0
        i += 2;
 782:	bfa1                	j	6da <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 784:	008b8493          	addi	s1,s7,8
 788:	4681                	li	a3,0
 78a:	4629                	li	a2,10
 78c:	000ba583          	lw	a1,0(s7)
 790:	855a                	mv	a0,s6
 792:	e61ff0ef          	jal	5f2 <printint>
 796:	8ba6                	mv	s7,s1
      state = 0;
 798:	4981                	li	s3,0
 79a:	b781                	j	6da <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 79c:	008b8493          	addi	s1,s7,8
 7a0:	4681                	li	a3,0
 7a2:	4629                	li	a2,10
 7a4:	000ba583          	lw	a1,0(s7)
 7a8:	855a                	mv	a0,s6
 7aa:	e49ff0ef          	jal	5f2 <printint>
        i += 1;
 7ae:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b0:	8ba6                	mv	s7,s1
      state = 0;
 7b2:	4981                	li	s3,0
 7b4:	b71d                	j	6da <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b6:	008b8493          	addi	s1,s7,8
 7ba:	4681                	li	a3,0
 7bc:	4629                	li	a2,10
 7be:	000ba583          	lw	a1,0(s7)
 7c2:	855a                	mv	a0,s6
 7c4:	e2fff0ef          	jal	5f2 <printint>
        i += 2;
 7c8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7ca:	8ba6                	mv	s7,s1
      state = 0;
 7cc:	4981                	li	s3,0
        i += 2;
 7ce:	b731                	j	6da <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 7d0:	008b8493          	addi	s1,s7,8
 7d4:	4681                	li	a3,0
 7d6:	4641                	li	a2,16
 7d8:	000ba583          	lw	a1,0(s7)
 7dc:	855a                	mv	a0,s6
 7de:	e15ff0ef          	jal	5f2 <printint>
 7e2:	8ba6                	mv	s7,s1
      state = 0;
 7e4:	4981                	li	s3,0
 7e6:	bdd5                	j	6da <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7e8:	008b8493          	addi	s1,s7,8
 7ec:	4681                	li	a3,0
 7ee:	4641                	li	a2,16
 7f0:	000ba583          	lw	a1,0(s7)
 7f4:	855a                	mv	a0,s6
 7f6:	dfdff0ef          	jal	5f2 <printint>
        i += 1;
 7fa:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 7fc:	8ba6                	mv	s7,s1
      state = 0;
 7fe:	4981                	li	s3,0
 800:	bde9                	j	6da <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 802:	008b8493          	addi	s1,s7,8
 806:	4681                	li	a3,0
 808:	4641                	li	a2,16
 80a:	000ba583          	lw	a1,0(s7)
 80e:	855a                	mv	a0,s6
 810:	de3ff0ef          	jal	5f2 <printint>
        i += 2;
 814:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 816:	8ba6                	mv	s7,s1
      state = 0;
 818:	4981                	li	s3,0
        i += 2;
 81a:	b5c1                	j	6da <vprintf+0x44>
 81c:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 81e:	008b8793          	addi	a5,s7,8
 822:	8cbe                	mv	s9,a5
 824:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 828:	03000593          	li	a1,48
 82c:	855a                	mv	a0,s6
 82e:	da7ff0ef          	jal	5d4 <putc>
  putc(fd, 'x');
 832:	07800593          	li	a1,120
 836:	855a                	mv	a0,s6
 838:	d9dff0ef          	jal	5d4 <putc>
 83c:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 83e:	00000b97          	auipc	s7,0x0
 842:	33ab8b93          	addi	s7,s7,826 # b78 <digits>
 846:	03c9d793          	srli	a5,s3,0x3c
 84a:	97de                	add	a5,a5,s7
 84c:	0007c583          	lbu	a1,0(a5)
 850:	855a                	mv	a0,s6
 852:	d83ff0ef          	jal	5d4 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 856:	0992                	slli	s3,s3,0x4
 858:	34fd                	addiw	s1,s1,-1
 85a:	f4f5                	bnez	s1,846 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 85c:	8be6                	mv	s7,s9
      state = 0;
 85e:	4981                	li	s3,0
 860:	6ca2                	ld	s9,8(sp)
 862:	bda5                	j	6da <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 864:	008b8993          	addi	s3,s7,8
 868:	000bb483          	ld	s1,0(s7)
 86c:	cc91                	beqz	s1,888 <vprintf+0x1f2>
        for(; *s; s++)
 86e:	0004c583          	lbu	a1,0(s1)
 872:	c985                	beqz	a1,8a2 <vprintf+0x20c>
          putc(fd, *s);
 874:	855a                	mv	a0,s6
 876:	d5fff0ef          	jal	5d4 <putc>
        for(; *s; s++)
 87a:	0485                	addi	s1,s1,1
 87c:	0004c583          	lbu	a1,0(s1)
 880:	f9f5                	bnez	a1,874 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 882:	8bce                	mv	s7,s3
      state = 0;
 884:	4981                	li	s3,0
 886:	bd91                	j	6da <vprintf+0x44>
          s = "(null)";
 888:	00000497          	auipc	s1,0x0
 88c:	2e848493          	addi	s1,s1,744 # b70 <malloc+0x154>
        for(; *s; s++)
 890:	02800593          	li	a1,40
 894:	b7c5                	j	874 <vprintf+0x1de>
        putc(fd, '%');
 896:	85be                	mv	a1,a5
 898:	855a                	mv	a0,s6
 89a:	d3bff0ef          	jal	5d4 <putc>
      state = 0;
 89e:	4981                	li	s3,0
 8a0:	bd2d                	j	6da <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 8a2:	8bce                	mv	s7,s3
      state = 0;
 8a4:	4981                	li	s3,0
 8a6:	bd15                	j	6da <vprintf+0x44>
 8a8:	6906                	ld	s2,64(sp)
 8aa:	79e2                	ld	s3,56(sp)
 8ac:	7a42                	ld	s4,48(sp)
 8ae:	7aa2                	ld	s5,40(sp)
 8b0:	7b02                	ld	s6,32(sp)
 8b2:	6be2                	ld	s7,24(sp)
 8b4:	6c42                	ld	s8,16(sp)
    }
  }
}
 8b6:	60e6                	ld	ra,88(sp)
 8b8:	6446                	ld	s0,80(sp)
 8ba:	64a6                	ld	s1,72(sp)
 8bc:	6125                	addi	sp,sp,96
 8be:	8082                	ret
      if(c0 == 'd'){
 8c0:	06400713          	li	a4,100
 8c4:	e6e789e3          	beq	a5,a4,736 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 8c8:	f9478693          	addi	a3,a5,-108
 8cc:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 8d0:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8d2:	4701                	li	a4,0
      } else if(c0 == 'u'){
 8d4:	07500513          	li	a0,117
 8d8:	eaa786e3          	beq	a5,a0,784 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 8dc:	f8b60513          	addi	a0,a2,-117
 8e0:	e119                	bnez	a0,8e6 <vprintf+0x250>
 8e2:	ea069de3          	bnez	a3,79c <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 8e6:	f8b58513          	addi	a0,a1,-117
 8ea:	e119                	bnez	a0,8f0 <vprintf+0x25a>
 8ec:	ec0715e3          	bnez	a4,7b6 <vprintf+0x120>
      } else if(c0 == 'x'){
 8f0:	07800513          	li	a0,120
 8f4:	eca78ee3          	beq	a5,a0,7d0 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 8f8:	f8860613          	addi	a2,a2,-120
 8fc:	e219                	bnez	a2,902 <vprintf+0x26c>
 8fe:	ee0695e3          	bnez	a3,7e8 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 902:	f8858593          	addi	a1,a1,-120
 906:	e199                	bnez	a1,90c <vprintf+0x276>
 908:	ee071de3          	bnez	a4,802 <vprintf+0x16c>
      } else if(c0 == 'p'){
 90c:	07000713          	li	a4,112
 910:	f0e786e3          	beq	a5,a4,81c <vprintf+0x186>
      } else if(c0 == 's'){
 914:	07300713          	li	a4,115
 918:	f4e786e3          	beq	a5,a4,864 <vprintf+0x1ce>
      } else if(c0 == '%'){
 91c:	02500713          	li	a4,37
 920:	f6e78be3          	beq	a5,a4,896 <vprintf+0x200>
        putc(fd, '%');
 924:	02500593          	li	a1,37
 928:	855a                	mv	a0,s6
 92a:	cabff0ef          	jal	5d4 <putc>
        putc(fd, c0);
 92e:	85a6                	mv	a1,s1
 930:	855a                	mv	a0,s6
 932:	ca3ff0ef          	jal	5d4 <putc>
      state = 0;
 936:	4981                	li	s3,0
 938:	b34d                	j	6da <vprintf+0x44>

000000000000093a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 93a:	715d                	addi	sp,sp,-80
 93c:	ec06                	sd	ra,24(sp)
 93e:	e822                	sd	s0,16(sp)
 940:	1000                	addi	s0,sp,32
 942:	e010                	sd	a2,0(s0)
 944:	e414                	sd	a3,8(s0)
 946:	e818                	sd	a4,16(s0)
 948:	ec1c                	sd	a5,24(s0)
 94a:	03043023          	sd	a6,32(s0)
 94e:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 952:	8622                	mv	a2,s0
 954:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 958:	d3fff0ef          	jal	696 <vprintf>
}
 95c:	60e2                	ld	ra,24(sp)
 95e:	6442                	ld	s0,16(sp)
 960:	6161                	addi	sp,sp,80
 962:	8082                	ret

0000000000000964 <printf>:

void
printf(const char *fmt, ...)
{
 964:	711d                	addi	sp,sp,-96
 966:	ec06                	sd	ra,24(sp)
 968:	e822                	sd	s0,16(sp)
 96a:	1000                	addi	s0,sp,32
 96c:	e40c                	sd	a1,8(s0)
 96e:	e810                	sd	a2,16(s0)
 970:	ec14                	sd	a3,24(s0)
 972:	f018                	sd	a4,32(s0)
 974:	f41c                	sd	a5,40(s0)
 976:	03043823          	sd	a6,48(s0)
 97a:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 97e:	00840613          	addi	a2,s0,8
 982:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 986:	85aa                	mv	a1,a0
 988:	4505                	li	a0,1
 98a:	d0dff0ef          	jal	696 <vprintf>
}
 98e:	60e2                	ld	ra,24(sp)
 990:	6442                	ld	s0,16(sp)
 992:	6125                	addi	sp,sp,96
 994:	8082                	ret

0000000000000996 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 996:	1141                	addi	sp,sp,-16
 998:	e406                	sd	ra,8(sp)
 99a:	e022                	sd	s0,0(sp)
 99c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 99e:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9a2:	00000797          	auipc	a5,0x0
 9a6:	65e7b783          	ld	a5,1630(a5) # 1000 <freep>
 9aa:	a039                	j	9b8 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9ac:	6398                	ld	a4,0(a5)
 9ae:	00e7e463          	bltu	a5,a4,9b6 <free+0x20>
 9b2:	00e6ea63          	bltu	a3,a4,9c6 <free+0x30>
{
 9b6:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9b8:	fed7fae3          	bgeu	a5,a3,9ac <free+0x16>
 9bc:	6398                	ld	a4,0(a5)
 9be:	00e6e463          	bltu	a3,a4,9c6 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9c2:	fee7eae3          	bltu	a5,a4,9b6 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 9c6:	ff852583          	lw	a1,-8(a0)
 9ca:	6390                	ld	a2,0(a5)
 9cc:	02059813          	slli	a6,a1,0x20
 9d0:	01c85713          	srli	a4,a6,0x1c
 9d4:	9736                	add	a4,a4,a3
 9d6:	02e60563          	beq	a2,a4,a00 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 9da:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 9de:	4790                	lw	a2,8(a5)
 9e0:	02061593          	slli	a1,a2,0x20
 9e4:	01c5d713          	srli	a4,a1,0x1c
 9e8:	973e                	add	a4,a4,a5
 9ea:	02e68263          	beq	a3,a4,a0e <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 9ee:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 9f0:	00000717          	auipc	a4,0x0
 9f4:	60f73823          	sd	a5,1552(a4) # 1000 <freep>
}
 9f8:	60a2                	ld	ra,8(sp)
 9fa:	6402                	ld	s0,0(sp)
 9fc:	0141                	addi	sp,sp,16
 9fe:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 a00:	4618                	lw	a4,8(a2)
 a02:	9f2d                	addw	a4,a4,a1
 a04:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a08:	6398                	ld	a4,0(a5)
 a0a:	6310                	ld	a2,0(a4)
 a0c:	b7f9                	j	9da <free+0x44>
    p->s.size += bp->s.size;
 a0e:	ff852703          	lw	a4,-8(a0)
 a12:	9f31                	addw	a4,a4,a2
 a14:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 a16:	ff053683          	ld	a3,-16(a0)
 a1a:	bfd1                	j	9ee <free+0x58>

0000000000000a1c <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a1c:	7139                	addi	sp,sp,-64
 a1e:	fc06                	sd	ra,56(sp)
 a20:	f822                	sd	s0,48(sp)
 a22:	f04a                	sd	s2,32(sp)
 a24:	ec4e                	sd	s3,24(sp)
 a26:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a28:	02051993          	slli	s3,a0,0x20
 a2c:	0209d993          	srli	s3,s3,0x20
 a30:	09bd                	addi	s3,s3,15
 a32:	0049d993          	srli	s3,s3,0x4
 a36:	2985                	addiw	s3,s3,1
 a38:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 a3a:	00000517          	auipc	a0,0x0
 a3e:	5c653503          	ld	a0,1478(a0) # 1000 <freep>
 a42:	c905                	beqz	a0,a72 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a44:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a46:	4798                	lw	a4,8(a5)
 a48:	09377663          	bgeu	a4,s3,ad4 <malloc+0xb8>
 a4c:	f426                	sd	s1,40(sp)
 a4e:	e852                	sd	s4,16(sp)
 a50:	e456                	sd	s5,8(sp)
 a52:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a54:	8a4e                	mv	s4,s3
 a56:	6705                	lui	a4,0x1
 a58:	00e9f363          	bgeu	s3,a4,a5e <malloc+0x42>
 a5c:	6a05                	lui	s4,0x1
 a5e:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a62:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a66:	00000497          	auipc	s1,0x0
 a6a:	59a48493          	addi	s1,s1,1434 # 1000 <freep>
  if(p == (char*)-1)
 a6e:	5afd                	li	s5,-1
 a70:	a83d                	j	aae <malloc+0x92>
 a72:	f426                	sd	s1,40(sp)
 a74:	e852                	sd	s4,16(sp)
 a76:	e456                	sd	s5,8(sp)
 a78:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a7a:	00000797          	auipc	a5,0x0
 a7e:	5a678793          	addi	a5,a5,1446 # 1020 <base>
 a82:	00000717          	auipc	a4,0x0
 a86:	56f73f23          	sd	a5,1406(a4) # 1000 <freep>
 a8a:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a8c:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a90:	b7d1                	j	a54 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 a92:	6398                	ld	a4,0(a5)
 a94:	e118                	sd	a4,0(a0)
 a96:	a899                	j	aec <malloc+0xd0>
  hp->s.size = nu;
 a98:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a9c:	0541                	addi	a0,a0,16
 a9e:	ef9ff0ef          	jal	996 <free>
  return freep;
 aa2:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 aa4:	c125                	beqz	a0,b04 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 aa6:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 aa8:	4798                	lw	a4,8(a5)
 aaa:	03277163          	bgeu	a4,s2,acc <malloc+0xb0>
    if(p == freep)
 aae:	6098                	ld	a4,0(s1)
 ab0:	853e                	mv	a0,a5
 ab2:	fef71ae3          	bne	a4,a5,aa6 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 ab6:	8552                	mv	a0,s4
 ab8:	acfff0ef          	jal	586 <sbrk>
  if(p == (char*)-1)
 abc:	fd551ee3          	bne	a0,s5,a98 <malloc+0x7c>
        return 0;
 ac0:	4501                	li	a0,0
 ac2:	74a2                	ld	s1,40(sp)
 ac4:	6a42                	ld	s4,16(sp)
 ac6:	6aa2                	ld	s5,8(sp)
 ac8:	6b02                	ld	s6,0(sp)
 aca:	a03d                	j	af8 <malloc+0xdc>
 acc:	74a2                	ld	s1,40(sp)
 ace:	6a42                	ld	s4,16(sp)
 ad0:	6aa2                	ld	s5,8(sp)
 ad2:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 ad4:	fae90fe3          	beq	s2,a4,a92 <malloc+0x76>
        p->s.size -= nunits;
 ad8:	4137073b          	subw	a4,a4,s3
 adc:	c798                	sw	a4,8(a5)
        p += p->s.size;
 ade:	02071693          	slli	a3,a4,0x20
 ae2:	01c6d713          	srli	a4,a3,0x1c
 ae6:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 ae8:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 aec:	00000717          	auipc	a4,0x0
 af0:	50a73a23          	sd	a0,1300(a4) # 1000 <freep>
      return (void*)(p + 1);
 af4:	01078513          	addi	a0,a5,16
  }
}
 af8:	70e2                	ld	ra,56(sp)
 afa:	7442                	ld	s0,48(sp)
 afc:	7902                	ld	s2,32(sp)
 afe:	69e2                	ld	s3,24(sp)
 b00:	6121                	addi	sp,sp,64
 b02:	8082                	ret
 b04:	74a2                	ld	s1,40(sp)
 b06:	6a42                	ld	s4,16(sp)
 b08:	6aa2                	ld	s5,8(sp)
 b0a:	6b02                	ld	s6,0(sp)
 b0c:	b7f5                	j	af8 <malloc+0xdc>
