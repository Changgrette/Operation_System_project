
user/_pgtbltest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <err>:

char *testname = "???";

void
err(char *why)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	e04a                	sd	s2,0(sp)
   a:	1000                	addi	s0,sp,32
   c:	892a                	mv	s2,a0
  printf("pgtbltest: %s failed: %s, pid=%d\n", testname, why, getpid());
   e:	00001497          	auipc	s1,0x1
  12:	ff24b483          	ld	s1,-14(s1) # 1000 <testname>
  16:	5e4000ef          	jal	5fa <getpid>
  1a:	86aa                	mv	a3,a0
  1c:	864a                	mv	a2,s2
  1e:	85a6                	mv	a1,s1
  20:	00001517          	auipc	a0,0x1
  24:	b7050513          	addi	a0,a0,-1168 # b90 <malloc+0xf8>
  28:	1b9000ef          	jal	9e0 <printf>
  exit(1);
  2c:	4505                	li	a0,1
  2e:	54c000ef          	jal	57a <exit>

0000000000000032 <print_pte>:
}

void
print_pte(uint64 va)
{
  32:	1101                	addi	sp,sp,-32
  34:	ec06                	sd	ra,24(sp)
  36:	e822                	sd	s0,16(sp)
  38:	e426                	sd	s1,8(sp)
  3a:	1000                	addi	s0,sp,32
  3c:	84aa                	mv	s1,a0
    pte_t pte = (pte_t) pgpte((void *) va);
  3e:	5fe000ef          	jal	63c <pgpte>
  42:	862a                	mv	a2,a0
    printf("va 0x%lx pte 0x%lx pa 0x%lx perm 0x%lx\n", va, pte, PTE2PA(pte), PTE_FLAGS(pte));
  44:	00a55693          	srli	a3,a0,0xa
  48:	3ff57713          	andi	a4,a0,1023
  4c:	06b2                	slli	a3,a3,0xc
  4e:	85a6                	mv	a1,s1
  50:	00001517          	auipc	a0,0x1
  54:	b6850513          	addi	a0,a0,-1176 # bb8 <malloc+0x120>
  58:	189000ef          	jal	9e0 <printf>
}
  5c:	60e2                	ld	ra,24(sp)
  5e:	6442                	ld	s0,16(sp)
  60:	64a2                	ld	s1,8(sp)
  62:	6105                	addi	sp,sp,32
  64:	8082                	ret

0000000000000066 <print_pgtbl>:

void
print_pgtbl()
{
  66:	7179                	addi	sp,sp,-48
  68:	f406                	sd	ra,40(sp)
  6a:	f022                	sd	s0,32(sp)
  6c:	ec26                	sd	s1,24(sp)
  6e:	e84a                	sd	s2,16(sp)
  70:	e44e                	sd	s3,8(sp)
  72:	1800                	addi	s0,sp,48
  printf("print_pgtbl starting\n");
  74:	00001517          	auipc	a0,0x1
  78:	b6c50513          	addi	a0,a0,-1172 # be0 <malloc+0x148>
  7c:	165000ef          	jal	9e0 <printf>
  80:	4481                	li	s1,0
  for (uint64 i = 0; i < 10; i++) {
  82:	6985                	lui	s3,0x1
  84:	6929                	lui	s2,0xa
    print_pte(i * PGSIZE);
  86:	8526                	mv	a0,s1
  88:	fabff0ef          	jal	32 <print_pte>
  for (uint64 i = 0; i < 10; i++) {
  8c:	94ce                	add	s1,s1,s3
  8e:	ff249ce3          	bne	s1,s2,86 <print_pgtbl+0x20>
  92:	020004b7          	lui	s1,0x2000
  96:	14ed                	addi	s1,s1,-5 # 1fffffb <base+0x1ffefdb>
  98:	04b6                	slli	s1,s1,0xd
  }
  uint64 top = MAXVA/PGSIZE;
  for (uint64 i = top-10; i < top; i++) {
  9a:	6985                	lui	s3,0x1
  9c:	4905                	li	s2,1
  9e:	191a                	slli	s2,s2,0x26
    print_pte(i * PGSIZE);
  a0:	8526                	mv	a0,s1
  a2:	f91ff0ef          	jal	32 <print_pte>
  for (uint64 i = top-10; i < top; i++) {
  a6:	94ce                	add	s1,s1,s3
  a8:	ff249ce3          	bne	s1,s2,a0 <print_pgtbl+0x3a>
  }
  printf("print_pgtbl: OK\n");
  ac:	00001517          	auipc	a0,0x1
  b0:	b4c50513          	addi	a0,a0,-1204 # bf8 <malloc+0x160>
  b4:	12d000ef          	jal	9e0 <printf>
}
  b8:	70a2                	ld	ra,40(sp)
  ba:	7402                	ld	s0,32(sp)
  bc:	64e2                	ld	s1,24(sp)
  be:	6942                	ld	s2,16(sp)
  c0:	69a2                	ld	s3,8(sp)
  c2:	6145                	addi	sp,sp,48
  c4:	8082                	ret

00000000000000c6 <ugetpid_test>:

void
ugetpid_test()
{
  c6:	7179                	addi	sp,sp,-48
  c8:	f406                	sd	ra,40(sp)
  ca:	f022                	sd	s0,32(sp)
  cc:	ec26                	sd	s1,24(sp)
  ce:	e84a                	sd	s2,16(sp)
  d0:	1800                	addi	s0,sp,48
  int i;

  printf("ugetpid_test starting\n");
  d2:	00001517          	auipc	a0,0x1
  d6:	b3e50513          	addi	a0,a0,-1218 # c10 <malloc+0x178>
  da:	107000ef          	jal	9e0 <printf>
  testname = "ugetpid_test";
  de:	00001797          	auipc	a5,0x1
  e2:	b4a78793          	addi	a5,a5,-1206 # c28 <malloc+0x190>
  e6:	00001717          	auipc	a4,0x1
  ea:	f0f73d23          	sd	a5,-230(a4) # 1000 <testname>
  ee:	04000493          	li	s1,64

  for (i = 0; i < 64; i++) {
    int ret = fork();
    if (ret != 0) {
      wait(&ret);
  f2:	fdc40913          	addi	s2,s0,-36
    int ret = fork();
  f6:	47c000ef          	jal	572 <fork>
  fa:	fca42e23          	sw	a0,-36(s0)
    if (ret != 0) {
  fe:	c905                	beqz	a0,12e <ugetpid_test+0x68>
      wait(&ret);
 100:	854a                	mv	a0,s2
 102:	480000ef          	jal	582 <wait>
      if (ret != 0)
 106:	fdc42783          	lw	a5,-36(s0)
 10a:	ef99                	bnez	a5,128 <ugetpid_test+0x62>
  for (i = 0; i < 64; i++) {
 10c:	34fd                	addiw	s1,s1,-1
 10e:	f4e5                	bnez	s1,f6 <ugetpid_test+0x30>
    }
    if (getpid() != ugetpid())
      err("missmatched PID");
    exit(0);
  }
  printf("ugetpid_test: OK\n");
 110:	00001517          	auipc	a0,0x1
 114:	b3850513          	addi	a0,a0,-1224 # c48 <malloc+0x1b0>
 118:	0c9000ef          	jal	9e0 <printf>
}
 11c:	70a2                	ld	ra,40(sp)
 11e:	7402                	ld	s0,32(sp)
 120:	64e2                	ld	s1,24(sp)
 122:	6942                	ld	s2,16(sp)
 124:	6145                	addi	sp,sp,48
 126:	8082                	ret
        exit(1);
 128:	4505                	li	a0,1
 12a:	450000ef          	jal	57a <exit>
    if (getpid() != ugetpid())
 12e:	4cc000ef          	jal	5fa <getpid>
 132:	84aa                	mv	s1,a0
 134:	424000ef          	jal	558 <ugetpid>
 138:	00a48863          	beq	s1,a0,148 <ugetpid_test+0x82>
      err("missmatched PID");
 13c:	00001517          	auipc	a0,0x1
 140:	afc50513          	addi	a0,a0,-1284 # c38 <malloc+0x1a0>
 144:	ebdff0ef          	jal	0 <err>
    exit(0);
 148:	4501                	li	a0,0
 14a:	430000ef          	jal	57a <exit>

000000000000014e <print_kpgtbl>:

void
print_kpgtbl()
{
 14e:	1141                	addi	sp,sp,-16
 150:	e406                	sd	ra,8(sp)
 152:	e022                	sd	s0,0(sp)
 154:	0800                	addi	s0,sp,16
  printf("print_kpgtbl starting\n");
 156:	00001517          	auipc	a0,0x1
 15a:	b0a50513          	addi	a0,a0,-1270 # c60 <malloc+0x1c8>
 15e:	083000ef          	jal	9e0 <printf>
  kpgtbl();
 162:	4e4000ef          	jal	646 <kpgtbl>
  printf("print_kpgtbl: OK\n");
 166:	00001517          	auipc	a0,0x1
 16a:	b1250513          	addi	a0,a0,-1262 # c78 <malloc+0x1e0>
 16e:	073000ef          	jal	9e0 <printf>
}
 172:	60a2                	ld	ra,8(sp)
 174:	6402                	ld	s0,0(sp)
 176:	0141                	addi	sp,sp,16
 178:	8082                	ret

000000000000017a <supercheck>:


void
supercheck(uint64 s)
{
 17a:	7139                	addi	sp,sp,-64
 17c:	fc06                	sd	ra,56(sp)
 17e:	f822                	sd	s0,48(sp)
 180:	e05a                	sd	s6,0(sp)
 182:	0080                	addi	s0,sp,64
 184:	8b2a                	mv	s6,a0
  pte_t last_pte = 0;

  for (uint64 p = s;  p < s + 512 * PGSIZE; p += PGSIZE) {
 186:	ffe007b7          	lui	a5,0xffe00
 18a:	06f57663          	bgeu	a0,a5,1f6 <supercheck+0x7c>
 18e:	f426                	sd	s1,40(sp)
 190:	f04a                	sd	s2,32(sp)
 192:	ec4e                	sd	s3,24(sp)
 194:	e852                	sd	s4,16(sp)
 196:	e456                	sd	s5,8(sp)
 198:	002009b7          	lui	s3,0x200
 19c:	99aa                	add	s3,s3,a0
 19e:	84aa                	mv	s1,a0
  pte_t last_pte = 0;
 1a0:	4501                	li	a0,0
    if(pte == 0)
      err("no pte");
    if ((uint64) last_pte != 0 && pte != last_pte) {
        err("pte different");
    }
    if((pte & PTE_V) == 0 || (pte & PTE_R) == 0 || (pte & PTE_W) == 0){
 1a2:	4a1d                	li	s4,7
  for (uint64 p = s;  p < s + 512 * PGSIZE; p += PGSIZE) {
 1a4:	6a85                	lui	s5,0x1
 1a6:	a831                	j	1c2 <supercheck+0x48>
      err("no pte");
 1a8:	00001517          	auipc	a0,0x1
 1ac:	ae850513          	addi	a0,a0,-1304 # c90 <malloc+0x1f8>
 1b0:	e51ff0ef          	jal	0 <err>
    if((pte & PTE_V) == 0 || (pte & PTE_R) == 0 || (pte & PTE_W) == 0){
 1b4:	00757793          	andi	a5,a0,7
 1b8:	03479463          	bne	a5,s4,1e0 <supercheck+0x66>
  for (uint64 p = s;  p < s + 512 * PGSIZE; p += PGSIZE) {
 1bc:	94d6                	add	s1,s1,s5
 1be:	0334f763          	bgeu	s1,s3,1ec <supercheck+0x72>
    pte_t pte = (pte_t) pgpte((void *) p);
 1c2:	892a                	mv	s2,a0
 1c4:	8526                	mv	a0,s1
 1c6:	476000ef          	jal	63c <pgpte>
    if(pte == 0)
 1ca:	dd79                	beqz	a0,1a8 <supercheck+0x2e>
    if ((uint64) last_pte != 0 && pte != last_pte) {
 1cc:	fe0904e3          	beqz	s2,1b4 <supercheck+0x3a>
 1d0:	ff2502e3          	beq	a0,s2,1b4 <supercheck+0x3a>
        err("pte different");
 1d4:	00001517          	auipc	a0,0x1
 1d8:	ac450513          	addi	a0,a0,-1340 # c98 <malloc+0x200>
 1dc:	e25ff0ef          	jal	0 <err>
      err("pte wrong");
 1e0:	00001517          	auipc	a0,0x1
 1e4:	ac850513          	addi	a0,a0,-1336 # ca8 <malloc+0x210>
 1e8:	e19ff0ef          	jal	0 <err>
 1ec:	74a2                	ld	s1,40(sp)
 1ee:	7902                	ld	s2,32(sp)
 1f0:	69e2                	ld	s3,24(sp)
 1f2:	6a42                	ld	s4,16(sp)
 1f4:	6aa2                	ld	s5,8(sp)
    }
    last_pte = pte;
  }

  for(int i = 0; i < 512; i += PGSIZE){
    *(int*)(s+i) = i;
 1f6:	000b2023          	sw	zero,0(s6)

  for(int i = 0; i < 512; i += PGSIZE){
    if(*(int*)(s+i) != i)
      err("wrong value");
  }
}
 1fa:	70e2                	ld	ra,56(sp)
 1fc:	7442                	ld	s0,48(sp)
 1fe:	6b02                	ld	s6,0(sp)
 200:	6121                	addi	sp,sp,64
 202:	8082                	ret

0000000000000204 <superpg_test>:

void
superpg_test()
{
 204:	7179                	addi	sp,sp,-48
 206:	f406                	sd	ra,40(sp)
 208:	f022                	sd	s0,32(sp)
 20a:	ec26                	sd	s1,24(sp)
 20c:	1800                	addi	s0,sp,48
  int pid;
  
  printf("superpg_test starting\n");
 20e:	00001517          	auipc	a0,0x1
 212:	aaa50513          	addi	a0,a0,-1366 # cb8 <malloc+0x220>
 216:	7ca000ef          	jal	9e0 <printf>
  testname = "superpg_test";
 21a:	00001797          	auipc	a5,0x1
 21e:	ab678793          	addi	a5,a5,-1354 # cd0 <malloc+0x238>
 222:	00001717          	auipc	a4,0x1
 226:	dcf73f23          	sd	a5,-546(a4) # 1000 <testname>
  
  char *end = sbrk(N);
 22a:	00800537          	lui	a0,0x800
 22e:	3d4000ef          	jal	602 <sbrk>
  if (end == 0 || end == (char*)0xffffffffffffffff)
 232:	fff50713          	addi	a4,a0,-1 # 7fffff <base+0x7fefdf>
 236:	57f5                	li	a5,-3
 238:	04e7e463          	bltu	a5,a4,280 <superpg_test+0x7c>
    err("sbrk failed");
  
  uint64 s = SUPERPGROUNDUP((uint64) end);
 23c:	002007b7          	lui	a5,0x200
 240:	17fd                	addi	a5,a5,-1 # 1fffff <base+0x1fefdf>
 242:	953e                	add	a0,a0,a5
 244:	ffe007b7          	lui	a5,0xffe00
 248:	8fe9                	and	a5,a5,a0
 24a:	84be                	mv	s1,a5
  supercheck(s);
 24c:	853e                	mv	a0,a5
 24e:	f2dff0ef          	jal	17a <supercheck>
  if((pid = fork()) < 0) {
 252:	320000ef          	jal	572 <fork>
 256:	02054b63          	bltz	a0,28c <superpg_test+0x88>
    err("fork");
  } else if(pid == 0) {
 25a:	cd1d                	beqz	a0,298 <superpg_test+0x94>
    supercheck(s);
    exit(0);
  } else {
    int status;
    wait(&status);
 25c:	fdc40513          	addi	a0,s0,-36
 260:	322000ef          	jal	582 <wait>
    if (status != 0) {
 264:	fdc42783          	lw	a5,-36(s0)
 268:	ef95                	bnez	a5,2a4 <superpg_test+0xa0>
      exit(0);
    }
  }
  printf("superpg_test: OK\n");  
 26a:	00001517          	auipc	a0,0x1
 26e:	a8e50513          	addi	a0,a0,-1394 # cf8 <malloc+0x260>
 272:	76e000ef          	jal	9e0 <printf>
}
 276:	70a2                	ld	ra,40(sp)
 278:	7402                	ld	s0,32(sp)
 27a:	64e2                	ld	s1,24(sp)
 27c:	6145                	addi	sp,sp,48
 27e:	8082                	ret
    err("sbrk failed");
 280:	00001517          	auipc	a0,0x1
 284:	a6050513          	addi	a0,a0,-1440 # ce0 <malloc+0x248>
 288:	d79ff0ef          	jal	0 <err>
    err("fork");
 28c:	00001517          	auipc	a0,0x1
 290:	a6450513          	addi	a0,a0,-1436 # cf0 <malloc+0x258>
 294:	d6dff0ef          	jal	0 <err>
    supercheck(s);
 298:	8526                	mv	a0,s1
 29a:	ee1ff0ef          	jal	17a <supercheck>
    exit(0);
 29e:	4501                	li	a0,0
 2a0:	2da000ef          	jal	57a <exit>
      exit(0);
 2a4:	4501                	li	a0,0
 2a6:	2d4000ef          	jal	57a <exit>

00000000000002aa <main>:
{
 2aa:	1141                	addi	sp,sp,-16
 2ac:	e406                	sd	ra,8(sp)
 2ae:	e022                	sd	s0,0(sp)
 2b0:	0800                	addi	s0,sp,16
  print_pgtbl();
 2b2:	db5ff0ef          	jal	66 <print_pgtbl>
  ugetpid_test();
 2b6:	e11ff0ef          	jal	c6 <ugetpid_test>
  print_kpgtbl();
 2ba:	e95ff0ef          	jal	14e <print_kpgtbl>
  superpg_test();
 2be:	f47ff0ef          	jal	204 <superpg_test>
  printf("pgtbltest: all tests succeeded\n");
 2c2:	00001517          	auipc	a0,0x1
 2c6:	a4e50513          	addi	a0,a0,-1458 # d10 <malloc+0x278>
 2ca:	716000ef          	jal	9e0 <printf>
  exit(0);
 2ce:	4501                	li	a0,0
 2d0:	2aa000ef          	jal	57a <exit>

00000000000002d4 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 2d4:	1141                	addi	sp,sp,-16
 2d6:	e406                	sd	ra,8(sp)
 2d8:	e022                	sd	s0,0(sp)
 2da:	0800                	addi	s0,sp,16
  extern int main();
  main();
 2dc:	fcfff0ef          	jal	2aa <main>
  exit(0);
 2e0:	4501                	li	a0,0
 2e2:	298000ef          	jal	57a <exit>

00000000000002e6 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 2e6:	1141                	addi	sp,sp,-16
 2e8:	e406                	sd	ra,8(sp)
 2ea:	e022                	sd	s0,0(sp)
 2ec:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 2ee:	87aa                	mv	a5,a0
 2f0:	0585                	addi	a1,a1,1
 2f2:	0785                	addi	a5,a5,1 # ffffffffffe00001 <base+0xffffffffffdfefe1>
 2f4:	fff5c703          	lbu	a4,-1(a1)
 2f8:	fee78fa3          	sb	a4,-1(a5)
 2fc:	fb75                	bnez	a4,2f0 <strcpy+0xa>
    ;
  return os;
}
 2fe:	60a2                	ld	ra,8(sp)
 300:	6402                	ld	s0,0(sp)
 302:	0141                	addi	sp,sp,16
 304:	8082                	ret

0000000000000306 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 306:	1141                	addi	sp,sp,-16
 308:	e406                	sd	ra,8(sp)
 30a:	e022                	sd	s0,0(sp)
 30c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 30e:	00054783          	lbu	a5,0(a0)
 312:	cb91                	beqz	a5,326 <strcmp+0x20>
 314:	0005c703          	lbu	a4,0(a1)
 318:	00f71763          	bne	a4,a5,326 <strcmp+0x20>
    p++, q++;
 31c:	0505                	addi	a0,a0,1
 31e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 320:	00054783          	lbu	a5,0(a0)
 324:	fbe5                	bnez	a5,314 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 326:	0005c503          	lbu	a0,0(a1)
}
 32a:	40a7853b          	subw	a0,a5,a0
 32e:	60a2                	ld	ra,8(sp)
 330:	6402                	ld	s0,0(sp)
 332:	0141                	addi	sp,sp,16
 334:	8082                	ret

0000000000000336 <strlen>:

uint
strlen(const char *s)
{
 336:	1141                	addi	sp,sp,-16
 338:	e406                	sd	ra,8(sp)
 33a:	e022                	sd	s0,0(sp)
 33c:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 33e:	00054783          	lbu	a5,0(a0)
 342:	cf91                	beqz	a5,35e <strlen+0x28>
 344:	00150793          	addi	a5,a0,1
 348:	86be                	mv	a3,a5
 34a:	0785                	addi	a5,a5,1
 34c:	fff7c703          	lbu	a4,-1(a5)
 350:	ff65                	bnez	a4,348 <strlen+0x12>
 352:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 356:	60a2                	ld	ra,8(sp)
 358:	6402                	ld	s0,0(sp)
 35a:	0141                	addi	sp,sp,16
 35c:	8082                	ret
  for(n = 0; s[n]; n++)
 35e:	4501                	li	a0,0
 360:	bfdd                	j	356 <strlen+0x20>

0000000000000362 <memset>:

void*
memset(void *dst, int c, uint n)
{
 362:	1141                	addi	sp,sp,-16
 364:	e406                	sd	ra,8(sp)
 366:	e022                	sd	s0,0(sp)
 368:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 36a:	ca19                	beqz	a2,380 <memset+0x1e>
 36c:	87aa                	mv	a5,a0
 36e:	1602                	slli	a2,a2,0x20
 370:	9201                	srli	a2,a2,0x20
 372:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 376:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 37a:	0785                	addi	a5,a5,1
 37c:	fee79de3          	bne	a5,a4,376 <memset+0x14>
  }
  return dst;
}
 380:	60a2                	ld	ra,8(sp)
 382:	6402                	ld	s0,0(sp)
 384:	0141                	addi	sp,sp,16
 386:	8082                	ret

0000000000000388 <strchr>:

char*
strchr(const char *s, char c)
{
 388:	1141                	addi	sp,sp,-16
 38a:	e406                	sd	ra,8(sp)
 38c:	e022                	sd	s0,0(sp)
 38e:	0800                	addi	s0,sp,16
  for(; *s; s++)
 390:	00054783          	lbu	a5,0(a0)
 394:	cf81                	beqz	a5,3ac <strchr+0x24>
    if(*s == c)
 396:	00f58763          	beq	a1,a5,3a4 <strchr+0x1c>
  for(; *s; s++)
 39a:	0505                	addi	a0,a0,1
 39c:	00054783          	lbu	a5,0(a0)
 3a0:	fbfd                	bnez	a5,396 <strchr+0xe>
      return (char*)s;
  return 0;
 3a2:	4501                	li	a0,0
}
 3a4:	60a2                	ld	ra,8(sp)
 3a6:	6402                	ld	s0,0(sp)
 3a8:	0141                	addi	sp,sp,16
 3aa:	8082                	ret
  return 0;
 3ac:	4501                	li	a0,0
 3ae:	bfdd                	j	3a4 <strchr+0x1c>

00000000000003b0 <gets>:

char*
gets(char *buf, int max)
{
 3b0:	711d                	addi	sp,sp,-96
 3b2:	ec86                	sd	ra,88(sp)
 3b4:	e8a2                	sd	s0,80(sp)
 3b6:	e4a6                	sd	s1,72(sp)
 3b8:	e0ca                	sd	s2,64(sp)
 3ba:	fc4e                	sd	s3,56(sp)
 3bc:	f852                	sd	s4,48(sp)
 3be:	f456                	sd	s5,40(sp)
 3c0:	f05a                	sd	s6,32(sp)
 3c2:	ec5e                	sd	s7,24(sp)
 3c4:	e862                	sd	s8,16(sp)
 3c6:	1080                	addi	s0,sp,96
 3c8:	8baa                	mv	s7,a0
 3ca:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 3cc:	892a                	mv	s2,a0
 3ce:	4481                	li	s1,0
    cc = read(0, &c, 1);
 3d0:	faf40b13          	addi	s6,s0,-81
 3d4:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 3d6:	8c26                	mv	s8,s1
 3d8:	0014899b          	addiw	s3,s1,1
 3dc:	84ce                	mv	s1,s3
 3de:	0349d463          	bge	s3,s4,406 <gets+0x56>
    cc = read(0, &c, 1);
 3e2:	8656                	mv	a2,s5
 3e4:	85da                	mv	a1,s6
 3e6:	4501                	li	a0,0
 3e8:	1aa000ef          	jal	592 <read>
    if(cc < 1)
 3ec:	00a05d63          	blez	a0,406 <gets+0x56>
      break;
    buf[i++] = c;
 3f0:	faf44783          	lbu	a5,-81(s0)
 3f4:	00f90023          	sb	a5,0(s2) # a000 <base+0x8fe0>
    if(c == '\n' || c == '\r')
 3f8:	0905                	addi	s2,s2,1
 3fa:	ff678713          	addi	a4,a5,-10
 3fe:	c319                	beqz	a4,404 <gets+0x54>
 400:	17cd                	addi	a5,a5,-13
 402:	fbf1                	bnez	a5,3d6 <gets+0x26>
    buf[i++] = c;
 404:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 406:	9c5e                	add	s8,s8,s7
 408:	000c0023          	sb	zero,0(s8)
  return buf;
}
 40c:	855e                	mv	a0,s7
 40e:	60e6                	ld	ra,88(sp)
 410:	6446                	ld	s0,80(sp)
 412:	64a6                	ld	s1,72(sp)
 414:	6906                	ld	s2,64(sp)
 416:	79e2                	ld	s3,56(sp)
 418:	7a42                	ld	s4,48(sp)
 41a:	7aa2                	ld	s5,40(sp)
 41c:	7b02                	ld	s6,32(sp)
 41e:	6be2                	ld	s7,24(sp)
 420:	6c42                	ld	s8,16(sp)
 422:	6125                	addi	sp,sp,96
 424:	8082                	ret

0000000000000426 <stat>:

int
stat(const char *n, struct stat *st)
{
 426:	1101                	addi	sp,sp,-32
 428:	ec06                	sd	ra,24(sp)
 42a:	e822                	sd	s0,16(sp)
 42c:	e04a                	sd	s2,0(sp)
 42e:	1000                	addi	s0,sp,32
 430:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 432:	4581                	li	a1,0
 434:	186000ef          	jal	5ba <open>
  if(fd < 0)
 438:	02054263          	bltz	a0,45c <stat+0x36>
 43c:	e426                	sd	s1,8(sp)
 43e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 440:	85ca                	mv	a1,s2
 442:	190000ef          	jal	5d2 <fstat>
 446:	892a                	mv	s2,a0
  close(fd);
 448:	8526                	mv	a0,s1
 44a:	158000ef          	jal	5a2 <close>
  return r;
 44e:	64a2                	ld	s1,8(sp)
}
 450:	854a                	mv	a0,s2
 452:	60e2                	ld	ra,24(sp)
 454:	6442                	ld	s0,16(sp)
 456:	6902                	ld	s2,0(sp)
 458:	6105                	addi	sp,sp,32
 45a:	8082                	ret
    return -1;
 45c:	57fd                	li	a5,-1
 45e:	893e                	mv	s2,a5
 460:	bfc5                	j	450 <stat+0x2a>

0000000000000462 <atoi>:

int
atoi(const char *s)
{
 462:	1141                	addi	sp,sp,-16
 464:	e406                	sd	ra,8(sp)
 466:	e022                	sd	s0,0(sp)
 468:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 46a:	00054683          	lbu	a3,0(a0)
 46e:	fd06879b          	addiw	a5,a3,-48
 472:	0ff7f793          	zext.b	a5,a5
 476:	4625                	li	a2,9
 478:	02f66963          	bltu	a2,a5,4aa <atoi+0x48>
 47c:	872a                	mv	a4,a0
  n = 0;
 47e:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 480:	0705                	addi	a4,a4,1
 482:	0025179b          	slliw	a5,a0,0x2
 486:	9fa9                	addw	a5,a5,a0
 488:	0017979b          	slliw	a5,a5,0x1
 48c:	9fb5                	addw	a5,a5,a3
 48e:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 492:	00074683          	lbu	a3,0(a4)
 496:	fd06879b          	addiw	a5,a3,-48
 49a:	0ff7f793          	zext.b	a5,a5
 49e:	fef671e3          	bgeu	a2,a5,480 <atoi+0x1e>
  return n;
}
 4a2:	60a2                	ld	ra,8(sp)
 4a4:	6402                	ld	s0,0(sp)
 4a6:	0141                	addi	sp,sp,16
 4a8:	8082                	ret
  n = 0;
 4aa:	4501                	li	a0,0
 4ac:	bfdd                	j	4a2 <atoi+0x40>

00000000000004ae <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 4ae:	1141                	addi	sp,sp,-16
 4b0:	e406                	sd	ra,8(sp)
 4b2:	e022                	sd	s0,0(sp)
 4b4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 4b6:	02b57563          	bgeu	a0,a1,4e0 <memmove+0x32>
    while(n-- > 0)
 4ba:	00c05f63          	blez	a2,4d8 <memmove+0x2a>
 4be:	1602                	slli	a2,a2,0x20
 4c0:	9201                	srli	a2,a2,0x20
 4c2:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 4c6:	872a                	mv	a4,a0
      *dst++ = *src++;
 4c8:	0585                	addi	a1,a1,1
 4ca:	0705                	addi	a4,a4,1
 4cc:	fff5c683          	lbu	a3,-1(a1)
 4d0:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 4d4:	fee79ae3          	bne	a5,a4,4c8 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 4d8:	60a2                	ld	ra,8(sp)
 4da:	6402                	ld	s0,0(sp)
 4dc:	0141                	addi	sp,sp,16
 4de:	8082                	ret
    while(n-- > 0)
 4e0:	fec05ce3          	blez	a2,4d8 <memmove+0x2a>
    dst += n;
 4e4:	00c50733          	add	a4,a0,a2
    src += n;
 4e8:	95b2                	add	a1,a1,a2
 4ea:	fff6079b          	addiw	a5,a2,-1
 4ee:	1782                	slli	a5,a5,0x20
 4f0:	9381                	srli	a5,a5,0x20
 4f2:	fff7c793          	not	a5,a5
 4f6:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 4f8:	15fd                	addi	a1,a1,-1
 4fa:	177d                	addi	a4,a4,-1
 4fc:	0005c683          	lbu	a3,0(a1)
 500:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 504:	fef71ae3          	bne	a4,a5,4f8 <memmove+0x4a>
 508:	bfc1                	j	4d8 <memmove+0x2a>

000000000000050a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 50a:	1141                	addi	sp,sp,-16
 50c:	e406                	sd	ra,8(sp)
 50e:	e022                	sd	s0,0(sp)
 510:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 512:	c61d                	beqz	a2,540 <memcmp+0x36>
 514:	1602                	slli	a2,a2,0x20
 516:	9201                	srli	a2,a2,0x20
 518:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 51c:	00054783          	lbu	a5,0(a0)
 520:	0005c703          	lbu	a4,0(a1)
 524:	00e79863          	bne	a5,a4,534 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 528:	0505                	addi	a0,a0,1
    p2++;
 52a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 52c:	fed518e3          	bne	a0,a3,51c <memcmp+0x12>
  }
  return 0;
 530:	4501                	li	a0,0
 532:	a019                	j	538 <memcmp+0x2e>
      return *p1 - *p2;
 534:	40e7853b          	subw	a0,a5,a4
}
 538:	60a2                	ld	ra,8(sp)
 53a:	6402                	ld	s0,0(sp)
 53c:	0141                	addi	sp,sp,16
 53e:	8082                	ret
  return 0;
 540:	4501                	li	a0,0
 542:	bfdd                	j	538 <memcmp+0x2e>

0000000000000544 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 544:	1141                	addi	sp,sp,-16
 546:	e406                	sd	ra,8(sp)
 548:	e022                	sd	s0,0(sp)
 54a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 54c:	f63ff0ef          	jal	4ae <memmove>
}
 550:	60a2                	ld	ra,8(sp)
 552:	6402                	ld	s0,0(sp)
 554:	0141                	addi	sp,sp,16
 556:	8082                	ret

0000000000000558 <ugetpid>:

#ifdef LAB_PGTBL
int
ugetpid(void)
{
 558:	1141                	addi	sp,sp,-16
 55a:	e406                	sd	ra,8(sp)
 55c:	e022                	sd	s0,0(sp)
 55e:	0800                	addi	s0,sp,16
  struct usyscall *u = (struct usyscall *)USYSCALL;
  return u->pid;
 560:	040007b7          	lui	a5,0x4000
 564:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3ffefdd>
 566:	07b2                	slli	a5,a5,0xc
}
 568:	4388                	lw	a0,0(a5)
 56a:	60a2                	ld	ra,8(sp)
 56c:	6402                	ld	s0,0(sp)
 56e:	0141                	addi	sp,sp,16
 570:	8082                	ret

0000000000000572 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 572:	4885                	li	a7,1
 ecall
 574:	00000073          	ecall
 ret
 578:	8082                	ret

000000000000057a <exit>:
.global exit
exit:
 li a7, SYS_exit
 57a:	4889                	li	a7,2
 ecall
 57c:	00000073          	ecall
 ret
 580:	8082                	ret

0000000000000582 <wait>:
.global wait
wait:
 li a7, SYS_wait
 582:	488d                	li	a7,3
 ecall
 584:	00000073          	ecall
 ret
 588:	8082                	ret

000000000000058a <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 58a:	4891                	li	a7,4
 ecall
 58c:	00000073          	ecall
 ret
 590:	8082                	ret

0000000000000592 <read>:
.global read
read:
 li a7, SYS_read
 592:	4895                	li	a7,5
 ecall
 594:	00000073          	ecall
 ret
 598:	8082                	ret

000000000000059a <write>:
.global write
write:
 li a7, SYS_write
 59a:	48c1                	li	a7,16
 ecall
 59c:	00000073          	ecall
 ret
 5a0:	8082                	ret

00000000000005a2 <close>:
.global close
close:
 li a7, SYS_close
 5a2:	48d5                	li	a7,21
 ecall
 5a4:	00000073          	ecall
 ret
 5a8:	8082                	ret

00000000000005aa <kill>:
.global kill
kill:
 li a7, SYS_kill
 5aa:	4899                	li	a7,6
 ecall
 5ac:	00000073          	ecall
 ret
 5b0:	8082                	ret

00000000000005b2 <exec>:
.global exec
exec:
 li a7, SYS_exec
 5b2:	489d                	li	a7,7
 ecall
 5b4:	00000073          	ecall
 ret
 5b8:	8082                	ret

00000000000005ba <open>:
.global open
open:
 li a7, SYS_open
 5ba:	48bd                	li	a7,15
 ecall
 5bc:	00000073          	ecall
 ret
 5c0:	8082                	ret

00000000000005c2 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 5c2:	48c5                	li	a7,17
 ecall
 5c4:	00000073          	ecall
 ret
 5c8:	8082                	ret

00000000000005ca <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 5ca:	48c9                	li	a7,18
 ecall
 5cc:	00000073          	ecall
 ret
 5d0:	8082                	ret

00000000000005d2 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 5d2:	48a1                	li	a7,8
 ecall
 5d4:	00000073          	ecall
 ret
 5d8:	8082                	ret

00000000000005da <link>:
.global link
link:
 li a7, SYS_link
 5da:	48cd                	li	a7,19
 ecall
 5dc:	00000073          	ecall
 ret
 5e0:	8082                	ret

00000000000005e2 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 5e2:	48d1                	li	a7,20
 ecall
 5e4:	00000073          	ecall
 ret
 5e8:	8082                	ret

00000000000005ea <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 5ea:	48a5                	li	a7,9
 ecall
 5ec:	00000073          	ecall
 ret
 5f0:	8082                	ret

00000000000005f2 <dup>:
.global dup
dup:
 li a7, SYS_dup
 5f2:	48a9                	li	a7,10
 ecall
 5f4:	00000073          	ecall
 ret
 5f8:	8082                	ret

00000000000005fa <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 5fa:	48ad                	li	a7,11
 ecall
 5fc:	00000073          	ecall
 ret
 600:	8082                	ret

0000000000000602 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 602:	48b1                	li	a7,12
 ecall
 604:	00000073          	ecall
 ret
 608:	8082                	ret

000000000000060a <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 60a:	48b5                	li	a7,13
 ecall
 60c:	00000073          	ecall
 ret
 610:	8082                	ret

0000000000000612 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 612:	48b9                	li	a7,14
 ecall
 614:	00000073          	ecall
 ret
 618:	8082                	ret

000000000000061a <bind>:
.global bind
bind:
 li a7, SYS_bind
 61a:	48f5                	li	a7,29
 ecall
 61c:	00000073          	ecall
 ret
 620:	8082                	ret

0000000000000622 <unbind>:
.global unbind
unbind:
 li a7, SYS_unbind
 622:	48f9                	li	a7,30
 ecall
 624:	00000073          	ecall
 ret
 628:	8082                	ret

000000000000062a <send>:
.global send
send:
 li a7, SYS_send
 62a:	48fd                	li	a7,31
 ecall
 62c:	00000073          	ecall
 ret
 630:	8082                	ret

0000000000000632 <recv>:
.global recv
recv:
 li a7, SYS_recv
 632:	02000893          	li	a7,32
 ecall
 636:	00000073          	ecall
 ret
 63a:	8082                	ret

000000000000063c <pgpte>:
.global pgpte
pgpte:
 li a7, SYS_pgpte
 63c:	02100893          	li	a7,33
 ecall
 640:	00000073          	ecall
 ret
 644:	8082                	ret

0000000000000646 <kpgtbl>:
.global kpgtbl
kpgtbl:
 li a7, SYS_kpgtbl
 646:	02200893          	li	a7,34
 ecall
 64a:	00000073          	ecall
 ret
 64e:	8082                	ret

0000000000000650 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 650:	1101                	addi	sp,sp,-32
 652:	ec06                	sd	ra,24(sp)
 654:	e822                	sd	s0,16(sp)
 656:	1000                	addi	s0,sp,32
 658:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 65c:	4605                	li	a2,1
 65e:	fef40593          	addi	a1,s0,-17
 662:	f39ff0ef          	jal	59a <write>
}
 666:	60e2                	ld	ra,24(sp)
 668:	6442                	ld	s0,16(sp)
 66a:	6105                	addi	sp,sp,32
 66c:	8082                	ret

000000000000066e <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 66e:	7139                	addi	sp,sp,-64
 670:	fc06                	sd	ra,56(sp)
 672:	f822                	sd	s0,48(sp)
 674:	f04a                	sd	s2,32(sp)
 676:	ec4e                	sd	s3,24(sp)
 678:	0080                	addi	s0,sp,64
 67a:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 67c:	cac9                	beqz	a3,70e <printint+0xa0>
 67e:	01f5d79b          	srliw	a5,a1,0x1f
 682:	c7d1                	beqz	a5,70e <printint+0xa0>
    neg = 1;
    x = -xx;
 684:	40b005bb          	negw	a1,a1
    neg = 1;
 688:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 68a:	fc040993          	addi	s3,s0,-64
  neg = 0;
 68e:	86ce                	mv	a3,s3
  i = 0;
 690:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 692:	00000817          	auipc	a6,0x0
 696:	6ae80813          	addi	a6,a6,1710 # d40 <digits>
 69a:	88ba                	mv	a7,a4
 69c:	0017051b          	addiw	a0,a4,1
 6a0:	872a                	mv	a4,a0
 6a2:	02c5f7bb          	remuw	a5,a1,a2
 6a6:	1782                	slli	a5,a5,0x20
 6a8:	9381                	srli	a5,a5,0x20
 6aa:	97c2                	add	a5,a5,a6
 6ac:	0007c783          	lbu	a5,0(a5)
 6b0:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 6b4:	87ae                	mv	a5,a1
 6b6:	02c5d5bb          	divuw	a1,a1,a2
 6ba:	0685                	addi	a3,a3,1
 6bc:	fcc7ffe3          	bgeu	a5,a2,69a <printint+0x2c>
  if(neg)
 6c0:	00030c63          	beqz	t1,6d8 <printint+0x6a>
    buf[i++] = '-';
 6c4:	fd050793          	addi	a5,a0,-48
 6c8:	00878533          	add	a0,a5,s0
 6cc:	02d00793          	li	a5,45
 6d0:	fef50823          	sb	a5,-16(a0)
 6d4:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 6d8:	02e05563          	blez	a4,702 <printint+0x94>
 6dc:	f426                	sd	s1,40(sp)
 6de:	377d                	addiw	a4,a4,-1
 6e0:	00e984b3          	add	s1,s3,a4
 6e4:	19fd                	addi	s3,s3,-1 # 1fffff <base+0x1fefdf>
 6e6:	99ba                	add	s3,s3,a4
 6e8:	1702                	slli	a4,a4,0x20
 6ea:	9301                	srli	a4,a4,0x20
 6ec:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 6f0:	0004c583          	lbu	a1,0(s1)
 6f4:	854a                	mv	a0,s2
 6f6:	f5bff0ef          	jal	650 <putc>
  while(--i >= 0)
 6fa:	14fd                	addi	s1,s1,-1
 6fc:	ff349ae3          	bne	s1,s3,6f0 <printint+0x82>
 700:	74a2                	ld	s1,40(sp)
}
 702:	70e2                	ld	ra,56(sp)
 704:	7442                	ld	s0,48(sp)
 706:	7902                	ld	s2,32(sp)
 708:	69e2                	ld	s3,24(sp)
 70a:	6121                	addi	sp,sp,64
 70c:	8082                	ret
  neg = 0;
 70e:	4301                	li	t1,0
 710:	bfad                	j	68a <printint+0x1c>

0000000000000712 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 712:	711d                	addi	sp,sp,-96
 714:	ec86                	sd	ra,88(sp)
 716:	e8a2                	sd	s0,80(sp)
 718:	e4a6                	sd	s1,72(sp)
 71a:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 71c:	0005c483          	lbu	s1,0(a1)
 720:	20048963          	beqz	s1,932 <vprintf+0x220>
 724:	e0ca                	sd	s2,64(sp)
 726:	fc4e                	sd	s3,56(sp)
 728:	f852                	sd	s4,48(sp)
 72a:	f456                	sd	s5,40(sp)
 72c:	f05a                	sd	s6,32(sp)
 72e:	ec5e                	sd	s7,24(sp)
 730:	e862                	sd	s8,16(sp)
 732:	8b2a                	mv	s6,a0
 734:	8a2e                	mv	s4,a1
 736:	8bb2                	mv	s7,a2
  state = 0;
 738:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 73a:	4901                	li	s2,0
 73c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 73e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 742:	06400c13          	li	s8,100
 746:	a00d                	j	768 <vprintf+0x56>
        putc(fd, c0);
 748:	85a6                	mv	a1,s1
 74a:	855a                	mv	a0,s6
 74c:	f05ff0ef          	jal	650 <putc>
 750:	a019                	j	756 <vprintf+0x44>
    } else if(state == '%'){
 752:	03598363          	beq	s3,s5,778 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 756:	0019079b          	addiw	a5,s2,1
 75a:	893e                	mv	s2,a5
 75c:	873e                	mv	a4,a5
 75e:	97d2                	add	a5,a5,s4
 760:	0007c483          	lbu	s1,0(a5)
 764:	1c048063          	beqz	s1,924 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 768:	0004879b          	sext.w	a5,s1
    if(state == 0){
 76c:	fe0993e3          	bnez	s3,752 <vprintf+0x40>
      if(c0 == '%'){
 770:	fd579ce3          	bne	a5,s5,748 <vprintf+0x36>
        state = '%';
 774:	89be                	mv	s3,a5
 776:	b7c5                	j	756 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 778:	00ea06b3          	add	a3,s4,a4
 77c:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 780:	1a060e63          	beqz	a2,93c <vprintf+0x22a>
      if(c0 == 'd'){
 784:	03878763          	beq	a5,s8,7b2 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 788:	f9478693          	addi	a3,a5,-108
 78c:	0016b693          	seqz	a3,a3
 790:	f9c60593          	addi	a1,a2,-100
 794:	e99d                	bnez	a1,7ca <vprintf+0xb8>
 796:	ca95                	beqz	a3,7ca <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 798:	008b8493          	addi	s1,s7,8
 79c:	4685                	li	a3,1
 79e:	4629                	li	a2,10
 7a0:	000ba583          	lw	a1,0(s7)
 7a4:	855a                	mv	a0,s6
 7a6:	ec9ff0ef          	jal	66e <printint>
        i += 1;
 7aa:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 7ac:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 7ae:	4981                	li	s3,0
 7b0:	b75d                	j	756 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 7b2:	008b8493          	addi	s1,s7,8
 7b6:	4685                	li	a3,1
 7b8:	4629                	li	a2,10
 7ba:	000ba583          	lw	a1,0(s7)
 7be:	855a                	mv	a0,s6
 7c0:	eafff0ef          	jal	66e <printint>
 7c4:	8ba6                	mv	s7,s1
      state = 0;
 7c6:	4981                	li	s3,0
 7c8:	b779                	j	756 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 7ca:	9752                	add	a4,a4,s4
 7cc:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 7d0:	f9460713          	addi	a4,a2,-108
 7d4:	00173713          	seqz	a4,a4
 7d8:	8f75                	and	a4,a4,a3
 7da:	f9c58513          	addi	a0,a1,-100
 7de:	16051963          	bnez	a0,950 <vprintf+0x23e>
 7e2:	16070763          	beqz	a4,950 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 7e6:	008b8493          	addi	s1,s7,8
 7ea:	4685                	li	a3,1
 7ec:	4629                	li	a2,10
 7ee:	000ba583          	lw	a1,0(s7)
 7f2:	855a                	mv	a0,s6
 7f4:	e7bff0ef          	jal	66e <printint>
        i += 2;
 7f8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 7fa:	8ba6                	mv	s7,s1
      state = 0;
 7fc:	4981                	li	s3,0
        i += 2;
 7fe:	bfa1                	j	756 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 800:	008b8493          	addi	s1,s7,8
 804:	4681                	li	a3,0
 806:	4629                	li	a2,10
 808:	000ba583          	lw	a1,0(s7)
 80c:	855a                	mv	a0,s6
 80e:	e61ff0ef          	jal	66e <printint>
 812:	8ba6                	mv	s7,s1
      state = 0;
 814:	4981                	li	s3,0
 816:	b781                	j	756 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 818:	008b8493          	addi	s1,s7,8
 81c:	4681                	li	a3,0
 81e:	4629                	li	a2,10
 820:	000ba583          	lw	a1,0(s7)
 824:	855a                	mv	a0,s6
 826:	e49ff0ef          	jal	66e <printint>
        i += 1;
 82a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 82c:	8ba6                	mv	s7,s1
      state = 0;
 82e:	4981                	li	s3,0
 830:	b71d                	j	756 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 832:	008b8493          	addi	s1,s7,8
 836:	4681                	li	a3,0
 838:	4629                	li	a2,10
 83a:	000ba583          	lw	a1,0(s7)
 83e:	855a                	mv	a0,s6
 840:	e2fff0ef          	jal	66e <printint>
        i += 2;
 844:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 846:	8ba6                	mv	s7,s1
      state = 0;
 848:	4981                	li	s3,0
        i += 2;
 84a:	b731                	j	756 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 84c:	008b8493          	addi	s1,s7,8
 850:	4681                	li	a3,0
 852:	4641                	li	a2,16
 854:	000ba583          	lw	a1,0(s7)
 858:	855a                	mv	a0,s6
 85a:	e15ff0ef          	jal	66e <printint>
 85e:	8ba6                	mv	s7,s1
      state = 0;
 860:	4981                	li	s3,0
 862:	bdd5                	j	756 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 864:	008b8493          	addi	s1,s7,8
 868:	4681                	li	a3,0
 86a:	4641                	li	a2,16
 86c:	000ba583          	lw	a1,0(s7)
 870:	855a                	mv	a0,s6
 872:	dfdff0ef          	jal	66e <printint>
        i += 1;
 876:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 878:	8ba6                	mv	s7,s1
      state = 0;
 87a:	4981                	li	s3,0
 87c:	bde9                	j	756 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 87e:	008b8493          	addi	s1,s7,8
 882:	4681                	li	a3,0
 884:	4641                	li	a2,16
 886:	000ba583          	lw	a1,0(s7)
 88a:	855a                	mv	a0,s6
 88c:	de3ff0ef          	jal	66e <printint>
        i += 2;
 890:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 892:	8ba6                	mv	s7,s1
      state = 0;
 894:	4981                	li	s3,0
        i += 2;
 896:	b5c1                	j	756 <vprintf+0x44>
 898:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 89a:	008b8793          	addi	a5,s7,8
 89e:	8cbe                	mv	s9,a5
 8a0:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 8a4:	03000593          	li	a1,48
 8a8:	855a                	mv	a0,s6
 8aa:	da7ff0ef          	jal	650 <putc>
  putc(fd, 'x');
 8ae:	07800593          	li	a1,120
 8b2:	855a                	mv	a0,s6
 8b4:	d9dff0ef          	jal	650 <putc>
 8b8:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 8ba:	00000b97          	auipc	s7,0x0
 8be:	486b8b93          	addi	s7,s7,1158 # d40 <digits>
 8c2:	03c9d793          	srli	a5,s3,0x3c
 8c6:	97de                	add	a5,a5,s7
 8c8:	0007c583          	lbu	a1,0(a5)
 8cc:	855a                	mv	a0,s6
 8ce:	d83ff0ef          	jal	650 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 8d2:	0992                	slli	s3,s3,0x4
 8d4:	34fd                	addiw	s1,s1,-1
 8d6:	f4f5                	bnez	s1,8c2 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 8d8:	8be6                	mv	s7,s9
      state = 0;
 8da:	4981                	li	s3,0
 8dc:	6ca2                	ld	s9,8(sp)
 8de:	bda5                	j	756 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 8e0:	008b8993          	addi	s3,s7,8
 8e4:	000bb483          	ld	s1,0(s7)
 8e8:	cc91                	beqz	s1,904 <vprintf+0x1f2>
        for(; *s; s++)
 8ea:	0004c583          	lbu	a1,0(s1)
 8ee:	c985                	beqz	a1,91e <vprintf+0x20c>
          putc(fd, *s);
 8f0:	855a                	mv	a0,s6
 8f2:	d5fff0ef          	jal	650 <putc>
        for(; *s; s++)
 8f6:	0485                	addi	s1,s1,1
 8f8:	0004c583          	lbu	a1,0(s1)
 8fc:	f9f5                	bnez	a1,8f0 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 8fe:	8bce                	mv	s7,s3
      state = 0;
 900:	4981                	li	s3,0
 902:	bd91                	j	756 <vprintf+0x44>
          s = "(null)";
 904:	00000497          	auipc	s1,0x0
 908:	43448493          	addi	s1,s1,1076 # d38 <malloc+0x2a0>
        for(; *s; s++)
 90c:	02800593          	li	a1,40
 910:	b7c5                	j	8f0 <vprintf+0x1de>
        putc(fd, '%');
 912:	85be                	mv	a1,a5
 914:	855a                	mv	a0,s6
 916:	d3bff0ef          	jal	650 <putc>
      state = 0;
 91a:	4981                	li	s3,0
 91c:	bd2d                	j	756 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 91e:	8bce                	mv	s7,s3
      state = 0;
 920:	4981                	li	s3,0
 922:	bd15                	j	756 <vprintf+0x44>
 924:	6906                	ld	s2,64(sp)
 926:	79e2                	ld	s3,56(sp)
 928:	7a42                	ld	s4,48(sp)
 92a:	7aa2                	ld	s5,40(sp)
 92c:	7b02                	ld	s6,32(sp)
 92e:	6be2                	ld	s7,24(sp)
 930:	6c42                	ld	s8,16(sp)
    }
  }
}
 932:	60e6                	ld	ra,88(sp)
 934:	6446                	ld	s0,80(sp)
 936:	64a6                	ld	s1,72(sp)
 938:	6125                	addi	sp,sp,96
 93a:	8082                	ret
      if(c0 == 'd'){
 93c:	06400713          	li	a4,100
 940:	e6e789e3          	beq	a5,a4,7b2 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 944:	f9478693          	addi	a3,a5,-108
 948:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 94c:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 94e:	4701                	li	a4,0
      } else if(c0 == 'u'){
 950:	07500513          	li	a0,117
 954:	eaa786e3          	beq	a5,a0,800 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 958:	f8b60513          	addi	a0,a2,-117
 95c:	e119                	bnez	a0,962 <vprintf+0x250>
 95e:	ea069de3          	bnez	a3,818 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 962:	f8b58513          	addi	a0,a1,-117
 966:	e119                	bnez	a0,96c <vprintf+0x25a>
 968:	ec0715e3          	bnez	a4,832 <vprintf+0x120>
      } else if(c0 == 'x'){
 96c:	07800513          	li	a0,120
 970:	eca78ee3          	beq	a5,a0,84c <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 974:	f8860613          	addi	a2,a2,-120
 978:	e219                	bnez	a2,97e <vprintf+0x26c>
 97a:	ee0695e3          	bnez	a3,864 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 97e:	f8858593          	addi	a1,a1,-120
 982:	e199                	bnez	a1,988 <vprintf+0x276>
 984:	ee071de3          	bnez	a4,87e <vprintf+0x16c>
      } else if(c0 == 'p'){
 988:	07000713          	li	a4,112
 98c:	f0e786e3          	beq	a5,a4,898 <vprintf+0x186>
      } else if(c0 == 's'){
 990:	07300713          	li	a4,115
 994:	f4e786e3          	beq	a5,a4,8e0 <vprintf+0x1ce>
      } else if(c0 == '%'){
 998:	02500713          	li	a4,37
 99c:	f6e78be3          	beq	a5,a4,912 <vprintf+0x200>
        putc(fd, '%');
 9a0:	02500593          	li	a1,37
 9a4:	855a                	mv	a0,s6
 9a6:	cabff0ef          	jal	650 <putc>
        putc(fd, c0);
 9aa:	85a6                	mv	a1,s1
 9ac:	855a                	mv	a0,s6
 9ae:	ca3ff0ef          	jal	650 <putc>
      state = 0;
 9b2:	4981                	li	s3,0
 9b4:	b34d                	j	756 <vprintf+0x44>

00000000000009b6 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 9b6:	715d                	addi	sp,sp,-80
 9b8:	ec06                	sd	ra,24(sp)
 9ba:	e822                	sd	s0,16(sp)
 9bc:	1000                	addi	s0,sp,32
 9be:	e010                	sd	a2,0(s0)
 9c0:	e414                	sd	a3,8(s0)
 9c2:	e818                	sd	a4,16(s0)
 9c4:	ec1c                	sd	a5,24(s0)
 9c6:	03043023          	sd	a6,32(s0)
 9ca:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 9ce:	8622                	mv	a2,s0
 9d0:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 9d4:	d3fff0ef          	jal	712 <vprintf>
}
 9d8:	60e2                	ld	ra,24(sp)
 9da:	6442                	ld	s0,16(sp)
 9dc:	6161                	addi	sp,sp,80
 9de:	8082                	ret

00000000000009e0 <printf>:

void
printf(const char *fmt, ...)
{
 9e0:	711d                	addi	sp,sp,-96
 9e2:	ec06                	sd	ra,24(sp)
 9e4:	e822                	sd	s0,16(sp)
 9e6:	1000                	addi	s0,sp,32
 9e8:	e40c                	sd	a1,8(s0)
 9ea:	e810                	sd	a2,16(s0)
 9ec:	ec14                	sd	a3,24(s0)
 9ee:	f018                	sd	a4,32(s0)
 9f0:	f41c                	sd	a5,40(s0)
 9f2:	03043823          	sd	a6,48(s0)
 9f6:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 9fa:	00840613          	addi	a2,s0,8
 9fe:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 a02:	85aa                	mv	a1,a0
 a04:	4505                	li	a0,1
 a06:	d0dff0ef          	jal	712 <vprintf>
}
 a0a:	60e2                	ld	ra,24(sp)
 a0c:	6442                	ld	s0,16(sp)
 a0e:	6125                	addi	sp,sp,96
 a10:	8082                	ret

0000000000000a12 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 a12:	1141                	addi	sp,sp,-16
 a14:	e406                	sd	ra,8(sp)
 a16:	e022                	sd	s0,0(sp)
 a18:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 a1a:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a1e:	00000797          	auipc	a5,0x0
 a22:	5f27b783          	ld	a5,1522(a5) # 1010 <freep>
 a26:	a039                	j	a34 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a28:	6398                	ld	a4,0(a5)
 a2a:	00e7e463          	bltu	a5,a4,a32 <free+0x20>
 a2e:	00e6ea63          	bltu	a3,a4,a42 <free+0x30>
{
 a32:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a34:	fed7fae3          	bgeu	a5,a3,a28 <free+0x16>
 a38:	6398                	ld	a4,0(a5)
 a3a:	00e6e463          	bltu	a3,a4,a42 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a3e:	fee7eae3          	bltu	a5,a4,a32 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 a42:	ff852583          	lw	a1,-8(a0)
 a46:	6390                	ld	a2,0(a5)
 a48:	02059813          	slli	a6,a1,0x20
 a4c:	01c85713          	srli	a4,a6,0x1c
 a50:	9736                	add	a4,a4,a3
 a52:	02e60563          	beq	a2,a4,a7c <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 a56:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 a5a:	4790                	lw	a2,8(a5)
 a5c:	02061593          	slli	a1,a2,0x20
 a60:	01c5d713          	srli	a4,a1,0x1c
 a64:	973e                	add	a4,a4,a5
 a66:	02e68263          	beq	a3,a4,a8a <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 a6a:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 a6c:	00000717          	auipc	a4,0x0
 a70:	5af73223          	sd	a5,1444(a4) # 1010 <freep>
}
 a74:	60a2                	ld	ra,8(sp)
 a76:	6402                	ld	s0,0(sp)
 a78:	0141                	addi	sp,sp,16
 a7a:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 a7c:	4618                	lw	a4,8(a2)
 a7e:	9f2d                	addw	a4,a4,a1
 a80:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a84:	6398                	ld	a4,0(a5)
 a86:	6310                	ld	a2,0(a4)
 a88:	b7f9                	j	a56 <free+0x44>
    p->s.size += bp->s.size;
 a8a:	ff852703          	lw	a4,-8(a0)
 a8e:	9f31                	addw	a4,a4,a2
 a90:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 a92:	ff053683          	ld	a3,-16(a0)
 a96:	bfd1                	j	a6a <free+0x58>

0000000000000a98 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a98:	7139                	addi	sp,sp,-64
 a9a:	fc06                	sd	ra,56(sp)
 a9c:	f822                	sd	s0,48(sp)
 a9e:	f04a                	sd	s2,32(sp)
 aa0:	ec4e                	sd	s3,24(sp)
 aa2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 aa4:	02051993          	slli	s3,a0,0x20
 aa8:	0209d993          	srli	s3,s3,0x20
 aac:	09bd                	addi	s3,s3,15
 aae:	0049d993          	srli	s3,s3,0x4
 ab2:	2985                	addiw	s3,s3,1
 ab4:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 ab6:	00000517          	auipc	a0,0x0
 aba:	55a53503          	ld	a0,1370(a0) # 1010 <freep>
 abe:	c905                	beqz	a0,aee <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ac0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 ac2:	4798                	lw	a4,8(a5)
 ac4:	09377663          	bgeu	a4,s3,b50 <malloc+0xb8>
 ac8:	f426                	sd	s1,40(sp)
 aca:	e852                	sd	s4,16(sp)
 acc:	e456                	sd	s5,8(sp)
 ace:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 ad0:	8a4e                	mv	s4,s3
 ad2:	6705                	lui	a4,0x1
 ad4:	00e9f363          	bgeu	s3,a4,ada <malloc+0x42>
 ad8:	6a05                	lui	s4,0x1
 ada:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 ade:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 ae2:	00000497          	auipc	s1,0x0
 ae6:	52e48493          	addi	s1,s1,1326 # 1010 <freep>
  if(p == (char*)-1)
 aea:	5afd                	li	s5,-1
 aec:	a83d                	j	b2a <malloc+0x92>
 aee:	f426                	sd	s1,40(sp)
 af0:	e852                	sd	s4,16(sp)
 af2:	e456                	sd	s5,8(sp)
 af4:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 af6:	00000797          	auipc	a5,0x0
 afa:	52a78793          	addi	a5,a5,1322 # 1020 <base>
 afe:	00000717          	auipc	a4,0x0
 b02:	50f73923          	sd	a5,1298(a4) # 1010 <freep>
 b06:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 b08:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 b0c:	b7d1                	j	ad0 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 b0e:	6398                	ld	a4,0(a5)
 b10:	e118                	sd	a4,0(a0)
 b12:	a899                	j	b68 <malloc+0xd0>
  hp->s.size = nu;
 b14:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 b18:	0541                	addi	a0,a0,16
 b1a:	ef9ff0ef          	jal	a12 <free>
  return freep;
 b1e:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 b20:	c125                	beqz	a0,b80 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b22:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b24:	4798                	lw	a4,8(a5)
 b26:	03277163          	bgeu	a4,s2,b48 <malloc+0xb0>
    if(p == freep)
 b2a:	6098                	ld	a4,0(s1)
 b2c:	853e                	mv	a0,a5
 b2e:	fef71ae3          	bne	a4,a5,b22 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 b32:	8552                	mv	a0,s4
 b34:	acfff0ef          	jal	602 <sbrk>
  if(p == (char*)-1)
 b38:	fd551ee3          	bne	a0,s5,b14 <malloc+0x7c>
        return 0;
 b3c:	4501                	li	a0,0
 b3e:	74a2                	ld	s1,40(sp)
 b40:	6a42                	ld	s4,16(sp)
 b42:	6aa2                	ld	s5,8(sp)
 b44:	6b02                	ld	s6,0(sp)
 b46:	a03d                	j	b74 <malloc+0xdc>
 b48:	74a2                	ld	s1,40(sp)
 b4a:	6a42                	ld	s4,16(sp)
 b4c:	6aa2                	ld	s5,8(sp)
 b4e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 b50:	fae90fe3          	beq	s2,a4,b0e <malloc+0x76>
        p->s.size -= nunits;
 b54:	4137073b          	subw	a4,a4,s3
 b58:	c798                	sw	a4,8(a5)
        p += p->s.size;
 b5a:	02071693          	slli	a3,a4,0x20
 b5e:	01c6d713          	srli	a4,a3,0x1c
 b62:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 b64:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 b68:	00000717          	auipc	a4,0x0
 b6c:	4aa73423          	sd	a0,1192(a4) # 1010 <freep>
      return (void*)(p + 1);
 b70:	01078513          	addi	a0,a5,16
  }
}
 b74:	70e2                	ld	ra,56(sp)
 b76:	7442                	ld	s0,48(sp)
 b78:	7902                	ld	s2,32(sp)
 b7a:	69e2                	ld	s3,24(sp)
 b7c:	6121                	addi	sp,sp,64
 b7e:	8082                	ret
 b80:	74a2                	ld	s1,40(sp)
 b82:	6a42                	ld	s4,16(sp)
 b84:	6aa2                	ld	s5,8(sp)
 b86:	6b02                	ld	s6,0(sp)
 b88:	b7f5                	j	b74 <malloc+0xdc>
