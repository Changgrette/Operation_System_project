
user/_cowtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <simpletest>:
// allocate more than half of physical memory,
// then fork. this will fail in the default
// kernel, which does not support copy-on-write.
void
simpletest()
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	1800                	addi	s0,sp,48
  uint64 phys_size = PHYSTOP - KERNBASE;
  int sz = (phys_size / 3) * 2;

  printf("simple: ");
   e:	00001517          	auipc	a0,0x1
  12:	ce250513          	addi	a0,a0,-798 # cf0 <malloc+0xf2>
  16:	331000ef          	jal	b46 <printf>
  
  char *p = sbrk(sz);
  1a:	05555537          	lui	a0,0x5555
  1e:	55450513          	addi	a0,a0,1364 # 5555554 <base+0x5550544>
  22:	77c000ef          	jal	79e <sbrk>
  if(p == (char*)0xffffffffffffffffL){
  26:	57fd                	li	a5,-1
  28:	04f50b63          	beq	a0,a5,7e <simpletest+0x7e>
  2c:	84aa                	mv	s1,a0
    printf("sbrk(%d) failed\n", sz);
    exit(-1);
  }

  for(char *q = p; q < p + sz; q += 4096){
  2e:	05556937          	lui	s2,0x5556
  32:	992a                	add	s2,s2,a0
  34:	6985                	lui	s3,0x1
    *(int*)q = getpid();
  36:	760000ef          	jal	796 <getpid>
  3a:	c088                	sw	a0,0(s1)
  for(char *q = p; q < p + sz; q += 4096){
  3c:	94ce                	add	s1,s1,s3
  3e:	fe991ce3          	bne	s2,s1,36 <simpletest+0x36>
  }

  int pid = fork();
  42:	6cc000ef          	jal	70e <fork>
  if(pid < 0){
  46:	04054963          	bltz	a0,98 <simpletest+0x98>
    printf("fork() failed\n");
    exit(-1);
  }

  if(pid == 0)
  4a:	c125                	beqz	a0,aa <simpletest+0xaa>
    exit(0);

  wait(0);
  4c:	4501                	li	a0,0
  4e:	6d0000ef          	jal	71e <wait>

  if(sbrk(-sz) == (char*)0xffffffffffffffffL){
  52:	faaab537          	lui	a0,0xfaaab
  56:	aac50513          	addi	a0,a0,-1364 # fffffffffaaaaaac <base+0xfffffffffaaa5a9c>
  5a:	744000ef          	jal	79e <sbrk>
  5e:	57fd                	li	a5,-1
  60:	04f50763          	beq	a0,a5,ae <simpletest+0xae>
    printf("sbrk(-%d) failed\n", sz);
    exit(-1);
  }

  printf("ok\n");
  64:	00001517          	auipc	a0,0x1
  68:	cdc50513          	addi	a0,a0,-804 # d40 <malloc+0x142>
  6c:	2db000ef          	jal	b46 <printf>
}
  70:	70a2                	ld	ra,40(sp)
  72:	7402                	ld	s0,32(sp)
  74:	64e2                	ld	s1,24(sp)
  76:	6942                	ld	s2,16(sp)
  78:	69a2                	ld	s3,8(sp)
  7a:	6145                	addi	sp,sp,48
  7c:	8082                	ret
    printf("sbrk(%d) failed\n", sz);
  7e:	055555b7          	lui	a1,0x5555
  82:	55458593          	addi	a1,a1,1364 # 5555554 <base+0x5550544>
  86:	00001517          	auipc	a0,0x1
  8a:	c7a50513          	addi	a0,a0,-902 # d00 <malloc+0x102>
  8e:	2b9000ef          	jal	b46 <printf>
    exit(-1);
  92:	557d                	li	a0,-1
  94:	682000ef          	jal	716 <exit>
    printf("fork() failed\n");
  98:	00001517          	auipc	a0,0x1
  9c:	c8050513          	addi	a0,a0,-896 # d18 <malloc+0x11a>
  a0:	2a7000ef          	jal	b46 <printf>
    exit(-1);
  a4:	557d                	li	a0,-1
  a6:	670000ef          	jal	716 <exit>
    exit(0);
  aa:	66c000ef          	jal	716 <exit>
    printf("sbrk(-%d) failed\n", sz);
  ae:	055555b7          	lui	a1,0x5555
  b2:	55458593          	addi	a1,a1,1364 # 5555554 <base+0x5550544>
  b6:	00001517          	auipc	a0,0x1
  ba:	c7250513          	addi	a0,a0,-910 # d28 <malloc+0x12a>
  be:	289000ef          	jal	b46 <printf>
    exit(-1);
  c2:	557d                	li	a0,-1
  c4:	652000ef          	jal	716 <exit>

00000000000000c8 <threetest>:
// this causes more than half of physical memory
// to be allocated, so it also checks whether
// copied pages are freed.
void
threetest()
{
  c8:	7179                	addi	sp,sp,-48
  ca:	f406                	sd	ra,40(sp)
  cc:	f022                	sd	s0,32(sp)
  ce:	ec26                	sd	s1,24(sp)
  d0:	e84a                	sd	s2,16(sp)
  d2:	e44e                	sd	s3,8(sp)
  d4:	e052                	sd	s4,0(sp)
  d6:	1800                	addi	s0,sp,48
  uint64 phys_size = PHYSTOP - KERNBASE;
  int sz = phys_size / 4;
  int pid1, pid2;

  printf("three: ");
  d8:	00001517          	auipc	a0,0x1
  dc:	c7050513          	addi	a0,a0,-912 # d48 <malloc+0x14a>
  e0:	267000ef          	jal	b46 <printf>
  
  char *p = sbrk(sz);
  e4:	02000537          	lui	a0,0x2000
  e8:	6b6000ef          	jal	79e <sbrk>
  ec:	84aa                	mv	s1,a0
  if(p == (char*)0xffffffffffffffffL){
  ee:	57fd                	li	a5,-1
  f0:	06f50863          	beq	a0,a5,160 <threetest+0x98>
    printf("sbrk(%d) failed\n", sz);
    exit(-1);
  }

  pid1 = fork();
  f4:	61a000ef          	jal	70e <fork>
  if(pid1 < 0){
  f8:	06054f63          	bltz	a0,176 <threetest+0xae>
    printf("fork failed\n");
    exit(-1);
  }
  if(pid1 == 0){
  fc:	c551                	beqz	a0,188 <threetest+0xc0>
      *(int*)q = 9999;
    }
    exit(0);
  }

  for(char *q = p; q < p + sz; q += 4096){
  fe:	020009b7          	lui	s3,0x2000
 102:	99a6                	add	s3,s3,s1
 104:	8926                	mv	s2,s1
 106:	6a05                	lui	s4,0x1
    *(int*)q = getpid();
 108:	68e000ef          	jal	796 <getpid>
 10c:	00a92023          	sw	a0,0(s2) # 5556000 <base+0x5550ff0>
  for(char *q = p; q < p + sz; q += 4096){
 110:	9952                	add	s2,s2,s4
 112:	ff391be3          	bne	s2,s3,108 <threetest+0x40>
  }

  wait(0);
 116:	4501                	li	a0,0
 118:	606000ef          	jal	71e <wait>

  sleep(1);
 11c:	4505                	li	a0,1
 11e:	688000ef          	jal	7a6 <sleep>

  for(char *q = p; q < p + sz; q += 4096){
 122:	6a05                	lui	s4,0x1
    if(*(int*)q != getpid()){
 124:	0004a903          	lw	s2,0(s1)
 128:	66e000ef          	jal	796 <getpid>
 12c:	0ca91c63          	bne	s2,a0,204 <threetest+0x13c>
  for(char *q = p; q < p + sz; q += 4096){
 130:	94d2                	add	s1,s1,s4
 132:	ff3499e3          	bne	s1,s3,124 <threetest+0x5c>
      printf("wrong content\n");
      exit(-1);
    }
  }

  if(sbrk(-sz) == (char*)0xffffffffffffffffL){
 136:	fe000537          	lui	a0,0xfe000
 13a:	664000ef          	jal	79e <sbrk>
 13e:	57fd                	li	a5,-1
 140:	0cf50b63          	beq	a0,a5,216 <threetest+0x14e>
    printf("sbrk(-%d) failed\n", sz);
    exit(-1);
  }

  printf("ok\n");
 144:	00001517          	auipc	a0,0x1
 148:	bfc50513          	addi	a0,a0,-1028 # d40 <malloc+0x142>
 14c:	1fb000ef          	jal	b46 <printf>
}
 150:	70a2                	ld	ra,40(sp)
 152:	7402                	ld	s0,32(sp)
 154:	64e2                	ld	s1,24(sp)
 156:	6942                	ld	s2,16(sp)
 158:	69a2                	ld	s3,8(sp)
 15a:	6a02                	ld	s4,0(sp)
 15c:	6145                	addi	sp,sp,48
 15e:	8082                	ret
    printf("sbrk(%d) failed\n", sz);
 160:	020005b7          	lui	a1,0x2000
 164:	00001517          	auipc	a0,0x1
 168:	b9c50513          	addi	a0,a0,-1124 # d00 <malloc+0x102>
 16c:	1db000ef          	jal	b46 <printf>
    exit(-1);
 170:	8526                	mv	a0,s1
 172:	5a4000ef          	jal	716 <exit>
    printf("fork failed\n");
 176:	00001517          	auipc	a0,0x1
 17a:	bda50513          	addi	a0,a0,-1062 # d50 <malloc+0x152>
 17e:	1c9000ef          	jal	b46 <printf>
    exit(-1);
 182:	557d                	li	a0,-1
 184:	592000ef          	jal	716 <exit>
    pid2 = fork();
 188:	586000ef          	jal	70e <fork>
    if(pid2 < 0){
 18c:	02054c63          	bltz	a0,1c4 <threetest+0xfc>
    if(pid2 == 0){
 190:	e139                	bnez	a0,1d6 <threetest+0x10e>
      for(char *q = p; q < p + (sz/5)*4; q += 4096){
 192:	0199a9b7          	lui	s3,0x199a
 196:	99a6                	add	s3,s3,s1
 198:	8926                	mv	s2,s1
 19a:	6a05                	lui	s4,0x1
        *(int*)q = getpid();
 19c:	5fa000ef          	jal	796 <getpid>
 1a0:	00a92023          	sw	a0,0(s2)
      for(char *q = p; q < p + (sz/5)*4; q += 4096){
 1a4:	9952                	add	s2,s2,s4
 1a6:	ff391be3          	bne	s2,s3,19c <threetest+0xd4>
      for(char *q = p; q < p + (sz/5)*4; q += 4096){
 1aa:	6a05                	lui	s4,0x1
        if(*(int*)q != getpid()){
 1ac:	0004a903          	lw	s2,0(s1)
 1b0:	5e6000ef          	jal	796 <getpid>
 1b4:	02a91f63          	bne	s2,a0,1f2 <threetest+0x12a>
      for(char *q = p; q < p + (sz/5)*4; q += 4096){
 1b8:	94d2                	add	s1,s1,s4
 1ba:	ff3499e3          	bne	s1,s3,1ac <threetest+0xe4>
      exit(-1);
 1be:	557d                	li	a0,-1
 1c0:	556000ef          	jal	716 <exit>
      printf("fork failed");
 1c4:	00001517          	auipc	a0,0x1
 1c8:	b9c50513          	addi	a0,a0,-1124 # d60 <malloc+0x162>
 1cc:	17b000ef          	jal	b46 <printf>
      exit(-1);
 1d0:	557d                	li	a0,-1
 1d2:	544000ef          	jal	716 <exit>
    for(char *q = p; q < p + (sz/2); q += 4096){
 1d6:	01000737          	lui	a4,0x1000
 1da:	9726                	add	a4,a4,s1
      *(int*)q = 9999;
 1dc:	6789                	lui	a5,0x2
 1de:	70f78793          	addi	a5,a5,1807 # 270f <buf+0x6ff>
    for(char *q = p; q < p + (sz/2); q += 4096){
 1e2:	6685                	lui	a3,0x1
      *(int*)q = 9999;
 1e4:	c09c                	sw	a5,0(s1)
    for(char *q = p; q < p + (sz/2); q += 4096){
 1e6:	94b6                	add	s1,s1,a3
 1e8:	fee49ee3          	bne	s1,a4,1e4 <threetest+0x11c>
    exit(0);
 1ec:	4501                	li	a0,0
 1ee:	528000ef          	jal	716 <exit>
          printf("wrong content\n");
 1f2:	00001517          	auipc	a0,0x1
 1f6:	b7e50513          	addi	a0,a0,-1154 # d70 <malloc+0x172>
 1fa:	14d000ef          	jal	b46 <printf>
          exit(-1);
 1fe:	557d                	li	a0,-1
 200:	516000ef          	jal	716 <exit>
      printf("wrong content\n");
 204:	00001517          	auipc	a0,0x1
 208:	b6c50513          	addi	a0,a0,-1172 # d70 <malloc+0x172>
 20c:	13b000ef          	jal	b46 <printf>
      exit(-1);
 210:	557d                	li	a0,-1
 212:	504000ef          	jal	716 <exit>
    printf("sbrk(-%d) failed\n", sz);
 216:	020005b7          	lui	a1,0x2000
 21a:	00001517          	auipc	a0,0x1
 21e:	b0e50513          	addi	a0,a0,-1266 # d28 <malloc+0x12a>
 222:	125000ef          	jal	b46 <printf>
    exit(-1);
 226:	557d                	li	a0,-1
 228:	4ee000ef          	jal	716 <exit>

000000000000022c <filetest>:
char junk3[4096];

// test whether copyout() simulates COW faults.
void
filetest()
{
 22c:	7139                	addi	sp,sp,-64
 22e:	fc06                	sd	ra,56(sp)
 230:	f822                	sd	s0,48(sp)
 232:	f426                	sd	s1,40(sp)
 234:	f04a                	sd	s2,32(sp)
 236:	ec4e                	sd	s3,24(sp)
 238:	e852                	sd	s4,16(sp)
 23a:	0080                	addi	s0,sp,64
  printf("file: ");
 23c:	00001517          	auipc	a0,0x1
 240:	b4450513          	addi	a0,a0,-1212 # d80 <malloc+0x182>
 244:	103000ef          	jal	b46 <printf>
  
  buf[0] = 99;
 248:	06300793          	li	a5,99
 24c:	00002717          	auipc	a4,0x2
 250:	dcf70223          	sb	a5,-572(a4) # 2010 <buf>

  for(int i = 0; i < 4; i++){
 254:	fc042423          	sw	zero,-56(s0)
    if(pipe(fds) != 0){
 258:	00001497          	auipc	s1,0x1
 25c:	da848493          	addi	s1,s1,-600 # 1000 <fds>
        printf("error: read the wrong value\n");
        exit(1);
      }
      exit(0);
    }
    if(write(fds[1], &i, sizeof(i)) != sizeof(i)){
 260:	fc840a13          	addi	s4,s0,-56
 264:	4911                	li	s2,4
  for(int i = 0; i < 4; i++){
 266:	498d                	li	s3,3
    if(pipe(fds) != 0){
 268:	8526                	mv	a0,s1
 26a:	4bc000ef          	jal	726 <pipe>
 26e:	e925                	bnez	a0,2de <filetest+0xb2>
    int pid = fork();
 270:	49e000ef          	jal	70e <fork>
    if(pid < 0){
 274:	06054e63          	bltz	a0,2f0 <filetest+0xc4>
    if(pid == 0){
 278:	c549                	beqz	a0,302 <filetest+0xd6>
    if(write(fds[1], &i, sizeof(i)) != sizeof(i)){
 27a:	864a                	mv	a2,s2
 27c:	85d2                	mv	a1,s4
 27e:	40c8                	lw	a0,4(s1)
 280:	4b6000ef          	jal	736 <write>
 284:	0f251063          	bne	a0,s2,364 <filetest+0x138>
  for(int i = 0; i < 4; i++){
 288:	fc842783          	lw	a5,-56(s0)
 28c:	2785                	addiw	a5,a5,1
 28e:	fcf42423          	sw	a5,-56(s0)
 292:	fcf9dbe3          	bge	s3,a5,268 <filetest+0x3c>
      printf("error: write failed\n");
      exit(-1);
    }
  }

  int xstatus = 0;
 296:	fc042623          	sw	zero,-52(s0)
 29a:	4491                	li	s1,4
  for(int i = 0; i < 4; i++) {
    wait(&xstatus);
 29c:	fcc40913          	addi	s2,s0,-52
 2a0:	854a                	mv	a0,s2
 2a2:	47c000ef          	jal	71e <wait>
    if(xstatus != 0) {
 2a6:	fcc42783          	lw	a5,-52(s0)
 2aa:	0c079663          	bnez	a5,376 <filetest+0x14a>
  for(int i = 0; i < 4; i++) {
 2ae:	34fd                	addiw	s1,s1,-1
 2b0:	f8e5                	bnez	s1,2a0 <filetest+0x74>
      exit(1);
    }
  }

  if(buf[0] != 99){
 2b2:	00002717          	auipc	a4,0x2
 2b6:	d5e74703          	lbu	a4,-674(a4) # 2010 <buf>
 2ba:	06300793          	li	a5,99
 2be:	0af71f63          	bne	a4,a5,37c <filetest+0x150>
    printf("error: child overwrote parent\n");
    exit(1);
  }

  printf("ok\n");
 2c2:	00001517          	auipc	a0,0x1
 2c6:	a7e50513          	addi	a0,a0,-1410 # d40 <malloc+0x142>
 2ca:	07d000ef          	jal	b46 <printf>
}
 2ce:	70e2                	ld	ra,56(sp)
 2d0:	7442                	ld	s0,48(sp)
 2d2:	74a2                	ld	s1,40(sp)
 2d4:	7902                	ld	s2,32(sp)
 2d6:	69e2                	ld	s3,24(sp)
 2d8:	6a42                	ld	s4,16(sp)
 2da:	6121                	addi	sp,sp,64
 2dc:	8082                	ret
      printf("pipe() failed\n");
 2de:	00001517          	auipc	a0,0x1
 2e2:	aaa50513          	addi	a0,a0,-1366 # d88 <malloc+0x18a>
 2e6:	061000ef          	jal	b46 <printf>
      exit(-1);
 2ea:	557d                	li	a0,-1
 2ec:	42a000ef          	jal	716 <exit>
      printf("fork failed\n");
 2f0:	00001517          	auipc	a0,0x1
 2f4:	a6050513          	addi	a0,a0,-1440 # d50 <malloc+0x152>
 2f8:	04f000ef          	jal	b46 <printf>
      exit(-1);
 2fc:	557d                	li	a0,-1
 2fe:	418000ef          	jal	716 <exit>
      sleep(1);
 302:	4505                	li	a0,1
 304:	4a2000ef          	jal	7a6 <sleep>
      if(read(fds[0], buf, sizeof(i)) != sizeof(i)){
 308:	4611                	li	a2,4
 30a:	00002597          	auipc	a1,0x2
 30e:	d0658593          	addi	a1,a1,-762 # 2010 <buf>
 312:	00001517          	auipc	a0,0x1
 316:	cee52503          	lw	a0,-786(a0) # 1000 <fds>
 31a:	414000ef          	jal	72e <read>
 31e:	4791                	li	a5,4
 320:	02f51663          	bne	a0,a5,34c <filetest+0x120>
      sleep(1);
 324:	4505                	li	a0,1
 326:	480000ef          	jal	7a6 <sleep>
      if(j != i){
 32a:	fc842703          	lw	a4,-56(s0)
 32e:	00002797          	auipc	a5,0x2
 332:	ce27a783          	lw	a5,-798(a5) # 2010 <buf>
 336:	02f70463          	beq	a4,a5,35e <filetest+0x132>
        printf("error: read the wrong value\n");
 33a:	00001517          	auipc	a0,0x1
 33e:	a7650513          	addi	a0,a0,-1418 # db0 <malloc+0x1b2>
 342:	005000ef          	jal	b46 <printf>
        exit(1);
 346:	4505                	li	a0,1
 348:	3ce000ef          	jal	716 <exit>
        printf("error: read failed\n");
 34c:	00001517          	auipc	a0,0x1
 350:	a4c50513          	addi	a0,a0,-1460 # d98 <malloc+0x19a>
 354:	7f2000ef          	jal	b46 <printf>
        exit(1);
 358:	4505                	li	a0,1
 35a:	3bc000ef          	jal	716 <exit>
      exit(0);
 35e:	4501                	li	a0,0
 360:	3b6000ef          	jal	716 <exit>
      printf("error: write failed\n");
 364:	00001517          	auipc	a0,0x1
 368:	a6c50513          	addi	a0,a0,-1428 # dd0 <malloc+0x1d2>
 36c:	7da000ef          	jal	b46 <printf>
      exit(-1);
 370:	557d                	li	a0,-1
 372:	3a4000ef          	jal	716 <exit>
      exit(1);
 376:	4505                	li	a0,1
 378:	39e000ef          	jal	716 <exit>
    printf("error: child overwrote parent\n");
 37c:	00001517          	auipc	a0,0x1
 380:	a6c50513          	addi	a0,a0,-1428 # de8 <malloc+0x1ea>
 384:	7c2000ef          	jal	b46 <printf>
    exit(1);
 388:	4505                	li	a0,1
 38a:	38c000ef          	jal	716 <exit>

000000000000038e <forkforktest>:
//
// try to expose races in page reference counting.
//
void
forkforktest()
{
 38e:	715d                	addi	sp,sp,-80
 390:	e486                	sd	ra,72(sp)
 392:	e0a2                	sd	s0,64(sp)
 394:	fc26                	sd	s1,56(sp)
 396:	f84a                	sd	s2,48(sp)
 398:	f44e                	sd	s3,40(sp)
 39a:	f052                	sd	s4,32(sp)
 39c:	ec56                	sd	s5,24(sp)
 39e:	0880                	addi	s0,sp,80
  printf("forkfork: ");
 3a0:	00001517          	auipc	a0,0x1
 3a4:	a6850513          	addi	a0,a0,-1432 # e08 <malloc+0x20a>
 3a8:	79e000ef          	jal	b46 <printf>

  int sz = 256 * 4096;
  char *p = sbrk(sz);
 3ac:	00100537          	lui	a0,0x100
 3b0:	3ee000ef          	jal	79e <sbrk>
 3b4:	8aaa                	mv	s5,a0
  memset(p, 27, sz);
 3b6:	00100637          	lui	a2,0x100
 3ba:	45ed                	li	a1,27
 3bc:	15c000ef          	jal	518 <memset>
 3c0:	06400993          	li	s3,100
{
 3c4:	4a0d                	li	s4,3
      }
    }

    for(int nc = 0; nc < children; nc++){
      int st;
      wait(&st);
 3c6:	fbc40913          	addi	s2,s0,-68
{
 3ca:	84d2                	mv	s1,s4
      if(fork() == 0){
 3cc:	342000ef          	jal	70e <fork>
 3d0:	cd39                	beqz	a0,42e <forkforktest+0xa0>
    for(int nc = 0; nc < children; nc++){
 3d2:	34fd                	addiw	s1,s1,-1
 3d4:	fce5                	bnez	s1,3cc <forkforktest+0x3e>
      wait(&st);
 3d6:	854a                	mv	a0,s2
 3d8:	346000ef          	jal	71e <wait>
 3dc:	854a                	mv	a0,s2
 3de:	340000ef          	jal	71e <wait>
 3e2:	854a                	mv	a0,s2
 3e4:	33a000ef          	jal	71e <wait>
  for(int iter = 0; iter < 100; iter++){
 3e8:	39fd                	addiw	s3,s3,-1 # 1999fff <base+0x1994fef>
 3ea:	fe0990e3          	bnez	s3,3ca <forkforktest+0x3c>
    }
  }

  sleep(5);
 3ee:	4515                	li	a0,5
 3f0:	3b6000ef          	jal	7a6 <sleep>
  for(int i = 0; i < sz; i += 4096){
 3f4:	87d6                	mv	a5,s5
 3f6:	00100737          	lui	a4,0x100
 3fa:	00ea86b3          	add	a3,s5,a4
    if(p[i] != 27){
 3fe:	45ed                	li	a1,27
  for(int i = 0; i < sz; i += 4096){
 400:	6605                	lui	a2,0x1
    if(p[i] != 27){
 402:	0007c703          	lbu	a4,0(a5)
 406:	02b71e63          	bne	a4,a1,442 <forkforktest+0xb4>
  for(int i = 0; i < sz; i += 4096){
 40a:	97b2                	add	a5,a5,a2
 40c:	fef69be3          	bne	a3,a5,402 <forkforktest+0x74>
      printf("error: parent's memory was modified!\n");
      exit(1);
    }
  }

  printf("ok\n");
 410:	00001517          	auipc	a0,0x1
 414:	93050513          	addi	a0,a0,-1744 # d40 <malloc+0x142>
 418:	72e000ef          	jal	b46 <printf>
}
 41c:	60a6                	ld	ra,72(sp)
 41e:	6406                	ld	s0,64(sp)
 420:	74e2                	ld	s1,56(sp)
 422:	7942                	ld	s2,48(sp)
 424:	79a2                	ld	s3,40(sp)
 426:	7a02                	ld	s4,32(sp)
 428:	6ae2                	ld	s5,24(sp)
 42a:	6161                	addi	sp,sp,80
 42c:	8082                	ret
        sleep(2);
 42e:	4509                	li	a0,2
 430:	376000ef          	jal	7a6 <sleep>
        fork();
 434:	2da000ef          	jal	70e <fork>
        fork();
 438:	2d6000ef          	jal	70e <fork>
        exit(0);
 43c:	4501                	li	a0,0
 43e:	2d8000ef          	jal	716 <exit>
      printf("error: parent's memory was modified!\n");
 442:	00001517          	auipc	a0,0x1
 446:	9d650513          	addi	a0,a0,-1578 # e18 <malloc+0x21a>
 44a:	6fc000ef          	jal	b46 <printf>
      exit(1);
 44e:	4505                	li	a0,1
 450:	2c6000ef          	jal	716 <exit>

0000000000000454 <main>:

int
main(int argc, char *argv[])
{
 454:	1141                	addi	sp,sp,-16
 456:	e406                	sd	ra,8(sp)
 458:	e022                	sd	s0,0(sp)
 45a:	0800                	addi	s0,sp,16
  simpletest();
 45c:	ba5ff0ef          	jal	0 <simpletest>

  // check that the first simpletest() freed the physical memory.
  simpletest();
 460:	ba1ff0ef          	jal	0 <simpletest>

  threetest();
 464:	c65ff0ef          	jal	c8 <threetest>
  threetest();
 468:	c61ff0ef          	jal	c8 <threetest>
  threetest();
 46c:	c5dff0ef          	jal	c8 <threetest>

  filetest();
 470:	dbdff0ef          	jal	22c <filetest>

  forkforktest();
 474:	f1bff0ef          	jal	38e <forkforktest>

  printf("ALL COW TESTS PASSED\n");
 478:	00001517          	auipc	a0,0x1
 47c:	9c850513          	addi	a0,a0,-1592 # e40 <malloc+0x242>
 480:	6c6000ef          	jal	b46 <printf>

  exit(0);
 484:	4501                	li	a0,0
 486:	290000ef          	jal	716 <exit>

000000000000048a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 48a:	1141                	addi	sp,sp,-16
 48c:	e406                	sd	ra,8(sp)
 48e:	e022                	sd	s0,0(sp)
 490:	0800                	addi	s0,sp,16
  extern int main();
  main();
 492:	fc3ff0ef          	jal	454 <main>
  exit(0);
 496:	4501                	li	a0,0
 498:	27e000ef          	jal	716 <exit>

000000000000049c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 49c:	1141                	addi	sp,sp,-16
 49e:	e406                	sd	ra,8(sp)
 4a0:	e022                	sd	s0,0(sp)
 4a2:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 4a4:	87aa                	mv	a5,a0
 4a6:	0585                	addi	a1,a1,1
 4a8:	0785                	addi	a5,a5,1
 4aa:	fff5c703          	lbu	a4,-1(a1)
 4ae:	fee78fa3          	sb	a4,-1(a5)
 4b2:	fb75                	bnez	a4,4a6 <strcpy+0xa>
    ;
  return os;
}
 4b4:	60a2                	ld	ra,8(sp)
 4b6:	6402                	ld	s0,0(sp)
 4b8:	0141                	addi	sp,sp,16
 4ba:	8082                	ret

00000000000004bc <strcmp>:

int
strcmp(const char *p, const char *q)
{
 4bc:	1141                	addi	sp,sp,-16
 4be:	e406                	sd	ra,8(sp)
 4c0:	e022                	sd	s0,0(sp)
 4c2:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 4c4:	00054783          	lbu	a5,0(a0)
 4c8:	cb91                	beqz	a5,4dc <strcmp+0x20>
 4ca:	0005c703          	lbu	a4,0(a1)
 4ce:	00f71763          	bne	a4,a5,4dc <strcmp+0x20>
    p++, q++;
 4d2:	0505                	addi	a0,a0,1
 4d4:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 4d6:	00054783          	lbu	a5,0(a0)
 4da:	fbe5                	bnez	a5,4ca <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 4dc:	0005c503          	lbu	a0,0(a1)
}
 4e0:	40a7853b          	subw	a0,a5,a0
 4e4:	60a2                	ld	ra,8(sp)
 4e6:	6402                	ld	s0,0(sp)
 4e8:	0141                	addi	sp,sp,16
 4ea:	8082                	ret

00000000000004ec <strlen>:

uint
strlen(const char *s)
{
 4ec:	1141                	addi	sp,sp,-16
 4ee:	e406                	sd	ra,8(sp)
 4f0:	e022                	sd	s0,0(sp)
 4f2:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 4f4:	00054783          	lbu	a5,0(a0)
 4f8:	cf91                	beqz	a5,514 <strlen+0x28>
 4fa:	00150793          	addi	a5,a0,1
 4fe:	86be                	mv	a3,a5
 500:	0785                	addi	a5,a5,1
 502:	fff7c703          	lbu	a4,-1(a5)
 506:	ff65                	bnez	a4,4fe <strlen+0x12>
 508:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 50c:	60a2                	ld	ra,8(sp)
 50e:	6402                	ld	s0,0(sp)
 510:	0141                	addi	sp,sp,16
 512:	8082                	ret
  for(n = 0; s[n]; n++)
 514:	4501                	li	a0,0
 516:	bfdd                	j	50c <strlen+0x20>

0000000000000518 <memset>:

void*
memset(void *dst, int c, uint n)
{
 518:	1141                	addi	sp,sp,-16
 51a:	e406                	sd	ra,8(sp)
 51c:	e022                	sd	s0,0(sp)
 51e:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 520:	ca19                	beqz	a2,536 <memset+0x1e>
 522:	87aa                	mv	a5,a0
 524:	1602                	slli	a2,a2,0x20
 526:	9201                	srli	a2,a2,0x20
 528:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 52c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 530:	0785                	addi	a5,a5,1
 532:	fee79de3          	bne	a5,a4,52c <memset+0x14>
  }
  return dst;
}
 536:	60a2                	ld	ra,8(sp)
 538:	6402                	ld	s0,0(sp)
 53a:	0141                	addi	sp,sp,16
 53c:	8082                	ret

000000000000053e <strchr>:

char*
strchr(const char *s, char c)
{
 53e:	1141                	addi	sp,sp,-16
 540:	e406                	sd	ra,8(sp)
 542:	e022                	sd	s0,0(sp)
 544:	0800                	addi	s0,sp,16
  for(; *s; s++)
 546:	00054783          	lbu	a5,0(a0)
 54a:	cf81                	beqz	a5,562 <strchr+0x24>
    if(*s == c)
 54c:	00f58763          	beq	a1,a5,55a <strchr+0x1c>
  for(; *s; s++)
 550:	0505                	addi	a0,a0,1
 552:	00054783          	lbu	a5,0(a0)
 556:	fbfd                	bnez	a5,54c <strchr+0xe>
      return (char*)s;
  return 0;
 558:	4501                	li	a0,0
}
 55a:	60a2                	ld	ra,8(sp)
 55c:	6402                	ld	s0,0(sp)
 55e:	0141                	addi	sp,sp,16
 560:	8082                	ret
  return 0;
 562:	4501                	li	a0,0
 564:	bfdd                	j	55a <strchr+0x1c>

0000000000000566 <gets>:

char*
gets(char *buf, int max)
{
 566:	711d                	addi	sp,sp,-96
 568:	ec86                	sd	ra,88(sp)
 56a:	e8a2                	sd	s0,80(sp)
 56c:	e4a6                	sd	s1,72(sp)
 56e:	e0ca                	sd	s2,64(sp)
 570:	fc4e                	sd	s3,56(sp)
 572:	f852                	sd	s4,48(sp)
 574:	f456                	sd	s5,40(sp)
 576:	f05a                	sd	s6,32(sp)
 578:	ec5e                	sd	s7,24(sp)
 57a:	e862                	sd	s8,16(sp)
 57c:	1080                	addi	s0,sp,96
 57e:	8baa                	mv	s7,a0
 580:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 582:	892a                	mv	s2,a0
 584:	4481                	li	s1,0
    cc = read(0, &c, 1);
 586:	faf40b13          	addi	s6,s0,-81
 58a:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 58c:	8c26                	mv	s8,s1
 58e:	0014899b          	addiw	s3,s1,1
 592:	84ce                	mv	s1,s3
 594:	0349d463          	bge	s3,s4,5bc <gets+0x56>
    cc = read(0, &c, 1);
 598:	8656                	mv	a2,s5
 59a:	85da                	mv	a1,s6
 59c:	4501                	li	a0,0
 59e:	190000ef          	jal	72e <read>
    if(cc < 1)
 5a2:	00a05d63          	blez	a0,5bc <gets+0x56>
      break;
    buf[i++] = c;
 5a6:	faf44783          	lbu	a5,-81(s0)
 5aa:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 5ae:	0905                	addi	s2,s2,1
 5b0:	ff678713          	addi	a4,a5,-10
 5b4:	c319                	beqz	a4,5ba <gets+0x54>
 5b6:	17cd                	addi	a5,a5,-13
 5b8:	fbf1                	bnez	a5,58c <gets+0x26>
    buf[i++] = c;
 5ba:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 5bc:	9c5e                	add	s8,s8,s7
 5be:	000c0023          	sb	zero,0(s8)
  return buf;
}
 5c2:	855e                	mv	a0,s7
 5c4:	60e6                	ld	ra,88(sp)
 5c6:	6446                	ld	s0,80(sp)
 5c8:	64a6                	ld	s1,72(sp)
 5ca:	6906                	ld	s2,64(sp)
 5cc:	79e2                	ld	s3,56(sp)
 5ce:	7a42                	ld	s4,48(sp)
 5d0:	7aa2                	ld	s5,40(sp)
 5d2:	7b02                	ld	s6,32(sp)
 5d4:	6be2                	ld	s7,24(sp)
 5d6:	6c42                	ld	s8,16(sp)
 5d8:	6125                	addi	sp,sp,96
 5da:	8082                	ret

00000000000005dc <stat>:

int
stat(const char *n, struct stat *st)
{
 5dc:	1101                	addi	sp,sp,-32
 5de:	ec06                	sd	ra,24(sp)
 5e0:	e822                	sd	s0,16(sp)
 5e2:	e04a                	sd	s2,0(sp)
 5e4:	1000                	addi	s0,sp,32
 5e6:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 5e8:	4581                	li	a1,0
 5ea:	16c000ef          	jal	756 <open>
  if(fd < 0)
 5ee:	02054263          	bltz	a0,612 <stat+0x36>
 5f2:	e426                	sd	s1,8(sp)
 5f4:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 5f6:	85ca                	mv	a1,s2
 5f8:	176000ef          	jal	76e <fstat>
 5fc:	892a                	mv	s2,a0
  close(fd);
 5fe:	8526                	mv	a0,s1
 600:	13e000ef          	jal	73e <close>
  return r;
 604:	64a2                	ld	s1,8(sp)
}
 606:	854a                	mv	a0,s2
 608:	60e2                	ld	ra,24(sp)
 60a:	6442                	ld	s0,16(sp)
 60c:	6902                	ld	s2,0(sp)
 60e:	6105                	addi	sp,sp,32
 610:	8082                	ret
    return -1;
 612:	57fd                	li	a5,-1
 614:	893e                	mv	s2,a5
 616:	bfc5                	j	606 <stat+0x2a>

0000000000000618 <atoi>:

int
atoi(const char *s)
{
 618:	1141                	addi	sp,sp,-16
 61a:	e406                	sd	ra,8(sp)
 61c:	e022                	sd	s0,0(sp)
 61e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 620:	00054683          	lbu	a3,0(a0)
 624:	fd06879b          	addiw	a5,a3,-48 # fd0 <digits+0x170>
 628:	0ff7f793          	zext.b	a5,a5
 62c:	4625                	li	a2,9
 62e:	02f66963          	bltu	a2,a5,660 <atoi+0x48>
 632:	872a                	mv	a4,a0
  n = 0;
 634:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 636:	0705                	addi	a4,a4,1 # 100001 <base+0xfaff1>
 638:	0025179b          	slliw	a5,a0,0x2
 63c:	9fa9                	addw	a5,a5,a0
 63e:	0017979b          	slliw	a5,a5,0x1
 642:	9fb5                	addw	a5,a5,a3
 644:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 648:	00074683          	lbu	a3,0(a4)
 64c:	fd06879b          	addiw	a5,a3,-48
 650:	0ff7f793          	zext.b	a5,a5
 654:	fef671e3          	bgeu	a2,a5,636 <atoi+0x1e>
  return n;
}
 658:	60a2                	ld	ra,8(sp)
 65a:	6402                	ld	s0,0(sp)
 65c:	0141                	addi	sp,sp,16
 65e:	8082                	ret
  n = 0;
 660:	4501                	li	a0,0
 662:	bfdd                	j	658 <atoi+0x40>

0000000000000664 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 664:	1141                	addi	sp,sp,-16
 666:	e406                	sd	ra,8(sp)
 668:	e022                	sd	s0,0(sp)
 66a:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 66c:	02b57563          	bgeu	a0,a1,696 <memmove+0x32>
    while(n-- > 0)
 670:	00c05f63          	blez	a2,68e <memmove+0x2a>
 674:	1602                	slli	a2,a2,0x20
 676:	9201                	srli	a2,a2,0x20
 678:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 67c:	872a                	mv	a4,a0
      *dst++ = *src++;
 67e:	0585                	addi	a1,a1,1
 680:	0705                	addi	a4,a4,1
 682:	fff5c683          	lbu	a3,-1(a1)
 686:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 68a:	fee79ae3          	bne	a5,a4,67e <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 68e:	60a2                	ld	ra,8(sp)
 690:	6402                	ld	s0,0(sp)
 692:	0141                	addi	sp,sp,16
 694:	8082                	ret
    while(n-- > 0)
 696:	fec05ce3          	blez	a2,68e <memmove+0x2a>
    dst += n;
 69a:	00c50733          	add	a4,a0,a2
    src += n;
 69e:	95b2                	add	a1,a1,a2
 6a0:	fff6079b          	addiw	a5,a2,-1 # fff <digits+0x19f>
 6a4:	1782                	slli	a5,a5,0x20
 6a6:	9381                	srli	a5,a5,0x20
 6a8:	fff7c793          	not	a5,a5
 6ac:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 6ae:	15fd                	addi	a1,a1,-1
 6b0:	177d                	addi	a4,a4,-1
 6b2:	0005c683          	lbu	a3,0(a1)
 6b6:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 6ba:	fef71ae3          	bne	a4,a5,6ae <memmove+0x4a>
 6be:	bfc1                	j	68e <memmove+0x2a>

00000000000006c0 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 6c0:	1141                	addi	sp,sp,-16
 6c2:	e406                	sd	ra,8(sp)
 6c4:	e022                	sd	s0,0(sp)
 6c6:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 6c8:	c61d                	beqz	a2,6f6 <memcmp+0x36>
 6ca:	1602                	slli	a2,a2,0x20
 6cc:	9201                	srli	a2,a2,0x20
 6ce:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 6d2:	00054783          	lbu	a5,0(a0)
 6d6:	0005c703          	lbu	a4,0(a1)
 6da:	00e79863          	bne	a5,a4,6ea <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 6de:	0505                	addi	a0,a0,1
    p2++;
 6e0:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 6e2:	fed518e3          	bne	a0,a3,6d2 <memcmp+0x12>
  }
  return 0;
 6e6:	4501                	li	a0,0
 6e8:	a019                	j	6ee <memcmp+0x2e>
      return *p1 - *p2;
 6ea:	40e7853b          	subw	a0,a5,a4
}
 6ee:	60a2                	ld	ra,8(sp)
 6f0:	6402                	ld	s0,0(sp)
 6f2:	0141                	addi	sp,sp,16
 6f4:	8082                	ret
  return 0;
 6f6:	4501                	li	a0,0
 6f8:	bfdd                	j	6ee <memcmp+0x2e>

00000000000006fa <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 6fa:	1141                	addi	sp,sp,-16
 6fc:	e406                	sd	ra,8(sp)
 6fe:	e022                	sd	s0,0(sp)
 700:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 702:	f63ff0ef          	jal	664 <memmove>
}
 706:	60a2                	ld	ra,8(sp)
 708:	6402                	ld	s0,0(sp)
 70a:	0141                	addi	sp,sp,16
 70c:	8082                	ret

000000000000070e <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 70e:	4885                	li	a7,1
 ecall
 710:	00000073          	ecall
 ret
 714:	8082                	ret

0000000000000716 <exit>:
.global exit
exit:
 li a7, SYS_exit
 716:	4889                	li	a7,2
 ecall
 718:	00000073          	ecall
 ret
 71c:	8082                	ret

000000000000071e <wait>:
.global wait
wait:
 li a7, SYS_wait
 71e:	488d                	li	a7,3
 ecall
 720:	00000073          	ecall
 ret
 724:	8082                	ret

0000000000000726 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 726:	4891                	li	a7,4
 ecall
 728:	00000073          	ecall
 ret
 72c:	8082                	ret

000000000000072e <read>:
.global read
read:
 li a7, SYS_read
 72e:	4895                	li	a7,5
 ecall
 730:	00000073          	ecall
 ret
 734:	8082                	ret

0000000000000736 <write>:
.global write
write:
 li a7, SYS_write
 736:	48c1                	li	a7,16
 ecall
 738:	00000073          	ecall
 ret
 73c:	8082                	ret

000000000000073e <close>:
.global close
close:
 li a7, SYS_close
 73e:	48d5                	li	a7,21
 ecall
 740:	00000073          	ecall
 ret
 744:	8082                	ret

0000000000000746 <kill>:
.global kill
kill:
 li a7, SYS_kill
 746:	4899                	li	a7,6
 ecall
 748:	00000073          	ecall
 ret
 74c:	8082                	ret

000000000000074e <exec>:
.global exec
exec:
 li a7, SYS_exec
 74e:	489d                	li	a7,7
 ecall
 750:	00000073          	ecall
 ret
 754:	8082                	ret

0000000000000756 <open>:
.global open
open:
 li a7, SYS_open
 756:	48bd                	li	a7,15
 ecall
 758:	00000073          	ecall
 ret
 75c:	8082                	ret

000000000000075e <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 75e:	48c5                	li	a7,17
 ecall
 760:	00000073          	ecall
 ret
 764:	8082                	ret

0000000000000766 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 766:	48c9                	li	a7,18
 ecall
 768:	00000073          	ecall
 ret
 76c:	8082                	ret

000000000000076e <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 76e:	48a1                	li	a7,8
 ecall
 770:	00000073          	ecall
 ret
 774:	8082                	ret

0000000000000776 <link>:
.global link
link:
 li a7, SYS_link
 776:	48cd                	li	a7,19
 ecall
 778:	00000073          	ecall
 ret
 77c:	8082                	ret

000000000000077e <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 77e:	48d1                	li	a7,20
 ecall
 780:	00000073          	ecall
 ret
 784:	8082                	ret

0000000000000786 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 786:	48a5                	li	a7,9
 ecall
 788:	00000073          	ecall
 ret
 78c:	8082                	ret

000000000000078e <dup>:
.global dup
dup:
 li a7, SYS_dup
 78e:	48a9                	li	a7,10
 ecall
 790:	00000073          	ecall
 ret
 794:	8082                	ret

0000000000000796 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 796:	48ad                	li	a7,11
 ecall
 798:	00000073          	ecall
 ret
 79c:	8082                	ret

000000000000079e <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 79e:	48b1                	li	a7,12
 ecall
 7a0:	00000073          	ecall
 ret
 7a4:	8082                	ret

00000000000007a6 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 7a6:	48b5                	li	a7,13
 ecall
 7a8:	00000073          	ecall
 ret
 7ac:	8082                	ret

00000000000007ae <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 7ae:	48b9                	li	a7,14
 ecall
 7b0:	00000073          	ecall
 ret
 7b4:	8082                	ret

00000000000007b6 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 7b6:	1101                	addi	sp,sp,-32
 7b8:	ec06                	sd	ra,24(sp)
 7ba:	e822                	sd	s0,16(sp)
 7bc:	1000                	addi	s0,sp,32
 7be:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 7c2:	4605                	li	a2,1
 7c4:	fef40593          	addi	a1,s0,-17
 7c8:	f6fff0ef          	jal	736 <write>
}
 7cc:	60e2                	ld	ra,24(sp)
 7ce:	6442                	ld	s0,16(sp)
 7d0:	6105                	addi	sp,sp,32
 7d2:	8082                	ret

00000000000007d4 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 7d4:	7139                	addi	sp,sp,-64
 7d6:	fc06                	sd	ra,56(sp)
 7d8:	f822                	sd	s0,48(sp)
 7da:	f04a                	sd	s2,32(sp)
 7dc:	ec4e                	sd	s3,24(sp)
 7de:	0080                	addi	s0,sp,64
 7e0:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 7e2:	cac9                	beqz	a3,874 <printint+0xa0>
 7e4:	01f5d79b          	srliw	a5,a1,0x1f
 7e8:	c7d1                	beqz	a5,874 <printint+0xa0>
    neg = 1;
    x = -xx;
 7ea:	40b005bb          	negw	a1,a1
    neg = 1;
 7ee:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 7f0:	fc040993          	addi	s3,s0,-64
  neg = 0;
 7f4:	86ce                	mv	a3,s3
  i = 0;
 7f6:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 7f8:	00000817          	auipc	a6,0x0
 7fc:	66880813          	addi	a6,a6,1640 # e60 <digits>
 800:	88ba                	mv	a7,a4
 802:	0017051b          	addiw	a0,a4,1
 806:	872a                	mv	a4,a0
 808:	02c5f7bb          	remuw	a5,a1,a2
 80c:	1782                	slli	a5,a5,0x20
 80e:	9381                	srli	a5,a5,0x20
 810:	97c2                	add	a5,a5,a6
 812:	0007c783          	lbu	a5,0(a5)
 816:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 81a:	87ae                	mv	a5,a1
 81c:	02c5d5bb          	divuw	a1,a1,a2
 820:	0685                	addi	a3,a3,1
 822:	fcc7ffe3          	bgeu	a5,a2,800 <printint+0x2c>
  if(neg)
 826:	00030c63          	beqz	t1,83e <printint+0x6a>
    buf[i++] = '-';
 82a:	fd050793          	addi	a5,a0,-48
 82e:	00878533          	add	a0,a5,s0
 832:	02d00793          	li	a5,45
 836:	fef50823          	sb	a5,-16(a0)
 83a:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 83e:	02e05563          	blez	a4,868 <printint+0x94>
 842:	f426                	sd	s1,40(sp)
 844:	377d                	addiw	a4,a4,-1
 846:	00e984b3          	add	s1,s3,a4
 84a:	19fd                	addi	s3,s3,-1
 84c:	99ba                	add	s3,s3,a4
 84e:	1702                	slli	a4,a4,0x20
 850:	9301                	srli	a4,a4,0x20
 852:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 856:	0004c583          	lbu	a1,0(s1)
 85a:	854a                	mv	a0,s2
 85c:	f5bff0ef          	jal	7b6 <putc>
  while(--i >= 0)
 860:	14fd                	addi	s1,s1,-1
 862:	ff349ae3          	bne	s1,s3,856 <printint+0x82>
 866:	74a2                	ld	s1,40(sp)
}
 868:	70e2                	ld	ra,56(sp)
 86a:	7442                	ld	s0,48(sp)
 86c:	7902                	ld	s2,32(sp)
 86e:	69e2                	ld	s3,24(sp)
 870:	6121                	addi	sp,sp,64
 872:	8082                	ret
  neg = 0;
 874:	4301                	li	t1,0
 876:	bfad                	j	7f0 <printint+0x1c>

0000000000000878 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 878:	711d                	addi	sp,sp,-96
 87a:	ec86                	sd	ra,88(sp)
 87c:	e8a2                	sd	s0,80(sp)
 87e:	e4a6                	sd	s1,72(sp)
 880:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 882:	0005c483          	lbu	s1,0(a1)
 886:	20048963          	beqz	s1,a98 <vprintf+0x220>
 88a:	e0ca                	sd	s2,64(sp)
 88c:	fc4e                	sd	s3,56(sp)
 88e:	f852                	sd	s4,48(sp)
 890:	f456                	sd	s5,40(sp)
 892:	f05a                	sd	s6,32(sp)
 894:	ec5e                	sd	s7,24(sp)
 896:	e862                	sd	s8,16(sp)
 898:	8b2a                	mv	s6,a0
 89a:	8a2e                	mv	s4,a1
 89c:	8bb2                	mv	s7,a2
  state = 0;
 89e:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 8a0:	4901                	li	s2,0
 8a2:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 8a4:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 8a8:	06400c13          	li	s8,100
 8ac:	a00d                	j	8ce <vprintf+0x56>
        putc(fd, c0);
 8ae:	85a6                	mv	a1,s1
 8b0:	855a                	mv	a0,s6
 8b2:	f05ff0ef          	jal	7b6 <putc>
 8b6:	a019                	j	8bc <vprintf+0x44>
    } else if(state == '%'){
 8b8:	03598363          	beq	s3,s5,8de <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 8bc:	0019079b          	addiw	a5,s2,1
 8c0:	893e                	mv	s2,a5
 8c2:	873e                	mv	a4,a5
 8c4:	97d2                	add	a5,a5,s4
 8c6:	0007c483          	lbu	s1,0(a5)
 8ca:	1c048063          	beqz	s1,a8a <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 8ce:	0004879b          	sext.w	a5,s1
    if(state == 0){
 8d2:	fe0993e3          	bnez	s3,8b8 <vprintf+0x40>
      if(c0 == '%'){
 8d6:	fd579ce3          	bne	a5,s5,8ae <vprintf+0x36>
        state = '%';
 8da:	89be                	mv	s3,a5
 8dc:	b7c5                	j	8bc <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 8de:	00ea06b3          	add	a3,s4,a4
 8e2:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 8e6:	1a060e63          	beqz	a2,aa2 <vprintf+0x22a>
      if(c0 == 'd'){
 8ea:	03878763          	beq	a5,s8,918 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 8ee:	f9478693          	addi	a3,a5,-108
 8f2:	0016b693          	seqz	a3,a3
 8f6:	f9c60593          	addi	a1,a2,-100
 8fa:	e99d                	bnez	a1,930 <vprintf+0xb8>
 8fc:	ca95                	beqz	a3,930 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8fe:	008b8493          	addi	s1,s7,8
 902:	4685                	li	a3,1
 904:	4629                	li	a2,10
 906:	000ba583          	lw	a1,0(s7)
 90a:	855a                	mv	a0,s6
 90c:	ec9ff0ef          	jal	7d4 <printint>
        i += 1;
 910:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 912:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 914:	4981                	li	s3,0
 916:	b75d                	j	8bc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 918:	008b8493          	addi	s1,s7,8
 91c:	4685                	li	a3,1
 91e:	4629                	li	a2,10
 920:	000ba583          	lw	a1,0(s7)
 924:	855a                	mv	a0,s6
 926:	eafff0ef          	jal	7d4 <printint>
 92a:	8ba6                	mv	s7,s1
      state = 0;
 92c:	4981                	li	s3,0
 92e:	b779                	j	8bc <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 930:	9752                	add	a4,a4,s4
 932:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 936:	f9460713          	addi	a4,a2,-108
 93a:	00173713          	seqz	a4,a4
 93e:	8f75                	and	a4,a4,a3
 940:	f9c58513          	addi	a0,a1,-100
 944:	16051963          	bnez	a0,ab6 <vprintf+0x23e>
 948:	16070763          	beqz	a4,ab6 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 94c:	008b8493          	addi	s1,s7,8
 950:	4685                	li	a3,1
 952:	4629                	li	a2,10
 954:	000ba583          	lw	a1,0(s7)
 958:	855a                	mv	a0,s6
 95a:	e7bff0ef          	jal	7d4 <printint>
        i += 2;
 95e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 960:	8ba6                	mv	s7,s1
      state = 0;
 962:	4981                	li	s3,0
        i += 2;
 964:	bfa1                	j	8bc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 966:	008b8493          	addi	s1,s7,8
 96a:	4681                	li	a3,0
 96c:	4629                	li	a2,10
 96e:	000ba583          	lw	a1,0(s7)
 972:	855a                	mv	a0,s6
 974:	e61ff0ef          	jal	7d4 <printint>
 978:	8ba6                	mv	s7,s1
      state = 0;
 97a:	4981                	li	s3,0
 97c:	b781                	j	8bc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 97e:	008b8493          	addi	s1,s7,8
 982:	4681                	li	a3,0
 984:	4629                	li	a2,10
 986:	000ba583          	lw	a1,0(s7)
 98a:	855a                	mv	a0,s6
 98c:	e49ff0ef          	jal	7d4 <printint>
        i += 1;
 990:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 992:	8ba6                	mv	s7,s1
      state = 0;
 994:	4981                	li	s3,0
 996:	b71d                	j	8bc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 998:	008b8493          	addi	s1,s7,8
 99c:	4681                	li	a3,0
 99e:	4629                	li	a2,10
 9a0:	000ba583          	lw	a1,0(s7)
 9a4:	855a                	mv	a0,s6
 9a6:	e2fff0ef          	jal	7d4 <printint>
        i += 2;
 9aa:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 9ac:	8ba6                	mv	s7,s1
      state = 0;
 9ae:	4981                	li	s3,0
        i += 2;
 9b0:	b731                	j	8bc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 9b2:	008b8493          	addi	s1,s7,8
 9b6:	4681                	li	a3,0
 9b8:	4641                	li	a2,16
 9ba:	000ba583          	lw	a1,0(s7)
 9be:	855a                	mv	a0,s6
 9c0:	e15ff0ef          	jal	7d4 <printint>
 9c4:	8ba6                	mv	s7,s1
      state = 0;
 9c6:	4981                	li	s3,0
 9c8:	bdd5                	j	8bc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 9ca:	008b8493          	addi	s1,s7,8
 9ce:	4681                	li	a3,0
 9d0:	4641                	li	a2,16
 9d2:	000ba583          	lw	a1,0(s7)
 9d6:	855a                	mv	a0,s6
 9d8:	dfdff0ef          	jal	7d4 <printint>
        i += 1;
 9dc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 9de:	8ba6                	mv	s7,s1
      state = 0;
 9e0:	4981                	li	s3,0
 9e2:	bde9                	j	8bc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 9e4:	008b8493          	addi	s1,s7,8
 9e8:	4681                	li	a3,0
 9ea:	4641                	li	a2,16
 9ec:	000ba583          	lw	a1,0(s7)
 9f0:	855a                	mv	a0,s6
 9f2:	de3ff0ef          	jal	7d4 <printint>
        i += 2;
 9f6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 9f8:	8ba6                	mv	s7,s1
      state = 0;
 9fa:	4981                	li	s3,0
        i += 2;
 9fc:	b5c1                	j	8bc <vprintf+0x44>
 9fe:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 a00:	008b8793          	addi	a5,s7,8
 a04:	8cbe                	mv	s9,a5
 a06:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 a0a:	03000593          	li	a1,48
 a0e:	855a                	mv	a0,s6
 a10:	da7ff0ef          	jal	7b6 <putc>
  putc(fd, 'x');
 a14:	07800593          	li	a1,120
 a18:	855a                	mv	a0,s6
 a1a:	d9dff0ef          	jal	7b6 <putc>
 a1e:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a20:	00000b97          	auipc	s7,0x0
 a24:	440b8b93          	addi	s7,s7,1088 # e60 <digits>
 a28:	03c9d793          	srli	a5,s3,0x3c
 a2c:	97de                	add	a5,a5,s7
 a2e:	0007c583          	lbu	a1,0(a5)
 a32:	855a                	mv	a0,s6
 a34:	d83ff0ef          	jal	7b6 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 a38:	0992                	slli	s3,s3,0x4
 a3a:	34fd                	addiw	s1,s1,-1
 a3c:	f4f5                	bnez	s1,a28 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 a3e:	8be6                	mv	s7,s9
      state = 0;
 a40:	4981                	li	s3,0
 a42:	6ca2                	ld	s9,8(sp)
 a44:	bda5                	j	8bc <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 a46:	008b8993          	addi	s3,s7,8
 a4a:	000bb483          	ld	s1,0(s7)
 a4e:	cc91                	beqz	s1,a6a <vprintf+0x1f2>
        for(; *s; s++)
 a50:	0004c583          	lbu	a1,0(s1)
 a54:	c985                	beqz	a1,a84 <vprintf+0x20c>
          putc(fd, *s);
 a56:	855a                	mv	a0,s6
 a58:	d5fff0ef          	jal	7b6 <putc>
        for(; *s; s++)
 a5c:	0485                	addi	s1,s1,1
 a5e:	0004c583          	lbu	a1,0(s1)
 a62:	f9f5                	bnez	a1,a56 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 a64:	8bce                	mv	s7,s3
      state = 0;
 a66:	4981                	li	s3,0
 a68:	bd91                	j	8bc <vprintf+0x44>
          s = "(null)";
 a6a:	00000497          	auipc	s1,0x0
 a6e:	3ee48493          	addi	s1,s1,1006 # e58 <malloc+0x25a>
        for(; *s; s++)
 a72:	02800593          	li	a1,40
 a76:	b7c5                	j	a56 <vprintf+0x1de>
        putc(fd, '%');
 a78:	85be                	mv	a1,a5
 a7a:	855a                	mv	a0,s6
 a7c:	d3bff0ef          	jal	7b6 <putc>
      state = 0;
 a80:	4981                	li	s3,0
 a82:	bd2d                	j	8bc <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 a84:	8bce                	mv	s7,s3
      state = 0;
 a86:	4981                	li	s3,0
 a88:	bd15                	j	8bc <vprintf+0x44>
 a8a:	6906                	ld	s2,64(sp)
 a8c:	79e2                	ld	s3,56(sp)
 a8e:	7a42                	ld	s4,48(sp)
 a90:	7aa2                	ld	s5,40(sp)
 a92:	7b02                	ld	s6,32(sp)
 a94:	6be2                	ld	s7,24(sp)
 a96:	6c42                	ld	s8,16(sp)
    }
  }
}
 a98:	60e6                	ld	ra,88(sp)
 a9a:	6446                	ld	s0,80(sp)
 a9c:	64a6                	ld	s1,72(sp)
 a9e:	6125                	addi	sp,sp,96
 aa0:	8082                	ret
      if(c0 == 'd'){
 aa2:	06400713          	li	a4,100
 aa6:	e6e789e3          	beq	a5,a4,918 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 aaa:	f9478693          	addi	a3,a5,-108
 aae:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 ab2:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 ab4:	4701                	li	a4,0
      } else if(c0 == 'u'){
 ab6:	07500513          	li	a0,117
 aba:	eaa786e3          	beq	a5,a0,966 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 abe:	f8b60513          	addi	a0,a2,-117
 ac2:	e119                	bnez	a0,ac8 <vprintf+0x250>
 ac4:	ea069de3          	bnez	a3,97e <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 ac8:	f8b58513          	addi	a0,a1,-117
 acc:	e119                	bnez	a0,ad2 <vprintf+0x25a>
 ace:	ec0715e3          	bnez	a4,998 <vprintf+0x120>
      } else if(c0 == 'x'){
 ad2:	07800513          	li	a0,120
 ad6:	eca78ee3          	beq	a5,a0,9b2 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 ada:	f8860613          	addi	a2,a2,-120
 ade:	e219                	bnez	a2,ae4 <vprintf+0x26c>
 ae0:	ee0695e3          	bnez	a3,9ca <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 ae4:	f8858593          	addi	a1,a1,-120
 ae8:	e199                	bnez	a1,aee <vprintf+0x276>
 aea:	ee071de3          	bnez	a4,9e4 <vprintf+0x16c>
      } else if(c0 == 'p'){
 aee:	07000713          	li	a4,112
 af2:	f0e786e3          	beq	a5,a4,9fe <vprintf+0x186>
      } else if(c0 == 's'){
 af6:	07300713          	li	a4,115
 afa:	f4e786e3          	beq	a5,a4,a46 <vprintf+0x1ce>
      } else if(c0 == '%'){
 afe:	02500713          	li	a4,37
 b02:	f6e78be3          	beq	a5,a4,a78 <vprintf+0x200>
        putc(fd, '%');
 b06:	02500593          	li	a1,37
 b0a:	855a                	mv	a0,s6
 b0c:	cabff0ef          	jal	7b6 <putc>
        putc(fd, c0);
 b10:	85a6                	mv	a1,s1
 b12:	855a                	mv	a0,s6
 b14:	ca3ff0ef          	jal	7b6 <putc>
      state = 0;
 b18:	4981                	li	s3,0
 b1a:	b34d                	j	8bc <vprintf+0x44>

0000000000000b1c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 b1c:	715d                	addi	sp,sp,-80
 b1e:	ec06                	sd	ra,24(sp)
 b20:	e822                	sd	s0,16(sp)
 b22:	1000                	addi	s0,sp,32
 b24:	e010                	sd	a2,0(s0)
 b26:	e414                	sd	a3,8(s0)
 b28:	e818                	sd	a4,16(s0)
 b2a:	ec1c                	sd	a5,24(s0)
 b2c:	03043023          	sd	a6,32(s0)
 b30:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 b34:	8622                	mv	a2,s0
 b36:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 b3a:	d3fff0ef          	jal	878 <vprintf>
}
 b3e:	60e2                	ld	ra,24(sp)
 b40:	6442                	ld	s0,16(sp)
 b42:	6161                	addi	sp,sp,80
 b44:	8082                	ret

0000000000000b46 <printf>:

void
printf(const char *fmt, ...)
{
 b46:	711d                	addi	sp,sp,-96
 b48:	ec06                	sd	ra,24(sp)
 b4a:	e822                	sd	s0,16(sp)
 b4c:	1000                	addi	s0,sp,32
 b4e:	e40c                	sd	a1,8(s0)
 b50:	e810                	sd	a2,16(s0)
 b52:	ec14                	sd	a3,24(s0)
 b54:	f018                	sd	a4,32(s0)
 b56:	f41c                	sd	a5,40(s0)
 b58:	03043823          	sd	a6,48(s0)
 b5c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 b60:	00840613          	addi	a2,s0,8
 b64:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 b68:	85aa                	mv	a1,a0
 b6a:	4505                	li	a0,1
 b6c:	d0dff0ef          	jal	878 <vprintf>
}
 b70:	60e2                	ld	ra,24(sp)
 b72:	6442                	ld	s0,16(sp)
 b74:	6125                	addi	sp,sp,96
 b76:	8082                	ret

0000000000000b78 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 b78:	1141                	addi	sp,sp,-16
 b7a:	e406                	sd	ra,8(sp)
 b7c:	e022                	sd	s0,0(sp)
 b7e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 b80:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b84:	00000797          	auipc	a5,0x0
 b88:	4847b783          	ld	a5,1156(a5) # 1008 <freep>
 b8c:	a039                	j	b9a <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b8e:	6398                	ld	a4,0(a5)
 b90:	00e7e463          	bltu	a5,a4,b98 <free+0x20>
 b94:	00e6ea63          	bltu	a3,a4,ba8 <free+0x30>
{
 b98:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b9a:	fed7fae3          	bgeu	a5,a3,b8e <free+0x16>
 b9e:	6398                	ld	a4,0(a5)
 ba0:	00e6e463          	bltu	a3,a4,ba8 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ba4:	fee7eae3          	bltu	a5,a4,b98 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 ba8:	ff852583          	lw	a1,-8(a0)
 bac:	6390                	ld	a2,0(a5)
 bae:	02059813          	slli	a6,a1,0x20
 bb2:	01c85713          	srli	a4,a6,0x1c
 bb6:	9736                	add	a4,a4,a3
 bb8:	02e60563          	beq	a2,a4,be2 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 bbc:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 bc0:	4790                	lw	a2,8(a5)
 bc2:	02061593          	slli	a1,a2,0x20
 bc6:	01c5d713          	srli	a4,a1,0x1c
 bca:	973e                	add	a4,a4,a5
 bcc:	02e68263          	beq	a3,a4,bf0 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 bd0:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 bd2:	00000717          	auipc	a4,0x0
 bd6:	42f73b23          	sd	a5,1078(a4) # 1008 <freep>
}
 bda:	60a2                	ld	ra,8(sp)
 bdc:	6402                	ld	s0,0(sp)
 bde:	0141                	addi	sp,sp,16
 be0:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 be2:	4618                	lw	a4,8(a2)
 be4:	9f2d                	addw	a4,a4,a1
 be6:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 bea:	6398                	ld	a4,0(a5)
 bec:	6310                	ld	a2,0(a4)
 bee:	b7f9                	j	bbc <free+0x44>
    p->s.size += bp->s.size;
 bf0:	ff852703          	lw	a4,-8(a0)
 bf4:	9f31                	addw	a4,a4,a2
 bf6:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 bf8:	ff053683          	ld	a3,-16(a0)
 bfc:	bfd1                	j	bd0 <free+0x58>

0000000000000bfe <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 bfe:	7139                	addi	sp,sp,-64
 c00:	fc06                	sd	ra,56(sp)
 c02:	f822                	sd	s0,48(sp)
 c04:	f04a                	sd	s2,32(sp)
 c06:	ec4e                	sd	s3,24(sp)
 c08:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 c0a:	02051993          	slli	s3,a0,0x20
 c0e:	0209d993          	srli	s3,s3,0x20
 c12:	09bd                	addi	s3,s3,15
 c14:	0049d993          	srli	s3,s3,0x4
 c18:	2985                	addiw	s3,s3,1
 c1a:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 c1c:	00000517          	auipc	a0,0x0
 c20:	3ec53503          	ld	a0,1004(a0) # 1008 <freep>
 c24:	c905                	beqz	a0,c54 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c26:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 c28:	4798                	lw	a4,8(a5)
 c2a:	09377663          	bgeu	a4,s3,cb6 <malloc+0xb8>
 c2e:	f426                	sd	s1,40(sp)
 c30:	e852                	sd	s4,16(sp)
 c32:	e456                	sd	s5,8(sp)
 c34:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 c36:	8a4e                	mv	s4,s3
 c38:	6705                	lui	a4,0x1
 c3a:	00e9f363          	bgeu	s3,a4,c40 <malloc+0x42>
 c3e:	6a05                	lui	s4,0x1
 c40:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 c44:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 c48:	00000497          	auipc	s1,0x0
 c4c:	3c048493          	addi	s1,s1,960 # 1008 <freep>
  if(p == (char*)-1)
 c50:	5afd                	li	s5,-1
 c52:	a83d                	j	c90 <malloc+0x92>
 c54:	f426                	sd	s1,40(sp)
 c56:	e852                	sd	s4,16(sp)
 c58:	e456                	sd	s5,8(sp)
 c5a:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 c5c:	00004797          	auipc	a5,0x4
 c60:	3b478793          	addi	a5,a5,948 # 5010 <base>
 c64:	00000717          	auipc	a4,0x0
 c68:	3af73223          	sd	a5,932(a4) # 1008 <freep>
 c6c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 c6e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 c72:	b7d1                	j	c36 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 c74:	6398                	ld	a4,0(a5)
 c76:	e118                	sd	a4,0(a0)
 c78:	a899                	j	cce <malloc+0xd0>
  hp->s.size = nu;
 c7a:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 c7e:	0541                	addi	a0,a0,16
 c80:	ef9ff0ef          	jal	b78 <free>
  return freep;
 c84:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 c86:	c125                	beqz	a0,ce6 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c88:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 c8a:	4798                	lw	a4,8(a5)
 c8c:	03277163          	bgeu	a4,s2,cae <malloc+0xb0>
    if(p == freep)
 c90:	6098                	ld	a4,0(s1)
 c92:	853e                	mv	a0,a5
 c94:	fef71ae3          	bne	a4,a5,c88 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 c98:	8552                	mv	a0,s4
 c9a:	b05ff0ef          	jal	79e <sbrk>
  if(p == (char*)-1)
 c9e:	fd551ee3          	bne	a0,s5,c7a <malloc+0x7c>
        return 0;
 ca2:	4501                	li	a0,0
 ca4:	74a2                	ld	s1,40(sp)
 ca6:	6a42                	ld	s4,16(sp)
 ca8:	6aa2                	ld	s5,8(sp)
 caa:	6b02                	ld	s6,0(sp)
 cac:	a03d                	j	cda <malloc+0xdc>
 cae:	74a2                	ld	s1,40(sp)
 cb0:	6a42                	ld	s4,16(sp)
 cb2:	6aa2                	ld	s5,8(sp)
 cb4:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 cb6:	fae90fe3          	beq	s2,a4,c74 <malloc+0x76>
        p->s.size -= nunits;
 cba:	4137073b          	subw	a4,a4,s3
 cbe:	c798                	sw	a4,8(a5)
        p += p->s.size;
 cc0:	02071693          	slli	a3,a4,0x20
 cc4:	01c6d713          	srli	a4,a3,0x1c
 cc8:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 cca:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 cce:	00000717          	auipc	a4,0x0
 cd2:	32a73d23          	sd	a0,826(a4) # 1008 <freep>
      return (void*)(p + 1);
 cd6:	01078513          	addi	a0,a5,16
  }
}
 cda:	70e2                	ld	ra,56(sp)
 cdc:	7442                	ld	s0,48(sp)
 cde:	7902                	ld	s2,32(sp)
 ce0:	69e2                	ld	s3,24(sp)
 ce2:	6121                	addi	sp,sp,64
 ce4:	8082                	ret
 ce6:	74a2                	ld	s1,40(sp)
 ce8:	6a42                	ld	s4,16(sp)
 cea:	6aa2                	ld	s5,8(sp)
 cec:	6b02                	ld	s6,0(sp)
 cee:	b7f5                	j	cda <malloc+0xdc>
