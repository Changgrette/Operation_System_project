
user/_trace:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	712d                	addi	sp,sp,-288
   2:	ee06                	sd	ra,280(sp)
   4:	ea22                	sd	s0,272(sp)
   6:	e626                	sd	s1,264(sp)
   8:	e24a                	sd	s2,256(sp)
   a:	1200                	addi	s0,sp,288
   c:	84ae                	mv	s1,a1
  int i;
  char *nargv[MAXARG];

  if(argc < 3 || (argv[1][0] < '0' || argv[1][0] > '9')){
   e:	4789                	li	a5,2
  10:	00a7dd63          	bge	a5,a0,2a <main+0x2a>
  14:	892a                	mv	s2,a0
  16:	6588                	ld	a0,8(a1)
  18:	00054783          	lbu	a5,0(a0)
  1c:	fd07879b          	addiw	a5,a5,-48
  20:	0ff7f793          	zext.b	a5,a5
  24:	4725                	li	a4,9
  26:	00f77d63          	bgeu	a4,a5,40 <main+0x40>
    fprintf(2, "Usage: %s mask command\n", argv[0]);
  2a:	6090                	ld	a2,0(s1)
  2c:	00001597          	auipc	a1,0x1
  30:	8f458593          	addi	a1,a1,-1804 # 920 <malloc+0xf8>
  34:	4509                	li	a0,2
  36:	710000ef          	jal	746 <fprintf>
    exit(1);
  3a:	4505                	li	a0,1
  3c:	2fc000ef          	jal	338 <exit>
  }

  if (trace(atoi(argv[1])) < 0) {
  40:	1fa000ef          	jal	23a <atoi>
  44:	394000ef          	jal	3d8 <trace>
  48:	04054763          	bltz	a0,96 <main+0x96>
    fprintf(2, "%s: trace failed\n", argv[0]);
    exit(1);
  }
  
  for(i = 2; i < argc && i < MAXARG; i++){
  4c:	01048593          	addi	a1,s1,16
  50:	ee040713          	addi	a4,s0,-288
  54:	4689                	li	a3,2
    nargv[i-2] = argv[i];
  56:	619c                	ld	a5,0(a1)
  58:	e31c                	sd	a5,0(a4)
  for(i = 2; i < argc && i < MAXARG; i++){
  5a:	0016879b          	addiw	a5,a3,1
  5e:	86be                	mv	a3,a5
  60:	05a1                	addi	a1,a1,8
  62:	0721                	addi	a4,a4,8
  64:	0127d563          	bge	a5,s2,6e <main+0x6e>
  68:	0207a793          	slti	a5,a5,32
  6c:	f7ed                	bnez	a5,56 <main+0x56>
  }
  nargv[argc-2] = 0;
  6e:	3979                	addiw	s2,s2,-2
  70:	ee040593          	addi	a1,s0,-288
  74:	090e                	slli	s2,s2,0x3
  76:	992e                	add	s2,s2,a1
  78:	00093023          	sd	zero,0(s2)
  exec(nargv[0], nargv);
  7c:	ee043503          	ld	a0,-288(s0)
  80:	2f0000ef          	jal	370 <exec>
  printf("trace: exec failed\n");
  84:	00001517          	auipc	a0,0x1
  88:	8cc50513          	addi	a0,a0,-1844 # 950 <malloc+0x128>
  8c:	6e4000ef          	jal	770 <printf>
  exit(0);
  90:	4501                	li	a0,0
  92:	2a6000ef          	jal	338 <exit>
    fprintf(2, "%s: trace failed\n", argv[0]);
  96:	6090                	ld	a2,0(s1)
  98:	00001597          	auipc	a1,0x1
  9c:	8a058593          	addi	a1,a1,-1888 # 938 <malloc+0x110>
  a0:	4509                	li	a0,2
  a2:	6a4000ef          	jal	746 <fprintf>
    exit(1);
  a6:	4505                	li	a0,1
  a8:	290000ef          	jal	338 <exit>

00000000000000ac <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  ac:	1141                	addi	sp,sp,-16
  ae:	e406                	sd	ra,8(sp)
  b0:	e022                	sd	s0,0(sp)
  b2:	0800                	addi	s0,sp,16
  extern int main();
  main();
  b4:	f4dff0ef          	jal	0 <main>
  exit(0);
  b8:	4501                	li	a0,0
  ba:	27e000ef          	jal	338 <exit>

00000000000000be <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  be:	1141                	addi	sp,sp,-16
  c0:	e406                	sd	ra,8(sp)
  c2:	e022                	sd	s0,0(sp)
  c4:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  c6:	87aa                	mv	a5,a0
  c8:	0585                	addi	a1,a1,1
  ca:	0785                	addi	a5,a5,1
  cc:	fff5c703          	lbu	a4,-1(a1)
  d0:	fee78fa3          	sb	a4,-1(a5)
  d4:	fb75                	bnez	a4,c8 <strcpy+0xa>
    ;
  return os;
}
  d6:	60a2                	ld	ra,8(sp)
  d8:	6402                	ld	s0,0(sp)
  da:	0141                	addi	sp,sp,16
  dc:	8082                	ret

00000000000000de <strcmp>:

int
strcmp(const char *p, const char *q)
{
  de:	1141                	addi	sp,sp,-16
  e0:	e406                	sd	ra,8(sp)
  e2:	e022                	sd	s0,0(sp)
  e4:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  e6:	00054783          	lbu	a5,0(a0)
  ea:	cb91                	beqz	a5,fe <strcmp+0x20>
  ec:	0005c703          	lbu	a4,0(a1)
  f0:	00f71763          	bne	a4,a5,fe <strcmp+0x20>
    p++, q++;
  f4:	0505                	addi	a0,a0,1
  f6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  f8:	00054783          	lbu	a5,0(a0)
  fc:	fbe5                	bnez	a5,ec <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  fe:	0005c503          	lbu	a0,0(a1)
}
 102:	40a7853b          	subw	a0,a5,a0
 106:	60a2                	ld	ra,8(sp)
 108:	6402                	ld	s0,0(sp)
 10a:	0141                	addi	sp,sp,16
 10c:	8082                	ret

000000000000010e <strlen>:

uint
strlen(const char *s)
{
 10e:	1141                	addi	sp,sp,-16
 110:	e406                	sd	ra,8(sp)
 112:	e022                	sd	s0,0(sp)
 114:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 116:	00054783          	lbu	a5,0(a0)
 11a:	cf91                	beqz	a5,136 <strlen+0x28>
 11c:	00150793          	addi	a5,a0,1
 120:	86be                	mv	a3,a5
 122:	0785                	addi	a5,a5,1
 124:	fff7c703          	lbu	a4,-1(a5)
 128:	ff65                	bnez	a4,120 <strlen+0x12>
 12a:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 12e:	60a2                	ld	ra,8(sp)
 130:	6402                	ld	s0,0(sp)
 132:	0141                	addi	sp,sp,16
 134:	8082                	ret
  for(n = 0; s[n]; n++)
 136:	4501                	li	a0,0
 138:	bfdd                	j	12e <strlen+0x20>

000000000000013a <memset>:

void*
memset(void *dst, int c, uint n)
{
 13a:	1141                	addi	sp,sp,-16
 13c:	e406                	sd	ra,8(sp)
 13e:	e022                	sd	s0,0(sp)
 140:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 142:	ca19                	beqz	a2,158 <memset+0x1e>
 144:	87aa                	mv	a5,a0
 146:	1602                	slli	a2,a2,0x20
 148:	9201                	srli	a2,a2,0x20
 14a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 14e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 152:	0785                	addi	a5,a5,1
 154:	fee79de3          	bne	a5,a4,14e <memset+0x14>
  }
  return dst;
}
 158:	60a2                	ld	ra,8(sp)
 15a:	6402                	ld	s0,0(sp)
 15c:	0141                	addi	sp,sp,16
 15e:	8082                	ret

0000000000000160 <strchr>:

char*
strchr(const char *s, char c)
{
 160:	1141                	addi	sp,sp,-16
 162:	e406                	sd	ra,8(sp)
 164:	e022                	sd	s0,0(sp)
 166:	0800                	addi	s0,sp,16
  for(; *s; s++)
 168:	00054783          	lbu	a5,0(a0)
 16c:	cf81                	beqz	a5,184 <strchr+0x24>
    if(*s == c)
 16e:	00f58763          	beq	a1,a5,17c <strchr+0x1c>
  for(; *s; s++)
 172:	0505                	addi	a0,a0,1
 174:	00054783          	lbu	a5,0(a0)
 178:	fbfd                	bnez	a5,16e <strchr+0xe>
      return (char*)s;
  return 0;
 17a:	4501                	li	a0,0
}
 17c:	60a2                	ld	ra,8(sp)
 17e:	6402                	ld	s0,0(sp)
 180:	0141                	addi	sp,sp,16
 182:	8082                	ret
  return 0;
 184:	4501                	li	a0,0
 186:	bfdd                	j	17c <strchr+0x1c>

0000000000000188 <gets>:

char*
gets(char *buf, int max)
{
 188:	711d                	addi	sp,sp,-96
 18a:	ec86                	sd	ra,88(sp)
 18c:	e8a2                	sd	s0,80(sp)
 18e:	e4a6                	sd	s1,72(sp)
 190:	e0ca                	sd	s2,64(sp)
 192:	fc4e                	sd	s3,56(sp)
 194:	f852                	sd	s4,48(sp)
 196:	f456                	sd	s5,40(sp)
 198:	f05a                	sd	s6,32(sp)
 19a:	ec5e                	sd	s7,24(sp)
 19c:	e862                	sd	s8,16(sp)
 19e:	1080                	addi	s0,sp,96
 1a0:	8baa                	mv	s7,a0
 1a2:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1a4:	892a                	mv	s2,a0
 1a6:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1a8:	faf40b13          	addi	s6,s0,-81
 1ac:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1ae:	8c26                	mv	s8,s1
 1b0:	0014899b          	addiw	s3,s1,1
 1b4:	84ce                	mv	s1,s3
 1b6:	0349d463          	bge	s3,s4,1de <gets+0x56>
    cc = read(0, &c, 1);
 1ba:	8656                	mv	a2,s5
 1bc:	85da                	mv	a1,s6
 1be:	4501                	li	a0,0
 1c0:	190000ef          	jal	350 <read>
    if(cc < 1)
 1c4:	00a05d63          	blez	a0,1de <gets+0x56>
      break;
    buf[i++] = c;
 1c8:	faf44783          	lbu	a5,-81(s0)
 1cc:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 1d0:	0905                	addi	s2,s2,1
 1d2:	ff678713          	addi	a4,a5,-10
 1d6:	c319                	beqz	a4,1dc <gets+0x54>
 1d8:	17cd                	addi	a5,a5,-13
 1da:	fbf1                	bnez	a5,1ae <gets+0x26>
    buf[i++] = c;
 1dc:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1de:	9c5e                	add	s8,s8,s7
 1e0:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1e4:	855e                	mv	a0,s7
 1e6:	60e6                	ld	ra,88(sp)
 1e8:	6446                	ld	s0,80(sp)
 1ea:	64a6                	ld	s1,72(sp)
 1ec:	6906                	ld	s2,64(sp)
 1ee:	79e2                	ld	s3,56(sp)
 1f0:	7a42                	ld	s4,48(sp)
 1f2:	7aa2                	ld	s5,40(sp)
 1f4:	7b02                	ld	s6,32(sp)
 1f6:	6be2                	ld	s7,24(sp)
 1f8:	6c42                	ld	s8,16(sp)
 1fa:	6125                	addi	sp,sp,96
 1fc:	8082                	ret

00000000000001fe <stat>:

int
stat(const char *n, struct stat *st)
{
 1fe:	1101                	addi	sp,sp,-32
 200:	ec06                	sd	ra,24(sp)
 202:	e822                	sd	s0,16(sp)
 204:	e04a                	sd	s2,0(sp)
 206:	1000                	addi	s0,sp,32
 208:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 20a:	4581                	li	a1,0
 20c:	16c000ef          	jal	378 <open>
  if(fd < 0)
 210:	02054263          	bltz	a0,234 <stat+0x36>
 214:	e426                	sd	s1,8(sp)
 216:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 218:	85ca                	mv	a1,s2
 21a:	176000ef          	jal	390 <fstat>
 21e:	892a                	mv	s2,a0
  close(fd);
 220:	8526                	mv	a0,s1
 222:	13e000ef          	jal	360 <close>
  return r;
 226:	64a2                	ld	s1,8(sp)
}
 228:	854a                	mv	a0,s2
 22a:	60e2                	ld	ra,24(sp)
 22c:	6442                	ld	s0,16(sp)
 22e:	6902                	ld	s2,0(sp)
 230:	6105                	addi	sp,sp,32
 232:	8082                	ret
    return -1;
 234:	57fd                	li	a5,-1
 236:	893e                	mv	s2,a5
 238:	bfc5                	j	228 <stat+0x2a>

000000000000023a <atoi>:

int
atoi(const char *s)
{
 23a:	1141                	addi	sp,sp,-16
 23c:	e406                	sd	ra,8(sp)
 23e:	e022                	sd	s0,0(sp)
 240:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 242:	00054683          	lbu	a3,0(a0)
 246:	fd06879b          	addiw	a5,a3,-48
 24a:	0ff7f793          	zext.b	a5,a5
 24e:	4625                	li	a2,9
 250:	02f66963          	bltu	a2,a5,282 <atoi+0x48>
 254:	872a                	mv	a4,a0
  n = 0;
 256:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 258:	0705                	addi	a4,a4,1
 25a:	0025179b          	slliw	a5,a0,0x2
 25e:	9fa9                	addw	a5,a5,a0
 260:	0017979b          	slliw	a5,a5,0x1
 264:	9fb5                	addw	a5,a5,a3
 266:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 26a:	00074683          	lbu	a3,0(a4)
 26e:	fd06879b          	addiw	a5,a3,-48
 272:	0ff7f793          	zext.b	a5,a5
 276:	fef671e3          	bgeu	a2,a5,258 <atoi+0x1e>
  return n;
}
 27a:	60a2                	ld	ra,8(sp)
 27c:	6402                	ld	s0,0(sp)
 27e:	0141                	addi	sp,sp,16
 280:	8082                	ret
  n = 0;
 282:	4501                	li	a0,0
 284:	bfdd                	j	27a <atoi+0x40>

0000000000000286 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 286:	1141                	addi	sp,sp,-16
 288:	e406                	sd	ra,8(sp)
 28a:	e022                	sd	s0,0(sp)
 28c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 28e:	02b57563          	bgeu	a0,a1,2b8 <memmove+0x32>
    while(n-- > 0)
 292:	00c05f63          	blez	a2,2b0 <memmove+0x2a>
 296:	1602                	slli	a2,a2,0x20
 298:	9201                	srli	a2,a2,0x20
 29a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 29e:	872a                	mv	a4,a0
      *dst++ = *src++;
 2a0:	0585                	addi	a1,a1,1
 2a2:	0705                	addi	a4,a4,1
 2a4:	fff5c683          	lbu	a3,-1(a1)
 2a8:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2ac:	fee79ae3          	bne	a5,a4,2a0 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2b0:	60a2                	ld	ra,8(sp)
 2b2:	6402                	ld	s0,0(sp)
 2b4:	0141                	addi	sp,sp,16
 2b6:	8082                	ret
    while(n-- > 0)
 2b8:	fec05ce3          	blez	a2,2b0 <memmove+0x2a>
    dst += n;
 2bc:	00c50733          	add	a4,a0,a2
    src += n;
 2c0:	95b2                	add	a1,a1,a2
 2c2:	fff6079b          	addiw	a5,a2,-1
 2c6:	1782                	slli	a5,a5,0x20
 2c8:	9381                	srli	a5,a5,0x20
 2ca:	fff7c793          	not	a5,a5
 2ce:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2d0:	15fd                	addi	a1,a1,-1
 2d2:	177d                	addi	a4,a4,-1
 2d4:	0005c683          	lbu	a3,0(a1)
 2d8:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 2dc:	fef71ae3          	bne	a4,a5,2d0 <memmove+0x4a>
 2e0:	bfc1                	j	2b0 <memmove+0x2a>

00000000000002e2 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2e2:	1141                	addi	sp,sp,-16
 2e4:	e406                	sd	ra,8(sp)
 2e6:	e022                	sd	s0,0(sp)
 2e8:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 2ea:	c61d                	beqz	a2,318 <memcmp+0x36>
 2ec:	1602                	slli	a2,a2,0x20
 2ee:	9201                	srli	a2,a2,0x20
 2f0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 2f4:	00054783          	lbu	a5,0(a0)
 2f8:	0005c703          	lbu	a4,0(a1)
 2fc:	00e79863          	bne	a5,a4,30c <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 300:	0505                	addi	a0,a0,1
    p2++;
 302:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 304:	fed518e3          	bne	a0,a3,2f4 <memcmp+0x12>
  }
  return 0;
 308:	4501                	li	a0,0
 30a:	a019                	j	310 <memcmp+0x2e>
      return *p1 - *p2;
 30c:	40e7853b          	subw	a0,a5,a4
}
 310:	60a2                	ld	ra,8(sp)
 312:	6402                	ld	s0,0(sp)
 314:	0141                	addi	sp,sp,16
 316:	8082                	ret
  return 0;
 318:	4501                	li	a0,0
 31a:	bfdd                	j	310 <memcmp+0x2e>

000000000000031c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 31c:	1141                	addi	sp,sp,-16
 31e:	e406                	sd	ra,8(sp)
 320:	e022                	sd	s0,0(sp)
 322:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 324:	f63ff0ef          	jal	286 <memmove>
}
 328:	60a2                	ld	ra,8(sp)
 32a:	6402                	ld	s0,0(sp)
 32c:	0141                	addi	sp,sp,16
 32e:	8082                	ret

0000000000000330 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 330:	4885                	li	a7,1
 ecall
 332:	00000073          	ecall
 ret
 336:	8082                	ret

0000000000000338 <exit>:
.global exit
exit:
 li a7, SYS_exit
 338:	4889                	li	a7,2
 ecall
 33a:	00000073          	ecall
 ret
 33e:	8082                	ret

0000000000000340 <wait>:
.global wait
wait:
 li a7, SYS_wait
 340:	488d                	li	a7,3
 ecall
 342:	00000073          	ecall
 ret
 346:	8082                	ret

0000000000000348 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 348:	4891                	li	a7,4
 ecall
 34a:	00000073          	ecall
 ret
 34e:	8082                	ret

0000000000000350 <read>:
.global read
read:
 li a7, SYS_read
 350:	4895                	li	a7,5
 ecall
 352:	00000073          	ecall
 ret
 356:	8082                	ret

0000000000000358 <write>:
.global write
write:
 li a7, SYS_write
 358:	48c1                	li	a7,16
 ecall
 35a:	00000073          	ecall
 ret
 35e:	8082                	ret

0000000000000360 <close>:
.global close
close:
 li a7, SYS_close
 360:	48d5                	li	a7,21
 ecall
 362:	00000073          	ecall
 ret
 366:	8082                	ret

0000000000000368 <kill>:
.global kill
kill:
 li a7, SYS_kill
 368:	4899                	li	a7,6
 ecall
 36a:	00000073          	ecall
 ret
 36e:	8082                	ret

0000000000000370 <exec>:
.global exec
exec:
 li a7, SYS_exec
 370:	489d                	li	a7,7
 ecall
 372:	00000073          	ecall
 ret
 376:	8082                	ret

0000000000000378 <open>:
.global open
open:
 li a7, SYS_open
 378:	48bd                	li	a7,15
 ecall
 37a:	00000073          	ecall
 ret
 37e:	8082                	ret

0000000000000380 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 380:	48c5                	li	a7,17
 ecall
 382:	00000073          	ecall
 ret
 386:	8082                	ret

0000000000000388 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 388:	48c9                	li	a7,18
 ecall
 38a:	00000073          	ecall
 ret
 38e:	8082                	ret

0000000000000390 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 390:	48a1                	li	a7,8
 ecall
 392:	00000073          	ecall
 ret
 396:	8082                	ret

0000000000000398 <link>:
.global link
link:
 li a7, SYS_link
 398:	48cd                	li	a7,19
 ecall
 39a:	00000073          	ecall
 ret
 39e:	8082                	ret

00000000000003a0 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3a0:	48d1                	li	a7,20
 ecall
 3a2:	00000073          	ecall
 ret
 3a6:	8082                	ret

00000000000003a8 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3a8:	48a5                	li	a7,9
 ecall
 3aa:	00000073          	ecall
 ret
 3ae:	8082                	ret

00000000000003b0 <dup>:
.global dup
dup:
 li a7, SYS_dup
 3b0:	48a9                	li	a7,10
 ecall
 3b2:	00000073          	ecall
 ret
 3b6:	8082                	ret

00000000000003b8 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3b8:	48ad                	li	a7,11
 ecall
 3ba:	00000073          	ecall
 ret
 3be:	8082                	ret

00000000000003c0 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 3c0:	48b1                	li	a7,12
 ecall
 3c2:	00000073          	ecall
 ret
 3c6:	8082                	ret

00000000000003c8 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 3c8:	48b5                	li	a7,13
 ecall
 3ca:	00000073          	ecall
 ret
 3ce:	8082                	ret

00000000000003d0 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 3d0:	48b9                	li	a7,14
 ecall
 3d2:	00000073          	ecall
 ret
 3d6:	8082                	ret

00000000000003d8 <trace>:
.global trace
trace:
 li a7, SYS_trace
 3d8:	48d9                	li	a7,22
 ecall
 3da:	00000073          	ecall
 ret
 3de:	8082                	ret

00000000000003e0 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 3e0:	1101                	addi	sp,sp,-32
 3e2:	ec06                	sd	ra,24(sp)
 3e4:	e822                	sd	s0,16(sp)
 3e6:	1000                	addi	s0,sp,32
 3e8:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 3ec:	4605                	li	a2,1
 3ee:	fef40593          	addi	a1,s0,-17
 3f2:	f67ff0ef          	jal	358 <write>
}
 3f6:	60e2                	ld	ra,24(sp)
 3f8:	6442                	ld	s0,16(sp)
 3fa:	6105                	addi	sp,sp,32
 3fc:	8082                	ret

00000000000003fe <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 3fe:	7139                	addi	sp,sp,-64
 400:	fc06                	sd	ra,56(sp)
 402:	f822                	sd	s0,48(sp)
 404:	f04a                	sd	s2,32(sp)
 406:	ec4e                	sd	s3,24(sp)
 408:	0080                	addi	s0,sp,64
 40a:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 40c:	cac9                	beqz	a3,49e <printint+0xa0>
 40e:	01f5d79b          	srliw	a5,a1,0x1f
 412:	c7d1                	beqz	a5,49e <printint+0xa0>
    neg = 1;
    x = -xx;
 414:	40b005bb          	negw	a1,a1
    neg = 1;
 418:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 41a:	fc040993          	addi	s3,s0,-64
  neg = 0;
 41e:	86ce                	mv	a3,s3
  i = 0;
 420:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 422:	00000817          	auipc	a6,0x0
 426:	54e80813          	addi	a6,a6,1358 # 970 <digits>
 42a:	88ba                	mv	a7,a4
 42c:	0017051b          	addiw	a0,a4,1
 430:	872a                	mv	a4,a0
 432:	02c5f7bb          	remuw	a5,a1,a2
 436:	1782                	slli	a5,a5,0x20
 438:	9381                	srli	a5,a5,0x20
 43a:	97c2                	add	a5,a5,a6
 43c:	0007c783          	lbu	a5,0(a5)
 440:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 444:	87ae                	mv	a5,a1
 446:	02c5d5bb          	divuw	a1,a1,a2
 44a:	0685                	addi	a3,a3,1
 44c:	fcc7ffe3          	bgeu	a5,a2,42a <printint+0x2c>
  if(neg)
 450:	00030c63          	beqz	t1,468 <printint+0x6a>
    buf[i++] = '-';
 454:	fd050793          	addi	a5,a0,-48
 458:	00878533          	add	a0,a5,s0
 45c:	02d00793          	li	a5,45
 460:	fef50823          	sb	a5,-16(a0)
 464:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 468:	02e05563          	blez	a4,492 <printint+0x94>
 46c:	f426                	sd	s1,40(sp)
 46e:	377d                	addiw	a4,a4,-1
 470:	00e984b3          	add	s1,s3,a4
 474:	19fd                	addi	s3,s3,-1
 476:	99ba                	add	s3,s3,a4
 478:	1702                	slli	a4,a4,0x20
 47a:	9301                	srli	a4,a4,0x20
 47c:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 480:	0004c583          	lbu	a1,0(s1)
 484:	854a                	mv	a0,s2
 486:	f5bff0ef          	jal	3e0 <putc>
  while(--i >= 0)
 48a:	14fd                	addi	s1,s1,-1
 48c:	ff349ae3          	bne	s1,s3,480 <printint+0x82>
 490:	74a2                	ld	s1,40(sp)
}
 492:	70e2                	ld	ra,56(sp)
 494:	7442                	ld	s0,48(sp)
 496:	7902                	ld	s2,32(sp)
 498:	69e2                	ld	s3,24(sp)
 49a:	6121                	addi	sp,sp,64
 49c:	8082                	ret
  neg = 0;
 49e:	4301                	li	t1,0
 4a0:	bfad                	j	41a <printint+0x1c>

00000000000004a2 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4a2:	711d                	addi	sp,sp,-96
 4a4:	ec86                	sd	ra,88(sp)
 4a6:	e8a2                	sd	s0,80(sp)
 4a8:	e4a6                	sd	s1,72(sp)
 4aa:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 4ac:	0005c483          	lbu	s1,0(a1)
 4b0:	20048963          	beqz	s1,6c2 <vprintf+0x220>
 4b4:	e0ca                	sd	s2,64(sp)
 4b6:	fc4e                	sd	s3,56(sp)
 4b8:	f852                	sd	s4,48(sp)
 4ba:	f456                	sd	s5,40(sp)
 4bc:	f05a                	sd	s6,32(sp)
 4be:	ec5e                	sd	s7,24(sp)
 4c0:	e862                	sd	s8,16(sp)
 4c2:	8b2a                	mv	s6,a0
 4c4:	8a2e                	mv	s4,a1
 4c6:	8bb2                	mv	s7,a2
  state = 0;
 4c8:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 4ca:	4901                	li	s2,0
 4cc:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 4ce:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 4d2:	06400c13          	li	s8,100
 4d6:	a00d                	j	4f8 <vprintf+0x56>
        putc(fd, c0);
 4d8:	85a6                	mv	a1,s1
 4da:	855a                	mv	a0,s6
 4dc:	f05ff0ef          	jal	3e0 <putc>
 4e0:	a019                	j	4e6 <vprintf+0x44>
    } else if(state == '%'){
 4e2:	03598363          	beq	s3,s5,508 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 4e6:	0019079b          	addiw	a5,s2,1
 4ea:	893e                	mv	s2,a5
 4ec:	873e                	mv	a4,a5
 4ee:	97d2                	add	a5,a5,s4
 4f0:	0007c483          	lbu	s1,0(a5)
 4f4:	1c048063          	beqz	s1,6b4 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 4f8:	0004879b          	sext.w	a5,s1
    if(state == 0){
 4fc:	fe0993e3          	bnez	s3,4e2 <vprintf+0x40>
      if(c0 == '%'){
 500:	fd579ce3          	bne	a5,s5,4d8 <vprintf+0x36>
        state = '%';
 504:	89be                	mv	s3,a5
 506:	b7c5                	j	4e6 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 508:	00ea06b3          	add	a3,s4,a4
 50c:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 510:	1a060e63          	beqz	a2,6cc <vprintf+0x22a>
      if(c0 == 'd'){
 514:	03878763          	beq	a5,s8,542 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 518:	f9478693          	addi	a3,a5,-108
 51c:	0016b693          	seqz	a3,a3
 520:	f9c60593          	addi	a1,a2,-100
 524:	e99d                	bnez	a1,55a <vprintf+0xb8>
 526:	ca95                	beqz	a3,55a <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 528:	008b8493          	addi	s1,s7,8
 52c:	4685                	li	a3,1
 52e:	4629                	li	a2,10
 530:	000ba583          	lw	a1,0(s7)
 534:	855a                	mv	a0,s6
 536:	ec9ff0ef          	jal	3fe <printint>
        i += 1;
 53a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 53c:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 53e:	4981                	li	s3,0
 540:	b75d                	j	4e6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 542:	008b8493          	addi	s1,s7,8
 546:	4685                	li	a3,1
 548:	4629                	li	a2,10
 54a:	000ba583          	lw	a1,0(s7)
 54e:	855a                	mv	a0,s6
 550:	eafff0ef          	jal	3fe <printint>
 554:	8ba6                	mv	s7,s1
      state = 0;
 556:	4981                	li	s3,0
 558:	b779                	j	4e6 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 55a:	9752                	add	a4,a4,s4
 55c:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 560:	f9460713          	addi	a4,a2,-108
 564:	00173713          	seqz	a4,a4
 568:	8f75                	and	a4,a4,a3
 56a:	f9c58513          	addi	a0,a1,-100
 56e:	16051963          	bnez	a0,6e0 <vprintf+0x23e>
 572:	16070763          	beqz	a4,6e0 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 576:	008b8493          	addi	s1,s7,8
 57a:	4685                	li	a3,1
 57c:	4629                	li	a2,10
 57e:	000ba583          	lw	a1,0(s7)
 582:	855a                	mv	a0,s6
 584:	e7bff0ef          	jal	3fe <printint>
        i += 2;
 588:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 58a:	8ba6                	mv	s7,s1
      state = 0;
 58c:	4981                	li	s3,0
        i += 2;
 58e:	bfa1                	j	4e6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 590:	008b8493          	addi	s1,s7,8
 594:	4681                	li	a3,0
 596:	4629                	li	a2,10
 598:	000ba583          	lw	a1,0(s7)
 59c:	855a                	mv	a0,s6
 59e:	e61ff0ef          	jal	3fe <printint>
 5a2:	8ba6                	mv	s7,s1
      state = 0;
 5a4:	4981                	li	s3,0
 5a6:	b781                	j	4e6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5a8:	008b8493          	addi	s1,s7,8
 5ac:	4681                	li	a3,0
 5ae:	4629                	li	a2,10
 5b0:	000ba583          	lw	a1,0(s7)
 5b4:	855a                	mv	a0,s6
 5b6:	e49ff0ef          	jal	3fe <printint>
        i += 1;
 5ba:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5bc:	8ba6                	mv	s7,s1
      state = 0;
 5be:	4981                	li	s3,0
 5c0:	b71d                	j	4e6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5c2:	008b8493          	addi	s1,s7,8
 5c6:	4681                	li	a3,0
 5c8:	4629                	li	a2,10
 5ca:	000ba583          	lw	a1,0(s7)
 5ce:	855a                	mv	a0,s6
 5d0:	e2fff0ef          	jal	3fe <printint>
        i += 2;
 5d4:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5d6:	8ba6                	mv	s7,s1
      state = 0;
 5d8:	4981                	li	s3,0
        i += 2;
 5da:	b731                	j	4e6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 5dc:	008b8493          	addi	s1,s7,8
 5e0:	4681                	li	a3,0
 5e2:	4641                	li	a2,16
 5e4:	000ba583          	lw	a1,0(s7)
 5e8:	855a                	mv	a0,s6
 5ea:	e15ff0ef          	jal	3fe <printint>
 5ee:	8ba6                	mv	s7,s1
      state = 0;
 5f0:	4981                	li	s3,0
 5f2:	bdd5                	j	4e6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5f4:	008b8493          	addi	s1,s7,8
 5f8:	4681                	li	a3,0
 5fa:	4641                	li	a2,16
 5fc:	000ba583          	lw	a1,0(s7)
 600:	855a                	mv	a0,s6
 602:	dfdff0ef          	jal	3fe <printint>
        i += 1;
 606:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 608:	8ba6                	mv	s7,s1
      state = 0;
 60a:	4981                	li	s3,0
 60c:	bde9                	j	4e6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 60e:	008b8493          	addi	s1,s7,8
 612:	4681                	li	a3,0
 614:	4641                	li	a2,16
 616:	000ba583          	lw	a1,0(s7)
 61a:	855a                	mv	a0,s6
 61c:	de3ff0ef          	jal	3fe <printint>
        i += 2;
 620:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 622:	8ba6                	mv	s7,s1
      state = 0;
 624:	4981                	li	s3,0
        i += 2;
 626:	b5c1                	j	4e6 <vprintf+0x44>
 628:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 62a:	008b8793          	addi	a5,s7,8
 62e:	8cbe                	mv	s9,a5
 630:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 634:	03000593          	li	a1,48
 638:	855a                	mv	a0,s6
 63a:	da7ff0ef          	jal	3e0 <putc>
  putc(fd, 'x');
 63e:	07800593          	li	a1,120
 642:	855a                	mv	a0,s6
 644:	d9dff0ef          	jal	3e0 <putc>
 648:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 64a:	00000b97          	auipc	s7,0x0
 64e:	326b8b93          	addi	s7,s7,806 # 970 <digits>
 652:	03c9d793          	srli	a5,s3,0x3c
 656:	97de                	add	a5,a5,s7
 658:	0007c583          	lbu	a1,0(a5)
 65c:	855a                	mv	a0,s6
 65e:	d83ff0ef          	jal	3e0 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 662:	0992                	slli	s3,s3,0x4
 664:	34fd                	addiw	s1,s1,-1
 666:	f4f5                	bnez	s1,652 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 668:	8be6                	mv	s7,s9
      state = 0;
 66a:	4981                	li	s3,0
 66c:	6ca2                	ld	s9,8(sp)
 66e:	bda5                	j	4e6 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 670:	008b8993          	addi	s3,s7,8
 674:	000bb483          	ld	s1,0(s7)
 678:	cc91                	beqz	s1,694 <vprintf+0x1f2>
        for(; *s; s++)
 67a:	0004c583          	lbu	a1,0(s1)
 67e:	c985                	beqz	a1,6ae <vprintf+0x20c>
          putc(fd, *s);
 680:	855a                	mv	a0,s6
 682:	d5fff0ef          	jal	3e0 <putc>
        for(; *s; s++)
 686:	0485                	addi	s1,s1,1
 688:	0004c583          	lbu	a1,0(s1)
 68c:	f9f5                	bnez	a1,680 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 68e:	8bce                	mv	s7,s3
      state = 0;
 690:	4981                	li	s3,0
 692:	bd91                	j	4e6 <vprintf+0x44>
          s = "(null)";
 694:	00000497          	auipc	s1,0x0
 698:	2d448493          	addi	s1,s1,724 # 968 <malloc+0x140>
        for(; *s; s++)
 69c:	02800593          	li	a1,40
 6a0:	b7c5                	j	680 <vprintf+0x1de>
        putc(fd, '%');
 6a2:	85be                	mv	a1,a5
 6a4:	855a                	mv	a0,s6
 6a6:	d3bff0ef          	jal	3e0 <putc>
      state = 0;
 6aa:	4981                	li	s3,0
 6ac:	bd2d                	j	4e6 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6ae:	8bce                	mv	s7,s3
      state = 0;
 6b0:	4981                	li	s3,0
 6b2:	bd15                	j	4e6 <vprintf+0x44>
 6b4:	6906                	ld	s2,64(sp)
 6b6:	79e2                	ld	s3,56(sp)
 6b8:	7a42                	ld	s4,48(sp)
 6ba:	7aa2                	ld	s5,40(sp)
 6bc:	7b02                	ld	s6,32(sp)
 6be:	6be2                	ld	s7,24(sp)
 6c0:	6c42                	ld	s8,16(sp)
    }
  }
}
 6c2:	60e6                	ld	ra,88(sp)
 6c4:	6446                	ld	s0,80(sp)
 6c6:	64a6                	ld	s1,72(sp)
 6c8:	6125                	addi	sp,sp,96
 6ca:	8082                	ret
      if(c0 == 'd'){
 6cc:	06400713          	li	a4,100
 6d0:	e6e789e3          	beq	a5,a4,542 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 6d4:	f9478693          	addi	a3,a5,-108
 6d8:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 6dc:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6de:	4701                	li	a4,0
      } else if(c0 == 'u'){
 6e0:	07500513          	li	a0,117
 6e4:	eaa786e3          	beq	a5,a0,590 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 6e8:	f8b60513          	addi	a0,a2,-117
 6ec:	e119                	bnez	a0,6f2 <vprintf+0x250>
 6ee:	ea069de3          	bnez	a3,5a8 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6f2:	f8b58513          	addi	a0,a1,-117
 6f6:	e119                	bnez	a0,6fc <vprintf+0x25a>
 6f8:	ec0715e3          	bnez	a4,5c2 <vprintf+0x120>
      } else if(c0 == 'x'){
 6fc:	07800513          	li	a0,120
 700:	eca78ee3          	beq	a5,a0,5dc <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 704:	f8860613          	addi	a2,a2,-120
 708:	e219                	bnez	a2,70e <vprintf+0x26c>
 70a:	ee0695e3          	bnez	a3,5f4 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 70e:	f8858593          	addi	a1,a1,-120
 712:	e199                	bnez	a1,718 <vprintf+0x276>
 714:	ee071de3          	bnez	a4,60e <vprintf+0x16c>
      } else if(c0 == 'p'){
 718:	07000713          	li	a4,112
 71c:	f0e786e3          	beq	a5,a4,628 <vprintf+0x186>
      } else if(c0 == 's'){
 720:	07300713          	li	a4,115
 724:	f4e786e3          	beq	a5,a4,670 <vprintf+0x1ce>
      } else if(c0 == '%'){
 728:	02500713          	li	a4,37
 72c:	f6e78be3          	beq	a5,a4,6a2 <vprintf+0x200>
        putc(fd, '%');
 730:	02500593          	li	a1,37
 734:	855a                	mv	a0,s6
 736:	cabff0ef          	jal	3e0 <putc>
        putc(fd, c0);
 73a:	85a6                	mv	a1,s1
 73c:	855a                	mv	a0,s6
 73e:	ca3ff0ef          	jal	3e0 <putc>
      state = 0;
 742:	4981                	li	s3,0
 744:	b34d                	j	4e6 <vprintf+0x44>

0000000000000746 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 746:	715d                	addi	sp,sp,-80
 748:	ec06                	sd	ra,24(sp)
 74a:	e822                	sd	s0,16(sp)
 74c:	1000                	addi	s0,sp,32
 74e:	e010                	sd	a2,0(s0)
 750:	e414                	sd	a3,8(s0)
 752:	e818                	sd	a4,16(s0)
 754:	ec1c                	sd	a5,24(s0)
 756:	03043023          	sd	a6,32(s0)
 75a:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 75e:	8622                	mv	a2,s0
 760:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 764:	d3fff0ef          	jal	4a2 <vprintf>
}
 768:	60e2                	ld	ra,24(sp)
 76a:	6442                	ld	s0,16(sp)
 76c:	6161                	addi	sp,sp,80
 76e:	8082                	ret

0000000000000770 <printf>:

void
printf(const char *fmt, ...)
{
 770:	711d                	addi	sp,sp,-96
 772:	ec06                	sd	ra,24(sp)
 774:	e822                	sd	s0,16(sp)
 776:	1000                	addi	s0,sp,32
 778:	e40c                	sd	a1,8(s0)
 77a:	e810                	sd	a2,16(s0)
 77c:	ec14                	sd	a3,24(s0)
 77e:	f018                	sd	a4,32(s0)
 780:	f41c                	sd	a5,40(s0)
 782:	03043823          	sd	a6,48(s0)
 786:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 78a:	00840613          	addi	a2,s0,8
 78e:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 792:	85aa                	mv	a1,a0
 794:	4505                	li	a0,1
 796:	d0dff0ef          	jal	4a2 <vprintf>
}
 79a:	60e2                	ld	ra,24(sp)
 79c:	6442                	ld	s0,16(sp)
 79e:	6125                	addi	sp,sp,96
 7a0:	8082                	ret

00000000000007a2 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7a2:	1141                	addi	sp,sp,-16
 7a4:	e406                	sd	ra,8(sp)
 7a6:	e022                	sd	s0,0(sp)
 7a8:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 7aa:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7ae:	00001797          	auipc	a5,0x1
 7b2:	8527b783          	ld	a5,-1966(a5) # 1000 <freep>
 7b6:	a039                	j	7c4 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7b8:	6398                	ld	a4,0(a5)
 7ba:	00e7e463          	bltu	a5,a4,7c2 <free+0x20>
 7be:	00e6ea63          	bltu	a3,a4,7d2 <free+0x30>
{
 7c2:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7c4:	fed7fae3          	bgeu	a5,a3,7b8 <free+0x16>
 7c8:	6398                	ld	a4,0(a5)
 7ca:	00e6e463          	bltu	a3,a4,7d2 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7ce:	fee7eae3          	bltu	a5,a4,7c2 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 7d2:	ff852583          	lw	a1,-8(a0)
 7d6:	6390                	ld	a2,0(a5)
 7d8:	02059813          	slli	a6,a1,0x20
 7dc:	01c85713          	srli	a4,a6,0x1c
 7e0:	9736                	add	a4,a4,a3
 7e2:	02e60563          	beq	a2,a4,80c <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 7e6:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 7ea:	4790                	lw	a2,8(a5)
 7ec:	02061593          	slli	a1,a2,0x20
 7f0:	01c5d713          	srli	a4,a1,0x1c
 7f4:	973e                	add	a4,a4,a5
 7f6:	02e68263          	beq	a3,a4,81a <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 7fa:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 7fc:	00001717          	auipc	a4,0x1
 800:	80f73223          	sd	a5,-2044(a4) # 1000 <freep>
}
 804:	60a2                	ld	ra,8(sp)
 806:	6402                	ld	s0,0(sp)
 808:	0141                	addi	sp,sp,16
 80a:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 80c:	4618                	lw	a4,8(a2)
 80e:	9f2d                	addw	a4,a4,a1
 810:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 814:	6398                	ld	a4,0(a5)
 816:	6310                	ld	a2,0(a4)
 818:	b7f9                	j	7e6 <free+0x44>
    p->s.size += bp->s.size;
 81a:	ff852703          	lw	a4,-8(a0)
 81e:	9f31                	addw	a4,a4,a2
 820:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 822:	ff053683          	ld	a3,-16(a0)
 826:	bfd1                	j	7fa <free+0x58>

0000000000000828 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 828:	7139                	addi	sp,sp,-64
 82a:	fc06                	sd	ra,56(sp)
 82c:	f822                	sd	s0,48(sp)
 82e:	f04a                	sd	s2,32(sp)
 830:	ec4e                	sd	s3,24(sp)
 832:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 834:	02051993          	slli	s3,a0,0x20
 838:	0209d993          	srli	s3,s3,0x20
 83c:	09bd                	addi	s3,s3,15
 83e:	0049d993          	srli	s3,s3,0x4
 842:	2985                	addiw	s3,s3,1
 844:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 846:	00000517          	auipc	a0,0x0
 84a:	7ba53503          	ld	a0,1978(a0) # 1000 <freep>
 84e:	c905                	beqz	a0,87e <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 850:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 852:	4798                	lw	a4,8(a5)
 854:	09377663          	bgeu	a4,s3,8e0 <malloc+0xb8>
 858:	f426                	sd	s1,40(sp)
 85a:	e852                	sd	s4,16(sp)
 85c:	e456                	sd	s5,8(sp)
 85e:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 860:	8a4e                	mv	s4,s3
 862:	6705                	lui	a4,0x1
 864:	00e9f363          	bgeu	s3,a4,86a <malloc+0x42>
 868:	6a05                	lui	s4,0x1
 86a:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 86e:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 872:	00000497          	auipc	s1,0x0
 876:	78e48493          	addi	s1,s1,1934 # 1000 <freep>
  if(p == (char*)-1)
 87a:	5afd                	li	s5,-1
 87c:	a83d                	j	8ba <malloc+0x92>
 87e:	f426                	sd	s1,40(sp)
 880:	e852                	sd	s4,16(sp)
 882:	e456                	sd	s5,8(sp)
 884:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 886:	00000797          	auipc	a5,0x0
 88a:	78a78793          	addi	a5,a5,1930 # 1010 <base>
 88e:	00000717          	auipc	a4,0x0
 892:	76f73923          	sd	a5,1906(a4) # 1000 <freep>
 896:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 898:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 89c:	b7d1                	j	860 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 89e:	6398                	ld	a4,0(a5)
 8a0:	e118                	sd	a4,0(a0)
 8a2:	a899                	j	8f8 <malloc+0xd0>
  hp->s.size = nu;
 8a4:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 8a8:	0541                	addi	a0,a0,16
 8aa:	ef9ff0ef          	jal	7a2 <free>
  return freep;
 8ae:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 8b0:	c125                	beqz	a0,910 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8b2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8b4:	4798                	lw	a4,8(a5)
 8b6:	03277163          	bgeu	a4,s2,8d8 <malloc+0xb0>
    if(p == freep)
 8ba:	6098                	ld	a4,0(s1)
 8bc:	853e                	mv	a0,a5
 8be:	fef71ae3          	bne	a4,a5,8b2 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 8c2:	8552                	mv	a0,s4
 8c4:	afdff0ef          	jal	3c0 <sbrk>
  if(p == (char*)-1)
 8c8:	fd551ee3          	bne	a0,s5,8a4 <malloc+0x7c>
        return 0;
 8cc:	4501                	li	a0,0
 8ce:	74a2                	ld	s1,40(sp)
 8d0:	6a42                	ld	s4,16(sp)
 8d2:	6aa2                	ld	s5,8(sp)
 8d4:	6b02                	ld	s6,0(sp)
 8d6:	a03d                	j	904 <malloc+0xdc>
 8d8:	74a2                	ld	s1,40(sp)
 8da:	6a42                	ld	s4,16(sp)
 8dc:	6aa2                	ld	s5,8(sp)
 8de:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 8e0:	fae90fe3          	beq	s2,a4,89e <malloc+0x76>
        p->s.size -= nunits;
 8e4:	4137073b          	subw	a4,a4,s3
 8e8:	c798                	sw	a4,8(a5)
        p += p->s.size;
 8ea:	02071693          	slli	a3,a4,0x20
 8ee:	01c6d713          	srli	a4,a3,0x1c
 8f2:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 8f4:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 8f8:	00000717          	auipc	a4,0x0
 8fc:	70a73423          	sd	a0,1800(a4) # 1000 <freep>
      return (void*)(p + 1);
 900:	01078513          	addi	a0,a5,16
  }
}
 904:	70e2                	ld	ra,56(sp)
 906:	7442                	ld	s0,48(sp)
 908:	7902                	ld	s2,32(sp)
 90a:	69e2                	ld	s3,24(sp)
 90c:	6121                	addi	sp,sp,64
 90e:	8082                	ret
 910:	74a2                	ld	s1,40(sp)
 912:	6a42                	ld	s4,16(sp)
 914:	6aa2                	ld	s5,8(sp)
 916:	6b02                	ld	s6,0(sp)
 918:	b7f5                	j	904 <malloc+0xdc>
