
user/_attacktest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <do_rand>:
char output[64];

// from FreeBSD.
int
do_rand(unsigned long *ctx)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
 * October 1988, p. 1195.
 */
    long hi, lo, x;

    /* Transform to [1, 0x7ffffffe] range. */
    x = (*ctx % 0x7ffffffe) + 1;
   8:	611c                	ld	a5,0(a0)
   a:	0017d693          	srli	a3,a5,0x1
   e:	c0000737          	lui	a4,0xc0000
  12:	0705                	addi	a4,a4,1 # ffffffffc0000001 <base+0xffffffffbfffefa1>
  14:	1706                	slli	a4,a4,0x21
  16:	0725                	addi	a4,a4,9
  18:	02e6b733          	mulhu	a4,a3,a4
  1c:	8375                	srli	a4,a4,0x1d
  1e:	01e71693          	slli	a3,a4,0x1e
  22:	40e68733          	sub	a4,a3,a4
  26:	0706                	slli	a4,a4,0x1
  28:	8f99                	sub	a5,a5,a4
  2a:	0785                	addi	a5,a5,1
    hi = x / 127773;
    lo = x % 127773;
  2c:	1fe406b7          	lui	a3,0x1fe40
  30:	b7968693          	addi	a3,a3,-1159 # 1fe3fb79 <base+0x1fe3eb19>
  34:	41a70737          	lui	a4,0x41a70
  38:	5af70713          	addi	a4,a4,1455 # 41a705af <base+0x41a6f54f>
  3c:	1702                	slli	a4,a4,0x20
  3e:	9736                	add	a4,a4,a3
  40:	02e79733          	mulh	a4,a5,a4
  44:	873d                	srai	a4,a4,0xf
  46:	43f7d693          	srai	a3,a5,0x3f
  4a:	8f15                	sub	a4,a4,a3
  4c:	66fd                	lui	a3,0x1f
  4e:	31d68693          	addi	a3,a3,797 # 1f31d <base+0x1e2bd>
  52:	02d706b3          	mul	a3,a4,a3
  56:	8f95                	sub	a5,a5,a3
    x = 16807 * lo - 2836 * hi;
  58:	6691                	lui	a3,0x4
  5a:	1a768693          	addi	a3,a3,423 # 41a7 <base+0x3147>
  5e:	02d787b3          	mul	a5,a5,a3
  62:	76fd                	lui	a3,0xfffff
  64:	4ec68693          	addi	a3,a3,1260 # fffffffffffff4ec <base+0xffffffffffffe48c>
  68:	02d70733          	mul	a4,a4,a3
  6c:	97ba                	add	a5,a5,a4
    if (x < 0)
  6e:	0007ca63          	bltz	a5,82 <do_rand+0x82>
        x += 0x7fffffff;
    /* Transform to [0, 0x7ffffffd] range. */
    x--;
  72:	17fd                	addi	a5,a5,-1
    *ctx = x;
  74:	e11c                	sd	a5,0(a0)
    return (x);
}
  76:	0007851b          	sext.w	a0,a5
  7a:	60a2                	ld	ra,8(sp)
  7c:	6402                	ld	s0,0(sp)
  7e:	0141                	addi	sp,sp,16
  80:	8082                	ret
        x += 0x7fffffff;
  82:	80000737          	lui	a4,0x80000
  86:	fff74713          	not	a4,a4
  8a:	97ba                	add	a5,a5,a4
  8c:	b7dd                	j	72 <do_rand+0x72>

000000000000008e <rand>:

unsigned long rand_next = 1;

int
rand(void)
{
  8e:	1141                	addi	sp,sp,-16
  90:	e406                	sd	ra,8(sp)
  92:	e022                	sd	s0,0(sp)
  94:	0800                	addi	s0,sp,16
    return (do_rand(&rand_next));
  96:	00001517          	auipc	a0,0x1
  9a:	f6a50513          	addi	a0,a0,-150 # 1000 <rand_next>
  9e:	f63ff0ef          	jal	0 <do_rand>
}
  a2:	60a2                	ld	ra,8(sp)
  a4:	6402                	ld	s0,0(sp)
  a6:	0141                	addi	sp,sp,16
  a8:	8082                	ret

00000000000000aa <randstring>:

// generate a random string of the indicated length.
char *
randstring(char *buf, int n)
{
  aa:	7139                	addi	sp,sp,-64
  ac:	fc06                	sd	ra,56(sp)
  ae:	f822                	sd	s0,48(sp)
  b0:	e852                	sd	s4,16(sp)
  b2:	e456                	sd	s5,8(sp)
  b4:	0080                	addi	s0,sp,64
  b6:	8aaa                	mv	s5,a0
  b8:	8a2e                	mv	s4,a1
  for(int i = 0; i < n-1; i++) {
  ba:	4785                	li	a5,1
  bc:	06b7d163          	bge	a5,a1,11e <randstring+0x74>
  c0:	f426                	sd	s1,40(sp)
  c2:	f04a                	sd	s2,32(sp)
  c4:	ec4e                	sd	s3,24(sp)
  c6:	84aa                	mv	s1,a0
  c8:	00f50933          	add	s2,a0,a5
  cc:	ffe5879b          	addiw	a5,a1,-2
  d0:	1782                	slli	a5,a5,0x20
  d2:	9381                	srli	a5,a5,0x20
  d4:	993e                	add	s2,s2,a5
    buf[i] = "./abcdef"[(rand() >> 7) % 8];
  d6:	00001997          	auipc	s3,0x1
  da:	a3a98993          	addi	s3,s3,-1478 # b10 <malloc+0xf2>
  de:	fb1ff0ef          	jal	8e <rand>
  e2:	4075579b          	sraiw	a5,a0,0x7
  e6:	41f5551b          	sraiw	a0,a0,0x1f
  ea:	01d5571b          	srliw	a4,a0,0x1d
  ee:	9fb9                	addw	a5,a5,a4
  f0:	8b9d                	andi	a5,a5,7
  f2:	9f99                	subw	a5,a5,a4
  f4:	97ce                	add	a5,a5,s3
  f6:	0007c783          	lbu	a5,0(a5)
  fa:	00f48023          	sb	a5,0(s1)
  for(int i = 0; i < n-1; i++) {
  fe:	0485                	addi	s1,s1,1
 100:	fd249fe3          	bne	s1,s2,de <randstring+0x34>
 104:	74a2                	ld	s1,40(sp)
 106:	7902                	ld	s2,32(sp)
 108:	69e2                	ld	s3,24(sp)
  }
  if(n > 0)
    buf[n-1] = '\0';
 10a:	9a56                	add	s4,s4,s5
 10c:	fe0a0fa3          	sb	zero,-1(s4)
  return buf;
}
 110:	8556                	mv	a0,s5
 112:	70e2                	ld	ra,56(sp)
 114:	7442                	ld	s0,48(sp)
 116:	6a42                	ld	s4,16(sp)
 118:	6aa2                	ld	s5,8(sp)
 11a:	6121                	addi	sp,sp,64
 11c:	8082                	ret
  if(n > 0)
 11e:	feb059e3          	blez	a1,110 <randstring+0x66>
 122:	b7e5                	j	10a <randstring+0x60>

0000000000000124 <main>:

int
main(int argc, char *argv[])
{
 124:	7179                	addi	sp,sp,-48
 126:	f406                	sd	ra,40(sp)
 128:	f022                	sd	s0,32(sp)
 12a:	1800                	addi	s0,sp,48
  int pid;
  int fds[2];

  // an insecure way of generating a random string, because xv6
  // doesn't have good source of randomness.
  rand_next = uptime();
 12c:	49a000ef          	jal	5c6 <uptime>
 130:	00001797          	auipc	a5,0x1
 134:	eca7b823          	sd	a0,-304(a5) # 1000 <rand_next>
  randstring(secret, 8);
 138:	45a1                	li	a1,8
 13a:	00001517          	auipc	a0,0x1
 13e:	ed650513          	addi	a0,a0,-298 # 1010 <secret>
 142:	f69ff0ef          	jal	aa <randstring>
  
  if((pid = fork()) < 0) {
 146:	3e0000ef          	jal	526 <fork>
 14a:	06054d63          	bltz	a0,1c4 <main+0xa0>
    printf("fork failed\n");
    exit(1);   
  }
  if(pid == 0) {
 14e:	c541                	beqz	a0,1d6 <main+0xb2>
    char *newargv[] = { "secret", secret, 0 };
    exec(newargv[0], newargv);
    printf("exec %s failed\n", newargv[0]);
    exit(1);
  } else {
    wait(0);  // wait for secret to exit
 150:	4501                	li	a0,0
 152:	3e4000ef          	jal	536 <wait>
    if(pipe(fds) < 0) {
 156:	fe840513          	addi	a0,s0,-24
 15a:	3e4000ef          	jal	53e <pipe>
 15e:	0a054d63          	bltz	a0,218 <main+0xf4>
      printf("pipe failed\n");
      exit(1);   
    }
    if((pid = fork()) < 0) {
 162:	3c4000ef          	jal	526 <fork>
 166:	0c054263          	bltz	a0,22a <main+0x106>
      printf("fork failed\n");
      exit(1);   
    }
    if(pid == 0) {
 16a:	0c050963          	beqz	a0,23c <main+0x118>
      char *newargv[] = { "attack", 0 };
      exec(newargv[0], newargv);
      printf("exec %s failed\n", newargv[0]);
      exit(1);
    } else {
       close(fds[1]);
 16e:	fec42503          	lw	a0,-20(s0)
 172:	3e4000ef          	jal	556 <close>
      if(read(fds[0], output, 64) < 0) {
 176:	04000613          	li	a2,64
 17a:	00001597          	auipc	a1,0x1
 17e:	ea658593          	addi	a1,a1,-346 # 1020 <output>
 182:	fe842503          	lw	a0,-24(s0)
 186:	3c0000ef          	jal	546 <read>
 18a:	0e054c63          	bltz	a0,282 <main+0x15e>
        printf("FAIL; read failed; no secret\n");
        exit(1);
      }
      if(strcmp(secret, output) == 0) {
 18e:	00001597          	auipc	a1,0x1
 192:	e9258593          	addi	a1,a1,-366 # 1020 <output>
 196:	00001517          	auipc	a0,0x1
 19a:	e7a50513          	addi	a0,a0,-390 # 1010 <secret>
 19e:	136000ef          	jal	2d4 <strcmp>
 1a2:	0e051963          	bnez	a0,294 <main+0x170>
        printf("OK: secret is %s\n", output);
 1a6:	00001597          	auipc	a1,0x1
 1aa:	e7a58593          	addi	a1,a1,-390 # 1020 <output>
 1ae:	00001517          	auipc	a0,0x1
 1b2:	9d250513          	addi	a0,a0,-1582 # b80 <malloc+0x162>
 1b6:	7b0000ef          	jal	966 <printf>
      } else {
        printf("FAIL: no/incorrect secret\n");
      }
    }
  }
}
 1ba:	4501                	li	a0,0
 1bc:	70a2                	ld	ra,40(sp)
 1be:	7402                	ld	s0,32(sp)
 1c0:	6145                	addi	sp,sp,48
 1c2:	8082                	ret
    printf("fork failed\n");
 1c4:	00001517          	auipc	a0,0x1
 1c8:	95c50513          	addi	a0,a0,-1700 # b20 <malloc+0x102>
 1cc:	79a000ef          	jal	966 <printf>
    exit(1);   
 1d0:	4505                	li	a0,1
 1d2:	35c000ef          	jal	52e <exit>
    char *newargv[] = { "secret", secret, 0 };
 1d6:	00001797          	auipc	a5,0x1
 1da:	95a78793          	addi	a5,a5,-1702 # b30 <malloc+0x112>
 1de:	fcf43823          	sd	a5,-48(s0)
 1e2:	00001797          	auipc	a5,0x1
 1e6:	e2e78793          	addi	a5,a5,-466 # 1010 <secret>
 1ea:	fcf43c23          	sd	a5,-40(s0)
 1ee:	fe043023          	sd	zero,-32(s0)
    exec(newargv[0], newargv);
 1f2:	fd040593          	addi	a1,s0,-48
 1f6:	00001517          	auipc	a0,0x1
 1fa:	93a50513          	addi	a0,a0,-1734 # b30 <malloc+0x112>
 1fe:	368000ef          	jal	566 <exec>
    printf("exec %s failed\n", newargv[0]);
 202:	fd043583          	ld	a1,-48(s0)
 206:	00001517          	auipc	a0,0x1
 20a:	93250513          	addi	a0,a0,-1742 # b38 <malloc+0x11a>
 20e:	758000ef          	jal	966 <printf>
    exit(1);
 212:	4505                	li	a0,1
 214:	31a000ef          	jal	52e <exit>
      printf("pipe failed\n");
 218:	00001517          	auipc	a0,0x1
 21c:	93050513          	addi	a0,a0,-1744 # b48 <malloc+0x12a>
 220:	746000ef          	jal	966 <printf>
      exit(1);   
 224:	4505                	li	a0,1
 226:	308000ef          	jal	52e <exit>
      printf("fork failed\n");
 22a:	00001517          	auipc	a0,0x1
 22e:	8f650513          	addi	a0,a0,-1802 # b20 <malloc+0x102>
 232:	734000ef          	jal	966 <printf>
      exit(1);   
 236:	4505                	li	a0,1
 238:	2f6000ef          	jal	52e <exit>
      close(fds[0]);
 23c:	fe842503          	lw	a0,-24(s0)
 240:	316000ef          	jal	556 <close>
      close(2);
 244:	4509                	li	a0,2
 246:	310000ef          	jal	556 <close>
      dup(fds[1]);
 24a:	fec42503          	lw	a0,-20(s0)
 24e:	358000ef          	jal	5a6 <dup>
      char *newargv[] = { "attack", 0 };
 252:	00001797          	auipc	a5,0x1
 256:	90678793          	addi	a5,a5,-1786 # b58 <malloc+0x13a>
 25a:	fcf43823          	sd	a5,-48(s0)
 25e:	fc043c23          	sd	zero,-40(s0)
      exec(newargv[0], newargv);
 262:	fd040593          	addi	a1,s0,-48
 266:	853e                	mv	a0,a5
 268:	2fe000ef          	jal	566 <exec>
      printf("exec %s failed\n", newargv[0]);
 26c:	fd043583          	ld	a1,-48(s0)
 270:	00001517          	auipc	a0,0x1
 274:	8c850513          	addi	a0,a0,-1848 # b38 <malloc+0x11a>
 278:	6ee000ef          	jal	966 <printf>
      exit(1);
 27c:	4505                	li	a0,1
 27e:	2b0000ef          	jal	52e <exit>
        printf("FAIL; read failed; no secret\n");
 282:	00001517          	auipc	a0,0x1
 286:	8de50513          	addi	a0,a0,-1826 # b60 <malloc+0x142>
 28a:	6dc000ef          	jal	966 <printf>
        exit(1);
 28e:	4505                	li	a0,1
 290:	29e000ef          	jal	52e <exit>
        printf("FAIL: no/incorrect secret\n");
 294:	00001517          	auipc	a0,0x1
 298:	90450513          	addi	a0,a0,-1788 # b98 <malloc+0x17a>
 29c:	6ca000ef          	jal	966 <printf>
 2a0:	bf29                	j	1ba <main+0x96>

00000000000002a2 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 2a2:	1141                	addi	sp,sp,-16
 2a4:	e406                	sd	ra,8(sp)
 2a6:	e022                	sd	s0,0(sp)
 2a8:	0800                	addi	s0,sp,16
  extern int main();
  main();
 2aa:	e7bff0ef          	jal	124 <main>
  exit(0);
 2ae:	4501                	li	a0,0
 2b0:	27e000ef          	jal	52e <exit>

00000000000002b4 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 2b4:	1141                	addi	sp,sp,-16
 2b6:	e406                	sd	ra,8(sp)
 2b8:	e022                	sd	s0,0(sp)
 2ba:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 2bc:	87aa                	mv	a5,a0
 2be:	0585                	addi	a1,a1,1
 2c0:	0785                	addi	a5,a5,1
 2c2:	fff5c703          	lbu	a4,-1(a1)
 2c6:	fee78fa3          	sb	a4,-1(a5)
 2ca:	fb75                	bnez	a4,2be <strcpy+0xa>
    ;
  return os;
}
 2cc:	60a2                	ld	ra,8(sp)
 2ce:	6402                	ld	s0,0(sp)
 2d0:	0141                	addi	sp,sp,16
 2d2:	8082                	ret

00000000000002d4 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2d4:	1141                	addi	sp,sp,-16
 2d6:	e406                	sd	ra,8(sp)
 2d8:	e022                	sd	s0,0(sp)
 2da:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 2dc:	00054783          	lbu	a5,0(a0)
 2e0:	cb91                	beqz	a5,2f4 <strcmp+0x20>
 2e2:	0005c703          	lbu	a4,0(a1)
 2e6:	00f71763          	bne	a4,a5,2f4 <strcmp+0x20>
    p++, q++;
 2ea:	0505                	addi	a0,a0,1
 2ec:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2ee:	00054783          	lbu	a5,0(a0)
 2f2:	fbe5                	bnez	a5,2e2 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 2f4:	0005c503          	lbu	a0,0(a1)
}
 2f8:	40a7853b          	subw	a0,a5,a0
 2fc:	60a2                	ld	ra,8(sp)
 2fe:	6402                	ld	s0,0(sp)
 300:	0141                	addi	sp,sp,16
 302:	8082                	ret

0000000000000304 <strlen>:

uint
strlen(const char *s)
{
 304:	1141                	addi	sp,sp,-16
 306:	e406                	sd	ra,8(sp)
 308:	e022                	sd	s0,0(sp)
 30a:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 30c:	00054783          	lbu	a5,0(a0)
 310:	cf91                	beqz	a5,32c <strlen+0x28>
 312:	00150793          	addi	a5,a0,1
 316:	86be                	mv	a3,a5
 318:	0785                	addi	a5,a5,1
 31a:	fff7c703          	lbu	a4,-1(a5)
 31e:	ff65                	bnez	a4,316 <strlen+0x12>
 320:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 324:	60a2                	ld	ra,8(sp)
 326:	6402                	ld	s0,0(sp)
 328:	0141                	addi	sp,sp,16
 32a:	8082                	ret
  for(n = 0; s[n]; n++)
 32c:	4501                	li	a0,0
 32e:	bfdd                	j	324 <strlen+0x20>

0000000000000330 <memset>:

void*
memset(void *dst, int c, uint n)
{
 330:	1141                	addi	sp,sp,-16
 332:	e406                	sd	ra,8(sp)
 334:	e022                	sd	s0,0(sp)
 336:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 338:	ca19                	beqz	a2,34e <memset+0x1e>
 33a:	87aa                	mv	a5,a0
 33c:	1602                	slli	a2,a2,0x20
 33e:	9201                	srli	a2,a2,0x20
 340:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 344:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 348:	0785                	addi	a5,a5,1
 34a:	fee79de3          	bne	a5,a4,344 <memset+0x14>
  }
  return dst;
}
 34e:	60a2                	ld	ra,8(sp)
 350:	6402                	ld	s0,0(sp)
 352:	0141                	addi	sp,sp,16
 354:	8082                	ret

0000000000000356 <strchr>:

char*
strchr(const char *s, char c)
{
 356:	1141                	addi	sp,sp,-16
 358:	e406                	sd	ra,8(sp)
 35a:	e022                	sd	s0,0(sp)
 35c:	0800                	addi	s0,sp,16
  for(; *s; s++)
 35e:	00054783          	lbu	a5,0(a0)
 362:	cf81                	beqz	a5,37a <strchr+0x24>
    if(*s == c)
 364:	00f58763          	beq	a1,a5,372 <strchr+0x1c>
  for(; *s; s++)
 368:	0505                	addi	a0,a0,1
 36a:	00054783          	lbu	a5,0(a0)
 36e:	fbfd                	bnez	a5,364 <strchr+0xe>
      return (char*)s;
  return 0;
 370:	4501                	li	a0,0
}
 372:	60a2                	ld	ra,8(sp)
 374:	6402                	ld	s0,0(sp)
 376:	0141                	addi	sp,sp,16
 378:	8082                	ret
  return 0;
 37a:	4501                	li	a0,0
 37c:	bfdd                	j	372 <strchr+0x1c>

000000000000037e <gets>:

char*
gets(char *buf, int max)
{
 37e:	711d                	addi	sp,sp,-96
 380:	ec86                	sd	ra,88(sp)
 382:	e8a2                	sd	s0,80(sp)
 384:	e4a6                	sd	s1,72(sp)
 386:	e0ca                	sd	s2,64(sp)
 388:	fc4e                	sd	s3,56(sp)
 38a:	f852                	sd	s4,48(sp)
 38c:	f456                	sd	s5,40(sp)
 38e:	f05a                	sd	s6,32(sp)
 390:	ec5e                	sd	s7,24(sp)
 392:	e862                	sd	s8,16(sp)
 394:	1080                	addi	s0,sp,96
 396:	8baa                	mv	s7,a0
 398:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 39a:	892a                	mv	s2,a0
 39c:	4481                	li	s1,0
    cc = read(0, &c, 1);
 39e:	faf40b13          	addi	s6,s0,-81
 3a2:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 3a4:	8c26                	mv	s8,s1
 3a6:	0014899b          	addiw	s3,s1,1
 3aa:	84ce                	mv	s1,s3
 3ac:	0349d463          	bge	s3,s4,3d4 <gets+0x56>
    cc = read(0, &c, 1);
 3b0:	8656                	mv	a2,s5
 3b2:	85da                	mv	a1,s6
 3b4:	4501                	li	a0,0
 3b6:	190000ef          	jal	546 <read>
    if(cc < 1)
 3ba:	00a05d63          	blez	a0,3d4 <gets+0x56>
      break;
    buf[i++] = c;
 3be:	faf44783          	lbu	a5,-81(s0)
 3c2:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 3c6:	0905                	addi	s2,s2,1
 3c8:	ff678713          	addi	a4,a5,-10
 3cc:	c319                	beqz	a4,3d2 <gets+0x54>
 3ce:	17cd                	addi	a5,a5,-13
 3d0:	fbf1                	bnez	a5,3a4 <gets+0x26>
    buf[i++] = c;
 3d2:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 3d4:	9c5e                	add	s8,s8,s7
 3d6:	000c0023          	sb	zero,0(s8)
  return buf;
}
 3da:	855e                	mv	a0,s7
 3dc:	60e6                	ld	ra,88(sp)
 3de:	6446                	ld	s0,80(sp)
 3e0:	64a6                	ld	s1,72(sp)
 3e2:	6906                	ld	s2,64(sp)
 3e4:	79e2                	ld	s3,56(sp)
 3e6:	7a42                	ld	s4,48(sp)
 3e8:	7aa2                	ld	s5,40(sp)
 3ea:	7b02                	ld	s6,32(sp)
 3ec:	6be2                	ld	s7,24(sp)
 3ee:	6c42                	ld	s8,16(sp)
 3f0:	6125                	addi	sp,sp,96
 3f2:	8082                	ret

00000000000003f4 <stat>:

int
stat(const char *n, struct stat *st)
{
 3f4:	1101                	addi	sp,sp,-32
 3f6:	ec06                	sd	ra,24(sp)
 3f8:	e822                	sd	s0,16(sp)
 3fa:	e04a                	sd	s2,0(sp)
 3fc:	1000                	addi	s0,sp,32
 3fe:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 400:	4581                	li	a1,0
 402:	16c000ef          	jal	56e <open>
  if(fd < 0)
 406:	02054263          	bltz	a0,42a <stat+0x36>
 40a:	e426                	sd	s1,8(sp)
 40c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 40e:	85ca                	mv	a1,s2
 410:	176000ef          	jal	586 <fstat>
 414:	892a                	mv	s2,a0
  close(fd);
 416:	8526                	mv	a0,s1
 418:	13e000ef          	jal	556 <close>
  return r;
 41c:	64a2                	ld	s1,8(sp)
}
 41e:	854a                	mv	a0,s2
 420:	60e2                	ld	ra,24(sp)
 422:	6442                	ld	s0,16(sp)
 424:	6902                	ld	s2,0(sp)
 426:	6105                	addi	sp,sp,32
 428:	8082                	ret
    return -1;
 42a:	57fd                	li	a5,-1
 42c:	893e                	mv	s2,a5
 42e:	bfc5                	j	41e <stat+0x2a>

0000000000000430 <atoi>:

int
atoi(const char *s)
{
 430:	1141                	addi	sp,sp,-16
 432:	e406                	sd	ra,8(sp)
 434:	e022                	sd	s0,0(sp)
 436:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 438:	00054683          	lbu	a3,0(a0)
 43c:	fd06879b          	addiw	a5,a3,-48
 440:	0ff7f793          	zext.b	a5,a5
 444:	4625                	li	a2,9
 446:	02f66963          	bltu	a2,a5,478 <atoi+0x48>
 44a:	872a                	mv	a4,a0
  n = 0;
 44c:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 44e:	0705                	addi	a4,a4,1 # ffffffff80000001 <base+0xffffffff7fffefa1>
 450:	0025179b          	slliw	a5,a0,0x2
 454:	9fa9                	addw	a5,a5,a0
 456:	0017979b          	slliw	a5,a5,0x1
 45a:	9fb5                	addw	a5,a5,a3
 45c:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 460:	00074683          	lbu	a3,0(a4)
 464:	fd06879b          	addiw	a5,a3,-48
 468:	0ff7f793          	zext.b	a5,a5
 46c:	fef671e3          	bgeu	a2,a5,44e <atoi+0x1e>
  return n;
}
 470:	60a2                	ld	ra,8(sp)
 472:	6402                	ld	s0,0(sp)
 474:	0141                	addi	sp,sp,16
 476:	8082                	ret
  n = 0;
 478:	4501                	li	a0,0
 47a:	bfdd                	j	470 <atoi+0x40>

000000000000047c <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 47c:	1141                	addi	sp,sp,-16
 47e:	e406                	sd	ra,8(sp)
 480:	e022                	sd	s0,0(sp)
 482:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 484:	02b57563          	bgeu	a0,a1,4ae <memmove+0x32>
    while(n-- > 0)
 488:	00c05f63          	blez	a2,4a6 <memmove+0x2a>
 48c:	1602                	slli	a2,a2,0x20
 48e:	9201                	srli	a2,a2,0x20
 490:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 494:	872a                	mv	a4,a0
      *dst++ = *src++;
 496:	0585                	addi	a1,a1,1
 498:	0705                	addi	a4,a4,1
 49a:	fff5c683          	lbu	a3,-1(a1)
 49e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 4a2:	fee79ae3          	bne	a5,a4,496 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 4a6:	60a2                	ld	ra,8(sp)
 4a8:	6402                	ld	s0,0(sp)
 4aa:	0141                	addi	sp,sp,16
 4ac:	8082                	ret
    while(n-- > 0)
 4ae:	fec05ce3          	blez	a2,4a6 <memmove+0x2a>
    dst += n;
 4b2:	00c50733          	add	a4,a0,a2
    src += n;
 4b6:	95b2                	add	a1,a1,a2
 4b8:	fff6079b          	addiw	a5,a2,-1
 4bc:	1782                	slli	a5,a5,0x20
 4be:	9381                	srli	a5,a5,0x20
 4c0:	fff7c793          	not	a5,a5
 4c4:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 4c6:	15fd                	addi	a1,a1,-1
 4c8:	177d                	addi	a4,a4,-1
 4ca:	0005c683          	lbu	a3,0(a1)
 4ce:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 4d2:	fef71ae3          	bne	a4,a5,4c6 <memmove+0x4a>
 4d6:	bfc1                	j	4a6 <memmove+0x2a>

00000000000004d8 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 4d8:	1141                	addi	sp,sp,-16
 4da:	e406                	sd	ra,8(sp)
 4dc:	e022                	sd	s0,0(sp)
 4de:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 4e0:	c61d                	beqz	a2,50e <memcmp+0x36>
 4e2:	1602                	slli	a2,a2,0x20
 4e4:	9201                	srli	a2,a2,0x20
 4e6:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 4ea:	00054783          	lbu	a5,0(a0)
 4ee:	0005c703          	lbu	a4,0(a1)
 4f2:	00e79863          	bne	a5,a4,502 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 4f6:	0505                	addi	a0,a0,1
    p2++;
 4f8:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4fa:	fed518e3          	bne	a0,a3,4ea <memcmp+0x12>
  }
  return 0;
 4fe:	4501                	li	a0,0
 500:	a019                	j	506 <memcmp+0x2e>
      return *p1 - *p2;
 502:	40e7853b          	subw	a0,a5,a4
}
 506:	60a2                	ld	ra,8(sp)
 508:	6402                	ld	s0,0(sp)
 50a:	0141                	addi	sp,sp,16
 50c:	8082                	ret
  return 0;
 50e:	4501                	li	a0,0
 510:	bfdd                	j	506 <memcmp+0x2e>

0000000000000512 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 512:	1141                	addi	sp,sp,-16
 514:	e406                	sd	ra,8(sp)
 516:	e022                	sd	s0,0(sp)
 518:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 51a:	f63ff0ef          	jal	47c <memmove>
}
 51e:	60a2                	ld	ra,8(sp)
 520:	6402                	ld	s0,0(sp)
 522:	0141                	addi	sp,sp,16
 524:	8082                	ret

0000000000000526 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 526:	4885                	li	a7,1
 ecall
 528:	00000073          	ecall
 ret
 52c:	8082                	ret

000000000000052e <exit>:
.global exit
exit:
 li a7, SYS_exit
 52e:	4889                	li	a7,2
 ecall
 530:	00000073          	ecall
 ret
 534:	8082                	ret

0000000000000536 <wait>:
.global wait
wait:
 li a7, SYS_wait
 536:	488d                	li	a7,3
 ecall
 538:	00000073          	ecall
 ret
 53c:	8082                	ret

000000000000053e <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 53e:	4891                	li	a7,4
 ecall
 540:	00000073          	ecall
 ret
 544:	8082                	ret

0000000000000546 <read>:
.global read
read:
 li a7, SYS_read
 546:	4895                	li	a7,5
 ecall
 548:	00000073          	ecall
 ret
 54c:	8082                	ret

000000000000054e <write>:
.global write
write:
 li a7, SYS_write
 54e:	48c1                	li	a7,16
 ecall
 550:	00000073          	ecall
 ret
 554:	8082                	ret

0000000000000556 <close>:
.global close
close:
 li a7, SYS_close
 556:	48d5                	li	a7,21
 ecall
 558:	00000073          	ecall
 ret
 55c:	8082                	ret

000000000000055e <kill>:
.global kill
kill:
 li a7, SYS_kill
 55e:	4899                	li	a7,6
 ecall
 560:	00000073          	ecall
 ret
 564:	8082                	ret

0000000000000566 <exec>:
.global exec
exec:
 li a7, SYS_exec
 566:	489d                	li	a7,7
 ecall
 568:	00000073          	ecall
 ret
 56c:	8082                	ret

000000000000056e <open>:
.global open
open:
 li a7, SYS_open
 56e:	48bd                	li	a7,15
 ecall
 570:	00000073          	ecall
 ret
 574:	8082                	ret

0000000000000576 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 576:	48c5                	li	a7,17
 ecall
 578:	00000073          	ecall
 ret
 57c:	8082                	ret

000000000000057e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 57e:	48c9                	li	a7,18
 ecall
 580:	00000073          	ecall
 ret
 584:	8082                	ret

0000000000000586 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 586:	48a1                	li	a7,8
 ecall
 588:	00000073          	ecall
 ret
 58c:	8082                	ret

000000000000058e <link>:
.global link
link:
 li a7, SYS_link
 58e:	48cd                	li	a7,19
 ecall
 590:	00000073          	ecall
 ret
 594:	8082                	ret

0000000000000596 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 596:	48d1                	li	a7,20
 ecall
 598:	00000073          	ecall
 ret
 59c:	8082                	ret

000000000000059e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 59e:	48a5                	li	a7,9
 ecall
 5a0:	00000073          	ecall
 ret
 5a4:	8082                	ret

00000000000005a6 <dup>:
.global dup
dup:
 li a7, SYS_dup
 5a6:	48a9                	li	a7,10
 ecall
 5a8:	00000073          	ecall
 ret
 5ac:	8082                	ret

00000000000005ae <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 5ae:	48ad                	li	a7,11
 ecall
 5b0:	00000073          	ecall
 ret
 5b4:	8082                	ret

00000000000005b6 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 5b6:	48b1                	li	a7,12
 ecall
 5b8:	00000073          	ecall
 ret
 5bc:	8082                	ret

00000000000005be <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 5be:	48b5                	li	a7,13
 ecall
 5c0:	00000073          	ecall
 ret
 5c4:	8082                	ret

00000000000005c6 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 5c6:	48b9                	li	a7,14
 ecall
 5c8:	00000073          	ecall
 ret
 5cc:	8082                	ret

00000000000005ce <trace>:
.global trace
trace:
 li a7, SYS_trace
 5ce:	48d9                	li	a7,22
 ecall
 5d0:	00000073          	ecall
 ret
 5d4:	8082                	ret

00000000000005d6 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 5d6:	1101                	addi	sp,sp,-32
 5d8:	ec06                	sd	ra,24(sp)
 5da:	e822                	sd	s0,16(sp)
 5dc:	1000                	addi	s0,sp,32
 5de:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 5e2:	4605                	li	a2,1
 5e4:	fef40593          	addi	a1,s0,-17
 5e8:	f67ff0ef          	jal	54e <write>
}
 5ec:	60e2                	ld	ra,24(sp)
 5ee:	6442                	ld	s0,16(sp)
 5f0:	6105                	addi	sp,sp,32
 5f2:	8082                	ret

00000000000005f4 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 5f4:	7139                	addi	sp,sp,-64
 5f6:	fc06                	sd	ra,56(sp)
 5f8:	f822                	sd	s0,48(sp)
 5fa:	f04a                	sd	s2,32(sp)
 5fc:	ec4e                	sd	s3,24(sp)
 5fe:	0080                	addi	s0,sp,64
 600:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 602:	cac9                	beqz	a3,694 <printint+0xa0>
 604:	01f5d79b          	srliw	a5,a1,0x1f
 608:	c7d1                	beqz	a5,694 <printint+0xa0>
    neg = 1;
    x = -xx;
 60a:	40b005bb          	negw	a1,a1
    neg = 1;
 60e:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 610:	fc040993          	addi	s3,s0,-64
  neg = 0;
 614:	86ce                	mv	a3,s3
  i = 0;
 616:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 618:	00000817          	auipc	a6,0x0
 61c:	5a880813          	addi	a6,a6,1448 # bc0 <digits>
 620:	88ba                	mv	a7,a4
 622:	0017051b          	addiw	a0,a4,1
 626:	872a                	mv	a4,a0
 628:	02c5f7bb          	remuw	a5,a1,a2
 62c:	1782                	slli	a5,a5,0x20
 62e:	9381                	srli	a5,a5,0x20
 630:	97c2                	add	a5,a5,a6
 632:	0007c783          	lbu	a5,0(a5)
 636:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 63a:	87ae                	mv	a5,a1
 63c:	02c5d5bb          	divuw	a1,a1,a2
 640:	0685                	addi	a3,a3,1
 642:	fcc7ffe3          	bgeu	a5,a2,620 <printint+0x2c>
  if(neg)
 646:	00030c63          	beqz	t1,65e <printint+0x6a>
    buf[i++] = '-';
 64a:	fd050793          	addi	a5,a0,-48
 64e:	00878533          	add	a0,a5,s0
 652:	02d00793          	li	a5,45
 656:	fef50823          	sb	a5,-16(a0)
 65a:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 65e:	02e05563          	blez	a4,688 <printint+0x94>
 662:	f426                	sd	s1,40(sp)
 664:	377d                	addiw	a4,a4,-1
 666:	00e984b3          	add	s1,s3,a4
 66a:	19fd                	addi	s3,s3,-1
 66c:	99ba                	add	s3,s3,a4
 66e:	1702                	slli	a4,a4,0x20
 670:	9301                	srli	a4,a4,0x20
 672:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 676:	0004c583          	lbu	a1,0(s1)
 67a:	854a                	mv	a0,s2
 67c:	f5bff0ef          	jal	5d6 <putc>
  while(--i >= 0)
 680:	14fd                	addi	s1,s1,-1
 682:	ff349ae3          	bne	s1,s3,676 <printint+0x82>
 686:	74a2                	ld	s1,40(sp)
}
 688:	70e2                	ld	ra,56(sp)
 68a:	7442                	ld	s0,48(sp)
 68c:	7902                	ld	s2,32(sp)
 68e:	69e2                	ld	s3,24(sp)
 690:	6121                	addi	sp,sp,64
 692:	8082                	ret
  neg = 0;
 694:	4301                	li	t1,0
 696:	bfad                	j	610 <printint+0x1c>

0000000000000698 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 698:	711d                	addi	sp,sp,-96
 69a:	ec86                	sd	ra,88(sp)
 69c:	e8a2                	sd	s0,80(sp)
 69e:	e4a6                	sd	s1,72(sp)
 6a0:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 6a2:	0005c483          	lbu	s1,0(a1)
 6a6:	20048963          	beqz	s1,8b8 <vprintf+0x220>
 6aa:	e0ca                	sd	s2,64(sp)
 6ac:	fc4e                	sd	s3,56(sp)
 6ae:	f852                	sd	s4,48(sp)
 6b0:	f456                	sd	s5,40(sp)
 6b2:	f05a                	sd	s6,32(sp)
 6b4:	ec5e                	sd	s7,24(sp)
 6b6:	e862                	sd	s8,16(sp)
 6b8:	8b2a                	mv	s6,a0
 6ba:	8a2e                	mv	s4,a1
 6bc:	8bb2                	mv	s7,a2
  state = 0;
 6be:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 6c0:	4901                	li	s2,0
 6c2:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 6c4:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 6c8:	06400c13          	li	s8,100
 6cc:	a00d                	j	6ee <vprintf+0x56>
        putc(fd, c0);
 6ce:	85a6                	mv	a1,s1
 6d0:	855a                	mv	a0,s6
 6d2:	f05ff0ef          	jal	5d6 <putc>
 6d6:	a019                	j	6dc <vprintf+0x44>
    } else if(state == '%'){
 6d8:	03598363          	beq	s3,s5,6fe <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 6dc:	0019079b          	addiw	a5,s2,1
 6e0:	893e                	mv	s2,a5
 6e2:	873e                	mv	a4,a5
 6e4:	97d2                	add	a5,a5,s4
 6e6:	0007c483          	lbu	s1,0(a5)
 6ea:	1c048063          	beqz	s1,8aa <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 6ee:	0004879b          	sext.w	a5,s1
    if(state == 0){
 6f2:	fe0993e3          	bnez	s3,6d8 <vprintf+0x40>
      if(c0 == '%'){
 6f6:	fd579ce3          	bne	a5,s5,6ce <vprintf+0x36>
        state = '%';
 6fa:	89be                	mv	s3,a5
 6fc:	b7c5                	j	6dc <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 6fe:	00ea06b3          	add	a3,s4,a4
 702:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 706:	1a060e63          	beqz	a2,8c2 <vprintf+0x22a>
      if(c0 == 'd'){
 70a:	03878763          	beq	a5,s8,738 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 70e:	f9478693          	addi	a3,a5,-108
 712:	0016b693          	seqz	a3,a3
 716:	f9c60593          	addi	a1,a2,-100
 71a:	e99d                	bnez	a1,750 <vprintf+0xb8>
 71c:	ca95                	beqz	a3,750 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 71e:	008b8493          	addi	s1,s7,8
 722:	4685                	li	a3,1
 724:	4629                	li	a2,10
 726:	000ba583          	lw	a1,0(s7)
 72a:	855a                	mv	a0,s6
 72c:	ec9ff0ef          	jal	5f4 <printint>
        i += 1;
 730:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 732:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 734:	4981                	li	s3,0
 736:	b75d                	j	6dc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 738:	008b8493          	addi	s1,s7,8
 73c:	4685                	li	a3,1
 73e:	4629                	li	a2,10
 740:	000ba583          	lw	a1,0(s7)
 744:	855a                	mv	a0,s6
 746:	eafff0ef          	jal	5f4 <printint>
 74a:	8ba6                	mv	s7,s1
      state = 0;
 74c:	4981                	li	s3,0
 74e:	b779                	j	6dc <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 750:	9752                	add	a4,a4,s4
 752:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 756:	f9460713          	addi	a4,a2,-108
 75a:	00173713          	seqz	a4,a4
 75e:	8f75                	and	a4,a4,a3
 760:	f9c58513          	addi	a0,a1,-100
 764:	16051963          	bnez	a0,8d6 <vprintf+0x23e>
 768:	16070763          	beqz	a4,8d6 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 76c:	008b8493          	addi	s1,s7,8
 770:	4685                	li	a3,1
 772:	4629                	li	a2,10
 774:	000ba583          	lw	a1,0(s7)
 778:	855a                	mv	a0,s6
 77a:	e7bff0ef          	jal	5f4 <printint>
        i += 2;
 77e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 780:	8ba6                	mv	s7,s1
      state = 0;
 782:	4981                	li	s3,0
        i += 2;
 784:	bfa1                	j	6dc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 786:	008b8493          	addi	s1,s7,8
 78a:	4681                	li	a3,0
 78c:	4629                	li	a2,10
 78e:	000ba583          	lw	a1,0(s7)
 792:	855a                	mv	a0,s6
 794:	e61ff0ef          	jal	5f4 <printint>
 798:	8ba6                	mv	s7,s1
      state = 0;
 79a:	4981                	li	s3,0
 79c:	b781                	j	6dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 79e:	008b8493          	addi	s1,s7,8
 7a2:	4681                	li	a3,0
 7a4:	4629                	li	a2,10
 7a6:	000ba583          	lw	a1,0(s7)
 7aa:	855a                	mv	a0,s6
 7ac:	e49ff0ef          	jal	5f4 <printint>
        i += 1;
 7b0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b2:	8ba6                	mv	s7,s1
      state = 0;
 7b4:	4981                	li	s3,0
 7b6:	b71d                	j	6dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b8:	008b8493          	addi	s1,s7,8
 7bc:	4681                	li	a3,0
 7be:	4629                	li	a2,10
 7c0:	000ba583          	lw	a1,0(s7)
 7c4:	855a                	mv	a0,s6
 7c6:	e2fff0ef          	jal	5f4 <printint>
        i += 2;
 7ca:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7cc:	8ba6                	mv	s7,s1
      state = 0;
 7ce:	4981                	li	s3,0
        i += 2;
 7d0:	b731                	j	6dc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 7d2:	008b8493          	addi	s1,s7,8
 7d6:	4681                	li	a3,0
 7d8:	4641                	li	a2,16
 7da:	000ba583          	lw	a1,0(s7)
 7de:	855a                	mv	a0,s6
 7e0:	e15ff0ef          	jal	5f4 <printint>
 7e4:	8ba6                	mv	s7,s1
      state = 0;
 7e6:	4981                	li	s3,0
 7e8:	bdd5                	j	6dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ea:	008b8493          	addi	s1,s7,8
 7ee:	4681                	li	a3,0
 7f0:	4641                	li	a2,16
 7f2:	000ba583          	lw	a1,0(s7)
 7f6:	855a                	mv	a0,s6
 7f8:	dfdff0ef          	jal	5f4 <printint>
        i += 1;
 7fc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 7fe:	8ba6                	mv	s7,s1
      state = 0;
 800:	4981                	li	s3,0
 802:	bde9                	j	6dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 804:	008b8493          	addi	s1,s7,8
 808:	4681                	li	a3,0
 80a:	4641                	li	a2,16
 80c:	000ba583          	lw	a1,0(s7)
 810:	855a                	mv	a0,s6
 812:	de3ff0ef          	jal	5f4 <printint>
        i += 2;
 816:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 818:	8ba6                	mv	s7,s1
      state = 0;
 81a:	4981                	li	s3,0
        i += 2;
 81c:	b5c1                	j	6dc <vprintf+0x44>
 81e:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 820:	008b8793          	addi	a5,s7,8
 824:	8cbe                	mv	s9,a5
 826:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 82a:	03000593          	li	a1,48
 82e:	855a                	mv	a0,s6
 830:	da7ff0ef          	jal	5d6 <putc>
  putc(fd, 'x');
 834:	07800593          	li	a1,120
 838:	855a                	mv	a0,s6
 83a:	d9dff0ef          	jal	5d6 <putc>
 83e:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 840:	00000b97          	auipc	s7,0x0
 844:	380b8b93          	addi	s7,s7,896 # bc0 <digits>
 848:	03c9d793          	srli	a5,s3,0x3c
 84c:	97de                	add	a5,a5,s7
 84e:	0007c583          	lbu	a1,0(a5)
 852:	855a                	mv	a0,s6
 854:	d83ff0ef          	jal	5d6 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 858:	0992                	slli	s3,s3,0x4
 85a:	34fd                	addiw	s1,s1,-1
 85c:	f4f5                	bnez	s1,848 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 85e:	8be6                	mv	s7,s9
      state = 0;
 860:	4981                	li	s3,0
 862:	6ca2                	ld	s9,8(sp)
 864:	bda5                	j	6dc <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 866:	008b8993          	addi	s3,s7,8
 86a:	000bb483          	ld	s1,0(s7)
 86e:	cc91                	beqz	s1,88a <vprintf+0x1f2>
        for(; *s; s++)
 870:	0004c583          	lbu	a1,0(s1)
 874:	c985                	beqz	a1,8a4 <vprintf+0x20c>
          putc(fd, *s);
 876:	855a                	mv	a0,s6
 878:	d5fff0ef          	jal	5d6 <putc>
        for(; *s; s++)
 87c:	0485                	addi	s1,s1,1
 87e:	0004c583          	lbu	a1,0(s1)
 882:	f9f5                	bnez	a1,876 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 884:	8bce                	mv	s7,s3
      state = 0;
 886:	4981                	li	s3,0
 888:	bd91                	j	6dc <vprintf+0x44>
          s = "(null)";
 88a:	00000497          	auipc	s1,0x0
 88e:	32e48493          	addi	s1,s1,814 # bb8 <malloc+0x19a>
        for(; *s; s++)
 892:	02800593          	li	a1,40
 896:	b7c5                	j	876 <vprintf+0x1de>
        putc(fd, '%');
 898:	85be                	mv	a1,a5
 89a:	855a                	mv	a0,s6
 89c:	d3bff0ef          	jal	5d6 <putc>
      state = 0;
 8a0:	4981                	li	s3,0
 8a2:	bd2d                	j	6dc <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 8a4:	8bce                	mv	s7,s3
      state = 0;
 8a6:	4981                	li	s3,0
 8a8:	bd15                	j	6dc <vprintf+0x44>
 8aa:	6906                	ld	s2,64(sp)
 8ac:	79e2                	ld	s3,56(sp)
 8ae:	7a42                	ld	s4,48(sp)
 8b0:	7aa2                	ld	s5,40(sp)
 8b2:	7b02                	ld	s6,32(sp)
 8b4:	6be2                	ld	s7,24(sp)
 8b6:	6c42                	ld	s8,16(sp)
    }
  }
}
 8b8:	60e6                	ld	ra,88(sp)
 8ba:	6446                	ld	s0,80(sp)
 8bc:	64a6                	ld	s1,72(sp)
 8be:	6125                	addi	sp,sp,96
 8c0:	8082                	ret
      if(c0 == 'd'){
 8c2:	06400713          	li	a4,100
 8c6:	e6e789e3          	beq	a5,a4,738 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 8ca:	f9478693          	addi	a3,a5,-108
 8ce:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 8d2:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8d4:	4701                	li	a4,0
      } else if(c0 == 'u'){
 8d6:	07500513          	li	a0,117
 8da:	eaa786e3          	beq	a5,a0,786 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 8de:	f8b60513          	addi	a0,a2,-117
 8e2:	e119                	bnez	a0,8e8 <vprintf+0x250>
 8e4:	ea069de3          	bnez	a3,79e <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 8e8:	f8b58513          	addi	a0,a1,-117
 8ec:	e119                	bnez	a0,8f2 <vprintf+0x25a>
 8ee:	ec0715e3          	bnez	a4,7b8 <vprintf+0x120>
      } else if(c0 == 'x'){
 8f2:	07800513          	li	a0,120
 8f6:	eca78ee3          	beq	a5,a0,7d2 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 8fa:	f8860613          	addi	a2,a2,-120
 8fe:	e219                	bnez	a2,904 <vprintf+0x26c>
 900:	ee0695e3          	bnez	a3,7ea <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 904:	f8858593          	addi	a1,a1,-120
 908:	e199                	bnez	a1,90e <vprintf+0x276>
 90a:	ee071de3          	bnez	a4,804 <vprintf+0x16c>
      } else if(c0 == 'p'){
 90e:	07000713          	li	a4,112
 912:	f0e786e3          	beq	a5,a4,81e <vprintf+0x186>
      } else if(c0 == 's'){
 916:	07300713          	li	a4,115
 91a:	f4e786e3          	beq	a5,a4,866 <vprintf+0x1ce>
      } else if(c0 == '%'){
 91e:	02500713          	li	a4,37
 922:	f6e78be3          	beq	a5,a4,898 <vprintf+0x200>
        putc(fd, '%');
 926:	02500593          	li	a1,37
 92a:	855a                	mv	a0,s6
 92c:	cabff0ef          	jal	5d6 <putc>
        putc(fd, c0);
 930:	85a6                	mv	a1,s1
 932:	855a                	mv	a0,s6
 934:	ca3ff0ef          	jal	5d6 <putc>
      state = 0;
 938:	4981                	li	s3,0
 93a:	b34d                	j	6dc <vprintf+0x44>

000000000000093c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 93c:	715d                	addi	sp,sp,-80
 93e:	ec06                	sd	ra,24(sp)
 940:	e822                	sd	s0,16(sp)
 942:	1000                	addi	s0,sp,32
 944:	e010                	sd	a2,0(s0)
 946:	e414                	sd	a3,8(s0)
 948:	e818                	sd	a4,16(s0)
 94a:	ec1c                	sd	a5,24(s0)
 94c:	03043023          	sd	a6,32(s0)
 950:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 954:	8622                	mv	a2,s0
 956:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 95a:	d3fff0ef          	jal	698 <vprintf>
}
 95e:	60e2                	ld	ra,24(sp)
 960:	6442                	ld	s0,16(sp)
 962:	6161                	addi	sp,sp,80
 964:	8082                	ret

0000000000000966 <printf>:

void
printf(const char *fmt, ...)
{
 966:	711d                	addi	sp,sp,-96
 968:	ec06                	sd	ra,24(sp)
 96a:	e822                	sd	s0,16(sp)
 96c:	1000                	addi	s0,sp,32
 96e:	e40c                	sd	a1,8(s0)
 970:	e810                	sd	a2,16(s0)
 972:	ec14                	sd	a3,24(s0)
 974:	f018                	sd	a4,32(s0)
 976:	f41c                	sd	a5,40(s0)
 978:	03043823          	sd	a6,48(s0)
 97c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 980:	00840613          	addi	a2,s0,8
 984:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 988:	85aa                	mv	a1,a0
 98a:	4505                	li	a0,1
 98c:	d0dff0ef          	jal	698 <vprintf>
}
 990:	60e2                	ld	ra,24(sp)
 992:	6442                	ld	s0,16(sp)
 994:	6125                	addi	sp,sp,96
 996:	8082                	ret

0000000000000998 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 998:	1141                	addi	sp,sp,-16
 99a:	e406                	sd	ra,8(sp)
 99c:	e022                	sd	s0,0(sp)
 99e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 9a0:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9a4:	00000797          	auipc	a5,0x0
 9a8:	6747b783          	ld	a5,1652(a5) # 1018 <freep>
 9ac:	a039                	j	9ba <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9ae:	6398                	ld	a4,0(a5)
 9b0:	00e7e463          	bltu	a5,a4,9b8 <free+0x20>
 9b4:	00e6ea63          	bltu	a3,a4,9c8 <free+0x30>
{
 9b8:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9ba:	fed7fae3          	bgeu	a5,a3,9ae <free+0x16>
 9be:	6398                	ld	a4,0(a5)
 9c0:	00e6e463          	bltu	a3,a4,9c8 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9c4:	fee7eae3          	bltu	a5,a4,9b8 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 9c8:	ff852583          	lw	a1,-8(a0)
 9cc:	6390                	ld	a2,0(a5)
 9ce:	02059813          	slli	a6,a1,0x20
 9d2:	01c85713          	srli	a4,a6,0x1c
 9d6:	9736                	add	a4,a4,a3
 9d8:	02e60563          	beq	a2,a4,a02 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 9dc:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 9e0:	4790                	lw	a2,8(a5)
 9e2:	02061593          	slli	a1,a2,0x20
 9e6:	01c5d713          	srli	a4,a1,0x1c
 9ea:	973e                	add	a4,a4,a5
 9ec:	02e68263          	beq	a3,a4,a10 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 9f0:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 9f2:	00000717          	auipc	a4,0x0
 9f6:	62f73323          	sd	a5,1574(a4) # 1018 <freep>
}
 9fa:	60a2                	ld	ra,8(sp)
 9fc:	6402                	ld	s0,0(sp)
 9fe:	0141                	addi	sp,sp,16
 a00:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 a02:	4618                	lw	a4,8(a2)
 a04:	9f2d                	addw	a4,a4,a1
 a06:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a0a:	6398                	ld	a4,0(a5)
 a0c:	6310                	ld	a2,0(a4)
 a0e:	b7f9                	j	9dc <free+0x44>
    p->s.size += bp->s.size;
 a10:	ff852703          	lw	a4,-8(a0)
 a14:	9f31                	addw	a4,a4,a2
 a16:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 a18:	ff053683          	ld	a3,-16(a0)
 a1c:	bfd1                	j	9f0 <free+0x58>

0000000000000a1e <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a1e:	7139                	addi	sp,sp,-64
 a20:	fc06                	sd	ra,56(sp)
 a22:	f822                	sd	s0,48(sp)
 a24:	f04a                	sd	s2,32(sp)
 a26:	ec4e                	sd	s3,24(sp)
 a28:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a2a:	02051993          	slli	s3,a0,0x20
 a2e:	0209d993          	srli	s3,s3,0x20
 a32:	09bd                	addi	s3,s3,15
 a34:	0049d993          	srli	s3,s3,0x4
 a38:	2985                	addiw	s3,s3,1
 a3a:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 a3c:	00000517          	auipc	a0,0x0
 a40:	5dc53503          	ld	a0,1500(a0) # 1018 <freep>
 a44:	c905                	beqz	a0,a74 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a46:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a48:	4798                	lw	a4,8(a5)
 a4a:	09377663          	bgeu	a4,s3,ad6 <malloc+0xb8>
 a4e:	f426                	sd	s1,40(sp)
 a50:	e852                	sd	s4,16(sp)
 a52:	e456                	sd	s5,8(sp)
 a54:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a56:	8a4e                	mv	s4,s3
 a58:	6705                	lui	a4,0x1
 a5a:	00e9f363          	bgeu	s3,a4,a60 <malloc+0x42>
 a5e:	6a05                	lui	s4,0x1
 a60:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a64:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a68:	00000497          	auipc	s1,0x0
 a6c:	5b048493          	addi	s1,s1,1456 # 1018 <freep>
  if(p == (char*)-1)
 a70:	5afd                	li	s5,-1
 a72:	a83d                	j	ab0 <malloc+0x92>
 a74:	f426                	sd	s1,40(sp)
 a76:	e852                	sd	s4,16(sp)
 a78:	e456                	sd	s5,8(sp)
 a7a:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a7c:	00000797          	auipc	a5,0x0
 a80:	5e478793          	addi	a5,a5,1508 # 1060 <base>
 a84:	00000717          	auipc	a4,0x0
 a88:	58f73a23          	sd	a5,1428(a4) # 1018 <freep>
 a8c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a8e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a92:	b7d1                	j	a56 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 a94:	6398                	ld	a4,0(a5)
 a96:	e118                	sd	a4,0(a0)
 a98:	a899                	j	aee <malloc+0xd0>
  hp->s.size = nu;
 a9a:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a9e:	0541                	addi	a0,a0,16
 aa0:	ef9ff0ef          	jal	998 <free>
  return freep;
 aa4:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 aa6:	c125                	beqz	a0,b06 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 aa8:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 aaa:	4798                	lw	a4,8(a5)
 aac:	03277163          	bgeu	a4,s2,ace <malloc+0xb0>
    if(p == freep)
 ab0:	6098                	ld	a4,0(s1)
 ab2:	853e                	mv	a0,a5
 ab4:	fef71ae3          	bne	a4,a5,aa8 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 ab8:	8552                	mv	a0,s4
 aba:	afdff0ef          	jal	5b6 <sbrk>
  if(p == (char*)-1)
 abe:	fd551ee3          	bne	a0,s5,a9a <malloc+0x7c>
        return 0;
 ac2:	4501                	li	a0,0
 ac4:	74a2                	ld	s1,40(sp)
 ac6:	6a42                	ld	s4,16(sp)
 ac8:	6aa2                	ld	s5,8(sp)
 aca:	6b02                	ld	s6,0(sp)
 acc:	a03d                	j	afa <malloc+0xdc>
 ace:	74a2                	ld	s1,40(sp)
 ad0:	6a42                	ld	s4,16(sp)
 ad2:	6aa2                	ld	s5,8(sp)
 ad4:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 ad6:	fae90fe3          	beq	s2,a4,a94 <malloc+0x76>
        p->s.size -= nunits;
 ada:	4137073b          	subw	a4,a4,s3
 ade:	c798                	sw	a4,8(a5)
        p += p->s.size;
 ae0:	02071693          	slli	a3,a4,0x20
 ae4:	01c6d713          	srli	a4,a3,0x1c
 ae8:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 aea:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 aee:	00000717          	auipc	a4,0x0
 af2:	52a73523          	sd	a0,1322(a4) # 1018 <freep>
      return (void*)(p + 1);
 af6:	01078513          	addi	a0,a5,16
  }
}
 afa:	70e2                	ld	ra,56(sp)
 afc:	7442                	ld	s0,48(sp)
 afe:	7902                	ld	s2,32(sp)
 b00:	69e2                	ld	s3,24(sp)
 b02:	6121                	addi	sp,sp,64
 b04:	8082                	ret
 b06:	74a2                	ld	s1,40(sp)
 b08:	6a42                	ld	s4,16(sp)
 b0a:	6aa2                	ld	s5,8(sp)
 b0c:	6b02                	ld	s6,0(sp)
 b0e:	b7f5                	j	afa <malloc+0xdc>
