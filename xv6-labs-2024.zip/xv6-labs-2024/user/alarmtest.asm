
user/_alarmtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <periodic>:

volatile static int count;

void
periodic()
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  count = count + 1;
   8:	00001797          	auipc	a5,0x1
   c:	ff87a783          	lw	a5,-8(a5) # 1000 <count>
  10:	2785                	addiw	a5,a5,1
  12:	00001717          	auipc	a4,0x1
  16:	fef72723          	sw	a5,-18(a4) # 1000 <count>
  printf("alarm!\n");
  1a:	00001517          	auipc	a0,0x1
  1e:	c8650513          	addi	a0,a0,-890 # ca0 <malloc+0xfc>
  22:	2cb000ef          	jal	aec <printf>
  sigreturn();
  26:	72e000ef          	jal	754 <sigreturn>
}
  2a:	60a2                	ld	ra,8(sp)
  2c:	6402                	ld	s0,0(sp)
  2e:	0141                	addi	sp,sp,16
  30:	8082                	ret

0000000000000032 <slow_handler>:
  }
}

void
slow_handler()
{
  32:	1101                	addi	sp,sp,-32
  34:	ec06                	sd	ra,24(sp)
  36:	e822                	sd	s0,16(sp)
  38:	e426                	sd	s1,8(sp)
  3a:	1000                	addi	s0,sp,32
  count++;
  3c:	00001497          	auipc	s1,0x1
  40:	fc448493          	addi	s1,s1,-60 # 1000 <count>
  44:	00001797          	auipc	a5,0x1
  48:	fbc7a783          	lw	a5,-68(a5) # 1000 <count>
  4c:	2785                	addiw	a5,a5,1
  4e:	c09c                	sw	a5,0(s1)
  printf("alarm!\n");
  50:	00001517          	auipc	a0,0x1
  54:	c5050513          	addi	a0,a0,-944 # ca0 <malloc+0xfc>
  58:	295000ef          	jal	aec <printf>
  if (count > 1) {
  5c:	4098                	lw	a4,0(s1)
  5e:	2701                	sext.w	a4,a4
  60:	4685                	li	a3,1
  62:	1dcd67b7          	lui	a5,0x1dcd6
  66:	50078793          	addi	a5,a5,1280 # 1dcd6500 <base+0x1dcd54f0>
  6a:	02e6c063          	blt	a3,a4,8a <slow_handler+0x58>
    printf("test2 failed: alarm handler called more than once\n");
    exit(1);
  }
  for (int i = 0; i < 1000*500000; i++) {
    asm volatile("nop"); // avoid compiler optimizing away loop
  6e:	0001                	nop
  for (int i = 0; i < 1000*500000; i++) {
  70:	37fd                	addiw	a5,a5,-1
  72:	fff5                	bnez	a5,6e <slow_handler+0x3c>
  }
  sigalarm(0, 0);
  74:	4581                	li	a1,0
  76:	4501                	li	a0,0
  78:	6d4000ef          	jal	74c <sigalarm>
  sigreturn();
  7c:	6d8000ef          	jal	754 <sigreturn>
}
  80:	60e2                	ld	ra,24(sp)
  82:	6442                	ld	s0,16(sp)
  84:	64a2                	ld	s1,8(sp)
  86:	6105                	addi	sp,sp,32
  88:	8082                	ret
    printf("test2 failed: alarm handler called more than once\n");
  8a:	00001517          	auipc	a0,0x1
  8e:	c1e50513          	addi	a0,a0,-994 # ca8 <malloc+0x104>
  92:	25b000ef          	jal	aec <printf>
    exit(1);
  96:	4505                	li	a0,1
  98:	614000ef          	jal	6ac <exit>

000000000000009c <dummy_handler>:
//
// dummy alarm handler; after running immediately uninstall
// itself and finish signal handling
void
dummy_handler()
{
  9c:	1141                	addi	sp,sp,-16
  9e:	e406                	sd	ra,8(sp)
  a0:	e022                	sd	s0,0(sp)
  a2:	0800                	addi	s0,sp,16
  sigalarm(0, 0);
  a4:	4581                	li	a1,0
  a6:	4501                	li	a0,0
  a8:	6a4000ef          	jal	74c <sigalarm>
  sigreturn();
  ac:	6a8000ef          	jal	754 <sigreturn>
}
  b0:	60a2                	ld	ra,8(sp)
  b2:	6402                	ld	s0,0(sp)
  b4:	0141                	addi	sp,sp,16
  b6:	8082                	ret

00000000000000b8 <test0>:
{
  b8:	715d                	addi	sp,sp,-80
  ba:	e486                	sd	ra,72(sp)
  bc:	e0a2                	sd	s0,64(sp)
  be:	fc26                	sd	s1,56(sp)
  c0:	f84a                	sd	s2,48(sp)
  c2:	f44e                	sd	s3,40(sp)
  c4:	f052                	sd	s4,32(sp)
  c6:	ec56                	sd	s5,24(sp)
  c8:	e85a                	sd	s6,16(sp)
  ca:	e45e                	sd	s7,8(sp)
  cc:	e062                	sd	s8,0(sp)
  ce:	0880                	addi	s0,sp,80
  printf("test0 start\n");
  d0:	00001517          	auipc	a0,0x1
  d4:	c1050513          	addi	a0,a0,-1008 # ce0 <malloc+0x13c>
  d8:	215000ef          	jal	aec <printf>
  count = 0;
  dc:	00001797          	auipc	a5,0x1
  e0:	f207a223          	sw	zero,-220(a5) # 1000 <count>
  sigalarm(2, periodic);
  e4:	00000597          	auipc	a1,0x0
  e8:	f1c58593          	addi	a1,a1,-228 # 0 <periodic>
  ec:	4509                	li	a0,2
  ee:	65e000ef          	jal	74c <sigalarm>
  for(i = 0; i < 1000*500000; i++){
  f2:	4481                	li	s1,0
    if((i % 1000000) == 0)
  f4:	431be9b7          	lui	s3,0x431be
  f8:	e8398993          	addi	s3,s3,-381 # 431bde83 <base+0x431bce73>
  fc:	000f4937          	lui	s2,0xf4
 100:	2409091b          	addiw	s2,s2,576 # f4240 <base+0xf3230>
      write(2, ".", 1);
 104:	4c05                	li	s8,1
 106:	00001b97          	auipc	s7,0x1
 10a:	beab8b93          	addi	s7,s7,-1046 # cf0 <malloc+0x14c>
 10e:	4b09                	li	s6,2
    if(count > 0)
 110:	00001a97          	auipc	s5,0x1
 114:	ef0a8a93          	addi	s5,s5,-272 # 1000 <count>
  for(i = 0; i < 1000*500000; i++){
 118:	1dcd6a37          	lui	s4,0x1dcd6
 11c:	500a0a13          	addi	s4,s4,1280 # 1dcd6500 <base+0x1dcd54f0>
 120:	a809                	j	132 <test0+0x7a>
    if(count > 0)
 122:	000aa783          	lw	a5,0(s5)
 126:	2781                	sext.w	a5,a5
 128:	02f04663          	bgtz	a5,154 <test0+0x9c>
  for(i = 0; i < 1000*500000; i++){
 12c:	2485                	addiw	s1,s1,1
 12e:	03448363          	beq	s1,s4,154 <test0+0x9c>
    if((i % 1000000) == 0)
 132:	033487b3          	mul	a5,s1,s3
 136:	97c9                	srai	a5,a5,0x32
 138:	41f4d71b          	sraiw	a4,s1,0x1f
 13c:	9f99                	subw	a5,a5,a4
 13e:	02f907bb          	mulw	a5,s2,a5
 142:	40f487bb          	subw	a5,s1,a5
 146:	fff1                	bnez	a5,122 <test0+0x6a>
      write(2, ".", 1);
 148:	8662                	mv	a2,s8
 14a:	85de                	mv	a1,s7
 14c:	855a                	mv	a0,s6
 14e:	57e000ef          	jal	6cc <write>
 152:	bfc1                	j	122 <test0+0x6a>
  sigalarm(0, 0);
 154:	4581                	li	a1,0
 156:	4501                	li	a0,0
 158:	5f4000ef          	jal	74c <sigalarm>
  if(count > 0){
 15c:	00001797          	auipc	a5,0x1
 160:	ea47a783          	lw	a5,-348(a5) # 1000 <count>
 164:	02f05463          	blez	a5,18c <test0+0xd4>
    printf("test0 passed\n");
 168:	00001517          	auipc	a0,0x1
 16c:	b9050513          	addi	a0,a0,-1136 # cf8 <malloc+0x154>
 170:	17d000ef          	jal	aec <printf>
}
 174:	60a6                	ld	ra,72(sp)
 176:	6406                	ld	s0,64(sp)
 178:	74e2                	ld	s1,56(sp)
 17a:	7942                	ld	s2,48(sp)
 17c:	79a2                	ld	s3,40(sp)
 17e:	7a02                	ld	s4,32(sp)
 180:	6ae2                	ld	s5,24(sp)
 182:	6b42                	ld	s6,16(sp)
 184:	6ba2                	ld	s7,8(sp)
 186:	6c02                	ld	s8,0(sp)
 188:	6161                	addi	sp,sp,80
 18a:	8082                	ret
    printf("\ntest0 failed: the kernel never called the alarm handler\n");
 18c:	00001517          	auipc	a0,0x1
 190:	b7c50513          	addi	a0,a0,-1156 # d08 <malloc+0x164>
 194:	159000ef          	jal	aec <printf>
}
 198:	bff1                	j	174 <test0+0xbc>

000000000000019a <foo>:
void __attribute__ ((noinline)) foo(int i, int *j) {
 19a:	1101                	addi	sp,sp,-32
 19c:	ec06                	sd	ra,24(sp)
 19e:	e822                	sd	s0,16(sp)
 1a0:	e426                	sd	s1,8(sp)
 1a2:	1000                	addi	s0,sp,32
 1a4:	84ae                	mv	s1,a1
  if((i % 2500000) == 0) {
 1a6:	6b5fd7b7          	lui	a5,0x6b5fd
 1aa:	a6b78793          	addi	a5,a5,-1429 # 6b5fca6b <base+0x6b5fba5b>
 1ae:	02f507b3          	mul	a5,a0,a5
 1b2:	97d1                	srai	a5,a5,0x34
 1b4:	41f5571b          	sraiw	a4,a0,0x1f
 1b8:	9f99                	subw	a5,a5,a4
 1ba:	00262737          	lui	a4,0x262
 1be:	5a07071b          	addiw	a4,a4,1440 # 2625a0 <base+0x261590>
 1c2:	02f707bb          	mulw	a5,a4,a5
 1c6:	9d1d                	subw	a0,a0,a5
 1c8:	c909                	beqz	a0,1da <foo+0x40>
  *j += 1;
 1ca:	409c                	lw	a5,0(s1)
 1cc:	2785                	addiw	a5,a5,1
 1ce:	c09c                	sw	a5,0(s1)
}
 1d0:	60e2                	ld	ra,24(sp)
 1d2:	6442                	ld	s0,16(sp)
 1d4:	64a2                	ld	s1,8(sp)
 1d6:	6105                	addi	sp,sp,32
 1d8:	8082                	ret
    write(2, ".", 1);
 1da:	4605                	li	a2,1
 1dc:	00001597          	auipc	a1,0x1
 1e0:	b1458593          	addi	a1,a1,-1260 # cf0 <malloc+0x14c>
 1e4:	4509                	li	a0,2
 1e6:	4e6000ef          	jal	6cc <write>
 1ea:	b7c5                	j	1ca <foo+0x30>

00000000000001ec <test1>:
{
 1ec:	715d                	addi	sp,sp,-80
 1ee:	e486                	sd	ra,72(sp)
 1f0:	e0a2                	sd	s0,64(sp)
 1f2:	fc26                	sd	s1,56(sp)
 1f4:	f84a                	sd	s2,48(sp)
 1f6:	f44e                	sd	s3,40(sp)
 1f8:	f052                	sd	s4,32(sp)
 1fa:	ec56                	sd	s5,24(sp)
 1fc:	0880                	addi	s0,sp,80
  printf("test1 start\n");
 1fe:	00001517          	auipc	a0,0x1
 202:	b4a50513          	addi	a0,a0,-1206 # d48 <malloc+0x1a4>
 206:	0e7000ef          	jal	aec <printf>
  count = 0;
 20a:	00001797          	auipc	a5,0x1
 20e:	de07ab23          	sw	zero,-522(a5) # 1000 <count>
  j = 0;
 212:	fa042e23          	sw	zero,-68(s0)
  sigalarm(2, periodic);
 216:	00000597          	auipc	a1,0x0
 21a:	dea58593          	addi	a1,a1,-534 # 0 <periodic>
 21e:	4509                	li	a0,2
 220:	52c000ef          	jal	74c <sigalarm>
  for(i = 0; i < 500000000; i++){
 224:	4481                	li	s1,0
    if(count >= 10)
 226:	00001a17          	auipc	s4,0x1
 22a:	ddaa0a13          	addi	s4,s4,-550 # 1000 <count>
 22e:	49a5                	li	s3,9
    foo(i, &j);
 230:	fbc40a93          	addi	s5,s0,-68
  for(i = 0; i < 500000000; i++){
 234:	1dcd6937          	lui	s2,0x1dcd6
 238:	50090913          	addi	s2,s2,1280 # 1dcd6500 <base+0x1dcd54f0>
    if(count >= 10)
 23c:	000a2783          	lw	a5,0(s4)
 240:	2781                	sext.w	a5,a5
 242:	00f9c963          	blt	s3,a5,254 <test1+0x68>
    foo(i, &j);
 246:	85d6                	mv	a1,s5
 248:	8526                	mv	a0,s1
 24a:	f51ff0ef          	jal	19a <foo>
  for(i = 0; i < 500000000; i++){
 24e:	2485                	addiw	s1,s1,1
 250:	ff2496e3          	bne	s1,s2,23c <test1+0x50>
  if(count < 10){
 254:	00001717          	auipc	a4,0x1
 258:	dac72703          	lw	a4,-596(a4) # 1000 <count>
 25c:	47a5                	li	a5,9
 25e:	02e7d563          	bge	a5,a4,288 <test1+0x9c>
  } else if(i != j){
 262:	fbc42783          	lw	a5,-68(s0)
 266:	02978863          	beq	a5,s1,296 <test1+0xaa>
    printf("\ntest1 failed: foo() executed fewer times than it was called\n");
 26a:	00001517          	auipc	a0,0x1
 26e:	b1e50513          	addi	a0,a0,-1250 # d88 <malloc+0x1e4>
 272:	07b000ef          	jal	aec <printf>
}
 276:	60a6                	ld	ra,72(sp)
 278:	6406                	ld	s0,64(sp)
 27a:	74e2                	ld	s1,56(sp)
 27c:	7942                	ld	s2,48(sp)
 27e:	79a2                	ld	s3,40(sp)
 280:	7a02                	ld	s4,32(sp)
 282:	6ae2                	ld	s5,24(sp)
 284:	6161                	addi	sp,sp,80
 286:	8082                	ret
    printf("\ntest1 failed: too few calls to the handler\n");
 288:	00001517          	auipc	a0,0x1
 28c:	ad050513          	addi	a0,a0,-1328 # d58 <malloc+0x1b4>
 290:	05d000ef          	jal	aec <printf>
 294:	b7cd                	j	276 <test1+0x8a>
    printf("test1 passed\n");
 296:	00001517          	auipc	a0,0x1
 29a:	b3250513          	addi	a0,a0,-1230 # dc8 <malloc+0x224>
 29e:	04f000ef          	jal	aec <printf>
}
 2a2:	bfd1                	j	276 <test1+0x8a>

00000000000002a4 <test2>:
{
 2a4:	711d                	addi	sp,sp,-96
 2a6:	ec86                	sd	ra,88(sp)
 2a8:	e8a2                	sd	s0,80(sp)
 2aa:	1080                	addi	s0,sp,96
  printf("test2 start\n");
 2ac:	00001517          	auipc	a0,0x1
 2b0:	b2c50513          	addi	a0,a0,-1236 # dd8 <malloc+0x234>
 2b4:	039000ef          	jal	aec <printf>
  if ((pid = fork()) < 0) {
 2b8:	3ec000ef          	jal	6a4 <fork>
 2bc:	04054e63          	bltz	a0,318 <test2+0x74>
 2c0:	e4a6                	sd	s1,72(sp)
 2c2:	84aa                	mv	s1,a0
  if (pid == 0) {
 2c4:	e569                	bnez	a0,38e <test2+0xea>
 2c6:	e0ca                	sd	s2,64(sp)
 2c8:	fc4e                	sd	s3,56(sp)
 2ca:	f852                	sd	s4,48(sp)
 2cc:	f456                	sd	s5,40(sp)
 2ce:	f05a                	sd	s6,32(sp)
 2d0:	ec5e                	sd	s7,24(sp)
 2d2:	e862                	sd	s8,16(sp)
    count = 0;
 2d4:	00001797          	auipc	a5,0x1
 2d8:	d207a623          	sw	zero,-724(a5) # 1000 <count>
    sigalarm(2, slow_handler);
 2dc:	00000597          	auipc	a1,0x0
 2e0:	d5658593          	addi	a1,a1,-682 # 32 <slow_handler>
 2e4:	4509                	li	a0,2
 2e6:	466000ef          	jal	74c <sigalarm>
      if((i % 1000000) == 0)
 2ea:	431be9b7          	lui	s3,0x431be
 2ee:	e8398993          	addi	s3,s3,-381 # 431bde83 <base+0x431bce73>
 2f2:	000f4937          	lui	s2,0xf4
 2f6:	2409091b          	addiw	s2,s2,576 # f4240 <base+0xf3230>
        write(2, ".", 1);
 2fa:	4c05                	li	s8,1
 2fc:	00001b97          	auipc	s7,0x1
 300:	9f4b8b93          	addi	s7,s7,-1548 # cf0 <malloc+0x14c>
 304:	4b09                	li	s6,2
      if(count > 0)
 306:	00001a97          	auipc	s5,0x1
 30a:	cfaa8a93          	addi	s5,s5,-774 # 1000 <count>
    for(i = 0; i < 1000*500000; i++){
 30e:	1dcd6a37          	lui	s4,0x1dcd6
 312:	500a0a13          	addi	s4,s4,1280 # 1dcd6500 <base+0x1dcd54f0>
 316:	a815                	j	34a <test2+0xa6>
    printf("test2: fork failed\n");
 318:	00001517          	auipc	a0,0x1
 31c:	ad050513          	addi	a0,a0,-1328 # de8 <malloc+0x244>
 320:	7cc000ef          	jal	aec <printf>
  wait(&status);
 324:	fac40513          	addi	a0,s0,-84
 328:	38c000ef          	jal	6b4 <wait>
  if (status == 0) {
 32c:	fac42783          	lw	a5,-84(s0)
 330:	c3ad                	beqz	a5,392 <test2+0xee>
}
 332:	60e6                	ld	ra,88(sp)
 334:	6446                	ld	s0,80(sp)
 336:	6125                	addi	sp,sp,96
 338:	8082                	ret
      if(count > 0)
 33a:	000aa783          	lw	a5,0(s5)
 33e:	2781                	sext.w	a5,a5
 340:	02f04663          	bgtz	a5,36c <test2+0xc8>
    for(i = 0; i < 1000*500000; i++){
 344:	2485                	addiw	s1,s1,1
 346:	03448363          	beq	s1,s4,36c <test2+0xc8>
      if((i % 1000000) == 0)
 34a:	033487b3          	mul	a5,s1,s3
 34e:	97c9                	srai	a5,a5,0x32
 350:	41f4d71b          	sraiw	a4,s1,0x1f
 354:	9f99                	subw	a5,a5,a4
 356:	02f907bb          	mulw	a5,s2,a5
 35a:	40f487bb          	subw	a5,s1,a5
 35e:	fff1                	bnez	a5,33a <test2+0x96>
        write(2, ".", 1);
 360:	8662                	mv	a2,s8
 362:	85de                	mv	a1,s7
 364:	855a                	mv	a0,s6
 366:	366000ef          	jal	6cc <write>
 36a:	bfc1                	j	33a <test2+0x96>
    if (count == 0) {
 36c:	00001797          	auipc	a5,0x1
 370:	c947a783          	lw	a5,-876(a5) # 1000 <count>
 374:	eb91                	bnez	a5,388 <test2+0xe4>
      printf("\ntest2 failed: alarm not called\n");
 376:	00001517          	auipc	a0,0x1
 37a:	a8a50513          	addi	a0,a0,-1398 # e00 <malloc+0x25c>
 37e:	76e000ef          	jal	aec <printf>
      exit(1);
 382:	4505                	li	a0,1
 384:	328000ef          	jal	6ac <exit>
    exit(0);
 388:	4501                	li	a0,0
 38a:	322000ef          	jal	6ac <exit>
 38e:	64a6                	ld	s1,72(sp)
 390:	bf51                	j	324 <test2+0x80>
    printf("test2 passed\n");
 392:	00001517          	auipc	a0,0x1
 396:	a9650513          	addi	a0,a0,-1386 # e28 <malloc+0x284>
 39a:	752000ef          	jal	aec <printf>
}
 39e:	bf51                	j	332 <test2+0x8e>

00000000000003a0 <test3>:
//
// tests that the return from sys_sigreturn() does not
// modify the a0 register
void
test3()
{
 3a0:	1141                	addi	sp,sp,-16
 3a2:	e406                	sd	ra,8(sp)
 3a4:	e022                	sd	s0,0(sp)
 3a6:	0800                	addi	s0,sp,16
  uint64 a0;

  sigalarm(1, dummy_handler);
 3a8:	00000597          	auipc	a1,0x0
 3ac:	cf458593          	addi	a1,a1,-780 # 9c <dummy_handler>
 3b0:	4505                	li	a0,1
 3b2:	39a000ef          	jal	74c <sigalarm>
  printf("test3 start\n");
 3b6:	00001517          	auipc	a0,0x1
 3ba:	a8250513          	addi	a0,a0,-1406 # e38 <malloc+0x294>
 3be:	72e000ef          	jal	aec <printf>

  asm volatile("lui a5, 0");
 3c2:	000007b7          	lui	a5,0x0
  asm volatile("addi a0, a5, 0xac" : : : "a0");
 3c6:	0ac78513          	addi	a0,a5,172 # ac <dummy_handler+0x10>
 3ca:	1dcd67b7          	lui	a5,0x1dcd6
 3ce:	50078793          	addi	a5,a5,1280 # 1dcd6500 <base+0x1dcd54f0>
  for(int i = 0; i < 500000000; i++)
 3d2:	37fd                	addiw	a5,a5,-1
 3d4:	fffd                	bnez	a5,3d2 <test3+0x32>
    ;
  asm volatile("mv %0, a0" : "=r" (a0) );
 3d6:	872a                	mv	a4,a0

  if(a0 != 0xac)
 3d8:	0ac00793          	li	a5,172
 3dc:	00f70c63          	beq	a4,a5,3f4 <test3+0x54>
    printf("test3 failed: register a0 changed\n");
 3e0:	00001517          	auipc	a0,0x1
 3e4:	a6850513          	addi	a0,a0,-1432 # e48 <malloc+0x2a4>
 3e8:	704000ef          	jal	aec <printf>
  else
    printf("test3 passed\n");
}
 3ec:	60a2                	ld	ra,8(sp)
 3ee:	6402                	ld	s0,0(sp)
 3f0:	0141                	addi	sp,sp,16
 3f2:	8082                	ret
    printf("test3 passed\n");
 3f4:	00001517          	auipc	a0,0x1
 3f8:	a7c50513          	addi	a0,a0,-1412 # e70 <malloc+0x2cc>
 3fc:	6f0000ef          	jal	aec <printf>
}
 400:	b7f5                	j	3ec <test3+0x4c>

0000000000000402 <main>:
{
 402:	1141                	addi	sp,sp,-16
 404:	e406                	sd	ra,8(sp)
 406:	e022                	sd	s0,0(sp)
 408:	0800                	addi	s0,sp,16
  test0();
 40a:	cafff0ef          	jal	b8 <test0>
  test1();
 40e:	ddfff0ef          	jal	1ec <test1>
  test2();
 412:	e93ff0ef          	jal	2a4 <test2>
  test3();
 416:	f8bff0ef          	jal	3a0 <test3>
  exit(0);
 41a:	4501                	li	a0,0
 41c:	290000ef          	jal	6ac <exit>

0000000000000420 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 420:	1141                	addi	sp,sp,-16
 422:	e406                	sd	ra,8(sp)
 424:	e022                	sd	s0,0(sp)
 426:	0800                	addi	s0,sp,16
  extern int main();
  main();
 428:	fdbff0ef          	jal	402 <main>
  exit(0);
 42c:	4501                	li	a0,0
 42e:	27e000ef          	jal	6ac <exit>

0000000000000432 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 432:	1141                	addi	sp,sp,-16
 434:	e406                	sd	ra,8(sp)
 436:	e022                	sd	s0,0(sp)
 438:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 43a:	87aa                	mv	a5,a0
 43c:	0585                	addi	a1,a1,1
 43e:	0785                	addi	a5,a5,1
 440:	fff5c703          	lbu	a4,-1(a1)
 444:	fee78fa3          	sb	a4,-1(a5)
 448:	fb75                	bnez	a4,43c <strcpy+0xa>
    ;
  return os;
}
 44a:	60a2                	ld	ra,8(sp)
 44c:	6402                	ld	s0,0(sp)
 44e:	0141                	addi	sp,sp,16
 450:	8082                	ret

0000000000000452 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 452:	1141                	addi	sp,sp,-16
 454:	e406                	sd	ra,8(sp)
 456:	e022                	sd	s0,0(sp)
 458:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 45a:	00054783          	lbu	a5,0(a0)
 45e:	cb91                	beqz	a5,472 <strcmp+0x20>
 460:	0005c703          	lbu	a4,0(a1)
 464:	00f71763          	bne	a4,a5,472 <strcmp+0x20>
    p++, q++;
 468:	0505                	addi	a0,a0,1
 46a:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 46c:	00054783          	lbu	a5,0(a0)
 470:	fbe5                	bnez	a5,460 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 472:	0005c503          	lbu	a0,0(a1)
}
 476:	40a7853b          	subw	a0,a5,a0
 47a:	60a2                	ld	ra,8(sp)
 47c:	6402                	ld	s0,0(sp)
 47e:	0141                	addi	sp,sp,16
 480:	8082                	ret

0000000000000482 <strlen>:

uint
strlen(const char *s)
{
 482:	1141                	addi	sp,sp,-16
 484:	e406                	sd	ra,8(sp)
 486:	e022                	sd	s0,0(sp)
 488:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 48a:	00054783          	lbu	a5,0(a0)
 48e:	cf91                	beqz	a5,4aa <strlen+0x28>
 490:	00150793          	addi	a5,a0,1
 494:	86be                	mv	a3,a5
 496:	0785                	addi	a5,a5,1
 498:	fff7c703          	lbu	a4,-1(a5)
 49c:	ff65                	bnez	a4,494 <strlen+0x12>
 49e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 4a2:	60a2                	ld	ra,8(sp)
 4a4:	6402                	ld	s0,0(sp)
 4a6:	0141                	addi	sp,sp,16
 4a8:	8082                	ret
  for(n = 0; s[n]; n++)
 4aa:	4501                	li	a0,0
 4ac:	bfdd                	j	4a2 <strlen+0x20>

00000000000004ae <memset>:

void*
memset(void *dst, int c, uint n)
{
 4ae:	1141                	addi	sp,sp,-16
 4b0:	e406                	sd	ra,8(sp)
 4b2:	e022                	sd	s0,0(sp)
 4b4:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 4b6:	ca19                	beqz	a2,4cc <memset+0x1e>
 4b8:	87aa                	mv	a5,a0
 4ba:	1602                	slli	a2,a2,0x20
 4bc:	9201                	srli	a2,a2,0x20
 4be:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 4c2:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 4c6:	0785                	addi	a5,a5,1
 4c8:	fee79de3          	bne	a5,a4,4c2 <memset+0x14>
  }
  return dst;
}
 4cc:	60a2                	ld	ra,8(sp)
 4ce:	6402                	ld	s0,0(sp)
 4d0:	0141                	addi	sp,sp,16
 4d2:	8082                	ret

00000000000004d4 <strchr>:

char*
strchr(const char *s, char c)
{
 4d4:	1141                	addi	sp,sp,-16
 4d6:	e406                	sd	ra,8(sp)
 4d8:	e022                	sd	s0,0(sp)
 4da:	0800                	addi	s0,sp,16
  for(; *s; s++)
 4dc:	00054783          	lbu	a5,0(a0)
 4e0:	cf81                	beqz	a5,4f8 <strchr+0x24>
    if(*s == c)
 4e2:	00f58763          	beq	a1,a5,4f0 <strchr+0x1c>
  for(; *s; s++)
 4e6:	0505                	addi	a0,a0,1
 4e8:	00054783          	lbu	a5,0(a0)
 4ec:	fbfd                	bnez	a5,4e2 <strchr+0xe>
      return (char*)s;
  return 0;
 4ee:	4501                	li	a0,0
}
 4f0:	60a2                	ld	ra,8(sp)
 4f2:	6402                	ld	s0,0(sp)
 4f4:	0141                	addi	sp,sp,16
 4f6:	8082                	ret
  return 0;
 4f8:	4501                	li	a0,0
 4fa:	bfdd                	j	4f0 <strchr+0x1c>

00000000000004fc <gets>:

char*
gets(char *buf, int max)
{
 4fc:	711d                	addi	sp,sp,-96
 4fe:	ec86                	sd	ra,88(sp)
 500:	e8a2                	sd	s0,80(sp)
 502:	e4a6                	sd	s1,72(sp)
 504:	e0ca                	sd	s2,64(sp)
 506:	fc4e                	sd	s3,56(sp)
 508:	f852                	sd	s4,48(sp)
 50a:	f456                	sd	s5,40(sp)
 50c:	f05a                	sd	s6,32(sp)
 50e:	ec5e                	sd	s7,24(sp)
 510:	e862                	sd	s8,16(sp)
 512:	1080                	addi	s0,sp,96
 514:	8baa                	mv	s7,a0
 516:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 518:	892a                	mv	s2,a0
 51a:	4481                	li	s1,0
    cc = read(0, &c, 1);
 51c:	faf40b13          	addi	s6,s0,-81
 520:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 522:	8c26                	mv	s8,s1
 524:	0014899b          	addiw	s3,s1,1
 528:	84ce                	mv	s1,s3
 52a:	0349d463          	bge	s3,s4,552 <gets+0x56>
    cc = read(0, &c, 1);
 52e:	8656                	mv	a2,s5
 530:	85da                	mv	a1,s6
 532:	4501                	li	a0,0
 534:	190000ef          	jal	6c4 <read>
    if(cc < 1)
 538:	00a05d63          	blez	a0,552 <gets+0x56>
      break;
    buf[i++] = c;
 53c:	faf44783          	lbu	a5,-81(s0)
 540:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 544:	0905                	addi	s2,s2,1
 546:	ff678713          	addi	a4,a5,-10
 54a:	c319                	beqz	a4,550 <gets+0x54>
 54c:	17cd                	addi	a5,a5,-13
 54e:	fbf1                	bnez	a5,522 <gets+0x26>
    buf[i++] = c;
 550:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 552:	9c5e                	add	s8,s8,s7
 554:	000c0023          	sb	zero,0(s8)
  return buf;
}
 558:	855e                	mv	a0,s7
 55a:	60e6                	ld	ra,88(sp)
 55c:	6446                	ld	s0,80(sp)
 55e:	64a6                	ld	s1,72(sp)
 560:	6906                	ld	s2,64(sp)
 562:	79e2                	ld	s3,56(sp)
 564:	7a42                	ld	s4,48(sp)
 566:	7aa2                	ld	s5,40(sp)
 568:	7b02                	ld	s6,32(sp)
 56a:	6be2                	ld	s7,24(sp)
 56c:	6c42                	ld	s8,16(sp)
 56e:	6125                	addi	sp,sp,96
 570:	8082                	ret

0000000000000572 <stat>:

int
stat(const char *n, struct stat *st)
{
 572:	1101                	addi	sp,sp,-32
 574:	ec06                	sd	ra,24(sp)
 576:	e822                	sd	s0,16(sp)
 578:	e04a                	sd	s2,0(sp)
 57a:	1000                	addi	s0,sp,32
 57c:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 57e:	4581                	li	a1,0
 580:	16c000ef          	jal	6ec <open>
  if(fd < 0)
 584:	02054263          	bltz	a0,5a8 <stat+0x36>
 588:	e426                	sd	s1,8(sp)
 58a:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 58c:	85ca                	mv	a1,s2
 58e:	176000ef          	jal	704 <fstat>
 592:	892a                	mv	s2,a0
  close(fd);
 594:	8526                	mv	a0,s1
 596:	13e000ef          	jal	6d4 <close>
  return r;
 59a:	64a2                	ld	s1,8(sp)
}
 59c:	854a                	mv	a0,s2
 59e:	60e2                	ld	ra,24(sp)
 5a0:	6442                	ld	s0,16(sp)
 5a2:	6902                	ld	s2,0(sp)
 5a4:	6105                	addi	sp,sp,32
 5a6:	8082                	ret
    return -1;
 5a8:	57fd                	li	a5,-1
 5aa:	893e                	mv	s2,a5
 5ac:	bfc5                	j	59c <stat+0x2a>

00000000000005ae <atoi>:

int
atoi(const char *s)
{
 5ae:	1141                	addi	sp,sp,-16
 5b0:	e406                	sd	ra,8(sp)
 5b2:	e022                	sd	s0,0(sp)
 5b4:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 5b6:	00054683          	lbu	a3,0(a0)
 5ba:	fd06879b          	addiw	a5,a3,-48
 5be:	0ff7f793          	zext.b	a5,a5
 5c2:	4625                	li	a2,9
 5c4:	02f66963          	bltu	a2,a5,5f6 <atoi+0x48>
 5c8:	872a                	mv	a4,a0
  n = 0;
 5ca:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 5cc:	0705                	addi	a4,a4,1
 5ce:	0025179b          	slliw	a5,a0,0x2
 5d2:	9fa9                	addw	a5,a5,a0
 5d4:	0017979b          	slliw	a5,a5,0x1
 5d8:	9fb5                	addw	a5,a5,a3
 5da:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 5de:	00074683          	lbu	a3,0(a4)
 5e2:	fd06879b          	addiw	a5,a3,-48
 5e6:	0ff7f793          	zext.b	a5,a5
 5ea:	fef671e3          	bgeu	a2,a5,5cc <atoi+0x1e>
  return n;
}
 5ee:	60a2                	ld	ra,8(sp)
 5f0:	6402                	ld	s0,0(sp)
 5f2:	0141                	addi	sp,sp,16
 5f4:	8082                	ret
  n = 0;
 5f6:	4501                	li	a0,0
 5f8:	bfdd                	j	5ee <atoi+0x40>

00000000000005fa <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 5fa:	1141                	addi	sp,sp,-16
 5fc:	e406                	sd	ra,8(sp)
 5fe:	e022                	sd	s0,0(sp)
 600:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 602:	02b57563          	bgeu	a0,a1,62c <memmove+0x32>
    while(n-- > 0)
 606:	00c05f63          	blez	a2,624 <memmove+0x2a>
 60a:	1602                	slli	a2,a2,0x20
 60c:	9201                	srli	a2,a2,0x20
 60e:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 612:	872a                	mv	a4,a0
      *dst++ = *src++;
 614:	0585                	addi	a1,a1,1
 616:	0705                	addi	a4,a4,1
 618:	fff5c683          	lbu	a3,-1(a1)
 61c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 620:	fee79ae3          	bne	a5,a4,614 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 624:	60a2                	ld	ra,8(sp)
 626:	6402                	ld	s0,0(sp)
 628:	0141                	addi	sp,sp,16
 62a:	8082                	ret
    while(n-- > 0)
 62c:	fec05ce3          	blez	a2,624 <memmove+0x2a>
    dst += n;
 630:	00c50733          	add	a4,a0,a2
    src += n;
 634:	95b2                	add	a1,a1,a2
 636:	fff6079b          	addiw	a5,a2,-1
 63a:	1782                	slli	a5,a5,0x20
 63c:	9381                	srli	a5,a5,0x20
 63e:	fff7c793          	not	a5,a5
 642:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 644:	15fd                	addi	a1,a1,-1
 646:	177d                	addi	a4,a4,-1
 648:	0005c683          	lbu	a3,0(a1)
 64c:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 650:	fef71ae3          	bne	a4,a5,644 <memmove+0x4a>
 654:	bfc1                	j	624 <memmove+0x2a>

0000000000000656 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 656:	1141                	addi	sp,sp,-16
 658:	e406                	sd	ra,8(sp)
 65a:	e022                	sd	s0,0(sp)
 65c:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 65e:	c61d                	beqz	a2,68c <memcmp+0x36>
 660:	1602                	slli	a2,a2,0x20
 662:	9201                	srli	a2,a2,0x20
 664:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 668:	00054783          	lbu	a5,0(a0)
 66c:	0005c703          	lbu	a4,0(a1)
 670:	00e79863          	bne	a5,a4,680 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 674:	0505                	addi	a0,a0,1
    p2++;
 676:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 678:	fed518e3          	bne	a0,a3,668 <memcmp+0x12>
  }
  return 0;
 67c:	4501                	li	a0,0
 67e:	a019                	j	684 <memcmp+0x2e>
      return *p1 - *p2;
 680:	40e7853b          	subw	a0,a5,a4
}
 684:	60a2                	ld	ra,8(sp)
 686:	6402                	ld	s0,0(sp)
 688:	0141                	addi	sp,sp,16
 68a:	8082                	ret
  return 0;
 68c:	4501                	li	a0,0
 68e:	bfdd                	j	684 <memcmp+0x2e>

0000000000000690 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 690:	1141                	addi	sp,sp,-16
 692:	e406                	sd	ra,8(sp)
 694:	e022                	sd	s0,0(sp)
 696:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 698:	f63ff0ef          	jal	5fa <memmove>
}
 69c:	60a2                	ld	ra,8(sp)
 69e:	6402                	ld	s0,0(sp)
 6a0:	0141                	addi	sp,sp,16
 6a2:	8082                	ret

00000000000006a4 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 6a4:	4885                	li	a7,1
 ecall
 6a6:	00000073          	ecall
 ret
 6aa:	8082                	ret

00000000000006ac <exit>:
.global exit
exit:
 li a7, SYS_exit
 6ac:	4889                	li	a7,2
 ecall
 6ae:	00000073          	ecall
 ret
 6b2:	8082                	ret

00000000000006b4 <wait>:
.global wait
wait:
 li a7, SYS_wait
 6b4:	488d                	li	a7,3
 ecall
 6b6:	00000073          	ecall
 ret
 6ba:	8082                	ret

00000000000006bc <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 6bc:	4891                	li	a7,4
 ecall
 6be:	00000073          	ecall
 ret
 6c2:	8082                	ret

00000000000006c4 <read>:
.global read
read:
 li a7, SYS_read
 6c4:	4895                	li	a7,5
 ecall
 6c6:	00000073          	ecall
 ret
 6ca:	8082                	ret

00000000000006cc <write>:
.global write
write:
 li a7, SYS_write
 6cc:	48c1                	li	a7,16
 ecall
 6ce:	00000073          	ecall
 ret
 6d2:	8082                	ret

00000000000006d4 <close>:
.global close
close:
 li a7, SYS_close
 6d4:	48d5                	li	a7,21
 ecall
 6d6:	00000073          	ecall
 ret
 6da:	8082                	ret

00000000000006dc <kill>:
.global kill
kill:
 li a7, SYS_kill
 6dc:	4899                	li	a7,6
 ecall
 6de:	00000073          	ecall
 ret
 6e2:	8082                	ret

00000000000006e4 <exec>:
.global exec
exec:
 li a7, SYS_exec
 6e4:	489d                	li	a7,7
 ecall
 6e6:	00000073          	ecall
 ret
 6ea:	8082                	ret

00000000000006ec <open>:
.global open
open:
 li a7, SYS_open
 6ec:	48bd                	li	a7,15
 ecall
 6ee:	00000073          	ecall
 ret
 6f2:	8082                	ret

00000000000006f4 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 6f4:	48c5                	li	a7,17
 ecall
 6f6:	00000073          	ecall
 ret
 6fa:	8082                	ret

00000000000006fc <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 6fc:	48c9                	li	a7,18
 ecall
 6fe:	00000073          	ecall
 ret
 702:	8082                	ret

0000000000000704 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 704:	48a1                	li	a7,8
 ecall
 706:	00000073          	ecall
 ret
 70a:	8082                	ret

000000000000070c <link>:
.global link
link:
 li a7, SYS_link
 70c:	48cd                	li	a7,19
 ecall
 70e:	00000073          	ecall
 ret
 712:	8082                	ret

0000000000000714 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 714:	48d1                	li	a7,20
 ecall
 716:	00000073          	ecall
 ret
 71a:	8082                	ret

000000000000071c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 71c:	48a5                	li	a7,9
 ecall
 71e:	00000073          	ecall
 ret
 722:	8082                	ret

0000000000000724 <dup>:
.global dup
dup:
 li a7, SYS_dup
 724:	48a9                	li	a7,10
 ecall
 726:	00000073          	ecall
 ret
 72a:	8082                	ret

000000000000072c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 72c:	48ad                	li	a7,11
 ecall
 72e:	00000073          	ecall
 ret
 732:	8082                	ret

0000000000000734 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 734:	48b1                	li	a7,12
 ecall
 736:	00000073          	ecall
 ret
 73a:	8082                	ret

000000000000073c <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 73c:	48b5                	li	a7,13
 ecall
 73e:	00000073          	ecall
 ret
 742:	8082                	ret

0000000000000744 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 744:	48b9                	li	a7,14
 ecall
 746:	00000073          	ecall
 ret
 74a:	8082                	ret

000000000000074c <sigalarm>:
.global sigalarm
sigalarm:
 li a7, SYS_sigalarm
 74c:	48d9                	li	a7,22
 ecall
 74e:	00000073          	ecall
 ret
 752:	8082                	ret

0000000000000754 <sigreturn>:
.global sigreturn
sigreturn:
 li a7, SYS_sigreturn
 754:	48dd                	li	a7,23
 ecall
 756:	00000073          	ecall
 ret
 75a:	8082                	ret

000000000000075c <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 75c:	1101                	addi	sp,sp,-32
 75e:	ec06                	sd	ra,24(sp)
 760:	e822                	sd	s0,16(sp)
 762:	1000                	addi	s0,sp,32
 764:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 768:	4605                	li	a2,1
 76a:	fef40593          	addi	a1,s0,-17
 76e:	f5fff0ef          	jal	6cc <write>
}
 772:	60e2                	ld	ra,24(sp)
 774:	6442                	ld	s0,16(sp)
 776:	6105                	addi	sp,sp,32
 778:	8082                	ret

000000000000077a <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 77a:	7139                	addi	sp,sp,-64
 77c:	fc06                	sd	ra,56(sp)
 77e:	f822                	sd	s0,48(sp)
 780:	f04a                	sd	s2,32(sp)
 782:	ec4e                	sd	s3,24(sp)
 784:	0080                	addi	s0,sp,64
 786:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 788:	cac9                	beqz	a3,81a <printint+0xa0>
 78a:	01f5d79b          	srliw	a5,a1,0x1f
 78e:	c7d1                	beqz	a5,81a <printint+0xa0>
    neg = 1;
    x = -xx;
 790:	40b005bb          	negw	a1,a1
    neg = 1;
 794:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 796:	fc040993          	addi	s3,s0,-64
  neg = 0;
 79a:	86ce                	mv	a3,s3
  i = 0;
 79c:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 79e:	00000817          	auipc	a6,0x0
 7a2:	6ea80813          	addi	a6,a6,1770 # e88 <digits>
 7a6:	88ba                	mv	a7,a4
 7a8:	0017051b          	addiw	a0,a4,1
 7ac:	872a                	mv	a4,a0
 7ae:	02c5f7bb          	remuw	a5,a1,a2
 7b2:	1782                	slli	a5,a5,0x20
 7b4:	9381                	srli	a5,a5,0x20
 7b6:	97c2                	add	a5,a5,a6
 7b8:	0007c783          	lbu	a5,0(a5)
 7bc:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 7c0:	87ae                	mv	a5,a1
 7c2:	02c5d5bb          	divuw	a1,a1,a2
 7c6:	0685                	addi	a3,a3,1
 7c8:	fcc7ffe3          	bgeu	a5,a2,7a6 <printint+0x2c>
  if(neg)
 7cc:	00030c63          	beqz	t1,7e4 <printint+0x6a>
    buf[i++] = '-';
 7d0:	fd050793          	addi	a5,a0,-48
 7d4:	00878533          	add	a0,a5,s0
 7d8:	02d00793          	li	a5,45
 7dc:	fef50823          	sb	a5,-16(a0)
 7e0:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 7e4:	02e05563          	blez	a4,80e <printint+0x94>
 7e8:	f426                	sd	s1,40(sp)
 7ea:	377d                	addiw	a4,a4,-1
 7ec:	00e984b3          	add	s1,s3,a4
 7f0:	19fd                	addi	s3,s3,-1
 7f2:	99ba                	add	s3,s3,a4
 7f4:	1702                	slli	a4,a4,0x20
 7f6:	9301                	srli	a4,a4,0x20
 7f8:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 7fc:	0004c583          	lbu	a1,0(s1)
 800:	854a                	mv	a0,s2
 802:	f5bff0ef          	jal	75c <putc>
  while(--i >= 0)
 806:	14fd                	addi	s1,s1,-1
 808:	ff349ae3          	bne	s1,s3,7fc <printint+0x82>
 80c:	74a2                	ld	s1,40(sp)
}
 80e:	70e2                	ld	ra,56(sp)
 810:	7442                	ld	s0,48(sp)
 812:	7902                	ld	s2,32(sp)
 814:	69e2                	ld	s3,24(sp)
 816:	6121                	addi	sp,sp,64
 818:	8082                	ret
  neg = 0;
 81a:	4301                	li	t1,0
 81c:	bfad                	j	796 <printint+0x1c>

000000000000081e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 81e:	711d                	addi	sp,sp,-96
 820:	ec86                	sd	ra,88(sp)
 822:	e8a2                	sd	s0,80(sp)
 824:	e4a6                	sd	s1,72(sp)
 826:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 828:	0005c483          	lbu	s1,0(a1)
 82c:	20048963          	beqz	s1,a3e <vprintf+0x220>
 830:	e0ca                	sd	s2,64(sp)
 832:	fc4e                	sd	s3,56(sp)
 834:	f852                	sd	s4,48(sp)
 836:	f456                	sd	s5,40(sp)
 838:	f05a                	sd	s6,32(sp)
 83a:	ec5e                	sd	s7,24(sp)
 83c:	e862                	sd	s8,16(sp)
 83e:	8b2a                	mv	s6,a0
 840:	8a2e                	mv	s4,a1
 842:	8bb2                	mv	s7,a2
  state = 0;
 844:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 846:	4901                	li	s2,0
 848:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 84a:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 84e:	06400c13          	li	s8,100
 852:	a00d                	j	874 <vprintf+0x56>
        putc(fd, c0);
 854:	85a6                	mv	a1,s1
 856:	855a                	mv	a0,s6
 858:	f05ff0ef          	jal	75c <putc>
 85c:	a019                	j	862 <vprintf+0x44>
    } else if(state == '%'){
 85e:	03598363          	beq	s3,s5,884 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 862:	0019079b          	addiw	a5,s2,1
 866:	893e                	mv	s2,a5
 868:	873e                	mv	a4,a5
 86a:	97d2                	add	a5,a5,s4
 86c:	0007c483          	lbu	s1,0(a5)
 870:	1c048063          	beqz	s1,a30 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 874:	0004879b          	sext.w	a5,s1
    if(state == 0){
 878:	fe0993e3          	bnez	s3,85e <vprintf+0x40>
      if(c0 == '%'){
 87c:	fd579ce3          	bne	a5,s5,854 <vprintf+0x36>
        state = '%';
 880:	89be                	mv	s3,a5
 882:	b7c5                	j	862 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 884:	00ea06b3          	add	a3,s4,a4
 888:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 88c:	1a060e63          	beqz	a2,a48 <vprintf+0x22a>
      if(c0 == 'd'){
 890:	03878763          	beq	a5,s8,8be <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 894:	f9478693          	addi	a3,a5,-108
 898:	0016b693          	seqz	a3,a3
 89c:	f9c60593          	addi	a1,a2,-100
 8a0:	e99d                	bnez	a1,8d6 <vprintf+0xb8>
 8a2:	ca95                	beqz	a3,8d6 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8a4:	008b8493          	addi	s1,s7,8
 8a8:	4685                	li	a3,1
 8aa:	4629                	li	a2,10
 8ac:	000ba583          	lw	a1,0(s7)
 8b0:	855a                	mv	a0,s6
 8b2:	ec9ff0ef          	jal	77a <printint>
        i += 1;
 8b6:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 8b8:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 8ba:	4981                	li	s3,0
 8bc:	b75d                	j	862 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 8be:	008b8493          	addi	s1,s7,8
 8c2:	4685                	li	a3,1
 8c4:	4629                	li	a2,10
 8c6:	000ba583          	lw	a1,0(s7)
 8ca:	855a                	mv	a0,s6
 8cc:	eafff0ef          	jal	77a <printint>
 8d0:	8ba6                	mv	s7,s1
      state = 0;
 8d2:	4981                	li	s3,0
 8d4:	b779                	j	862 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 8d6:	9752                	add	a4,a4,s4
 8d8:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8dc:	f9460713          	addi	a4,a2,-108
 8e0:	00173713          	seqz	a4,a4
 8e4:	8f75                	and	a4,a4,a3
 8e6:	f9c58513          	addi	a0,a1,-100
 8ea:	16051963          	bnez	a0,a5c <vprintf+0x23e>
 8ee:	16070763          	beqz	a4,a5c <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8f2:	008b8493          	addi	s1,s7,8
 8f6:	4685                	li	a3,1
 8f8:	4629                	li	a2,10
 8fa:	000ba583          	lw	a1,0(s7)
 8fe:	855a                	mv	a0,s6
 900:	e7bff0ef          	jal	77a <printint>
        i += 2;
 904:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 906:	8ba6                	mv	s7,s1
      state = 0;
 908:	4981                	li	s3,0
        i += 2;
 90a:	bfa1                	j	862 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 90c:	008b8493          	addi	s1,s7,8
 910:	4681                	li	a3,0
 912:	4629                	li	a2,10
 914:	000ba583          	lw	a1,0(s7)
 918:	855a                	mv	a0,s6
 91a:	e61ff0ef          	jal	77a <printint>
 91e:	8ba6                	mv	s7,s1
      state = 0;
 920:	4981                	li	s3,0
 922:	b781                	j	862 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 924:	008b8493          	addi	s1,s7,8
 928:	4681                	li	a3,0
 92a:	4629                	li	a2,10
 92c:	000ba583          	lw	a1,0(s7)
 930:	855a                	mv	a0,s6
 932:	e49ff0ef          	jal	77a <printint>
        i += 1;
 936:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 938:	8ba6                	mv	s7,s1
      state = 0;
 93a:	4981                	li	s3,0
 93c:	b71d                	j	862 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 93e:	008b8493          	addi	s1,s7,8
 942:	4681                	li	a3,0
 944:	4629                	li	a2,10
 946:	000ba583          	lw	a1,0(s7)
 94a:	855a                	mv	a0,s6
 94c:	e2fff0ef          	jal	77a <printint>
        i += 2;
 950:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 952:	8ba6                	mv	s7,s1
      state = 0;
 954:	4981                	li	s3,0
        i += 2;
 956:	b731                	j	862 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 958:	008b8493          	addi	s1,s7,8
 95c:	4681                	li	a3,0
 95e:	4641                	li	a2,16
 960:	000ba583          	lw	a1,0(s7)
 964:	855a                	mv	a0,s6
 966:	e15ff0ef          	jal	77a <printint>
 96a:	8ba6                	mv	s7,s1
      state = 0;
 96c:	4981                	li	s3,0
 96e:	bdd5                	j	862 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 970:	008b8493          	addi	s1,s7,8
 974:	4681                	li	a3,0
 976:	4641                	li	a2,16
 978:	000ba583          	lw	a1,0(s7)
 97c:	855a                	mv	a0,s6
 97e:	dfdff0ef          	jal	77a <printint>
        i += 1;
 982:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 984:	8ba6                	mv	s7,s1
      state = 0;
 986:	4981                	li	s3,0
 988:	bde9                	j	862 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 98a:	008b8493          	addi	s1,s7,8
 98e:	4681                	li	a3,0
 990:	4641                	li	a2,16
 992:	000ba583          	lw	a1,0(s7)
 996:	855a                	mv	a0,s6
 998:	de3ff0ef          	jal	77a <printint>
        i += 2;
 99c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 99e:	8ba6                	mv	s7,s1
      state = 0;
 9a0:	4981                	li	s3,0
        i += 2;
 9a2:	b5c1                	j	862 <vprintf+0x44>
 9a4:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 9a6:	008b8793          	addi	a5,s7,8
 9aa:	8cbe                	mv	s9,a5
 9ac:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 9b0:	03000593          	li	a1,48
 9b4:	855a                	mv	a0,s6
 9b6:	da7ff0ef          	jal	75c <putc>
  putc(fd, 'x');
 9ba:	07800593          	li	a1,120
 9be:	855a                	mv	a0,s6
 9c0:	d9dff0ef          	jal	75c <putc>
 9c4:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 9c6:	00000b97          	auipc	s7,0x0
 9ca:	4c2b8b93          	addi	s7,s7,1218 # e88 <digits>
 9ce:	03c9d793          	srli	a5,s3,0x3c
 9d2:	97de                	add	a5,a5,s7
 9d4:	0007c583          	lbu	a1,0(a5)
 9d8:	855a                	mv	a0,s6
 9da:	d83ff0ef          	jal	75c <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 9de:	0992                	slli	s3,s3,0x4
 9e0:	34fd                	addiw	s1,s1,-1
 9e2:	f4f5                	bnez	s1,9ce <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 9e4:	8be6                	mv	s7,s9
      state = 0;
 9e6:	4981                	li	s3,0
 9e8:	6ca2                	ld	s9,8(sp)
 9ea:	bda5                	j	862 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 9ec:	008b8993          	addi	s3,s7,8
 9f0:	000bb483          	ld	s1,0(s7)
 9f4:	cc91                	beqz	s1,a10 <vprintf+0x1f2>
        for(; *s; s++)
 9f6:	0004c583          	lbu	a1,0(s1)
 9fa:	c985                	beqz	a1,a2a <vprintf+0x20c>
          putc(fd, *s);
 9fc:	855a                	mv	a0,s6
 9fe:	d5fff0ef          	jal	75c <putc>
        for(; *s; s++)
 a02:	0485                	addi	s1,s1,1
 a04:	0004c583          	lbu	a1,0(s1)
 a08:	f9f5                	bnez	a1,9fc <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 a0a:	8bce                	mv	s7,s3
      state = 0;
 a0c:	4981                	li	s3,0
 a0e:	bd91                	j	862 <vprintf+0x44>
          s = "(null)";
 a10:	00000497          	auipc	s1,0x0
 a14:	47048493          	addi	s1,s1,1136 # e80 <malloc+0x2dc>
        for(; *s; s++)
 a18:	02800593          	li	a1,40
 a1c:	b7c5                	j	9fc <vprintf+0x1de>
        putc(fd, '%');
 a1e:	85be                	mv	a1,a5
 a20:	855a                	mv	a0,s6
 a22:	d3bff0ef          	jal	75c <putc>
      state = 0;
 a26:	4981                	li	s3,0
 a28:	bd2d                	j	862 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 a2a:	8bce                	mv	s7,s3
      state = 0;
 a2c:	4981                	li	s3,0
 a2e:	bd15                	j	862 <vprintf+0x44>
 a30:	6906                	ld	s2,64(sp)
 a32:	79e2                	ld	s3,56(sp)
 a34:	7a42                	ld	s4,48(sp)
 a36:	7aa2                	ld	s5,40(sp)
 a38:	7b02                	ld	s6,32(sp)
 a3a:	6be2                	ld	s7,24(sp)
 a3c:	6c42                	ld	s8,16(sp)
    }
  }
}
 a3e:	60e6                	ld	ra,88(sp)
 a40:	6446                	ld	s0,80(sp)
 a42:	64a6                	ld	s1,72(sp)
 a44:	6125                	addi	sp,sp,96
 a46:	8082                	ret
      if(c0 == 'd'){
 a48:	06400713          	li	a4,100
 a4c:	e6e789e3          	beq	a5,a4,8be <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 a50:	f9478693          	addi	a3,a5,-108
 a54:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 a58:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 a5a:	4701                	li	a4,0
      } else if(c0 == 'u'){
 a5c:	07500513          	li	a0,117
 a60:	eaa786e3          	beq	a5,a0,90c <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 a64:	f8b60513          	addi	a0,a2,-117
 a68:	e119                	bnez	a0,a6e <vprintf+0x250>
 a6a:	ea069de3          	bnez	a3,924 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 a6e:	f8b58513          	addi	a0,a1,-117
 a72:	e119                	bnez	a0,a78 <vprintf+0x25a>
 a74:	ec0715e3          	bnez	a4,93e <vprintf+0x120>
      } else if(c0 == 'x'){
 a78:	07800513          	li	a0,120
 a7c:	eca78ee3          	beq	a5,a0,958 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 a80:	f8860613          	addi	a2,a2,-120
 a84:	e219                	bnez	a2,a8a <vprintf+0x26c>
 a86:	ee0695e3          	bnez	a3,970 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 a8a:	f8858593          	addi	a1,a1,-120
 a8e:	e199                	bnez	a1,a94 <vprintf+0x276>
 a90:	ee071de3          	bnez	a4,98a <vprintf+0x16c>
      } else if(c0 == 'p'){
 a94:	07000713          	li	a4,112
 a98:	f0e786e3          	beq	a5,a4,9a4 <vprintf+0x186>
      } else if(c0 == 's'){
 a9c:	07300713          	li	a4,115
 aa0:	f4e786e3          	beq	a5,a4,9ec <vprintf+0x1ce>
      } else if(c0 == '%'){
 aa4:	02500713          	li	a4,37
 aa8:	f6e78be3          	beq	a5,a4,a1e <vprintf+0x200>
        putc(fd, '%');
 aac:	02500593          	li	a1,37
 ab0:	855a                	mv	a0,s6
 ab2:	cabff0ef          	jal	75c <putc>
        putc(fd, c0);
 ab6:	85a6                	mv	a1,s1
 ab8:	855a                	mv	a0,s6
 aba:	ca3ff0ef          	jal	75c <putc>
      state = 0;
 abe:	4981                	li	s3,0
 ac0:	b34d                	j	862 <vprintf+0x44>

0000000000000ac2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 ac2:	715d                	addi	sp,sp,-80
 ac4:	ec06                	sd	ra,24(sp)
 ac6:	e822                	sd	s0,16(sp)
 ac8:	1000                	addi	s0,sp,32
 aca:	e010                	sd	a2,0(s0)
 acc:	e414                	sd	a3,8(s0)
 ace:	e818                	sd	a4,16(s0)
 ad0:	ec1c                	sd	a5,24(s0)
 ad2:	03043023          	sd	a6,32(s0)
 ad6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 ada:	8622                	mv	a2,s0
 adc:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 ae0:	d3fff0ef          	jal	81e <vprintf>
}
 ae4:	60e2                	ld	ra,24(sp)
 ae6:	6442                	ld	s0,16(sp)
 ae8:	6161                	addi	sp,sp,80
 aea:	8082                	ret

0000000000000aec <printf>:

void
printf(const char *fmt, ...)
{
 aec:	711d                	addi	sp,sp,-96
 aee:	ec06                	sd	ra,24(sp)
 af0:	e822                	sd	s0,16(sp)
 af2:	1000                	addi	s0,sp,32
 af4:	e40c                	sd	a1,8(s0)
 af6:	e810                	sd	a2,16(s0)
 af8:	ec14                	sd	a3,24(s0)
 afa:	f018                	sd	a4,32(s0)
 afc:	f41c                	sd	a5,40(s0)
 afe:	03043823          	sd	a6,48(s0)
 b02:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 b06:	00840613          	addi	a2,s0,8
 b0a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 b0e:	85aa                	mv	a1,a0
 b10:	4505                	li	a0,1
 b12:	d0dff0ef          	jal	81e <vprintf>
}
 b16:	60e2                	ld	ra,24(sp)
 b18:	6442                	ld	s0,16(sp)
 b1a:	6125                	addi	sp,sp,96
 b1c:	8082                	ret

0000000000000b1e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 b1e:	1141                	addi	sp,sp,-16
 b20:	e406                	sd	ra,8(sp)
 b22:	e022                	sd	s0,0(sp)
 b24:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 b26:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b2a:	00000797          	auipc	a5,0x0
 b2e:	4de7b783          	ld	a5,1246(a5) # 1008 <freep>
 b32:	a039                	j	b40 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b34:	6398                	ld	a4,0(a5)
 b36:	00e7e463          	bltu	a5,a4,b3e <free+0x20>
 b3a:	00e6ea63          	bltu	a3,a4,b4e <free+0x30>
{
 b3e:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b40:	fed7fae3          	bgeu	a5,a3,b34 <free+0x16>
 b44:	6398                	ld	a4,0(a5)
 b46:	00e6e463          	bltu	a3,a4,b4e <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b4a:	fee7eae3          	bltu	a5,a4,b3e <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 b4e:	ff852583          	lw	a1,-8(a0)
 b52:	6390                	ld	a2,0(a5)
 b54:	02059813          	slli	a6,a1,0x20
 b58:	01c85713          	srli	a4,a6,0x1c
 b5c:	9736                	add	a4,a4,a3
 b5e:	02e60563          	beq	a2,a4,b88 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 b62:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 b66:	4790                	lw	a2,8(a5)
 b68:	02061593          	slli	a1,a2,0x20
 b6c:	01c5d713          	srli	a4,a1,0x1c
 b70:	973e                	add	a4,a4,a5
 b72:	02e68263          	beq	a3,a4,b96 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 b76:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 b78:	00000717          	auipc	a4,0x0
 b7c:	48f73823          	sd	a5,1168(a4) # 1008 <freep>
}
 b80:	60a2                	ld	ra,8(sp)
 b82:	6402                	ld	s0,0(sp)
 b84:	0141                	addi	sp,sp,16
 b86:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 b88:	4618                	lw	a4,8(a2)
 b8a:	9f2d                	addw	a4,a4,a1
 b8c:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 b90:	6398                	ld	a4,0(a5)
 b92:	6310                	ld	a2,0(a4)
 b94:	b7f9                	j	b62 <free+0x44>
    p->s.size += bp->s.size;
 b96:	ff852703          	lw	a4,-8(a0)
 b9a:	9f31                	addw	a4,a4,a2
 b9c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 b9e:	ff053683          	ld	a3,-16(a0)
 ba2:	bfd1                	j	b76 <free+0x58>

0000000000000ba4 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 ba4:	7139                	addi	sp,sp,-64
 ba6:	fc06                	sd	ra,56(sp)
 ba8:	f822                	sd	s0,48(sp)
 baa:	f04a                	sd	s2,32(sp)
 bac:	ec4e                	sd	s3,24(sp)
 bae:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 bb0:	02051993          	slli	s3,a0,0x20
 bb4:	0209d993          	srli	s3,s3,0x20
 bb8:	09bd                	addi	s3,s3,15
 bba:	0049d993          	srli	s3,s3,0x4
 bbe:	2985                	addiw	s3,s3,1
 bc0:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 bc2:	00000517          	auipc	a0,0x0
 bc6:	44653503          	ld	a0,1094(a0) # 1008 <freep>
 bca:	c905                	beqz	a0,bfa <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 bcc:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 bce:	4798                	lw	a4,8(a5)
 bd0:	09377663          	bgeu	a4,s3,c5c <malloc+0xb8>
 bd4:	f426                	sd	s1,40(sp)
 bd6:	e852                	sd	s4,16(sp)
 bd8:	e456                	sd	s5,8(sp)
 bda:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 bdc:	8a4e                	mv	s4,s3
 bde:	6705                	lui	a4,0x1
 be0:	00e9f363          	bgeu	s3,a4,be6 <malloc+0x42>
 be4:	6a05                	lui	s4,0x1
 be6:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 bea:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 bee:	00000497          	auipc	s1,0x0
 bf2:	41a48493          	addi	s1,s1,1050 # 1008 <freep>
  if(p == (char*)-1)
 bf6:	5afd                	li	s5,-1
 bf8:	a83d                	j	c36 <malloc+0x92>
 bfa:	f426                	sd	s1,40(sp)
 bfc:	e852                	sd	s4,16(sp)
 bfe:	e456                	sd	s5,8(sp)
 c00:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 c02:	00000797          	auipc	a5,0x0
 c06:	40e78793          	addi	a5,a5,1038 # 1010 <base>
 c0a:	00000717          	auipc	a4,0x0
 c0e:	3ef73f23          	sd	a5,1022(a4) # 1008 <freep>
 c12:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 c14:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 c18:	b7d1                	j	bdc <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 c1a:	6398                	ld	a4,0(a5)
 c1c:	e118                	sd	a4,0(a0)
 c1e:	a899                	j	c74 <malloc+0xd0>
  hp->s.size = nu;
 c20:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 c24:	0541                	addi	a0,a0,16
 c26:	ef9ff0ef          	jal	b1e <free>
  return freep;
 c2a:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 c2c:	c125                	beqz	a0,c8c <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c2e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 c30:	4798                	lw	a4,8(a5)
 c32:	03277163          	bgeu	a4,s2,c54 <malloc+0xb0>
    if(p == freep)
 c36:	6098                	ld	a4,0(s1)
 c38:	853e                	mv	a0,a5
 c3a:	fef71ae3          	bne	a4,a5,c2e <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 c3e:	8552                	mv	a0,s4
 c40:	af5ff0ef          	jal	734 <sbrk>
  if(p == (char*)-1)
 c44:	fd551ee3          	bne	a0,s5,c20 <malloc+0x7c>
        return 0;
 c48:	4501                	li	a0,0
 c4a:	74a2                	ld	s1,40(sp)
 c4c:	6a42                	ld	s4,16(sp)
 c4e:	6aa2                	ld	s5,8(sp)
 c50:	6b02                	ld	s6,0(sp)
 c52:	a03d                	j	c80 <malloc+0xdc>
 c54:	74a2                	ld	s1,40(sp)
 c56:	6a42                	ld	s4,16(sp)
 c58:	6aa2                	ld	s5,8(sp)
 c5a:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 c5c:	fae90fe3          	beq	s2,a4,c1a <malloc+0x76>
        p->s.size -= nunits;
 c60:	4137073b          	subw	a4,a4,s3
 c64:	c798                	sw	a4,8(a5)
        p += p->s.size;
 c66:	02071693          	slli	a3,a4,0x20
 c6a:	01c6d713          	srli	a4,a3,0x1c
 c6e:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 c70:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 c74:	00000717          	auipc	a4,0x0
 c78:	38a73a23          	sd	a0,916(a4) # 1008 <freep>
      return (void*)(p + 1);
 c7c:	01078513          	addi	a0,a5,16
  }
}
 c80:	70e2                	ld	ra,56(sp)
 c82:	7442                	ld	s0,48(sp)
 c84:	7902                	ld	s2,32(sp)
 c86:	69e2                	ld	s3,24(sp)
 c88:	6121                	addi	sp,sp,64
 c8a:	8082                	ret
 c8c:	74a2                	ld	s1,40(sp)
 c8e:	6a42                	ld	s4,16(sp)
 c90:	6aa2                	ld	s5,8(sp)
 c92:	6b02                	ld	s6,0(sp)
 c94:	b7f5                	j	c80 <malloc+0xdc>
