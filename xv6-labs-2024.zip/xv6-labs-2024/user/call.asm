
user/_call:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <g>:
#include "kernel/param.h"
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int g(int x) {
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  return x+3;
}
   8:	250d                	addiw	a0,a0,3
   a:	60a2                	ld	ra,8(sp)
   c:	6402                	ld	s0,0(sp)
   e:	0141                	addi	sp,sp,16
  10:	8082                	ret

0000000000000012 <f>:

int f(int x) {
  12:	1141                	addi	sp,sp,-16
  14:	e406                	sd	ra,8(sp)
  16:	e022                	sd	s0,0(sp)
  18:	0800                	addi	s0,sp,16
  return g(x);
}
  1a:	250d                	addiw	a0,a0,3
  1c:	60a2                	ld	ra,8(sp)
  1e:	6402                	ld	s0,0(sp)
  20:	0141                	addi	sp,sp,16
  22:	8082                	ret

0000000000000024 <main>:

void main(void) {
  24:	1141                	addi	sp,sp,-16
  26:	e406                	sd	ra,8(sp)
  28:	e022                	sd	s0,0(sp)
  2a:	0800                	addi	s0,sp,16
  printf("%d %d\n", f(8)+1, 13);
  2c:	4635                	li	a2,13
  2e:	45b1                	li	a1,12
  30:	00001517          	auipc	a0,0x1
  34:	89050513          	addi	a0,a0,-1904 # 8c0 <malloc+0xfa>
  38:	6d6000ef          	jal	70e <printf>
  exit(0);
  3c:	4501                	li	a0,0
  3e:	290000ef          	jal	2ce <exit>

0000000000000042 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  42:	1141                	addi	sp,sp,-16
  44:	e406                	sd	ra,8(sp)
  46:	e022                	sd	s0,0(sp)
  48:	0800                	addi	s0,sp,16
  extern int main();
  main();
  4a:	fdbff0ef          	jal	24 <main>
  exit(0);
  4e:	4501                	li	a0,0
  50:	27e000ef          	jal	2ce <exit>

0000000000000054 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  54:	1141                	addi	sp,sp,-16
  56:	e406                	sd	ra,8(sp)
  58:	e022                	sd	s0,0(sp)
  5a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  5c:	87aa                	mv	a5,a0
  5e:	0585                	addi	a1,a1,1
  60:	0785                	addi	a5,a5,1
  62:	fff5c703          	lbu	a4,-1(a1)
  66:	fee78fa3          	sb	a4,-1(a5)
  6a:	fb75                	bnez	a4,5e <strcpy+0xa>
    ;
  return os;
}
  6c:	60a2                	ld	ra,8(sp)
  6e:	6402                	ld	s0,0(sp)
  70:	0141                	addi	sp,sp,16
  72:	8082                	ret

0000000000000074 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  74:	1141                	addi	sp,sp,-16
  76:	e406                	sd	ra,8(sp)
  78:	e022                	sd	s0,0(sp)
  7a:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  7c:	00054783          	lbu	a5,0(a0)
  80:	cb91                	beqz	a5,94 <strcmp+0x20>
  82:	0005c703          	lbu	a4,0(a1)
  86:	00f71763          	bne	a4,a5,94 <strcmp+0x20>
    p++, q++;
  8a:	0505                	addi	a0,a0,1
  8c:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  8e:	00054783          	lbu	a5,0(a0)
  92:	fbe5                	bnez	a5,82 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  94:	0005c503          	lbu	a0,0(a1)
}
  98:	40a7853b          	subw	a0,a5,a0
  9c:	60a2                	ld	ra,8(sp)
  9e:	6402                	ld	s0,0(sp)
  a0:	0141                	addi	sp,sp,16
  a2:	8082                	ret

00000000000000a4 <strlen>:

uint
strlen(const char *s)
{
  a4:	1141                	addi	sp,sp,-16
  a6:	e406                	sd	ra,8(sp)
  a8:	e022                	sd	s0,0(sp)
  aa:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  ac:	00054783          	lbu	a5,0(a0)
  b0:	cf91                	beqz	a5,cc <strlen+0x28>
  b2:	00150793          	addi	a5,a0,1
  b6:	86be                	mv	a3,a5
  b8:	0785                	addi	a5,a5,1
  ba:	fff7c703          	lbu	a4,-1(a5)
  be:	ff65                	bnez	a4,b6 <strlen+0x12>
  c0:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  c4:	60a2                	ld	ra,8(sp)
  c6:	6402                	ld	s0,0(sp)
  c8:	0141                	addi	sp,sp,16
  ca:	8082                	ret
  for(n = 0; s[n]; n++)
  cc:	4501                	li	a0,0
  ce:	bfdd                	j	c4 <strlen+0x20>

00000000000000d0 <memset>:

void*
memset(void *dst, int c, uint n)
{
  d0:	1141                	addi	sp,sp,-16
  d2:	e406                	sd	ra,8(sp)
  d4:	e022                	sd	s0,0(sp)
  d6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  d8:	ca19                	beqz	a2,ee <memset+0x1e>
  da:	87aa                	mv	a5,a0
  dc:	1602                	slli	a2,a2,0x20
  de:	9201                	srli	a2,a2,0x20
  e0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  e4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  e8:	0785                	addi	a5,a5,1
  ea:	fee79de3          	bne	a5,a4,e4 <memset+0x14>
  }
  return dst;
}
  ee:	60a2                	ld	ra,8(sp)
  f0:	6402                	ld	s0,0(sp)
  f2:	0141                	addi	sp,sp,16
  f4:	8082                	ret

00000000000000f6 <strchr>:

char*
strchr(const char *s, char c)
{
  f6:	1141                	addi	sp,sp,-16
  f8:	e406                	sd	ra,8(sp)
  fa:	e022                	sd	s0,0(sp)
  fc:	0800                	addi	s0,sp,16
  for(; *s; s++)
  fe:	00054783          	lbu	a5,0(a0)
 102:	cf81                	beqz	a5,11a <strchr+0x24>
    if(*s == c)
 104:	00f58763          	beq	a1,a5,112 <strchr+0x1c>
  for(; *s; s++)
 108:	0505                	addi	a0,a0,1
 10a:	00054783          	lbu	a5,0(a0)
 10e:	fbfd                	bnez	a5,104 <strchr+0xe>
      return (char*)s;
  return 0;
 110:	4501                	li	a0,0
}
 112:	60a2                	ld	ra,8(sp)
 114:	6402                	ld	s0,0(sp)
 116:	0141                	addi	sp,sp,16
 118:	8082                	ret
  return 0;
 11a:	4501                	li	a0,0
 11c:	bfdd                	j	112 <strchr+0x1c>

000000000000011e <gets>:

char*
gets(char *buf, int max)
{
 11e:	711d                	addi	sp,sp,-96
 120:	ec86                	sd	ra,88(sp)
 122:	e8a2                	sd	s0,80(sp)
 124:	e4a6                	sd	s1,72(sp)
 126:	e0ca                	sd	s2,64(sp)
 128:	fc4e                	sd	s3,56(sp)
 12a:	f852                	sd	s4,48(sp)
 12c:	f456                	sd	s5,40(sp)
 12e:	f05a                	sd	s6,32(sp)
 130:	ec5e                	sd	s7,24(sp)
 132:	e862                	sd	s8,16(sp)
 134:	1080                	addi	s0,sp,96
 136:	8baa                	mv	s7,a0
 138:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 13a:	892a                	mv	s2,a0
 13c:	4481                	li	s1,0
    cc = read(0, &c, 1);
 13e:	faf40b13          	addi	s6,s0,-81
 142:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 144:	8c26                	mv	s8,s1
 146:	0014899b          	addiw	s3,s1,1
 14a:	84ce                	mv	s1,s3
 14c:	0349d463          	bge	s3,s4,174 <gets+0x56>
    cc = read(0, &c, 1);
 150:	8656                	mv	a2,s5
 152:	85da                	mv	a1,s6
 154:	4501                	li	a0,0
 156:	190000ef          	jal	2e6 <read>
    if(cc < 1)
 15a:	00a05d63          	blez	a0,174 <gets+0x56>
      break;
    buf[i++] = c;
 15e:	faf44783          	lbu	a5,-81(s0)
 162:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 166:	0905                	addi	s2,s2,1
 168:	ff678713          	addi	a4,a5,-10
 16c:	c319                	beqz	a4,172 <gets+0x54>
 16e:	17cd                	addi	a5,a5,-13
 170:	fbf1                	bnez	a5,144 <gets+0x26>
    buf[i++] = c;
 172:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 174:	9c5e                	add	s8,s8,s7
 176:	000c0023          	sb	zero,0(s8)
  return buf;
}
 17a:	855e                	mv	a0,s7
 17c:	60e6                	ld	ra,88(sp)
 17e:	6446                	ld	s0,80(sp)
 180:	64a6                	ld	s1,72(sp)
 182:	6906                	ld	s2,64(sp)
 184:	79e2                	ld	s3,56(sp)
 186:	7a42                	ld	s4,48(sp)
 188:	7aa2                	ld	s5,40(sp)
 18a:	7b02                	ld	s6,32(sp)
 18c:	6be2                	ld	s7,24(sp)
 18e:	6c42                	ld	s8,16(sp)
 190:	6125                	addi	sp,sp,96
 192:	8082                	ret

0000000000000194 <stat>:

int
stat(const char *n, struct stat *st)
{
 194:	1101                	addi	sp,sp,-32
 196:	ec06                	sd	ra,24(sp)
 198:	e822                	sd	s0,16(sp)
 19a:	e04a                	sd	s2,0(sp)
 19c:	1000                	addi	s0,sp,32
 19e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1a0:	4581                	li	a1,0
 1a2:	16c000ef          	jal	30e <open>
  if(fd < 0)
 1a6:	02054263          	bltz	a0,1ca <stat+0x36>
 1aa:	e426                	sd	s1,8(sp)
 1ac:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 1ae:	85ca                	mv	a1,s2
 1b0:	176000ef          	jal	326 <fstat>
 1b4:	892a                	mv	s2,a0
  close(fd);
 1b6:	8526                	mv	a0,s1
 1b8:	13e000ef          	jal	2f6 <close>
  return r;
 1bc:	64a2                	ld	s1,8(sp)
}
 1be:	854a                	mv	a0,s2
 1c0:	60e2                	ld	ra,24(sp)
 1c2:	6442                	ld	s0,16(sp)
 1c4:	6902                	ld	s2,0(sp)
 1c6:	6105                	addi	sp,sp,32
 1c8:	8082                	ret
    return -1;
 1ca:	57fd                	li	a5,-1
 1cc:	893e                	mv	s2,a5
 1ce:	bfc5                	j	1be <stat+0x2a>

00000000000001d0 <atoi>:

int
atoi(const char *s)
{
 1d0:	1141                	addi	sp,sp,-16
 1d2:	e406                	sd	ra,8(sp)
 1d4:	e022                	sd	s0,0(sp)
 1d6:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1d8:	00054683          	lbu	a3,0(a0)
 1dc:	fd06879b          	addiw	a5,a3,-48
 1e0:	0ff7f793          	zext.b	a5,a5
 1e4:	4625                	li	a2,9
 1e6:	02f66963          	bltu	a2,a5,218 <atoi+0x48>
 1ea:	872a                	mv	a4,a0
  n = 0;
 1ec:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 1ee:	0705                	addi	a4,a4,1
 1f0:	0025179b          	slliw	a5,a0,0x2
 1f4:	9fa9                	addw	a5,a5,a0
 1f6:	0017979b          	slliw	a5,a5,0x1
 1fa:	9fb5                	addw	a5,a5,a3
 1fc:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 200:	00074683          	lbu	a3,0(a4)
 204:	fd06879b          	addiw	a5,a3,-48
 208:	0ff7f793          	zext.b	a5,a5
 20c:	fef671e3          	bgeu	a2,a5,1ee <atoi+0x1e>
  return n;
}
 210:	60a2                	ld	ra,8(sp)
 212:	6402                	ld	s0,0(sp)
 214:	0141                	addi	sp,sp,16
 216:	8082                	ret
  n = 0;
 218:	4501                	li	a0,0
 21a:	bfdd                	j	210 <atoi+0x40>

000000000000021c <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 21c:	1141                	addi	sp,sp,-16
 21e:	e406                	sd	ra,8(sp)
 220:	e022                	sd	s0,0(sp)
 222:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 224:	02b57563          	bgeu	a0,a1,24e <memmove+0x32>
    while(n-- > 0)
 228:	00c05f63          	blez	a2,246 <memmove+0x2a>
 22c:	1602                	slli	a2,a2,0x20
 22e:	9201                	srli	a2,a2,0x20
 230:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 234:	872a                	mv	a4,a0
      *dst++ = *src++;
 236:	0585                	addi	a1,a1,1
 238:	0705                	addi	a4,a4,1
 23a:	fff5c683          	lbu	a3,-1(a1)
 23e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 242:	fee79ae3          	bne	a5,a4,236 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 246:	60a2                	ld	ra,8(sp)
 248:	6402                	ld	s0,0(sp)
 24a:	0141                	addi	sp,sp,16
 24c:	8082                	ret
    while(n-- > 0)
 24e:	fec05ce3          	blez	a2,246 <memmove+0x2a>
    dst += n;
 252:	00c50733          	add	a4,a0,a2
    src += n;
 256:	95b2                	add	a1,a1,a2
 258:	fff6079b          	addiw	a5,a2,-1
 25c:	1782                	slli	a5,a5,0x20
 25e:	9381                	srli	a5,a5,0x20
 260:	fff7c793          	not	a5,a5
 264:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 266:	15fd                	addi	a1,a1,-1
 268:	177d                	addi	a4,a4,-1
 26a:	0005c683          	lbu	a3,0(a1)
 26e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 272:	fef71ae3          	bne	a4,a5,266 <memmove+0x4a>
 276:	bfc1                	j	246 <memmove+0x2a>

0000000000000278 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 278:	1141                	addi	sp,sp,-16
 27a:	e406                	sd	ra,8(sp)
 27c:	e022                	sd	s0,0(sp)
 27e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 280:	c61d                	beqz	a2,2ae <memcmp+0x36>
 282:	1602                	slli	a2,a2,0x20
 284:	9201                	srli	a2,a2,0x20
 286:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 28a:	00054783          	lbu	a5,0(a0)
 28e:	0005c703          	lbu	a4,0(a1)
 292:	00e79863          	bne	a5,a4,2a2 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 296:	0505                	addi	a0,a0,1
    p2++;
 298:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 29a:	fed518e3          	bne	a0,a3,28a <memcmp+0x12>
  }
  return 0;
 29e:	4501                	li	a0,0
 2a0:	a019                	j	2a6 <memcmp+0x2e>
      return *p1 - *p2;
 2a2:	40e7853b          	subw	a0,a5,a4
}
 2a6:	60a2                	ld	ra,8(sp)
 2a8:	6402                	ld	s0,0(sp)
 2aa:	0141                	addi	sp,sp,16
 2ac:	8082                	ret
  return 0;
 2ae:	4501                	li	a0,0
 2b0:	bfdd                	j	2a6 <memcmp+0x2e>

00000000000002b2 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 2b2:	1141                	addi	sp,sp,-16
 2b4:	e406                	sd	ra,8(sp)
 2b6:	e022                	sd	s0,0(sp)
 2b8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 2ba:	f63ff0ef          	jal	21c <memmove>
}
 2be:	60a2                	ld	ra,8(sp)
 2c0:	6402                	ld	s0,0(sp)
 2c2:	0141                	addi	sp,sp,16
 2c4:	8082                	ret

00000000000002c6 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2c6:	4885                	li	a7,1
 ecall
 2c8:	00000073          	ecall
 ret
 2cc:	8082                	ret

00000000000002ce <exit>:
.global exit
exit:
 li a7, SYS_exit
 2ce:	4889                	li	a7,2
 ecall
 2d0:	00000073          	ecall
 ret
 2d4:	8082                	ret

00000000000002d6 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2d6:	488d                	li	a7,3
 ecall
 2d8:	00000073          	ecall
 ret
 2dc:	8082                	ret

00000000000002de <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2de:	4891                	li	a7,4
 ecall
 2e0:	00000073          	ecall
 ret
 2e4:	8082                	ret

00000000000002e6 <read>:
.global read
read:
 li a7, SYS_read
 2e6:	4895                	li	a7,5
 ecall
 2e8:	00000073          	ecall
 ret
 2ec:	8082                	ret

00000000000002ee <write>:
.global write
write:
 li a7, SYS_write
 2ee:	48c1                	li	a7,16
 ecall
 2f0:	00000073          	ecall
 ret
 2f4:	8082                	ret

00000000000002f6 <close>:
.global close
close:
 li a7, SYS_close
 2f6:	48d5                	li	a7,21
 ecall
 2f8:	00000073          	ecall
 ret
 2fc:	8082                	ret

00000000000002fe <kill>:
.global kill
kill:
 li a7, SYS_kill
 2fe:	4899                	li	a7,6
 ecall
 300:	00000073          	ecall
 ret
 304:	8082                	ret

0000000000000306 <exec>:
.global exec
exec:
 li a7, SYS_exec
 306:	489d                	li	a7,7
 ecall
 308:	00000073          	ecall
 ret
 30c:	8082                	ret

000000000000030e <open>:
.global open
open:
 li a7, SYS_open
 30e:	48bd                	li	a7,15
 ecall
 310:	00000073          	ecall
 ret
 314:	8082                	ret

0000000000000316 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 316:	48c5                	li	a7,17
 ecall
 318:	00000073          	ecall
 ret
 31c:	8082                	ret

000000000000031e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 31e:	48c9                	li	a7,18
 ecall
 320:	00000073          	ecall
 ret
 324:	8082                	ret

0000000000000326 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 326:	48a1                	li	a7,8
 ecall
 328:	00000073          	ecall
 ret
 32c:	8082                	ret

000000000000032e <link>:
.global link
link:
 li a7, SYS_link
 32e:	48cd                	li	a7,19
 ecall
 330:	00000073          	ecall
 ret
 334:	8082                	ret

0000000000000336 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 336:	48d1                	li	a7,20
 ecall
 338:	00000073          	ecall
 ret
 33c:	8082                	ret

000000000000033e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 33e:	48a5                	li	a7,9
 ecall
 340:	00000073          	ecall
 ret
 344:	8082                	ret

0000000000000346 <dup>:
.global dup
dup:
 li a7, SYS_dup
 346:	48a9                	li	a7,10
 ecall
 348:	00000073          	ecall
 ret
 34c:	8082                	ret

000000000000034e <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 34e:	48ad                	li	a7,11
 ecall
 350:	00000073          	ecall
 ret
 354:	8082                	ret

0000000000000356 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 356:	48b1                	li	a7,12
 ecall
 358:	00000073          	ecall
 ret
 35c:	8082                	ret

000000000000035e <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 35e:	48b5                	li	a7,13
 ecall
 360:	00000073          	ecall
 ret
 364:	8082                	ret

0000000000000366 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 366:	48b9                	li	a7,14
 ecall
 368:	00000073          	ecall
 ret
 36c:	8082                	ret

000000000000036e <sigalarm>:
.global sigalarm
sigalarm:
 li a7, SYS_sigalarm
 36e:	48d9                	li	a7,22
 ecall
 370:	00000073          	ecall
 ret
 374:	8082                	ret

0000000000000376 <sigreturn>:
.global sigreturn
sigreturn:
 li a7, SYS_sigreturn
 376:	48dd                	li	a7,23
 ecall
 378:	00000073          	ecall
 ret
 37c:	8082                	ret

000000000000037e <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 37e:	1101                	addi	sp,sp,-32
 380:	ec06                	sd	ra,24(sp)
 382:	e822                	sd	s0,16(sp)
 384:	1000                	addi	s0,sp,32
 386:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 38a:	4605                	li	a2,1
 38c:	fef40593          	addi	a1,s0,-17
 390:	f5fff0ef          	jal	2ee <write>
}
 394:	60e2                	ld	ra,24(sp)
 396:	6442                	ld	s0,16(sp)
 398:	6105                	addi	sp,sp,32
 39a:	8082                	ret

000000000000039c <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 39c:	7139                	addi	sp,sp,-64
 39e:	fc06                	sd	ra,56(sp)
 3a0:	f822                	sd	s0,48(sp)
 3a2:	f04a                	sd	s2,32(sp)
 3a4:	ec4e                	sd	s3,24(sp)
 3a6:	0080                	addi	s0,sp,64
 3a8:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 3aa:	cac9                	beqz	a3,43c <printint+0xa0>
 3ac:	01f5d79b          	srliw	a5,a1,0x1f
 3b0:	c7d1                	beqz	a5,43c <printint+0xa0>
    neg = 1;
    x = -xx;
 3b2:	40b005bb          	negw	a1,a1
    neg = 1;
 3b6:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 3b8:	fc040993          	addi	s3,s0,-64
  neg = 0;
 3bc:	86ce                	mv	a3,s3
  i = 0;
 3be:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 3c0:	00000817          	auipc	a6,0x0
 3c4:	51080813          	addi	a6,a6,1296 # 8d0 <digits>
 3c8:	88ba                	mv	a7,a4
 3ca:	0017051b          	addiw	a0,a4,1
 3ce:	872a                	mv	a4,a0
 3d0:	02c5f7bb          	remuw	a5,a1,a2
 3d4:	1782                	slli	a5,a5,0x20
 3d6:	9381                	srli	a5,a5,0x20
 3d8:	97c2                	add	a5,a5,a6
 3da:	0007c783          	lbu	a5,0(a5)
 3de:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 3e2:	87ae                	mv	a5,a1
 3e4:	02c5d5bb          	divuw	a1,a1,a2
 3e8:	0685                	addi	a3,a3,1
 3ea:	fcc7ffe3          	bgeu	a5,a2,3c8 <printint+0x2c>
  if(neg)
 3ee:	00030c63          	beqz	t1,406 <printint+0x6a>
    buf[i++] = '-';
 3f2:	fd050793          	addi	a5,a0,-48
 3f6:	00878533          	add	a0,a5,s0
 3fa:	02d00793          	li	a5,45
 3fe:	fef50823          	sb	a5,-16(a0)
 402:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 406:	02e05563          	blez	a4,430 <printint+0x94>
 40a:	f426                	sd	s1,40(sp)
 40c:	377d                	addiw	a4,a4,-1
 40e:	00e984b3          	add	s1,s3,a4
 412:	19fd                	addi	s3,s3,-1
 414:	99ba                	add	s3,s3,a4
 416:	1702                	slli	a4,a4,0x20
 418:	9301                	srli	a4,a4,0x20
 41a:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 41e:	0004c583          	lbu	a1,0(s1)
 422:	854a                	mv	a0,s2
 424:	f5bff0ef          	jal	37e <putc>
  while(--i >= 0)
 428:	14fd                	addi	s1,s1,-1
 42a:	ff349ae3          	bne	s1,s3,41e <printint+0x82>
 42e:	74a2                	ld	s1,40(sp)
}
 430:	70e2                	ld	ra,56(sp)
 432:	7442                	ld	s0,48(sp)
 434:	7902                	ld	s2,32(sp)
 436:	69e2                	ld	s3,24(sp)
 438:	6121                	addi	sp,sp,64
 43a:	8082                	ret
  neg = 0;
 43c:	4301                	li	t1,0
 43e:	bfad                	j	3b8 <printint+0x1c>

0000000000000440 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 440:	711d                	addi	sp,sp,-96
 442:	ec86                	sd	ra,88(sp)
 444:	e8a2                	sd	s0,80(sp)
 446:	e4a6                	sd	s1,72(sp)
 448:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 44a:	0005c483          	lbu	s1,0(a1)
 44e:	20048963          	beqz	s1,660 <vprintf+0x220>
 452:	e0ca                	sd	s2,64(sp)
 454:	fc4e                	sd	s3,56(sp)
 456:	f852                	sd	s4,48(sp)
 458:	f456                	sd	s5,40(sp)
 45a:	f05a                	sd	s6,32(sp)
 45c:	ec5e                	sd	s7,24(sp)
 45e:	e862                	sd	s8,16(sp)
 460:	8b2a                	mv	s6,a0
 462:	8a2e                	mv	s4,a1
 464:	8bb2                	mv	s7,a2
  state = 0;
 466:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 468:	4901                	li	s2,0
 46a:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 46c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 470:	06400c13          	li	s8,100
 474:	a00d                	j	496 <vprintf+0x56>
        putc(fd, c0);
 476:	85a6                	mv	a1,s1
 478:	855a                	mv	a0,s6
 47a:	f05ff0ef          	jal	37e <putc>
 47e:	a019                	j	484 <vprintf+0x44>
    } else if(state == '%'){
 480:	03598363          	beq	s3,s5,4a6 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 484:	0019079b          	addiw	a5,s2,1
 488:	893e                	mv	s2,a5
 48a:	873e                	mv	a4,a5
 48c:	97d2                	add	a5,a5,s4
 48e:	0007c483          	lbu	s1,0(a5)
 492:	1c048063          	beqz	s1,652 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 496:	0004879b          	sext.w	a5,s1
    if(state == 0){
 49a:	fe0993e3          	bnez	s3,480 <vprintf+0x40>
      if(c0 == '%'){
 49e:	fd579ce3          	bne	a5,s5,476 <vprintf+0x36>
        state = '%';
 4a2:	89be                	mv	s3,a5
 4a4:	b7c5                	j	484 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 4a6:	00ea06b3          	add	a3,s4,a4
 4aa:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 4ae:	1a060e63          	beqz	a2,66a <vprintf+0x22a>
      if(c0 == 'd'){
 4b2:	03878763          	beq	a5,s8,4e0 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 4b6:	f9478693          	addi	a3,a5,-108
 4ba:	0016b693          	seqz	a3,a3
 4be:	f9c60593          	addi	a1,a2,-100
 4c2:	e99d                	bnez	a1,4f8 <vprintf+0xb8>
 4c4:	ca95                	beqz	a3,4f8 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 4c6:	008b8493          	addi	s1,s7,8
 4ca:	4685                	li	a3,1
 4cc:	4629                	li	a2,10
 4ce:	000ba583          	lw	a1,0(s7)
 4d2:	855a                	mv	a0,s6
 4d4:	ec9ff0ef          	jal	39c <printint>
        i += 1;
 4d8:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 4da:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 4dc:	4981                	li	s3,0
 4de:	b75d                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 4e0:	008b8493          	addi	s1,s7,8
 4e4:	4685                	li	a3,1
 4e6:	4629                	li	a2,10
 4e8:	000ba583          	lw	a1,0(s7)
 4ec:	855a                	mv	a0,s6
 4ee:	eafff0ef          	jal	39c <printint>
 4f2:	8ba6                	mv	s7,s1
      state = 0;
 4f4:	4981                	li	s3,0
 4f6:	b779                	j	484 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 4f8:	9752                	add	a4,a4,s4
 4fa:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4fe:	f9460713          	addi	a4,a2,-108
 502:	00173713          	seqz	a4,a4
 506:	8f75                	and	a4,a4,a3
 508:	f9c58513          	addi	a0,a1,-100
 50c:	16051963          	bnez	a0,67e <vprintf+0x23e>
 510:	16070763          	beqz	a4,67e <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 514:	008b8493          	addi	s1,s7,8
 518:	4685                	li	a3,1
 51a:	4629                	li	a2,10
 51c:	000ba583          	lw	a1,0(s7)
 520:	855a                	mv	a0,s6
 522:	e7bff0ef          	jal	39c <printint>
        i += 2;
 526:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 528:	8ba6                	mv	s7,s1
      state = 0;
 52a:	4981                	li	s3,0
        i += 2;
 52c:	bfa1                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 52e:	008b8493          	addi	s1,s7,8
 532:	4681                	li	a3,0
 534:	4629                	li	a2,10
 536:	000ba583          	lw	a1,0(s7)
 53a:	855a                	mv	a0,s6
 53c:	e61ff0ef          	jal	39c <printint>
 540:	8ba6                	mv	s7,s1
      state = 0;
 542:	4981                	li	s3,0
 544:	b781                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 546:	008b8493          	addi	s1,s7,8
 54a:	4681                	li	a3,0
 54c:	4629                	li	a2,10
 54e:	000ba583          	lw	a1,0(s7)
 552:	855a                	mv	a0,s6
 554:	e49ff0ef          	jal	39c <printint>
        i += 1;
 558:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 55a:	8ba6                	mv	s7,s1
      state = 0;
 55c:	4981                	li	s3,0
 55e:	b71d                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 560:	008b8493          	addi	s1,s7,8
 564:	4681                	li	a3,0
 566:	4629                	li	a2,10
 568:	000ba583          	lw	a1,0(s7)
 56c:	855a                	mv	a0,s6
 56e:	e2fff0ef          	jal	39c <printint>
        i += 2;
 572:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 574:	8ba6                	mv	s7,s1
      state = 0;
 576:	4981                	li	s3,0
        i += 2;
 578:	b731                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 57a:	008b8493          	addi	s1,s7,8
 57e:	4681                	li	a3,0
 580:	4641                	li	a2,16
 582:	000ba583          	lw	a1,0(s7)
 586:	855a                	mv	a0,s6
 588:	e15ff0ef          	jal	39c <printint>
 58c:	8ba6                	mv	s7,s1
      state = 0;
 58e:	4981                	li	s3,0
 590:	bdd5                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 592:	008b8493          	addi	s1,s7,8
 596:	4681                	li	a3,0
 598:	4641                	li	a2,16
 59a:	000ba583          	lw	a1,0(s7)
 59e:	855a                	mv	a0,s6
 5a0:	dfdff0ef          	jal	39c <printint>
        i += 1;
 5a4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 5a6:	8ba6                	mv	s7,s1
      state = 0;
 5a8:	4981                	li	s3,0
 5aa:	bde9                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5ac:	008b8493          	addi	s1,s7,8
 5b0:	4681                	li	a3,0
 5b2:	4641                	li	a2,16
 5b4:	000ba583          	lw	a1,0(s7)
 5b8:	855a                	mv	a0,s6
 5ba:	de3ff0ef          	jal	39c <printint>
        i += 2;
 5be:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 5c0:	8ba6                	mv	s7,s1
      state = 0;
 5c2:	4981                	li	s3,0
        i += 2;
 5c4:	b5c1                	j	484 <vprintf+0x44>
 5c6:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 5c8:	008b8793          	addi	a5,s7,8
 5cc:	8cbe                	mv	s9,a5
 5ce:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 5d2:	03000593          	li	a1,48
 5d6:	855a                	mv	a0,s6
 5d8:	da7ff0ef          	jal	37e <putc>
  putc(fd, 'x');
 5dc:	07800593          	li	a1,120
 5e0:	855a                	mv	a0,s6
 5e2:	d9dff0ef          	jal	37e <putc>
 5e6:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5e8:	00000b97          	auipc	s7,0x0
 5ec:	2e8b8b93          	addi	s7,s7,744 # 8d0 <digits>
 5f0:	03c9d793          	srli	a5,s3,0x3c
 5f4:	97de                	add	a5,a5,s7
 5f6:	0007c583          	lbu	a1,0(a5)
 5fa:	855a                	mv	a0,s6
 5fc:	d83ff0ef          	jal	37e <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 600:	0992                	slli	s3,s3,0x4
 602:	34fd                	addiw	s1,s1,-1
 604:	f4f5                	bnez	s1,5f0 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 606:	8be6                	mv	s7,s9
      state = 0;
 608:	4981                	li	s3,0
 60a:	6ca2                	ld	s9,8(sp)
 60c:	bda5                	j	484 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 60e:	008b8993          	addi	s3,s7,8
 612:	000bb483          	ld	s1,0(s7)
 616:	cc91                	beqz	s1,632 <vprintf+0x1f2>
        for(; *s; s++)
 618:	0004c583          	lbu	a1,0(s1)
 61c:	c985                	beqz	a1,64c <vprintf+0x20c>
          putc(fd, *s);
 61e:	855a                	mv	a0,s6
 620:	d5fff0ef          	jal	37e <putc>
        for(; *s; s++)
 624:	0485                	addi	s1,s1,1
 626:	0004c583          	lbu	a1,0(s1)
 62a:	f9f5                	bnez	a1,61e <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 62c:	8bce                	mv	s7,s3
      state = 0;
 62e:	4981                	li	s3,0
 630:	bd91                	j	484 <vprintf+0x44>
          s = "(null)";
 632:	00000497          	auipc	s1,0x0
 636:	29648493          	addi	s1,s1,662 # 8c8 <malloc+0x102>
        for(; *s; s++)
 63a:	02800593          	li	a1,40
 63e:	b7c5                	j	61e <vprintf+0x1de>
        putc(fd, '%');
 640:	85be                	mv	a1,a5
 642:	855a                	mv	a0,s6
 644:	d3bff0ef          	jal	37e <putc>
      state = 0;
 648:	4981                	li	s3,0
 64a:	bd2d                	j	484 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 64c:	8bce                	mv	s7,s3
      state = 0;
 64e:	4981                	li	s3,0
 650:	bd15                	j	484 <vprintf+0x44>
 652:	6906                	ld	s2,64(sp)
 654:	79e2                	ld	s3,56(sp)
 656:	7a42                	ld	s4,48(sp)
 658:	7aa2                	ld	s5,40(sp)
 65a:	7b02                	ld	s6,32(sp)
 65c:	6be2                	ld	s7,24(sp)
 65e:	6c42                	ld	s8,16(sp)
    }
  }
}
 660:	60e6                	ld	ra,88(sp)
 662:	6446                	ld	s0,80(sp)
 664:	64a6                	ld	s1,72(sp)
 666:	6125                	addi	sp,sp,96
 668:	8082                	ret
      if(c0 == 'd'){
 66a:	06400713          	li	a4,100
 66e:	e6e789e3          	beq	a5,a4,4e0 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 672:	f9478693          	addi	a3,a5,-108
 676:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 67a:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 67c:	4701                	li	a4,0
      } else if(c0 == 'u'){
 67e:	07500513          	li	a0,117
 682:	eaa786e3          	beq	a5,a0,52e <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 686:	f8b60513          	addi	a0,a2,-117
 68a:	e119                	bnez	a0,690 <vprintf+0x250>
 68c:	ea069de3          	bnez	a3,546 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 690:	f8b58513          	addi	a0,a1,-117
 694:	e119                	bnez	a0,69a <vprintf+0x25a>
 696:	ec0715e3          	bnez	a4,560 <vprintf+0x120>
      } else if(c0 == 'x'){
 69a:	07800513          	li	a0,120
 69e:	eca78ee3          	beq	a5,a0,57a <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 6a2:	f8860613          	addi	a2,a2,-120
 6a6:	e219                	bnez	a2,6ac <vprintf+0x26c>
 6a8:	ee0695e3          	bnez	a3,592 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6ac:	f8858593          	addi	a1,a1,-120
 6b0:	e199                	bnez	a1,6b6 <vprintf+0x276>
 6b2:	ee071de3          	bnez	a4,5ac <vprintf+0x16c>
      } else if(c0 == 'p'){
 6b6:	07000713          	li	a4,112
 6ba:	f0e786e3          	beq	a5,a4,5c6 <vprintf+0x186>
      } else if(c0 == 's'){
 6be:	07300713          	li	a4,115
 6c2:	f4e786e3          	beq	a5,a4,60e <vprintf+0x1ce>
      } else if(c0 == '%'){
 6c6:	02500713          	li	a4,37
 6ca:	f6e78be3          	beq	a5,a4,640 <vprintf+0x200>
        putc(fd, '%');
 6ce:	02500593          	li	a1,37
 6d2:	855a                	mv	a0,s6
 6d4:	cabff0ef          	jal	37e <putc>
        putc(fd, c0);
 6d8:	85a6                	mv	a1,s1
 6da:	855a                	mv	a0,s6
 6dc:	ca3ff0ef          	jal	37e <putc>
      state = 0;
 6e0:	4981                	li	s3,0
 6e2:	b34d                	j	484 <vprintf+0x44>

00000000000006e4 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6e4:	715d                	addi	sp,sp,-80
 6e6:	ec06                	sd	ra,24(sp)
 6e8:	e822                	sd	s0,16(sp)
 6ea:	1000                	addi	s0,sp,32
 6ec:	e010                	sd	a2,0(s0)
 6ee:	e414                	sd	a3,8(s0)
 6f0:	e818                	sd	a4,16(s0)
 6f2:	ec1c                	sd	a5,24(s0)
 6f4:	03043023          	sd	a6,32(s0)
 6f8:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6fc:	8622                	mv	a2,s0
 6fe:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 702:	d3fff0ef          	jal	440 <vprintf>
}
 706:	60e2                	ld	ra,24(sp)
 708:	6442                	ld	s0,16(sp)
 70a:	6161                	addi	sp,sp,80
 70c:	8082                	ret

000000000000070e <printf>:

void
printf(const char *fmt, ...)
{
 70e:	711d                	addi	sp,sp,-96
 710:	ec06                	sd	ra,24(sp)
 712:	e822                	sd	s0,16(sp)
 714:	1000                	addi	s0,sp,32
 716:	e40c                	sd	a1,8(s0)
 718:	e810                	sd	a2,16(s0)
 71a:	ec14                	sd	a3,24(s0)
 71c:	f018                	sd	a4,32(s0)
 71e:	f41c                	sd	a5,40(s0)
 720:	03043823          	sd	a6,48(s0)
 724:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 728:	00840613          	addi	a2,s0,8
 72c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 730:	85aa                	mv	a1,a0
 732:	4505                	li	a0,1
 734:	d0dff0ef          	jal	440 <vprintf>
}
 738:	60e2                	ld	ra,24(sp)
 73a:	6442                	ld	s0,16(sp)
 73c:	6125                	addi	sp,sp,96
 73e:	8082                	ret

0000000000000740 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 740:	1141                	addi	sp,sp,-16
 742:	e406                	sd	ra,8(sp)
 744:	e022                	sd	s0,0(sp)
 746:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 748:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 74c:	00001797          	auipc	a5,0x1
 750:	8b47b783          	ld	a5,-1868(a5) # 1000 <freep>
 754:	a039                	j	762 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 756:	6398                	ld	a4,0(a5)
 758:	00e7e463          	bltu	a5,a4,760 <free+0x20>
 75c:	00e6ea63          	bltu	a3,a4,770 <free+0x30>
{
 760:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 762:	fed7fae3          	bgeu	a5,a3,756 <free+0x16>
 766:	6398                	ld	a4,0(a5)
 768:	00e6e463          	bltu	a3,a4,770 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 76c:	fee7eae3          	bltu	a5,a4,760 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 770:	ff852583          	lw	a1,-8(a0)
 774:	6390                	ld	a2,0(a5)
 776:	02059813          	slli	a6,a1,0x20
 77a:	01c85713          	srli	a4,a6,0x1c
 77e:	9736                	add	a4,a4,a3
 780:	02e60563          	beq	a2,a4,7aa <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 784:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 788:	4790                	lw	a2,8(a5)
 78a:	02061593          	slli	a1,a2,0x20
 78e:	01c5d713          	srli	a4,a1,0x1c
 792:	973e                	add	a4,a4,a5
 794:	02e68263          	beq	a3,a4,7b8 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 798:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 79a:	00001717          	auipc	a4,0x1
 79e:	86f73323          	sd	a5,-1946(a4) # 1000 <freep>
}
 7a2:	60a2                	ld	ra,8(sp)
 7a4:	6402                	ld	s0,0(sp)
 7a6:	0141                	addi	sp,sp,16
 7a8:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 7aa:	4618                	lw	a4,8(a2)
 7ac:	9f2d                	addw	a4,a4,a1
 7ae:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 7b2:	6398                	ld	a4,0(a5)
 7b4:	6310                	ld	a2,0(a4)
 7b6:	b7f9                	j	784 <free+0x44>
    p->s.size += bp->s.size;
 7b8:	ff852703          	lw	a4,-8(a0)
 7bc:	9f31                	addw	a4,a4,a2
 7be:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 7c0:	ff053683          	ld	a3,-16(a0)
 7c4:	bfd1                	j	798 <free+0x58>

00000000000007c6 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7c6:	7139                	addi	sp,sp,-64
 7c8:	fc06                	sd	ra,56(sp)
 7ca:	f822                	sd	s0,48(sp)
 7cc:	f04a                	sd	s2,32(sp)
 7ce:	ec4e                	sd	s3,24(sp)
 7d0:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7d2:	02051993          	slli	s3,a0,0x20
 7d6:	0209d993          	srli	s3,s3,0x20
 7da:	09bd                	addi	s3,s3,15
 7dc:	0049d993          	srli	s3,s3,0x4
 7e0:	2985                	addiw	s3,s3,1
 7e2:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7e4:	00001517          	auipc	a0,0x1
 7e8:	81c53503          	ld	a0,-2020(a0) # 1000 <freep>
 7ec:	c905                	beqz	a0,81c <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7ee:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7f0:	4798                	lw	a4,8(a5)
 7f2:	09377663          	bgeu	a4,s3,87e <malloc+0xb8>
 7f6:	f426                	sd	s1,40(sp)
 7f8:	e852                	sd	s4,16(sp)
 7fa:	e456                	sd	s5,8(sp)
 7fc:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 7fe:	8a4e                	mv	s4,s3
 800:	6705                	lui	a4,0x1
 802:	00e9f363          	bgeu	s3,a4,808 <malloc+0x42>
 806:	6a05                	lui	s4,0x1
 808:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 80c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 810:	00000497          	auipc	s1,0x0
 814:	7f048493          	addi	s1,s1,2032 # 1000 <freep>
  if(p == (char*)-1)
 818:	5afd                	li	s5,-1
 81a:	a83d                	j	858 <malloc+0x92>
 81c:	f426                	sd	s1,40(sp)
 81e:	e852                	sd	s4,16(sp)
 820:	e456                	sd	s5,8(sp)
 822:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 824:	00000797          	auipc	a5,0x0
 828:	7ec78793          	addi	a5,a5,2028 # 1010 <base>
 82c:	00000717          	auipc	a4,0x0
 830:	7cf73a23          	sd	a5,2004(a4) # 1000 <freep>
 834:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 836:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 83a:	b7d1                	j	7fe <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 83c:	6398                	ld	a4,0(a5)
 83e:	e118                	sd	a4,0(a0)
 840:	a899                	j	896 <malloc+0xd0>
  hp->s.size = nu;
 842:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 846:	0541                	addi	a0,a0,16
 848:	ef9ff0ef          	jal	740 <free>
  return freep;
 84c:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 84e:	c125                	beqz	a0,8ae <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 850:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 852:	4798                	lw	a4,8(a5)
 854:	03277163          	bgeu	a4,s2,876 <malloc+0xb0>
    if(p == freep)
 858:	6098                	ld	a4,0(s1)
 85a:	853e                	mv	a0,a5
 85c:	fef71ae3          	bne	a4,a5,850 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 860:	8552                	mv	a0,s4
 862:	af5ff0ef          	jal	356 <sbrk>
  if(p == (char*)-1)
 866:	fd551ee3          	bne	a0,s5,842 <malloc+0x7c>
        return 0;
 86a:	4501                	li	a0,0
 86c:	74a2                	ld	s1,40(sp)
 86e:	6a42                	ld	s4,16(sp)
 870:	6aa2                	ld	s5,8(sp)
 872:	6b02                	ld	s6,0(sp)
 874:	a03d                	j	8a2 <malloc+0xdc>
 876:	74a2                	ld	s1,40(sp)
 878:	6a42                	ld	s4,16(sp)
 87a:	6aa2                	ld	s5,8(sp)
 87c:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 87e:	fae90fe3          	beq	s2,a4,83c <malloc+0x76>
        p->s.size -= nunits;
 882:	4137073b          	subw	a4,a4,s3
 886:	c798                	sw	a4,8(a5)
        p += p->s.size;
 888:	02071693          	slli	a3,a4,0x20
 88c:	01c6d713          	srli	a4,a3,0x1c
 890:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 892:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 896:	00000717          	auipc	a4,0x0
 89a:	76a73523          	sd	a0,1898(a4) # 1000 <freep>
      return (void*)(p + 1);
 89e:	01078513          	addi	a0,a5,16
  }
}
 8a2:	70e2                	ld	ra,56(sp)
 8a4:	7442                	ld	s0,48(sp)
 8a6:	7902                	ld	s2,32(sp)
 8a8:	69e2                	ld	s3,24(sp)
 8aa:	6121                	addi	sp,sp,64
 8ac:	8082                	ret
 8ae:	74a2                	ld	s1,40(sp)
 8b0:	6a42                	ld	s4,16(sp)
 8b2:	6aa2                	ld	s5,8(sp)
 8b4:	6b02                	ld	s6,0(sp)
 8b6:	b7f5                	j	8a2 <malloc+0xdc>
