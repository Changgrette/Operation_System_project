
user/_grep:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <matchstar>:
  return 0;
}

// matchstar: search for c*re at beginning of text
int matchstar(int c, char *re, char *text)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	e052                	sd	s4,0(sp)
   e:	1800                	addi	s0,sp,48
  10:	892a                	mv	s2,a0
  12:	89ae                	mv	s3,a1
  14:	84b2                	mv	s1,a2
  do{  // a * matches zero or more instances
    if(matchhere(re, text))
      return 1;
  }while(*text!='\0' && (*text++==c || c=='.'));
  16:	fd250a13          	addi	s4,a0,-46
  1a:	001a3a13          	seqz	s4,s4
    if(matchhere(re, text))
  1e:	85a6                	mv	a1,s1
  20:	854e                	mv	a0,s3
  22:	02a000ef          	jal	4c <matchhere>
  26:	e911                	bnez	a0,3a <matchstar+0x3a>
  }while(*text!='\0' && (*text++==c || c=='.'));
  28:	0004c783          	lbu	a5,0(s1)
  2c:	cb81                	beqz	a5,3c <matchstar+0x3c>
  2e:	0485                	addi	s1,s1,1
  30:	ff2787e3          	beq	a5,s2,1e <matchstar+0x1e>
  34:	fe0a15e3          	bnez	s4,1e <matchstar+0x1e>
  38:	a011                	j	3c <matchstar+0x3c>
      return 1;
  3a:	4505                	li	a0,1
  return 0;
}
  3c:	70a2                	ld	ra,40(sp)
  3e:	7402                	ld	s0,32(sp)
  40:	64e2                	ld	s1,24(sp)
  42:	6942                	ld	s2,16(sp)
  44:	69a2                	ld	s3,8(sp)
  46:	6a02                	ld	s4,0(sp)
  48:	6145                	addi	sp,sp,48
  4a:	8082                	ret

000000000000004c <matchhere>:
  if(re[0] == '\0')
  4c:	00054703          	lbu	a4,0(a0)
  50:	cf39                	beqz	a4,ae <matchhere+0x62>
{
  52:	1141                	addi	sp,sp,-16
  54:	e406                	sd	ra,8(sp)
  56:	e022                	sd	s0,0(sp)
  58:	0800                	addi	s0,sp,16
  5a:	87aa                	mv	a5,a0
  if(re[1] == '*')
  5c:	00154683          	lbu	a3,1(a0)
  60:	02a00613          	li	a2,42
  64:	02c68363          	beq	a3,a2,8a <matchhere+0x3e>
  if(re[0] == '$' && re[1] == '\0')
  68:	e681                	bnez	a3,70 <matchhere+0x24>
  6a:	fdc70693          	addi	a3,a4,-36
  6e:	c68d                	beqz	a3,98 <matchhere+0x4c>
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
  70:	0005c683          	lbu	a3,0(a1)
  return 0;
  74:	4501                	li	a0,0
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
  76:	c691                	beqz	a3,82 <matchhere+0x36>
  78:	02d70563          	beq	a4,a3,a2 <matchhere+0x56>
  7c:	fd270713          	addi	a4,a4,-46
  80:	c30d                	beqz	a4,a2 <matchhere+0x56>
}
  82:	60a2                	ld	ra,8(sp)
  84:	6402                	ld	s0,0(sp)
  86:	0141                	addi	sp,sp,16
  88:	8082                	ret
    return matchstar(re[0], re+2, text);
  8a:	862e                	mv	a2,a1
  8c:	00250593          	addi	a1,a0,2
  90:	853a                	mv	a0,a4
  92:	f6fff0ef          	jal	0 <matchstar>
  96:	b7f5                	j	82 <matchhere+0x36>
    return *text == '\0';
  98:	0005c503          	lbu	a0,0(a1)
  9c:	00153513          	seqz	a0,a0
  a0:	b7cd                	j	82 <matchhere+0x36>
    return matchhere(re+1, text+1);
  a2:	0585                	addi	a1,a1,1
  a4:	00178513          	addi	a0,a5,1
  a8:	fa5ff0ef          	jal	4c <matchhere>
  ac:	bfd9                	j	82 <matchhere+0x36>
    return 1;
  ae:	4505                	li	a0,1
}
  b0:	8082                	ret

00000000000000b2 <match>:
{
  b2:	1101                	addi	sp,sp,-32
  b4:	ec06                	sd	ra,24(sp)
  b6:	e822                	sd	s0,16(sp)
  b8:	e426                	sd	s1,8(sp)
  ba:	e04a                	sd	s2,0(sp)
  bc:	1000                	addi	s0,sp,32
  be:	892a                	mv	s2,a0
  c0:	84ae                	mv	s1,a1
  if(re[0] == '^')
  c2:	00054703          	lbu	a4,0(a0)
  c6:	05e00793          	li	a5,94
  ca:	00f70c63          	beq	a4,a5,e2 <match+0x30>
    if(matchhere(re, text))
  ce:	85a6                	mv	a1,s1
  d0:	854a                	mv	a0,s2
  d2:	f7bff0ef          	jal	4c <matchhere>
  d6:	e911                	bnez	a0,ea <match+0x38>
  }while(*text++ != '\0');
  d8:	0485                	addi	s1,s1,1
  da:	fff4c783          	lbu	a5,-1(s1)
  de:	fbe5                	bnez	a5,ce <match+0x1c>
  e0:	a031                	j	ec <match+0x3a>
    return matchhere(re+1, text);
  e2:	0505                	addi	a0,a0,1
  e4:	f69ff0ef          	jal	4c <matchhere>
  e8:	a011                	j	ec <match+0x3a>
      return 1;
  ea:	4505                	li	a0,1
}
  ec:	60e2                	ld	ra,24(sp)
  ee:	6442                	ld	s0,16(sp)
  f0:	64a2                	ld	s1,8(sp)
  f2:	6902                	ld	s2,0(sp)
  f4:	6105                	addi	sp,sp,32
  f6:	8082                	ret

00000000000000f8 <grep>:
{
  f8:	711d                	addi	sp,sp,-96
  fa:	ec86                	sd	ra,88(sp)
  fc:	e8a2                	sd	s0,80(sp)
  fe:	e4a6                	sd	s1,72(sp)
 100:	e0ca                	sd	s2,64(sp)
 102:	fc4e                	sd	s3,56(sp)
 104:	f852                	sd	s4,48(sp)
 106:	f456                	sd	s5,40(sp)
 108:	f05a                	sd	s6,32(sp)
 10a:	ec5e                	sd	s7,24(sp)
 10c:	e862                	sd	s8,16(sp)
 10e:	e466                	sd	s9,8(sp)
 110:	e06a                	sd	s10,0(sp)
 112:	1080                	addi	s0,sp,96
 114:	8aaa                	mv	s5,a0
 116:	8cae                	mv	s9,a1
  m = 0;
 118:	4b01                	li	s6,0
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 11a:	3ff00d13          	li	s10,1023
 11e:	00001b97          	auipc	s7,0x1
 122:	ef2b8b93          	addi	s7,s7,-270 # 1010 <buf>
    while((q = strchr(p, '\n')) != 0){
 126:	49a9                	li	s3,10
        write(1, p, q+1 - p);
 128:	4c05                	li	s8,1
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 12a:	a82d                	j	164 <grep+0x6c>
      p = q+1;
 12c:	00148913          	addi	s2,s1,1
    while((q = strchr(p, '\n')) != 0){
 130:	85ce                	mv	a1,s3
 132:	854a                	mv	a0,s2
 134:	1dc000ef          	jal	310 <strchr>
 138:	84aa                	mv	s1,a0
 13a:	c11d                	beqz	a0,160 <grep+0x68>
      *q = 0;
 13c:	00048023          	sb	zero,0(s1)
      if(match(pattern, p)){
 140:	85ca                	mv	a1,s2
 142:	8556                	mv	a0,s5
 144:	f6fff0ef          	jal	b2 <match>
 148:	d175                	beqz	a0,12c <grep+0x34>
        *q = '\n';
 14a:	01348023          	sb	s3,0(s1)
        write(1, p, q+1 - p);
 14e:	00148613          	addi	a2,s1,1
 152:	4126063b          	subw	a2,a2,s2
 156:	85ca                	mv	a1,s2
 158:	8562                	mv	a0,s8
 15a:	3c8000ef          	jal	522 <write>
 15e:	b7f9                	j	12c <grep+0x34>
    if(m > 0){
 160:	03604463          	bgtz	s6,188 <grep+0x90>
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 164:	416d063b          	subw	a2,s10,s6
 168:	016b85b3          	add	a1,s7,s6
 16c:	8566                	mv	a0,s9
 16e:	3ac000ef          	jal	51a <read>
 172:	02a05c63          	blez	a0,1aa <grep+0xb2>
    m += n;
 176:	00ab0a3b          	addw	s4,s6,a0
 17a:	8b52                	mv	s6,s4
    buf[m] = '\0';
 17c:	014b87b3          	add	a5,s7,s4
 180:	00078023          	sb	zero,0(a5)
    p = buf;
 184:	895e                	mv	s2,s7
    while((q = strchr(p, '\n')) != 0){
 186:	b76d                	j	130 <grep+0x38>
      m -= p - buf;
 188:	00001797          	auipc	a5,0x1
 18c:	e8878793          	addi	a5,a5,-376 # 1010 <buf>
 190:	40f907b3          	sub	a5,s2,a5
 194:	40fa063b          	subw	a2,s4,a5
 198:	8b32                	mv	s6,a2
      memmove(buf, p, m);
 19a:	85ca                	mv	a1,s2
 19c:	00001517          	auipc	a0,0x1
 1a0:	e7450513          	addi	a0,a0,-396 # 1010 <buf>
 1a4:	292000ef          	jal	436 <memmove>
 1a8:	bf75                	j	164 <grep+0x6c>
}
 1aa:	60e6                	ld	ra,88(sp)
 1ac:	6446                	ld	s0,80(sp)
 1ae:	64a6                	ld	s1,72(sp)
 1b0:	6906                	ld	s2,64(sp)
 1b2:	79e2                	ld	s3,56(sp)
 1b4:	7a42                	ld	s4,48(sp)
 1b6:	7aa2                	ld	s5,40(sp)
 1b8:	7b02                	ld	s6,32(sp)
 1ba:	6be2                	ld	s7,24(sp)
 1bc:	6c42                	ld	s8,16(sp)
 1be:	6ca2                	ld	s9,8(sp)
 1c0:	6d02                	ld	s10,0(sp)
 1c2:	6125                	addi	sp,sp,96
 1c4:	8082                	ret

00000000000001c6 <main>:
{
 1c6:	7179                	addi	sp,sp,-48
 1c8:	f406                	sd	ra,40(sp)
 1ca:	f022                	sd	s0,32(sp)
 1cc:	ec26                	sd	s1,24(sp)
 1ce:	e84a                	sd	s2,16(sp)
 1d0:	e44e                	sd	s3,8(sp)
 1d2:	e052                	sd	s4,0(sp)
 1d4:	1800                	addi	s0,sp,48
  if(argc <= 1){
 1d6:	4785                	li	a5,1
 1d8:	04a7d663          	bge	a5,a0,224 <main+0x5e>
  pattern = argv[1];
 1dc:	0085ba03          	ld	s4,8(a1)
  if(argc <= 2){
 1e0:	4789                	li	a5,2
 1e2:	04a7db63          	bge	a5,a0,238 <main+0x72>
 1e6:	01058913          	addi	s2,a1,16
 1ea:	ffd5099b          	addiw	s3,a0,-3
 1ee:	02099793          	slli	a5,s3,0x20
 1f2:	01d7d993          	srli	s3,a5,0x1d
 1f6:	05e1                	addi	a1,a1,24
 1f8:	99ae                	add	s3,s3,a1
    if((fd = open(argv[i], O_RDONLY)) < 0){
 1fa:	4581                	li	a1,0
 1fc:	00093503          	ld	a0,0(s2)
 200:	342000ef          	jal	542 <open>
 204:	84aa                	mv	s1,a0
 206:	04054063          	bltz	a0,246 <main+0x80>
    grep(pattern, fd);
 20a:	85aa                	mv	a1,a0
 20c:	8552                	mv	a0,s4
 20e:	eebff0ef          	jal	f8 <grep>
    close(fd);
 212:	8526                	mv	a0,s1
 214:	316000ef          	jal	52a <close>
  for(i = 2; i < argc; i++){
 218:	0921                	addi	s2,s2,8
 21a:	ff3910e3          	bne	s2,s3,1fa <main+0x34>
  exit(0);
 21e:	4501                	li	a0,0
 220:	2e2000ef          	jal	502 <exit>
    fprintf(2, "usage: grep pattern [file ...]\n");
 224:	00001597          	auipc	a1,0x1
 228:	8fc58593          	addi	a1,a1,-1796 # b20 <malloc+0x100>
 22c:	4509                	li	a0,2
 22e:	710000ef          	jal	93e <fprintf>
    exit(1);
 232:	4505                	li	a0,1
 234:	2ce000ef          	jal	502 <exit>
    grep(pattern, 0);
 238:	4581                	li	a1,0
 23a:	8552                	mv	a0,s4
 23c:	ebdff0ef          	jal	f8 <grep>
    exit(0);
 240:	4501                	li	a0,0
 242:	2c0000ef          	jal	502 <exit>
      printf("grep: cannot open %s\n", argv[i]);
 246:	00093583          	ld	a1,0(s2)
 24a:	00001517          	auipc	a0,0x1
 24e:	8f650513          	addi	a0,a0,-1802 # b40 <malloc+0x120>
 252:	716000ef          	jal	968 <printf>
      exit(1);
 256:	4505                	li	a0,1
 258:	2aa000ef          	jal	502 <exit>

000000000000025c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 25c:	1141                	addi	sp,sp,-16
 25e:	e406                	sd	ra,8(sp)
 260:	e022                	sd	s0,0(sp)
 262:	0800                	addi	s0,sp,16
  extern int main();
  main();
 264:	f63ff0ef          	jal	1c6 <main>
  exit(0);
 268:	4501                	li	a0,0
 26a:	298000ef          	jal	502 <exit>

000000000000026e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 26e:	1141                	addi	sp,sp,-16
 270:	e406                	sd	ra,8(sp)
 272:	e022                	sd	s0,0(sp)
 274:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 276:	87aa                	mv	a5,a0
 278:	0585                	addi	a1,a1,1
 27a:	0785                	addi	a5,a5,1
 27c:	fff5c703          	lbu	a4,-1(a1)
 280:	fee78fa3          	sb	a4,-1(a5)
 284:	fb75                	bnez	a4,278 <strcpy+0xa>
    ;
  return os;
}
 286:	60a2                	ld	ra,8(sp)
 288:	6402                	ld	s0,0(sp)
 28a:	0141                	addi	sp,sp,16
 28c:	8082                	ret

000000000000028e <strcmp>:

int
strcmp(const char *p, const char *q)
{
 28e:	1141                	addi	sp,sp,-16
 290:	e406                	sd	ra,8(sp)
 292:	e022                	sd	s0,0(sp)
 294:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 296:	00054783          	lbu	a5,0(a0)
 29a:	cb91                	beqz	a5,2ae <strcmp+0x20>
 29c:	0005c703          	lbu	a4,0(a1)
 2a0:	00f71763          	bne	a4,a5,2ae <strcmp+0x20>
    p++, q++;
 2a4:	0505                	addi	a0,a0,1
 2a6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2a8:	00054783          	lbu	a5,0(a0)
 2ac:	fbe5                	bnez	a5,29c <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 2ae:	0005c503          	lbu	a0,0(a1)
}
 2b2:	40a7853b          	subw	a0,a5,a0
 2b6:	60a2                	ld	ra,8(sp)
 2b8:	6402                	ld	s0,0(sp)
 2ba:	0141                	addi	sp,sp,16
 2bc:	8082                	ret

00000000000002be <strlen>:

uint
strlen(const char *s)
{
 2be:	1141                	addi	sp,sp,-16
 2c0:	e406                	sd	ra,8(sp)
 2c2:	e022                	sd	s0,0(sp)
 2c4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2c6:	00054783          	lbu	a5,0(a0)
 2ca:	cf91                	beqz	a5,2e6 <strlen+0x28>
 2cc:	00150793          	addi	a5,a0,1
 2d0:	86be                	mv	a3,a5
 2d2:	0785                	addi	a5,a5,1
 2d4:	fff7c703          	lbu	a4,-1(a5)
 2d8:	ff65                	bnez	a4,2d0 <strlen+0x12>
 2da:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 2de:	60a2                	ld	ra,8(sp)
 2e0:	6402                	ld	s0,0(sp)
 2e2:	0141                	addi	sp,sp,16
 2e4:	8082                	ret
  for(n = 0; s[n]; n++)
 2e6:	4501                	li	a0,0
 2e8:	bfdd                	j	2de <strlen+0x20>

00000000000002ea <memset>:

void*
memset(void *dst, int c, uint n)
{
 2ea:	1141                	addi	sp,sp,-16
 2ec:	e406                	sd	ra,8(sp)
 2ee:	e022                	sd	s0,0(sp)
 2f0:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2f2:	ca19                	beqz	a2,308 <memset+0x1e>
 2f4:	87aa                	mv	a5,a0
 2f6:	1602                	slli	a2,a2,0x20
 2f8:	9201                	srli	a2,a2,0x20
 2fa:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2fe:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 302:	0785                	addi	a5,a5,1
 304:	fee79de3          	bne	a5,a4,2fe <memset+0x14>
  }
  return dst;
}
 308:	60a2                	ld	ra,8(sp)
 30a:	6402                	ld	s0,0(sp)
 30c:	0141                	addi	sp,sp,16
 30e:	8082                	ret

0000000000000310 <strchr>:

char*
strchr(const char *s, char c)
{
 310:	1141                	addi	sp,sp,-16
 312:	e406                	sd	ra,8(sp)
 314:	e022                	sd	s0,0(sp)
 316:	0800                	addi	s0,sp,16
  for(; *s; s++)
 318:	00054783          	lbu	a5,0(a0)
 31c:	cf81                	beqz	a5,334 <strchr+0x24>
    if(*s == c)
 31e:	00f58763          	beq	a1,a5,32c <strchr+0x1c>
  for(; *s; s++)
 322:	0505                	addi	a0,a0,1
 324:	00054783          	lbu	a5,0(a0)
 328:	fbfd                	bnez	a5,31e <strchr+0xe>
      return (char*)s;
  return 0;
 32a:	4501                	li	a0,0
}
 32c:	60a2                	ld	ra,8(sp)
 32e:	6402                	ld	s0,0(sp)
 330:	0141                	addi	sp,sp,16
 332:	8082                	ret
  return 0;
 334:	4501                	li	a0,0
 336:	bfdd                	j	32c <strchr+0x1c>

0000000000000338 <gets>:

char*
gets(char *buf, int max)
{
 338:	711d                	addi	sp,sp,-96
 33a:	ec86                	sd	ra,88(sp)
 33c:	e8a2                	sd	s0,80(sp)
 33e:	e4a6                	sd	s1,72(sp)
 340:	e0ca                	sd	s2,64(sp)
 342:	fc4e                	sd	s3,56(sp)
 344:	f852                	sd	s4,48(sp)
 346:	f456                	sd	s5,40(sp)
 348:	f05a                	sd	s6,32(sp)
 34a:	ec5e                	sd	s7,24(sp)
 34c:	e862                	sd	s8,16(sp)
 34e:	1080                	addi	s0,sp,96
 350:	8baa                	mv	s7,a0
 352:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 354:	892a                	mv	s2,a0
 356:	4481                	li	s1,0
    cc = read(0, &c, 1);
 358:	faf40b13          	addi	s6,s0,-81
 35c:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 35e:	8c26                	mv	s8,s1
 360:	0014899b          	addiw	s3,s1,1
 364:	84ce                	mv	s1,s3
 366:	0349d463          	bge	s3,s4,38e <gets+0x56>
    cc = read(0, &c, 1);
 36a:	8656                	mv	a2,s5
 36c:	85da                	mv	a1,s6
 36e:	4501                	li	a0,0
 370:	1aa000ef          	jal	51a <read>
    if(cc < 1)
 374:	00a05d63          	blez	a0,38e <gets+0x56>
      break;
    buf[i++] = c;
 378:	faf44783          	lbu	a5,-81(s0)
 37c:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 380:	0905                	addi	s2,s2,1
 382:	ff678713          	addi	a4,a5,-10
 386:	c319                	beqz	a4,38c <gets+0x54>
 388:	17cd                	addi	a5,a5,-13
 38a:	fbf1                	bnez	a5,35e <gets+0x26>
    buf[i++] = c;
 38c:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 38e:	9c5e                	add	s8,s8,s7
 390:	000c0023          	sb	zero,0(s8)
  return buf;
}
 394:	855e                	mv	a0,s7
 396:	60e6                	ld	ra,88(sp)
 398:	6446                	ld	s0,80(sp)
 39a:	64a6                	ld	s1,72(sp)
 39c:	6906                	ld	s2,64(sp)
 39e:	79e2                	ld	s3,56(sp)
 3a0:	7a42                	ld	s4,48(sp)
 3a2:	7aa2                	ld	s5,40(sp)
 3a4:	7b02                	ld	s6,32(sp)
 3a6:	6be2                	ld	s7,24(sp)
 3a8:	6c42                	ld	s8,16(sp)
 3aa:	6125                	addi	sp,sp,96
 3ac:	8082                	ret

00000000000003ae <stat>:

int
stat(const char *n, struct stat *st)
{
 3ae:	1101                	addi	sp,sp,-32
 3b0:	ec06                	sd	ra,24(sp)
 3b2:	e822                	sd	s0,16(sp)
 3b4:	e04a                	sd	s2,0(sp)
 3b6:	1000                	addi	s0,sp,32
 3b8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3ba:	4581                	li	a1,0
 3bc:	186000ef          	jal	542 <open>
  if(fd < 0)
 3c0:	02054263          	bltz	a0,3e4 <stat+0x36>
 3c4:	e426                	sd	s1,8(sp)
 3c6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3c8:	85ca                	mv	a1,s2
 3ca:	190000ef          	jal	55a <fstat>
 3ce:	892a                	mv	s2,a0
  close(fd);
 3d0:	8526                	mv	a0,s1
 3d2:	158000ef          	jal	52a <close>
  return r;
 3d6:	64a2                	ld	s1,8(sp)
}
 3d8:	854a                	mv	a0,s2
 3da:	60e2                	ld	ra,24(sp)
 3dc:	6442                	ld	s0,16(sp)
 3de:	6902                	ld	s2,0(sp)
 3e0:	6105                	addi	sp,sp,32
 3e2:	8082                	ret
    return -1;
 3e4:	57fd                	li	a5,-1
 3e6:	893e                	mv	s2,a5
 3e8:	bfc5                	j	3d8 <stat+0x2a>

00000000000003ea <atoi>:

int
atoi(const char *s)
{
 3ea:	1141                	addi	sp,sp,-16
 3ec:	e406                	sd	ra,8(sp)
 3ee:	e022                	sd	s0,0(sp)
 3f0:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3f2:	00054683          	lbu	a3,0(a0)
 3f6:	fd06879b          	addiw	a5,a3,-48
 3fa:	0ff7f793          	zext.b	a5,a5
 3fe:	4625                	li	a2,9
 400:	02f66963          	bltu	a2,a5,432 <atoi+0x48>
 404:	872a                	mv	a4,a0
  n = 0;
 406:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 408:	0705                	addi	a4,a4,1
 40a:	0025179b          	slliw	a5,a0,0x2
 40e:	9fa9                	addw	a5,a5,a0
 410:	0017979b          	slliw	a5,a5,0x1
 414:	9fb5                	addw	a5,a5,a3
 416:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 41a:	00074683          	lbu	a3,0(a4)
 41e:	fd06879b          	addiw	a5,a3,-48
 422:	0ff7f793          	zext.b	a5,a5
 426:	fef671e3          	bgeu	a2,a5,408 <atoi+0x1e>
  return n;
}
 42a:	60a2                	ld	ra,8(sp)
 42c:	6402                	ld	s0,0(sp)
 42e:	0141                	addi	sp,sp,16
 430:	8082                	ret
  n = 0;
 432:	4501                	li	a0,0
 434:	bfdd                	j	42a <atoi+0x40>

0000000000000436 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 436:	1141                	addi	sp,sp,-16
 438:	e406                	sd	ra,8(sp)
 43a:	e022                	sd	s0,0(sp)
 43c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 43e:	02b57563          	bgeu	a0,a1,468 <memmove+0x32>
    while(n-- > 0)
 442:	00c05f63          	blez	a2,460 <memmove+0x2a>
 446:	1602                	slli	a2,a2,0x20
 448:	9201                	srli	a2,a2,0x20
 44a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 44e:	872a                	mv	a4,a0
      *dst++ = *src++;
 450:	0585                	addi	a1,a1,1
 452:	0705                	addi	a4,a4,1
 454:	fff5c683          	lbu	a3,-1(a1)
 458:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 45c:	fee79ae3          	bne	a5,a4,450 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 460:	60a2                	ld	ra,8(sp)
 462:	6402                	ld	s0,0(sp)
 464:	0141                	addi	sp,sp,16
 466:	8082                	ret
    while(n-- > 0)
 468:	fec05ce3          	blez	a2,460 <memmove+0x2a>
    dst += n;
 46c:	00c50733          	add	a4,a0,a2
    src += n;
 470:	95b2                	add	a1,a1,a2
 472:	fff6079b          	addiw	a5,a2,-1
 476:	1782                	slli	a5,a5,0x20
 478:	9381                	srli	a5,a5,0x20
 47a:	fff7c793          	not	a5,a5
 47e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 480:	15fd                	addi	a1,a1,-1
 482:	177d                	addi	a4,a4,-1
 484:	0005c683          	lbu	a3,0(a1)
 488:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 48c:	fef71ae3          	bne	a4,a5,480 <memmove+0x4a>
 490:	bfc1                	j	460 <memmove+0x2a>

0000000000000492 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 492:	1141                	addi	sp,sp,-16
 494:	e406                	sd	ra,8(sp)
 496:	e022                	sd	s0,0(sp)
 498:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 49a:	c61d                	beqz	a2,4c8 <memcmp+0x36>
 49c:	1602                	slli	a2,a2,0x20
 49e:	9201                	srli	a2,a2,0x20
 4a0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 4a4:	00054783          	lbu	a5,0(a0)
 4a8:	0005c703          	lbu	a4,0(a1)
 4ac:	00e79863          	bne	a5,a4,4bc <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 4b0:	0505                	addi	a0,a0,1
    p2++;
 4b2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4b4:	fed518e3          	bne	a0,a3,4a4 <memcmp+0x12>
  }
  return 0;
 4b8:	4501                	li	a0,0
 4ba:	a019                	j	4c0 <memcmp+0x2e>
      return *p1 - *p2;
 4bc:	40e7853b          	subw	a0,a5,a4
}
 4c0:	60a2                	ld	ra,8(sp)
 4c2:	6402                	ld	s0,0(sp)
 4c4:	0141                	addi	sp,sp,16
 4c6:	8082                	ret
  return 0;
 4c8:	4501                	li	a0,0
 4ca:	bfdd                	j	4c0 <memcmp+0x2e>

00000000000004cc <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4cc:	1141                	addi	sp,sp,-16
 4ce:	e406                	sd	ra,8(sp)
 4d0:	e022                	sd	s0,0(sp)
 4d2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4d4:	f63ff0ef          	jal	436 <memmove>
}
 4d8:	60a2                	ld	ra,8(sp)
 4da:	6402                	ld	s0,0(sp)
 4dc:	0141                	addi	sp,sp,16
 4de:	8082                	ret

00000000000004e0 <ugetpid>:

#ifdef LAB_PGTBL
int
ugetpid(void)
{
 4e0:	1141                	addi	sp,sp,-16
 4e2:	e406                	sd	ra,8(sp)
 4e4:	e022                	sd	s0,0(sp)
 4e6:	0800                	addi	s0,sp,16
  struct usyscall *u = (struct usyscall *)USYSCALL;
  return u->pid;
 4e8:	040007b7          	lui	a5,0x4000
 4ec:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3ffebed>
 4ee:	07b2                	slli	a5,a5,0xc
}
 4f0:	4388                	lw	a0,0(a5)
 4f2:	60a2                	ld	ra,8(sp)
 4f4:	6402                	ld	s0,0(sp)
 4f6:	0141                	addi	sp,sp,16
 4f8:	8082                	ret

00000000000004fa <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4fa:	4885                	li	a7,1
 ecall
 4fc:	00000073          	ecall
 ret
 500:	8082                	ret

0000000000000502 <exit>:
.global exit
exit:
 li a7, SYS_exit
 502:	4889                	li	a7,2
 ecall
 504:	00000073          	ecall
 ret
 508:	8082                	ret

000000000000050a <wait>:
.global wait
wait:
 li a7, SYS_wait
 50a:	488d                	li	a7,3
 ecall
 50c:	00000073          	ecall
 ret
 510:	8082                	ret

0000000000000512 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 512:	4891                	li	a7,4
 ecall
 514:	00000073          	ecall
 ret
 518:	8082                	ret

000000000000051a <read>:
.global read
read:
 li a7, SYS_read
 51a:	4895                	li	a7,5
 ecall
 51c:	00000073          	ecall
 ret
 520:	8082                	ret

0000000000000522 <write>:
.global write
write:
 li a7, SYS_write
 522:	48c1                	li	a7,16
 ecall
 524:	00000073          	ecall
 ret
 528:	8082                	ret

000000000000052a <close>:
.global close
close:
 li a7, SYS_close
 52a:	48d5                	li	a7,21
 ecall
 52c:	00000073          	ecall
 ret
 530:	8082                	ret

0000000000000532 <kill>:
.global kill
kill:
 li a7, SYS_kill
 532:	4899                	li	a7,6
 ecall
 534:	00000073          	ecall
 ret
 538:	8082                	ret

000000000000053a <exec>:
.global exec
exec:
 li a7, SYS_exec
 53a:	489d                	li	a7,7
 ecall
 53c:	00000073          	ecall
 ret
 540:	8082                	ret

0000000000000542 <open>:
.global open
open:
 li a7, SYS_open
 542:	48bd                	li	a7,15
 ecall
 544:	00000073          	ecall
 ret
 548:	8082                	ret

000000000000054a <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 54a:	48c5                	li	a7,17
 ecall
 54c:	00000073          	ecall
 ret
 550:	8082                	ret

0000000000000552 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 552:	48c9                	li	a7,18
 ecall
 554:	00000073          	ecall
 ret
 558:	8082                	ret

000000000000055a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 55a:	48a1                	li	a7,8
 ecall
 55c:	00000073          	ecall
 ret
 560:	8082                	ret

0000000000000562 <link>:
.global link
link:
 li a7, SYS_link
 562:	48cd                	li	a7,19
 ecall
 564:	00000073          	ecall
 ret
 568:	8082                	ret

000000000000056a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 56a:	48d1                	li	a7,20
 ecall
 56c:	00000073          	ecall
 ret
 570:	8082                	ret

0000000000000572 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 572:	48a5                	li	a7,9
 ecall
 574:	00000073          	ecall
 ret
 578:	8082                	ret

000000000000057a <dup>:
.global dup
dup:
 li a7, SYS_dup
 57a:	48a9                	li	a7,10
 ecall
 57c:	00000073          	ecall
 ret
 580:	8082                	ret

0000000000000582 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 582:	48ad                	li	a7,11
 ecall
 584:	00000073          	ecall
 ret
 588:	8082                	ret

000000000000058a <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 58a:	48b1                	li	a7,12
 ecall
 58c:	00000073          	ecall
 ret
 590:	8082                	ret

0000000000000592 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 592:	48b5                	li	a7,13
 ecall
 594:	00000073          	ecall
 ret
 598:	8082                	ret

000000000000059a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 59a:	48b9                	li	a7,14
 ecall
 59c:	00000073          	ecall
 ret
 5a0:	8082                	ret

00000000000005a2 <bind>:
.global bind
bind:
 li a7, SYS_bind
 5a2:	48f5                	li	a7,29
 ecall
 5a4:	00000073          	ecall
 ret
 5a8:	8082                	ret

00000000000005aa <unbind>:
.global unbind
unbind:
 li a7, SYS_unbind
 5aa:	48f9                	li	a7,30
 ecall
 5ac:	00000073          	ecall
 ret
 5b0:	8082                	ret

00000000000005b2 <send>:
.global send
send:
 li a7, SYS_send
 5b2:	48fd                	li	a7,31
 ecall
 5b4:	00000073          	ecall
 ret
 5b8:	8082                	ret

00000000000005ba <recv>:
.global recv
recv:
 li a7, SYS_recv
 5ba:	02000893          	li	a7,32
 ecall
 5be:	00000073          	ecall
 ret
 5c2:	8082                	ret

00000000000005c4 <pgpte>:
.global pgpte
pgpte:
 li a7, SYS_pgpte
 5c4:	02100893          	li	a7,33
 ecall
 5c8:	00000073          	ecall
 ret
 5cc:	8082                	ret

00000000000005ce <kpgtbl>:
.global kpgtbl
kpgtbl:
 li a7, SYS_kpgtbl
 5ce:	02200893          	li	a7,34
 ecall
 5d2:	00000073          	ecall
 ret
 5d6:	8082                	ret

00000000000005d8 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 5d8:	1101                	addi	sp,sp,-32
 5da:	ec06                	sd	ra,24(sp)
 5dc:	e822                	sd	s0,16(sp)
 5de:	1000                	addi	s0,sp,32
 5e0:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 5e4:	4605                	li	a2,1
 5e6:	fef40593          	addi	a1,s0,-17
 5ea:	f39ff0ef          	jal	522 <write>
}
 5ee:	60e2                	ld	ra,24(sp)
 5f0:	6442                	ld	s0,16(sp)
 5f2:	6105                	addi	sp,sp,32
 5f4:	8082                	ret

00000000000005f6 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 5f6:	7139                	addi	sp,sp,-64
 5f8:	fc06                	sd	ra,56(sp)
 5fa:	f822                	sd	s0,48(sp)
 5fc:	f04a                	sd	s2,32(sp)
 5fe:	ec4e                	sd	s3,24(sp)
 600:	0080                	addi	s0,sp,64
 602:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 604:	cac9                	beqz	a3,696 <printint+0xa0>
 606:	01f5d79b          	srliw	a5,a1,0x1f
 60a:	c7d1                	beqz	a5,696 <printint+0xa0>
    neg = 1;
    x = -xx;
 60c:	40b005bb          	negw	a1,a1
    neg = 1;
 610:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 612:	fc040993          	addi	s3,s0,-64
  neg = 0;
 616:	86ce                	mv	a3,s3
  i = 0;
 618:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 61a:	00000817          	auipc	a6,0x0
 61e:	54680813          	addi	a6,a6,1350 # b60 <digits>
 622:	88ba                	mv	a7,a4
 624:	0017051b          	addiw	a0,a4,1
 628:	872a                	mv	a4,a0
 62a:	02c5f7bb          	remuw	a5,a1,a2
 62e:	1782                	slli	a5,a5,0x20
 630:	9381                	srli	a5,a5,0x20
 632:	97c2                	add	a5,a5,a6
 634:	0007c783          	lbu	a5,0(a5)
 638:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 63c:	87ae                	mv	a5,a1
 63e:	02c5d5bb          	divuw	a1,a1,a2
 642:	0685                	addi	a3,a3,1
 644:	fcc7ffe3          	bgeu	a5,a2,622 <printint+0x2c>
  if(neg)
 648:	00030c63          	beqz	t1,660 <printint+0x6a>
    buf[i++] = '-';
 64c:	fd050793          	addi	a5,a0,-48
 650:	00878533          	add	a0,a5,s0
 654:	02d00793          	li	a5,45
 658:	fef50823          	sb	a5,-16(a0)
 65c:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 660:	02e05563          	blez	a4,68a <printint+0x94>
 664:	f426                	sd	s1,40(sp)
 666:	377d                	addiw	a4,a4,-1
 668:	00e984b3          	add	s1,s3,a4
 66c:	19fd                	addi	s3,s3,-1
 66e:	99ba                	add	s3,s3,a4
 670:	1702                	slli	a4,a4,0x20
 672:	9301                	srli	a4,a4,0x20
 674:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 678:	0004c583          	lbu	a1,0(s1)
 67c:	854a                	mv	a0,s2
 67e:	f5bff0ef          	jal	5d8 <putc>
  while(--i >= 0)
 682:	14fd                	addi	s1,s1,-1
 684:	ff349ae3          	bne	s1,s3,678 <printint+0x82>
 688:	74a2                	ld	s1,40(sp)
}
 68a:	70e2                	ld	ra,56(sp)
 68c:	7442                	ld	s0,48(sp)
 68e:	7902                	ld	s2,32(sp)
 690:	69e2                	ld	s3,24(sp)
 692:	6121                	addi	sp,sp,64
 694:	8082                	ret
  neg = 0;
 696:	4301                	li	t1,0
 698:	bfad                	j	612 <printint+0x1c>

000000000000069a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 69a:	711d                	addi	sp,sp,-96
 69c:	ec86                	sd	ra,88(sp)
 69e:	e8a2                	sd	s0,80(sp)
 6a0:	e4a6                	sd	s1,72(sp)
 6a2:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 6a4:	0005c483          	lbu	s1,0(a1)
 6a8:	20048963          	beqz	s1,8ba <vprintf+0x220>
 6ac:	e0ca                	sd	s2,64(sp)
 6ae:	fc4e                	sd	s3,56(sp)
 6b0:	f852                	sd	s4,48(sp)
 6b2:	f456                	sd	s5,40(sp)
 6b4:	f05a                	sd	s6,32(sp)
 6b6:	ec5e                	sd	s7,24(sp)
 6b8:	e862                	sd	s8,16(sp)
 6ba:	8b2a                	mv	s6,a0
 6bc:	8a2e                	mv	s4,a1
 6be:	8bb2                	mv	s7,a2
  state = 0;
 6c0:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 6c2:	4901                	li	s2,0
 6c4:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 6c6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 6ca:	06400c13          	li	s8,100
 6ce:	a00d                	j	6f0 <vprintf+0x56>
        putc(fd, c0);
 6d0:	85a6                	mv	a1,s1
 6d2:	855a                	mv	a0,s6
 6d4:	f05ff0ef          	jal	5d8 <putc>
 6d8:	a019                	j	6de <vprintf+0x44>
    } else if(state == '%'){
 6da:	03598363          	beq	s3,s5,700 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 6de:	0019079b          	addiw	a5,s2,1
 6e2:	893e                	mv	s2,a5
 6e4:	873e                	mv	a4,a5
 6e6:	97d2                	add	a5,a5,s4
 6e8:	0007c483          	lbu	s1,0(a5)
 6ec:	1c048063          	beqz	s1,8ac <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 6f0:	0004879b          	sext.w	a5,s1
    if(state == 0){
 6f4:	fe0993e3          	bnez	s3,6da <vprintf+0x40>
      if(c0 == '%'){
 6f8:	fd579ce3          	bne	a5,s5,6d0 <vprintf+0x36>
        state = '%';
 6fc:	89be                	mv	s3,a5
 6fe:	b7c5                	j	6de <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 700:	00ea06b3          	add	a3,s4,a4
 704:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 708:	1a060e63          	beqz	a2,8c4 <vprintf+0x22a>
      if(c0 == 'd'){
 70c:	03878763          	beq	a5,s8,73a <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 710:	f9478693          	addi	a3,a5,-108
 714:	0016b693          	seqz	a3,a3
 718:	f9c60593          	addi	a1,a2,-100
 71c:	e99d                	bnez	a1,752 <vprintf+0xb8>
 71e:	ca95                	beqz	a3,752 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 720:	008b8493          	addi	s1,s7,8
 724:	4685                	li	a3,1
 726:	4629                	li	a2,10
 728:	000ba583          	lw	a1,0(s7)
 72c:	855a                	mv	a0,s6
 72e:	ec9ff0ef          	jal	5f6 <printint>
        i += 1;
 732:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 734:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 736:	4981                	li	s3,0
 738:	b75d                	j	6de <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 73a:	008b8493          	addi	s1,s7,8
 73e:	4685                	li	a3,1
 740:	4629                	li	a2,10
 742:	000ba583          	lw	a1,0(s7)
 746:	855a                	mv	a0,s6
 748:	eafff0ef          	jal	5f6 <printint>
 74c:	8ba6                	mv	s7,s1
      state = 0;
 74e:	4981                	li	s3,0
 750:	b779                	j	6de <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 752:	9752                	add	a4,a4,s4
 754:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 758:	f9460713          	addi	a4,a2,-108
 75c:	00173713          	seqz	a4,a4
 760:	8f75                	and	a4,a4,a3
 762:	f9c58513          	addi	a0,a1,-100
 766:	16051963          	bnez	a0,8d8 <vprintf+0x23e>
 76a:	16070763          	beqz	a4,8d8 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 76e:	008b8493          	addi	s1,s7,8
 772:	4685                	li	a3,1
 774:	4629                	li	a2,10
 776:	000ba583          	lw	a1,0(s7)
 77a:	855a                	mv	a0,s6
 77c:	e7bff0ef          	jal	5f6 <printint>
        i += 2;
 780:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 782:	8ba6                	mv	s7,s1
      state = 0;
 784:	4981                	li	s3,0
        i += 2;
 786:	bfa1                	j	6de <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 788:	008b8493          	addi	s1,s7,8
 78c:	4681                	li	a3,0
 78e:	4629                	li	a2,10
 790:	000ba583          	lw	a1,0(s7)
 794:	855a                	mv	a0,s6
 796:	e61ff0ef          	jal	5f6 <printint>
 79a:	8ba6                	mv	s7,s1
      state = 0;
 79c:	4981                	li	s3,0
 79e:	b781                	j	6de <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7a0:	008b8493          	addi	s1,s7,8
 7a4:	4681                	li	a3,0
 7a6:	4629                	li	a2,10
 7a8:	000ba583          	lw	a1,0(s7)
 7ac:	855a                	mv	a0,s6
 7ae:	e49ff0ef          	jal	5f6 <printint>
        i += 1;
 7b2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b4:	8ba6                	mv	s7,s1
      state = 0;
 7b6:	4981                	li	s3,0
 7b8:	b71d                	j	6de <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7ba:	008b8493          	addi	s1,s7,8
 7be:	4681                	li	a3,0
 7c0:	4629                	li	a2,10
 7c2:	000ba583          	lw	a1,0(s7)
 7c6:	855a                	mv	a0,s6
 7c8:	e2fff0ef          	jal	5f6 <printint>
        i += 2;
 7cc:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7ce:	8ba6                	mv	s7,s1
      state = 0;
 7d0:	4981                	li	s3,0
        i += 2;
 7d2:	b731                	j	6de <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 7d4:	008b8493          	addi	s1,s7,8
 7d8:	4681                	li	a3,0
 7da:	4641                	li	a2,16
 7dc:	000ba583          	lw	a1,0(s7)
 7e0:	855a                	mv	a0,s6
 7e2:	e15ff0ef          	jal	5f6 <printint>
 7e6:	8ba6                	mv	s7,s1
      state = 0;
 7e8:	4981                	li	s3,0
 7ea:	bdd5                	j	6de <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ec:	008b8493          	addi	s1,s7,8
 7f0:	4681                	li	a3,0
 7f2:	4641                	li	a2,16
 7f4:	000ba583          	lw	a1,0(s7)
 7f8:	855a                	mv	a0,s6
 7fa:	dfdff0ef          	jal	5f6 <printint>
        i += 1;
 7fe:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 800:	8ba6                	mv	s7,s1
      state = 0;
 802:	4981                	li	s3,0
 804:	bde9                	j	6de <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 806:	008b8493          	addi	s1,s7,8
 80a:	4681                	li	a3,0
 80c:	4641                	li	a2,16
 80e:	000ba583          	lw	a1,0(s7)
 812:	855a                	mv	a0,s6
 814:	de3ff0ef          	jal	5f6 <printint>
        i += 2;
 818:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 81a:	8ba6                	mv	s7,s1
      state = 0;
 81c:	4981                	li	s3,0
        i += 2;
 81e:	b5c1                	j	6de <vprintf+0x44>
 820:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 822:	008b8793          	addi	a5,s7,8
 826:	8cbe                	mv	s9,a5
 828:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 82c:	03000593          	li	a1,48
 830:	855a                	mv	a0,s6
 832:	da7ff0ef          	jal	5d8 <putc>
  putc(fd, 'x');
 836:	07800593          	li	a1,120
 83a:	855a                	mv	a0,s6
 83c:	d9dff0ef          	jal	5d8 <putc>
 840:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 842:	00000b97          	auipc	s7,0x0
 846:	31eb8b93          	addi	s7,s7,798 # b60 <digits>
 84a:	03c9d793          	srli	a5,s3,0x3c
 84e:	97de                	add	a5,a5,s7
 850:	0007c583          	lbu	a1,0(a5)
 854:	855a                	mv	a0,s6
 856:	d83ff0ef          	jal	5d8 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 85a:	0992                	slli	s3,s3,0x4
 85c:	34fd                	addiw	s1,s1,-1
 85e:	f4f5                	bnez	s1,84a <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 860:	8be6                	mv	s7,s9
      state = 0;
 862:	4981                	li	s3,0
 864:	6ca2                	ld	s9,8(sp)
 866:	bda5                	j	6de <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 868:	008b8993          	addi	s3,s7,8
 86c:	000bb483          	ld	s1,0(s7)
 870:	cc91                	beqz	s1,88c <vprintf+0x1f2>
        for(; *s; s++)
 872:	0004c583          	lbu	a1,0(s1)
 876:	c985                	beqz	a1,8a6 <vprintf+0x20c>
          putc(fd, *s);
 878:	855a                	mv	a0,s6
 87a:	d5fff0ef          	jal	5d8 <putc>
        for(; *s; s++)
 87e:	0485                	addi	s1,s1,1
 880:	0004c583          	lbu	a1,0(s1)
 884:	f9f5                	bnez	a1,878 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 886:	8bce                	mv	s7,s3
      state = 0;
 888:	4981                	li	s3,0
 88a:	bd91                	j	6de <vprintf+0x44>
          s = "(null)";
 88c:	00000497          	auipc	s1,0x0
 890:	2cc48493          	addi	s1,s1,716 # b58 <malloc+0x138>
        for(; *s; s++)
 894:	02800593          	li	a1,40
 898:	b7c5                	j	878 <vprintf+0x1de>
        putc(fd, '%');
 89a:	85be                	mv	a1,a5
 89c:	855a                	mv	a0,s6
 89e:	d3bff0ef          	jal	5d8 <putc>
      state = 0;
 8a2:	4981                	li	s3,0
 8a4:	bd2d                	j	6de <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 8a6:	8bce                	mv	s7,s3
      state = 0;
 8a8:	4981                	li	s3,0
 8aa:	bd15                	j	6de <vprintf+0x44>
 8ac:	6906                	ld	s2,64(sp)
 8ae:	79e2                	ld	s3,56(sp)
 8b0:	7a42                	ld	s4,48(sp)
 8b2:	7aa2                	ld	s5,40(sp)
 8b4:	7b02                	ld	s6,32(sp)
 8b6:	6be2                	ld	s7,24(sp)
 8b8:	6c42                	ld	s8,16(sp)
    }
  }
}
 8ba:	60e6                	ld	ra,88(sp)
 8bc:	6446                	ld	s0,80(sp)
 8be:	64a6                	ld	s1,72(sp)
 8c0:	6125                	addi	sp,sp,96
 8c2:	8082                	ret
      if(c0 == 'd'){
 8c4:	06400713          	li	a4,100
 8c8:	e6e789e3          	beq	a5,a4,73a <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 8cc:	f9478693          	addi	a3,a5,-108
 8d0:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 8d4:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8d6:	4701                	li	a4,0
      } else if(c0 == 'u'){
 8d8:	07500513          	li	a0,117
 8dc:	eaa786e3          	beq	a5,a0,788 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 8e0:	f8b60513          	addi	a0,a2,-117
 8e4:	e119                	bnez	a0,8ea <vprintf+0x250>
 8e6:	ea069de3          	bnez	a3,7a0 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 8ea:	f8b58513          	addi	a0,a1,-117
 8ee:	e119                	bnez	a0,8f4 <vprintf+0x25a>
 8f0:	ec0715e3          	bnez	a4,7ba <vprintf+0x120>
      } else if(c0 == 'x'){
 8f4:	07800513          	li	a0,120
 8f8:	eca78ee3          	beq	a5,a0,7d4 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 8fc:	f8860613          	addi	a2,a2,-120
 900:	e219                	bnez	a2,906 <vprintf+0x26c>
 902:	ee0695e3          	bnez	a3,7ec <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 906:	f8858593          	addi	a1,a1,-120
 90a:	e199                	bnez	a1,910 <vprintf+0x276>
 90c:	ee071de3          	bnez	a4,806 <vprintf+0x16c>
      } else if(c0 == 'p'){
 910:	07000713          	li	a4,112
 914:	f0e786e3          	beq	a5,a4,820 <vprintf+0x186>
      } else if(c0 == 's'){
 918:	07300713          	li	a4,115
 91c:	f4e786e3          	beq	a5,a4,868 <vprintf+0x1ce>
      } else if(c0 == '%'){
 920:	02500713          	li	a4,37
 924:	f6e78be3          	beq	a5,a4,89a <vprintf+0x200>
        putc(fd, '%');
 928:	02500593          	li	a1,37
 92c:	855a                	mv	a0,s6
 92e:	cabff0ef          	jal	5d8 <putc>
        putc(fd, c0);
 932:	85a6                	mv	a1,s1
 934:	855a                	mv	a0,s6
 936:	ca3ff0ef          	jal	5d8 <putc>
      state = 0;
 93a:	4981                	li	s3,0
 93c:	b34d                	j	6de <vprintf+0x44>

000000000000093e <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 93e:	715d                	addi	sp,sp,-80
 940:	ec06                	sd	ra,24(sp)
 942:	e822                	sd	s0,16(sp)
 944:	1000                	addi	s0,sp,32
 946:	e010                	sd	a2,0(s0)
 948:	e414                	sd	a3,8(s0)
 94a:	e818                	sd	a4,16(s0)
 94c:	ec1c                	sd	a5,24(s0)
 94e:	03043023          	sd	a6,32(s0)
 952:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 956:	8622                	mv	a2,s0
 958:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 95c:	d3fff0ef          	jal	69a <vprintf>
}
 960:	60e2                	ld	ra,24(sp)
 962:	6442                	ld	s0,16(sp)
 964:	6161                	addi	sp,sp,80
 966:	8082                	ret

0000000000000968 <printf>:

void
printf(const char *fmt, ...)
{
 968:	711d                	addi	sp,sp,-96
 96a:	ec06                	sd	ra,24(sp)
 96c:	e822                	sd	s0,16(sp)
 96e:	1000                	addi	s0,sp,32
 970:	e40c                	sd	a1,8(s0)
 972:	e810                	sd	a2,16(s0)
 974:	ec14                	sd	a3,24(s0)
 976:	f018                	sd	a4,32(s0)
 978:	f41c                	sd	a5,40(s0)
 97a:	03043823          	sd	a6,48(s0)
 97e:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 982:	00840613          	addi	a2,s0,8
 986:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 98a:	85aa                	mv	a1,a0
 98c:	4505                	li	a0,1
 98e:	d0dff0ef          	jal	69a <vprintf>
}
 992:	60e2                	ld	ra,24(sp)
 994:	6442                	ld	s0,16(sp)
 996:	6125                	addi	sp,sp,96
 998:	8082                	ret

000000000000099a <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 99a:	1141                	addi	sp,sp,-16
 99c:	e406                	sd	ra,8(sp)
 99e:	e022                	sd	s0,0(sp)
 9a0:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 9a2:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9a6:	00000797          	auipc	a5,0x0
 9aa:	65a7b783          	ld	a5,1626(a5) # 1000 <freep>
 9ae:	a039                	j	9bc <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9b0:	6398                	ld	a4,0(a5)
 9b2:	00e7e463          	bltu	a5,a4,9ba <free+0x20>
 9b6:	00e6ea63          	bltu	a3,a4,9ca <free+0x30>
{
 9ba:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9bc:	fed7fae3          	bgeu	a5,a3,9b0 <free+0x16>
 9c0:	6398                	ld	a4,0(a5)
 9c2:	00e6e463          	bltu	a3,a4,9ca <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9c6:	fee7eae3          	bltu	a5,a4,9ba <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 9ca:	ff852583          	lw	a1,-8(a0)
 9ce:	6390                	ld	a2,0(a5)
 9d0:	02059813          	slli	a6,a1,0x20
 9d4:	01c85713          	srli	a4,a6,0x1c
 9d8:	9736                	add	a4,a4,a3
 9da:	02e60563          	beq	a2,a4,a04 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 9de:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 9e2:	4790                	lw	a2,8(a5)
 9e4:	02061593          	slli	a1,a2,0x20
 9e8:	01c5d713          	srli	a4,a1,0x1c
 9ec:	973e                	add	a4,a4,a5
 9ee:	02e68263          	beq	a3,a4,a12 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 9f2:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 9f4:	00000717          	auipc	a4,0x0
 9f8:	60f73623          	sd	a5,1548(a4) # 1000 <freep>
}
 9fc:	60a2                	ld	ra,8(sp)
 9fe:	6402                	ld	s0,0(sp)
 a00:	0141                	addi	sp,sp,16
 a02:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 a04:	4618                	lw	a4,8(a2)
 a06:	9f2d                	addw	a4,a4,a1
 a08:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a0c:	6398                	ld	a4,0(a5)
 a0e:	6310                	ld	a2,0(a4)
 a10:	b7f9                	j	9de <free+0x44>
    p->s.size += bp->s.size;
 a12:	ff852703          	lw	a4,-8(a0)
 a16:	9f31                	addw	a4,a4,a2
 a18:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 a1a:	ff053683          	ld	a3,-16(a0)
 a1e:	bfd1                	j	9f2 <free+0x58>

0000000000000a20 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a20:	7139                	addi	sp,sp,-64
 a22:	fc06                	sd	ra,56(sp)
 a24:	f822                	sd	s0,48(sp)
 a26:	f04a                	sd	s2,32(sp)
 a28:	ec4e                	sd	s3,24(sp)
 a2a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a2c:	02051993          	slli	s3,a0,0x20
 a30:	0209d993          	srli	s3,s3,0x20
 a34:	09bd                	addi	s3,s3,15
 a36:	0049d993          	srli	s3,s3,0x4
 a3a:	2985                	addiw	s3,s3,1
 a3c:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 a3e:	00000517          	auipc	a0,0x0
 a42:	5c253503          	ld	a0,1474(a0) # 1000 <freep>
 a46:	c905                	beqz	a0,a76 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a48:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a4a:	4798                	lw	a4,8(a5)
 a4c:	09377663          	bgeu	a4,s3,ad8 <malloc+0xb8>
 a50:	f426                	sd	s1,40(sp)
 a52:	e852                	sd	s4,16(sp)
 a54:	e456                	sd	s5,8(sp)
 a56:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a58:	8a4e                	mv	s4,s3
 a5a:	6705                	lui	a4,0x1
 a5c:	00e9f363          	bgeu	s3,a4,a62 <malloc+0x42>
 a60:	6a05                	lui	s4,0x1
 a62:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a66:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a6a:	00000497          	auipc	s1,0x0
 a6e:	59648493          	addi	s1,s1,1430 # 1000 <freep>
  if(p == (char*)-1)
 a72:	5afd                	li	s5,-1
 a74:	a83d                	j	ab2 <malloc+0x92>
 a76:	f426                	sd	s1,40(sp)
 a78:	e852                	sd	s4,16(sp)
 a7a:	e456                	sd	s5,8(sp)
 a7c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a7e:	00001797          	auipc	a5,0x1
 a82:	99278793          	addi	a5,a5,-1646 # 1410 <base>
 a86:	00000717          	auipc	a4,0x0
 a8a:	56f73d23          	sd	a5,1402(a4) # 1000 <freep>
 a8e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a90:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a94:	b7d1                	j	a58 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 a96:	6398                	ld	a4,0(a5)
 a98:	e118                	sd	a4,0(a0)
 a9a:	a899                	j	af0 <malloc+0xd0>
  hp->s.size = nu;
 a9c:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 aa0:	0541                	addi	a0,a0,16
 aa2:	ef9ff0ef          	jal	99a <free>
  return freep;
 aa6:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 aa8:	c125                	beqz	a0,b08 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 aaa:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 aac:	4798                	lw	a4,8(a5)
 aae:	03277163          	bgeu	a4,s2,ad0 <malloc+0xb0>
    if(p == freep)
 ab2:	6098                	ld	a4,0(s1)
 ab4:	853e                	mv	a0,a5
 ab6:	fef71ae3          	bne	a4,a5,aaa <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 aba:	8552                	mv	a0,s4
 abc:	acfff0ef          	jal	58a <sbrk>
  if(p == (char*)-1)
 ac0:	fd551ee3          	bne	a0,s5,a9c <malloc+0x7c>
        return 0;
 ac4:	4501                	li	a0,0
 ac6:	74a2                	ld	s1,40(sp)
 ac8:	6a42                	ld	s4,16(sp)
 aca:	6aa2                	ld	s5,8(sp)
 acc:	6b02                	ld	s6,0(sp)
 ace:	a03d                	j	afc <malloc+0xdc>
 ad0:	74a2                	ld	s1,40(sp)
 ad2:	6a42                	ld	s4,16(sp)
 ad4:	6aa2                	ld	s5,8(sp)
 ad6:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 ad8:	fae90fe3          	beq	s2,a4,a96 <malloc+0x76>
        p->s.size -= nunits;
 adc:	4137073b          	subw	a4,a4,s3
 ae0:	c798                	sw	a4,8(a5)
        p += p->s.size;
 ae2:	02071693          	slli	a3,a4,0x20
 ae6:	01c6d713          	srli	a4,a3,0x1c
 aea:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 aec:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 af0:	00000717          	auipc	a4,0x0
 af4:	50a73823          	sd	a0,1296(a4) # 1000 <freep>
      return (void*)(p + 1);
 af8:	01078513          	addi	a0,a5,16
  }
}
 afc:	70e2                	ld	ra,56(sp)
 afe:	7442                	ld	s0,48(sp)
 b00:	7902                	ld	s2,32(sp)
 b02:	69e2                	ld	s3,24(sp)
 b04:	6121                	addi	sp,sp,64
 b06:	8082                	ret
 b08:	74a2                	ld	s1,40(sp)
 b0a:	6a42                	ld	s4,16(sp)
 b0c:	6aa2                	ld	s5,8(sp)
 b0e:	6b02                	ld	s6,0(sp)
 b10:	b7f5                	j	afc <malloc+0xdc>
