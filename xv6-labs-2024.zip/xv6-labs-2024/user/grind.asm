
user/_grind:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <do_rand>:
#include "kernel/riscv.h"

// from FreeBSD.
int
do_rand(unsigned long *ctx)
{
       0:	1141                	addi	sp,sp,-16
       2:	e406                	sd	ra,8(sp)
       4:	e022                	sd	s0,0(sp)
       6:	0800                	addi	s0,sp,16
 * October 1988, p. 1195.
 */
    long hi, lo, x;

    /* Transform to [1, 0x7ffffffe] range. */
    x = (*ctx % 0x7ffffffe) + 1;
       8:	611c                	ld	a5,0(a0)
       a:	0017d693          	srli	a3,a5,0x1
       e:	c0000737          	lui	a4,0xc0000
      12:	0705                	addi	a4,a4,1 # ffffffffc0000001 <base+0xffffffffbfffdbf9>
      14:	1706                	slli	a4,a4,0x21
      16:	0725                	addi	a4,a4,9
      18:	02e6b733          	mulhu	a4,a3,a4
      1c:	8375                	srli	a4,a4,0x1d
      1e:	01e71693          	slli	a3,a4,0x1e
      22:	40e68733          	sub	a4,a3,a4
      26:	0706                	slli	a4,a4,0x1
      28:	8f99                	sub	a5,a5,a4
      2a:	0785                	addi	a5,a5,1
    hi = x / 127773;
    lo = x % 127773;
      2c:	1fe406b7          	lui	a3,0x1fe40
      30:	b7968693          	addi	a3,a3,-1159 # 1fe3fb79 <base+0x1fe3d771>
      34:	41a70737          	lui	a4,0x41a70
      38:	5af70713          	addi	a4,a4,1455 # 41a705af <base+0x41a6e1a7>
      3c:	1702                	slli	a4,a4,0x20
      3e:	9736                	add	a4,a4,a3
      40:	02e79733          	mulh	a4,a5,a4
      44:	873d                	srai	a4,a4,0xf
      46:	43f7d693          	srai	a3,a5,0x3f
      4a:	8f15                	sub	a4,a4,a3
      4c:	66fd                	lui	a3,0x1f
      4e:	31d68693          	addi	a3,a3,797 # 1f31d <base+0x1cf15>
      52:	02d706b3          	mul	a3,a4,a3
      56:	8f95                	sub	a5,a5,a3
    x = 16807 * lo - 2836 * hi;
      58:	6691                	lui	a3,0x4
      5a:	1a768693          	addi	a3,a3,423 # 41a7 <base+0x1d9f>
      5e:	02d787b3          	mul	a5,a5,a3
      62:	76fd                	lui	a3,0xfffff
      64:	4ec68693          	addi	a3,a3,1260 # fffffffffffff4ec <base+0xffffffffffffd0e4>
      68:	02d70733          	mul	a4,a4,a3
      6c:	97ba                	add	a5,a5,a4
    if (x < 0)
      6e:	0007ca63          	bltz	a5,82 <do_rand+0x82>
        x += 0x7fffffff;
    /* Transform to [0, 0x7ffffffd] range. */
    x--;
      72:	17fd                	addi	a5,a5,-1
    *ctx = x;
      74:	e11c                	sd	a5,0(a0)
    return (x);
}
      76:	0007851b          	sext.w	a0,a5
      7a:	60a2                	ld	ra,8(sp)
      7c:	6402                	ld	s0,0(sp)
      7e:	0141                	addi	sp,sp,16
      80:	8082                	ret
        x += 0x7fffffff;
      82:	80000737          	lui	a4,0x80000
      86:	fff74713          	not	a4,a4
      8a:	97ba                	add	a5,a5,a4
      8c:	b7dd                	j	72 <do_rand+0x72>

000000000000008e <rand>:

unsigned long rand_next = 1;

int
rand(void)
{
      8e:	1141                	addi	sp,sp,-16
      90:	e406                	sd	ra,8(sp)
      92:	e022                	sd	s0,0(sp)
      94:	0800                	addi	s0,sp,16
    return (do_rand(&rand_next));
      96:	00002517          	auipc	a0,0x2
      9a:	f6a50513          	addi	a0,a0,-150 # 2000 <rand_next>
      9e:	f63ff0ef          	jal	0 <do_rand>
}
      a2:	60a2                	ld	ra,8(sp)
      a4:	6402                	ld	s0,0(sp)
      a6:	0141                	addi	sp,sp,16
      a8:	8082                	ret

00000000000000aa <go>:

void
go(int which_child)
{
      aa:	7171                	addi	sp,sp,-176
      ac:	f506                	sd	ra,168(sp)
      ae:	f122                	sd	s0,160(sp)
      b0:	ed26                	sd	s1,152(sp)
      b2:	1900                	addi	s0,sp,176
      b4:	84aa                	mv	s1,a0
  int fd = -1;
  static char buf[999];
  char *break0 = sbrk(0);
      b6:	4501                	li	a0,0
      b8:	3fd000ef          	jal	cb4 <sbrk>
      bc:	f4a43c23          	sd	a0,-168(s0)
  uint64 iters = 0;

  mkdir("grindir");
      c0:	00001517          	auipc	a0,0x1
      c4:	18050513          	addi	a0,a0,384 # 1240 <malloc+0xf6>
      c8:	3cd000ef          	jal	c94 <mkdir>
  if(chdir("grindir") != 0){
      cc:	00001517          	auipc	a0,0x1
      d0:	17450513          	addi	a0,a0,372 # 1240 <malloc+0xf6>
      d4:	3c9000ef          	jal	c9c <chdir>
      d8:	c505                	beqz	a0,100 <go+0x56>
      da:	e94a                	sd	s2,144(sp)
      dc:	e54e                	sd	s3,136(sp)
      de:	e152                	sd	s4,128(sp)
      e0:	fcd6                	sd	s5,120(sp)
      e2:	f8da                	sd	s6,112(sp)
      e4:	f4de                	sd	s7,104(sp)
      e6:	f0e2                	sd	s8,96(sp)
      e8:	ece6                	sd	s9,88(sp)
      ea:	e8ea                	sd	s10,80(sp)
      ec:	e4ee                	sd	s11,72(sp)
    printf("grind: chdir grindir failed\n");
      ee:	00001517          	auipc	a0,0x1
      f2:	15a50513          	addi	a0,a0,346 # 1248 <malloc+0xfe>
      f6:	79d000ef          	jal	1092 <printf>
    exit(1);
      fa:	4505                	li	a0,1
      fc:	331000ef          	jal	c2c <exit>
     100:	e94a                	sd	s2,144(sp)
     102:	e54e                	sd	s3,136(sp)
     104:	e152                	sd	s4,128(sp)
     106:	fcd6                	sd	s5,120(sp)
     108:	f8da                	sd	s6,112(sp)
     10a:	f4de                	sd	s7,104(sp)
     10c:	f0e2                	sd	s8,96(sp)
     10e:	ece6                	sd	s9,88(sp)
     110:	e8ea                	sd	s10,80(sp)
     112:	e4ee                	sd	s11,72(sp)
  }
  chdir("/");
     114:	00001517          	auipc	a0,0x1
     118:	15c50513          	addi	a0,a0,348 # 1270 <malloc+0x126>
     11c:	381000ef          	jal	c9c <chdir>
     120:	00001c17          	auipc	s8,0x1
     124:	160c0c13          	addi	s8,s8,352 # 1280 <malloc+0x136>
     128:	c489                	beqz	s1,132 <go+0x88>
     12a:	00001c17          	auipc	s8,0x1
     12e:	14ec0c13          	addi	s8,s8,334 # 1278 <malloc+0x12e>
  uint64 iters = 0;
     132:	4481                	li	s1,0
  int fd = -1;
     134:	5cfd                	li	s9,-1
  
  while(1){
    iters++;
    if((iters % 500) == 0)
     136:	106259b7          	lui	s3,0x10625
     13a:	dd398993          	addi	s3,s3,-557 # 10624dd3 <base+0x106229cb>
     13e:	09be                	slli	s3,s3,0xf
     140:	8d598993          	addi	s3,s3,-1835
     144:	09ca                	slli	s3,s3,0x12
     146:	80098993          	addi	s3,s3,-2048
     14a:	fcf98993          	addi	s3,s3,-49
     14e:	1f400b93          	li	s7,500
      write(1, which_child?"B":"A", 1);
     152:	4a05                	li	s4,1
    int what = rand() % 23;
     154:	b2164ab7          	lui	s5,0xb2164
     158:	2c9a8a93          	addi	s5,s5,713 # ffffffffb21642c9 <base+0xffffffffb2161ec1>
     15c:	4b59                	li	s6,22
     15e:	00001917          	auipc	s2,0x1
     162:	3f290913          	addi	s2,s2,1010 # 1550 <malloc+0x406>
      close(fd1);
      unlink("c");
    } else if(what == 22){
      // echo hi | cat
      int aa[2], bb[2];
      if(pipe(aa) < 0){
     166:	f6840d93          	addi	s11,s0,-152
     16a:	a819                	j	180 <go+0xd6>
      close(open("grindir/../a", O_CREATE|O_RDWR));
     16c:	20200593          	li	a1,514
     170:	00001517          	auipc	a0,0x1
     174:	11850513          	addi	a0,a0,280 # 1288 <malloc+0x13e>
     178:	2f5000ef          	jal	c6c <open>
     17c:	2d9000ef          	jal	c54 <close>
    iters++;
     180:	0485                	addi	s1,s1,1
    if((iters % 500) == 0)
     182:	0024d793          	srli	a5,s1,0x2
     186:	0337b7b3          	mulhu	a5,a5,s3
     18a:	8391                	srli	a5,a5,0x4
     18c:	037787b3          	mul	a5,a5,s7
     190:	00f49763          	bne	s1,a5,19e <go+0xf4>
      write(1, which_child?"B":"A", 1);
     194:	8652                	mv	a2,s4
     196:	85e2                	mv	a1,s8
     198:	8552                	mv	a0,s4
     19a:	2b3000ef          	jal	c4c <write>
    int what = rand() % 23;
     19e:	ef1ff0ef          	jal	8e <rand>
     1a2:	035507b3          	mul	a5,a0,s5
     1a6:	9381                	srli	a5,a5,0x20
     1a8:	9fa9                	addw	a5,a5,a0
     1aa:	4047d79b          	sraiw	a5,a5,0x4
     1ae:	41f5571b          	sraiw	a4,a0,0x1f
     1b2:	9f99                	subw	a5,a5,a4
     1b4:	0017971b          	slliw	a4,a5,0x1
     1b8:	9f3d                	addw	a4,a4,a5
     1ba:	0037171b          	slliw	a4,a4,0x3
     1be:	40f707bb          	subw	a5,a4,a5
     1c2:	9d1d                	subw	a0,a0,a5
     1c4:	faab6ee3          	bltu	s6,a0,180 <go+0xd6>
     1c8:	02051793          	slli	a5,a0,0x20
     1cc:	01e7d513          	srli	a0,a5,0x1e
     1d0:	954a                	add	a0,a0,s2
     1d2:	411c                	lw	a5,0(a0)
     1d4:	97ca                	add	a5,a5,s2
     1d6:	8782                	jr	a5
      close(open("grindir/../grindir/../b", O_CREATE|O_RDWR));
     1d8:	20200593          	li	a1,514
     1dc:	00001517          	auipc	a0,0x1
     1e0:	0bc50513          	addi	a0,a0,188 # 1298 <malloc+0x14e>
     1e4:	289000ef          	jal	c6c <open>
     1e8:	26d000ef          	jal	c54 <close>
     1ec:	bf51                	j	180 <go+0xd6>
      unlink("grindir/../a");
     1ee:	00001517          	auipc	a0,0x1
     1f2:	09a50513          	addi	a0,a0,154 # 1288 <malloc+0x13e>
     1f6:	287000ef          	jal	c7c <unlink>
     1fa:	b759                	j	180 <go+0xd6>
      if(chdir("grindir") != 0){
     1fc:	00001517          	auipc	a0,0x1
     200:	04450513          	addi	a0,a0,68 # 1240 <malloc+0xf6>
     204:	299000ef          	jal	c9c <chdir>
     208:	ed11                	bnez	a0,224 <go+0x17a>
      unlink("../b");
     20a:	00001517          	auipc	a0,0x1
     20e:	0a650513          	addi	a0,a0,166 # 12b0 <malloc+0x166>
     212:	26b000ef          	jal	c7c <unlink>
      chdir("/");
     216:	00001517          	auipc	a0,0x1
     21a:	05a50513          	addi	a0,a0,90 # 1270 <malloc+0x126>
     21e:	27f000ef          	jal	c9c <chdir>
     222:	bfb9                	j	180 <go+0xd6>
        printf("grind: chdir grindir failed\n");
     224:	00001517          	auipc	a0,0x1
     228:	02450513          	addi	a0,a0,36 # 1248 <malloc+0xfe>
     22c:	667000ef          	jal	1092 <printf>
        exit(1);
     230:	4505                	li	a0,1
     232:	1fb000ef          	jal	c2c <exit>
      close(fd);
     236:	8566                	mv	a0,s9
     238:	21d000ef          	jal	c54 <close>
      fd = open("/grindir/../a", O_CREATE|O_RDWR);
     23c:	20200593          	li	a1,514
     240:	00001517          	auipc	a0,0x1
     244:	07850513          	addi	a0,a0,120 # 12b8 <malloc+0x16e>
     248:	225000ef          	jal	c6c <open>
     24c:	8caa                	mv	s9,a0
     24e:	bf0d                	j	180 <go+0xd6>
      close(fd);
     250:	8566                	mv	a0,s9
     252:	203000ef          	jal	c54 <close>
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
     256:	20200593          	li	a1,514
     25a:	00001517          	auipc	a0,0x1
     25e:	06e50513          	addi	a0,a0,110 # 12c8 <malloc+0x17e>
     262:	20b000ef          	jal	c6c <open>
     266:	8caa                	mv	s9,a0
     268:	bf21                	j	180 <go+0xd6>
      write(fd, buf, sizeof(buf));
     26a:	3e700613          	li	a2,999
     26e:	00002597          	auipc	a1,0x2
     272:	db258593          	addi	a1,a1,-590 # 2020 <buf.0>
     276:	8566                	mv	a0,s9
     278:	1d5000ef          	jal	c4c <write>
     27c:	b711                	j	180 <go+0xd6>
      read(fd, buf, sizeof(buf));
     27e:	3e700613          	li	a2,999
     282:	00002597          	auipc	a1,0x2
     286:	d9e58593          	addi	a1,a1,-610 # 2020 <buf.0>
     28a:	8566                	mv	a0,s9
     28c:	1b9000ef          	jal	c44 <read>
     290:	bdc5                	j	180 <go+0xd6>
      mkdir("grindir/../a");
     292:	00001517          	auipc	a0,0x1
     296:	ff650513          	addi	a0,a0,-10 # 1288 <malloc+0x13e>
     29a:	1fb000ef          	jal	c94 <mkdir>
      close(open("a/../a/./a", O_CREATE|O_RDWR));
     29e:	20200593          	li	a1,514
     2a2:	00001517          	auipc	a0,0x1
     2a6:	03e50513          	addi	a0,a0,62 # 12e0 <malloc+0x196>
     2aa:	1c3000ef          	jal	c6c <open>
     2ae:	1a7000ef          	jal	c54 <close>
      unlink("a/a");
     2b2:	00001517          	auipc	a0,0x1
     2b6:	03e50513          	addi	a0,a0,62 # 12f0 <malloc+0x1a6>
     2ba:	1c3000ef          	jal	c7c <unlink>
     2be:	b5c9                	j	180 <go+0xd6>
      mkdir("/../b");
     2c0:	00001517          	auipc	a0,0x1
     2c4:	03850513          	addi	a0,a0,56 # 12f8 <malloc+0x1ae>
     2c8:	1cd000ef          	jal	c94 <mkdir>
      close(open("grindir/../b/b", O_CREATE|O_RDWR));
     2cc:	20200593          	li	a1,514
     2d0:	00001517          	auipc	a0,0x1
     2d4:	03050513          	addi	a0,a0,48 # 1300 <malloc+0x1b6>
     2d8:	195000ef          	jal	c6c <open>
     2dc:	179000ef          	jal	c54 <close>
      unlink("b/b");
     2e0:	00001517          	auipc	a0,0x1
     2e4:	03050513          	addi	a0,a0,48 # 1310 <malloc+0x1c6>
     2e8:	195000ef          	jal	c7c <unlink>
     2ec:	bd51                	j	180 <go+0xd6>
      unlink("b");
     2ee:	00001517          	auipc	a0,0x1
     2f2:	02a50513          	addi	a0,a0,42 # 1318 <malloc+0x1ce>
     2f6:	187000ef          	jal	c7c <unlink>
      link("../grindir/./../a", "../b");
     2fa:	00001597          	auipc	a1,0x1
     2fe:	fb658593          	addi	a1,a1,-74 # 12b0 <malloc+0x166>
     302:	00001517          	auipc	a0,0x1
     306:	01e50513          	addi	a0,a0,30 # 1320 <malloc+0x1d6>
     30a:	183000ef          	jal	c8c <link>
     30e:	bd8d                	j	180 <go+0xd6>
      unlink("../grindir/../a");
     310:	00001517          	auipc	a0,0x1
     314:	02850513          	addi	a0,a0,40 # 1338 <malloc+0x1ee>
     318:	165000ef          	jal	c7c <unlink>
      link(".././b", "/grindir/../a");
     31c:	00001597          	auipc	a1,0x1
     320:	f9c58593          	addi	a1,a1,-100 # 12b8 <malloc+0x16e>
     324:	00001517          	auipc	a0,0x1
     328:	02450513          	addi	a0,a0,36 # 1348 <malloc+0x1fe>
     32c:	161000ef          	jal	c8c <link>
     330:	bd81                	j	180 <go+0xd6>
      int pid = fork();
     332:	0f3000ef          	jal	c24 <fork>
      if(pid == 0){
     336:	c519                	beqz	a0,344 <go+0x29a>
      } else if(pid < 0){
     338:	00054863          	bltz	a0,348 <go+0x29e>
      wait(0);
     33c:	4501                	li	a0,0
     33e:	0f7000ef          	jal	c34 <wait>
     342:	bd3d                	j	180 <go+0xd6>
        exit(0);
     344:	0e9000ef          	jal	c2c <exit>
        printf("grind: fork failed\n");
     348:	00001517          	auipc	a0,0x1
     34c:	00850513          	addi	a0,a0,8 # 1350 <malloc+0x206>
     350:	543000ef          	jal	1092 <printf>
        exit(1);
     354:	4505                	li	a0,1
     356:	0d7000ef          	jal	c2c <exit>
      int pid = fork();
     35a:	0cb000ef          	jal	c24 <fork>
      if(pid == 0){
     35e:	c519                	beqz	a0,36c <go+0x2c2>
      } else if(pid < 0){
     360:	00054d63          	bltz	a0,37a <go+0x2d0>
      wait(0);
     364:	4501                	li	a0,0
     366:	0cf000ef          	jal	c34 <wait>
     36a:	bd19                	j	180 <go+0xd6>
        fork();
     36c:	0b9000ef          	jal	c24 <fork>
        fork();
     370:	0b5000ef          	jal	c24 <fork>
        exit(0);
     374:	4501                	li	a0,0
     376:	0b7000ef          	jal	c2c <exit>
        printf("grind: fork failed\n");
     37a:	00001517          	auipc	a0,0x1
     37e:	fd650513          	addi	a0,a0,-42 # 1350 <malloc+0x206>
     382:	511000ef          	jal	1092 <printf>
        exit(1);
     386:	4505                	li	a0,1
     388:	0a5000ef          	jal	c2c <exit>
      sbrk(6011);
     38c:	6505                	lui	a0,0x1
     38e:	77b50513          	addi	a0,a0,1915 # 177b <digits+0x1cb>
     392:	123000ef          	jal	cb4 <sbrk>
     396:	b3ed                	j	180 <go+0xd6>
      if(sbrk(0) > break0)
     398:	4501                	li	a0,0
     39a:	11b000ef          	jal	cb4 <sbrk>
     39e:	f5843783          	ld	a5,-168(s0)
     3a2:	dca7ffe3          	bgeu	a5,a0,180 <go+0xd6>
        sbrk(-(sbrk(0) - break0));
     3a6:	4501                	li	a0,0
     3a8:	10d000ef          	jal	cb4 <sbrk>
     3ac:	f5843783          	ld	a5,-168(s0)
     3b0:	40a7853b          	subw	a0,a5,a0
     3b4:	101000ef          	jal	cb4 <sbrk>
     3b8:	b3e1                	j	180 <go+0xd6>
      int pid = fork();
     3ba:	06b000ef          	jal	c24 <fork>
     3be:	8d2a                	mv	s10,a0
      if(pid == 0){
     3c0:	c10d                	beqz	a0,3e2 <go+0x338>
      } else if(pid < 0){
     3c2:	02054d63          	bltz	a0,3fc <go+0x352>
      if(chdir("../grindir/..") != 0){
     3c6:	00001517          	auipc	a0,0x1
     3ca:	faa50513          	addi	a0,a0,-86 # 1370 <malloc+0x226>
     3ce:	0cf000ef          	jal	c9c <chdir>
     3d2:	ed15                	bnez	a0,40e <go+0x364>
      kill(pid);
     3d4:	856a                	mv	a0,s10
     3d6:	087000ef          	jal	c5c <kill>
      wait(0);
     3da:	4501                	li	a0,0
     3dc:	059000ef          	jal	c34 <wait>
     3e0:	b345                	j	180 <go+0xd6>
        close(open("a", O_CREATE|O_RDWR));
     3e2:	20200593          	li	a1,514
     3e6:	00001517          	auipc	a0,0x1
     3ea:	f8250513          	addi	a0,a0,-126 # 1368 <malloc+0x21e>
     3ee:	07f000ef          	jal	c6c <open>
     3f2:	063000ef          	jal	c54 <close>
        exit(0);
     3f6:	4501                	li	a0,0
     3f8:	035000ef          	jal	c2c <exit>
        printf("grind: fork failed\n");
     3fc:	00001517          	auipc	a0,0x1
     400:	f5450513          	addi	a0,a0,-172 # 1350 <malloc+0x206>
     404:	48f000ef          	jal	1092 <printf>
        exit(1);
     408:	4505                	li	a0,1
     40a:	023000ef          	jal	c2c <exit>
        printf("grind: chdir failed\n");
     40e:	00001517          	auipc	a0,0x1
     412:	f7250513          	addi	a0,a0,-142 # 1380 <malloc+0x236>
     416:	47d000ef          	jal	1092 <printf>
        exit(1);
     41a:	4505                	li	a0,1
     41c:	011000ef          	jal	c2c <exit>
      int pid = fork();
     420:	005000ef          	jal	c24 <fork>
      if(pid == 0){
     424:	c519                	beqz	a0,432 <go+0x388>
      } else if(pid < 0){
     426:	00054d63          	bltz	a0,440 <go+0x396>
      wait(0);
     42a:	4501                	li	a0,0
     42c:	009000ef          	jal	c34 <wait>
     430:	bb81                	j	180 <go+0xd6>
        kill(getpid());
     432:	07b000ef          	jal	cac <getpid>
     436:	027000ef          	jal	c5c <kill>
        exit(0);
     43a:	4501                	li	a0,0
     43c:	7f0000ef          	jal	c2c <exit>
        printf("grind: fork failed\n");
     440:	00001517          	auipc	a0,0x1
     444:	f1050513          	addi	a0,a0,-240 # 1350 <malloc+0x206>
     448:	44b000ef          	jal	1092 <printf>
        exit(1);
     44c:	4505                	li	a0,1
     44e:	7de000ef          	jal	c2c <exit>
      if(pipe(fds) < 0){
     452:	f7840513          	addi	a0,s0,-136
     456:	7e6000ef          	jal	c3c <pipe>
     45a:	02054363          	bltz	a0,480 <go+0x3d6>
      int pid = fork();
     45e:	7c6000ef          	jal	c24 <fork>
      if(pid == 0){
     462:	c905                	beqz	a0,492 <go+0x3e8>
      } else if(pid < 0){
     464:	08054263          	bltz	a0,4e8 <go+0x43e>
      close(fds[0]);
     468:	f7842503          	lw	a0,-136(s0)
     46c:	7e8000ef          	jal	c54 <close>
      close(fds[1]);
     470:	f7c42503          	lw	a0,-132(s0)
     474:	7e0000ef          	jal	c54 <close>
      wait(0);
     478:	4501                	li	a0,0
     47a:	7ba000ef          	jal	c34 <wait>
     47e:	b309                	j	180 <go+0xd6>
        printf("grind: pipe failed\n");
     480:	00001517          	auipc	a0,0x1
     484:	f1850513          	addi	a0,a0,-232 # 1398 <malloc+0x24e>
     488:	40b000ef          	jal	1092 <printf>
        exit(1);
     48c:	4505                	li	a0,1
     48e:	79e000ef          	jal	c2c <exit>
        fork();
     492:	792000ef          	jal	c24 <fork>
        fork();
     496:	78e000ef          	jal	c24 <fork>
        if(write(fds[1], "x", 1) != 1)
     49a:	4605                	li	a2,1
     49c:	00001597          	auipc	a1,0x1
     4a0:	f1458593          	addi	a1,a1,-236 # 13b0 <malloc+0x266>
     4a4:	f7c42503          	lw	a0,-132(s0)
     4a8:	7a4000ef          	jal	c4c <write>
     4ac:	4785                	li	a5,1
     4ae:	00f51f63          	bne	a0,a5,4cc <go+0x422>
        if(read(fds[0], &c, 1) != 1)
     4b2:	4605                	li	a2,1
     4b4:	f7040593          	addi	a1,s0,-144
     4b8:	f7842503          	lw	a0,-136(s0)
     4bc:	788000ef          	jal	c44 <read>
     4c0:	4785                	li	a5,1
     4c2:	00f51c63          	bne	a0,a5,4da <go+0x430>
        exit(0);
     4c6:	4501                	li	a0,0
     4c8:	764000ef          	jal	c2c <exit>
          printf("grind: pipe write failed\n");
     4cc:	00001517          	auipc	a0,0x1
     4d0:	eec50513          	addi	a0,a0,-276 # 13b8 <malloc+0x26e>
     4d4:	3bf000ef          	jal	1092 <printf>
     4d8:	bfe9                	j	4b2 <go+0x408>
          printf("grind: pipe read failed\n");
     4da:	00001517          	auipc	a0,0x1
     4de:	efe50513          	addi	a0,a0,-258 # 13d8 <malloc+0x28e>
     4e2:	3b1000ef          	jal	1092 <printf>
     4e6:	b7c5                	j	4c6 <go+0x41c>
        printf("grind: fork failed\n");
     4e8:	00001517          	auipc	a0,0x1
     4ec:	e6850513          	addi	a0,a0,-408 # 1350 <malloc+0x206>
     4f0:	3a3000ef          	jal	1092 <printf>
        exit(1);
     4f4:	4505                	li	a0,1
     4f6:	736000ef          	jal	c2c <exit>
      int pid = fork();
     4fa:	72a000ef          	jal	c24 <fork>
      if(pid == 0){
     4fe:	c519                	beqz	a0,50c <go+0x462>
      } else if(pid < 0){
     500:	04054f63          	bltz	a0,55e <go+0x4b4>
      wait(0);
     504:	4501                	li	a0,0
     506:	72e000ef          	jal	c34 <wait>
     50a:	b99d                	j	180 <go+0xd6>
        unlink("a");
     50c:	00001517          	auipc	a0,0x1
     510:	e5c50513          	addi	a0,a0,-420 # 1368 <malloc+0x21e>
     514:	768000ef          	jal	c7c <unlink>
        mkdir("a");
     518:	00001517          	auipc	a0,0x1
     51c:	e5050513          	addi	a0,a0,-432 # 1368 <malloc+0x21e>
     520:	774000ef          	jal	c94 <mkdir>
        chdir("a");
     524:	00001517          	auipc	a0,0x1
     528:	e4450513          	addi	a0,a0,-444 # 1368 <malloc+0x21e>
     52c:	770000ef          	jal	c9c <chdir>
        unlink("../a");
     530:	00001517          	auipc	a0,0x1
     534:	ec850513          	addi	a0,a0,-312 # 13f8 <malloc+0x2ae>
     538:	744000ef          	jal	c7c <unlink>
        fd = open("x", O_CREATE|O_RDWR);
     53c:	20200593          	li	a1,514
     540:	00001517          	auipc	a0,0x1
     544:	e7050513          	addi	a0,a0,-400 # 13b0 <malloc+0x266>
     548:	724000ef          	jal	c6c <open>
        unlink("x");
     54c:	00001517          	auipc	a0,0x1
     550:	e6450513          	addi	a0,a0,-412 # 13b0 <malloc+0x266>
     554:	728000ef          	jal	c7c <unlink>
        exit(0);
     558:	4501                	li	a0,0
     55a:	6d2000ef          	jal	c2c <exit>
        printf("grind: fork failed\n");
     55e:	00001517          	auipc	a0,0x1
     562:	df250513          	addi	a0,a0,-526 # 1350 <malloc+0x206>
     566:	32d000ef          	jal	1092 <printf>
        exit(1);
     56a:	4505                	li	a0,1
     56c:	6c0000ef          	jal	c2c <exit>
      unlink("c");
     570:	00001517          	auipc	a0,0x1
     574:	e9050513          	addi	a0,a0,-368 # 1400 <malloc+0x2b6>
     578:	704000ef          	jal	c7c <unlink>
      int fd1 = open("c", O_CREATE|O_RDWR);
     57c:	20200593          	li	a1,514
     580:	00001517          	auipc	a0,0x1
     584:	e8050513          	addi	a0,a0,-384 # 1400 <malloc+0x2b6>
     588:	6e4000ef          	jal	c6c <open>
     58c:	8d2a                	mv	s10,a0
      if(fd1 < 0){
     58e:	04054563          	bltz	a0,5d8 <go+0x52e>
      if(write(fd1, "x", 1) != 1){
     592:	8652                	mv	a2,s4
     594:	00001597          	auipc	a1,0x1
     598:	e1c58593          	addi	a1,a1,-484 # 13b0 <malloc+0x266>
     59c:	6b0000ef          	jal	c4c <write>
     5a0:	05451563          	bne	a0,s4,5ea <go+0x540>
      if(fstat(fd1, &st) != 0){
     5a4:	f7840593          	addi	a1,s0,-136
     5a8:	856a                	mv	a0,s10
     5aa:	6da000ef          	jal	c84 <fstat>
     5ae:	e539                	bnez	a0,5fc <go+0x552>
      if(st.size != 1){
     5b0:	f8843583          	ld	a1,-120(s0)
     5b4:	05459d63          	bne	a1,s4,60e <go+0x564>
      if(st.ino > 200){
     5b8:	f7c42583          	lw	a1,-132(s0)
     5bc:	0c800793          	li	a5,200
     5c0:	06b7e163          	bltu	a5,a1,622 <go+0x578>
      close(fd1);
     5c4:	856a                	mv	a0,s10
     5c6:	68e000ef          	jal	c54 <close>
      unlink("c");
     5ca:	00001517          	auipc	a0,0x1
     5ce:	e3650513          	addi	a0,a0,-458 # 1400 <malloc+0x2b6>
     5d2:	6aa000ef          	jal	c7c <unlink>
     5d6:	b66d                	j	180 <go+0xd6>
        printf("grind: create c failed\n");
     5d8:	00001517          	auipc	a0,0x1
     5dc:	e3050513          	addi	a0,a0,-464 # 1408 <malloc+0x2be>
     5e0:	2b3000ef          	jal	1092 <printf>
        exit(1);
     5e4:	4505                	li	a0,1
     5e6:	646000ef          	jal	c2c <exit>
        printf("grind: write c failed\n");
     5ea:	00001517          	auipc	a0,0x1
     5ee:	e3650513          	addi	a0,a0,-458 # 1420 <malloc+0x2d6>
     5f2:	2a1000ef          	jal	1092 <printf>
        exit(1);
     5f6:	4505                	li	a0,1
     5f8:	634000ef          	jal	c2c <exit>
        printf("grind: fstat failed\n");
     5fc:	00001517          	auipc	a0,0x1
     600:	e3c50513          	addi	a0,a0,-452 # 1438 <malloc+0x2ee>
     604:	28f000ef          	jal	1092 <printf>
        exit(1);
     608:	4505                	li	a0,1
     60a:	622000ef          	jal	c2c <exit>
        printf("grind: fstat reports wrong size %d\n", (int)st.size);
     60e:	2581                	sext.w	a1,a1
     610:	00001517          	auipc	a0,0x1
     614:	e4050513          	addi	a0,a0,-448 # 1450 <malloc+0x306>
     618:	27b000ef          	jal	1092 <printf>
        exit(1);
     61c:	4505                	li	a0,1
     61e:	60e000ef          	jal	c2c <exit>
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
     622:	00001517          	auipc	a0,0x1
     626:	e5650513          	addi	a0,a0,-426 # 1478 <malloc+0x32e>
     62a:	269000ef          	jal	1092 <printf>
        exit(1);
     62e:	4505                	li	a0,1
     630:	5fc000ef          	jal	c2c <exit>
      if(pipe(aa) < 0){
     634:	856e                	mv	a0,s11
     636:	606000ef          	jal	c3c <pipe>
     63a:	0a054863          	bltz	a0,6ea <go+0x640>
        fprintf(2, "grind: pipe failed\n");
        exit(1);
      }
      if(pipe(bb) < 0){
     63e:	f7040513          	addi	a0,s0,-144
     642:	5fa000ef          	jal	c3c <pipe>
     646:	0a054c63          	bltz	a0,6fe <go+0x654>
        fprintf(2, "grind: pipe failed\n");
        exit(1);
      }
      int pid1 = fork();
     64a:	5da000ef          	jal	c24 <fork>
      if(pid1 == 0){
     64e:	0c050263          	beqz	a0,712 <go+0x668>
        close(aa[1]);
        char *args[3] = { "echo", "hi", 0 };
        exec("grindir/../echo", args);
        fprintf(2, "grind: echo: not found\n");
        exit(2);
      } else if(pid1 < 0){
     652:	14054463          	bltz	a0,79a <go+0x6f0>
        fprintf(2, "grind: fork failed\n");
        exit(3);
      }
      int pid2 = fork();
     656:	5ce000ef          	jal	c24 <fork>
      if(pid2 == 0){
     65a:	14050a63          	beqz	a0,7ae <go+0x704>
        close(bb[1]);
        char *args[2] = { "cat", 0 };
        exec("/cat", args);
        fprintf(2, "grind: cat: not found\n");
        exit(6);
      } else if(pid2 < 0){
     65e:	1e054863          	bltz	a0,84e <go+0x7a4>
        fprintf(2, "grind: fork failed\n");
        exit(7);
      }
      close(aa[0]);
     662:	f6842503          	lw	a0,-152(s0)
     666:	5ee000ef          	jal	c54 <close>
      close(aa[1]);
     66a:	f6c42503          	lw	a0,-148(s0)
     66e:	5e6000ef          	jal	c54 <close>
      close(bb[1]);
     672:	f7442503          	lw	a0,-140(s0)
     676:	5de000ef          	jal	c54 <close>
      char buf[4] = { 0, 0, 0, 0 };
     67a:	f6042023          	sw	zero,-160(s0)
      read(bb[0], buf+0, 1);
     67e:	8652                	mv	a2,s4
     680:	f6040593          	addi	a1,s0,-160
     684:	f7042503          	lw	a0,-144(s0)
     688:	5bc000ef          	jal	c44 <read>
      read(bb[0], buf+1, 1);
     68c:	8652                	mv	a2,s4
     68e:	f6140593          	addi	a1,s0,-159
     692:	f7042503          	lw	a0,-144(s0)
     696:	5ae000ef          	jal	c44 <read>
      read(bb[0], buf+2, 1);
     69a:	8652                	mv	a2,s4
     69c:	f6240593          	addi	a1,s0,-158
     6a0:	f7042503          	lw	a0,-144(s0)
     6a4:	5a0000ef          	jal	c44 <read>
      close(bb[0]);
     6a8:	f7042503          	lw	a0,-144(s0)
     6ac:	5a8000ef          	jal	c54 <close>
      int st1, st2;
      wait(&st1);
     6b0:	f6440513          	addi	a0,s0,-156
     6b4:	580000ef          	jal	c34 <wait>
      wait(&st2);
     6b8:	f7840513          	addi	a0,s0,-136
     6bc:	578000ef          	jal	c34 <wait>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     6c0:	f6442783          	lw	a5,-156(s0)
     6c4:	f7842703          	lw	a4,-136(s0)
     6c8:	f4e43823          	sd	a4,-176(s0)
     6cc:	00e7ed33          	or	s10,a5,a4
     6d0:	180d1963          	bnez	s10,862 <go+0x7b8>
     6d4:	00001597          	auipc	a1,0x1
     6d8:	e4458593          	addi	a1,a1,-444 # 1518 <malloc+0x3ce>
     6dc:	f6040513          	addi	a0,s0,-160
     6e0:	2d8000ef          	jal	9b8 <strcmp>
     6e4:	a8050ee3          	beqz	a0,180 <go+0xd6>
     6e8:	aab5                	j	864 <go+0x7ba>
        fprintf(2, "grind: pipe failed\n");
     6ea:	00001597          	auipc	a1,0x1
     6ee:	cae58593          	addi	a1,a1,-850 # 1398 <malloc+0x24e>
     6f2:	4509                	li	a0,2
     6f4:	175000ef          	jal	1068 <fprintf>
        exit(1);
     6f8:	4505                	li	a0,1
     6fa:	532000ef          	jal	c2c <exit>
        fprintf(2, "grind: pipe failed\n");
     6fe:	00001597          	auipc	a1,0x1
     702:	c9a58593          	addi	a1,a1,-870 # 1398 <malloc+0x24e>
     706:	4509                	li	a0,2
     708:	161000ef          	jal	1068 <fprintf>
        exit(1);
     70c:	4505                	li	a0,1
     70e:	51e000ef          	jal	c2c <exit>
        close(bb[0]);
     712:	f7042503          	lw	a0,-144(s0)
     716:	53e000ef          	jal	c54 <close>
        close(bb[1]);
     71a:	f7442503          	lw	a0,-140(s0)
     71e:	536000ef          	jal	c54 <close>
        close(aa[0]);
     722:	f6842503          	lw	a0,-152(s0)
     726:	52e000ef          	jal	c54 <close>
        close(1);
     72a:	4505                	li	a0,1
     72c:	528000ef          	jal	c54 <close>
        if(dup(aa[1]) != 1){
     730:	f6c42503          	lw	a0,-148(s0)
     734:	570000ef          	jal	ca4 <dup>
     738:	4785                	li	a5,1
     73a:	00f50c63          	beq	a0,a5,752 <go+0x6a8>
          fprintf(2, "grind: dup failed\n");
     73e:	00001597          	auipc	a1,0x1
     742:	d6258593          	addi	a1,a1,-670 # 14a0 <malloc+0x356>
     746:	4509                	li	a0,2
     748:	121000ef          	jal	1068 <fprintf>
          exit(1);
     74c:	4505                	li	a0,1
     74e:	4de000ef          	jal	c2c <exit>
        close(aa[1]);
     752:	f6c42503          	lw	a0,-148(s0)
     756:	4fe000ef          	jal	c54 <close>
        char *args[3] = { "echo", "hi", 0 };
     75a:	00001797          	auipc	a5,0x1
     75e:	d5e78793          	addi	a5,a5,-674 # 14b8 <malloc+0x36e>
     762:	f6f43c23          	sd	a5,-136(s0)
     766:	00001797          	auipc	a5,0x1
     76a:	d5a78793          	addi	a5,a5,-678 # 14c0 <malloc+0x376>
     76e:	f8f43023          	sd	a5,-128(s0)
     772:	f8043423          	sd	zero,-120(s0)
        exec("grindir/../echo", args);
     776:	f7840593          	addi	a1,s0,-136
     77a:	00001517          	auipc	a0,0x1
     77e:	d4e50513          	addi	a0,a0,-690 # 14c8 <malloc+0x37e>
     782:	4e2000ef          	jal	c64 <exec>
        fprintf(2, "grind: echo: not found\n");
     786:	00001597          	auipc	a1,0x1
     78a:	d5258593          	addi	a1,a1,-686 # 14d8 <malloc+0x38e>
     78e:	4509                	li	a0,2
     790:	0d9000ef          	jal	1068 <fprintf>
        exit(2);
     794:	4509                	li	a0,2
     796:	496000ef          	jal	c2c <exit>
        fprintf(2, "grind: fork failed\n");
     79a:	00001597          	auipc	a1,0x1
     79e:	bb658593          	addi	a1,a1,-1098 # 1350 <malloc+0x206>
     7a2:	4509                	li	a0,2
     7a4:	0c5000ef          	jal	1068 <fprintf>
        exit(3);
     7a8:	450d                	li	a0,3
     7aa:	482000ef          	jal	c2c <exit>
        close(aa[1]);
     7ae:	f6c42503          	lw	a0,-148(s0)
     7b2:	4a2000ef          	jal	c54 <close>
        close(bb[0]);
     7b6:	f7042503          	lw	a0,-144(s0)
     7ba:	49a000ef          	jal	c54 <close>
        close(0);
     7be:	4501                	li	a0,0
     7c0:	494000ef          	jal	c54 <close>
        if(dup(aa[0]) != 0){
     7c4:	f6842503          	lw	a0,-152(s0)
     7c8:	4dc000ef          	jal	ca4 <dup>
     7cc:	c919                	beqz	a0,7e2 <go+0x738>
          fprintf(2, "grind: dup failed\n");
     7ce:	00001597          	auipc	a1,0x1
     7d2:	cd258593          	addi	a1,a1,-814 # 14a0 <malloc+0x356>
     7d6:	4509                	li	a0,2
     7d8:	091000ef          	jal	1068 <fprintf>
          exit(4);
     7dc:	4511                	li	a0,4
     7de:	44e000ef          	jal	c2c <exit>
        close(aa[0]);
     7e2:	f6842503          	lw	a0,-152(s0)
     7e6:	46e000ef          	jal	c54 <close>
        close(1);
     7ea:	4505                	li	a0,1
     7ec:	468000ef          	jal	c54 <close>
        if(dup(bb[1]) != 1){
     7f0:	f7442503          	lw	a0,-140(s0)
     7f4:	4b0000ef          	jal	ca4 <dup>
     7f8:	4785                	li	a5,1
     7fa:	00f50c63          	beq	a0,a5,812 <go+0x768>
          fprintf(2, "grind: dup failed\n");
     7fe:	00001597          	auipc	a1,0x1
     802:	ca258593          	addi	a1,a1,-862 # 14a0 <malloc+0x356>
     806:	4509                	li	a0,2
     808:	061000ef          	jal	1068 <fprintf>
          exit(5);
     80c:	4515                	li	a0,5
     80e:	41e000ef          	jal	c2c <exit>
        close(bb[1]);
     812:	f7442503          	lw	a0,-140(s0)
     816:	43e000ef          	jal	c54 <close>
        char *args[2] = { "cat", 0 };
     81a:	00001797          	auipc	a5,0x1
     81e:	cd678793          	addi	a5,a5,-810 # 14f0 <malloc+0x3a6>
     822:	f6f43c23          	sd	a5,-136(s0)
     826:	f8043023          	sd	zero,-128(s0)
        exec("/cat", args);
     82a:	f7840593          	addi	a1,s0,-136
     82e:	00001517          	auipc	a0,0x1
     832:	cca50513          	addi	a0,a0,-822 # 14f8 <malloc+0x3ae>
     836:	42e000ef          	jal	c64 <exec>
        fprintf(2, "grind: cat: not found\n");
     83a:	00001597          	auipc	a1,0x1
     83e:	cc658593          	addi	a1,a1,-826 # 1500 <malloc+0x3b6>
     842:	4509                	li	a0,2
     844:	025000ef          	jal	1068 <fprintf>
        exit(6);
     848:	4519                	li	a0,6
     84a:	3e2000ef          	jal	c2c <exit>
        fprintf(2, "grind: fork failed\n");
     84e:	00001597          	auipc	a1,0x1
     852:	b0258593          	addi	a1,a1,-1278 # 1350 <malloc+0x206>
     856:	4509                	li	a0,2
     858:	011000ef          	jal	1068 <fprintf>
        exit(7);
     85c:	451d                	li	a0,7
     85e:	3ce000ef          	jal	c2c <exit>
     862:	8d3e                	mv	s10,a5
        printf("grind: exec pipeline failed %d %d \"%s\"\n", st1, st2, buf);
     864:	f6040693          	addi	a3,s0,-160
     868:	f5043603          	ld	a2,-176(s0)
     86c:	85ea                	mv	a1,s10
     86e:	00001517          	auipc	a0,0x1
     872:	cb250513          	addi	a0,a0,-846 # 1520 <malloc+0x3d6>
     876:	01d000ef          	jal	1092 <printf>
        exit(1);
     87a:	4505                	li	a0,1
     87c:	3b0000ef          	jal	c2c <exit>

0000000000000880 <iter>:
  }
}

void
iter()
{
     880:	7179                	addi	sp,sp,-48
     882:	f406                	sd	ra,40(sp)
     884:	f022                	sd	s0,32(sp)
     886:	1800                	addi	s0,sp,48
  unlink("a");
     888:	00001517          	auipc	a0,0x1
     88c:	ae050513          	addi	a0,a0,-1312 # 1368 <malloc+0x21e>
     890:	3ec000ef          	jal	c7c <unlink>
  unlink("b");
     894:	00001517          	auipc	a0,0x1
     898:	a8450513          	addi	a0,a0,-1404 # 1318 <malloc+0x1ce>
     89c:	3e0000ef          	jal	c7c <unlink>
  
  int pid1 = fork();
     8a0:	384000ef          	jal	c24 <fork>
  if(pid1 < 0){
     8a4:	02054163          	bltz	a0,8c6 <iter+0x46>
     8a8:	ec26                	sd	s1,24(sp)
     8aa:	84aa                	mv	s1,a0
    printf("grind: fork failed\n");
    exit(1);
  }
  if(pid1 == 0){
     8ac:	e905                	bnez	a0,8dc <iter+0x5c>
     8ae:	e84a                	sd	s2,16(sp)
    rand_next ^= 31;
     8b0:	00001717          	auipc	a4,0x1
     8b4:	75070713          	addi	a4,a4,1872 # 2000 <rand_next>
     8b8:	631c                	ld	a5,0(a4)
     8ba:	01f7c793          	xori	a5,a5,31
     8be:	e31c                	sd	a5,0(a4)
    go(0);
     8c0:	4501                	li	a0,0
     8c2:	fe8ff0ef          	jal	aa <go>
     8c6:	ec26                	sd	s1,24(sp)
     8c8:	e84a                	sd	s2,16(sp)
    printf("grind: fork failed\n");
     8ca:	00001517          	auipc	a0,0x1
     8ce:	a8650513          	addi	a0,a0,-1402 # 1350 <malloc+0x206>
     8d2:	7c0000ef          	jal	1092 <printf>
    exit(1);
     8d6:	4505                	li	a0,1
     8d8:	354000ef          	jal	c2c <exit>
     8dc:	e84a                	sd	s2,16(sp)
    exit(0);
  }

  int pid2 = fork();
     8de:	346000ef          	jal	c24 <fork>
     8e2:	892a                	mv	s2,a0
  if(pid2 < 0){
     8e4:	02054063          	bltz	a0,904 <iter+0x84>
    printf("grind: fork failed\n");
    exit(1);
  }
  if(pid2 == 0){
     8e8:	e51d                	bnez	a0,916 <iter+0x96>
    rand_next ^= 7177;
     8ea:	00001697          	auipc	a3,0x1
     8ee:	71668693          	addi	a3,a3,1814 # 2000 <rand_next>
     8f2:	629c                	ld	a5,0(a3)
     8f4:	6709                	lui	a4,0x2
     8f6:	c0970713          	addi	a4,a4,-1015 # 1c09 <digits+0x659>
     8fa:	8fb9                	xor	a5,a5,a4
     8fc:	e29c                	sd	a5,0(a3)
    go(1);
     8fe:	4505                	li	a0,1
     900:	faaff0ef          	jal	aa <go>
    printf("grind: fork failed\n");
     904:	00001517          	auipc	a0,0x1
     908:	a4c50513          	addi	a0,a0,-1460 # 1350 <malloc+0x206>
     90c:	786000ef          	jal	1092 <printf>
    exit(1);
     910:	4505                	li	a0,1
     912:	31a000ef          	jal	c2c <exit>
    exit(0);
  }

  int st1 = -1;
     916:	57fd                	li	a5,-1
     918:	fcf42e23          	sw	a5,-36(s0)
  wait(&st1);
     91c:	fdc40513          	addi	a0,s0,-36
     920:	314000ef          	jal	c34 <wait>
  if(st1 != 0){
     924:	fdc42783          	lw	a5,-36(s0)
     928:	eb99                	bnez	a5,93e <iter+0xbe>
    kill(pid1);
    kill(pid2);
  }
  int st2 = -1;
     92a:	57fd                	li	a5,-1
     92c:	fcf42c23          	sw	a5,-40(s0)
  wait(&st2);
     930:	fd840513          	addi	a0,s0,-40
     934:	300000ef          	jal	c34 <wait>

  exit(0);
     938:	4501                	li	a0,0
     93a:	2f2000ef          	jal	c2c <exit>
    kill(pid1);
     93e:	8526                	mv	a0,s1
     940:	31c000ef          	jal	c5c <kill>
    kill(pid2);
     944:	854a                	mv	a0,s2
     946:	316000ef          	jal	c5c <kill>
     94a:	b7c5                	j	92a <iter+0xaa>

000000000000094c <main>:
}

int
main()
{
     94c:	1101                	addi	sp,sp,-32
     94e:	ec06                	sd	ra,24(sp)
     950:	e822                	sd	s0,16(sp)
     952:	e426                	sd	s1,8(sp)
     954:	e04a                	sd	s2,0(sp)
     956:	1000                	addi	s0,sp,32
      exit(0);
    }
    if(pid > 0){
      wait(0);
    }
    sleep(20);
     958:	4951                	li	s2,20
    rand_next += 1;
     95a:	00001497          	auipc	s1,0x1
     95e:	6a648493          	addi	s1,s1,1702 # 2000 <rand_next>
     962:	a809                	j	974 <main+0x28>
      iter();
     964:	f1dff0ef          	jal	880 <iter>
    sleep(20);
     968:	854a                	mv	a0,s2
     96a:	352000ef          	jal	cbc <sleep>
    rand_next += 1;
     96e:	609c                	ld	a5,0(s1)
     970:	0785                	addi	a5,a5,1
     972:	e09c                	sd	a5,0(s1)
    int pid = fork();
     974:	2b0000ef          	jal	c24 <fork>
    if(pid == 0){
     978:	d575                	beqz	a0,964 <main+0x18>
    if(pid > 0){
     97a:	fea057e3          	blez	a0,968 <main+0x1c>
      wait(0);
     97e:	4501                	li	a0,0
     980:	2b4000ef          	jal	c34 <wait>
     984:	b7d5                	j	968 <main+0x1c>

0000000000000986 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
     986:	1141                	addi	sp,sp,-16
     988:	e406                	sd	ra,8(sp)
     98a:	e022                	sd	s0,0(sp)
     98c:	0800                	addi	s0,sp,16
  extern int main();
  main();
     98e:	fbfff0ef          	jal	94c <main>
  exit(0);
     992:	4501                	li	a0,0
     994:	298000ef          	jal	c2c <exit>

0000000000000998 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
     998:	1141                	addi	sp,sp,-16
     99a:	e406                	sd	ra,8(sp)
     99c:	e022                	sd	s0,0(sp)
     99e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     9a0:	87aa                	mv	a5,a0
     9a2:	0585                	addi	a1,a1,1
     9a4:	0785                	addi	a5,a5,1
     9a6:	fff5c703          	lbu	a4,-1(a1)
     9aa:	fee78fa3          	sb	a4,-1(a5)
     9ae:	fb75                	bnez	a4,9a2 <strcpy+0xa>
    ;
  return os;
}
     9b0:	60a2                	ld	ra,8(sp)
     9b2:	6402                	ld	s0,0(sp)
     9b4:	0141                	addi	sp,sp,16
     9b6:	8082                	ret

00000000000009b8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
     9b8:	1141                	addi	sp,sp,-16
     9ba:	e406                	sd	ra,8(sp)
     9bc:	e022                	sd	s0,0(sp)
     9be:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
     9c0:	00054783          	lbu	a5,0(a0)
     9c4:	cb91                	beqz	a5,9d8 <strcmp+0x20>
     9c6:	0005c703          	lbu	a4,0(a1)
     9ca:	00f71763          	bne	a4,a5,9d8 <strcmp+0x20>
    p++, q++;
     9ce:	0505                	addi	a0,a0,1
     9d0:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
     9d2:	00054783          	lbu	a5,0(a0)
     9d6:	fbe5                	bnez	a5,9c6 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
     9d8:	0005c503          	lbu	a0,0(a1)
}
     9dc:	40a7853b          	subw	a0,a5,a0
     9e0:	60a2                	ld	ra,8(sp)
     9e2:	6402                	ld	s0,0(sp)
     9e4:	0141                	addi	sp,sp,16
     9e6:	8082                	ret

00000000000009e8 <strlen>:

uint
strlen(const char *s)
{
     9e8:	1141                	addi	sp,sp,-16
     9ea:	e406                	sd	ra,8(sp)
     9ec:	e022                	sd	s0,0(sp)
     9ee:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
     9f0:	00054783          	lbu	a5,0(a0)
     9f4:	cf91                	beqz	a5,a10 <strlen+0x28>
     9f6:	00150793          	addi	a5,a0,1
     9fa:	86be                	mv	a3,a5
     9fc:	0785                	addi	a5,a5,1
     9fe:	fff7c703          	lbu	a4,-1(a5)
     a02:	ff65                	bnez	a4,9fa <strlen+0x12>
     a04:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
     a08:	60a2                	ld	ra,8(sp)
     a0a:	6402                	ld	s0,0(sp)
     a0c:	0141                	addi	sp,sp,16
     a0e:	8082                	ret
  for(n = 0; s[n]; n++)
     a10:	4501                	li	a0,0
     a12:	bfdd                	j	a08 <strlen+0x20>

0000000000000a14 <memset>:

void*
memset(void *dst, int c, uint n)
{
     a14:	1141                	addi	sp,sp,-16
     a16:	e406                	sd	ra,8(sp)
     a18:	e022                	sd	s0,0(sp)
     a1a:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     a1c:	ca19                	beqz	a2,a32 <memset+0x1e>
     a1e:	87aa                	mv	a5,a0
     a20:	1602                	slli	a2,a2,0x20
     a22:	9201                	srli	a2,a2,0x20
     a24:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
     a28:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
     a2c:	0785                	addi	a5,a5,1
     a2e:	fee79de3          	bne	a5,a4,a28 <memset+0x14>
  }
  return dst;
}
     a32:	60a2                	ld	ra,8(sp)
     a34:	6402                	ld	s0,0(sp)
     a36:	0141                	addi	sp,sp,16
     a38:	8082                	ret

0000000000000a3a <strchr>:

char*
strchr(const char *s, char c)
{
     a3a:	1141                	addi	sp,sp,-16
     a3c:	e406                	sd	ra,8(sp)
     a3e:	e022                	sd	s0,0(sp)
     a40:	0800                	addi	s0,sp,16
  for(; *s; s++)
     a42:	00054783          	lbu	a5,0(a0)
     a46:	cf81                	beqz	a5,a5e <strchr+0x24>
    if(*s == c)
     a48:	00f58763          	beq	a1,a5,a56 <strchr+0x1c>
  for(; *s; s++)
     a4c:	0505                	addi	a0,a0,1
     a4e:	00054783          	lbu	a5,0(a0)
     a52:	fbfd                	bnez	a5,a48 <strchr+0xe>
      return (char*)s;
  return 0;
     a54:	4501                	li	a0,0
}
     a56:	60a2                	ld	ra,8(sp)
     a58:	6402                	ld	s0,0(sp)
     a5a:	0141                	addi	sp,sp,16
     a5c:	8082                	ret
  return 0;
     a5e:	4501                	li	a0,0
     a60:	bfdd                	j	a56 <strchr+0x1c>

0000000000000a62 <gets>:

char*
gets(char *buf, int max)
{
     a62:	711d                	addi	sp,sp,-96
     a64:	ec86                	sd	ra,88(sp)
     a66:	e8a2                	sd	s0,80(sp)
     a68:	e4a6                	sd	s1,72(sp)
     a6a:	e0ca                	sd	s2,64(sp)
     a6c:	fc4e                	sd	s3,56(sp)
     a6e:	f852                	sd	s4,48(sp)
     a70:	f456                	sd	s5,40(sp)
     a72:	f05a                	sd	s6,32(sp)
     a74:	ec5e                	sd	s7,24(sp)
     a76:	e862                	sd	s8,16(sp)
     a78:	1080                	addi	s0,sp,96
     a7a:	8baa                	mv	s7,a0
     a7c:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     a7e:	892a                	mv	s2,a0
     a80:	4481                	li	s1,0
    cc = read(0, &c, 1);
     a82:	faf40b13          	addi	s6,s0,-81
     a86:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
     a88:	8c26                	mv	s8,s1
     a8a:	0014899b          	addiw	s3,s1,1
     a8e:	84ce                	mv	s1,s3
     a90:	0349d463          	bge	s3,s4,ab8 <gets+0x56>
    cc = read(0, &c, 1);
     a94:	8656                	mv	a2,s5
     a96:	85da                	mv	a1,s6
     a98:	4501                	li	a0,0
     a9a:	1aa000ef          	jal	c44 <read>
    if(cc < 1)
     a9e:	00a05d63          	blez	a0,ab8 <gets+0x56>
      break;
    buf[i++] = c;
     aa2:	faf44783          	lbu	a5,-81(s0)
     aa6:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
     aaa:	0905                	addi	s2,s2,1
     aac:	ff678713          	addi	a4,a5,-10
     ab0:	c319                	beqz	a4,ab6 <gets+0x54>
     ab2:	17cd                	addi	a5,a5,-13
     ab4:	fbf1                	bnez	a5,a88 <gets+0x26>
    buf[i++] = c;
     ab6:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
     ab8:	9c5e                	add	s8,s8,s7
     aba:	000c0023          	sb	zero,0(s8)
  return buf;
}
     abe:	855e                	mv	a0,s7
     ac0:	60e6                	ld	ra,88(sp)
     ac2:	6446                	ld	s0,80(sp)
     ac4:	64a6                	ld	s1,72(sp)
     ac6:	6906                	ld	s2,64(sp)
     ac8:	79e2                	ld	s3,56(sp)
     aca:	7a42                	ld	s4,48(sp)
     acc:	7aa2                	ld	s5,40(sp)
     ace:	7b02                	ld	s6,32(sp)
     ad0:	6be2                	ld	s7,24(sp)
     ad2:	6c42                	ld	s8,16(sp)
     ad4:	6125                	addi	sp,sp,96
     ad6:	8082                	ret

0000000000000ad8 <stat>:

int
stat(const char *n, struct stat *st)
{
     ad8:	1101                	addi	sp,sp,-32
     ada:	ec06                	sd	ra,24(sp)
     adc:	e822                	sd	s0,16(sp)
     ade:	e04a                	sd	s2,0(sp)
     ae0:	1000                	addi	s0,sp,32
     ae2:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     ae4:	4581                	li	a1,0
     ae6:	186000ef          	jal	c6c <open>
  if(fd < 0)
     aea:	02054263          	bltz	a0,b0e <stat+0x36>
     aee:	e426                	sd	s1,8(sp)
     af0:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
     af2:	85ca                	mv	a1,s2
     af4:	190000ef          	jal	c84 <fstat>
     af8:	892a                	mv	s2,a0
  close(fd);
     afa:	8526                	mv	a0,s1
     afc:	158000ef          	jal	c54 <close>
  return r;
     b00:	64a2                	ld	s1,8(sp)
}
     b02:	854a                	mv	a0,s2
     b04:	60e2                	ld	ra,24(sp)
     b06:	6442                	ld	s0,16(sp)
     b08:	6902                	ld	s2,0(sp)
     b0a:	6105                	addi	sp,sp,32
     b0c:	8082                	ret
    return -1;
     b0e:	57fd                	li	a5,-1
     b10:	893e                	mv	s2,a5
     b12:	bfc5                	j	b02 <stat+0x2a>

0000000000000b14 <atoi>:

int
atoi(const char *s)
{
     b14:	1141                	addi	sp,sp,-16
     b16:	e406                	sd	ra,8(sp)
     b18:	e022                	sd	s0,0(sp)
     b1a:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     b1c:	00054683          	lbu	a3,0(a0)
     b20:	fd06879b          	addiw	a5,a3,-48
     b24:	0ff7f793          	zext.b	a5,a5
     b28:	4625                	li	a2,9
     b2a:	02f66963          	bltu	a2,a5,b5c <atoi+0x48>
     b2e:	872a                	mv	a4,a0
  n = 0;
     b30:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
     b32:	0705                	addi	a4,a4,1
     b34:	0025179b          	slliw	a5,a0,0x2
     b38:	9fa9                	addw	a5,a5,a0
     b3a:	0017979b          	slliw	a5,a5,0x1
     b3e:	9fb5                	addw	a5,a5,a3
     b40:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
     b44:	00074683          	lbu	a3,0(a4)
     b48:	fd06879b          	addiw	a5,a3,-48
     b4c:	0ff7f793          	zext.b	a5,a5
     b50:	fef671e3          	bgeu	a2,a5,b32 <atoi+0x1e>
  return n;
}
     b54:	60a2                	ld	ra,8(sp)
     b56:	6402                	ld	s0,0(sp)
     b58:	0141                	addi	sp,sp,16
     b5a:	8082                	ret
  n = 0;
     b5c:	4501                	li	a0,0
     b5e:	bfdd                	j	b54 <atoi+0x40>

0000000000000b60 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     b60:	1141                	addi	sp,sp,-16
     b62:	e406                	sd	ra,8(sp)
     b64:	e022                	sd	s0,0(sp)
     b66:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     b68:	02b57563          	bgeu	a0,a1,b92 <memmove+0x32>
    while(n-- > 0)
     b6c:	00c05f63          	blez	a2,b8a <memmove+0x2a>
     b70:	1602                	slli	a2,a2,0x20
     b72:	9201                	srli	a2,a2,0x20
     b74:	00c507b3          	add	a5,a0,a2
  dst = vdst;
     b78:	872a                	mv	a4,a0
      *dst++ = *src++;
     b7a:	0585                	addi	a1,a1,1
     b7c:	0705                	addi	a4,a4,1
     b7e:	fff5c683          	lbu	a3,-1(a1)
     b82:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
     b86:	fee79ae3          	bne	a5,a4,b7a <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
     b8a:	60a2                	ld	ra,8(sp)
     b8c:	6402                	ld	s0,0(sp)
     b8e:	0141                	addi	sp,sp,16
     b90:	8082                	ret
    while(n-- > 0)
     b92:	fec05ce3          	blez	a2,b8a <memmove+0x2a>
    dst += n;
     b96:	00c50733          	add	a4,a0,a2
    src += n;
     b9a:	95b2                	add	a1,a1,a2
     b9c:	fff6079b          	addiw	a5,a2,-1
     ba0:	1782                	slli	a5,a5,0x20
     ba2:	9381                	srli	a5,a5,0x20
     ba4:	fff7c793          	not	a5,a5
     ba8:	97ba                	add	a5,a5,a4
      *--dst = *--src;
     baa:	15fd                	addi	a1,a1,-1
     bac:	177d                	addi	a4,a4,-1
     bae:	0005c683          	lbu	a3,0(a1)
     bb2:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
     bb6:	fef71ae3          	bne	a4,a5,baa <memmove+0x4a>
     bba:	bfc1                	j	b8a <memmove+0x2a>

0000000000000bbc <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
     bbc:	1141                	addi	sp,sp,-16
     bbe:	e406                	sd	ra,8(sp)
     bc0:	e022                	sd	s0,0(sp)
     bc2:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     bc4:	c61d                	beqz	a2,bf2 <memcmp+0x36>
     bc6:	1602                	slli	a2,a2,0x20
     bc8:	9201                	srli	a2,a2,0x20
     bca:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
     bce:	00054783          	lbu	a5,0(a0)
     bd2:	0005c703          	lbu	a4,0(a1)
     bd6:	00e79863          	bne	a5,a4,be6 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
     bda:	0505                	addi	a0,a0,1
    p2++;
     bdc:	0585                	addi	a1,a1,1
  while (n-- > 0) {
     bde:	fed518e3          	bne	a0,a3,bce <memcmp+0x12>
  }
  return 0;
     be2:	4501                	li	a0,0
     be4:	a019                	j	bea <memcmp+0x2e>
      return *p1 - *p2;
     be6:	40e7853b          	subw	a0,a5,a4
}
     bea:	60a2                	ld	ra,8(sp)
     bec:	6402                	ld	s0,0(sp)
     bee:	0141                	addi	sp,sp,16
     bf0:	8082                	ret
  return 0;
     bf2:	4501                	li	a0,0
     bf4:	bfdd                	j	bea <memcmp+0x2e>

0000000000000bf6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
     bf6:	1141                	addi	sp,sp,-16
     bf8:	e406                	sd	ra,8(sp)
     bfa:	e022                	sd	s0,0(sp)
     bfc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
     bfe:	f63ff0ef          	jal	b60 <memmove>
}
     c02:	60a2                	ld	ra,8(sp)
     c04:	6402                	ld	s0,0(sp)
     c06:	0141                	addi	sp,sp,16
     c08:	8082                	ret

0000000000000c0a <ugetpid>:

#ifdef LAB_PGTBL
int
ugetpid(void)
{
     c0a:	1141                	addi	sp,sp,-16
     c0c:	e406                	sd	ra,8(sp)
     c0e:	e022                	sd	s0,0(sp)
     c10:	0800                	addi	s0,sp,16
  struct usyscall *u = (struct usyscall *)USYSCALL;
  return u->pid;
     c12:	040007b7          	lui	a5,0x4000
     c16:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3ffdbf5>
     c18:	07b2                	slli	a5,a5,0xc
}
     c1a:	4388                	lw	a0,0(a5)
     c1c:	60a2                	ld	ra,8(sp)
     c1e:	6402                	ld	s0,0(sp)
     c20:	0141                	addi	sp,sp,16
     c22:	8082                	ret

0000000000000c24 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
     c24:	4885                	li	a7,1
 ecall
     c26:	00000073          	ecall
 ret
     c2a:	8082                	ret

0000000000000c2c <exit>:
.global exit
exit:
 li a7, SYS_exit
     c2c:	4889                	li	a7,2
 ecall
     c2e:	00000073          	ecall
 ret
     c32:	8082                	ret

0000000000000c34 <wait>:
.global wait
wait:
 li a7, SYS_wait
     c34:	488d                	li	a7,3
 ecall
     c36:	00000073          	ecall
 ret
     c3a:	8082                	ret

0000000000000c3c <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
     c3c:	4891                	li	a7,4
 ecall
     c3e:	00000073          	ecall
 ret
     c42:	8082                	ret

0000000000000c44 <read>:
.global read
read:
 li a7, SYS_read
     c44:	4895                	li	a7,5
 ecall
     c46:	00000073          	ecall
 ret
     c4a:	8082                	ret

0000000000000c4c <write>:
.global write
write:
 li a7, SYS_write
     c4c:	48c1                	li	a7,16
 ecall
     c4e:	00000073          	ecall
 ret
     c52:	8082                	ret

0000000000000c54 <close>:
.global close
close:
 li a7, SYS_close
     c54:	48d5                	li	a7,21
 ecall
     c56:	00000073          	ecall
 ret
     c5a:	8082                	ret

0000000000000c5c <kill>:
.global kill
kill:
 li a7, SYS_kill
     c5c:	4899                	li	a7,6
 ecall
     c5e:	00000073          	ecall
 ret
     c62:	8082                	ret

0000000000000c64 <exec>:
.global exec
exec:
 li a7, SYS_exec
     c64:	489d                	li	a7,7
 ecall
     c66:	00000073          	ecall
 ret
     c6a:	8082                	ret

0000000000000c6c <open>:
.global open
open:
 li a7, SYS_open
     c6c:	48bd                	li	a7,15
 ecall
     c6e:	00000073          	ecall
 ret
     c72:	8082                	ret

0000000000000c74 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
     c74:	48c5                	li	a7,17
 ecall
     c76:	00000073          	ecall
 ret
     c7a:	8082                	ret

0000000000000c7c <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
     c7c:	48c9                	li	a7,18
 ecall
     c7e:	00000073          	ecall
 ret
     c82:	8082                	ret

0000000000000c84 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
     c84:	48a1                	li	a7,8
 ecall
     c86:	00000073          	ecall
 ret
     c8a:	8082                	ret

0000000000000c8c <link>:
.global link
link:
 li a7, SYS_link
     c8c:	48cd                	li	a7,19
 ecall
     c8e:	00000073          	ecall
 ret
     c92:	8082                	ret

0000000000000c94 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
     c94:	48d1                	li	a7,20
 ecall
     c96:	00000073          	ecall
 ret
     c9a:	8082                	ret

0000000000000c9c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
     c9c:	48a5                	li	a7,9
 ecall
     c9e:	00000073          	ecall
 ret
     ca2:	8082                	ret

0000000000000ca4 <dup>:
.global dup
dup:
 li a7, SYS_dup
     ca4:	48a9                	li	a7,10
 ecall
     ca6:	00000073          	ecall
 ret
     caa:	8082                	ret

0000000000000cac <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
     cac:	48ad                	li	a7,11
 ecall
     cae:	00000073          	ecall
 ret
     cb2:	8082                	ret

0000000000000cb4 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
     cb4:	48b1                	li	a7,12
 ecall
     cb6:	00000073          	ecall
 ret
     cba:	8082                	ret

0000000000000cbc <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
     cbc:	48b5                	li	a7,13
 ecall
     cbe:	00000073          	ecall
 ret
     cc2:	8082                	ret

0000000000000cc4 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
     cc4:	48b9                	li	a7,14
 ecall
     cc6:	00000073          	ecall
 ret
     cca:	8082                	ret

0000000000000ccc <bind>:
.global bind
bind:
 li a7, SYS_bind
     ccc:	48f5                	li	a7,29
 ecall
     cce:	00000073          	ecall
 ret
     cd2:	8082                	ret

0000000000000cd4 <unbind>:
.global unbind
unbind:
 li a7, SYS_unbind
     cd4:	48f9                	li	a7,30
 ecall
     cd6:	00000073          	ecall
 ret
     cda:	8082                	ret

0000000000000cdc <send>:
.global send
send:
 li a7, SYS_send
     cdc:	48fd                	li	a7,31
 ecall
     cde:	00000073          	ecall
 ret
     ce2:	8082                	ret

0000000000000ce4 <recv>:
.global recv
recv:
 li a7, SYS_recv
     ce4:	02000893          	li	a7,32
 ecall
     ce8:	00000073          	ecall
 ret
     cec:	8082                	ret

0000000000000cee <pgpte>:
.global pgpte
pgpte:
 li a7, SYS_pgpte
     cee:	02100893          	li	a7,33
 ecall
     cf2:	00000073          	ecall
 ret
     cf6:	8082                	ret

0000000000000cf8 <kpgtbl>:
.global kpgtbl
kpgtbl:
 li a7, SYS_kpgtbl
     cf8:	02200893          	li	a7,34
 ecall
     cfc:	00000073          	ecall
 ret
     d00:	8082                	ret

0000000000000d02 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
     d02:	1101                	addi	sp,sp,-32
     d04:	ec06                	sd	ra,24(sp)
     d06:	e822                	sd	s0,16(sp)
     d08:	1000                	addi	s0,sp,32
     d0a:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
     d0e:	4605                	li	a2,1
     d10:	fef40593          	addi	a1,s0,-17
     d14:	f39ff0ef          	jal	c4c <write>
}
     d18:	60e2                	ld	ra,24(sp)
     d1a:	6442                	ld	s0,16(sp)
     d1c:	6105                	addi	sp,sp,32
     d1e:	8082                	ret

0000000000000d20 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
     d20:	7139                	addi	sp,sp,-64
     d22:	fc06                	sd	ra,56(sp)
     d24:	f822                	sd	s0,48(sp)
     d26:	f04a                	sd	s2,32(sp)
     d28:	ec4e                	sd	s3,24(sp)
     d2a:	0080                	addi	s0,sp,64
     d2c:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     d2e:	cac9                	beqz	a3,dc0 <printint+0xa0>
     d30:	01f5d79b          	srliw	a5,a1,0x1f
     d34:	c7d1                	beqz	a5,dc0 <printint+0xa0>
    neg = 1;
    x = -xx;
     d36:	40b005bb          	negw	a1,a1
    neg = 1;
     d3a:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
     d3c:	fc040993          	addi	s3,s0,-64
  neg = 0;
     d40:	86ce                	mv	a3,s3
  i = 0;
     d42:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
     d44:	00001817          	auipc	a6,0x1
     d48:	86c80813          	addi	a6,a6,-1940 # 15b0 <digits>
     d4c:	88ba                	mv	a7,a4
     d4e:	0017051b          	addiw	a0,a4,1
     d52:	872a                	mv	a4,a0
     d54:	02c5f7bb          	remuw	a5,a1,a2
     d58:	1782                	slli	a5,a5,0x20
     d5a:	9381                	srli	a5,a5,0x20
     d5c:	97c2                	add	a5,a5,a6
     d5e:	0007c783          	lbu	a5,0(a5)
     d62:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
     d66:	87ae                	mv	a5,a1
     d68:	02c5d5bb          	divuw	a1,a1,a2
     d6c:	0685                	addi	a3,a3,1
     d6e:	fcc7ffe3          	bgeu	a5,a2,d4c <printint+0x2c>
  if(neg)
     d72:	00030c63          	beqz	t1,d8a <printint+0x6a>
    buf[i++] = '-';
     d76:	fd050793          	addi	a5,a0,-48
     d7a:	00878533          	add	a0,a5,s0
     d7e:	02d00793          	li	a5,45
     d82:	fef50823          	sb	a5,-16(a0)
     d86:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
     d8a:	02e05563          	blez	a4,db4 <printint+0x94>
     d8e:	f426                	sd	s1,40(sp)
     d90:	377d                	addiw	a4,a4,-1
     d92:	00e984b3          	add	s1,s3,a4
     d96:	19fd                	addi	s3,s3,-1
     d98:	99ba                	add	s3,s3,a4
     d9a:	1702                	slli	a4,a4,0x20
     d9c:	9301                	srli	a4,a4,0x20
     d9e:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
     da2:	0004c583          	lbu	a1,0(s1)
     da6:	854a                	mv	a0,s2
     da8:	f5bff0ef          	jal	d02 <putc>
  while(--i >= 0)
     dac:	14fd                	addi	s1,s1,-1
     dae:	ff349ae3          	bne	s1,s3,da2 <printint+0x82>
     db2:	74a2                	ld	s1,40(sp)
}
     db4:	70e2                	ld	ra,56(sp)
     db6:	7442                	ld	s0,48(sp)
     db8:	7902                	ld	s2,32(sp)
     dba:	69e2                	ld	s3,24(sp)
     dbc:	6121                	addi	sp,sp,64
     dbe:	8082                	ret
  neg = 0;
     dc0:	4301                	li	t1,0
     dc2:	bfad                	j	d3c <printint+0x1c>

0000000000000dc4 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
     dc4:	711d                	addi	sp,sp,-96
     dc6:	ec86                	sd	ra,88(sp)
     dc8:	e8a2                	sd	s0,80(sp)
     dca:	e4a6                	sd	s1,72(sp)
     dcc:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
     dce:	0005c483          	lbu	s1,0(a1)
     dd2:	20048963          	beqz	s1,fe4 <vprintf+0x220>
     dd6:	e0ca                	sd	s2,64(sp)
     dd8:	fc4e                	sd	s3,56(sp)
     dda:	f852                	sd	s4,48(sp)
     ddc:	f456                	sd	s5,40(sp)
     dde:	f05a                	sd	s6,32(sp)
     de0:	ec5e                	sd	s7,24(sp)
     de2:	e862                	sd	s8,16(sp)
     de4:	8b2a                	mv	s6,a0
     de6:	8a2e                	mv	s4,a1
     de8:	8bb2                	mv	s7,a2
  state = 0;
     dea:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
     dec:	4901                	li	s2,0
     dee:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
     df0:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
     df4:	06400c13          	li	s8,100
     df8:	a00d                	j	e1a <vprintf+0x56>
        putc(fd, c0);
     dfa:	85a6                	mv	a1,s1
     dfc:	855a                	mv	a0,s6
     dfe:	f05ff0ef          	jal	d02 <putc>
     e02:	a019                	j	e08 <vprintf+0x44>
    } else if(state == '%'){
     e04:	03598363          	beq	s3,s5,e2a <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
     e08:	0019079b          	addiw	a5,s2,1
     e0c:	893e                	mv	s2,a5
     e0e:	873e                	mv	a4,a5
     e10:	97d2                	add	a5,a5,s4
     e12:	0007c483          	lbu	s1,0(a5)
     e16:	1c048063          	beqz	s1,fd6 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
     e1a:	0004879b          	sext.w	a5,s1
    if(state == 0){
     e1e:	fe0993e3          	bnez	s3,e04 <vprintf+0x40>
      if(c0 == '%'){
     e22:	fd579ce3          	bne	a5,s5,dfa <vprintf+0x36>
        state = '%';
     e26:	89be                	mv	s3,a5
     e28:	b7c5                	j	e08 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
     e2a:	00ea06b3          	add	a3,s4,a4
     e2e:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
     e32:	1a060e63          	beqz	a2,fee <vprintf+0x22a>
      if(c0 == 'd'){
     e36:	03878763          	beq	a5,s8,e64 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
     e3a:	f9478693          	addi	a3,a5,-108
     e3e:	0016b693          	seqz	a3,a3
     e42:	f9c60593          	addi	a1,a2,-100
     e46:	e99d                	bnez	a1,e7c <vprintf+0xb8>
     e48:	ca95                	beqz	a3,e7c <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
     e4a:	008b8493          	addi	s1,s7,8
     e4e:	4685                	li	a3,1
     e50:	4629                	li	a2,10
     e52:	000ba583          	lw	a1,0(s7)
     e56:	855a                	mv	a0,s6
     e58:	ec9ff0ef          	jal	d20 <printint>
        i += 1;
     e5c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
     e5e:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
     e60:	4981                	li	s3,0
     e62:	b75d                	j	e08 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
     e64:	008b8493          	addi	s1,s7,8
     e68:	4685                	li	a3,1
     e6a:	4629                	li	a2,10
     e6c:	000ba583          	lw	a1,0(s7)
     e70:	855a                	mv	a0,s6
     e72:	eafff0ef          	jal	d20 <printint>
     e76:	8ba6                	mv	s7,s1
      state = 0;
     e78:	4981                	li	s3,0
     e7a:	b779                	j	e08 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
     e7c:	9752                	add	a4,a4,s4
     e7e:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
     e82:	f9460713          	addi	a4,a2,-108
     e86:	00173713          	seqz	a4,a4
     e8a:	8f75                	and	a4,a4,a3
     e8c:	f9c58513          	addi	a0,a1,-100
     e90:	16051963          	bnez	a0,1002 <vprintf+0x23e>
     e94:	16070763          	beqz	a4,1002 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
     e98:	008b8493          	addi	s1,s7,8
     e9c:	4685                	li	a3,1
     e9e:	4629                	li	a2,10
     ea0:	000ba583          	lw	a1,0(s7)
     ea4:	855a                	mv	a0,s6
     ea6:	e7bff0ef          	jal	d20 <printint>
        i += 2;
     eaa:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
     eac:	8ba6                	mv	s7,s1
      state = 0;
     eae:	4981                	li	s3,0
        i += 2;
     eb0:	bfa1                	j	e08 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
     eb2:	008b8493          	addi	s1,s7,8
     eb6:	4681                	li	a3,0
     eb8:	4629                	li	a2,10
     eba:	000ba583          	lw	a1,0(s7)
     ebe:	855a                	mv	a0,s6
     ec0:	e61ff0ef          	jal	d20 <printint>
     ec4:	8ba6                	mv	s7,s1
      state = 0;
     ec6:	4981                	li	s3,0
     ec8:	b781                	j	e08 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     eca:	008b8493          	addi	s1,s7,8
     ece:	4681                	li	a3,0
     ed0:	4629                	li	a2,10
     ed2:	000ba583          	lw	a1,0(s7)
     ed6:	855a                	mv	a0,s6
     ed8:	e49ff0ef          	jal	d20 <printint>
        i += 1;
     edc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
     ede:	8ba6                	mv	s7,s1
      state = 0;
     ee0:	4981                	li	s3,0
     ee2:	b71d                	j	e08 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     ee4:	008b8493          	addi	s1,s7,8
     ee8:	4681                	li	a3,0
     eea:	4629                	li	a2,10
     eec:	000ba583          	lw	a1,0(s7)
     ef0:	855a                	mv	a0,s6
     ef2:	e2fff0ef          	jal	d20 <printint>
        i += 2;
     ef6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
     ef8:	8ba6                	mv	s7,s1
      state = 0;
     efa:	4981                	li	s3,0
        i += 2;
     efc:	b731                	j	e08 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
     efe:	008b8493          	addi	s1,s7,8
     f02:	4681                	li	a3,0
     f04:	4641                	li	a2,16
     f06:	000ba583          	lw	a1,0(s7)
     f0a:	855a                	mv	a0,s6
     f0c:	e15ff0ef          	jal	d20 <printint>
     f10:	8ba6                	mv	s7,s1
      state = 0;
     f12:	4981                	li	s3,0
     f14:	bdd5                	j	e08 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     f16:	008b8493          	addi	s1,s7,8
     f1a:	4681                	li	a3,0
     f1c:	4641                	li	a2,16
     f1e:	000ba583          	lw	a1,0(s7)
     f22:	855a                	mv	a0,s6
     f24:	dfdff0ef          	jal	d20 <printint>
        i += 1;
     f28:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
     f2a:	8ba6                	mv	s7,s1
      state = 0;
     f2c:	4981                	li	s3,0
     f2e:	bde9                	j	e08 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     f30:	008b8493          	addi	s1,s7,8
     f34:	4681                	li	a3,0
     f36:	4641                	li	a2,16
     f38:	000ba583          	lw	a1,0(s7)
     f3c:	855a                	mv	a0,s6
     f3e:	de3ff0ef          	jal	d20 <printint>
        i += 2;
     f42:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
     f44:	8ba6                	mv	s7,s1
      state = 0;
     f46:	4981                	li	s3,0
        i += 2;
     f48:	b5c1                	j	e08 <vprintf+0x44>
     f4a:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
     f4c:	008b8793          	addi	a5,s7,8
     f50:	8cbe                	mv	s9,a5
     f52:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
     f56:	03000593          	li	a1,48
     f5a:	855a                	mv	a0,s6
     f5c:	da7ff0ef          	jal	d02 <putc>
  putc(fd, 'x');
     f60:	07800593          	li	a1,120
     f64:	855a                	mv	a0,s6
     f66:	d9dff0ef          	jal	d02 <putc>
     f6a:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     f6c:	00000b97          	auipc	s7,0x0
     f70:	644b8b93          	addi	s7,s7,1604 # 15b0 <digits>
     f74:	03c9d793          	srli	a5,s3,0x3c
     f78:	97de                	add	a5,a5,s7
     f7a:	0007c583          	lbu	a1,0(a5)
     f7e:	855a                	mv	a0,s6
     f80:	d83ff0ef          	jal	d02 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     f84:	0992                	slli	s3,s3,0x4
     f86:	34fd                	addiw	s1,s1,-1
     f88:	f4f5                	bnez	s1,f74 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
     f8a:	8be6                	mv	s7,s9
      state = 0;
     f8c:	4981                	li	s3,0
     f8e:	6ca2                	ld	s9,8(sp)
     f90:	bda5                	j	e08 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
     f92:	008b8993          	addi	s3,s7,8
     f96:	000bb483          	ld	s1,0(s7)
     f9a:	cc91                	beqz	s1,fb6 <vprintf+0x1f2>
        for(; *s; s++)
     f9c:	0004c583          	lbu	a1,0(s1)
     fa0:	c985                	beqz	a1,fd0 <vprintf+0x20c>
          putc(fd, *s);
     fa2:	855a                	mv	a0,s6
     fa4:	d5fff0ef          	jal	d02 <putc>
        for(; *s; s++)
     fa8:	0485                	addi	s1,s1,1
     faa:	0004c583          	lbu	a1,0(s1)
     fae:	f9f5                	bnez	a1,fa2 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
     fb0:	8bce                	mv	s7,s3
      state = 0;
     fb2:	4981                	li	s3,0
     fb4:	bd91                	j	e08 <vprintf+0x44>
          s = "(null)";
     fb6:	00000497          	auipc	s1,0x0
     fba:	59248493          	addi	s1,s1,1426 # 1548 <malloc+0x3fe>
        for(; *s; s++)
     fbe:	02800593          	li	a1,40
     fc2:	b7c5                	j	fa2 <vprintf+0x1de>
        putc(fd, '%');
     fc4:	85be                	mv	a1,a5
     fc6:	855a                	mv	a0,s6
     fc8:	d3bff0ef          	jal	d02 <putc>
      state = 0;
     fcc:	4981                	li	s3,0
     fce:	bd2d                	j	e08 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
     fd0:	8bce                	mv	s7,s3
      state = 0;
     fd2:	4981                	li	s3,0
     fd4:	bd15                	j	e08 <vprintf+0x44>
     fd6:	6906                	ld	s2,64(sp)
     fd8:	79e2                	ld	s3,56(sp)
     fda:	7a42                	ld	s4,48(sp)
     fdc:	7aa2                	ld	s5,40(sp)
     fde:	7b02                	ld	s6,32(sp)
     fe0:	6be2                	ld	s7,24(sp)
     fe2:	6c42                	ld	s8,16(sp)
    }
  }
}
     fe4:	60e6                	ld	ra,88(sp)
     fe6:	6446                	ld	s0,80(sp)
     fe8:	64a6                	ld	s1,72(sp)
     fea:	6125                	addi	sp,sp,96
     fec:	8082                	ret
      if(c0 == 'd'){
     fee:	06400713          	li	a4,100
     ff2:	e6e789e3          	beq	a5,a4,e64 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
     ff6:	f9478693          	addi	a3,a5,-108
     ffa:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
     ffe:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    1000:	4701                	li	a4,0
      } else if(c0 == 'u'){
    1002:	07500513          	li	a0,117
    1006:	eaa786e3          	beq	a5,a0,eb2 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
    100a:	f8b60513          	addi	a0,a2,-117
    100e:	e119                	bnez	a0,1014 <vprintf+0x250>
    1010:	ea069de3          	bnez	a3,eca <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    1014:	f8b58513          	addi	a0,a1,-117
    1018:	e119                	bnez	a0,101e <vprintf+0x25a>
    101a:	ec0715e3          	bnez	a4,ee4 <vprintf+0x120>
      } else if(c0 == 'x'){
    101e:	07800513          	li	a0,120
    1022:	eca78ee3          	beq	a5,a0,efe <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
    1026:	f8860613          	addi	a2,a2,-120
    102a:	e219                	bnez	a2,1030 <vprintf+0x26c>
    102c:	ee0695e3          	bnez	a3,f16 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    1030:	f8858593          	addi	a1,a1,-120
    1034:	e199                	bnez	a1,103a <vprintf+0x276>
    1036:	ee071de3          	bnez	a4,f30 <vprintf+0x16c>
      } else if(c0 == 'p'){
    103a:	07000713          	li	a4,112
    103e:	f0e786e3          	beq	a5,a4,f4a <vprintf+0x186>
      } else if(c0 == 's'){
    1042:	07300713          	li	a4,115
    1046:	f4e786e3          	beq	a5,a4,f92 <vprintf+0x1ce>
      } else if(c0 == '%'){
    104a:	02500713          	li	a4,37
    104e:	f6e78be3          	beq	a5,a4,fc4 <vprintf+0x200>
        putc(fd, '%');
    1052:	02500593          	li	a1,37
    1056:	855a                	mv	a0,s6
    1058:	cabff0ef          	jal	d02 <putc>
        putc(fd, c0);
    105c:	85a6                	mv	a1,s1
    105e:	855a                	mv	a0,s6
    1060:	ca3ff0ef          	jal	d02 <putc>
      state = 0;
    1064:	4981                	li	s3,0
    1066:	b34d                	j	e08 <vprintf+0x44>

0000000000001068 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    1068:	715d                	addi	sp,sp,-80
    106a:	ec06                	sd	ra,24(sp)
    106c:	e822                	sd	s0,16(sp)
    106e:	1000                	addi	s0,sp,32
    1070:	e010                	sd	a2,0(s0)
    1072:	e414                	sd	a3,8(s0)
    1074:	e818                	sd	a4,16(s0)
    1076:	ec1c                	sd	a5,24(s0)
    1078:	03043023          	sd	a6,32(s0)
    107c:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    1080:	8622                	mv	a2,s0
    1082:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    1086:	d3fff0ef          	jal	dc4 <vprintf>
}
    108a:	60e2                	ld	ra,24(sp)
    108c:	6442                	ld	s0,16(sp)
    108e:	6161                	addi	sp,sp,80
    1090:	8082                	ret

0000000000001092 <printf>:

void
printf(const char *fmt, ...)
{
    1092:	711d                	addi	sp,sp,-96
    1094:	ec06                	sd	ra,24(sp)
    1096:	e822                	sd	s0,16(sp)
    1098:	1000                	addi	s0,sp,32
    109a:	e40c                	sd	a1,8(s0)
    109c:	e810                	sd	a2,16(s0)
    109e:	ec14                	sd	a3,24(s0)
    10a0:	f018                	sd	a4,32(s0)
    10a2:	f41c                	sd	a5,40(s0)
    10a4:	03043823          	sd	a6,48(s0)
    10a8:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    10ac:	00840613          	addi	a2,s0,8
    10b0:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    10b4:	85aa                	mv	a1,a0
    10b6:	4505                	li	a0,1
    10b8:	d0dff0ef          	jal	dc4 <vprintf>
}
    10bc:	60e2                	ld	ra,24(sp)
    10be:	6442                	ld	s0,16(sp)
    10c0:	6125                	addi	sp,sp,96
    10c2:	8082                	ret

00000000000010c4 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    10c4:	1141                	addi	sp,sp,-16
    10c6:	e406                	sd	ra,8(sp)
    10c8:	e022                	sd	s0,0(sp)
    10ca:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    10cc:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    10d0:	00001797          	auipc	a5,0x1
    10d4:	f407b783          	ld	a5,-192(a5) # 2010 <freep>
    10d8:	a039                	j	10e6 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    10da:	6398                	ld	a4,0(a5)
    10dc:	00e7e463          	bltu	a5,a4,10e4 <free+0x20>
    10e0:	00e6ea63          	bltu	a3,a4,10f4 <free+0x30>
{
    10e4:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    10e6:	fed7fae3          	bgeu	a5,a3,10da <free+0x16>
    10ea:	6398                	ld	a4,0(a5)
    10ec:	00e6e463          	bltu	a3,a4,10f4 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    10f0:	fee7eae3          	bltu	a5,a4,10e4 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
    10f4:	ff852583          	lw	a1,-8(a0)
    10f8:	6390                	ld	a2,0(a5)
    10fa:	02059813          	slli	a6,a1,0x20
    10fe:	01c85713          	srli	a4,a6,0x1c
    1102:	9736                	add	a4,a4,a3
    1104:	02e60563          	beq	a2,a4,112e <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    1108:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    110c:	4790                	lw	a2,8(a5)
    110e:	02061593          	slli	a1,a2,0x20
    1112:	01c5d713          	srli	a4,a1,0x1c
    1116:	973e                	add	a4,a4,a5
    1118:	02e68263          	beq	a3,a4,113c <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    111c:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    111e:	00001717          	auipc	a4,0x1
    1122:	eef73923          	sd	a5,-270(a4) # 2010 <freep>
}
    1126:	60a2                	ld	ra,8(sp)
    1128:	6402                	ld	s0,0(sp)
    112a:	0141                	addi	sp,sp,16
    112c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    112e:	4618                	lw	a4,8(a2)
    1130:	9f2d                	addw	a4,a4,a1
    1132:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    1136:	6398                	ld	a4,0(a5)
    1138:	6310                	ld	a2,0(a4)
    113a:	b7f9                	j	1108 <free+0x44>
    p->s.size += bp->s.size;
    113c:	ff852703          	lw	a4,-8(a0)
    1140:	9f31                	addw	a4,a4,a2
    1142:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    1144:	ff053683          	ld	a3,-16(a0)
    1148:	bfd1                	j	111c <free+0x58>

000000000000114a <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    114a:	7139                	addi	sp,sp,-64
    114c:	fc06                	sd	ra,56(sp)
    114e:	f822                	sd	s0,48(sp)
    1150:	f04a                	sd	s2,32(sp)
    1152:	ec4e                	sd	s3,24(sp)
    1154:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1156:	02051993          	slli	s3,a0,0x20
    115a:	0209d993          	srli	s3,s3,0x20
    115e:	09bd                	addi	s3,s3,15
    1160:	0049d993          	srli	s3,s3,0x4
    1164:	2985                	addiw	s3,s3,1
    1166:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
    1168:	00001517          	auipc	a0,0x1
    116c:	ea853503          	ld	a0,-344(a0) # 2010 <freep>
    1170:	c905                	beqz	a0,11a0 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1172:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    1174:	4798                	lw	a4,8(a5)
    1176:	09377663          	bgeu	a4,s3,1202 <malloc+0xb8>
    117a:	f426                	sd	s1,40(sp)
    117c:	e852                	sd	s4,16(sp)
    117e:	e456                	sd	s5,8(sp)
    1180:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
    1182:	8a4e                	mv	s4,s3
    1184:	6705                	lui	a4,0x1
    1186:	00e9f363          	bgeu	s3,a4,118c <malloc+0x42>
    118a:	6a05                	lui	s4,0x1
    118c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    1190:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    1194:	00001497          	auipc	s1,0x1
    1198:	e7c48493          	addi	s1,s1,-388 # 2010 <freep>
  if(p == (char*)-1)
    119c:	5afd                	li	s5,-1
    119e:	a83d                	j	11dc <malloc+0x92>
    11a0:	f426                	sd	s1,40(sp)
    11a2:	e852                	sd	s4,16(sp)
    11a4:	e456                	sd	s5,8(sp)
    11a6:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    11a8:	00001797          	auipc	a5,0x1
    11ac:	26078793          	addi	a5,a5,608 # 2408 <base>
    11b0:	00001717          	auipc	a4,0x1
    11b4:	e6f73023          	sd	a5,-416(a4) # 2010 <freep>
    11b8:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    11ba:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    11be:	b7d1                	j	1182 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    11c0:	6398                	ld	a4,0(a5)
    11c2:	e118                	sd	a4,0(a0)
    11c4:	a899                	j	121a <malloc+0xd0>
  hp->s.size = nu;
    11c6:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    11ca:	0541                	addi	a0,a0,16
    11cc:	ef9ff0ef          	jal	10c4 <free>
  return freep;
    11d0:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
    11d2:	c125                	beqz	a0,1232 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    11d4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    11d6:	4798                	lw	a4,8(a5)
    11d8:	03277163          	bgeu	a4,s2,11fa <malloc+0xb0>
    if(p == freep)
    11dc:	6098                	ld	a4,0(s1)
    11de:	853e                	mv	a0,a5
    11e0:	fef71ae3          	bne	a4,a5,11d4 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    11e4:	8552                	mv	a0,s4
    11e6:	acfff0ef          	jal	cb4 <sbrk>
  if(p == (char*)-1)
    11ea:	fd551ee3          	bne	a0,s5,11c6 <malloc+0x7c>
        return 0;
    11ee:	4501                	li	a0,0
    11f0:	74a2                	ld	s1,40(sp)
    11f2:	6a42                	ld	s4,16(sp)
    11f4:	6aa2                	ld	s5,8(sp)
    11f6:	6b02                	ld	s6,0(sp)
    11f8:	a03d                	j	1226 <malloc+0xdc>
    11fa:	74a2                	ld	s1,40(sp)
    11fc:	6a42                	ld	s4,16(sp)
    11fe:	6aa2                	ld	s5,8(sp)
    1200:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
    1202:	fae90fe3          	beq	s2,a4,11c0 <malloc+0x76>
        p->s.size -= nunits;
    1206:	4137073b          	subw	a4,a4,s3
    120a:	c798                	sw	a4,8(a5)
        p += p->s.size;
    120c:	02071693          	slli	a3,a4,0x20
    1210:	01c6d713          	srli	a4,a3,0x1c
    1214:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    1216:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    121a:	00001717          	auipc	a4,0x1
    121e:	dea73b23          	sd	a0,-522(a4) # 2010 <freep>
      return (void*)(p + 1);
    1222:	01078513          	addi	a0,a5,16
  }
}
    1226:	70e2                	ld	ra,56(sp)
    1228:	7442                	ld	s0,48(sp)
    122a:	7902                	ld	s2,32(sp)
    122c:	69e2                	ld	s3,24(sp)
    122e:	6121                	addi	sp,sp,64
    1230:	8082                	ret
    1232:	74a2                	ld	s1,40(sp)
    1234:	6a42                	ld	s4,16(sp)
    1236:	6aa2                	ld	s5,8(sp)
    1238:	6b02                	ld	s6,0(sp)
    123a:	b7f5                	j	1226 <malloc+0xdc>
