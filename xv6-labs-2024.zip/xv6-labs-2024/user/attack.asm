
user/_attack:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "user/user.h"

#define PGSIZE 4096

int main() {
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
    // 分配足够多的内存页，确保覆盖到secret释放的页
    char *p = sbrk(17 * PGSIZE);  // 分配17页（覆盖secret的第10页）
   8:	6545                	lui	a0,0x11
   a:	348000ef          	jal	352 <sbrk>
    if (p == (char*)-1) {
   e:	57fd                	li	a5,-1
  10:	00f50d63          	beq	a0,a5,2a <main+0x2a>

    // 定位到第16页的起始地址（跳过attack自身分配的页）
    char *secret_page = p + 16 * PGSIZE;

    // 读取secret（偏移32字节处，避免覆盖栈指针）
    write(2, secret_page + 32, 8);  // 输出8字节secret
  14:	4621                	li	a2,8
  16:	65c1                	lui	a1,0x10
  18:	02058593          	addi	a1,a1,32 # 10020 <base+0xf010>
  1c:	95aa                	add	a1,a1,a0
  1e:	4509                	li	a0,2
  20:	2ca000ef          	jal	2ea <write>
    exit(0);
  24:	4501                	li	a0,0
  26:	2a4000ef          	jal	2ca <exit>
        fprintf(2, "sbrk failed\n");
  2a:	00001597          	auipc	a1,0x1
  2e:	88658593          	addi	a1,a1,-1914 # 8b0 <malloc+0xf6>
  32:	4509                	li	a0,2
  34:	6a4000ef          	jal	6d8 <fprintf>
        exit(1);
  38:	4505                	li	a0,1
  3a:	290000ef          	jal	2ca <exit>

000000000000003e <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  3e:	1141                	addi	sp,sp,-16
  40:	e406                	sd	ra,8(sp)
  42:	e022                	sd	s0,0(sp)
  44:	0800                	addi	s0,sp,16
  extern int main();
  main();
  46:	fbbff0ef          	jal	0 <main>
  exit(0);
  4a:	4501                	li	a0,0
  4c:	27e000ef          	jal	2ca <exit>

0000000000000050 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  50:	1141                	addi	sp,sp,-16
  52:	e406                	sd	ra,8(sp)
  54:	e022                	sd	s0,0(sp)
  56:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  58:	87aa                	mv	a5,a0
  5a:	0585                	addi	a1,a1,1
  5c:	0785                	addi	a5,a5,1
  5e:	fff5c703          	lbu	a4,-1(a1)
  62:	fee78fa3          	sb	a4,-1(a5)
  66:	fb75                	bnez	a4,5a <strcpy+0xa>
    ;
  return os;
}
  68:	60a2                	ld	ra,8(sp)
  6a:	6402                	ld	s0,0(sp)
  6c:	0141                	addi	sp,sp,16
  6e:	8082                	ret

0000000000000070 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  70:	1141                	addi	sp,sp,-16
  72:	e406                	sd	ra,8(sp)
  74:	e022                	sd	s0,0(sp)
  76:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  78:	00054783          	lbu	a5,0(a0) # 11000 <base+0xfff0>
  7c:	cb91                	beqz	a5,90 <strcmp+0x20>
  7e:	0005c703          	lbu	a4,0(a1)
  82:	00f71763          	bne	a4,a5,90 <strcmp+0x20>
    p++, q++;
  86:	0505                	addi	a0,a0,1
  88:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  8a:	00054783          	lbu	a5,0(a0)
  8e:	fbe5                	bnez	a5,7e <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  90:	0005c503          	lbu	a0,0(a1)
}
  94:	40a7853b          	subw	a0,a5,a0
  98:	60a2                	ld	ra,8(sp)
  9a:	6402                	ld	s0,0(sp)
  9c:	0141                	addi	sp,sp,16
  9e:	8082                	ret

00000000000000a0 <strlen>:

uint
strlen(const char *s)
{
  a0:	1141                	addi	sp,sp,-16
  a2:	e406                	sd	ra,8(sp)
  a4:	e022                	sd	s0,0(sp)
  a6:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  a8:	00054783          	lbu	a5,0(a0)
  ac:	cf91                	beqz	a5,c8 <strlen+0x28>
  ae:	00150793          	addi	a5,a0,1
  b2:	86be                	mv	a3,a5
  b4:	0785                	addi	a5,a5,1
  b6:	fff7c703          	lbu	a4,-1(a5)
  ba:	ff65                	bnez	a4,b2 <strlen+0x12>
  bc:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  c0:	60a2                	ld	ra,8(sp)
  c2:	6402                	ld	s0,0(sp)
  c4:	0141                	addi	sp,sp,16
  c6:	8082                	ret
  for(n = 0; s[n]; n++)
  c8:	4501                	li	a0,0
  ca:	bfdd                	j	c0 <strlen+0x20>

00000000000000cc <memset>:

void*
memset(void *dst, int c, uint n)
{
  cc:	1141                	addi	sp,sp,-16
  ce:	e406                	sd	ra,8(sp)
  d0:	e022                	sd	s0,0(sp)
  d2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  d4:	ca19                	beqz	a2,ea <memset+0x1e>
  d6:	87aa                	mv	a5,a0
  d8:	1602                	slli	a2,a2,0x20
  da:	9201                	srli	a2,a2,0x20
  dc:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  e0:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  e4:	0785                	addi	a5,a5,1
  e6:	fee79de3          	bne	a5,a4,e0 <memset+0x14>
  }
  return dst;
}
  ea:	60a2                	ld	ra,8(sp)
  ec:	6402                	ld	s0,0(sp)
  ee:	0141                	addi	sp,sp,16
  f0:	8082                	ret

00000000000000f2 <strchr>:

char*
strchr(const char *s, char c)
{
  f2:	1141                	addi	sp,sp,-16
  f4:	e406                	sd	ra,8(sp)
  f6:	e022                	sd	s0,0(sp)
  f8:	0800                	addi	s0,sp,16
  for(; *s; s++)
  fa:	00054783          	lbu	a5,0(a0)
  fe:	cf81                	beqz	a5,116 <strchr+0x24>
    if(*s == c)
 100:	00f58763          	beq	a1,a5,10e <strchr+0x1c>
  for(; *s; s++)
 104:	0505                	addi	a0,a0,1
 106:	00054783          	lbu	a5,0(a0)
 10a:	fbfd                	bnez	a5,100 <strchr+0xe>
      return (char*)s;
  return 0;
 10c:	4501                	li	a0,0
}
 10e:	60a2                	ld	ra,8(sp)
 110:	6402                	ld	s0,0(sp)
 112:	0141                	addi	sp,sp,16
 114:	8082                	ret
  return 0;
 116:	4501                	li	a0,0
 118:	bfdd                	j	10e <strchr+0x1c>

000000000000011a <gets>:

char*
gets(char *buf, int max)
{
 11a:	711d                	addi	sp,sp,-96
 11c:	ec86                	sd	ra,88(sp)
 11e:	e8a2                	sd	s0,80(sp)
 120:	e4a6                	sd	s1,72(sp)
 122:	e0ca                	sd	s2,64(sp)
 124:	fc4e                	sd	s3,56(sp)
 126:	f852                	sd	s4,48(sp)
 128:	f456                	sd	s5,40(sp)
 12a:	f05a                	sd	s6,32(sp)
 12c:	ec5e                	sd	s7,24(sp)
 12e:	e862                	sd	s8,16(sp)
 130:	1080                	addi	s0,sp,96
 132:	8baa                	mv	s7,a0
 134:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 136:	892a                	mv	s2,a0
 138:	4481                	li	s1,0
    cc = read(0, &c, 1);
 13a:	faf40b13          	addi	s6,s0,-81
 13e:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 140:	8c26                	mv	s8,s1
 142:	0014899b          	addiw	s3,s1,1
 146:	84ce                	mv	s1,s3
 148:	0349d463          	bge	s3,s4,170 <gets+0x56>
    cc = read(0, &c, 1);
 14c:	8656                	mv	a2,s5
 14e:	85da                	mv	a1,s6
 150:	4501                	li	a0,0
 152:	190000ef          	jal	2e2 <read>
    if(cc < 1)
 156:	00a05d63          	blez	a0,170 <gets+0x56>
      break;
    buf[i++] = c;
 15a:	faf44783          	lbu	a5,-81(s0)
 15e:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 162:	0905                	addi	s2,s2,1
 164:	ff678713          	addi	a4,a5,-10
 168:	c319                	beqz	a4,16e <gets+0x54>
 16a:	17cd                	addi	a5,a5,-13
 16c:	fbf1                	bnez	a5,140 <gets+0x26>
    buf[i++] = c;
 16e:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 170:	9c5e                	add	s8,s8,s7
 172:	000c0023          	sb	zero,0(s8)
  return buf;
}
 176:	855e                	mv	a0,s7
 178:	60e6                	ld	ra,88(sp)
 17a:	6446                	ld	s0,80(sp)
 17c:	64a6                	ld	s1,72(sp)
 17e:	6906                	ld	s2,64(sp)
 180:	79e2                	ld	s3,56(sp)
 182:	7a42                	ld	s4,48(sp)
 184:	7aa2                	ld	s5,40(sp)
 186:	7b02                	ld	s6,32(sp)
 188:	6be2                	ld	s7,24(sp)
 18a:	6c42                	ld	s8,16(sp)
 18c:	6125                	addi	sp,sp,96
 18e:	8082                	ret

0000000000000190 <stat>:

int
stat(const char *n, struct stat *st)
{
 190:	1101                	addi	sp,sp,-32
 192:	ec06                	sd	ra,24(sp)
 194:	e822                	sd	s0,16(sp)
 196:	e04a                	sd	s2,0(sp)
 198:	1000                	addi	s0,sp,32
 19a:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 19c:	4581                	li	a1,0
 19e:	16c000ef          	jal	30a <open>
  if(fd < 0)
 1a2:	02054263          	bltz	a0,1c6 <stat+0x36>
 1a6:	e426                	sd	s1,8(sp)
 1a8:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 1aa:	85ca                	mv	a1,s2
 1ac:	176000ef          	jal	322 <fstat>
 1b0:	892a                	mv	s2,a0
  close(fd);
 1b2:	8526                	mv	a0,s1
 1b4:	13e000ef          	jal	2f2 <close>
  return r;
 1b8:	64a2                	ld	s1,8(sp)
}
 1ba:	854a                	mv	a0,s2
 1bc:	60e2                	ld	ra,24(sp)
 1be:	6442                	ld	s0,16(sp)
 1c0:	6902                	ld	s2,0(sp)
 1c2:	6105                	addi	sp,sp,32
 1c4:	8082                	ret
    return -1;
 1c6:	57fd                	li	a5,-1
 1c8:	893e                	mv	s2,a5
 1ca:	bfc5                	j	1ba <stat+0x2a>

00000000000001cc <atoi>:

int
atoi(const char *s)
{
 1cc:	1141                	addi	sp,sp,-16
 1ce:	e406                	sd	ra,8(sp)
 1d0:	e022                	sd	s0,0(sp)
 1d2:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1d4:	00054683          	lbu	a3,0(a0)
 1d8:	fd06879b          	addiw	a5,a3,-48
 1dc:	0ff7f793          	zext.b	a5,a5
 1e0:	4625                	li	a2,9
 1e2:	02f66963          	bltu	a2,a5,214 <atoi+0x48>
 1e6:	872a                	mv	a4,a0
  n = 0;
 1e8:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 1ea:	0705                	addi	a4,a4,1
 1ec:	0025179b          	slliw	a5,a0,0x2
 1f0:	9fa9                	addw	a5,a5,a0
 1f2:	0017979b          	slliw	a5,a5,0x1
 1f6:	9fb5                	addw	a5,a5,a3
 1f8:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1fc:	00074683          	lbu	a3,0(a4)
 200:	fd06879b          	addiw	a5,a3,-48
 204:	0ff7f793          	zext.b	a5,a5
 208:	fef671e3          	bgeu	a2,a5,1ea <atoi+0x1e>
  return n;
}
 20c:	60a2                	ld	ra,8(sp)
 20e:	6402                	ld	s0,0(sp)
 210:	0141                	addi	sp,sp,16
 212:	8082                	ret
  n = 0;
 214:	4501                	li	a0,0
 216:	bfdd                	j	20c <atoi+0x40>

0000000000000218 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 218:	1141                	addi	sp,sp,-16
 21a:	e406                	sd	ra,8(sp)
 21c:	e022                	sd	s0,0(sp)
 21e:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 220:	02b57563          	bgeu	a0,a1,24a <memmove+0x32>
    while(n-- > 0)
 224:	00c05f63          	blez	a2,242 <memmove+0x2a>
 228:	1602                	slli	a2,a2,0x20
 22a:	9201                	srli	a2,a2,0x20
 22c:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 230:	872a                	mv	a4,a0
      *dst++ = *src++;
 232:	0585                	addi	a1,a1,1
 234:	0705                	addi	a4,a4,1
 236:	fff5c683          	lbu	a3,-1(a1)
 23a:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 23e:	fee79ae3          	bne	a5,a4,232 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 242:	60a2                	ld	ra,8(sp)
 244:	6402                	ld	s0,0(sp)
 246:	0141                	addi	sp,sp,16
 248:	8082                	ret
    while(n-- > 0)
 24a:	fec05ce3          	blez	a2,242 <memmove+0x2a>
    dst += n;
 24e:	00c50733          	add	a4,a0,a2
    src += n;
 252:	95b2                	add	a1,a1,a2
 254:	fff6079b          	addiw	a5,a2,-1
 258:	1782                	slli	a5,a5,0x20
 25a:	9381                	srli	a5,a5,0x20
 25c:	fff7c793          	not	a5,a5
 260:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 262:	15fd                	addi	a1,a1,-1
 264:	177d                	addi	a4,a4,-1
 266:	0005c683          	lbu	a3,0(a1)
 26a:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 26e:	fef71ae3          	bne	a4,a5,262 <memmove+0x4a>
 272:	bfc1                	j	242 <memmove+0x2a>

0000000000000274 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 274:	1141                	addi	sp,sp,-16
 276:	e406                	sd	ra,8(sp)
 278:	e022                	sd	s0,0(sp)
 27a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 27c:	c61d                	beqz	a2,2aa <memcmp+0x36>
 27e:	1602                	slli	a2,a2,0x20
 280:	9201                	srli	a2,a2,0x20
 282:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 286:	00054783          	lbu	a5,0(a0)
 28a:	0005c703          	lbu	a4,0(a1)
 28e:	00e79863          	bne	a5,a4,29e <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 292:	0505                	addi	a0,a0,1
    p2++;
 294:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 296:	fed518e3          	bne	a0,a3,286 <memcmp+0x12>
  }
  return 0;
 29a:	4501                	li	a0,0
 29c:	a019                	j	2a2 <memcmp+0x2e>
      return *p1 - *p2;
 29e:	40e7853b          	subw	a0,a5,a4
}
 2a2:	60a2                	ld	ra,8(sp)
 2a4:	6402                	ld	s0,0(sp)
 2a6:	0141                	addi	sp,sp,16
 2a8:	8082                	ret
  return 0;
 2aa:	4501                	li	a0,0
 2ac:	bfdd                	j	2a2 <memcmp+0x2e>

00000000000002ae <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 2ae:	1141                	addi	sp,sp,-16
 2b0:	e406                	sd	ra,8(sp)
 2b2:	e022                	sd	s0,0(sp)
 2b4:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 2b6:	f63ff0ef          	jal	218 <memmove>
}
 2ba:	60a2                	ld	ra,8(sp)
 2bc:	6402                	ld	s0,0(sp)
 2be:	0141                	addi	sp,sp,16
 2c0:	8082                	ret

00000000000002c2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2c2:	4885                	li	a7,1
 ecall
 2c4:	00000073          	ecall
 ret
 2c8:	8082                	ret

00000000000002ca <exit>:
.global exit
exit:
 li a7, SYS_exit
 2ca:	4889                	li	a7,2
 ecall
 2cc:	00000073          	ecall
 ret
 2d0:	8082                	ret

00000000000002d2 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2d2:	488d                	li	a7,3
 ecall
 2d4:	00000073          	ecall
 ret
 2d8:	8082                	ret

00000000000002da <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2da:	4891                	li	a7,4
 ecall
 2dc:	00000073          	ecall
 ret
 2e0:	8082                	ret

00000000000002e2 <read>:
.global read
read:
 li a7, SYS_read
 2e2:	4895                	li	a7,5
 ecall
 2e4:	00000073          	ecall
 ret
 2e8:	8082                	ret

00000000000002ea <write>:
.global write
write:
 li a7, SYS_write
 2ea:	48c1                	li	a7,16
 ecall
 2ec:	00000073          	ecall
 ret
 2f0:	8082                	ret

00000000000002f2 <close>:
.global close
close:
 li a7, SYS_close
 2f2:	48d5                	li	a7,21
 ecall
 2f4:	00000073          	ecall
 ret
 2f8:	8082                	ret

00000000000002fa <kill>:
.global kill
kill:
 li a7, SYS_kill
 2fa:	4899                	li	a7,6
 ecall
 2fc:	00000073          	ecall
 ret
 300:	8082                	ret

0000000000000302 <exec>:
.global exec
exec:
 li a7, SYS_exec
 302:	489d                	li	a7,7
 ecall
 304:	00000073          	ecall
 ret
 308:	8082                	ret

000000000000030a <open>:
.global open
open:
 li a7, SYS_open
 30a:	48bd                	li	a7,15
 ecall
 30c:	00000073          	ecall
 ret
 310:	8082                	ret

0000000000000312 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 312:	48c5                	li	a7,17
 ecall
 314:	00000073          	ecall
 ret
 318:	8082                	ret

000000000000031a <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 31a:	48c9                	li	a7,18
 ecall
 31c:	00000073          	ecall
 ret
 320:	8082                	ret

0000000000000322 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 322:	48a1                	li	a7,8
 ecall
 324:	00000073          	ecall
 ret
 328:	8082                	ret

000000000000032a <link>:
.global link
link:
 li a7, SYS_link
 32a:	48cd                	li	a7,19
 ecall
 32c:	00000073          	ecall
 ret
 330:	8082                	ret

0000000000000332 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 332:	48d1                	li	a7,20
 ecall
 334:	00000073          	ecall
 ret
 338:	8082                	ret

000000000000033a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 33a:	48a5                	li	a7,9
 ecall
 33c:	00000073          	ecall
 ret
 340:	8082                	ret

0000000000000342 <dup>:
.global dup
dup:
 li a7, SYS_dup
 342:	48a9                	li	a7,10
 ecall
 344:	00000073          	ecall
 ret
 348:	8082                	ret

000000000000034a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 34a:	48ad                	li	a7,11
 ecall
 34c:	00000073          	ecall
 ret
 350:	8082                	ret

0000000000000352 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 352:	48b1                	li	a7,12
 ecall
 354:	00000073          	ecall
 ret
 358:	8082                	ret

000000000000035a <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 35a:	48b5                	li	a7,13
 ecall
 35c:	00000073          	ecall
 ret
 360:	8082                	ret

0000000000000362 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 362:	48b9                	li	a7,14
 ecall
 364:	00000073          	ecall
 ret
 368:	8082                	ret

000000000000036a <trace>:
.global trace
trace:
 li a7, SYS_trace
 36a:	48d9                	li	a7,22
 ecall
 36c:	00000073          	ecall
 ret
 370:	8082                	ret

0000000000000372 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 372:	1101                	addi	sp,sp,-32
 374:	ec06                	sd	ra,24(sp)
 376:	e822                	sd	s0,16(sp)
 378:	1000                	addi	s0,sp,32
 37a:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 37e:	4605                	li	a2,1
 380:	fef40593          	addi	a1,s0,-17
 384:	f67ff0ef          	jal	2ea <write>
}
 388:	60e2                	ld	ra,24(sp)
 38a:	6442                	ld	s0,16(sp)
 38c:	6105                	addi	sp,sp,32
 38e:	8082                	ret

0000000000000390 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 390:	7139                	addi	sp,sp,-64
 392:	fc06                	sd	ra,56(sp)
 394:	f822                	sd	s0,48(sp)
 396:	f04a                	sd	s2,32(sp)
 398:	ec4e                	sd	s3,24(sp)
 39a:	0080                	addi	s0,sp,64
 39c:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 39e:	cac9                	beqz	a3,430 <printint+0xa0>
 3a0:	01f5d79b          	srliw	a5,a1,0x1f
 3a4:	c7d1                	beqz	a5,430 <printint+0xa0>
    neg = 1;
    x = -xx;
 3a6:	40b005bb          	negw	a1,a1
    neg = 1;
 3aa:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 3ac:	fc040993          	addi	s3,s0,-64
  neg = 0;
 3b0:	86ce                	mv	a3,s3
  i = 0;
 3b2:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 3b4:	00000817          	auipc	a6,0x0
 3b8:	51480813          	addi	a6,a6,1300 # 8c8 <digits>
 3bc:	88ba                	mv	a7,a4
 3be:	0017051b          	addiw	a0,a4,1
 3c2:	872a                	mv	a4,a0
 3c4:	02c5f7bb          	remuw	a5,a1,a2
 3c8:	1782                	slli	a5,a5,0x20
 3ca:	9381                	srli	a5,a5,0x20
 3cc:	97c2                	add	a5,a5,a6
 3ce:	0007c783          	lbu	a5,0(a5)
 3d2:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 3d6:	87ae                	mv	a5,a1
 3d8:	02c5d5bb          	divuw	a1,a1,a2
 3dc:	0685                	addi	a3,a3,1
 3de:	fcc7ffe3          	bgeu	a5,a2,3bc <printint+0x2c>
  if(neg)
 3e2:	00030c63          	beqz	t1,3fa <printint+0x6a>
    buf[i++] = '-';
 3e6:	fd050793          	addi	a5,a0,-48
 3ea:	00878533          	add	a0,a5,s0
 3ee:	02d00793          	li	a5,45
 3f2:	fef50823          	sb	a5,-16(a0)
 3f6:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 3fa:	02e05563          	blez	a4,424 <printint+0x94>
 3fe:	f426                	sd	s1,40(sp)
 400:	377d                	addiw	a4,a4,-1
 402:	00e984b3          	add	s1,s3,a4
 406:	19fd                	addi	s3,s3,-1
 408:	99ba                	add	s3,s3,a4
 40a:	1702                	slli	a4,a4,0x20
 40c:	9301                	srli	a4,a4,0x20
 40e:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 412:	0004c583          	lbu	a1,0(s1)
 416:	854a                	mv	a0,s2
 418:	f5bff0ef          	jal	372 <putc>
  while(--i >= 0)
 41c:	14fd                	addi	s1,s1,-1
 41e:	ff349ae3          	bne	s1,s3,412 <printint+0x82>
 422:	74a2                	ld	s1,40(sp)
}
 424:	70e2                	ld	ra,56(sp)
 426:	7442                	ld	s0,48(sp)
 428:	7902                	ld	s2,32(sp)
 42a:	69e2                	ld	s3,24(sp)
 42c:	6121                	addi	sp,sp,64
 42e:	8082                	ret
  neg = 0;
 430:	4301                	li	t1,0
 432:	bfad                	j	3ac <printint+0x1c>

0000000000000434 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 434:	711d                	addi	sp,sp,-96
 436:	ec86                	sd	ra,88(sp)
 438:	e8a2                	sd	s0,80(sp)
 43a:	e4a6                	sd	s1,72(sp)
 43c:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 43e:	0005c483          	lbu	s1,0(a1)
 442:	20048963          	beqz	s1,654 <vprintf+0x220>
 446:	e0ca                	sd	s2,64(sp)
 448:	fc4e                	sd	s3,56(sp)
 44a:	f852                	sd	s4,48(sp)
 44c:	f456                	sd	s5,40(sp)
 44e:	f05a                	sd	s6,32(sp)
 450:	ec5e                	sd	s7,24(sp)
 452:	e862                	sd	s8,16(sp)
 454:	8b2a                	mv	s6,a0
 456:	8a2e                	mv	s4,a1
 458:	8bb2                	mv	s7,a2
  state = 0;
 45a:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 45c:	4901                	li	s2,0
 45e:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 460:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 464:	06400c13          	li	s8,100
 468:	a00d                	j	48a <vprintf+0x56>
        putc(fd, c0);
 46a:	85a6                	mv	a1,s1
 46c:	855a                	mv	a0,s6
 46e:	f05ff0ef          	jal	372 <putc>
 472:	a019                	j	478 <vprintf+0x44>
    } else if(state == '%'){
 474:	03598363          	beq	s3,s5,49a <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 478:	0019079b          	addiw	a5,s2,1
 47c:	893e                	mv	s2,a5
 47e:	873e                	mv	a4,a5
 480:	97d2                	add	a5,a5,s4
 482:	0007c483          	lbu	s1,0(a5)
 486:	1c048063          	beqz	s1,646 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 48a:	0004879b          	sext.w	a5,s1
    if(state == 0){
 48e:	fe0993e3          	bnez	s3,474 <vprintf+0x40>
      if(c0 == '%'){
 492:	fd579ce3          	bne	a5,s5,46a <vprintf+0x36>
        state = '%';
 496:	89be                	mv	s3,a5
 498:	b7c5                	j	478 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 49a:	00ea06b3          	add	a3,s4,a4
 49e:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 4a2:	1a060e63          	beqz	a2,65e <vprintf+0x22a>
      if(c0 == 'd'){
 4a6:	03878763          	beq	a5,s8,4d4 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 4aa:	f9478693          	addi	a3,a5,-108
 4ae:	0016b693          	seqz	a3,a3
 4b2:	f9c60593          	addi	a1,a2,-100
 4b6:	e99d                	bnez	a1,4ec <vprintf+0xb8>
 4b8:	ca95                	beqz	a3,4ec <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 4ba:	008b8493          	addi	s1,s7,8
 4be:	4685                	li	a3,1
 4c0:	4629                	li	a2,10
 4c2:	000ba583          	lw	a1,0(s7)
 4c6:	855a                	mv	a0,s6
 4c8:	ec9ff0ef          	jal	390 <printint>
        i += 1;
 4cc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 4ce:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 4d0:	4981                	li	s3,0
 4d2:	b75d                	j	478 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 4d4:	008b8493          	addi	s1,s7,8
 4d8:	4685                	li	a3,1
 4da:	4629                	li	a2,10
 4dc:	000ba583          	lw	a1,0(s7)
 4e0:	855a                	mv	a0,s6
 4e2:	eafff0ef          	jal	390 <printint>
 4e6:	8ba6                	mv	s7,s1
      state = 0;
 4e8:	4981                	li	s3,0
 4ea:	b779                	j	478 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 4ec:	9752                	add	a4,a4,s4
 4ee:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4f2:	f9460713          	addi	a4,a2,-108
 4f6:	00173713          	seqz	a4,a4
 4fa:	8f75                	and	a4,a4,a3
 4fc:	f9c58513          	addi	a0,a1,-100
 500:	16051963          	bnez	a0,672 <vprintf+0x23e>
 504:	16070763          	beqz	a4,672 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 508:	008b8493          	addi	s1,s7,8
 50c:	4685                	li	a3,1
 50e:	4629                	li	a2,10
 510:	000ba583          	lw	a1,0(s7)
 514:	855a                	mv	a0,s6
 516:	e7bff0ef          	jal	390 <printint>
        i += 2;
 51a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 51c:	8ba6                	mv	s7,s1
      state = 0;
 51e:	4981                	li	s3,0
        i += 2;
 520:	bfa1                	j	478 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 522:	008b8493          	addi	s1,s7,8
 526:	4681                	li	a3,0
 528:	4629                	li	a2,10
 52a:	000ba583          	lw	a1,0(s7)
 52e:	855a                	mv	a0,s6
 530:	e61ff0ef          	jal	390 <printint>
 534:	8ba6                	mv	s7,s1
      state = 0;
 536:	4981                	li	s3,0
 538:	b781                	j	478 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 53a:	008b8493          	addi	s1,s7,8
 53e:	4681                	li	a3,0
 540:	4629                	li	a2,10
 542:	000ba583          	lw	a1,0(s7)
 546:	855a                	mv	a0,s6
 548:	e49ff0ef          	jal	390 <printint>
        i += 1;
 54c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 54e:	8ba6                	mv	s7,s1
      state = 0;
 550:	4981                	li	s3,0
 552:	b71d                	j	478 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 554:	008b8493          	addi	s1,s7,8
 558:	4681                	li	a3,0
 55a:	4629                	li	a2,10
 55c:	000ba583          	lw	a1,0(s7)
 560:	855a                	mv	a0,s6
 562:	e2fff0ef          	jal	390 <printint>
        i += 2;
 566:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 568:	8ba6                	mv	s7,s1
      state = 0;
 56a:	4981                	li	s3,0
        i += 2;
 56c:	b731                	j	478 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 56e:	008b8493          	addi	s1,s7,8
 572:	4681                	li	a3,0
 574:	4641                	li	a2,16
 576:	000ba583          	lw	a1,0(s7)
 57a:	855a                	mv	a0,s6
 57c:	e15ff0ef          	jal	390 <printint>
 580:	8ba6                	mv	s7,s1
      state = 0;
 582:	4981                	li	s3,0
 584:	bdd5                	j	478 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 586:	008b8493          	addi	s1,s7,8
 58a:	4681                	li	a3,0
 58c:	4641                	li	a2,16
 58e:	000ba583          	lw	a1,0(s7)
 592:	855a                	mv	a0,s6
 594:	dfdff0ef          	jal	390 <printint>
        i += 1;
 598:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 59a:	8ba6                	mv	s7,s1
      state = 0;
 59c:	4981                	li	s3,0
 59e:	bde9                	j	478 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5a0:	008b8493          	addi	s1,s7,8
 5a4:	4681                	li	a3,0
 5a6:	4641                	li	a2,16
 5a8:	000ba583          	lw	a1,0(s7)
 5ac:	855a                	mv	a0,s6
 5ae:	de3ff0ef          	jal	390 <printint>
        i += 2;
 5b2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 5b4:	8ba6                	mv	s7,s1
      state = 0;
 5b6:	4981                	li	s3,0
        i += 2;
 5b8:	b5c1                	j	478 <vprintf+0x44>
 5ba:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 5bc:	008b8793          	addi	a5,s7,8
 5c0:	8cbe                	mv	s9,a5
 5c2:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 5c6:	03000593          	li	a1,48
 5ca:	855a                	mv	a0,s6
 5cc:	da7ff0ef          	jal	372 <putc>
  putc(fd, 'x');
 5d0:	07800593          	li	a1,120
 5d4:	855a                	mv	a0,s6
 5d6:	d9dff0ef          	jal	372 <putc>
 5da:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5dc:	00000b97          	auipc	s7,0x0
 5e0:	2ecb8b93          	addi	s7,s7,748 # 8c8 <digits>
 5e4:	03c9d793          	srli	a5,s3,0x3c
 5e8:	97de                	add	a5,a5,s7
 5ea:	0007c583          	lbu	a1,0(a5)
 5ee:	855a                	mv	a0,s6
 5f0:	d83ff0ef          	jal	372 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 5f4:	0992                	slli	s3,s3,0x4
 5f6:	34fd                	addiw	s1,s1,-1
 5f8:	f4f5                	bnez	s1,5e4 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 5fa:	8be6                	mv	s7,s9
      state = 0;
 5fc:	4981                	li	s3,0
 5fe:	6ca2                	ld	s9,8(sp)
 600:	bda5                	j	478 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 602:	008b8993          	addi	s3,s7,8
 606:	000bb483          	ld	s1,0(s7)
 60a:	cc91                	beqz	s1,626 <vprintf+0x1f2>
        for(; *s; s++)
 60c:	0004c583          	lbu	a1,0(s1)
 610:	c985                	beqz	a1,640 <vprintf+0x20c>
          putc(fd, *s);
 612:	855a                	mv	a0,s6
 614:	d5fff0ef          	jal	372 <putc>
        for(; *s; s++)
 618:	0485                	addi	s1,s1,1
 61a:	0004c583          	lbu	a1,0(s1)
 61e:	f9f5                	bnez	a1,612 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 620:	8bce                	mv	s7,s3
      state = 0;
 622:	4981                	li	s3,0
 624:	bd91                	j	478 <vprintf+0x44>
          s = "(null)";
 626:	00000497          	auipc	s1,0x0
 62a:	29a48493          	addi	s1,s1,666 # 8c0 <malloc+0x106>
        for(; *s; s++)
 62e:	02800593          	li	a1,40
 632:	b7c5                	j	612 <vprintf+0x1de>
        putc(fd, '%');
 634:	85be                	mv	a1,a5
 636:	855a                	mv	a0,s6
 638:	d3bff0ef          	jal	372 <putc>
      state = 0;
 63c:	4981                	li	s3,0
 63e:	bd2d                	j	478 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 640:	8bce                	mv	s7,s3
      state = 0;
 642:	4981                	li	s3,0
 644:	bd15                	j	478 <vprintf+0x44>
 646:	6906                	ld	s2,64(sp)
 648:	79e2                	ld	s3,56(sp)
 64a:	7a42                	ld	s4,48(sp)
 64c:	7aa2                	ld	s5,40(sp)
 64e:	7b02                	ld	s6,32(sp)
 650:	6be2                	ld	s7,24(sp)
 652:	6c42                	ld	s8,16(sp)
    }
  }
}
 654:	60e6                	ld	ra,88(sp)
 656:	6446                	ld	s0,80(sp)
 658:	64a6                	ld	s1,72(sp)
 65a:	6125                	addi	sp,sp,96
 65c:	8082                	ret
      if(c0 == 'd'){
 65e:	06400713          	li	a4,100
 662:	e6e789e3          	beq	a5,a4,4d4 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 666:	f9478693          	addi	a3,a5,-108
 66a:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 66e:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 670:	4701                	li	a4,0
      } else if(c0 == 'u'){
 672:	07500513          	li	a0,117
 676:	eaa786e3          	beq	a5,a0,522 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 67a:	f8b60513          	addi	a0,a2,-117
 67e:	e119                	bnez	a0,684 <vprintf+0x250>
 680:	ea069de3          	bnez	a3,53a <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 684:	f8b58513          	addi	a0,a1,-117
 688:	e119                	bnez	a0,68e <vprintf+0x25a>
 68a:	ec0715e3          	bnez	a4,554 <vprintf+0x120>
      } else if(c0 == 'x'){
 68e:	07800513          	li	a0,120
 692:	eca78ee3          	beq	a5,a0,56e <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 696:	f8860613          	addi	a2,a2,-120
 69a:	e219                	bnez	a2,6a0 <vprintf+0x26c>
 69c:	ee0695e3          	bnez	a3,586 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6a0:	f8858593          	addi	a1,a1,-120
 6a4:	e199                	bnez	a1,6aa <vprintf+0x276>
 6a6:	ee071de3          	bnez	a4,5a0 <vprintf+0x16c>
      } else if(c0 == 'p'){
 6aa:	07000713          	li	a4,112
 6ae:	f0e786e3          	beq	a5,a4,5ba <vprintf+0x186>
      } else if(c0 == 's'){
 6b2:	07300713          	li	a4,115
 6b6:	f4e786e3          	beq	a5,a4,602 <vprintf+0x1ce>
      } else if(c0 == '%'){
 6ba:	02500713          	li	a4,37
 6be:	f6e78be3          	beq	a5,a4,634 <vprintf+0x200>
        putc(fd, '%');
 6c2:	02500593          	li	a1,37
 6c6:	855a                	mv	a0,s6
 6c8:	cabff0ef          	jal	372 <putc>
        putc(fd, c0);
 6cc:	85a6                	mv	a1,s1
 6ce:	855a                	mv	a0,s6
 6d0:	ca3ff0ef          	jal	372 <putc>
      state = 0;
 6d4:	4981                	li	s3,0
 6d6:	b34d                	j	478 <vprintf+0x44>

00000000000006d8 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6d8:	715d                	addi	sp,sp,-80
 6da:	ec06                	sd	ra,24(sp)
 6dc:	e822                	sd	s0,16(sp)
 6de:	1000                	addi	s0,sp,32
 6e0:	e010                	sd	a2,0(s0)
 6e2:	e414                	sd	a3,8(s0)
 6e4:	e818                	sd	a4,16(s0)
 6e6:	ec1c                	sd	a5,24(s0)
 6e8:	03043023          	sd	a6,32(s0)
 6ec:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6f0:	8622                	mv	a2,s0
 6f2:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 6f6:	d3fff0ef          	jal	434 <vprintf>
}
 6fa:	60e2                	ld	ra,24(sp)
 6fc:	6442                	ld	s0,16(sp)
 6fe:	6161                	addi	sp,sp,80
 700:	8082                	ret

0000000000000702 <printf>:

void
printf(const char *fmt, ...)
{
 702:	711d                	addi	sp,sp,-96
 704:	ec06                	sd	ra,24(sp)
 706:	e822                	sd	s0,16(sp)
 708:	1000                	addi	s0,sp,32
 70a:	e40c                	sd	a1,8(s0)
 70c:	e810                	sd	a2,16(s0)
 70e:	ec14                	sd	a3,24(s0)
 710:	f018                	sd	a4,32(s0)
 712:	f41c                	sd	a5,40(s0)
 714:	03043823          	sd	a6,48(s0)
 718:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 71c:	00840613          	addi	a2,s0,8
 720:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 724:	85aa                	mv	a1,a0
 726:	4505                	li	a0,1
 728:	d0dff0ef          	jal	434 <vprintf>
}
 72c:	60e2                	ld	ra,24(sp)
 72e:	6442                	ld	s0,16(sp)
 730:	6125                	addi	sp,sp,96
 732:	8082                	ret

0000000000000734 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 734:	1141                	addi	sp,sp,-16
 736:	e406                	sd	ra,8(sp)
 738:	e022                	sd	s0,0(sp)
 73a:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 73c:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 740:	00001797          	auipc	a5,0x1
 744:	8c07b783          	ld	a5,-1856(a5) # 1000 <freep>
 748:	a039                	j	756 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 74a:	6398                	ld	a4,0(a5)
 74c:	00e7e463          	bltu	a5,a4,754 <free+0x20>
 750:	00e6ea63          	bltu	a3,a4,764 <free+0x30>
{
 754:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 756:	fed7fae3          	bgeu	a5,a3,74a <free+0x16>
 75a:	6398                	ld	a4,0(a5)
 75c:	00e6e463          	bltu	a3,a4,764 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 760:	fee7eae3          	bltu	a5,a4,754 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 764:	ff852583          	lw	a1,-8(a0)
 768:	6390                	ld	a2,0(a5)
 76a:	02059813          	slli	a6,a1,0x20
 76e:	01c85713          	srli	a4,a6,0x1c
 772:	9736                	add	a4,a4,a3
 774:	02e60563          	beq	a2,a4,79e <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 778:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 77c:	4790                	lw	a2,8(a5)
 77e:	02061593          	slli	a1,a2,0x20
 782:	01c5d713          	srli	a4,a1,0x1c
 786:	973e                	add	a4,a4,a5
 788:	02e68263          	beq	a3,a4,7ac <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 78c:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 78e:	00001717          	auipc	a4,0x1
 792:	86f73923          	sd	a5,-1934(a4) # 1000 <freep>
}
 796:	60a2                	ld	ra,8(sp)
 798:	6402                	ld	s0,0(sp)
 79a:	0141                	addi	sp,sp,16
 79c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 79e:	4618                	lw	a4,8(a2)
 7a0:	9f2d                	addw	a4,a4,a1
 7a2:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 7a6:	6398                	ld	a4,0(a5)
 7a8:	6310                	ld	a2,0(a4)
 7aa:	b7f9                	j	778 <free+0x44>
    p->s.size += bp->s.size;
 7ac:	ff852703          	lw	a4,-8(a0)
 7b0:	9f31                	addw	a4,a4,a2
 7b2:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 7b4:	ff053683          	ld	a3,-16(a0)
 7b8:	bfd1                	j	78c <free+0x58>

00000000000007ba <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7ba:	7139                	addi	sp,sp,-64
 7bc:	fc06                	sd	ra,56(sp)
 7be:	f822                	sd	s0,48(sp)
 7c0:	f04a                	sd	s2,32(sp)
 7c2:	ec4e                	sd	s3,24(sp)
 7c4:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7c6:	02051993          	slli	s3,a0,0x20
 7ca:	0209d993          	srli	s3,s3,0x20
 7ce:	09bd                	addi	s3,s3,15
 7d0:	0049d993          	srli	s3,s3,0x4
 7d4:	2985                	addiw	s3,s3,1
 7d6:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7d8:	00001517          	auipc	a0,0x1
 7dc:	82853503          	ld	a0,-2008(a0) # 1000 <freep>
 7e0:	c905                	beqz	a0,810 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7e2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7e4:	4798                	lw	a4,8(a5)
 7e6:	09377663          	bgeu	a4,s3,872 <malloc+0xb8>
 7ea:	f426                	sd	s1,40(sp)
 7ec:	e852                	sd	s4,16(sp)
 7ee:	e456                	sd	s5,8(sp)
 7f0:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 7f2:	8a4e                	mv	s4,s3
 7f4:	6705                	lui	a4,0x1
 7f6:	00e9f363          	bgeu	s3,a4,7fc <malloc+0x42>
 7fa:	6a05                	lui	s4,0x1
 7fc:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 800:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 804:	00000497          	auipc	s1,0x0
 808:	7fc48493          	addi	s1,s1,2044 # 1000 <freep>
  if(p == (char*)-1)
 80c:	5afd                	li	s5,-1
 80e:	a83d                	j	84c <malloc+0x92>
 810:	f426                	sd	s1,40(sp)
 812:	e852                	sd	s4,16(sp)
 814:	e456                	sd	s5,8(sp)
 816:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 818:	00000797          	auipc	a5,0x0
 81c:	7f878793          	addi	a5,a5,2040 # 1010 <base>
 820:	00000717          	auipc	a4,0x0
 824:	7ef73023          	sd	a5,2016(a4) # 1000 <freep>
 828:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 82a:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 82e:	b7d1                	j	7f2 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 830:	6398                	ld	a4,0(a5)
 832:	e118                	sd	a4,0(a0)
 834:	a899                	j	88a <malloc+0xd0>
  hp->s.size = nu;
 836:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 83a:	0541                	addi	a0,a0,16
 83c:	ef9ff0ef          	jal	734 <free>
  return freep;
 840:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 842:	c125                	beqz	a0,8a2 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 844:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 846:	4798                	lw	a4,8(a5)
 848:	03277163          	bgeu	a4,s2,86a <malloc+0xb0>
    if(p == freep)
 84c:	6098                	ld	a4,0(s1)
 84e:	853e                	mv	a0,a5
 850:	fef71ae3          	bne	a4,a5,844 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 854:	8552                	mv	a0,s4
 856:	afdff0ef          	jal	352 <sbrk>
  if(p == (char*)-1)
 85a:	fd551ee3          	bne	a0,s5,836 <malloc+0x7c>
        return 0;
 85e:	4501                	li	a0,0
 860:	74a2                	ld	s1,40(sp)
 862:	6a42                	ld	s4,16(sp)
 864:	6aa2                	ld	s5,8(sp)
 866:	6b02                	ld	s6,0(sp)
 868:	a03d                	j	896 <malloc+0xdc>
 86a:	74a2                	ld	s1,40(sp)
 86c:	6a42                	ld	s4,16(sp)
 86e:	6aa2                	ld	s5,8(sp)
 870:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 872:	fae90fe3          	beq	s2,a4,830 <malloc+0x76>
        p->s.size -= nunits;
 876:	4137073b          	subw	a4,a4,s3
 87a:	c798                	sw	a4,8(a5)
        p += p->s.size;
 87c:	02071693          	slli	a3,a4,0x20
 880:	01c6d713          	srli	a4,a3,0x1c
 884:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 886:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 88a:	00000717          	auipc	a4,0x0
 88e:	76a73b23          	sd	a0,1910(a4) # 1000 <freep>
      return (void*)(p + 1);
 892:	01078513          	addi	a0,a5,16
  }
}
 896:	70e2                	ld	ra,56(sp)
 898:	7442                	ld	s0,48(sp)
 89a:	7902                	ld	s2,32(sp)
 89c:	69e2                	ld	s3,24(sp)
 89e:	6121                	addi	sp,sp,64
 8a0:	8082                	ret
 8a2:	74a2                	ld	s1,40(sp)
 8a4:	6a42                	ld	s4,16(sp)
 8a6:	6aa2                	ld	s5,8(sp)
 8a8:	6b02                	ld	s6,0(sp)
 8aa:	b7f5                	j	896 <malloc+0xdc>
