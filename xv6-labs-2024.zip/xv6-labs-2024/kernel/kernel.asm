
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00019117          	auipc	sp,0x19
    80000004:	de010113          	addi	sp,sp,-544 # 80018de0 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	711040ef          	jal	80004f26 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	00021797          	auipc	a5,0x21
    8000002c:	eb878793          	addi	a5,a5,-328 # 80020ee0 <end>
    80000030:	00f53733          	sltu	a4,a0,a5
    80000034:	47c5                	li	a5,17
    80000036:	07ee                	slli	a5,a5,0x1b
    80000038:	17fd                	addi	a5,a5,-1
    8000003a:	00a7b7b3          	sltu	a5,a5,a0
    8000003e:	8fd9                	or	a5,a5,a4
    80000040:	ef95                	bnez	a5,8000007c <kfree+0x60>
    80000042:	84aa                	mv	s1,a0
    80000044:	03451793          	slli	a5,a0,0x34
    80000048:	eb95                	bnez	a5,8000007c <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    8000004a:	6605                	lui	a2,0x1
    8000004c:	4585                	li	a1,1
    8000004e:	110000ef          	jal	8000015e <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000052:	00008917          	auipc	s2,0x8
    80000056:	95e90913          	addi	s2,s2,-1698 # 800079b0 <kmem>
    8000005a:	854a                	mv	a0,s2
    8000005c:	181050ef          	jal	800059dc <acquire>
  r->next = kmem.freelist;
    80000060:	01893783          	ld	a5,24(s2)
    80000064:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000066:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    8000006a:	854a                	mv	a0,s2
    8000006c:	205050ef          	jal	80005a70 <release>
}
    80000070:	60e2                	ld	ra,24(sp)
    80000072:	6442                	ld	s0,16(sp)
    80000074:	64a2                	ld	s1,8(sp)
    80000076:	6902                	ld	s2,0(sp)
    80000078:	6105                	addi	sp,sp,32
    8000007a:	8082                	ret
    panic("kfree");
    8000007c:	00007517          	auipc	a0,0x7
    80000080:	f8450513          	addi	a0,a0,-124 # 80007000 <etext>
    80000084:	61a050ef          	jal	8000569e <panic>

0000000080000088 <freerange>:
{
    80000088:	7179                	addi	sp,sp,-48
    8000008a:	f406                	sd	ra,40(sp)
    8000008c:	f022                	sd	s0,32(sp)
    8000008e:	ec26                	sd	s1,24(sp)
    80000090:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000092:	6785                	lui	a5,0x1
    80000094:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000098:	00e504b3          	add	s1,a0,a4
    8000009c:	777d                	lui	a4,0xfffff
    8000009e:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000a0:	94be                	add	s1,s1,a5
    800000a2:	0295e263          	bltu	a1,s1,800000c6 <freerange+0x3e>
    800000a6:	e84a                	sd	s2,16(sp)
    800000a8:	e44e                	sd	s3,8(sp)
    800000aa:	e052                	sd	s4,0(sp)
    800000ac:	892e                	mv	s2,a1
    kfree(p);
    800000ae:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000b0:	89be                	mv	s3,a5
    kfree(p);
    800000b2:	01448533          	add	a0,s1,s4
    800000b6:	f67ff0ef          	jal	8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000ba:	94ce                	add	s1,s1,s3
    800000bc:	fe997be3          	bgeu	s2,s1,800000b2 <freerange+0x2a>
    800000c0:	6942                	ld	s2,16(sp)
    800000c2:	69a2                	ld	s3,8(sp)
    800000c4:	6a02                	ld	s4,0(sp)
}
    800000c6:	70a2                	ld	ra,40(sp)
    800000c8:	7402                	ld	s0,32(sp)
    800000ca:	64e2                	ld	s1,24(sp)
    800000cc:	6145                	addi	sp,sp,48
    800000ce:	8082                	ret

00000000800000d0 <kinit>:
{
    800000d0:	1141                	addi	sp,sp,-16
    800000d2:	e406                	sd	ra,8(sp)
    800000d4:	e022                	sd	s0,0(sp)
    800000d6:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d8:	00007597          	auipc	a1,0x7
    800000dc:	f3858593          	addi	a1,a1,-200 # 80007010 <etext+0x10>
    800000e0:	00008517          	auipc	a0,0x8
    800000e4:	8d050513          	addi	a0,a0,-1840 # 800079b0 <kmem>
    800000e8:	06b050ef          	jal	80005952 <initlock>
  freerange(end, (void*)PHYSTOP);
    800000ec:	45c5                	li	a1,17
    800000ee:	05ee                	slli	a1,a1,0x1b
    800000f0:	00021517          	auipc	a0,0x21
    800000f4:	df050513          	addi	a0,a0,-528 # 80020ee0 <end>
    800000f8:	f91ff0ef          	jal	80000088 <freerange>
}
    800000fc:	60a2                	ld	ra,8(sp)
    800000fe:	6402                	ld	s0,0(sp)
    80000100:	0141                	addi	sp,sp,16
    80000102:	8082                	ret

0000000080000104 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000104:	1101                	addi	sp,sp,-32
    80000106:	ec06                	sd	ra,24(sp)
    80000108:	e822                	sd	s0,16(sp)
    8000010a:	e426                	sd	s1,8(sp)
    8000010c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    8000010e:	00008517          	auipc	a0,0x8
    80000112:	8a250513          	addi	a0,a0,-1886 # 800079b0 <kmem>
    80000116:	0c7050ef          	jal	800059dc <acquire>
  r = kmem.freelist;
    8000011a:	00008497          	auipc	s1,0x8
    8000011e:	8ae4b483          	ld	s1,-1874(s1) # 800079c8 <kmem+0x18>
  if(r)
    80000122:	c49d                	beqz	s1,80000150 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000124:	609c                	ld	a5,0(s1)
    80000126:	00008717          	auipc	a4,0x8
    8000012a:	8af73123          	sd	a5,-1886(a4) # 800079c8 <kmem+0x18>
  release(&kmem.lock);
    8000012e:	00008517          	auipc	a0,0x8
    80000132:	88250513          	addi	a0,a0,-1918 # 800079b0 <kmem>
    80000136:	13b050ef          	jal	80005a70 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    8000013a:	6605                	lui	a2,0x1
    8000013c:	4595                	li	a1,5
    8000013e:	8526                	mv	a0,s1
    80000140:	01e000ef          	jal	8000015e <memset>
  return (void*)r;
}
    80000144:	8526                	mv	a0,s1
    80000146:	60e2                	ld	ra,24(sp)
    80000148:	6442                	ld	s0,16(sp)
    8000014a:	64a2                	ld	s1,8(sp)
    8000014c:	6105                	addi	sp,sp,32
    8000014e:	8082                	ret
  release(&kmem.lock);
    80000150:	00008517          	auipc	a0,0x8
    80000154:	86050513          	addi	a0,a0,-1952 # 800079b0 <kmem>
    80000158:	119050ef          	jal	80005a70 <release>
  if(r)
    8000015c:	b7e5                	j	80000144 <kalloc+0x40>

000000008000015e <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000015e:	1141                	addi	sp,sp,-16
    80000160:	e406                	sd	ra,8(sp)
    80000162:	e022                	sd	s0,0(sp)
    80000164:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000166:	ca19                	beqz	a2,8000017c <memset+0x1e>
    80000168:	87aa                	mv	a5,a0
    8000016a:	1602                	slli	a2,a2,0x20
    8000016c:	9201                	srli	a2,a2,0x20
    8000016e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000172:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000176:	0785                	addi	a5,a5,1
    80000178:	fee79de3          	bne	a5,a4,80000172 <memset+0x14>
  }
  return dst;
}
    8000017c:	60a2                	ld	ra,8(sp)
    8000017e:	6402                	ld	s0,0(sp)
    80000180:	0141                	addi	sp,sp,16
    80000182:	8082                	ret

0000000080000184 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000184:	1141                	addi	sp,sp,-16
    80000186:	e406                	sd	ra,8(sp)
    80000188:	e022                	sd	s0,0(sp)
    8000018a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    8000018c:	c61d                	beqz	a2,800001ba <memcmp+0x36>
    8000018e:	1602                	slli	a2,a2,0x20
    80000190:	9201                	srli	a2,a2,0x20
    80000192:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000196:	00054783          	lbu	a5,0(a0)
    8000019a:	0005c703          	lbu	a4,0(a1)
    8000019e:	00e79863          	bne	a5,a4,800001ae <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    800001a2:	0505                	addi	a0,a0,1
    800001a4:	0585                	addi	a1,a1,1
  while(n-- > 0){
    800001a6:	fed518e3          	bne	a0,a3,80000196 <memcmp+0x12>
  }

  return 0;
    800001aa:	4501                	li	a0,0
    800001ac:	a019                	j	800001b2 <memcmp+0x2e>
      return *s1 - *s2;
    800001ae:	40e7853b          	subw	a0,a5,a4
}
    800001b2:	60a2                	ld	ra,8(sp)
    800001b4:	6402                	ld	s0,0(sp)
    800001b6:	0141                	addi	sp,sp,16
    800001b8:	8082                	ret
  return 0;
    800001ba:	4501                	li	a0,0
    800001bc:	bfdd                	j	800001b2 <memcmp+0x2e>

00000000800001be <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001be:	1141                	addi	sp,sp,-16
    800001c0:	e406                	sd	ra,8(sp)
    800001c2:	e022                	sd	s0,0(sp)
    800001c4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001c6:	c205                	beqz	a2,800001e6 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001c8:	02a5e363          	bltu	a1,a0,800001ee <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001cc:	1602                	slli	a2,a2,0x20
    800001ce:	9201                	srli	a2,a2,0x20
    800001d0:	00c587b3          	add	a5,a1,a2
{
    800001d4:	872a                	mv	a4,a0
      *d++ = *s++;
    800001d6:	0585                	addi	a1,a1,1
    800001d8:	0705                	addi	a4,a4,1
    800001da:	fff5c683          	lbu	a3,-1(a1)
    800001de:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001e2:	feb79ae3          	bne	a5,a1,800001d6 <memmove+0x18>

  return dst;
}
    800001e6:	60a2                	ld	ra,8(sp)
    800001e8:	6402                	ld	s0,0(sp)
    800001ea:	0141                	addi	sp,sp,16
    800001ec:	8082                	ret
  if(s < d && s + n > d){
    800001ee:	02061693          	slli	a3,a2,0x20
    800001f2:	9281                	srli	a3,a3,0x20
    800001f4:	00d58733          	add	a4,a1,a3
    800001f8:	fce57ae3          	bgeu	a0,a4,800001cc <memmove+0xe>
    d += n;
    800001fc:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001fe:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000202:	1782                	slli	a5,a5,0x20
    80000204:	9381                	srli	a5,a5,0x20
    80000206:	fff7c793          	not	a5,a5
    8000020a:	97ba                	add	a5,a5,a4
      *--d = *--s;
    8000020c:	177d                	addi	a4,a4,-1
    8000020e:	16fd                	addi	a3,a3,-1
    80000210:	00074603          	lbu	a2,0(a4)
    80000214:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000218:	fee79ae3          	bne	a5,a4,8000020c <memmove+0x4e>
    8000021c:	b7e9                	j	800001e6 <memmove+0x28>

000000008000021e <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    8000021e:	1141                	addi	sp,sp,-16
    80000220:	e406                	sd	ra,8(sp)
    80000222:	e022                	sd	s0,0(sp)
    80000224:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000226:	f99ff0ef          	jal	800001be <memmove>
}
    8000022a:	60a2                	ld	ra,8(sp)
    8000022c:	6402                	ld	s0,0(sp)
    8000022e:	0141                	addi	sp,sp,16
    80000230:	8082                	ret

0000000080000232 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000232:	1141                	addi	sp,sp,-16
    80000234:	e406                	sd	ra,8(sp)
    80000236:	e022                	sd	s0,0(sp)
    80000238:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000023a:	ce11                	beqz	a2,80000256 <strncmp+0x24>
    8000023c:	00054783          	lbu	a5,0(a0)
    80000240:	cf89                	beqz	a5,8000025a <strncmp+0x28>
    80000242:	0005c703          	lbu	a4,0(a1)
    80000246:	00f71a63          	bne	a4,a5,8000025a <strncmp+0x28>
    n--, p++, q++;
    8000024a:	367d                	addiw	a2,a2,-1
    8000024c:	0505                	addi	a0,a0,1
    8000024e:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000250:	f675                	bnez	a2,8000023c <strncmp+0xa>
  if(n == 0)
    return 0;
    80000252:	4501                	li	a0,0
    80000254:	a801                	j	80000264 <strncmp+0x32>
    80000256:	4501                	li	a0,0
    80000258:	a031                	j	80000264 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    8000025a:	00054503          	lbu	a0,0(a0)
    8000025e:	0005c783          	lbu	a5,0(a1)
    80000262:	9d1d                	subw	a0,a0,a5
}
    80000264:	60a2                	ld	ra,8(sp)
    80000266:	6402                	ld	s0,0(sp)
    80000268:	0141                	addi	sp,sp,16
    8000026a:	8082                	ret

000000008000026c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    8000026c:	1141                	addi	sp,sp,-16
    8000026e:	e406                	sd	ra,8(sp)
    80000270:	e022                	sd	s0,0(sp)
    80000272:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000274:	87aa                	mv	a5,a0
    80000276:	a011                	j	8000027a <strncpy+0xe>
    80000278:	8636                	mv	a2,a3
    8000027a:	02c05863          	blez	a2,800002aa <strncpy+0x3e>
    8000027e:	fff6069b          	addiw	a3,a2,-1
    80000282:	8836                	mv	a6,a3
    80000284:	0785                	addi	a5,a5,1
    80000286:	0005c703          	lbu	a4,0(a1)
    8000028a:	fee78fa3          	sb	a4,-1(a5)
    8000028e:	0585                	addi	a1,a1,1
    80000290:	f765                	bnez	a4,80000278 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000292:	873e                	mv	a4,a5
    80000294:	01005b63          	blez	a6,800002aa <strncpy+0x3e>
    80000298:	9fb1                	addw	a5,a5,a2
    8000029a:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    8000029c:	0705                	addi	a4,a4,1
    8000029e:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    800002a2:	40e786bb          	subw	a3,a5,a4
    800002a6:	fed04be3          	bgtz	a3,8000029c <strncpy+0x30>
  return os;
}
    800002aa:	60a2                	ld	ra,8(sp)
    800002ac:	6402                	ld	s0,0(sp)
    800002ae:	0141                	addi	sp,sp,16
    800002b0:	8082                	ret

00000000800002b2 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    800002b2:	1141                	addi	sp,sp,-16
    800002b4:	e406                	sd	ra,8(sp)
    800002b6:	e022                	sd	s0,0(sp)
    800002b8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    800002ba:	02c05363          	blez	a2,800002e0 <safestrcpy+0x2e>
    800002be:	fff6069b          	addiw	a3,a2,-1
    800002c2:	1682                	slli	a3,a3,0x20
    800002c4:	9281                	srli	a3,a3,0x20
    800002c6:	96ae                	add	a3,a3,a1
    800002c8:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002ca:	00d58963          	beq	a1,a3,800002dc <safestrcpy+0x2a>
    800002ce:	0585                	addi	a1,a1,1
    800002d0:	0785                	addi	a5,a5,1
    800002d2:	fff5c703          	lbu	a4,-1(a1)
    800002d6:	fee78fa3          	sb	a4,-1(a5)
    800002da:	fb65                	bnez	a4,800002ca <safestrcpy+0x18>
    ;
  *s = 0;
    800002dc:	00078023          	sb	zero,0(a5)
  return os;
}
    800002e0:	60a2                	ld	ra,8(sp)
    800002e2:	6402                	ld	s0,0(sp)
    800002e4:	0141                	addi	sp,sp,16
    800002e6:	8082                	ret

00000000800002e8 <strlen>:

int
strlen(const char *s)
{
    800002e8:	1141                	addi	sp,sp,-16
    800002ea:	e406                	sd	ra,8(sp)
    800002ec:	e022                	sd	s0,0(sp)
    800002ee:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002f0:	00054783          	lbu	a5,0(a0)
    800002f4:	cf91                	beqz	a5,80000310 <strlen+0x28>
    800002f6:	00150793          	addi	a5,a0,1
    800002fa:	86be                	mv	a3,a5
    800002fc:	0785                	addi	a5,a5,1
    800002fe:	fff7c703          	lbu	a4,-1(a5)
    80000302:	ff65                	bnez	a4,800002fa <strlen+0x12>
    80000304:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000308:	60a2                	ld	ra,8(sp)
    8000030a:	6402                	ld	s0,0(sp)
    8000030c:	0141                	addi	sp,sp,16
    8000030e:	8082                	ret
  for(n = 0; s[n]; n++)
    80000310:	4501                	li	a0,0
    80000312:	bfdd                	j	80000308 <strlen+0x20>

0000000080000314 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000314:	1141                	addi	sp,sp,-16
    80000316:	e406                	sd	ra,8(sp)
    80000318:	e022                	sd	s0,0(sp)
    8000031a:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    8000031c:	367000ef          	jal	80000e82 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000320:	00007717          	auipc	a4,0x7
    80000324:	66070713          	addi	a4,a4,1632 # 80007980 <started>
  if(cpuid() == 0){
    80000328:	c51d                	beqz	a0,80000356 <main+0x42>
    while(started == 0)
    8000032a:	431c                	lw	a5,0(a4)
    8000032c:	2781                	sext.w	a5,a5
    8000032e:	dff5                	beqz	a5,8000032a <main+0x16>
      ;
    __sync_synchronize();
    80000330:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000334:	34f000ef          	jal	80000e82 <cpuid>
    80000338:	85aa                	mv	a1,a0
    8000033a:	00007517          	auipc	a0,0x7
    8000033e:	cfe50513          	addi	a0,a0,-770 # 80007038 <etext+0x38>
    80000342:	04c050ef          	jal	8000538e <printf>
    kvminithart();    // turn on paging
    80000346:	156000ef          	jal	8000049c <kvminithart>
    trapinithart();   // install kernel trap vector
    8000034a:	6e2010ef          	jal	80001a2c <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    8000034e:	61a040ef          	jal	80004968 <plicinithart>
  }

  scheduler();        
    80000352:	01e010ef          	jal	80001370 <scheduler>
    consoleinit();
    80000356:	75f040ef          	jal	800052b4 <consoleinit>
    printfinit();
    8000035a:	37e050ef          	jal	800056d8 <printfinit>
    printf("\n");
    8000035e:	00007517          	auipc	a0,0x7
    80000362:	cba50513          	addi	a0,a0,-838 # 80007018 <etext+0x18>
    80000366:	028050ef          	jal	8000538e <printf>
    printf("xv6 kernel is booting\n");
    8000036a:	00007517          	auipc	a0,0x7
    8000036e:	cb650513          	addi	a0,a0,-842 # 80007020 <etext+0x20>
    80000372:	01c050ef          	jal	8000538e <printf>
    printf("\n");
    80000376:	00007517          	auipc	a0,0x7
    8000037a:	ca250513          	addi	a0,a0,-862 # 80007018 <etext+0x18>
    8000037e:	010050ef          	jal	8000538e <printf>
    kinit();         // physical page allocator
    80000382:	d4fff0ef          	jal	800000d0 <kinit>
    kvminit();       // create kernel page table
    80000386:	3b0000ef          	jal	80000736 <kvminit>
    kvminithart();   // turn on paging
    8000038a:	112000ef          	jal	8000049c <kvminithart>
    procinit();      // process table
    8000038e:	241000ef          	jal	80000dce <procinit>
    trapinit();      // trap vectors
    80000392:	676010ef          	jal	80001a08 <trapinit>
    trapinithart();  // install kernel trap vector
    80000396:	696010ef          	jal	80001a2c <trapinithart>
    plicinit();      // set up interrupt controller
    8000039a:	5b4040ef          	jal	8000494e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    8000039e:	5ca040ef          	jal	80004968 <plicinithart>
    binit();         // buffer cache
    800003a2:	51b010ef          	jal	800020bc <binit>
    iinit();         // inode table
    800003a6:	2d6020ef          	jal	8000267c <iinit>
    fileinit();      // file table
    800003aa:	0bc030ef          	jal	80003466 <fileinit>
    virtio_disk_init(); // emulated hard disk
    800003ae:	6aa040ef          	jal	80004a58 <virtio_disk_init>
    userinit();      // first user process
    800003b2:	5f3000ef          	jal	800011a4 <userinit>
    __sync_synchronize();
    800003b6:	0330000f          	fence	rw,rw
    started = 1;
    800003ba:	4785                	li	a5,1
    800003bc:	00007717          	auipc	a4,0x7
    800003c0:	5cf72223          	sw	a5,1476(a4) # 80007980 <started>
    800003c4:	b779                	j	80000352 <main+0x3e>

00000000800003c6 <vmprint_walk>:
    return va;
}

static void
vmprint_walk(pagetable_t pagetable, int level, int indent)
{
    800003c6:	7119                	addi	sp,sp,-128
    800003c8:	fc86                	sd	ra,120(sp)
    800003ca:	f8a2                	sd	s0,112(sp)
    800003cc:	f4a6                	sd	s1,104(sp)
    800003ce:	f0ca                	sd	s2,96(sp)
    800003d0:	ecce                	sd	s3,88(sp)
    800003d2:	e8d2                	sd	s4,80(sp)
    800003d4:	e4d6                	sd	s5,72(sp)
    800003d6:	e0da                	sd	s6,64(sp)
    800003d8:	fc5e                	sd	s7,56(sp)
    800003da:	f862                	sd	s8,48(sp)
    800003dc:	f466                	sd	s9,40(sp)
    800003de:	f06a                	sd	s10,32(sp)
    800003e0:	ec6e                	sd	s11,24(sp)
    800003e2:	0100                	addi	s0,sp,128
    800003e4:	f8b43023          	sd	a1,-128(s0)
    800003e8:	8ab2                	mv	s5,a2
    uint64 va = (uint64)index << (12 + 9*level);
    800003ea:	00359d1b          	slliw	s10,a1,0x3
    800003ee:	00bd0d3b          	addw	s10,s10,a1
    800003f2:	2d31                	addiw	s10,s10,12
    800003f4:	8a2a                	mv	s4,a0
    800003f6:	4981                	li	s3,0
    if (va & (1ULL << 38)) {
    800003f8:	4d85                	li	s11,1
    800003fa:	1d9a                	slli	s11,s11,0x26
        if(pte & PTE_V){
            uint64 pa = PTE2PA(pte);
            uint64 va = va_from_index(level, i);

            for(int d = 0; d < indent; d++)
                printf(" ..");
    800003fc:	00007b17          	auipc	s6,0x7
    80000400:	c54b0b13          	addi	s6,s6,-940 # 80007050 <etext+0x50>
        va |= ~((1ULL << 39) - 1); // set high bits to 1
    80000404:	57fd                	li	a5,-1
    80000406:	179e                	slli	a5,a5,0x27
    80000408:	f8f43423          	sd	a5,-120(s0)
    for(int i = 0; i < 512; i++){
    8000040c:	20000c93          	li	s9,512
    80000410:	a81d                	j	80000446 <vmprint_walk+0x80>
            for(int d = 0; d < indent; d++)
    80000412:	01505963          	blez	s5,80000424 <vmprint_walk+0x5e>
    80000416:	4481                	li	s1,0
                printf(" ..");
    80000418:	855a                	mv	a0,s6
    8000041a:	775040ef          	jal	8000538e <printf>
            for(int d = 0; d < indent; d++)
    8000041e:	2485                	addiw	s1,s1,1
    80000420:	fe9a9ce3          	bne	s5,s1,80000418 <vmprint_walk+0x52>

            printf("%p: pte %p pa %p\n", (void*)va, (void*)(uint64)pte, (void*)pa);
    80000424:	86de                	mv	a3,s7
    80000426:	864a                	mv	a2,s2
    80000428:	85e2                	mv	a1,s8
    8000042a:	00007517          	auipc	a0,0x7
    8000042e:	c2e50513          	addi	a0,a0,-978 # 80007058 <etext+0x58>
    80000432:	75d040ef          	jal	8000538e <printf>

            // 如果不是叶子节点（没有 R/W/X 权限），说明是下一级页表
            if((pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000436:	00e97913          	andi	s2,s2,14
    8000043a:	02090863          	beqz	s2,8000046a <vmprint_walk+0xa4>
    for(int i = 0; i < 512; i++){
    8000043e:	0985                	addi	s3,s3,1
    80000440:	0a21                	addi	s4,s4,8
    80000442:	03998e63          	beq	s3,s9,8000047e <vmprint_walk+0xb8>
        pte_t pte = pte_array[i];
    80000446:	000a3903          	ld	s2,0(s4)
        if(pte & PTE_V){
    8000044a:	00197793          	andi	a5,s2,1
    8000044e:	dbe5                	beqz	a5,8000043e <vmprint_walk+0x78>
            uint64 pa = PTE2PA(pte);
    80000450:	00a95b93          	srli	s7,s2,0xa
    80000454:	0bb2                	slli	s7,s7,0xc
    uint64 va = (uint64)index << (12 + 9*level);
    80000456:	01a99c33          	sll	s8,s3,s10
    if (va & (1ULL << 38)) {
    8000045a:	01bc77b3          	and	a5,s8,s11
    8000045e:	dbd5                	beqz	a5,80000412 <vmprint_walk+0x4c>
        va |= ~((1ULL << 39) - 1); // set high bits to 1
    80000460:	f8843783          	ld	a5,-120(s0)
    80000464:	00fc6c33          	or	s8,s8,a5
    80000468:	b76d                	j	80000412 <vmprint_walk+0x4c>
                pagetable_t next = (pagetable_t)pa;
                vmprint_walk(next, level-1, indent+1);
    8000046a:	001a861b          	addiw	a2,s5,1
    8000046e:	f8043783          	ld	a5,-128(s0)
    80000472:	fff7859b          	addiw	a1,a5,-1
    80000476:	855e                	mv	a0,s7
    80000478:	f4fff0ef          	jal	800003c6 <vmprint_walk>
    8000047c:	b7c9                	j	8000043e <vmprint_walk+0x78>
            }
        }
    }
}
    8000047e:	70e6                	ld	ra,120(sp)
    80000480:	7446                	ld	s0,112(sp)
    80000482:	74a6                	ld	s1,104(sp)
    80000484:	7906                	ld	s2,96(sp)
    80000486:	69e6                	ld	s3,88(sp)
    80000488:	6a46                	ld	s4,80(sp)
    8000048a:	6aa6                	ld	s5,72(sp)
    8000048c:	6b06                	ld	s6,64(sp)
    8000048e:	7be2                	ld	s7,56(sp)
    80000490:	7c42                	ld	s8,48(sp)
    80000492:	7ca2                	ld	s9,40(sp)
    80000494:	7d02                	ld	s10,32(sp)
    80000496:	6de2                	ld	s11,24(sp)
    80000498:	6109                	addi	sp,sp,128
    8000049a:	8082                	ret

000000008000049c <kvminithart>:
{
    8000049c:	1141                	addi	sp,sp,-16
    8000049e:	e406                	sd	ra,8(sp)
    800004a0:	e022                	sd	s0,0(sp)
    800004a2:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800004a4:	12000073          	sfence.vma
  w_satp(MAKE_SATP(kernel_pagetable));
    800004a8:	00007797          	auipc	a5,0x7
    800004ac:	4e07b783          	ld	a5,1248(a5) # 80007988 <kernel_pagetable>
    800004b0:	83b1                	srli	a5,a5,0xc
    800004b2:	577d                	li	a4,-1
    800004b4:	177e                	slli	a4,a4,0x3f
    800004b6:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800004b8:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800004bc:	12000073          	sfence.vma
}
    800004c0:	60a2                	ld	ra,8(sp)
    800004c2:	6402                	ld	s0,0(sp)
    800004c4:	0141                	addi	sp,sp,16
    800004c6:	8082                	ret

00000000800004c8 <walk>:
{
    800004c8:	7139                	addi	sp,sp,-64
    800004ca:	fc06                	sd	ra,56(sp)
    800004cc:	f822                	sd	s0,48(sp)
    800004ce:	f426                	sd	s1,40(sp)
    800004d0:	f04a                	sd	s2,32(sp)
    800004d2:	ec4e                	sd	s3,24(sp)
    800004d4:	e852                	sd	s4,16(sp)
    800004d6:	e456                	sd	s5,8(sp)
    800004d8:	e05a                	sd	s6,0(sp)
    800004da:	0080                	addi	s0,sp,64
    800004dc:	84aa                	mv	s1,a0
    800004de:	89ae                	mv	s3,a1
    800004e0:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    800004e2:	57fd                	li	a5,-1
    800004e4:	83e9                	srli	a5,a5,0x1a
    800004e6:	4a79                	li	s4,30
  for(int level = 2; level > 0; level--) {
    800004e8:	4ab1                	li	s5,12
  if(va >= MAXVA)
    800004ea:	04b7e763          	bltu	a5,a1,80000538 <walk+0x70>
    pte_t *pte = &pagetable[PX(level, va)];
    800004ee:	0149d933          	srl	s2,s3,s4
    800004f2:	1ff97913          	andi	s2,s2,511
    800004f6:	090e                	slli	s2,s2,0x3
    800004f8:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    800004fa:	00093483          	ld	s1,0(s2)
    800004fe:	0014f793          	andi	a5,s1,1
    80000502:	c3a9                	beqz	a5,80000544 <walk+0x7c>
      if(PTE_LEAF(*pte)) {
    80000504:	00e4f793          	andi	a5,s1,14
    80000508:	ef89                	bnez	a5,80000522 <walk+0x5a>
      pagetable = (pagetable_t)PTE2PA(*pte);
    8000050a:	80a9                	srli	s1,s1,0xa
    8000050c:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    8000050e:	3a5d                	addiw	s4,s4,-9
    80000510:	fd5a1fe3          	bne	s4,s5,800004ee <walk+0x26>
  return &pagetable[PX(0, va)];
    80000514:	00c9d993          	srli	s3,s3,0xc
    80000518:	1ff9f993          	andi	s3,s3,511
    8000051c:	098e                	slli	s3,s3,0x3
    8000051e:	01348933          	add	s2,s1,s3
}
    80000522:	854a                	mv	a0,s2
    80000524:	70e2                	ld	ra,56(sp)
    80000526:	7442                	ld	s0,48(sp)
    80000528:	74a2                	ld	s1,40(sp)
    8000052a:	7902                	ld	s2,32(sp)
    8000052c:	69e2                	ld	s3,24(sp)
    8000052e:	6a42                	ld	s4,16(sp)
    80000530:	6aa2                	ld	s5,8(sp)
    80000532:	6b02                	ld	s6,0(sp)
    80000534:	6121                	addi	sp,sp,64
    80000536:	8082                	ret
    panic("walk");
    80000538:	00007517          	auipc	a0,0x7
    8000053c:	b3850513          	addi	a0,a0,-1224 # 80007070 <etext+0x70>
    80000540:	15e050ef          	jal	8000569e <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000544:	020b0263          	beqz	s6,80000568 <walk+0xa0>
    80000548:	bbdff0ef          	jal	80000104 <kalloc>
    8000054c:	84aa                	mv	s1,a0
    8000054e:	cd19                	beqz	a0,8000056c <walk+0xa4>
      memset(pagetable, 0, PGSIZE);
    80000550:	6605                	lui	a2,0x1
    80000552:	4581                	li	a1,0
    80000554:	c0bff0ef          	jal	8000015e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000558:	00c4d793          	srli	a5,s1,0xc
    8000055c:	07aa                	slli	a5,a5,0xa
    8000055e:	0017e793          	ori	a5,a5,1
    80000562:	00f93023          	sd	a5,0(s2)
    80000566:	b765                	j	8000050e <walk+0x46>
        return 0;
    80000568:	4901                	li	s2,0
    8000056a:	bf65                	j	80000522 <walk+0x5a>
    8000056c:	892a                	mv	s2,a0
    8000056e:	bf55                	j	80000522 <walk+0x5a>

0000000080000570 <walkaddr>:
  if(va >= MAXVA)
    80000570:	57fd                	li	a5,-1
    80000572:	83e9                	srli	a5,a5,0x1a
    80000574:	00b7f463          	bgeu	a5,a1,8000057c <walkaddr+0xc>
    return 0;
    80000578:	4501                	li	a0,0
}
    8000057a:	8082                	ret
{
    8000057c:	1141                	addi	sp,sp,-16
    8000057e:	e406                	sd	ra,8(sp)
    80000580:	e022                	sd	s0,0(sp)
    80000582:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000584:	4601                	li	a2,0
    80000586:	f43ff0ef          	jal	800004c8 <walk>
  if(pte == 0)
    8000058a:	c901                	beqz	a0,8000059a <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    8000058c:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000058e:	0117f693          	andi	a3,a5,17
    80000592:	4745                	li	a4,17
    return 0;
    80000594:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000596:	00e68663          	beq	a3,a4,800005a2 <walkaddr+0x32>
}
    8000059a:	60a2                	ld	ra,8(sp)
    8000059c:	6402                	ld	s0,0(sp)
    8000059e:	0141                	addi	sp,sp,16
    800005a0:	8082                	ret
  pa = PTE2PA(*pte);
    800005a2:	83a9                	srli	a5,a5,0xa
    800005a4:	00c79513          	slli	a0,a5,0xc
  return pa;
    800005a8:	bfcd                	j	8000059a <walkaddr+0x2a>

00000000800005aa <mappages>:
{
    800005aa:	715d                	addi	sp,sp,-80
    800005ac:	e486                	sd	ra,72(sp)
    800005ae:	e0a2                	sd	s0,64(sp)
    800005b0:	fc26                	sd	s1,56(sp)
    800005b2:	f84a                	sd	s2,48(sp)
    800005b4:	f44e                	sd	s3,40(sp)
    800005b6:	f052                	sd	s4,32(sp)
    800005b8:	ec56                	sd	s5,24(sp)
    800005ba:	e85a                	sd	s6,16(sp)
    800005bc:	e45e                	sd	s7,8(sp)
    800005be:	0880                	addi	s0,sp,80
  if((va % PGSIZE) != 0)
    800005c0:	03459793          	slli	a5,a1,0x34
    800005c4:	eba1                	bnez	a5,80000614 <mappages+0x6a>
    800005c6:	8a2a                	mv	s4,a0
    800005c8:	8aba                	mv	s5,a4
  if((size % PGSIZE) != 0)
    800005ca:	03461793          	slli	a5,a2,0x34
    800005ce:	eba9                	bnez	a5,80000620 <mappages+0x76>
  if(size == 0)
    800005d0:	ce31                	beqz	a2,8000062c <mappages+0x82>
  last = va + size - PGSIZE;
    800005d2:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    800005d6:	80060613          	addi	a2,a2,-2048
    800005da:	00b60933          	add	s2,a2,a1
  a = va;
    800005de:	84ae                	mv	s1,a1
    if((pte = walk(pagetable, a, 1)) == 0)
    800005e0:	4b05                	li	s6,1
    800005e2:	40b689b3          	sub	s3,a3,a1
    a += PGSIZE;
    800005e6:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    800005e8:	865a                	mv	a2,s6
    800005ea:	85a6                	mv	a1,s1
    800005ec:	8552                	mv	a0,s4
    800005ee:	edbff0ef          	jal	800004c8 <walk>
    800005f2:	c929                	beqz	a0,80000644 <mappages+0x9a>
    if(*pte & PTE_V)
    800005f4:	611c                	ld	a5,0(a0)
    800005f6:	8b85                	andi	a5,a5,1
    800005f8:	e3a1                	bnez	a5,80000638 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800005fa:	013487b3          	add	a5,s1,s3
    800005fe:	83b1                	srli	a5,a5,0xc
    80000600:	07aa                	slli	a5,a5,0xa
    80000602:	0157e7b3          	or	a5,a5,s5
    80000606:	0017e793          	ori	a5,a5,1
    8000060a:	e11c                	sd	a5,0(a0)
    if(a == last)
    8000060c:	05248863          	beq	s1,s2,8000065c <mappages+0xb2>
    a += PGSIZE;
    80000610:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80000612:	bfd9                	j	800005e8 <mappages+0x3e>
    panic("mappages: va not aligned");
    80000614:	00007517          	auipc	a0,0x7
    80000618:	a6450513          	addi	a0,a0,-1436 # 80007078 <etext+0x78>
    8000061c:	082050ef          	jal	8000569e <panic>
    panic("mappages: size not aligned");
    80000620:	00007517          	auipc	a0,0x7
    80000624:	a7850513          	addi	a0,a0,-1416 # 80007098 <etext+0x98>
    80000628:	076050ef          	jal	8000569e <panic>
    panic("mappages: size");
    8000062c:	00007517          	auipc	a0,0x7
    80000630:	a8c50513          	addi	a0,a0,-1396 # 800070b8 <etext+0xb8>
    80000634:	06a050ef          	jal	8000569e <panic>
      panic("mappages: remap");
    80000638:	00007517          	auipc	a0,0x7
    8000063c:	a9050513          	addi	a0,a0,-1392 # 800070c8 <etext+0xc8>
    80000640:	05e050ef          	jal	8000569e <panic>
      return -1;
    80000644:	557d                	li	a0,-1
}
    80000646:	60a6                	ld	ra,72(sp)
    80000648:	6406                	ld	s0,64(sp)
    8000064a:	74e2                	ld	s1,56(sp)
    8000064c:	7942                	ld	s2,48(sp)
    8000064e:	79a2                	ld	s3,40(sp)
    80000650:	7a02                	ld	s4,32(sp)
    80000652:	6ae2                	ld	s5,24(sp)
    80000654:	6b42                	ld	s6,16(sp)
    80000656:	6ba2                	ld	s7,8(sp)
    80000658:	6161                	addi	sp,sp,80
    8000065a:	8082                	ret
  return 0;
    8000065c:	4501                	li	a0,0
    8000065e:	b7e5                	j	80000646 <mappages+0x9c>

0000000080000660 <kvmmap>:
{
    80000660:	1141                	addi	sp,sp,-16
    80000662:	e406                	sd	ra,8(sp)
    80000664:	e022                	sd	s0,0(sp)
    80000666:	0800                	addi	s0,sp,16
    80000668:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    8000066a:	86b2                	mv	a3,a2
    8000066c:	863e                	mv	a2,a5
    8000066e:	f3dff0ef          	jal	800005aa <mappages>
    80000672:	e509                	bnez	a0,8000067c <kvmmap+0x1c>
}
    80000674:	60a2                	ld	ra,8(sp)
    80000676:	6402                	ld	s0,0(sp)
    80000678:	0141                	addi	sp,sp,16
    8000067a:	8082                	ret
    panic("kvmmap");
    8000067c:	00007517          	auipc	a0,0x7
    80000680:	a5c50513          	addi	a0,a0,-1444 # 800070d8 <etext+0xd8>
    80000684:	01a050ef          	jal	8000569e <panic>

0000000080000688 <kvmmake>:
{
    80000688:	1101                	addi	sp,sp,-32
    8000068a:	ec06                	sd	ra,24(sp)
    8000068c:	e822                	sd	s0,16(sp)
    8000068e:	e426                	sd	s1,8(sp)
    80000690:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80000692:	a73ff0ef          	jal	80000104 <kalloc>
    80000696:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80000698:	6605                	lui	a2,0x1
    8000069a:	4581                	li	a1,0
    8000069c:	ac3ff0ef          	jal	8000015e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800006a0:	4719                	li	a4,6
    800006a2:	6685                	lui	a3,0x1
    800006a4:	10000637          	lui	a2,0x10000
    800006a8:	85b2                	mv	a1,a2
    800006aa:	8526                	mv	a0,s1
    800006ac:	fb5ff0ef          	jal	80000660 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800006b0:	4719                	li	a4,6
    800006b2:	6685                	lui	a3,0x1
    800006b4:	10001637          	lui	a2,0x10001
    800006b8:	85b2                	mv	a1,a2
    800006ba:	8526                	mv	a0,s1
    800006bc:	fa5ff0ef          	jal	80000660 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800006c0:	4719                	li	a4,6
    800006c2:	040006b7          	lui	a3,0x4000
    800006c6:	0c000637          	lui	a2,0xc000
    800006ca:	85b2                	mv	a1,a2
    800006cc:	8526                	mv	a0,s1
    800006ce:	f93ff0ef          	jal	80000660 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800006d2:	4729                	li	a4,10
    800006d4:	80007697          	auipc	a3,0x80007
    800006d8:	92c68693          	addi	a3,a3,-1748 # 7000 <_entry-0x7fff9000>
    800006dc:	4605                	li	a2,1
    800006de:	067e                	slli	a2,a2,0x1f
    800006e0:	85b2                	mv	a1,a2
    800006e2:	8526                	mv	a0,s1
    800006e4:	f7dff0ef          	jal	80000660 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800006e8:	4719                	li	a4,6
    800006ea:	00007697          	auipc	a3,0x7
    800006ee:	91668693          	addi	a3,a3,-1770 # 80007000 <etext>
    800006f2:	47c5                	li	a5,17
    800006f4:	07ee                	slli	a5,a5,0x1b
    800006f6:	40d786b3          	sub	a3,a5,a3
    800006fa:	00007617          	auipc	a2,0x7
    800006fe:	90660613          	addi	a2,a2,-1786 # 80007000 <etext>
    80000702:	85b2                	mv	a1,a2
    80000704:	8526                	mv	a0,s1
    80000706:	f5bff0ef          	jal	80000660 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000070a:	4729                	li	a4,10
    8000070c:	6685                	lui	a3,0x1
    8000070e:	00006617          	auipc	a2,0x6
    80000712:	8f260613          	addi	a2,a2,-1806 # 80006000 <_trampoline>
    80000716:	040005b7          	lui	a1,0x4000
    8000071a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000071c:	05b2                	slli	a1,a1,0xc
    8000071e:	8526                	mv	a0,s1
    80000720:	f41ff0ef          	jal	80000660 <kvmmap>
  proc_mapstacks(kpgtbl);
    80000724:	8526                	mv	a0,s1
    80000726:	606000ef          	jal	80000d2c <proc_mapstacks>
}
    8000072a:	8526                	mv	a0,s1
    8000072c:	60e2                	ld	ra,24(sp)
    8000072e:	6442                	ld	s0,16(sp)
    80000730:	64a2                	ld	s1,8(sp)
    80000732:	6105                	addi	sp,sp,32
    80000734:	8082                	ret

0000000080000736 <kvminit>:
{
    80000736:	1141                	addi	sp,sp,-16
    80000738:	e406                	sd	ra,8(sp)
    8000073a:	e022                	sd	s0,0(sp)
    8000073c:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000073e:	f4bff0ef          	jal	80000688 <kvmmake>
    80000742:	00007797          	auipc	a5,0x7
    80000746:	24a7b323          	sd	a0,582(a5) # 80007988 <kernel_pagetable>
}
    8000074a:	60a2                	ld	ra,8(sp)
    8000074c:	6402                	ld	s0,0(sp)
    8000074e:	0141                	addi	sp,sp,16
    80000750:	8082                	ret

0000000080000752 <uvmunmap>:
{
    80000752:	715d                	addi	sp,sp,-80
    80000754:	e486                	sd	ra,72(sp)
    80000756:	e0a2                	sd	s0,64(sp)
    80000758:	0880                	addi	s0,sp,80
  if((va % PGSIZE) != 0)
    8000075a:	03459793          	slli	a5,a1,0x34
    8000075e:	e39d                	bnez	a5,80000784 <uvmunmap+0x32>
    80000760:	f84a                	sd	s2,48(sp)
    80000762:	f44e                	sd	s3,40(sp)
    80000764:	f052                	sd	s4,32(sp)
    80000766:	ec56                	sd	s5,24(sp)
    80000768:	e85a                	sd	s6,16(sp)
    8000076a:	e45e                	sd	s7,8(sp)
    8000076c:	8a2a                	mv	s4,a0
    8000076e:	892e                	mv	s2,a1
    80000770:	8ab6                	mv	s5,a3
  for(a = va; a < va + npages*PGSIZE; a += sz){
    80000772:	0632                	slli	a2,a2,0xc
    80000774:	00b609b3          	add	s3,a2,a1
    if(PTE_FLAGS(*pte) == PTE_V)
    80000778:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += sz){
    8000077a:	6b05                	lui	s6,0x1
    8000077c:	0935f763          	bgeu	a1,s3,8000080a <uvmunmap+0xb8>
    80000780:	fc26                	sd	s1,56(sp)
    80000782:	a8a1                	j	800007da <uvmunmap+0x88>
    80000784:	fc26                	sd	s1,56(sp)
    80000786:	f84a                	sd	s2,48(sp)
    80000788:	f44e                	sd	s3,40(sp)
    8000078a:	f052                	sd	s4,32(sp)
    8000078c:	ec56                	sd	s5,24(sp)
    8000078e:	e85a                	sd	s6,16(sp)
    80000790:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    80000792:	00007517          	auipc	a0,0x7
    80000796:	94e50513          	addi	a0,a0,-1714 # 800070e0 <etext+0xe0>
    8000079a:	705040ef          	jal	8000569e <panic>
      panic("uvmunmap: walk");
    8000079e:	00007517          	auipc	a0,0x7
    800007a2:	95a50513          	addi	a0,a0,-1702 # 800070f8 <etext+0xf8>
    800007a6:	6f9040ef          	jal	8000569e <panic>
      printf("va=%ld pte=%ld\n", a, *pte);
    800007aa:	85ca                	mv	a1,s2
    800007ac:	00007517          	auipc	a0,0x7
    800007b0:	95c50513          	addi	a0,a0,-1700 # 80007108 <etext+0x108>
    800007b4:	3db040ef          	jal	8000538e <printf>
      panic("uvmunmap: not mapped");
    800007b8:	00007517          	auipc	a0,0x7
    800007bc:	96050513          	addi	a0,a0,-1696 # 80007118 <etext+0x118>
    800007c0:	6df040ef          	jal	8000569e <panic>
      panic("uvmunmap: not a leaf");
    800007c4:	00007517          	auipc	a0,0x7
    800007c8:	96c50513          	addi	a0,a0,-1684 # 80007130 <etext+0x130>
    800007cc:	6d3040ef          	jal	8000569e <panic>
    *pte = 0;
    800007d0:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += sz){
    800007d4:	995a                	add	s2,s2,s6
    800007d6:	03397963          	bgeu	s2,s3,80000808 <uvmunmap+0xb6>
    if((pte = walk(pagetable, a, 0)) == 0)
    800007da:	4601                	li	a2,0
    800007dc:	85ca                	mv	a1,s2
    800007de:	8552                	mv	a0,s4
    800007e0:	ce9ff0ef          	jal	800004c8 <walk>
    800007e4:	84aa                	mv	s1,a0
    800007e6:	dd45                	beqz	a0,8000079e <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0) {
    800007e8:	6110                	ld	a2,0(a0)
    800007ea:	00167793          	andi	a5,a2,1
    800007ee:	dfd5                	beqz	a5,800007aa <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    800007f0:	3ff67793          	andi	a5,a2,1023
    800007f4:	fd7788e3          	beq	a5,s7,800007c4 <uvmunmap+0x72>
    if(do_free){
    800007f8:	fc0a8ce3          	beqz	s5,800007d0 <uvmunmap+0x7e>
      uint64 pa = PTE2PA(*pte);
    800007fc:	8229                	srli	a2,a2,0xa
      kfree((void*)pa);
    800007fe:	00c61513          	slli	a0,a2,0xc
    80000802:	81bff0ef          	jal	8000001c <kfree>
    80000806:	b7e9                	j	800007d0 <uvmunmap+0x7e>
    80000808:	74e2                	ld	s1,56(sp)
    8000080a:	7942                	ld	s2,48(sp)
    8000080c:	79a2                	ld	s3,40(sp)
    8000080e:	7a02                	ld	s4,32(sp)
    80000810:	6ae2                	ld	s5,24(sp)
    80000812:	6b42                	ld	s6,16(sp)
    80000814:	6ba2                	ld	s7,8(sp)
}
    80000816:	60a6                	ld	ra,72(sp)
    80000818:	6406                	ld	s0,64(sp)
    8000081a:	6161                	addi	sp,sp,80
    8000081c:	8082                	ret

000000008000081e <uvmcreate>:
{
    8000081e:	1101                	addi	sp,sp,-32
    80000820:	ec06                	sd	ra,24(sp)
    80000822:	e822                	sd	s0,16(sp)
    80000824:	e426                	sd	s1,8(sp)
    80000826:	1000                	addi	s0,sp,32
  pagetable = (pagetable_t) kalloc();
    80000828:	8ddff0ef          	jal	80000104 <kalloc>
    8000082c:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000082e:	c509                	beqz	a0,80000838 <uvmcreate+0x1a>
  memset(pagetable, 0, PGSIZE);
    80000830:	6605                	lui	a2,0x1
    80000832:	4581                	li	a1,0
    80000834:	92bff0ef          	jal	8000015e <memset>
}
    80000838:	8526                	mv	a0,s1
    8000083a:	60e2                	ld	ra,24(sp)
    8000083c:	6442                	ld	s0,16(sp)
    8000083e:	64a2                	ld	s1,8(sp)
    80000840:	6105                	addi	sp,sp,32
    80000842:	8082                	ret

0000000080000844 <uvmfirst>:
{
    80000844:	7179                	addi	sp,sp,-48
    80000846:	f406                	sd	ra,40(sp)
    80000848:	f022                	sd	s0,32(sp)
    8000084a:	ec26                	sd	s1,24(sp)
    8000084c:	e84a                	sd	s2,16(sp)
    8000084e:	e44e                	sd	s3,8(sp)
    80000850:	e052                	sd	s4,0(sp)
    80000852:	1800                	addi	s0,sp,48
  if(sz >= PGSIZE)
    80000854:	6785                	lui	a5,0x1
    80000856:	04f67063          	bgeu	a2,a5,80000896 <uvmfirst+0x52>
    8000085a:	89aa                	mv	s3,a0
    8000085c:	8a2e                	mv	s4,a1
    8000085e:	84b2                	mv	s1,a2
  mem = kalloc();
    80000860:	8a5ff0ef          	jal	80000104 <kalloc>
    80000864:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000866:	6605                	lui	a2,0x1
    80000868:	4581                	li	a1,0
    8000086a:	8f5ff0ef          	jal	8000015e <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    8000086e:	4779                	li	a4,30
    80000870:	86ca                	mv	a3,s2
    80000872:	6605                	lui	a2,0x1
    80000874:	4581                	li	a1,0
    80000876:	854e                	mv	a0,s3
    80000878:	d33ff0ef          	jal	800005aa <mappages>
  memmove(mem, src, sz);
    8000087c:	8626                	mv	a2,s1
    8000087e:	85d2                	mv	a1,s4
    80000880:	854a                	mv	a0,s2
    80000882:	93dff0ef          	jal	800001be <memmove>
}
    80000886:	70a2                	ld	ra,40(sp)
    80000888:	7402                	ld	s0,32(sp)
    8000088a:	64e2                	ld	s1,24(sp)
    8000088c:	6942                	ld	s2,16(sp)
    8000088e:	69a2                	ld	s3,8(sp)
    80000890:	6a02                	ld	s4,0(sp)
    80000892:	6145                	addi	sp,sp,48
    80000894:	8082                	ret
    panic("uvmfirst: more than a page");
    80000896:	00007517          	auipc	a0,0x7
    8000089a:	8b250513          	addi	a0,a0,-1870 # 80007148 <etext+0x148>
    8000089e:	601040ef          	jal	8000569e <panic>

00000000800008a2 <uvmdealloc>:
{
    800008a2:	1101                	addi	sp,sp,-32
    800008a4:	ec06                	sd	ra,24(sp)
    800008a6:	e822                	sd	s0,16(sp)
    800008a8:	e426                	sd	s1,8(sp)
    800008aa:	1000                	addi	s0,sp,32
    return oldsz;
    800008ac:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800008ae:	00b67d63          	bgeu	a2,a1,800008c8 <uvmdealloc+0x26>
    800008b2:	84b2                	mv	s1,a2
  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800008b4:	6785                	lui	a5,0x1
    800008b6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800008b8:	00f60733          	add	a4,a2,a5
    800008bc:	76fd                	lui	a3,0xfffff
    800008be:	8f75                	and	a4,a4,a3
    800008c0:	97ae                	add	a5,a5,a1
    800008c2:	8ff5                	and	a5,a5,a3
    800008c4:	00f76863          	bltu	a4,a5,800008d4 <uvmdealloc+0x32>
}
    800008c8:	8526                	mv	a0,s1
    800008ca:	60e2                	ld	ra,24(sp)
    800008cc:	6442                	ld	s0,16(sp)
    800008ce:	64a2                	ld	s1,8(sp)
    800008d0:	6105                	addi	sp,sp,32
    800008d2:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800008d4:	8f99                	sub	a5,a5,a4
    800008d6:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800008d8:	4685                	li	a3,1
    800008da:	0007861b          	sext.w	a2,a5
    800008de:	85ba                	mv	a1,a4
    800008e0:	e73ff0ef          	jal	80000752 <uvmunmap>
    800008e4:	b7d5                	j	800008c8 <uvmdealloc+0x26>

00000000800008e6 <uvmalloc>:
  if(newsz < oldsz)
    800008e6:	0ab66163          	bltu	a2,a1,80000988 <uvmalloc+0xa2>
{
    800008ea:	715d                	addi	sp,sp,-80
    800008ec:	e486                	sd	ra,72(sp)
    800008ee:	e0a2                	sd	s0,64(sp)
    800008f0:	f84a                	sd	s2,48(sp)
    800008f2:	f052                	sd	s4,32(sp)
    800008f4:	ec56                	sd	s5,24(sp)
    800008f6:	e45e                	sd	s7,8(sp)
    800008f8:	0880                	addi	s0,sp,80
    800008fa:	8aaa                	mv	s5,a0
    800008fc:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800008fe:	6785                	lui	a5,0x1
    80000900:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000902:	95be                	add	a1,a1,a5
    80000904:	77fd                	lui	a5,0xfffff
    80000906:	00f5f933          	and	s2,a1,a5
    8000090a:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += sz){
    8000090c:	08c97063          	bgeu	s2,a2,8000098c <uvmalloc+0xa6>
    80000910:	fc26                	sd	s1,56(sp)
    80000912:	f44e                	sd	s3,40(sp)
    80000914:	e85a                	sd	s6,16(sp)
    memset(mem, 0, sz);
    80000916:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000918:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    8000091c:	fe8ff0ef          	jal	80000104 <kalloc>
    80000920:	84aa                	mv	s1,a0
    if(mem == 0){
    80000922:	c50d                	beqz	a0,8000094c <uvmalloc+0x66>
    memset(mem, 0, sz);
    80000924:	864e                	mv	a2,s3
    80000926:	4581                	li	a1,0
    80000928:	837ff0ef          	jal	8000015e <memset>
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000092c:	875a                	mv	a4,s6
    8000092e:	86a6                	mv	a3,s1
    80000930:	864e                	mv	a2,s3
    80000932:	85ca                	mv	a1,s2
    80000934:	8556                	mv	a0,s5
    80000936:	c75ff0ef          	jal	800005aa <mappages>
    8000093a:	e915                	bnez	a0,8000096e <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += sz){
    8000093c:	994e                	add	s2,s2,s3
    8000093e:	fd496fe3          	bltu	s2,s4,8000091c <uvmalloc+0x36>
  return newsz;
    80000942:	8552                	mv	a0,s4
    80000944:	74e2                	ld	s1,56(sp)
    80000946:	79a2                	ld	s3,40(sp)
    80000948:	6b42                	ld	s6,16(sp)
    8000094a:	a811                	j	8000095e <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    8000094c:	865e                	mv	a2,s7
    8000094e:	85ca                	mv	a1,s2
    80000950:	8556                	mv	a0,s5
    80000952:	f51ff0ef          	jal	800008a2 <uvmdealloc>
      return 0;
    80000956:	4501                	li	a0,0
    80000958:	74e2                	ld	s1,56(sp)
    8000095a:	79a2                	ld	s3,40(sp)
    8000095c:	6b42                	ld	s6,16(sp)
}
    8000095e:	60a6                	ld	ra,72(sp)
    80000960:	6406                	ld	s0,64(sp)
    80000962:	7942                	ld	s2,48(sp)
    80000964:	7a02                	ld	s4,32(sp)
    80000966:	6ae2                	ld	s5,24(sp)
    80000968:	6ba2                	ld	s7,8(sp)
    8000096a:	6161                	addi	sp,sp,80
    8000096c:	8082                	ret
      kfree(mem);
    8000096e:	8526                	mv	a0,s1
    80000970:	eacff0ef          	jal	8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80000974:	865e                	mv	a2,s7
    80000976:	85ca                	mv	a1,s2
    80000978:	8556                	mv	a0,s5
    8000097a:	f29ff0ef          	jal	800008a2 <uvmdealloc>
      return 0;
    8000097e:	4501                	li	a0,0
    80000980:	74e2                	ld	s1,56(sp)
    80000982:	79a2                	ld	s3,40(sp)
    80000984:	6b42                	ld	s6,16(sp)
    80000986:	bfe1                	j	8000095e <uvmalloc+0x78>
    return oldsz;
    80000988:	852e                	mv	a0,a1
}
    8000098a:	8082                	ret
  return newsz;
    8000098c:	8532                	mv	a0,a2
    8000098e:	bfc1                	j	8000095e <uvmalloc+0x78>

0000000080000990 <freewalk>:
{
    80000990:	7179                	addi	sp,sp,-48
    80000992:	f406                	sd	ra,40(sp)
    80000994:	f022                	sd	s0,32(sp)
    80000996:	ec26                	sd	s1,24(sp)
    80000998:	e84a                	sd	s2,16(sp)
    8000099a:	e44e                	sd	s3,8(sp)
    8000099c:	1800                	addi	s0,sp,48
    8000099e:	89aa                	mv	s3,a0
  for(int i = 0; i < 512; i++){
    800009a0:	84aa                	mv	s1,a0
    800009a2:	6905                	lui	s2,0x1
    800009a4:	992a                	add	s2,s2,a0
    800009a6:	a811                	j	800009ba <freewalk+0x2a>
      panic("freewalk: leaf");
    800009a8:	00006517          	auipc	a0,0x6
    800009ac:	7c050513          	addi	a0,a0,1984 # 80007168 <etext+0x168>
    800009b0:	4ef040ef          	jal	8000569e <panic>
  for(int i = 0; i < 512; i++){
    800009b4:	04a1                	addi	s1,s1,8
    800009b6:	03248163          	beq	s1,s2,800009d8 <freewalk+0x48>
    pte_t pte = pagetable[i];
    800009ba:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800009bc:	0017f713          	andi	a4,a5,1
    800009c0:	db75                	beqz	a4,800009b4 <freewalk+0x24>
    800009c2:	00e7f713          	andi	a4,a5,14
    800009c6:	f36d                	bnez	a4,800009a8 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800009c8:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800009ca:	00c79513          	slli	a0,a5,0xc
    800009ce:	fc3ff0ef          	jal	80000990 <freewalk>
      pagetable[i] = 0;
    800009d2:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800009d6:	bff9                	j	800009b4 <freewalk+0x24>
  kfree((void*)pagetable);
    800009d8:	854e                	mv	a0,s3
    800009da:	e42ff0ef          	jal	8000001c <kfree>
}
    800009de:	70a2                	ld	ra,40(sp)
    800009e0:	7402                	ld	s0,32(sp)
    800009e2:	64e2                	ld	s1,24(sp)
    800009e4:	6942                	ld	s2,16(sp)
    800009e6:	69a2                	ld	s3,8(sp)
    800009e8:	6145                	addi	sp,sp,48
    800009ea:	8082                	ret

00000000800009ec <uvmfree>:
{
    800009ec:	1101                	addi	sp,sp,-32
    800009ee:	ec06                	sd	ra,24(sp)
    800009f0:	e822                	sd	s0,16(sp)
    800009f2:	e426                	sd	s1,8(sp)
    800009f4:	1000                	addi	s0,sp,32
    800009f6:	84aa                	mv	s1,a0
  if(sz > 0)
    800009f8:	e989                	bnez	a1,80000a0a <uvmfree+0x1e>
  freewalk(pagetable);
    800009fa:	8526                	mv	a0,s1
    800009fc:	f95ff0ef          	jal	80000990 <freewalk>
}
    80000a00:	60e2                	ld	ra,24(sp)
    80000a02:	6442                	ld	s0,16(sp)
    80000a04:	64a2                	ld	s1,8(sp)
    80000a06:	6105                	addi	sp,sp,32
    80000a08:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80000a0a:	6785                	lui	a5,0x1
    80000a0c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000a0e:	95be                	add	a1,a1,a5
    80000a10:	4685                	li	a3,1
    80000a12:	00c5d613          	srli	a2,a1,0xc
    80000a16:	4581                	li	a1,0
    80000a18:	d3bff0ef          	jal	80000752 <uvmunmap>
    80000a1c:	bff9                	j	800009fa <uvmfree+0xe>

0000000080000a1e <uvmcopy>:
  for(i = 0; i < sz; i += szinc){
    80000a1e:	c64d                	beqz	a2,80000ac8 <uvmcopy+0xaa>
{
    80000a20:	715d                	addi	sp,sp,-80
    80000a22:	e486                	sd	ra,72(sp)
    80000a24:	e0a2                	sd	s0,64(sp)
    80000a26:	fc26                	sd	s1,56(sp)
    80000a28:	f84a                	sd	s2,48(sp)
    80000a2a:	f44e                	sd	s3,40(sp)
    80000a2c:	f052                	sd	s4,32(sp)
    80000a2e:	ec56                	sd	s5,24(sp)
    80000a30:	e85a                	sd	s6,16(sp)
    80000a32:	e45e                	sd	s7,8(sp)
    80000a34:	0880                	addi	s0,sp,80
    80000a36:	8b2a                	mv	s6,a0
    80000a38:	8aae                	mv	s5,a1
    80000a3a:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += szinc){
    80000a3c:	4901                	li	s2,0
    memmove(mem, (char*)pa, PGSIZE);
    80000a3e:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    80000a40:	4601                	li	a2,0
    80000a42:	85ca                	mv	a1,s2
    80000a44:	855a                	mv	a0,s6
    80000a46:	a83ff0ef          	jal	800004c8 <walk>
    80000a4a:	cd0d                	beqz	a0,80000a84 <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    80000a4c:	00053b83          	ld	s7,0(a0)
    80000a50:	001bf793          	andi	a5,s7,1
    80000a54:	cf95                	beqz	a5,80000a90 <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    80000a56:	eaeff0ef          	jal	80000104 <kalloc>
    80000a5a:	84aa                	mv	s1,a0
    80000a5c:	c139                	beqz	a0,80000aa2 <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    80000a5e:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80000a62:	864e                	mv	a2,s3
    80000a64:	05b2                	slli	a1,a1,0xc
    80000a66:	f58ff0ef          	jal	800001be <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80000a6a:	3ffbf713          	andi	a4,s7,1023
    80000a6e:	86a6                	mv	a3,s1
    80000a70:	864e                	mv	a2,s3
    80000a72:	85ca                	mv	a1,s2
    80000a74:	8556                	mv	a0,s5
    80000a76:	b35ff0ef          	jal	800005aa <mappages>
    80000a7a:	e10d                	bnez	a0,80000a9c <uvmcopy+0x7e>
  for(i = 0; i < sz; i += szinc){
    80000a7c:	994e                	add	s2,s2,s3
    80000a7e:	fd4961e3          	bltu	s2,s4,80000a40 <uvmcopy+0x22>
    80000a82:	a805                	j	80000ab2 <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    80000a84:	00006517          	auipc	a0,0x6
    80000a88:	6f450513          	addi	a0,a0,1780 # 80007178 <etext+0x178>
    80000a8c:	413040ef          	jal	8000569e <panic>
      panic("uvmcopy: page not present");
    80000a90:	00006517          	auipc	a0,0x6
    80000a94:	70850513          	addi	a0,a0,1800 # 80007198 <etext+0x198>
    80000a98:	407040ef          	jal	8000569e <panic>
      kfree(mem);
    80000a9c:	8526                	mv	a0,s1
    80000a9e:	d7eff0ef          	jal	8000001c <kfree>
  uvmunmap(new, 0, i / PGSIZE, 1);
    80000aa2:	4685                	li	a3,1
    80000aa4:	00c95613          	srli	a2,s2,0xc
    80000aa8:	4581                	li	a1,0
    80000aaa:	8556                	mv	a0,s5
    80000aac:	ca7ff0ef          	jal	80000752 <uvmunmap>
  return -1;
    80000ab0:	557d                	li	a0,-1
}
    80000ab2:	60a6                	ld	ra,72(sp)
    80000ab4:	6406                	ld	s0,64(sp)
    80000ab6:	74e2                	ld	s1,56(sp)
    80000ab8:	7942                	ld	s2,48(sp)
    80000aba:	79a2                	ld	s3,40(sp)
    80000abc:	7a02                	ld	s4,32(sp)
    80000abe:	6ae2                	ld	s5,24(sp)
    80000ac0:	6b42                	ld	s6,16(sp)
    80000ac2:	6ba2                	ld	s7,8(sp)
    80000ac4:	6161                	addi	sp,sp,80
    80000ac6:	8082                	ret
  return 0;
    80000ac8:	4501                	li	a0,0
}
    80000aca:	8082                	ret

0000000080000acc <uvmclear>:
{
    80000acc:	1141                	addi	sp,sp,-16
    80000ace:	e406                	sd	ra,8(sp)
    80000ad0:	e022                	sd	s0,0(sp)
    80000ad2:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000ad4:	4601                	li	a2,0
    80000ad6:	9f3ff0ef          	jal	800004c8 <walk>
  if(pte == 0)
    80000ada:	c901                	beqz	a0,80000aea <uvmclear+0x1e>
  *pte &= ~PTE_U;
    80000adc:	611c                	ld	a5,0(a0)
    80000ade:	9bbd                	andi	a5,a5,-17
    80000ae0:	e11c                	sd	a5,0(a0)
}
    80000ae2:	60a2                	ld	ra,8(sp)
    80000ae4:	6402                	ld	s0,0(sp)
    80000ae6:	0141                	addi	sp,sp,16
    80000ae8:	8082                	ret
    panic("uvmclear");
    80000aea:	00006517          	auipc	a0,0x6
    80000aee:	6ce50513          	addi	a0,a0,1742 # 800071b8 <etext+0x1b8>
    80000af2:	3ad040ef          	jal	8000569e <panic>

0000000080000af6 <copyout>:
  while(len > 0){
    80000af6:	c2d1                	beqz	a3,80000b7a <copyout+0x84>
{
    80000af8:	711d                	addi	sp,sp,-96
    80000afa:	ec86                	sd	ra,88(sp)
    80000afc:	e8a2                	sd	s0,80(sp)
    80000afe:	e4a6                	sd	s1,72(sp)
    80000b00:	e0ca                	sd	s2,64(sp)
    80000b02:	fc4e                	sd	s3,56(sp)
    80000b04:	f852                	sd	s4,48(sp)
    80000b06:	f456                	sd	s5,40(sp)
    80000b08:	f05a                	sd	s6,32(sp)
    80000b0a:	ec5e                	sd	s7,24(sp)
    80000b0c:	e862                	sd	s8,16(sp)
    80000b0e:	e466                	sd	s9,8(sp)
    80000b10:	1080                	addi	s0,sp,96
    80000b12:	8b2a                	mv	s6,a0
    80000b14:	89ae                	mv	s3,a1
    80000b16:	8ab2                	mv	s5,a2
    80000b18:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80000b1a:	7cfd                	lui	s9,0xfffff
    if (va0 >= MAXVA)
    80000b1c:	5c7d                	li	s8,-1
    80000b1e:	01ac5c13          	srli	s8,s8,0x1a
    n = PGSIZE - (dstva - va0);
    80000b22:	6b85                	lui	s7,0x1
    80000b24:	a005                	j	80000b44 <copyout+0x4e>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000b26:	412989b3          	sub	s3,s3,s2
    80000b2a:	0004861b          	sext.w	a2,s1
    80000b2e:	85d6                	mv	a1,s5
    80000b30:	954e                	add	a0,a0,s3
    80000b32:	e8cff0ef          	jal	800001be <memmove>
    len -= n;
    80000b36:	409a0a33          	sub	s4,s4,s1
    src += n;
    80000b3a:	9aa6                	add	s5,s5,s1
    dstva = va0 + PGSIZE;
    80000b3c:	017909b3          	add	s3,s2,s7
  while(len > 0){
    80000b40:	020a0b63          	beqz	s4,80000b76 <copyout+0x80>
    va0 = PGROUNDDOWN(dstva);
    80000b44:	0199f933          	and	s2,s3,s9
    if (va0 >= MAXVA)
    80000b48:	032c6b63          	bltu	s8,s2,80000b7e <copyout+0x88>
    if((pte = walk(pagetable, va0, 0)) == 0) {
    80000b4c:	4601                	li	a2,0
    80000b4e:	85ca                	mv	a1,s2
    80000b50:	855a                	mv	a0,s6
    80000b52:	977ff0ef          	jal	800004c8 <walk>
    80000b56:	c131                	beqz	a0,80000b9a <copyout+0xa4>
    if((*pte & PTE_W) == 0)
    80000b58:	611c                	ld	a5,0(a0)
    80000b5a:	8b91                	andi	a5,a5,4
    80000b5c:	c3a9                	beqz	a5,80000b9e <copyout+0xa8>
    pa0 = walkaddr(pagetable, va0);
    80000b5e:	85ca                	mv	a1,s2
    80000b60:	855a                	mv	a0,s6
    80000b62:	a0fff0ef          	jal	80000570 <walkaddr>
    if(pa0 == 0)
    80000b66:	cd15                	beqz	a0,80000ba2 <copyout+0xac>
    n = PGSIZE - (dstva - va0);
    80000b68:	413904b3          	sub	s1,s2,s3
    80000b6c:	94de                	add	s1,s1,s7
    if(n > len)
    80000b6e:	fa9a7ce3          	bgeu	s4,s1,80000b26 <copyout+0x30>
    80000b72:	84d2                	mv	s1,s4
    80000b74:	bf4d                	j	80000b26 <copyout+0x30>
  return 0;
    80000b76:	4501                	li	a0,0
    80000b78:	a021                	j	80000b80 <copyout+0x8a>
    80000b7a:	4501                	li	a0,0
}
    80000b7c:	8082                	ret
      return -1;
    80000b7e:	557d                	li	a0,-1
}
    80000b80:	60e6                	ld	ra,88(sp)
    80000b82:	6446                	ld	s0,80(sp)
    80000b84:	64a6                	ld	s1,72(sp)
    80000b86:	6906                	ld	s2,64(sp)
    80000b88:	79e2                	ld	s3,56(sp)
    80000b8a:	7a42                	ld	s4,48(sp)
    80000b8c:	7aa2                	ld	s5,40(sp)
    80000b8e:	7b02                	ld	s6,32(sp)
    80000b90:	6be2                	ld	s7,24(sp)
    80000b92:	6c42                	ld	s8,16(sp)
    80000b94:	6ca2                	ld	s9,8(sp)
    80000b96:	6125                	addi	sp,sp,96
    80000b98:	8082                	ret
      return -1;
    80000b9a:	557d                	li	a0,-1
    80000b9c:	b7d5                	j	80000b80 <copyout+0x8a>
      return -1;
    80000b9e:	557d                	li	a0,-1
    80000ba0:	b7c5                	j	80000b80 <copyout+0x8a>
      return -1;
    80000ba2:	557d                	li	a0,-1
    80000ba4:	bff1                	j	80000b80 <copyout+0x8a>

0000000080000ba6 <copyin>:
  while(len > 0){
    80000ba6:	c6a5                	beqz	a3,80000c0e <copyin+0x68>
{
    80000ba8:	715d                	addi	sp,sp,-80
    80000baa:	e486                	sd	ra,72(sp)
    80000bac:	e0a2                	sd	s0,64(sp)
    80000bae:	fc26                	sd	s1,56(sp)
    80000bb0:	f84a                	sd	s2,48(sp)
    80000bb2:	f44e                	sd	s3,40(sp)
    80000bb4:	f052                	sd	s4,32(sp)
    80000bb6:	ec56                	sd	s5,24(sp)
    80000bb8:	e85a                	sd	s6,16(sp)
    80000bba:	e45e                	sd	s7,8(sp)
    80000bbc:	e062                	sd	s8,0(sp)
    80000bbe:	0880                	addi	s0,sp,80
    80000bc0:	8b2a                	mv	s6,a0
    80000bc2:	8a2e                	mv	s4,a1
    80000bc4:	8c32                	mv	s8,a2
    80000bc6:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000bc8:	7bfd                	lui	s7,0xfffff
    n = PGSIZE - (srcva - va0);
    80000bca:	6a85                	lui	s5,0x1
    80000bcc:	a00d                	j	80000bee <copyin+0x48>
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000bce:	018505b3          	add	a1,a0,s8
    80000bd2:	0004861b          	sext.w	a2,s1
    80000bd6:	412585b3          	sub	a1,a1,s2
    80000bda:	8552                	mv	a0,s4
    80000bdc:	de2ff0ef          	jal	800001be <memmove>
    len -= n;
    80000be0:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000be4:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000be6:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000bea:	02098063          	beqz	s3,80000c0a <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000bee:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000bf2:	85ca                	mv	a1,s2
    80000bf4:	855a                	mv	a0,s6
    80000bf6:	97bff0ef          	jal	80000570 <walkaddr>
    if(pa0 == 0)
    80000bfa:	cd01                	beqz	a0,80000c12 <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000bfc:	418904b3          	sub	s1,s2,s8
    80000c00:	94d6                	add	s1,s1,s5
    if(n > len)
    80000c02:	fc99f6e3          	bgeu	s3,s1,80000bce <copyin+0x28>
    80000c06:	84ce                	mv	s1,s3
    80000c08:	b7d9                	j	80000bce <copyin+0x28>
  return 0;
    80000c0a:	4501                	li	a0,0
    80000c0c:	a021                	j	80000c14 <copyin+0x6e>
    80000c0e:	4501                	li	a0,0
}
    80000c10:	8082                	ret
      return -1;
    80000c12:	557d                	li	a0,-1
}
    80000c14:	60a6                	ld	ra,72(sp)
    80000c16:	6406                	ld	s0,64(sp)
    80000c18:	74e2                	ld	s1,56(sp)
    80000c1a:	7942                	ld	s2,48(sp)
    80000c1c:	79a2                	ld	s3,40(sp)
    80000c1e:	7a02                	ld	s4,32(sp)
    80000c20:	6ae2                	ld	s5,24(sp)
    80000c22:	6b42                	ld	s6,16(sp)
    80000c24:	6ba2                	ld	s7,8(sp)
    80000c26:	6c02                	ld	s8,0(sp)
    80000c28:	6161                	addi	sp,sp,80
    80000c2a:	8082                	ret

0000000080000c2c <copyinstr>:
  while(got_null == 0 && max > 0){
    80000c2c:	cac5                	beqz	a3,80000cdc <copyinstr+0xb0>
{
    80000c2e:	715d                	addi	sp,sp,-80
    80000c30:	e486                	sd	ra,72(sp)
    80000c32:	e0a2                	sd	s0,64(sp)
    80000c34:	fc26                	sd	s1,56(sp)
    80000c36:	f84a                	sd	s2,48(sp)
    80000c38:	f44e                	sd	s3,40(sp)
    80000c3a:	f052                	sd	s4,32(sp)
    80000c3c:	ec56                	sd	s5,24(sp)
    80000c3e:	e85a                	sd	s6,16(sp)
    80000c40:	e45e                	sd	s7,8(sp)
    80000c42:	0880                	addi	s0,sp,80
    80000c44:	8aaa                	mv	s5,a0
    80000c46:	84ae                	mv	s1,a1
    80000c48:	8bb2                	mv	s7,a2
    80000c4a:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000c4c:	7b7d                	lui	s6,0xfffff
    n = PGSIZE - (srcva - va0);
    80000c4e:	6a05                	lui	s4,0x1
    80000c50:	a82d                	j	80000c8a <copyinstr+0x5e>
        *dst = '\0';
    80000c52:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80000c56:	4785                	li	a5,1
  if(got_null){
    80000c58:	0017c793          	xori	a5,a5,1
    80000c5c:	40f0053b          	negw	a0,a5
}
    80000c60:	60a6                	ld	ra,72(sp)
    80000c62:	6406                	ld	s0,64(sp)
    80000c64:	74e2                	ld	s1,56(sp)
    80000c66:	7942                	ld	s2,48(sp)
    80000c68:	79a2                	ld	s3,40(sp)
    80000c6a:	7a02                	ld	s4,32(sp)
    80000c6c:	6ae2                	ld	s5,24(sp)
    80000c6e:	6b42                	ld	s6,16(sp)
    80000c70:	6ba2                	ld	s7,8(sp)
    80000c72:	6161                	addi	sp,sp,80
    80000c74:	8082                	ret
    80000c76:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80000c7a:	9726                	add	a4,a4,s1
      --max;
    80000c7c:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80000c80:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80000c84:	04e58463          	beq	a1,a4,80000ccc <copyinstr+0xa0>
{
    80000c88:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80000c8a:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80000c8e:	85ca                	mv	a1,s2
    80000c90:	8556                	mv	a0,s5
    80000c92:	8dfff0ef          	jal	80000570 <walkaddr>
    if(pa0 == 0)
    80000c96:	cd0d                	beqz	a0,80000cd0 <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80000c98:	417906b3          	sub	a3,s2,s7
    80000c9c:	96d2                	add	a3,a3,s4
    if(n > max)
    80000c9e:	00d9f363          	bgeu	s3,a3,80000ca4 <copyinstr+0x78>
    80000ca2:	86ce                	mv	a3,s3
    while(n > 0){
    80000ca4:	ca85                	beqz	a3,80000cd4 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80000ca6:	01750633          	add	a2,a0,s7
    80000caa:	41260633          	sub	a2,a2,s2
    80000cae:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80000cb0:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80000cb2:	96a6                	add	a3,a3,s1
    80000cb4:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000cb6:	00f60733          	add	a4,a2,a5
    80000cba:	00074703          	lbu	a4,0(a4)
    80000cbe:	db51                	beqz	a4,80000c52 <copyinstr+0x26>
        *dst = *p;
    80000cc0:	00e78023          	sb	a4,0(a5)
      dst++;
    80000cc4:	0785                	addi	a5,a5,1
    while(n > 0){
    80000cc6:	fed797e3          	bne	a5,a3,80000cb4 <copyinstr+0x88>
    80000cca:	b775                	j	80000c76 <copyinstr+0x4a>
    80000ccc:	4781                	li	a5,0
    80000cce:	b769                	j	80000c58 <copyinstr+0x2c>
      return -1;
    80000cd0:	557d                	li	a0,-1
    80000cd2:	b779                	j	80000c60 <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80000cd4:	6b85                	lui	s7,0x1
    80000cd6:	9bca                	add	s7,s7,s2
    80000cd8:	87a6                	mv	a5,s1
    80000cda:	b77d                	j	80000c88 <copyinstr+0x5c>
  int got_null = 0;
    80000cdc:	4781                	li	a5,0
  if(got_null){
    80000cde:	0017c793          	xori	a5,a5,1
    80000ce2:	40f0053b          	negw	a0,a5
}
    80000ce6:	8082                	ret

0000000080000ce8 <vmprint>:

#ifdef LAB_PGTBL

void
vmprint(pagetable_t pagetable)
{
    80000ce8:	1101                	addi	sp,sp,-32
    80000cea:	ec06                	sd	ra,24(sp)
    80000cec:	e822                	sd	s0,16(sp)
    80000cee:	e426                	sd	s1,8(sp)
    80000cf0:	1000                	addi	s0,sp,32
    80000cf2:	84aa                	mv	s1,a0
    printf("page table %p\n", (void*)pagetable);
    80000cf4:	85aa                	mv	a1,a0
    80000cf6:	00006517          	auipc	a0,0x6
    80000cfa:	4d250513          	addi	a0,a0,1234 # 800071c8 <etext+0x1c8>
    80000cfe:	690040ef          	jal	8000538e <printf>
    vmprint_walk(pagetable, 2, 0); // start at level 2 (Sv39 top)
    80000d02:	4601                	li	a2,0
    80000d04:	4589                	li	a1,2
    80000d06:	8526                	mv	a0,s1
    80000d08:	ebeff0ef          	jal	800003c6 <vmprint_walk>
}
    80000d0c:	60e2                	ld	ra,24(sp)
    80000d0e:	6442                	ld	s0,16(sp)
    80000d10:	64a2                	ld	s1,8(sp)
    80000d12:	6105                	addi	sp,sp,32
    80000d14:	8082                	ret

0000000080000d16 <pgpte>:



#ifdef LAB_PGTBL
pte_t*
pgpte(pagetable_t pagetable, uint64 va) {
    80000d16:	1141                	addi	sp,sp,-16
    80000d18:	e406                	sd	ra,8(sp)
    80000d1a:	e022                	sd	s0,0(sp)
    80000d1c:	0800                	addi	s0,sp,16
  return walk(pagetable, va, 0);
    80000d1e:	4601                	li	a2,0
    80000d20:	fa8ff0ef          	jal	800004c8 <walk>
}
    80000d24:	60a2                	ld	ra,8(sp)
    80000d26:	6402                	ld	s0,0(sp)
    80000d28:	0141                	addi	sp,sp,16
    80000d2a:	8082                	ret

0000000080000d2c <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000d2c:	715d                	addi	sp,sp,-80
    80000d2e:	e486                	sd	ra,72(sp)
    80000d30:	e0a2                	sd	s0,64(sp)
    80000d32:	fc26                	sd	s1,56(sp)
    80000d34:	f84a                	sd	s2,48(sp)
    80000d36:	f44e                	sd	s3,40(sp)
    80000d38:	f052                	sd	s4,32(sp)
    80000d3a:	ec56                	sd	s5,24(sp)
    80000d3c:	e85a                	sd	s6,16(sp)
    80000d3e:	e45e                	sd	s7,8(sp)
    80000d40:	e062                	sd	s8,0(sp)
    80000d42:	0880                	addi	s0,sp,80
    80000d44:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d46:	00007497          	auipc	s1,0x7
    80000d4a:	0ba48493          	addi	s1,s1,186 # 80007e00 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000d4e:	8c26                	mv	s8,s1
    80000d50:	ff4df937          	lui	s2,0xff4df
    80000d54:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdadd>
    80000d58:	0936                	slli	s2,s2,0xd
    80000d5a:	6f590913          	addi	s2,s2,1781
    80000d5e:	0936                	slli	s2,s2,0xd
    80000d60:	bd390913          	addi	s2,s2,-1069
    80000d64:	0932                	slli	s2,s2,0xc
    80000d66:	7a790913          	addi	s2,s2,1959
    80000d6a:	010009b7          	lui	s3,0x1000
    80000d6e:	19fd                	addi	s3,s3,-1 # ffffff <_entry-0x7f000001>
    80000d70:	09ba                	slli	s3,s3,0xe
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000d72:	4b99                	li	s7,6
    80000d74:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d76:	0000da97          	auipc	s5,0xd
    80000d7a:	c8aa8a93          	addi	s5,s5,-886 # 8000da00 <tickslock>
    char *pa = kalloc();
    80000d7e:	b86ff0ef          	jal	80000104 <kalloc>
    80000d82:	862a                	mv	a2,a0
    if(pa == 0)
    80000d84:	cd1d                	beqz	a0,80000dc2 <proc_mapstacks+0x96>
    uint64 va = KSTACK((int) (p - proc));
    80000d86:	418485b3          	sub	a1,s1,s8
    80000d8a:	8591                	srai	a1,a1,0x4
    80000d8c:	032585b3          	mul	a1,a1,s2
    80000d90:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000d94:	875e                	mv	a4,s7
    80000d96:	86da                	mv	a3,s6
    80000d98:	40b985b3          	sub	a1,s3,a1
    80000d9c:	8552                	mv	a0,s4
    80000d9e:	8c3ff0ef          	jal	80000660 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000da2:	17048493          	addi	s1,s1,368
    80000da6:	fd549ce3          	bne	s1,s5,80000d7e <proc_mapstacks+0x52>
  }
}
    80000daa:	60a6                	ld	ra,72(sp)
    80000dac:	6406                	ld	s0,64(sp)
    80000dae:	74e2                	ld	s1,56(sp)
    80000db0:	7942                	ld	s2,48(sp)
    80000db2:	79a2                	ld	s3,40(sp)
    80000db4:	7a02                	ld	s4,32(sp)
    80000db6:	6ae2                	ld	s5,24(sp)
    80000db8:	6b42                	ld	s6,16(sp)
    80000dba:	6ba2                	ld	s7,8(sp)
    80000dbc:	6c02                	ld	s8,0(sp)
    80000dbe:	6161                	addi	sp,sp,80
    80000dc0:	8082                	ret
      panic("kalloc");
    80000dc2:	00006517          	auipc	a0,0x6
    80000dc6:	41650513          	addi	a0,a0,1046 # 800071d8 <etext+0x1d8>
    80000dca:	0d5040ef          	jal	8000569e <panic>

0000000080000dce <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000dce:	7139                	addi	sp,sp,-64
    80000dd0:	fc06                	sd	ra,56(sp)
    80000dd2:	f822                	sd	s0,48(sp)
    80000dd4:	f426                	sd	s1,40(sp)
    80000dd6:	f04a                	sd	s2,32(sp)
    80000dd8:	ec4e                	sd	s3,24(sp)
    80000dda:	e852                	sd	s4,16(sp)
    80000ddc:	e456                	sd	s5,8(sp)
    80000dde:	e05a                	sd	s6,0(sp)
    80000de0:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000de2:	00006597          	auipc	a1,0x6
    80000de6:	3fe58593          	addi	a1,a1,1022 # 800071e0 <etext+0x1e0>
    80000dea:	00007517          	auipc	a0,0x7
    80000dee:	be650513          	addi	a0,a0,-1050 # 800079d0 <pid_lock>
    80000df2:	361040ef          	jal	80005952 <initlock>
  initlock(&wait_lock, "wait_lock");
    80000df6:	00006597          	auipc	a1,0x6
    80000dfa:	3f258593          	addi	a1,a1,1010 # 800071e8 <etext+0x1e8>
    80000dfe:	00007517          	auipc	a0,0x7
    80000e02:	bea50513          	addi	a0,a0,-1046 # 800079e8 <wait_lock>
    80000e06:	34d040ef          	jal	80005952 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000e0a:	00007497          	auipc	s1,0x7
    80000e0e:	ff648493          	addi	s1,s1,-10 # 80007e00 <proc>
      initlock(&p->lock, "proc");
    80000e12:	00006a97          	auipc	s5,0x6
    80000e16:	3e6a8a93          	addi	s5,s5,998 # 800071f8 <etext+0x1f8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000e1a:	8a26                	mv	s4,s1
    80000e1c:	ff4df937          	lui	s2,0xff4df
    80000e20:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bdadd>
    80000e24:	0936                	slli	s2,s2,0xd
    80000e26:	6f590913          	addi	s2,s2,1781
    80000e2a:	0936                	slli	s2,s2,0xd
    80000e2c:	bd390913          	addi	s2,s2,-1069
    80000e30:	0932                	slli	s2,s2,0xc
    80000e32:	7a790913          	addi	s2,s2,1959
    80000e36:	010009b7          	lui	s3,0x1000
    80000e3a:	19fd                	addi	s3,s3,-1 # ffffff <_entry-0x7f000001>
    80000e3c:	09ba                	slli	s3,s3,0xe
  for(p = proc; p < &proc[NPROC]; p++) {
    80000e3e:	0000db17          	auipc	s6,0xd
    80000e42:	bc2b0b13          	addi	s6,s6,-1086 # 8000da00 <tickslock>
      initlock(&p->lock, "proc");
    80000e46:	85d6                	mv	a1,s5
    80000e48:	8526                	mv	a0,s1
    80000e4a:	309040ef          	jal	80005952 <initlock>
      p->state = UNUSED;
    80000e4e:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000e52:	414487b3          	sub	a5,s1,s4
    80000e56:	8791                	srai	a5,a5,0x4
    80000e58:	032787b3          	mul	a5,a5,s2
    80000e5c:	00d7979b          	slliw	a5,a5,0xd
    80000e60:	40f987b3          	sub	a5,s3,a5
    80000e64:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000e66:	17048493          	addi	s1,s1,368
    80000e6a:	fd649ee3          	bne	s1,s6,80000e46 <procinit+0x78>
  }
}
    80000e6e:	70e2                	ld	ra,56(sp)
    80000e70:	7442                	ld	s0,48(sp)
    80000e72:	74a2                	ld	s1,40(sp)
    80000e74:	7902                	ld	s2,32(sp)
    80000e76:	69e2                	ld	s3,24(sp)
    80000e78:	6a42                	ld	s4,16(sp)
    80000e7a:	6aa2                	ld	s5,8(sp)
    80000e7c:	6b02                	ld	s6,0(sp)
    80000e7e:	6121                	addi	sp,sp,64
    80000e80:	8082                	ret

0000000080000e82 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000e82:	1141                	addi	sp,sp,-16
    80000e84:	e406                	sd	ra,8(sp)
    80000e86:	e022                	sd	s0,0(sp)
    80000e88:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000e8a:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000e8c:	2501                	sext.w	a0,a0
    80000e8e:	60a2                	ld	ra,8(sp)
    80000e90:	6402                	ld	s0,0(sp)
    80000e92:	0141                	addi	sp,sp,16
    80000e94:	8082                	ret

0000000080000e96 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000e96:	1141                	addi	sp,sp,-16
    80000e98:	e406                	sd	ra,8(sp)
    80000e9a:	e022                	sd	s0,0(sp)
    80000e9c:	0800                	addi	s0,sp,16
    80000e9e:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000ea0:	2781                	sext.w	a5,a5
    80000ea2:	079e                	slli	a5,a5,0x7
  return c;
}
    80000ea4:	00007517          	auipc	a0,0x7
    80000ea8:	b5c50513          	addi	a0,a0,-1188 # 80007a00 <cpus>
    80000eac:	953e                	add	a0,a0,a5
    80000eae:	60a2                	ld	ra,8(sp)
    80000eb0:	6402                	ld	s0,0(sp)
    80000eb2:	0141                	addi	sp,sp,16
    80000eb4:	8082                	ret

0000000080000eb6 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000eb6:	1101                	addi	sp,sp,-32
    80000eb8:	ec06                	sd	ra,24(sp)
    80000eba:	e822                	sd	s0,16(sp)
    80000ebc:	e426                	sd	s1,8(sp)
    80000ebe:	1000                	addi	s0,sp,32
  push_off();
    80000ec0:	2d9040ef          	jal	80005998 <push_off>
    80000ec4:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000ec6:	2781                	sext.w	a5,a5
    80000ec8:	079e                	slli	a5,a5,0x7
    80000eca:	00007717          	auipc	a4,0x7
    80000ece:	b0670713          	addi	a4,a4,-1274 # 800079d0 <pid_lock>
    80000ed2:	97ba                	add	a5,a5,a4
    80000ed4:	7b9c                	ld	a5,48(a5)
    80000ed6:	84be                	mv	s1,a5
  pop_off();
    80000ed8:	349040ef          	jal	80005a20 <pop_off>
  return p;
}
    80000edc:	8526                	mv	a0,s1
    80000ede:	60e2                	ld	ra,24(sp)
    80000ee0:	6442                	ld	s0,16(sp)
    80000ee2:	64a2                	ld	s1,8(sp)
    80000ee4:	6105                	addi	sp,sp,32
    80000ee6:	8082                	ret

0000000080000ee8 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000ee8:	1141                	addi	sp,sp,-16
    80000eea:	e406                	sd	ra,8(sp)
    80000eec:	e022                	sd	s0,0(sp)
    80000eee:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000ef0:	fc7ff0ef          	jal	80000eb6 <myproc>
    80000ef4:	37d040ef          	jal	80005a70 <release>

  if (first) {
    80000ef8:	00007797          	auipc	a5,0x7
    80000efc:	a387a783          	lw	a5,-1480(a5) # 80007930 <first.1>
    80000f00:	e799                	bnez	a5,80000f0e <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000f02:	347000ef          	jal	80001a48 <usertrapret>
}
    80000f06:	60a2                	ld	ra,8(sp)
    80000f08:	6402                	ld	s0,0(sp)
    80000f0a:	0141                	addi	sp,sp,16
    80000f0c:	8082                	ret
    fsinit(ROOTDEV);
    80000f0e:	4505                	li	a0,1
    80000f10:	702010ef          	jal	80002612 <fsinit>
    first = 0;
    80000f14:	00007797          	auipc	a5,0x7
    80000f18:	a007ae23          	sw	zero,-1508(a5) # 80007930 <first.1>
    __sync_synchronize();
    80000f1c:	0330000f          	fence	rw,rw
    80000f20:	b7cd                	j	80000f02 <forkret+0x1a>

0000000080000f22 <allocpid>:
{
    80000f22:	1101                	addi	sp,sp,-32
    80000f24:	ec06                	sd	ra,24(sp)
    80000f26:	e822                	sd	s0,16(sp)
    80000f28:	e426                	sd	s1,8(sp)
    80000f2a:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000f2c:	00007517          	auipc	a0,0x7
    80000f30:	aa450513          	addi	a0,a0,-1372 # 800079d0 <pid_lock>
    80000f34:	2a9040ef          	jal	800059dc <acquire>
  pid = nextpid;
    80000f38:	00007797          	auipc	a5,0x7
    80000f3c:	9fc78793          	addi	a5,a5,-1540 # 80007934 <nextpid>
    80000f40:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000f42:	0014871b          	addiw	a4,s1,1
    80000f46:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000f48:	00007517          	auipc	a0,0x7
    80000f4c:	a8850513          	addi	a0,a0,-1400 # 800079d0 <pid_lock>
    80000f50:	321040ef          	jal	80005a70 <release>
}
    80000f54:	8526                	mv	a0,s1
    80000f56:	60e2                	ld	ra,24(sp)
    80000f58:	6442                	ld	s0,16(sp)
    80000f5a:	64a2                	ld	s1,8(sp)
    80000f5c:	6105                	addi	sp,sp,32
    80000f5e:	8082                	ret

0000000080000f60 <proc_pagetable>:
{
    80000f60:	1101                	addi	sp,sp,-32
    80000f62:	ec06                	sd	ra,24(sp)
    80000f64:	e822                	sd	s0,16(sp)
    80000f66:	e426                	sd	s1,8(sp)
    80000f68:	e04a                	sd	s2,0(sp)
    80000f6a:	1000                	addi	s0,sp,32
    80000f6c:	892a                	mv	s2,a0
    pagetable = uvmcreate();
    80000f6e:	8b1ff0ef          	jal	8000081e <uvmcreate>
    80000f72:	84aa                	mv	s1,a0
    if(pagetable == 0)
    80000f74:	c929                	beqz	a0,80000fc6 <proc_pagetable+0x66>
    if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000f76:	4729                	li	a4,10
    80000f78:	00005697          	auipc	a3,0x5
    80000f7c:	08868693          	addi	a3,a3,136 # 80006000 <_trampoline>
    80000f80:	6605                	lui	a2,0x1
    80000f82:	040005b7          	lui	a1,0x4000
    80000f86:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000f88:	05b2                	slli	a1,a1,0xc
    80000f8a:	e20ff0ef          	jal	800005aa <mappages>
    80000f8e:	04054363          	bltz	a0,80000fd4 <proc_pagetable+0x74>
    if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000f92:	4719                	li	a4,6
    80000f94:	05893683          	ld	a3,88(s2)
    80000f98:	6605                	lui	a2,0x1
    80000f9a:	020005b7          	lui	a1,0x2000
    80000f9e:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000fa0:	05b6                	slli	a1,a1,0xd
    80000fa2:	8526                	mv	a0,s1
    80000fa4:	e06ff0ef          	jal	800005aa <mappages>
    80000fa8:	02054c63          	bltz	a0,80000fe0 <proc_pagetable+0x80>
    if(mappages(pagetable, USYSCALL, PGSIZE,
    80000fac:	4749                	li	a4,18
    80000fae:	06093683          	ld	a3,96(s2)
    80000fb2:	6605                	lui	a2,0x1
    80000fb4:	040005b7          	lui	a1,0x4000
    80000fb8:	15f5                	addi	a1,a1,-3 # 3fffffd <_entry-0x7c000003>
    80000fba:	05b2                	slli	a1,a1,0xc
    80000fbc:	8526                	mv	a0,s1
    80000fbe:	decff0ef          	jal	800005aa <mappages>
    80000fc2:	02054e63          	bltz	a0,80000ffe <proc_pagetable+0x9e>
}
    80000fc6:	8526                	mv	a0,s1
    80000fc8:	60e2                	ld	ra,24(sp)
    80000fca:	6442                	ld	s0,16(sp)
    80000fcc:	64a2                	ld	s1,8(sp)
    80000fce:	6902                	ld	s2,0(sp)
    80000fd0:	6105                	addi	sp,sp,32
    80000fd2:	8082                	ret
        uvmfree(pagetable, 0);
    80000fd4:	4581                	li	a1,0
    80000fd6:	8526                	mv	a0,s1
    80000fd8:	a15ff0ef          	jal	800009ec <uvmfree>
        return 0;
    80000fdc:	4481                	li	s1,0
    80000fde:	b7e5                	j	80000fc6 <proc_pagetable+0x66>
        uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000fe0:	4681                	li	a3,0
    80000fe2:	4605                	li	a2,1
    80000fe4:	040005b7          	lui	a1,0x4000
    80000fe8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000fea:	05b2                	slli	a1,a1,0xc
    80000fec:	8526                	mv	a0,s1
    80000fee:	f64ff0ef          	jal	80000752 <uvmunmap>
        uvmfree(pagetable, 0);
    80000ff2:	4581                	li	a1,0
    80000ff4:	8526                	mv	a0,s1
    80000ff6:	9f7ff0ef          	jal	800009ec <uvmfree>
        return 0;
    80000ffa:	4481                	li	s1,0
    80000ffc:	b7e9                	j	80000fc6 <proc_pagetable+0x66>
        uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000ffe:	4681                	li	a3,0
    80001000:	4605                	li	a2,1
    80001002:	020005b7          	lui	a1,0x2000
    80001006:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001008:	05b6                	slli	a1,a1,0xd
    8000100a:	8526                	mv	a0,s1
    8000100c:	f46ff0ef          	jal	80000752 <uvmunmap>
        uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001010:	4681                	li	a3,0
    80001012:	4605                	li	a2,1
    80001014:	040005b7          	lui	a1,0x4000
    80001018:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000101a:	05b2                	slli	a1,a1,0xc
    8000101c:	8526                	mv	a0,s1
    8000101e:	f34ff0ef          	jal	80000752 <uvmunmap>
        uvmfree(pagetable, 0);
    80001022:	4581                	li	a1,0
    80001024:	8526                	mv	a0,s1
    80001026:	9c7ff0ef          	jal	800009ec <uvmfree>
        return 0;
    8000102a:	4481                	li	s1,0
    8000102c:	bf69                	j	80000fc6 <proc_pagetable+0x66>

000000008000102e <proc_freepagetable>:
{
    8000102e:	1101                	addi	sp,sp,-32
    80001030:	ec06                	sd	ra,24(sp)
    80001032:	e822                	sd	s0,16(sp)
    80001034:	e426                	sd	s1,8(sp)
    80001036:	e04a                	sd	s2,0(sp)
    80001038:	1000                	addi	s0,sp,32
    8000103a:	84aa                	mv	s1,a0
    8000103c:	892e                	mv	s2,a1
    uvmunmap(pagetable, USYSCALL, 1, 0);
    8000103e:	4681                	li	a3,0
    80001040:	4605                	li	a2,1
    80001042:	040005b7          	lui	a1,0x4000
    80001046:	15f5                	addi	a1,a1,-3 # 3fffffd <_entry-0x7c000003>
    80001048:	05b2                	slli	a1,a1,0xc
    8000104a:	f08ff0ef          	jal	80000752 <uvmunmap>
    uvmunmap(pagetable, TRAPFRAME, 1, 0);
    8000104e:	4681                	li	a3,0
    80001050:	4605                	li	a2,1
    80001052:	020005b7          	lui	a1,0x2000
    80001056:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001058:	05b6                	slli	a1,a1,0xd
    8000105a:	8526                	mv	a0,s1
    8000105c:	ef6ff0ef          	jal	80000752 <uvmunmap>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001060:	4681                	li	a3,0
    80001062:	4605                	li	a2,1
    80001064:	040005b7          	lui	a1,0x4000
    80001068:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000106a:	05b2                	slli	a1,a1,0xc
    8000106c:	8526                	mv	a0,s1
    8000106e:	ee4ff0ef          	jal	80000752 <uvmunmap>
    uvmfree(pagetable, sz);
    80001072:	85ca                	mv	a1,s2
    80001074:	8526                	mv	a0,s1
    80001076:	977ff0ef          	jal	800009ec <uvmfree>
}
    8000107a:	60e2                	ld	ra,24(sp)
    8000107c:	6442                	ld	s0,16(sp)
    8000107e:	64a2                	ld	s1,8(sp)
    80001080:	6902                	ld	s2,0(sp)
    80001082:	6105                	addi	sp,sp,32
    80001084:	8082                	ret

0000000080001086 <freeproc>:
{
    80001086:	1101                	addi	sp,sp,-32
    80001088:	ec06                	sd	ra,24(sp)
    8000108a:	e822                	sd	s0,16(sp)
    8000108c:	e426                	sd	s1,8(sp)
    8000108e:	1000                	addi	s0,sp,32
    80001090:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001092:	6d28                	ld	a0,88(a0)
    80001094:	c119                	beqz	a0,8000109a <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001096:	f87fe0ef          	jal	8000001c <kfree>
  p->trapframe = 0;
    8000109a:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    8000109e:	68a8                	ld	a0,80(s1)
    800010a0:	c501                	beqz	a0,800010a8 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    800010a2:	64ac                	ld	a1,72(s1)
    800010a4:	f8bff0ef          	jal	8000102e <proc_freepagetable>
  p->pagetable = 0;
    800010a8:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    800010ac:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    800010b0:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    800010b4:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    800010b8:	16048023          	sb	zero,352(s1)
  p->chan = 0;
    800010bc:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    800010c0:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    800010c4:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    800010c8:	0004ac23          	sw	zero,24(s1)
}
    800010cc:	60e2                	ld	ra,24(sp)
    800010ce:	6442                	ld	s0,16(sp)
    800010d0:	64a2                	ld	s1,8(sp)
    800010d2:	6105                	addi	sp,sp,32
    800010d4:	8082                	ret

00000000800010d6 <allocproc>:
{
    800010d6:	1101                	addi	sp,sp,-32
    800010d8:	ec06                	sd	ra,24(sp)
    800010da:	e822                	sd	s0,16(sp)
    800010dc:	e426                	sd	s1,8(sp)
    800010de:	e04a                	sd	s2,0(sp)
    800010e0:	1000                	addi	s0,sp,32
    for(p = proc; p < &proc[NPROC]; p++) {
    800010e2:	00007497          	auipc	s1,0x7
    800010e6:	d1e48493          	addi	s1,s1,-738 # 80007e00 <proc>
    800010ea:	0000d917          	auipc	s2,0xd
    800010ee:	91690913          	addi	s2,s2,-1770 # 8000da00 <tickslock>
        acquire(&p->lock);
    800010f2:	8526                	mv	a0,s1
    800010f4:	0e9040ef          	jal	800059dc <acquire>
        if(p->state == UNUSED) {
    800010f8:	4c9c                	lw	a5,24(s1)
    800010fa:	cb91                	beqz	a5,8000110e <allocproc+0x38>
            release(&p->lock);
    800010fc:	8526                	mv	a0,s1
    800010fe:	173040ef          	jal	80005a70 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001102:	17048493          	addi	s1,s1,368
    80001106:	ff2496e3          	bne	s1,s2,800010f2 <allocproc+0x1c>
    return 0;
    8000110a:	4481                	li	s1,0
    8000110c:	a8a9                	j	80001166 <allocproc+0x90>
    p->pid = allocpid();
    8000110e:	e15ff0ef          	jal	80000f22 <allocpid>
    80001112:	d888                	sw	a0,48(s1)
    p->state = USED;
    80001114:	4785                	li	a5,1
    80001116:	cc9c                	sw	a5,24(s1)
    if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001118:	fedfe0ef          	jal	80000104 <kalloc>
    8000111c:	892a                	mv	s2,a0
    8000111e:	eca8                	sd	a0,88(s1)
    80001120:	c931                	beqz	a0,80001174 <allocproc+0x9e>
    if((p->usyscall = (struct usyscall *)kalloc()) == 0){
    80001122:	fe3fe0ef          	jal	80000104 <kalloc>
    80001126:	892a                	mv	s2,a0
    80001128:	f0a8                	sd	a0,96(s1)
    8000112a:	cd29                	beqz	a0,80001184 <allocproc+0xae>
    memset((char *)p->usyscall, 0, PGSIZE);
    8000112c:	6605                	lui	a2,0x1
    8000112e:	4581                	li	a1,0
    80001130:	82eff0ef          	jal	8000015e <memset>
    p->usyscall->pid = p->pid;
    80001134:	70bc                	ld	a5,96(s1)
    80001136:	5898                	lw	a4,48(s1)
    80001138:	c398                	sw	a4,0(a5)
    p->pagetable = proc_pagetable(p);
    8000113a:	8526                	mv	a0,s1
    8000113c:	e25ff0ef          	jal	80000f60 <proc_pagetable>
    80001140:	892a                	mv	s2,a0
    80001142:	e8a8                	sd	a0,80(s1)
    if(p->pagetable == 0){
    80001144:	c921                	beqz	a0,80001194 <allocproc+0xbe>
    memset(&p->context, 0, sizeof(p->context));
    80001146:	07000613          	li	a2,112
    8000114a:	4581                	li	a1,0
    8000114c:	06848513          	addi	a0,s1,104
    80001150:	80eff0ef          	jal	8000015e <memset>
    p->context.ra = (uint64)forkret;
    80001154:	00000797          	auipc	a5,0x0
    80001158:	d9478793          	addi	a5,a5,-620 # 80000ee8 <forkret>
    8000115c:	f4bc                	sd	a5,104(s1)
    p->context.sp = p->kstack + PGSIZE;
    8000115e:	60bc                	ld	a5,64(s1)
    80001160:	6705                	lui	a4,0x1
    80001162:	97ba                	add	a5,a5,a4
    80001164:	f8bc                	sd	a5,112(s1)
}
    80001166:	8526                	mv	a0,s1
    80001168:	60e2                	ld	ra,24(sp)
    8000116a:	6442                	ld	s0,16(sp)
    8000116c:	64a2                	ld	s1,8(sp)
    8000116e:	6902                	ld	s2,0(sp)
    80001170:	6105                	addi	sp,sp,32
    80001172:	8082                	ret
        freeproc(p);
    80001174:	8526                	mv	a0,s1
    80001176:	f11ff0ef          	jal	80001086 <freeproc>
        release(&p->lock);
    8000117a:	8526                	mv	a0,s1
    8000117c:	0f5040ef          	jal	80005a70 <release>
        return 0;
    80001180:	84ca                	mv	s1,s2
    80001182:	b7d5                	j	80001166 <allocproc+0x90>
        freeproc(p);
    80001184:	8526                	mv	a0,s1
    80001186:	f01ff0ef          	jal	80001086 <freeproc>
        release(&p->lock);
    8000118a:	8526                	mv	a0,s1
    8000118c:	0e5040ef          	jal	80005a70 <release>
        return 0;
    80001190:	84ca                	mv	s1,s2
    80001192:	bfd1                	j	80001166 <allocproc+0x90>
        freeproc(p);
    80001194:	8526                	mv	a0,s1
    80001196:	ef1ff0ef          	jal	80001086 <freeproc>
        release(&p->lock);
    8000119a:	8526                	mv	a0,s1
    8000119c:	0d5040ef          	jal	80005a70 <release>
        return 0;
    800011a0:	84ca                	mv	s1,s2
    800011a2:	b7d1                	j	80001166 <allocproc+0x90>

00000000800011a4 <userinit>:
{
    800011a4:	1101                	addi	sp,sp,-32
    800011a6:	ec06                	sd	ra,24(sp)
    800011a8:	e822                	sd	s0,16(sp)
    800011aa:	e426                	sd	s1,8(sp)
    800011ac:	1000                	addi	s0,sp,32
  p = allocproc();
    800011ae:	f29ff0ef          	jal	800010d6 <allocproc>
    800011b2:	84aa                	mv	s1,a0
  initproc = p;
    800011b4:	00006797          	auipc	a5,0x6
    800011b8:	7ca7be23          	sd	a0,2012(a5) # 80007990 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    800011bc:	03400613          	li	a2,52
    800011c0:	00006597          	auipc	a1,0x6
    800011c4:	78058593          	addi	a1,a1,1920 # 80007940 <initcode>
    800011c8:	6928                	ld	a0,80(a0)
    800011ca:	e7aff0ef          	jal	80000844 <uvmfirst>
  p->sz = PGSIZE;
    800011ce:	6785                	lui	a5,0x1
    800011d0:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    800011d2:	6cb8                	ld	a4,88(s1)
    800011d4:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    800011d8:	6cb8                	ld	a4,88(s1)
    800011da:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    800011dc:	4641                	li	a2,16
    800011de:	00006597          	auipc	a1,0x6
    800011e2:	02258593          	addi	a1,a1,34 # 80007200 <etext+0x200>
    800011e6:	16048513          	addi	a0,s1,352
    800011ea:	8c8ff0ef          	jal	800002b2 <safestrcpy>
  p->cwd = namei("/");
    800011ee:	00006517          	auipc	a0,0x6
    800011f2:	02250513          	addi	a0,a0,34 # 80007210 <etext+0x210>
    800011f6:	545010ef          	jal	80002f3a <namei>
    800011fa:	14a4bc23          	sd	a0,344(s1)
  p->state = RUNNABLE;
    800011fe:	478d                	li	a5,3
    80001200:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001202:	8526                	mv	a0,s1
    80001204:	06d040ef          	jal	80005a70 <release>
}
    80001208:	60e2                	ld	ra,24(sp)
    8000120a:	6442                	ld	s0,16(sp)
    8000120c:	64a2                	ld	s1,8(sp)
    8000120e:	6105                	addi	sp,sp,32
    80001210:	8082                	ret

0000000080001212 <growproc>:
{
    80001212:	1101                	addi	sp,sp,-32
    80001214:	ec06                	sd	ra,24(sp)
    80001216:	e822                	sd	s0,16(sp)
    80001218:	e426                	sd	s1,8(sp)
    8000121a:	e04a                	sd	s2,0(sp)
    8000121c:	1000                	addi	s0,sp,32
    8000121e:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001220:	c97ff0ef          	jal	80000eb6 <myproc>
    80001224:	84aa                	mv	s1,a0
  sz = p->sz;
    80001226:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001228:	01204c63          	bgtz	s2,80001240 <growproc+0x2e>
  } else if(n < 0){
    8000122c:	02094463          	bltz	s2,80001254 <growproc+0x42>
  p->sz = sz;
    80001230:	e4ac                	sd	a1,72(s1)
  return 0;
    80001232:	4501                	li	a0,0
}
    80001234:	60e2                	ld	ra,24(sp)
    80001236:	6442                	ld	s0,16(sp)
    80001238:	64a2                	ld	s1,8(sp)
    8000123a:	6902                	ld	s2,0(sp)
    8000123c:	6105                	addi	sp,sp,32
    8000123e:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001240:	4691                	li	a3,4
    80001242:	00b90633          	add	a2,s2,a1
    80001246:	6928                	ld	a0,80(a0)
    80001248:	e9eff0ef          	jal	800008e6 <uvmalloc>
    8000124c:	85aa                	mv	a1,a0
    8000124e:	f16d                	bnez	a0,80001230 <growproc+0x1e>
      return -1;
    80001250:	557d                	li	a0,-1
    80001252:	b7cd                	j	80001234 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001254:	00b90633          	add	a2,s2,a1
    80001258:	6928                	ld	a0,80(a0)
    8000125a:	e48ff0ef          	jal	800008a2 <uvmdealloc>
    8000125e:	85aa                	mv	a1,a0
    80001260:	bfc1                	j	80001230 <growproc+0x1e>

0000000080001262 <fork>:
{
    80001262:	7139                	addi	sp,sp,-64
    80001264:	fc06                	sd	ra,56(sp)
    80001266:	f822                	sd	s0,48(sp)
    80001268:	f426                	sd	s1,40(sp)
    8000126a:	e456                	sd	s5,8(sp)
    8000126c:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    8000126e:	c49ff0ef          	jal	80000eb6 <myproc>
    80001272:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001274:	e63ff0ef          	jal	800010d6 <allocproc>
    80001278:	0e050a63          	beqz	a0,8000136c <fork+0x10a>
    8000127c:	e852                	sd	s4,16(sp)
    8000127e:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001280:	048ab603          	ld	a2,72(s5)
    80001284:	692c                	ld	a1,80(a0)
    80001286:	050ab503          	ld	a0,80(s5)
    8000128a:	f94ff0ef          	jal	80000a1e <uvmcopy>
    8000128e:	04054863          	bltz	a0,800012de <fork+0x7c>
    80001292:	f04a                	sd	s2,32(sp)
    80001294:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001296:	048ab783          	ld	a5,72(s5)
    8000129a:	04fa3423          	sd	a5,72(s4) # 1048 <_entry-0x7fffefb8>
  *(np->trapframe) = *(p->trapframe);
    8000129e:	058ab683          	ld	a3,88(s5)
    800012a2:	87b6                	mv	a5,a3
    800012a4:	058a3703          	ld	a4,88(s4)
    800012a8:	12068693          	addi	a3,a3,288
    800012ac:	6388                	ld	a0,0(a5)
    800012ae:	678c                	ld	a1,8(a5)
    800012b0:	6b90                	ld	a2,16(a5)
    800012b2:	e308                	sd	a0,0(a4)
    800012b4:	e70c                	sd	a1,8(a4)
    800012b6:	eb10                	sd	a2,16(a4)
    800012b8:	6f90                	ld	a2,24(a5)
    800012ba:	ef10                	sd	a2,24(a4)
    800012bc:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    800012c0:	02070713          	addi	a4,a4,32
    800012c4:	fed794e3          	bne	a5,a3,800012ac <fork+0x4a>
  np->trapframe->a0 = 0;
    800012c8:	058a3783          	ld	a5,88(s4)
    800012cc:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    800012d0:	0d8a8493          	addi	s1,s5,216
    800012d4:	0d8a0913          	addi	s2,s4,216
    800012d8:	158a8993          	addi	s3,s5,344
    800012dc:	a831                	j	800012f8 <fork+0x96>
    freeproc(np);
    800012de:	8552                	mv	a0,s4
    800012e0:	da7ff0ef          	jal	80001086 <freeproc>
    release(&np->lock);
    800012e4:	8552                	mv	a0,s4
    800012e6:	78a040ef          	jal	80005a70 <release>
    return -1;
    800012ea:	54fd                	li	s1,-1
    800012ec:	6a42                	ld	s4,16(sp)
    800012ee:	a885                	j	8000135e <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    800012f0:	04a1                	addi	s1,s1,8
    800012f2:	0921                	addi	s2,s2,8
    800012f4:	01348963          	beq	s1,s3,80001306 <fork+0xa4>
    if(p->ofile[i])
    800012f8:	6088                	ld	a0,0(s1)
    800012fa:	d97d                	beqz	a0,800012f0 <fork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    800012fc:	1ec020ef          	jal	800034e8 <filedup>
    80001300:	00a93023          	sd	a0,0(s2)
    80001304:	b7f5                	j	800012f0 <fork+0x8e>
  np->cwd = idup(p->cwd);
    80001306:	158ab503          	ld	a0,344(s5)
    8000130a:	504010ef          	jal	8000280e <idup>
    8000130e:	14aa3c23          	sd	a0,344(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001312:	4641                	li	a2,16
    80001314:	160a8593          	addi	a1,s5,352
    80001318:	160a0513          	addi	a0,s4,352
    8000131c:	f97fe0ef          	jal	800002b2 <safestrcpy>
  pid = np->pid;
    80001320:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001324:	8552                	mv	a0,s4
    80001326:	74a040ef          	jal	80005a70 <release>
  acquire(&wait_lock);
    8000132a:	00006517          	auipc	a0,0x6
    8000132e:	6be50513          	addi	a0,a0,1726 # 800079e8 <wait_lock>
    80001332:	6aa040ef          	jal	800059dc <acquire>
  np->parent = p;
    80001336:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    8000133a:	00006517          	auipc	a0,0x6
    8000133e:	6ae50513          	addi	a0,a0,1710 # 800079e8 <wait_lock>
    80001342:	72e040ef          	jal	80005a70 <release>
  acquire(&np->lock);
    80001346:	8552                	mv	a0,s4
    80001348:	694040ef          	jal	800059dc <acquire>
  np->state = RUNNABLE;
    8000134c:	478d                	li	a5,3
    8000134e:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001352:	8552                	mv	a0,s4
    80001354:	71c040ef          	jal	80005a70 <release>
  return pid;
    80001358:	7902                	ld	s2,32(sp)
    8000135a:	69e2                	ld	s3,24(sp)
    8000135c:	6a42                	ld	s4,16(sp)
}
    8000135e:	8526                	mv	a0,s1
    80001360:	70e2                	ld	ra,56(sp)
    80001362:	7442                	ld	s0,48(sp)
    80001364:	74a2                	ld	s1,40(sp)
    80001366:	6aa2                	ld	s5,8(sp)
    80001368:	6121                	addi	sp,sp,64
    8000136a:	8082                	ret
    return -1;
    8000136c:	54fd                	li	s1,-1
    8000136e:	bfc5                	j	8000135e <fork+0xfc>

0000000080001370 <scheduler>:
{
    80001370:	715d                	addi	sp,sp,-80
    80001372:	e486                	sd	ra,72(sp)
    80001374:	e0a2                	sd	s0,64(sp)
    80001376:	fc26                	sd	s1,56(sp)
    80001378:	f84a                	sd	s2,48(sp)
    8000137a:	f44e                	sd	s3,40(sp)
    8000137c:	f052                	sd	s4,32(sp)
    8000137e:	ec56                	sd	s5,24(sp)
    80001380:	e85a                	sd	s6,16(sp)
    80001382:	e45e                	sd	s7,8(sp)
    80001384:	e062                	sd	s8,0(sp)
    80001386:	0880                	addi	s0,sp,80
    80001388:	8792                	mv	a5,tp
  int id = r_tp();
    8000138a:	2781                	sext.w	a5,a5
  c->proc = 0;
    8000138c:	00779b13          	slli	s6,a5,0x7
    80001390:	00006717          	auipc	a4,0x6
    80001394:	64070713          	addi	a4,a4,1600 # 800079d0 <pid_lock>
    80001398:	975a                	add	a4,a4,s6
    8000139a:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    8000139e:	00006717          	auipc	a4,0x6
    800013a2:	66a70713          	addi	a4,a4,1642 # 80007a08 <cpus+0x8>
    800013a6:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    800013a8:	4c11                	li	s8,4
        c->proc = p;
    800013aa:	079e                	slli	a5,a5,0x7
    800013ac:	00006a17          	auipc	s4,0x6
    800013b0:	624a0a13          	addi	s4,s4,1572 # 800079d0 <pid_lock>
    800013b4:	9a3e                	add	s4,s4,a5
        found = 1;
    800013b6:	4b85                	li	s7,1
    800013b8:	a0a9                	j	80001402 <scheduler+0x92>
      release(&p->lock);
    800013ba:	8526                	mv	a0,s1
    800013bc:	6b4040ef          	jal	80005a70 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    800013c0:	17048493          	addi	s1,s1,368
    800013c4:	03248563          	beq	s1,s2,800013ee <scheduler+0x7e>
      acquire(&p->lock);
    800013c8:	8526                	mv	a0,s1
    800013ca:	612040ef          	jal	800059dc <acquire>
      if(p->state == RUNNABLE) {
    800013ce:	4c9c                	lw	a5,24(s1)
    800013d0:	ff3795e3          	bne	a5,s3,800013ba <scheduler+0x4a>
        p->state = RUNNING;
    800013d4:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    800013d8:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    800013dc:	06848593          	addi	a1,s1,104
    800013e0:	855a                	mv	a0,s6
    800013e2:	5bc000ef          	jal	8000199e <swtch>
        c->proc = 0;
    800013e6:	020a3823          	sd	zero,48(s4)
        found = 1;
    800013ea:	8ade                	mv	s5,s7
    800013ec:	b7f9                	j	800013ba <scheduler+0x4a>
    if(found == 0) {
    800013ee:	000a9a63          	bnez	s5,80001402 <scheduler+0x92>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800013f2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800013f6:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800013fa:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    800013fe:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001402:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001406:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000140a:	10079073          	csrw	sstatus,a5
    int found = 0;
    8000140e:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001410:	00007497          	auipc	s1,0x7
    80001414:	9f048493          	addi	s1,s1,-1552 # 80007e00 <proc>
      if(p->state == RUNNABLE) {
    80001418:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    8000141a:	0000c917          	auipc	s2,0xc
    8000141e:	5e690913          	addi	s2,s2,1510 # 8000da00 <tickslock>
    80001422:	b75d                	j	800013c8 <scheduler+0x58>

0000000080001424 <sched>:
{
    80001424:	7179                	addi	sp,sp,-48
    80001426:	f406                	sd	ra,40(sp)
    80001428:	f022                	sd	s0,32(sp)
    8000142a:	ec26                	sd	s1,24(sp)
    8000142c:	e84a                	sd	s2,16(sp)
    8000142e:	e44e                	sd	s3,8(sp)
    80001430:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001432:	a85ff0ef          	jal	80000eb6 <myproc>
    80001436:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001438:	534040ef          	jal	8000596c <holding>
    8000143c:	c935                	beqz	a0,800014b0 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000143e:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001440:	2781                	sext.w	a5,a5
    80001442:	079e                	slli	a5,a5,0x7
    80001444:	00006717          	auipc	a4,0x6
    80001448:	58c70713          	addi	a4,a4,1420 # 800079d0 <pid_lock>
    8000144c:	97ba                	add	a5,a5,a4
    8000144e:	0a87a703          	lw	a4,168(a5)
    80001452:	4785                	li	a5,1
    80001454:	06f71463          	bne	a4,a5,800014bc <sched+0x98>
  if(p->state == RUNNING)
    80001458:	4c98                	lw	a4,24(s1)
    8000145a:	4791                	li	a5,4
    8000145c:	06f70663          	beq	a4,a5,800014c8 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001460:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001464:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001466:	e7bd                	bnez	a5,800014d4 <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001468:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    8000146a:	00006917          	auipc	s2,0x6
    8000146e:	56690913          	addi	s2,s2,1382 # 800079d0 <pid_lock>
    80001472:	2781                	sext.w	a5,a5
    80001474:	079e                	slli	a5,a5,0x7
    80001476:	97ca                	add	a5,a5,s2
    80001478:	0ac7a983          	lw	s3,172(a5)
    8000147c:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    8000147e:	2781                	sext.w	a5,a5
    80001480:	079e                	slli	a5,a5,0x7
    80001482:	07a1                	addi	a5,a5,8
    80001484:	00006597          	auipc	a1,0x6
    80001488:	57c58593          	addi	a1,a1,1404 # 80007a00 <cpus>
    8000148c:	95be                	add	a1,a1,a5
    8000148e:	06848513          	addi	a0,s1,104
    80001492:	50c000ef          	jal	8000199e <swtch>
    80001496:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001498:	2781                	sext.w	a5,a5
    8000149a:	079e                	slli	a5,a5,0x7
    8000149c:	993e                	add	s2,s2,a5
    8000149e:	0b392623          	sw	s3,172(s2)
}
    800014a2:	70a2                	ld	ra,40(sp)
    800014a4:	7402                	ld	s0,32(sp)
    800014a6:	64e2                	ld	s1,24(sp)
    800014a8:	6942                	ld	s2,16(sp)
    800014aa:	69a2                	ld	s3,8(sp)
    800014ac:	6145                	addi	sp,sp,48
    800014ae:	8082                	ret
    panic("sched p->lock");
    800014b0:	00006517          	auipc	a0,0x6
    800014b4:	d6850513          	addi	a0,a0,-664 # 80007218 <etext+0x218>
    800014b8:	1e6040ef          	jal	8000569e <panic>
    panic("sched locks");
    800014bc:	00006517          	auipc	a0,0x6
    800014c0:	d6c50513          	addi	a0,a0,-660 # 80007228 <etext+0x228>
    800014c4:	1da040ef          	jal	8000569e <panic>
    panic("sched running");
    800014c8:	00006517          	auipc	a0,0x6
    800014cc:	d7050513          	addi	a0,a0,-656 # 80007238 <etext+0x238>
    800014d0:	1ce040ef          	jal	8000569e <panic>
    panic("sched interruptible");
    800014d4:	00006517          	auipc	a0,0x6
    800014d8:	d7450513          	addi	a0,a0,-652 # 80007248 <etext+0x248>
    800014dc:	1c2040ef          	jal	8000569e <panic>

00000000800014e0 <yield>:
{
    800014e0:	1101                	addi	sp,sp,-32
    800014e2:	ec06                	sd	ra,24(sp)
    800014e4:	e822                	sd	s0,16(sp)
    800014e6:	e426                	sd	s1,8(sp)
    800014e8:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800014ea:	9cdff0ef          	jal	80000eb6 <myproc>
    800014ee:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800014f0:	4ec040ef          	jal	800059dc <acquire>
  p->state = RUNNABLE;
    800014f4:	478d                	li	a5,3
    800014f6:	cc9c                	sw	a5,24(s1)
  sched();
    800014f8:	f2dff0ef          	jal	80001424 <sched>
  release(&p->lock);
    800014fc:	8526                	mv	a0,s1
    800014fe:	572040ef          	jal	80005a70 <release>
}
    80001502:	60e2                	ld	ra,24(sp)
    80001504:	6442                	ld	s0,16(sp)
    80001506:	64a2                	ld	s1,8(sp)
    80001508:	6105                	addi	sp,sp,32
    8000150a:	8082                	ret

000000008000150c <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    8000150c:	7179                	addi	sp,sp,-48
    8000150e:	f406                	sd	ra,40(sp)
    80001510:	f022                	sd	s0,32(sp)
    80001512:	ec26                	sd	s1,24(sp)
    80001514:	e84a                	sd	s2,16(sp)
    80001516:	e44e                	sd	s3,8(sp)
    80001518:	1800                	addi	s0,sp,48
    8000151a:	89aa                	mv	s3,a0
    8000151c:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000151e:	999ff0ef          	jal	80000eb6 <myproc>
    80001522:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001524:	4b8040ef          	jal	800059dc <acquire>
  release(lk);
    80001528:	854a                	mv	a0,s2
    8000152a:	546040ef          	jal	80005a70 <release>

  // Go to sleep.
  p->chan = chan;
    8000152e:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001532:	4789                	li	a5,2
    80001534:	cc9c                	sw	a5,24(s1)

  sched();
    80001536:	eefff0ef          	jal	80001424 <sched>

  // Tidy up.
  p->chan = 0;
    8000153a:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    8000153e:	8526                	mv	a0,s1
    80001540:	530040ef          	jal	80005a70 <release>
  acquire(lk);
    80001544:	854a                	mv	a0,s2
    80001546:	496040ef          	jal	800059dc <acquire>
}
    8000154a:	70a2                	ld	ra,40(sp)
    8000154c:	7402                	ld	s0,32(sp)
    8000154e:	64e2                	ld	s1,24(sp)
    80001550:	6942                	ld	s2,16(sp)
    80001552:	69a2                	ld	s3,8(sp)
    80001554:	6145                	addi	sp,sp,48
    80001556:	8082                	ret

0000000080001558 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    80001558:	7139                	addi	sp,sp,-64
    8000155a:	fc06                	sd	ra,56(sp)
    8000155c:	f822                	sd	s0,48(sp)
    8000155e:	f426                	sd	s1,40(sp)
    80001560:	f04a                	sd	s2,32(sp)
    80001562:	ec4e                	sd	s3,24(sp)
    80001564:	e852                	sd	s4,16(sp)
    80001566:	e456                	sd	s5,8(sp)
    80001568:	0080                	addi	s0,sp,64
    8000156a:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    8000156c:	00007497          	auipc	s1,0x7
    80001570:	89448493          	addi	s1,s1,-1900 # 80007e00 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001574:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001576:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001578:	0000c917          	auipc	s2,0xc
    8000157c:	48890913          	addi	s2,s2,1160 # 8000da00 <tickslock>
    80001580:	a801                	j	80001590 <wakeup+0x38>
      }
      release(&p->lock);
    80001582:	8526                	mv	a0,s1
    80001584:	4ec040ef          	jal	80005a70 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001588:	17048493          	addi	s1,s1,368
    8000158c:	03248263          	beq	s1,s2,800015b0 <wakeup+0x58>
    if(p != myproc()){
    80001590:	927ff0ef          	jal	80000eb6 <myproc>
    80001594:	fe950ae3          	beq	a0,s1,80001588 <wakeup+0x30>
      acquire(&p->lock);
    80001598:	8526                	mv	a0,s1
    8000159a:	442040ef          	jal	800059dc <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    8000159e:	4c9c                	lw	a5,24(s1)
    800015a0:	ff3791e3          	bne	a5,s3,80001582 <wakeup+0x2a>
    800015a4:	709c                	ld	a5,32(s1)
    800015a6:	fd479ee3          	bne	a5,s4,80001582 <wakeup+0x2a>
        p->state = RUNNABLE;
    800015aa:	0154ac23          	sw	s5,24(s1)
    800015ae:	bfd1                	j	80001582 <wakeup+0x2a>
    }
  }
}
    800015b0:	70e2                	ld	ra,56(sp)
    800015b2:	7442                	ld	s0,48(sp)
    800015b4:	74a2                	ld	s1,40(sp)
    800015b6:	7902                	ld	s2,32(sp)
    800015b8:	69e2                	ld	s3,24(sp)
    800015ba:	6a42                	ld	s4,16(sp)
    800015bc:	6aa2                	ld	s5,8(sp)
    800015be:	6121                	addi	sp,sp,64
    800015c0:	8082                	ret

00000000800015c2 <reparent>:
{
    800015c2:	7179                	addi	sp,sp,-48
    800015c4:	f406                	sd	ra,40(sp)
    800015c6:	f022                	sd	s0,32(sp)
    800015c8:	ec26                	sd	s1,24(sp)
    800015ca:	e84a                	sd	s2,16(sp)
    800015cc:	e44e                	sd	s3,8(sp)
    800015ce:	e052                	sd	s4,0(sp)
    800015d0:	1800                	addi	s0,sp,48
    800015d2:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800015d4:	00007497          	auipc	s1,0x7
    800015d8:	82c48493          	addi	s1,s1,-2004 # 80007e00 <proc>
      pp->parent = initproc;
    800015dc:	00006a17          	auipc	s4,0x6
    800015e0:	3b4a0a13          	addi	s4,s4,948 # 80007990 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800015e4:	0000c997          	auipc	s3,0xc
    800015e8:	41c98993          	addi	s3,s3,1052 # 8000da00 <tickslock>
    800015ec:	a029                	j	800015f6 <reparent+0x34>
    800015ee:	17048493          	addi	s1,s1,368
    800015f2:	01348b63          	beq	s1,s3,80001608 <reparent+0x46>
    if(pp->parent == p){
    800015f6:	7c9c                	ld	a5,56(s1)
    800015f8:	ff279be3          	bne	a5,s2,800015ee <reparent+0x2c>
      pp->parent = initproc;
    800015fc:	000a3503          	ld	a0,0(s4)
    80001600:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001602:	f57ff0ef          	jal	80001558 <wakeup>
    80001606:	b7e5                	j	800015ee <reparent+0x2c>
}
    80001608:	70a2                	ld	ra,40(sp)
    8000160a:	7402                	ld	s0,32(sp)
    8000160c:	64e2                	ld	s1,24(sp)
    8000160e:	6942                	ld	s2,16(sp)
    80001610:	69a2                	ld	s3,8(sp)
    80001612:	6a02                	ld	s4,0(sp)
    80001614:	6145                	addi	sp,sp,48
    80001616:	8082                	ret

0000000080001618 <exit>:
{
    80001618:	7179                	addi	sp,sp,-48
    8000161a:	f406                	sd	ra,40(sp)
    8000161c:	f022                	sd	s0,32(sp)
    8000161e:	ec26                	sd	s1,24(sp)
    80001620:	e84a                	sd	s2,16(sp)
    80001622:	e44e                	sd	s3,8(sp)
    80001624:	e052                	sd	s4,0(sp)
    80001626:	1800                	addi	s0,sp,48
    80001628:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000162a:	88dff0ef          	jal	80000eb6 <myproc>
    8000162e:	89aa                	mv	s3,a0
  if(p == initproc)
    80001630:	00006797          	auipc	a5,0x6
    80001634:	3607b783          	ld	a5,864(a5) # 80007990 <initproc>
    80001638:	0d850493          	addi	s1,a0,216
    8000163c:	15850913          	addi	s2,a0,344
    80001640:	00a79b63          	bne	a5,a0,80001656 <exit+0x3e>
    panic("init exiting");
    80001644:	00006517          	auipc	a0,0x6
    80001648:	c1c50513          	addi	a0,a0,-996 # 80007260 <etext+0x260>
    8000164c:	052040ef          	jal	8000569e <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80001650:	04a1                	addi	s1,s1,8
    80001652:	01248963          	beq	s1,s2,80001664 <exit+0x4c>
    if(p->ofile[fd]){
    80001656:	6088                	ld	a0,0(s1)
    80001658:	dd65                	beqz	a0,80001650 <exit+0x38>
      fileclose(f);
    8000165a:	6d5010ef          	jal	8000352e <fileclose>
      p->ofile[fd] = 0;
    8000165e:	0004b023          	sd	zero,0(s1)
    80001662:	b7fd                	j	80001650 <exit+0x38>
  begin_op();
    80001664:	299010ef          	jal	800030fc <begin_op>
  iput(p->cwd);
    80001668:	1589b503          	ld	a0,344(s3)
    8000166c:	35a010ef          	jal	800029c6 <iput>
  end_op();
    80001670:	2fd010ef          	jal	8000316c <end_op>
  p->cwd = 0;
    80001674:	1409bc23          	sd	zero,344(s3)
  acquire(&wait_lock);
    80001678:	00006517          	auipc	a0,0x6
    8000167c:	37050513          	addi	a0,a0,880 # 800079e8 <wait_lock>
    80001680:	35c040ef          	jal	800059dc <acquire>
  reparent(p);
    80001684:	854e                	mv	a0,s3
    80001686:	f3dff0ef          	jal	800015c2 <reparent>
  wakeup(p->parent);
    8000168a:	0389b503          	ld	a0,56(s3)
    8000168e:	ecbff0ef          	jal	80001558 <wakeup>
  acquire(&p->lock);
    80001692:	854e                	mv	a0,s3
    80001694:	348040ef          	jal	800059dc <acquire>
  p->xstate = status;
    80001698:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    8000169c:	4795                	li	a5,5
    8000169e:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800016a2:	00006517          	auipc	a0,0x6
    800016a6:	34650513          	addi	a0,a0,838 # 800079e8 <wait_lock>
    800016aa:	3c6040ef          	jal	80005a70 <release>
  sched();
    800016ae:	d77ff0ef          	jal	80001424 <sched>
  panic("zombie exit");
    800016b2:	00006517          	auipc	a0,0x6
    800016b6:	bbe50513          	addi	a0,a0,-1090 # 80007270 <etext+0x270>
    800016ba:	7e5030ef          	jal	8000569e <panic>

00000000800016be <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    800016be:	7179                	addi	sp,sp,-48
    800016c0:	f406                	sd	ra,40(sp)
    800016c2:	f022                	sd	s0,32(sp)
    800016c4:	ec26                	sd	s1,24(sp)
    800016c6:	e84a                	sd	s2,16(sp)
    800016c8:	e44e                	sd	s3,8(sp)
    800016ca:	1800                	addi	s0,sp,48
    800016cc:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800016ce:	00006497          	auipc	s1,0x6
    800016d2:	73248493          	addi	s1,s1,1842 # 80007e00 <proc>
    800016d6:	0000c997          	auipc	s3,0xc
    800016da:	32a98993          	addi	s3,s3,810 # 8000da00 <tickslock>
    acquire(&p->lock);
    800016de:	8526                	mv	a0,s1
    800016e0:	2fc040ef          	jal	800059dc <acquire>
    if(p->pid == pid){
    800016e4:	589c                	lw	a5,48(s1)
    800016e6:	01278b63          	beq	a5,s2,800016fc <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800016ea:	8526                	mv	a0,s1
    800016ec:	384040ef          	jal	80005a70 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800016f0:	17048493          	addi	s1,s1,368
    800016f4:	ff3495e3          	bne	s1,s3,800016de <kill+0x20>
  }
  return -1;
    800016f8:	557d                	li	a0,-1
    800016fa:	a819                	j	80001710 <kill+0x52>
      p->killed = 1;
    800016fc:	4785                	li	a5,1
    800016fe:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80001700:	4c98                	lw	a4,24(s1)
    80001702:	4789                	li	a5,2
    80001704:	00f70d63          	beq	a4,a5,8000171e <kill+0x60>
      release(&p->lock);
    80001708:	8526                	mv	a0,s1
    8000170a:	366040ef          	jal	80005a70 <release>
      return 0;
    8000170e:	4501                	li	a0,0
}
    80001710:	70a2                	ld	ra,40(sp)
    80001712:	7402                	ld	s0,32(sp)
    80001714:	64e2                	ld	s1,24(sp)
    80001716:	6942                	ld	s2,16(sp)
    80001718:	69a2                	ld	s3,8(sp)
    8000171a:	6145                	addi	sp,sp,48
    8000171c:	8082                	ret
        p->state = RUNNABLE;
    8000171e:	478d                	li	a5,3
    80001720:	cc9c                	sw	a5,24(s1)
    80001722:	b7dd                	j	80001708 <kill+0x4a>

0000000080001724 <setkilled>:

void
setkilled(struct proc *p)
{
    80001724:	1101                	addi	sp,sp,-32
    80001726:	ec06                	sd	ra,24(sp)
    80001728:	e822                	sd	s0,16(sp)
    8000172a:	e426                	sd	s1,8(sp)
    8000172c:	1000                	addi	s0,sp,32
    8000172e:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001730:	2ac040ef          	jal	800059dc <acquire>
  p->killed = 1;
    80001734:	4785                	li	a5,1
    80001736:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80001738:	8526                	mv	a0,s1
    8000173a:	336040ef          	jal	80005a70 <release>
}
    8000173e:	60e2                	ld	ra,24(sp)
    80001740:	6442                	ld	s0,16(sp)
    80001742:	64a2                	ld	s1,8(sp)
    80001744:	6105                	addi	sp,sp,32
    80001746:	8082                	ret

0000000080001748 <killed>:

int
killed(struct proc *p)
{
    80001748:	1101                	addi	sp,sp,-32
    8000174a:	ec06                	sd	ra,24(sp)
    8000174c:	e822                	sd	s0,16(sp)
    8000174e:	e426                	sd	s1,8(sp)
    80001750:	e04a                	sd	s2,0(sp)
    80001752:	1000                	addi	s0,sp,32
    80001754:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80001756:	286040ef          	jal	800059dc <acquire>
  k = p->killed;
    8000175a:	549c                	lw	a5,40(s1)
    8000175c:	893e                	mv	s2,a5
  release(&p->lock);
    8000175e:	8526                	mv	a0,s1
    80001760:	310040ef          	jal	80005a70 <release>
  return k;
}
    80001764:	854a                	mv	a0,s2
    80001766:	60e2                	ld	ra,24(sp)
    80001768:	6442                	ld	s0,16(sp)
    8000176a:	64a2                	ld	s1,8(sp)
    8000176c:	6902                	ld	s2,0(sp)
    8000176e:	6105                	addi	sp,sp,32
    80001770:	8082                	ret

0000000080001772 <wait>:
{
    80001772:	715d                	addi	sp,sp,-80
    80001774:	e486                	sd	ra,72(sp)
    80001776:	e0a2                	sd	s0,64(sp)
    80001778:	fc26                	sd	s1,56(sp)
    8000177a:	f84a                	sd	s2,48(sp)
    8000177c:	f44e                	sd	s3,40(sp)
    8000177e:	f052                	sd	s4,32(sp)
    80001780:	ec56                	sd	s5,24(sp)
    80001782:	e85a                	sd	s6,16(sp)
    80001784:	e45e                	sd	s7,8(sp)
    80001786:	0880                	addi	s0,sp,80
    80001788:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    8000178a:	f2cff0ef          	jal	80000eb6 <myproc>
    8000178e:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80001790:	00006517          	auipc	a0,0x6
    80001794:	25850513          	addi	a0,a0,600 # 800079e8 <wait_lock>
    80001798:	244040ef          	jal	800059dc <acquire>
        if(pp->state == ZOMBIE){
    8000179c:	4a15                	li	s4,5
        havekids = 1;
    8000179e:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800017a0:	0000c997          	auipc	s3,0xc
    800017a4:	26098993          	addi	s3,s3,608 # 8000da00 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800017a8:	00006b17          	auipc	s6,0x6
    800017ac:	240b0b13          	addi	s6,s6,576 # 800079e8 <wait_lock>
    800017b0:	a869                	j	8000184a <wait+0xd8>
          pid = pp->pid;
    800017b2:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800017b6:	000b8c63          	beqz	s7,800017ce <wait+0x5c>
    800017ba:	4691                	li	a3,4
    800017bc:	02c48613          	addi	a2,s1,44
    800017c0:	85de                	mv	a1,s7
    800017c2:	05093503          	ld	a0,80(s2)
    800017c6:	b30ff0ef          	jal	80000af6 <copyout>
    800017ca:	02054a63          	bltz	a0,800017fe <wait+0x8c>
          freeproc(pp);
    800017ce:	8526                	mv	a0,s1
    800017d0:	8b7ff0ef          	jal	80001086 <freeproc>
          release(&pp->lock);
    800017d4:	8526                	mv	a0,s1
    800017d6:	29a040ef          	jal	80005a70 <release>
          release(&wait_lock);
    800017da:	00006517          	auipc	a0,0x6
    800017de:	20e50513          	addi	a0,a0,526 # 800079e8 <wait_lock>
    800017e2:	28e040ef          	jal	80005a70 <release>
}
    800017e6:	854e                	mv	a0,s3
    800017e8:	60a6                	ld	ra,72(sp)
    800017ea:	6406                	ld	s0,64(sp)
    800017ec:	74e2                	ld	s1,56(sp)
    800017ee:	7942                	ld	s2,48(sp)
    800017f0:	79a2                	ld	s3,40(sp)
    800017f2:	7a02                	ld	s4,32(sp)
    800017f4:	6ae2                	ld	s5,24(sp)
    800017f6:	6b42                	ld	s6,16(sp)
    800017f8:	6ba2                	ld	s7,8(sp)
    800017fa:	6161                	addi	sp,sp,80
    800017fc:	8082                	ret
            release(&pp->lock);
    800017fe:	8526                	mv	a0,s1
    80001800:	270040ef          	jal	80005a70 <release>
            release(&wait_lock);
    80001804:	00006517          	auipc	a0,0x6
    80001808:	1e450513          	addi	a0,a0,484 # 800079e8 <wait_lock>
    8000180c:	264040ef          	jal	80005a70 <release>
            return -1;
    80001810:	59fd                	li	s3,-1
    80001812:	bfd1                	j	800017e6 <wait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001814:	17048493          	addi	s1,s1,368
    80001818:	03348063          	beq	s1,s3,80001838 <wait+0xc6>
      if(pp->parent == p){
    8000181c:	7c9c                	ld	a5,56(s1)
    8000181e:	ff279be3          	bne	a5,s2,80001814 <wait+0xa2>
        acquire(&pp->lock);
    80001822:	8526                	mv	a0,s1
    80001824:	1b8040ef          	jal	800059dc <acquire>
        if(pp->state == ZOMBIE){
    80001828:	4c9c                	lw	a5,24(s1)
    8000182a:	f94784e3          	beq	a5,s4,800017b2 <wait+0x40>
        release(&pp->lock);
    8000182e:	8526                	mv	a0,s1
    80001830:	240040ef          	jal	80005a70 <release>
        havekids = 1;
    80001834:	8756                	mv	a4,s5
    80001836:	bff9                	j	80001814 <wait+0xa2>
    if(!havekids || killed(p)){
    80001838:	cf19                	beqz	a4,80001856 <wait+0xe4>
    8000183a:	854a                	mv	a0,s2
    8000183c:	f0dff0ef          	jal	80001748 <killed>
    80001840:	e919                	bnez	a0,80001856 <wait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80001842:	85da                	mv	a1,s6
    80001844:	854a                	mv	a0,s2
    80001846:	cc7ff0ef          	jal	8000150c <sleep>
    havekids = 0;
    8000184a:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000184c:	00006497          	auipc	s1,0x6
    80001850:	5b448493          	addi	s1,s1,1460 # 80007e00 <proc>
    80001854:	b7e1                	j	8000181c <wait+0xaa>
      release(&wait_lock);
    80001856:	00006517          	auipc	a0,0x6
    8000185a:	19250513          	addi	a0,a0,402 # 800079e8 <wait_lock>
    8000185e:	212040ef          	jal	80005a70 <release>
      return -1;
    80001862:	59fd                	li	s3,-1
    80001864:	b749                	j	800017e6 <wait+0x74>

0000000080001866 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80001866:	7179                	addi	sp,sp,-48
    80001868:	f406                	sd	ra,40(sp)
    8000186a:	f022                	sd	s0,32(sp)
    8000186c:	ec26                	sd	s1,24(sp)
    8000186e:	e84a                	sd	s2,16(sp)
    80001870:	e44e                	sd	s3,8(sp)
    80001872:	e052                	sd	s4,0(sp)
    80001874:	1800                	addi	s0,sp,48
    80001876:	84aa                	mv	s1,a0
    80001878:	8a2e                	mv	s4,a1
    8000187a:	89b2                	mv	s3,a2
    8000187c:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000187e:	e38ff0ef          	jal	80000eb6 <myproc>
  if(user_dst){
    80001882:	cc99                	beqz	s1,800018a0 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80001884:	86ca                	mv	a3,s2
    80001886:	864e                	mv	a2,s3
    80001888:	85d2                	mv	a1,s4
    8000188a:	6928                	ld	a0,80(a0)
    8000188c:	a6aff0ef          	jal	80000af6 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80001890:	70a2                	ld	ra,40(sp)
    80001892:	7402                	ld	s0,32(sp)
    80001894:	64e2                	ld	s1,24(sp)
    80001896:	6942                	ld	s2,16(sp)
    80001898:	69a2                	ld	s3,8(sp)
    8000189a:	6a02                	ld	s4,0(sp)
    8000189c:	6145                	addi	sp,sp,48
    8000189e:	8082                	ret
    memmove((char *)dst, src, len);
    800018a0:	0009061b          	sext.w	a2,s2
    800018a4:	85ce                	mv	a1,s3
    800018a6:	8552                	mv	a0,s4
    800018a8:	917fe0ef          	jal	800001be <memmove>
    return 0;
    800018ac:	8526                	mv	a0,s1
    800018ae:	b7cd                	j	80001890 <either_copyout+0x2a>

00000000800018b0 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800018b0:	7179                	addi	sp,sp,-48
    800018b2:	f406                	sd	ra,40(sp)
    800018b4:	f022                	sd	s0,32(sp)
    800018b6:	ec26                	sd	s1,24(sp)
    800018b8:	e84a                	sd	s2,16(sp)
    800018ba:	e44e                	sd	s3,8(sp)
    800018bc:	e052                	sd	s4,0(sp)
    800018be:	1800                	addi	s0,sp,48
    800018c0:	8a2a                	mv	s4,a0
    800018c2:	84ae                	mv	s1,a1
    800018c4:	89b2                	mv	s3,a2
    800018c6:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800018c8:	deeff0ef          	jal	80000eb6 <myproc>
  if(user_src){
    800018cc:	cc99                	beqz	s1,800018ea <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800018ce:	86ca                	mv	a3,s2
    800018d0:	864e                	mv	a2,s3
    800018d2:	85d2                	mv	a1,s4
    800018d4:	6928                	ld	a0,80(a0)
    800018d6:	ad0ff0ef          	jal	80000ba6 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800018da:	70a2                	ld	ra,40(sp)
    800018dc:	7402                	ld	s0,32(sp)
    800018de:	64e2                	ld	s1,24(sp)
    800018e0:	6942                	ld	s2,16(sp)
    800018e2:	69a2                	ld	s3,8(sp)
    800018e4:	6a02                	ld	s4,0(sp)
    800018e6:	6145                	addi	sp,sp,48
    800018e8:	8082                	ret
    memmove(dst, (char*)src, len);
    800018ea:	0009061b          	sext.w	a2,s2
    800018ee:	85ce                	mv	a1,s3
    800018f0:	8552                	mv	a0,s4
    800018f2:	8cdfe0ef          	jal	800001be <memmove>
    return 0;
    800018f6:	8526                	mv	a0,s1
    800018f8:	b7cd                	j	800018da <either_copyin+0x2a>

00000000800018fa <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800018fa:	715d                	addi	sp,sp,-80
    800018fc:	e486                	sd	ra,72(sp)
    800018fe:	e0a2                	sd	s0,64(sp)
    80001900:	fc26                	sd	s1,56(sp)
    80001902:	f84a                	sd	s2,48(sp)
    80001904:	f44e                	sd	s3,40(sp)
    80001906:	f052                	sd	s4,32(sp)
    80001908:	ec56                	sd	s5,24(sp)
    8000190a:	e85a                	sd	s6,16(sp)
    8000190c:	e45e                	sd	s7,8(sp)
    8000190e:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80001910:	00005517          	auipc	a0,0x5
    80001914:	70850513          	addi	a0,a0,1800 # 80007018 <etext+0x18>
    80001918:	277030ef          	jal	8000538e <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000191c:	00006497          	auipc	s1,0x6
    80001920:	64448493          	addi	s1,s1,1604 # 80007f60 <proc+0x160>
    80001924:	0000c917          	auipc	s2,0xc
    80001928:	23c90913          	addi	s2,s2,572 # 8000db60 <bcache+0x148>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000192c:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    8000192e:	00006997          	auipc	s3,0x6
    80001932:	95298993          	addi	s3,s3,-1710 # 80007280 <etext+0x280>
    printf("%d %s %s", p->pid, state, p->name);
    80001936:	00006a97          	auipc	s5,0x6
    8000193a:	952a8a93          	addi	s5,s5,-1710 # 80007288 <etext+0x288>
    printf("\n");
    8000193e:	00005a17          	auipc	s4,0x5
    80001942:	6daa0a13          	addi	s4,s4,1754 # 80007018 <etext+0x18>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001946:	00006b97          	auipc	s7,0x6
    8000194a:	e6ab8b93          	addi	s7,s7,-406 # 800077b0 <states.0>
    8000194e:	a829                	j	80001968 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80001950:	ed06a583          	lw	a1,-304(a3)
    80001954:	8556                	mv	a0,s5
    80001956:	239030ef          	jal	8000538e <printf>
    printf("\n");
    8000195a:	8552                	mv	a0,s4
    8000195c:	233030ef          	jal	8000538e <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001960:	17048493          	addi	s1,s1,368
    80001964:	03248263          	beq	s1,s2,80001988 <procdump+0x8e>
    if(p->state == UNUSED)
    80001968:	86a6                	mv	a3,s1
    8000196a:	eb84a783          	lw	a5,-328(s1)
    8000196e:	dbed                	beqz	a5,80001960 <procdump+0x66>
      state = "???";
    80001970:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001972:	fcfb6fe3          	bltu	s6,a5,80001950 <procdump+0x56>
    80001976:	02079713          	slli	a4,a5,0x20
    8000197a:	01d75793          	srli	a5,a4,0x1d
    8000197e:	97de                	add	a5,a5,s7
    80001980:	6390                	ld	a2,0(a5)
    80001982:	f679                	bnez	a2,80001950 <procdump+0x56>
      state = "???";
    80001984:	864e                	mv	a2,s3
    80001986:	b7e9                	j	80001950 <procdump+0x56>
  }
}
    80001988:	60a6                	ld	ra,72(sp)
    8000198a:	6406                	ld	s0,64(sp)
    8000198c:	74e2                	ld	s1,56(sp)
    8000198e:	7942                	ld	s2,48(sp)
    80001990:	79a2                	ld	s3,40(sp)
    80001992:	7a02                	ld	s4,32(sp)
    80001994:	6ae2                	ld	s5,24(sp)
    80001996:	6b42                	ld	s6,16(sp)
    80001998:	6ba2                	ld	s7,8(sp)
    8000199a:	6161                	addi	sp,sp,80
    8000199c:	8082                	ret

000000008000199e <swtch>:
    8000199e:	00153023          	sd	ra,0(a0)
    800019a2:	00253423          	sd	sp,8(a0)
    800019a6:	e900                	sd	s0,16(a0)
    800019a8:	ed04                	sd	s1,24(a0)
    800019aa:	03253023          	sd	s2,32(a0)
    800019ae:	03353423          	sd	s3,40(a0)
    800019b2:	03453823          	sd	s4,48(a0)
    800019b6:	03553c23          	sd	s5,56(a0)
    800019ba:	05653023          	sd	s6,64(a0)
    800019be:	05753423          	sd	s7,72(a0)
    800019c2:	05853823          	sd	s8,80(a0)
    800019c6:	05953c23          	sd	s9,88(a0)
    800019ca:	07a53023          	sd	s10,96(a0)
    800019ce:	07b53423          	sd	s11,104(a0)
    800019d2:	0005b083          	ld	ra,0(a1)
    800019d6:	0085b103          	ld	sp,8(a1)
    800019da:	6980                	ld	s0,16(a1)
    800019dc:	6d84                	ld	s1,24(a1)
    800019de:	0205b903          	ld	s2,32(a1)
    800019e2:	0285b983          	ld	s3,40(a1)
    800019e6:	0305ba03          	ld	s4,48(a1)
    800019ea:	0385ba83          	ld	s5,56(a1)
    800019ee:	0405bb03          	ld	s6,64(a1)
    800019f2:	0485bb83          	ld	s7,72(a1)
    800019f6:	0505bc03          	ld	s8,80(a1)
    800019fa:	0585bc83          	ld	s9,88(a1)
    800019fe:	0605bd03          	ld	s10,96(a1)
    80001a02:	0685bd83          	ld	s11,104(a1)
    80001a06:	8082                	ret

0000000080001a08 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001a08:	1141                	addi	sp,sp,-16
    80001a0a:	e406                	sd	ra,8(sp)
    80001a0c:	e022                	sd	s0,0(sp)
    80001a0e:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001a10:	00006597          	auipc	a1,0x6
    80001a14:	8b858593          	addi	a1,a1,-1864 # 800072c8 <etext+0x2c8>
    80001a18:	0000c517          	auipc	a0,0xc
    80001a1c:	fe850513          	addi	a0,a0,-24 # 8000da00 <tickslock>
    80001a20:	733030ef          	jal	80005952 <initlock>
}
    80001a24:	60a2                	ld	ra,8(sp)
    80001a26:	6402                	ld	s0,0(sp)
    80001a28:	0141                	addi	sp,sp,16
    80001a2a:	8082                	ret

0000000080001a2c <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80001a2c:	1141                	addi	sp,sp,-16
    80001a2e:	e406                	sd	ra,8(sp)
    80001a30:	e022                	sd	s0,0(sp)
    80001a32:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001a34:	00003797          	auipc	a5,0x3
    80001a38:	ebc78793          	addi	a5,a5,-324 # 800048f0 <kernelvec>
    80001a3c:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80001a40:	60a2                	ld	ra,8(sp)
    80001a42:	6402                	ld	s0,0(sp)
    80001a44:	0141                	addi	sp,sp,16
    80001a46:	8082                	ret

0000000080001a48 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80001a48:	1141                	addi	sp,sp,-16
    80001a4a:	e406                	sd	ra,8(sp)
    80001a4c:	e022                	sd	s0,0(sp)
    80001a4e:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80001a50:	c66ff0ef          	jal	80000eb6 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a54:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001a58:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001a5a:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80001a5e:	00004697          	auipc	a3,0x4
    80001a62:	5a268693          	addi	a3,a3,1442 # 80006000 <_trampoline>
    80001a66:	00004717          	auipc	a4,0x4
    80001a6a:	59a70713          	addi	a4,a4,1434 # 80006000 <_trampoline>
    80001a6e:	8f15                	sub	a4,a4,a3
    80001a70:	040007b7          	lui	a5,0x4000
    80001a74:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80001a76:	07b2                	slli	a5,a5,0xc
    80001a78:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001a7a:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80001a7e:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80001a80:	18002673          	csrr	a2,satp
    80001a84:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80001a86:	6d30                	ld	a2,88(a0)
    80001a88:	6138                	ld	a4,64(a0)
    80001a8a:	6585                	lui	a1,0x1
    80001a8c:	972e                	add	a4,a4,a1
    80001a8e:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80001a90:	6d38                	ld	a4,88(a0)
    80001a92:	00000617          	auipc	a2,0x0
    80001a96:	11460613          	addi	a2,a2,276 # 80001ba6 <usertrap>
    80001a9a:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80001a9c:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80001a9e:	8612                	mv	a2,tp
    80001aa0:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001aa2:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80001aa6:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80001aaa:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001aae:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80001ab2:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001ab4:	6f18                	ld	a4,24(a4)
    80001ab6:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001aba:	6928                	ld	a0,80(a0)
    80001abc:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001abe:	00004717          	auipc	a4,0x4
    80001ac2:	5de70713          	addi	a4,a4,1502 # 8000609c <userret>
    80001ac6:	8f15                	sub	a4,a4,a3
    80001ac8:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001aca:	577d                	li	a4,-1
    80001acc:	177e                	slli	a4,a4,0x3f
    80001ace:	8d59                	or	a0,a0,a4
    80001ad0:	9782                	jalr	a5
}
    80001ad2:	60a2                	ld	ra,8(sp)
    80001ad4:	6402                	ld	s0,0(sp)
    80001ad6:	0141                	addi	sp,sp,16
    80001ad8:	8082                	ret

0000000080001ada <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001ada:	1141                	addi	sp,sp,-16
    80001adc:	e406                	sd	ra,8(sp)
    80001ade:	e022                	sd	s0,0(sp)
    80001ae0:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80001ae2:	ba0ff0ef          	jal	80000e82 <cpuid>
    80001ae6:	cd11                	beqz	a0,80001b02 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001ae8:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001aec:	000f4737          	lui	a4,0xf4
    80001af0:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80001af4:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80001af6:	14d79073          	csrw	stimecmp,a5
}
    80001afa:	60a2                	ld	ra,8(sp)
    80001afc:	6402                	ld	s0,0(sp)
    80001afe:	0141                	addi	sp,sp,16
    80001b00:	8082                	ret
    acquire(&tickslock);
    80001b02:	0000c517          	auipc	a0,0xc
    80001b06:	efe50513          	addi	a0,a0,-258 # 8000da00 <tickslock>
    80001b0a:	6d3030ef          	jal	800059dc <acquire>
    ticks++;
    80001b0e:	00006717          	auipc	a4,0x6
    80001b12:	e8a70713          	addi	a4,a4,-374 # 80007998 <ticks>
    80001b16:	431c                	lw	a5,0(a4)
    80001b18:	2785                	addiw	a5,a5,1
    80001b1a:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80001b1c:	853a                	mv	a0,a4
    80001b1e:	a3bff0ef          	jal	80001558 <wakeup>
    release(&tickslock);
    80001b22:	0000c517          	auipc	a0,0xc
    80001b26:	ede50513          	addi	a0,a0,-290 # 8000da00 <tickslock>
    80001b2a:	747030ef          	jal	80005a70 <release>
    80001b2e:	bf6d                	j	80001ae8 <clockintr+0xe>

0000000080001b30 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001b30:	1101                	addi	sp,sp,-32
    80001b32:	ec06                	sd	ra,24(sp)
    80001b34:	e822                	sd	s0,16(sp)
    80001b36:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001b38:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001b3c:	57fd                	li	a5,-1
    80001b3e:	17fe                	slli	a5,a5,0x3f
    80001b40:	07a5                	addi	a5,a5,9
    80001b42:	00f70c63          	beq	a4,a5,80001b5a <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80001b46:	57fd                	li	a5,-1
    80001b48:	17fe                	slli	a5,a5,0x3f
    80001b4a:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001b4c:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001b4e:	04f70863          	beq	a4,a5,80001b9e <devintr+0x6e>
  }
}
    80001b52:	60e2                	ld	ra,24(sp)
    80001b54:	6442                	ld	s0,16(sp)
    80001b56:	6105                	addi	sp,sp,32
    80001b58:	8082                	ret
    80001b5a:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80001b5c:	641020ef          	jal	8000499c <plic_claim>
    80001b60:	872a                	mv	a4,a0
    80001b62:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001b64:	47a9                	li	a5,10
    80001b66:	00f50963          	beq	a0,a5,80001b78 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    80001b6a:	4785                	li	a5,1
    80001b6c:	00f50963          	beq	a0,a5,80001b7e <devintr+0x4e>
    return 1;
    80001b70:	4505                	li	a0,1
    } else if(irq){
    80001b72:	eb09                	bnez	a4,80001b84 <devintr+0x54>
    80001b74:	64a2                	ld	s1,8(sp)
    80001b76:	bff1                	j	80001b52 <devintr+0x22>
      uartintr();
    80001b78:	59b030ef          	jal	80005912 <uartintr>
    if(irq)
    80001b7c:	a819                	j	80001b92 <devintr+0x62>
      virtio_disk_intr();
    80001b7e:	2b4030ef          	jal	80004e32 <virtio_disk_intr>
    if(irq)
    80001b82:	a801                	j	80001b92 <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    80001b84:	85ba                	mv	a1,a4
    80001b86:	00005517          	auipc	a0,0x5
    80001b8a:	74a50513          	addi	a0,a0,1866 # 800072d0 <etext+0x2d0>
    80001b8e:	001030ef          	jal	8000538e <printf>
      plic_complete(irq);
    80001b92:	8526                	mv	a0,s1
    80001b94:	629020ef          	jal	800049bc <plic_complete>
    return 1;
    80001b98:	4505                	li	a0,1
    80001b9a:	64a2                	ld	s1,8(sp)
    80001b9c:	bf5d                	j	80001b52 <devintr+0x22>
    clockintr();
    80001b9e:	f3dff0ef          	jal	80001ada <clockintr>
    return 2;
    80001ba2:	4509                	li	a0,2
    80001ba4:	b77d                	j	80001b52 <devintr+0x22>

0000000080001ba6 <usertrap>:
{
    80001ba6:	1101                	addi	sp,sp,-32
    80001ba8:	ec06                	sd	ra,24(sp)
    80001baa:	e822                	sd	s0,16(sp)
    80001bac:	e426                	sd	s1,8(sp)
    80001bae:	e04a                	sd	s2,0(sp)
    80001bb0:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001bb2:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80001bb6:	1007f793          	andi	a5,a5,256
    80001bba:	ef85                	bnez	a5,80001bf2 <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001bbc:	00003797          	auipc	a5,0x3
    80001bc0:	d3478793          	addi	a5,a5,-716 # 800048f0 <kernelvec>
    80001bc4:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001bc8:	aeeff0ef          	jal	80000eb6 <myproc>
    80001bcc:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001bce:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001bd0:	14102773          	csrr	a4,sepc
    80001bd4:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001bd6:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001bda:	47a1                	li	a5,8
    80001bdc:	02f70163          	beq	a4,a5,80001bfe <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001be0:	f51ff0ef          	jal	80001b30 <devintr>
    80001be4:	892a                	mv	s2,a0
    80001be6:	c135                	beqz	a0,80001c4a <usertrap+0xa4>
  if(killed(p))
    80001be8:	8526                	mv	a0,s1
    80001bea:	b5fff0ef          	jal	80001748 <killed>
    80001bee:	cd1d                	beqz	a0,80001c2c <usertrap+0x86>
    80001bf0:	a81d                	j	80001c26 <usertrap+0x80>
    panic("usertrap: not from user mode");
    80001bf2:	00005517          	auipc	a0,0x5
    80001bf6:	6fe50513          	addi	a0,a0,1790 # 800072f0 <etext+0x2f0>
    80001bfa:	2a5030ef          	jal	8000569e <panic>
    if(killed(p))
    80001bfe:	b4bff0ef          	jal	80001748 <killed>
    80001c02:	e121                	bnez	a0,80001c42 <usertrap+0x9c>
    p->trapframe->epc += 4;
    80001c04:	6cb8                	ld	a4,88(s1)
    80001c06:	6f1c                	ld	a5,24(a4)
    80001c08:	0791                	addi	a5,a5,4
    80001c0a:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c0c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001c10:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001c14:	10079073          	csrw	sstatus,a5
    syscall();
    80001c18:	242000ef          	jal	80001e5a <syscall>
  if(killed(p))
    80001c1c:	8526                	mv	a0,s1
    80001c1e:	b2bff0ef          	jal	80001748 <killed>
    80001c22:	c901                	beqz	a0,80001c32 <usertrap+0x8c>
    80001c24:	4901                	li	s2,0
    exit(-1);
    80001c26:	557d                	li	a0,-1
    80001c28:	9f1ff0ef          	jal	80001618 <exit>
  if(which_dev == 2)
    80001c2c:	4789                	li	a5,2
    80001c2e:	04f90563          	beq	s2,a5,80001c78 <usertrap+0xd2>
  usertrapret();
    80001c32:	e17ff0ef          	jal	80001a48 <usertrapret>
}
    80001c36:	60e2                	ld	ra,24(sp)
    80001c38:	6442                	ld	s0,16(sp)
    80001c3a:	64a2                	ld	s1,8(sp)
    80001c3c:	6902                	ld	s2,0(sp)
    80001c3e:	6105                	addi	sp,sp,32
    80001c40:	8082                	ret
      exit(-1);
    80001c42:	557d                	li	a0,-1
    80001c44:	9d5ff0ef          	jal	80001618 <exit>
    80001c48:	bf75                	j	80001c04 <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001c4a:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001c4e:	5890                	lw	a2,48(s1)
    80001c50:	00005517          	auipc	a0,0x5
    80001c54:	6c050513          	addi	a0,a0,1728 # 80007310 <etext+0x310>
    80001c58:	736030ef          	jal	8000538e <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001c5c:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001c60:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001c64:	00005517          	auipc	a0,0x5
    80001c68:	6dc50513          	addi	a0,a0,1756 # 80007340 <etext+0x340>
    80001c6c:	722030ef          	jal	8000538e <printf>
    setkilled(p);
    80001c70:	8526                	mv	a0,s1
    80001c72:	ab3ff0ef          	jal	80001724 <setkilled>
    80001c76:	b75d                	j	80001c1c <usertrap+0x76>
    yield();
    80001c78:	869ff0ef          	jal	800014e0 <yield>
    80001c7c:	bf5d                	j	80001c32 <usertrap+0x8c>

0000000080001c7e <kerneltrap>:
{
    80001c7e:	7179                	addi	sp,sp,-48
    80001c80:	f406                	sd	ra,40(sp)
    80001c82:	f022                	sd	s0,32(sp)
    80001c84:	ec26                	sd	s1,24(sp)
    80001c86:	e84a                	sd	s2,16(sp)
    80001c88:	e44e                	sd	s3,8(sp)
    80001c8a:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001c8c:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c90:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001c94:	142027f3          	csrr	a5,scause
    80001c98:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80001c9a:	1004f793          	andi	a5,s1,256
    80001c9e:	c795                	beqz	a5,80001cca <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001ca0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001ca4:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001ca6:	eb85                	bnez	a5,80001cd6 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80001ca8:	e89ff0ef          	jal	80001b30 <devintr>
    80001cac:	c91d                	beqz	a0,80001ce2 <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80001cae:	4789                	li	a5,2
    80001cb0:	04f50a63          	beq	a0,a5,80001d04 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001cb4:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001cb8:	10049073          	csrw	sstatus,s1
}
    80001cbc:	70a2                	ld	ra,40(sp)
    80001cbe:	7402                	ld	s0,32(sp)
    80001cc0:	64e2                	ld	s1,24(sp)
    80001cc2:	6942                	ld	s2,16(sp)
    80001cc4:	69a2                	ld	s3,8(sp)
    80001cc6:	6145                	addi	sp,sp,48
    80001cc8:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001cca:	00005517          	auipc	a0,0x5
    80001cce:	69e50513          	addi	a0,a0,1694 # 80007368 <etext+0x368>
    80001cd2:	1cd030ef          	jal	8000569e <panic>
    panic("kerneltrap: interrupts enabled");
    80001cd6:	00005517          	auipc	a0,0x5
    80001cda:	6ba50513          	addi	a0,a0,1722 # 80007390 <etext+0x390>
    80001cde:	1c1030ef          	jal	8000569e <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001ce2:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001ce6:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001cea:	85ce                	mv	a1,s3
    80001cec:	00005517          	auipc	a0,0x5
    80001cf0:	6c450513          	addi	a0,a0,1732 # 800073b0 <etext+0x3b0>
    80001cf4:	69a030ef          	jal	8000538e <printf>
    panic("kerneltrap");
    80001cf8:	00005517          	auipc	a0,0x5
    80001cfc:	6e050513          	addi	a0,a0,1760 # 800073d8 <etext+0x3d8>
    80001d00:	19f030ef          	jal	8000569e <panic>
  if(which_dev == 2 && myproc() != 0)
    80001d04:	9b2ff0ef          	jal	80000eb6 <myproc>
    80001d08:	d555                	beqz	a0,80001cb4 <kerneltrap+0x36>
    yield();
    80001d0a:	fd6ff0ef          	jal	800014e0 <yield>
    80001d0e:	b75d                	j	80001cb4 <kerneltrap+0x36>

0000000080001d10 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001d10:	1101                	addi	sp,sp,-32
    80001d12:	ec06                	sd	ra,24(sp)
    80001d14:	e822                	sd	s0,16(sp)
    80001d16:	e426                	sd	s1,8(sp)
    80001d18:	1000                	addi	s0,sp,32
    80001d1a:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001d1c:	99aff0ef          	jal	80000eb6 <myproc>
  switch (n) {
    80001d20:	4795                	li	a5,5
    80001d22:	0497e163          	bltu	a5,s1,80001d64 <argraw+0x54>
    80001d26:	048a                	slli	s1,s1,0x2
    80001d28:	00006717          	auipc	a4,0x6
    80001d2c:	ab870713          	addi	a4,a4,-1352 # 800077e0 <states.0+0x30>
    80001d30:	94ba                	add	s1,s1,a4
    80001d32:	409c                	lw	a5,0(s1)
    80001d34:	97ba                	add	a5,a5,a4
    80001d36:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001d38:	6d3c                	ld	a5,88(a0)
    80001d3a:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001d3c:	60e2                	ld	ra,24(sp)
    80001d3e:	6442                	ld	s0,16(sp)
    80001d40:	64a2                	ld	s1,8(sp)
    80001d42:	6105                	addi	sp,sp,32
    80001d44:	8082                	ret
    return p->trapframe->a1;
    80001d46:	6d3c                	ld	a5,88(a0)
    80001d48:	7fa8                	ld	a0,120(a5)
    80001d4a:	bfcd                	j	80001d3c <argraw+0x2c>
    return p->trapframe->a2;
    80001d4c:	6d3c                	ld	a5,88(a0)
    80001d4e:	63c8                	ld	a0,128(a5)
    80001d50:	b7f5                	j	80001d3c <argraw+0x2c>
    return p->trapframe->a3;
    80001d52:	6d3c                	ld	a5,88(a0)
    80001d54:	67c8                	ld	a0,136(a5)
    80001d56:	b7dd                	j	80001d3c <argraw+0x2c>
    return p->trapframe->a4;
    80001d58:	6d3c                	ld	a5,88(a0)
    80001d5a:	6bc8                	ld	a0,144(a5)
    80001d5c:	b7c5                	j	80001d3c <argraw+0x2c>
    return p->trapframe->a5;
    80001d5e:	6d3c                	ld	a5,88(a0)
    80001d60:	6fc8                	ld	a0,152(a5)
    80001d62:	bfe9                	j	80001d3c <argraw+0x2c>
  panic("argraw");
    80001d64:	00005517          	auipc	a0,0x5
    80001d68:	68450513          	addi	a0,a0,1668 # 800073e8 <etext+0x3e8>
    80001d6c:	133030ef          	jal	8000569e <panic>

0000000080001d70 <fetchaddr>:
{
    80001d70:	1101                	addi	sp,sp,-32
    80001d72:	ec06                	sd	ra,24(sp)
    80001d74:	e822                	sd	s0,16(sp)
    80001d76:	e426                	sd	s1,8(sp)
    80001d78:	e04a                	sd	s2,0(sp)
    80001d7a:	1000                	addi	s0,sp,32
    80001d7c:	84aa                	mv	s1,a0
    80001d7e:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001d80:	936ff0ef          	jal	80000eb6 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001d84:	653c                	ld	a5,72(a0)
    80001d86:	02f4f663          	bgeu	s1,a5,80001db2 <fetchaddr+0x42>
    80001d8a:	00848713          	addi	a4,s1,8
    80001d8e:	02e7e463          	bltu	a5,a4,80001db6 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001d92:	46a1                	li	a3,8
    80001d94:	8626                	mv	a2,s1
    80001d96:	85ca                	mv	a1,s2
    80001d98:	6928                	ld	a0,80(a0)
    80001d9a:	e0dfe0ef          	jal	80000ba6 <copyin>
    80001d9e:	00a03533          	snez	a0,a0
    80001da2:	40a0053b          	negw	a0,a0
}
    80001da6:	60e2                	ld	ra,24(sp)
    80001da8:	6442                	ld	s0,16(sp)
    80001daa:	64a2                	ld	s1,8(sp)
    80001dac:	6902                	ld	s2,0(sp)
    80001dae:	6105                	addi	sp,sp,32
    80001db0:	8082                	ret
    return -1;
    80001db2:	557d                	li	a0,-1
    80001db4:	bfcd                	j	80001da6 <fetchaddr+0x36>
    80001db6:	557d                	li	a0,-1
    80001db8:	b7fd                	j	80001da6 <fetchaddr+0x36>

0000000080001dba <fetchstr>:
{
    80001dba:	7179                	addi	sp,sp,-48
    80001dbc:	f406                	sd	ra,40(sp)
    80001dbe:	f022                	sd	s0,32(sp)
    80001dc0:	ec26                	sd	s1,24(sp)
    80001dc2:	e84a                	sd	s2,16(sp)
    80001dc4:	e44e                	sd	s3,8(sp)
    80001dc6:	1800                	addi	s0,sp,48
    80001dc8:	89aa                	mv	s3,a0
    80001dca:	84ae                	mv	s1,a1
    80001dcc:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80001dce:	8e8ff0ef          	jal	80000eb6 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001dd2:	86ca                	mv	a3,s2
    80001dd4:	864e                	mv	a2,s3
    80001dd6:	85a6                	mv	a1,s1
    80001dd8:	6928                	ld	a0,80(a0)
    80001dda:	e53fe0ef          	jal	80000c2c <copyinstr>
    80001dde:	00054c63          	bltz	a0,80001df6 <fetchstr+0x3c>
  return strlen(buf);
    80001de2:	8526                	mv	a0,s1
    80001de4:	d04fe0ef          	jal	800002e8 <strlen>
}
    80001de8:	70a2                	ld	ra,40(sp)
    80001dea:	7402                	ld	s0,32(sp)
    80001dec:	64e2                	ld	s1,24(sp)
    80001dee:	6942                	ld	s2,16(sp)
    80001df0:	69a2                	ld	s3,8(sp)
    80001df2:	6145                	addi	sp,sp,48
    80001df4:	8082                	ret
    return -1;
    80001df6:	557d                	li	a0,-1
    80001df8:	bfc5                	j	80001de8 <fetchstr+0x2e>

0000000080001dfa <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001dfa:	1101                	addi	sp,sp,-32
    80001dfc:	ec06                	sd	ra,24(sp)
    80001dfe:	e822                	sd	s0,16(sp)
    80001e00:	e426                	sd	s1,8(sp)
    80001e02:	1000                	addi	s0,sp,32
    80001e04:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001e06:	f0bff0ef          	jal	80001d10 <argraw>
    80001e0a:	c088                	sw	a0,0(s1)
}
    80001e0c:	60e2                	ld	ra,24(sp)
    80001e0e:	6442                	ld	s0,16(sp)
    80001e10:	64a2                	ld	s1,8(sp)
    80001e12:	6105                	addi	sp,sp,32
    80001e14:	8082                	ret

0000000080001e16 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001e16:	1101                	addi	sp,sp,-32
    80001e18:	ec06                	sd	ra,24(sp)
    80001e1a:	e822                	sd	s0,16(sp)
    80001e1c:	e426                	sd	s1,8(sp)
    80001e1e:	1000                	addi	s0,sp,32
    80001e20:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001e22:	eefff0ef          	jal	80001d10 <argraw>
    80001e26:	e088                	sd	a0,0(s1)
}
    80001e28:	60e2                	ld	ra,24(sp)
    80001e2a:	6442                	ld	s0,16(sp)
    80001e2c:	64a2                	ld	s1,8(sp)
    80001e2e:	6105                	addi	sp,sp,32
    80001e30:	8082                	ret

0000000080001e32 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001e32:	1101                	addi	sp,sp,-32
    80001e34:	ec06                	sd	ra,24(sp)
    80001e36:	e822                	sd	s0,16(sp)
    80001e38:	e426                	sd	s1,8(sp)
    80001e3a:	e04a                	sd	s2,0(sp)
    80001e3c:	1000                	addi	s0,sp,32
    80001e3e:	892e                	mv	s2,a1
    80001e40:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80001e42:	ecfff0ef          	jal	80001d10 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80001e46:	8626                	mv	a2,s1
    80001e48:	85ca                	mv	a1,s2
    80001e4a:	f71ff0ef          	jal	80001dba <fetchstr>
}
    80001e4e:	60e2                	ld	ra,24(sp)
    80001e50:	6442                	ld	s0,16(sp)
    80001e52:	64a2                	ld	s1,8(sp)
    80001e54:	6902                	ld	s2,0(sp)
    80001e56:	6105                	addi	sp,sp,32
    80001e58:	8082                	ret

0000000080001e5a <syscall>:



void
syscall(void)
{
    80001e5a:	1101                	addi	sp,sp,-32
    80001e5c:	ec06                	sd	ra,24(sp)
    80001e5e:	e822                	sd	s0,16(sp)
    80001e60:	e426                	sd	s1,8(sp)
    80001e62:	e04a                	sd	s2,0(sp)
    80001e64:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001e66:	850ff0ef          	jal	80000eb6 <myproc>
    80001e6a:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001e6c:	05853903          	ld	s2,88(a0)
    80001e70:	0a893783          	ld	a5,168(s2)
    80001e74:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001e78:	37fd                	addiw	a5,a5,-1
    80001e7a:	02100713          	li	a4,33
    80001e7e:	00f76f63          	bltu	a4,a5,80001e9c <syscall+0x42>
    80001e82:	00369713          	slli	a4,a3,0x3
    80001e86:	00006797          	auipc	a5,0x6
    80001e8a:	97278793          	addi	a5,a5,-1678 # 800077f8 <syscalls>
    80001e8e:	97ba                	add	a5,a5,a4
    80001e90:	639c                	ld	a5,0(a5)
    80001e92:	c789                	beqz	a5,80001e9c <syscall+0x42>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001e94:	9782                	jalr	a5
    80001e96:	06a93823          	sd	a0,112(s2)
    80001e9a:	a829                	j	80001eb4 <syscall+0x5a>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001e9c:	16048613          	addi	a2,s1,352
    80001ea0:	588c                	lw	a1,48(s1)
    80001ea2:	00005517          	auipc	a0,0x5
    80001ea6:	54e50513          	addi	a0,a0,1358 # 800073f0 <etext+0x3f0>
    80001eaa:	4e4030ef          	jal	8000538e <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001eae:	6cbc                	ld	a5,88(s1)
    80001eb0:	577d                	li	a4,-1
    80001eb2:	fbb8                	sd	a4,112(a5)
  }
}
    80001eb4:	60e2                	ld	ra,24(sp)
    80001eb6:	6442                	ld	s0,16(sp)
    80001eb8:	64a2                	ld	s1,8(sp)
    80001eba:	6902                	ld	s2,0(sp)
    80001ebc:	6105                	addi	sp,sp,32
    80001ebe:	8082                	ret

0000000080001ec0 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001ec0:	1101                	addi	sp,sp,-32
    80001ec2:	ec06                	sd	ra,24(sp)
    80001ec4:	e822                	sd	s0,16(sp)
    80001ec6:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001ec8:	fec40593          	addi	a1,s0,-20
    80001ecc:	4501                	li	a0,0
    80001ece:	f2dff0ef          	jal	80001dfa <argint>
  exit(n);
    80001ed2:	fec42503          	lw	a0,-20(s0)
    80001ed6:	f42ff0ef          	jal	80001618 <exit>
  return 0;  // not reached
}
    80001eda:	4501                	li	a0,0
    80001edc:	60e2                	ld	ra,24(sp)
    80001ede:	6442                	ld	s0,16(sp)
    80001ee0:	6105                	addi	sp,sp,32
    80001ee2:	8082                	ret

0000000080001ee4 <sys_getpid>:

uint64
sys_getpid(void)
{
    80001ee4:	1141                	addi	sp,sp,-16
    80001ee6:	e406                	sd	ra,8(sp)
    80001ee8:	e022                	sd	s0,0(sp)
    80001eea:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001eec:	fcbfe0ef          	jal	80000eb6 <myproc>
}
    80001ef0:	5908                	lw	a0,48(a0)
    80001ef2:	60a2                	ld	ra,8(sp)
    80001ef4:	6402                	ld	s0,0(sp)
    80001ef6:	0141                	addi	sp,sp,16
    80001ef8:	8082                	ret

0000000080001efa <sys_fork>:

uint64
sys_fork(void)
{
    80001efa:	1141                	addi	sp,sp,-16
    80001efc:	e406                	sd	ra,8(sp)
    80001efe:	e022                	sd	s0,0(sp)
    80001f00:	0800                	addi	s0,sp,16
  return fork();
    80001f02:	b60ff0ef          	jal	80001262 <fork>
}
    80001f06:	60a2                	ld	ra,8(sp)
    80001f08:	6402                	ld	s0,0(sp)
    80001f0a:	0141                	addi	sp,sp,16
    80001f0c:	8082                	ret

0000000080001f0e <sys_wait>:

uint64
sys_wait(void)
{
    80001f0e:	1101                	addi	sp,sp,-32
    80001f10:	ec06                	sd	ra,24(sp)
    80001f12:	e822                	sd	s0,16(sp)
    80001f14:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001f16:	fe840593          	addi	a1,s0,-24
    80001f1a:	4501                	li	a0,0
    80001f1c:	efbff0ef          	jal	80001e16 <argaddr>
  return wait(p);
    80001f20:	fe843503          	ld	a0,-24(s0)
    80001f24:	84fff0ef          	jal	80001772 <wait>
}
    80001f28:	60e2                	ld	ra,24(sp)
    80001f2a:	6442                	ld	s0,16(sp)
    80001f2c:	6105                	addi	sp,sp,32
    80001f2e:	8082                	ret

0000000080001f30 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001f30:	7179                	addi	sp,sp,-48
    80001f32:	f406                	sd	ra,40(sp)
    80001f34:	f022                	sd	s0,32(sp)
    80001f36:	ec26                	sd	s1,24(sp)
    80001f38:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001f3a:	fdc40593          	addi	a1,s0,-36
    80001f3e:	4501                	li	a0,0
    80001f40:	ebbff0ef          	jal	80001dfa <argint>
  addr = myproc()->sz;
    80001f44:	f73fe0ef          	jal	80000eb6 <myproc>
    80001f48:	653c                	ld	a5,72(a0)
    80001f4a:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80001f4c:	fdc42503          	lw	a0,-36(s0)
    80001f50:	ac2ff0ef          	jal	80001212 <growproc>
    80001f54:	00054863          	bltz	a0,80001f64 <sys_sbrk+0x34>
    return -1;
  return addr;
}
    80001f58:	8526                	mv	a0,s1
    80001f5a:	70a2                	ld	ra,40(sp)
    80001f5c:	7402                	ld	s0,32(sp)
    80001f5e:	64e2                	ld	s1,24(sp)
    80001f60:	6145                	addi	sp,sp,48
    80001f62:	8082                	ret
    return -1;
    80001f64:	57fd                	li	a5,-1
    80001f66:	84be                	mv	s1,a5
    80001f68:	bfc5                	j	80001f58 <sys_sbrk+0x28>

0000000080001f6a <sys_sleep>:

uint64
sys_sleep(void)
{
    80001f6a:	7139                	addi	sp,sp,-64
    80001f6c:	fc06                	sd	ra,56(sp)
    80001f6e:	f822                	sd	s0,48(sp)
    80001f70:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;


  argint(0, &n);
    80001f72:	fcc40593          	addi	a1,s0,-52
    80001f76:	4501                	li	a0,0
    80001f78:	e83ff0ef          	jal	80001dfa <argint>
  if(n < 0)
    80001f7c:	fcc42783          	lw	a5,-52(s0)
    80001f80:	0607c863          	bltz	a5,80001ff0 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80001f84:	0000c517          	auipc	a0,0xc
    80001f88:	a7c50513          	addi	a0,a0,-1412 # 8000da00 <tickslock>
    80001f8c:	251030ef          	jal	800059dc <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80001f90:	fcc42783          	lw	a5,-52(s0)
    80001f94:	c3b9                	beqz	a5,80001fda <sys_sleep+0x70>
    80001f96:	f426                	sd	s1,40(sp)
    80001f98:	f04a                	sd	s2,32(sp)
    80001f9a:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80001f9c:	00006997          	auipc	s3,0x6
    80001fa0:	9fc9a983          	lw	s3,-1540(s3) # 80007998 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80001fa4:	0000c917          	auipc	s2,0xc
    80001fa8:	a5c90913          	addi	s2,s2,-1444 # 8000da00 <tickslock>
    80001fac:	00006497          	auipc	s1,0x6
    80001fb0:	9ec48493          	addi	s1,s1,-1556 # 80007998 <ticks>
    if(killed(myproc())){
    80001fb4:	f03fe0ef          	jal	80000eb6 <myproc>
    80001fb8:	f90ff0ef          	jal	80001748 <killed>
    80001fbc:	ed0d                	bnez	a0,80001ff6 <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80001fbe:	85ca                	mv	a1,s2
    80001fc0:	8526                	mv	a0,s1
    80001fc2:	d4aff0ef          	jal	8000150c <sleep>
  while(ticks - ticks0 < n){
    80001fc6:	409c                	lw	a5,0(s1)
    80001fc8:	413787bb          	subw	a5,a5,s3
    80001fcc:	fcc42703          	lw	a4,-52(s0)
    80001fd0:	fee7e2e3          	bltu	a5,a4,80001fb4 <sys_sleep+0x4a>
    80001fd4:	74a2                	ld	s1,40(sp)
    80001fd6:	7902                	ld	s2,32(sp)
    80001fd8:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80001fda:	0000c517          	auipc	a0,0xc
    80001fde:	a2650513          	addi	a0,a0,-1498 # 8000da00 <tickslock>
    80001fe2:	28f030ef          	jal	80005a70 <release>
  return 0;
    80001fe6:	4501                	li	a0,0
}
    80001fe8:	70e2                	ld	ra,56(sp)
    80001fea:	7442                	ld	s0,48(sp)
    80001fec:	6121                	addi	sp,sp,64
    80001fee:	8082                	ret
    n = 0;
    80001ff0:	fc042623          	sw	zero,-52(s0)
    80001ff4:	bf41                	j	80001f84 <sys_sleep+0x1a>
      release(&tickslock);
    80001ff6:	0000c517          	auipc	a0,0xc
    80001ffa:	a0a50513          	addi	a0,a0,-1526 # 8000da00 <tickslock>
    80001ffe:	273030ef          	jal	80005a70 <release>
      return -1;
    80002002:	557d                	li	a0,-1
    80002004:	74a2                	ld	s1,40(sp)
    80002006:	7902                	ld	s2,32(sp)
    80002008:	69e2                	ld	s3,24(sp)
    8000200a:	bff9                	j	80001fe8 <sys_sleep+0x7e>

000000008000200c <sys_pgpte>:


#ifdef LAB_PGTBL
int
sys_pgpte(void)
{
    8000200c:	7179                	addi	sp,sp,-48
    8000200e:	f406                	sd	ra,40(sp)
    80002010:	f022                	sd	s0,32(sp)
    80002012:	ec26                	sd	s1,24(sp)
    80002014:	1800                	addi	s0,sp,48
  uint64 va;
  struct proc *p;  

  p = myproc();
    80002016:	ea1fe0ef          	jal	80000eb6 <myproc>
    8000201a:	84aa                	mv	s1,a0
  argaddr(0, &va);
    8000201c:	fd840593          	addi	a1,s0,-40
    80002020:	4501                	li	a0,0
    80002022:	df5ff0ef          	jal	80001e16 <argaddr>
  pte_t *pte = pgpte(p->pagetable, va);
    80002026:	fd843583          	ld	a1,-40(s0)
    8000202a:	68a8                	ld	a0,80(s1)
    8000202c:	cebfe0ef          	jal	80000d16 <pgpte>
    80002030:	87aa                	mv	a5,a0
  if(pte != 0) {
      return (uint64) *pte;
  }
  return 0;
    80002032:	4501                	li	a0,0
  if(pte != 0) {
    80002034:	c391                	beqz	a5,80002038 <sys_pgpte+0x2c>
      return (uint64) *pte;
    80002036:	4388                	lw	a0,0(a5)
}
    80002038:	70a2                	ld	ra,40(sp)
    8000203a:	7402                	ld	s0,32(sp)
    8000203c:	64e2                	ld	s1,24(sp)
    8000203e:	6145                	addi	sp,sp,48
    80002040:	8082                	ret

0000000080002042 <sys_kpgtbl>:
#endif

#ifdef LAB_PGTBL
int
sys_kpgtbl(void)
{
    80002042:	1141                	addi	sp,sp,-16
    80002044:	e406                	sd	ra,8(sp)
    80002046:	e022                	sd	s0,0(sp)
    80002048:	0800                	addi	s0,sp,16
  struct proc *p;  

  p = myproc();
    8000204a:	e6dfe0ef          	jal	80000eb6 <myproc>
  vmprint(p->pagetable);
    8000204e:	6928                	ld	a0,80(a0)
    80002050:	c99fe0ef          	jal	80000ce8 <vmprint>
  return 0;
}
    80002054:	4501                	li	a0,0
    80002056:	60a2                	ld	ra,8(sp)
    80002058:	6402                	ld	s0,0(sp)
    8000205a:	0141                	addi	sp,sp,16
    8000205c:	8082                	ret

000000008000205e <sys_kill>:
#endif


uint64
sys_kill(void)
{
    8000205e:	1101                	addi	sp,sp,-32
    80002060:	ec06                	sd	ra,24(sp)
    80002062:	e822                	sd	s0,16(sp)
    80002064:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002066:	fec40593          	addi	a1,s0,-20
    8000206a:	4501                	li	a0,0
    8000206c:	d8fff0ef          	jal	80001dfa <argint>
  return kill(pid);
    80002070:	fec42503          	lw	a0,-20(s0)
    80002074:	e4aff0ef          	jal	800016be <kill>
}
    80002078:	60e2                	ld	ra,24(sp)
    8000207a:	6442                	ld	s0,16(sp)
    8000207c:	6105                	addi	sp,sp,32
    8000207e:	8082                	ret

0000000080002080 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002080:	1101                	addi	sp,sp,-32
    80002082:	ec06                	sd	ra,24(sp)
    80002084:	e822                	sd	s0,16(sp)
    80002086:	e426                	sd	s1,8(sp)
    80002088:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    8000208a:	0000c517          	auipc	a0,0xc
    8000208e:	97650513          	addi	a0,a0,-1674 # 8000da00 <tickslock>
    80002092:	14b030ef          	jal	800059dc <acquire>
  xticks = ticks;
    80002096:	00006797          	auipc	a5,0x6
    8000209a:	9027a783          	lw	a5,-1790(a5) # 80007998 <ticks>
    8000209e:	84be                	mv	s1,a5
  release(&tickslock);
    800020a0:	0000c517          	auipc	a0,0xc
    800020a4:	96050513          	addi	a0,a0,-1696 # 8000da00 <tickslock>
    800020a8:	1c9030ef          	jal	80005a70 <release>
  return xticks;
}
    800020ac:	02049513          	slli	a0,s1,0x20
    800020b0:	9101                	srli	a0,a0,0x20
    800020b2:	60e2                	ld	ra,24(sp)
    800020b4:	6442                	ld	s0,16(sp)
    800020b6:	64a2                	ld	s1,8(sp)
    800020b8:	6105                	addi	sp,sp,32
    800020ba:	8082                	ret

00000000800020bc <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    800020bc:	7179                	addi	sp,sp,-48
    800020be:	f406                	sd	ra,40(sp)
    800020c0:	f022                	sd	s0,32(sp)
    800020c2:	ec26                	sd	s1,24(sp)
    800020c4:	e84a                	sd	s2,16(sp)
    800020c6:	e44e                	sd	s3,8(sp)
    800020c8:	e052                	sd	s4,0(sp)
    800020ca:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    800020cc:	00005597          	auipc	a1,0x5
    800020d0:	34458593          	addi	a1,a1,836 # 80007410 <etext+0x410>
    800020d4:	0000c517          	auipc	a0,0xc
    800020d8:	94450513          	addi	a0,a0,-1724 # 8000da18 <bcache>
    800020dc:	077030ef          	jal	80005952 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    800020e0:	00014797          	auipc	a5,0x14
    800020e4:	93878793          	addi	a5,a5,-1736 # 80015a18 <bcache+0x8000>
    800020e8:	00014717          	auipc	a4,0x14
    800020ec:	b9870713          	addi	a4,a4,-1128 # 80015c80 <bcache+0x8268>
    800020f0:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    800020f4:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    800020f8:	0000c497          	auipc	s1,0xc
    800020fc:	93848493          	addi	s1,s1,-1736 # 8000da30 <bcache+0x18>
    b->next = bcache.head.next;
    80002100:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002102:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002104:	00005a17          	auipc	s4,0x5
    80002108:	314a0a13          	addi	s4,s4,788 # 80007418 <etext+0x418>
    b->next = bcache.head.next;
    8000210c:	2b893783          	ld	a5,696(s2)
    80002110:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002112:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002116:	85d2                	mv	a1,s4
    80002118:	01048513          	addi	a0,s1,16
    8000211c:	24c010ef          	jal	80003368 <initsleeplock>
    bcache.head.next->prev = b;
    80002120:	2b893783          	ld	a5,696(s2)
    80002124:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002126:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000212a:	45848493          	addi	s1,s1,1112
    8000212e:	fd349fe3          	bne	s1,s3,8000210c <binit+0x50>
  }
}
    80002132:	70a2                	ld	ra,40(sp)
    80002134:	7402                	ld	s0,32(sp)
    80002136:	64e2                	ld	s1,24(sp)
    80002138:	6942                	ld	s2,16(sp)
    8000213a:	69a2                	ld	s3,8(sp)
    8000213c:	6a02                	ld	s4,0(sp)
    8000213e:	6145                	addi	sp,sp,48
    80002140:	8082                	ret

0000000080002142 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002142:	7179                	addi	sp,sp,-48
    80002144:	f406                	sd	ra,40(sp)
    80002146:	f022                	sd	s0,32(sp)
    80002148:	ec26                	sd	s1,24(sp)
    8000214a:	e84a                	sd	s2,16(sp)
    8000214c:	e44e                	sd	s3,8(sp)
    8000214e:	1800                	addi	s0,sp,48
    80002150:	892a                	mv	s2,a0
    80002152:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002154:	0000c517          	auipc	a0,0xc
    80002158:	8c450513          	addi	a0,a0,-1852 # 8000da18 <bcache>
    8000215c:	081030ef          	jal	800059dc <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002160:	00014497          	auipc	s1,0x14
    80002164:	b704b483          	ld	s1,-1168(s1) # 80015cd0 <bcache+0x82b8>
    80002168:	00014797          	auipc	a5,0x14
    8000216c:	b1878793          	addi	a5,a5,-1256 # 80015c80 <bcache+0x8268>
    80002170:	02f48b63          	beq	s1,a5,800021a6 <bread+0x64>
    80002174:	873e                	mv	a4,a5
    80002176:	a021                	j	8000217e <bread+0x3c>
    80002178:	68a4                	ld	s1,80(s1)
    8000217a:	02e48663          	beq	s1,a4,800021a6 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    8000217e:	449c                	lw	a5,8(s1)
    80002180:	ff279ce3          	bne	a5,s2,80002178 <bread+0x36>
    80002184:	44dc                	lw	a5,12(s1)
    80002186:	ff3799e3          	bne	a5,s3,80002178 <bread+0x36>
      b->refcnt++;
    8000218a:	40bc                	lw	a5,64(s1)
    8000218c:	2785                	addiw	a5,a5,1
    8000218e:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002190:	0000c517          	auipc	a0,0xc
    80002194:	88850513          	addi	a0,a0,-1912 # 8000da18 <bcache>
    80002198:	0d9030ef          	jal	80005a70 <release>
      acquiresleep(&b->lock);
    8000219c:	01048513          	addi	a0,s1,16
    800021a0:	1fe010ef          	jal	8000339e <acquiresleep>
      return b;
    800021a4:	a889                	j	800021f6 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800021a6:	00014497          	auipc	s1,0x14
    800021aa:	b224b483          	ld	s1,-1246(s1) # 80015cc8 <bcache+0x82b0>
    800021ae:	00014797          	auipc	a5,0x14
    800021b2:	ad278793          	addi	a5,a5,-1326 # 80015c80 <bcache+0x8268>
    800021b6:	00f48863          	beq	s1,a5,800021c6 <bread+0x84>
    800021ba:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    800021bc:	40bc                	lw	a5,64(s1)
    800021be:	cb91                	beqz	a5,800021d2 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800021c0:	64a4                	ld	s1,72(s1)
    800021c2:	fee49de3          	bne	s1,a4,800021bc <bread+0x7a>
  panic("bget: no buffers");
    800021c6:	00005517          	auipc	a0,0x5
    800021ca:	25a50513          	addi	a0,a0,602 # 80007420 <etext+0x420>
    800021ce:	4d0030ef          	jal	8000569e <panic>
      b->dev = dev;
    800021d2:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    800021d6:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    800021da:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    800021de:	4785                	li	a5,1
    800021e0:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800021e2:	0000c517          	auipc	a0,0xc
    800021e6:	83650513          	addi	a0,a0,-1994 # 8000da18 <bcache>
    800021ea:	087030ef          	jal	80005a70 <release>
      acquiresleep(&b->lock);
    800021ee:	01048513          	addi	a0,s1,16
    800021f2:	1ac010ef          	jal	8000339e <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    800021f6:	409c                	lw	a5,0(s1)
    800021f8:	cb89                	beqz	a5,8000220a <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    800021fa:	8526                	mv	a0,s1
    800021fc:	70a2                	ld	ra,40(sp)
    800021fe:	7402                	ld	s0,32(sp)
    80002200:	64e2                	ld	s1,24(sp)
    80002202:	6942                	ld	s2,16(sp)
    80002204:	69a2                	ld	s3,8(sp)
    80002206:	6145                	addi	sp,sp,48
    80002208:	8082                	ret
    virtio_disk_rw(b, 0);
    8000220a:	4581                	li	a1,0
    8000220c:	8526                	mv	a0,s1
    8000220e:	213020ef          	jal	80004c20 <virtio_disk_rw>
    b->valid = 1;
    80002212:	4785                	li	a5,1
    80002214:	c09c                	sw	a5,0(s1)
  return b;
    80002216:	b7d5                	j	800021fa <bread+0xb8>

0000000080002218 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002218:	1101                	addi	sp,sp,-32
    8000221a:	ec06                	sd	ra,24(sp)
    8000221c:	e822                	sd	s0,16(sp)
    8000221e:	e426                	sd	s1,8(sp)
    80002220:	1000                	addi	s0,sp,32
    80002222:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002224:	0541                	addi	a0,a0,16
    80002226:	1f6010ef          	jal	8000341c <holdingsleep>
    8000222a:	c911                	beqz	a0,8000223e <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    8000222c:	4585                	li	a1,1
    8000222e:	8526                	mv	a0,s1
    80002230:	1f1020ef          	jal	80004c20 <virtio_disk_rw>
}
    80002234:	60e2                	ld	ra,24(sp)
    80002236:	6442                	ld	s0,16(sp)
    80002238:	64a2                	ld	s1,8(sp)
    8000223a:	6105                	addi	sp,sp,32
    8000223c:	8082                	ret
    panic("bwrite");
    8000223e:	00005517          	auipc	a0,0x5
    80002242:	1fa50513          	addi	a0,a0,506 # 80007438 <etext+0x438>
    80002246:	458030ef          	jal	8000569e <panic>

000000008000224a <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000224a:	1101                	addi	sp,sp,-32
    8000224c:	ec06                	sd	ra,24(sp)
    8000224e:	e822                	sd	s0,16(sp)
    80002250:	e426                	sd	s1,8(sp)
    80002252:	e04a                	sd	s2,0(sp)
    80002254:	1000                	addi	s0,sp,32
    80002256:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002258:	01050913          	addi	s2,a0,16
    8000225c:	854a                	mv	a0,s2
    8000225e:	1be010ef          	jal	8000341c <holdingsleep>
    80002262:	c125                	beqz	a0,800022c2 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002264:	854a                	mv	a0,s2
    80002266:	17e010ef          	jal	800033e4 <releasesleep>

  acquire(&bcache.lock);
    8000226a:	0000b517          	auipc	a0,0xb
    8000226e:	7ae50513          	addi	a0,a0,1966 # 8000da18 <bcache>
    80002272:	76a030ef          	jal	800059dc <acquire>
  b->refcnt--;
    80002276:	40bc                	lw	a5,64(s1)
    80002278:	37fd                	addiw	a5,a5,-1
    8000227a:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    8000227c:	e79d                	bnez	a5,800022aa <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    8000227e:	68b8                	ld	a4,80(s1)
    80002280:	64bc                	ld	a5,72(s1)
    80002282:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002284:	68b8                	ld	a4,80(s1)
    80002286:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002288:	00013797          	auipc	a5,0x13
    8000228c:	79078793          	addi	a5,a5,1936 # 80015a18 <bcache+0x8000>
    80002290:	2b87b703          	ld	a4,696(a5)
    80002294:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002296:	00014717          	auipc	a4,0x14
    8000229a:	9ea70713          	addi	a4,a4,-1558 # 80015c80 <bcache+0x8268>
    8000229e:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800022a0:	2b87b703          	ld	a4,696(a5)
    800022a4:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800022a6:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800022aa:	0000b517          	auipc	a0,0xb
    800022ae:	76e50513          	addi	a0,a0,1902 # 8000da18 <bcache>
    800022b2:	7be030ef          	jal	80005a70 <release>
}
    800022b6:	60e2                	ld	ra,24(sp)
    800022b8:	6442                	ld	s0,16(sp)
    800022ba:	64a2                	ld	s1,8(sp)
    800022bc:	6902                	ld	s2,0(sp)
    800022be:	6105                	addi	sp,sp,32
    800022c0:	8082                	ret
    panic("brelse");
    800022c2:	00005517          	auipc	a0,0x5
    800022c6:	17e50513          	addi	a0,a0,382 # 80007440 <etext+0x440>
    800022ca:	3d4030ef          	jal	8000569e <panic>

00000000800022ce <bpin>:

void
bpin(struct buf *b) {
    800022ce:	1101                	addi	sp,sp,-32
    800022d0:	ec06                	sd	ra,24(sp)
    800022d2:	e822                	sd	s0,16(sp)
    800022d4:	e426                	sd	s1,8(sp)
    800022d6:	1000                	addi	s0,sp,32
    800022d8:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800022da:	0000b517          	auipc	a0,0xb
    800022de:	73e50513          	addi	a0,a0,1854 # 8000da18 <bcache>
    800022e2:	6fa030ef          	jal	800059dc <acquire>
  b->refcnt++;
    800022e6:	40bc                	lw	a5,64(s1)
    800022e8:	2785                	addiw	a5,a5,1
    800022ea:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800022ec:	0000b517          	auipc	a0,0xb
    800022f0:	72c50513          	addi	a0,a0,1836 # 8000da18 <bcache>
    800022f4:	77c030ef          	jal	80005a70 <release>
}
    800022f8:	60e2                	ld	ra,24(sp)
    800022fa:	6442                	ld	s0,16(sp)
    800022fc:	64a2                	ld	s1,8(sp)
    800022fe:	6105                	addi	sp,sp,32
    80002300:	8082                	ret

0000000080002302 <bunpin>:

void
bunpin(struct buf *b) {
    80002302:	1101                	addi	sp,sp,-32
    80002304:	ec06                	sd	ra,24(sp)
    80002306:	e822                	sd	s0,16(sp)
    80002308:	e426                	sd	s1,8(sp)
    8000230a:	1000                	addi	s0,sp,32
    8000230c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000230e:	0000b517          	auipc	a0,0xb
    80002312:	70a50513          	addi	a0,a0,1802 # 8000da18 <bcache>
    80002316:	6c6030ef          	jal	800059dc <acquire>
  b->refcnt--;
    8000231a:	40bc                	lw	a5,64(s1)
    8000231c:	37fd                	addiw	a5,a5,-1
    8000231e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002320:	0000b517          	auipc	a0,0xb
    80002324:	6f850513          	addi	a0,a0,1784 # 8000da18 <bcache>
    80002328:	748030ef          	jal	80005a70 <release>
}
    8000232c:	60e2                	ld	ra,24(sp)
    8000232e:	6442                	ld	s0,16(sp)
    80002330:	64a2                	ld	s1,8(sp)
    80002332:	6105                	addi	sp,sp,32
    80002334:	8082                	ret

0000000080002336 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002336:	1101                	addi	sp,sp,-32
    80002338:	ec06                	sd	ra,24(sp)
    8000233a:	e822                	sd	s0,16(sp)
    8000233c:	e426                	sd	s1,8(sp)
    8000233e:	e04a                	sd	s2,0(sp)
    80002340:	1000                	addi	s0,sp,32
    80002342:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002344:	00d5d79b          	srliw	a5,a1,0xd
    80002348:	00014597          	auipc	a1,0x14
    8000234c:	dac5a583          	lw	a1,-596(a1) # 800160f4 <sb+0x1c>
    80002350:	9dbd                	addw	a1,a1,a5
    80002352:	df1ff0ef          	jal	80002142 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002356:	0074f713          	andi	a4,s1,7
    8000235a:	4785                	li	a5,1
    8000235c:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002360:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002362:	90d9                	srli	s1,s1,0x36
    80002364:	00950733          	add	a4,a0,s1
    80002368:	05874703          	lbu	a4,88(a4)
    8000236c:	00e7f6b3          	and	a3,a5,a4
    80002370:	c29d                	beqz	a3,80002396 <bfree+0x60>
    80002372:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002374:	94aa                	add	s1,s1,a0
    80002376:	fff7c793          	not	a5,a5
    8000237a:	8f7d                	and	a4,a4,a5
    8000237c:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002380:	717000ef          	jal	80003296 <log_write>
  brelse(bp);
    80002384:	854a                	mv	a0,s2
    80002386:	ec5ff0ef          	jal	8000224a <brelse>
}
    8000238a:	60e2                	ld	ra,24(sp)
    8000238c:	6442                	ld	s0,16(sp)
    8000238e:	64a2                	ld	s1,8(sp)
    80002390:	6902                	ld	s2,0(sp)
    80002392:	6105                	addi	sp,sp,32
    80002394:	8082                	ret
    panic("freeing free block");
    80002396:	00005517          	auipc	a0,0x5
    8000239a:	0b250513          	addi	a0,a0,178 # 80007448 <etext+0x448>
    8000239e:	300030ef          	jal	8000569e <panic>

00000000800023a2 <balloc>:
{
    800023a2:	715d                	addi	sp,sp,-80
    800023a4:	e486                	sd	ra,72(sp)
    800023a6:	e0a2                	sd	s0,64(sp)
    800023a8:	fc26                	sd	s1,56(sp)
    800023aa:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    800023ac:	00014797          	auipc	a5,0x14
    800023b0:	d307a783          	lw	a5,-720(a5) # 800160dc <sb+0x4>
    800023b4:	0e078263          	beqz	a5,80002498 <balloc+0xf6>
    800023b8:	f84a                	sd	s2,48(sp)
    800023ba:	f44e                	sd	s3,40(sp)
    800023bc:	f052                	sd	s4,32(sp)
    800023be:	ec56                	sd	s5,24(sp)
    800023c0:	e85a                	sd	s6,16(sp)
    800023c2:	e45e                	sd	s7,8(sp)
    800023c4:	e062                	sd	s8,0(sp)
    800023c6:	8baa                	mv	s7,a0
    800023c8:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800023ca:	00014b17          	auipc	s6,0x14
    800023ce:	d0eb0b13          	addi	s6,s6,-754 # 800160d8 <sb>
      m = 1 << (bi % 8);
    800023d2:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800023d4:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    800023d6:	6c09                	lui	s8,0x2
    800023d8:	a09d                	j	8000243e <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    800023da:	97ca                	add	a5,a5,s2
    800023dc:	8e55                	or	a2,a2,a3
    800023de:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    800023e2:	854a                	mv	a0,s2
    800023e4:	6b3000ef          	jal	80003296 <log_write>
        brelse(bp);
    800023e8:	854a                	mv	a0,s2
    800023ea:	e61ff0ef          	jal	8000224a <brelse>
  bp = bread(dev, bno);
    800023ee:	85a6                	mv	a1,s1
    800023f0:	855e                	mv	a0,s7
    800023f2:	d51ff0ef          	jal	80002142 <bread>
    800023f6:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800023f8:	40000613          	li	a2,1024
    800023fc:	4581                	li	a1,0
    800023fe:	05850513          	addi	a0,a0,88
    80002402:	d5dfd0ef          	jal	8000015e <memset>
  log_write(bp);
    80002406:	854a                	mv	a0,s2
    80002408:	68f000ef          	jal	80003296 <log_write>
  brelse(bp);
    8000240c:	854a                	mv	a0,s2
    8000240e:	e3dff0ef          	jal	8000224a <brelse>
}
    80002412:	7942                	ld	s2,48(sp)
    80002414:	79a2                	ld	s3,40(sp)
    80002416:	7a02                	ld	s4,32(sp)
    80002418:	6ae2                	ld	s5,24(sp)
    8000241a:	6b42                	ld	s6,16(sp)
    8000241c:	6ba2                	ld	s7,8(sp)
    8000241e:	6c02                	ld	s8,0(sp)
}
    80002420:	8526                	mv	a0,s1
    80002422:	60a6                	ld	ra,72(sp)
    80002424:	6406                	ld	s0,64(sp)
    80002426:	74e2                	ld	s1,56(sp)
    80002428:	6161                	addi	sp,sp,80
    8000242a:	8082                	ret
    brelse(bp);
    8000242c:	854a                	mv	a0,s2
    8000242e:	e1dff0ef          	jal	8000224a <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002432:	015c0abb          	addw	s5,s8,s5
    80002436:	004b2783          	lw	a5,4(s6)
    8000243a:	04faf863          	bgeu	s5,a5,8000248a <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    8000243e:	40dad59b          	sraiw	a1,s5,0xd
    80002442:	01cb2783          	lw	a5,28(s6)
    80002446:	9dbd                	addw	a1,a1,a5
    80002448:	855e                	mv	a0,s7
    8000244a:	cf9ff0ef          	jal	80002142 <bread>
    8000244e:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002450:	004b2503          	lw	a0,4(s6)
    80002454:	84d6                	mv	s1,s5
    80002456:	4701                	li	a4,0
    80002458:	fca4fae3          	bgeu	s1,a0,8000242c <balloc+0x8a>
      m = 1 << (bi % 8);
    8000245c:	00777693          	andi	a3,a4,7
    80002460:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002464:	41f7579b          	sraiw	a5,a4,0x1f
    80002468:	01d7d79b          	srliw	a5,a5,0x1d
    8000246c:	9fb9                	addw	a5,a5,a4
    8000246e:	4037d79b          	sraiw	a5,a5,0x3
    80002472:	00f90633          	add	a2,s2,a5
    80002476:	05864603          	lbu	a2,88(a2)
    8000247a:	00c6f5b3          	and	a1,a3,a2
    8000247e:	ddb1                	beqz	a1,800023da <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002480:	2705                	addiw	a4,a4,1
    80002482:	2485                	addiw	s1,s1,1
    80002484:	fd471ae3          	bne	a4,s4,80002458 <balloc+0xb6>
    80002488:	b755                	j	8000242c <balloc+0x8a>
    8000248a:	7942                	ld	s2,48(sp)
    8000248c:	79a2                	ld	s3,40(sp)
    8000248e:	7a02                	ld	s4,32(sp)
    80002490:	6ae2                	ld	s5,24(sp)
    80002492:	6b42                	ld	s6,16(sp)
    80002494:	6ba2                	ld	s7,8(sp)
    80002496:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    80002498:	00005517          	auipc	a0,0x5
    8000249c:	fc850513          	addi	a0,a0,-56 # 80007460 <etext+0x460>
    800024a0:	6ef020ef          	jal	8000538e <printf>
  return 0;
    800024a4:	4481                	li	s1,0
    800024a6:	bfad                	j	80002420 <balloc+0x7e>

00000000800024a8 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800024a8:	7179                	addi	sp,sp,-48
    800024aa:	f406                	sd	ra,40(sp)
    800024ac:	f022                	sd	s0,32(sp)
    800024ae:	ec26                	sd	s1,24(sp)
    800024b0:	e84a                	sd	s2,16(sp)
    800024b2:	e44e                	sd	s3,8(sp)
    800024b4:	1800                	addi	s0,sp,48
    800024b6:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800024b8:	47ad                	li	a5,11
    800024ba:	02b7e363          	bltu	a5,a1,800024e0 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    800024be:	02059793          	slli	a5,a1,0x20
    800024c2:	01e7d593          	srli	a1,a5,0x1e
    800024c6:	00b509b3          	add	s3,a0,a1
    800024ca:	0509a483          	lw	s1,80(s3)
    800024ce:	e0b5                	bnez	s1,80002532 <bmap+0x8a>
      addr = balloc(ip->dev);
    800024d0:	4108                	lw	a0,0(a0)
    800024d2:	ed1ff0ef          	jal	800023a2 <balloc>
    800024d6:	84aa                	mv	s1,a0
      if(addr == 0)
    800024d8:	cd29                	beqz	a0,80002532 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    800024da:	04a9a823          	sw	a0,80(s3)
    800024de:	a891                	j	80002532 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800024e0:	ff45879b          	addiw	a5,a1,-12
    800024e4:	873e                	mv	a4,a5
    800024e6:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    800024e8:	0ff00793          	li	a5,255
    800024ec:	06e7e763          	bltu	a5,a4,8000255a <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800024f0:	08052483          	lw	s1,128(a0)
    800024f4:	e891                	bnez	s1,80002508 <bmap+0x60>
      addr = balloc(ip->dev);
    800024f6:	4108                	lw	a0,0(a0)
    800024f8:	eabff0ef          	jal	800023a2 <balloc>
    800024fc:	84aa                	mv	s1,a0
      if(addr == 0)
    800024fe:	c915                	beqz	a0,80002532 <bmap+0x8a>
    80002500:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002502:	08a92023          	sw	a0,128(s2)
    80002506:	a011                	j	8000250a <bmap+0x62>
    80002508:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000250a:	85a6                	mv	a1,s1
    8000250c:	00092503          	lw	a0,0(s2)
    80002510:	c33ff0ef          	jal	80002142 <bread>
    80002514:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002516:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000251a:	02099713          	slli	a4,s3,0x20
    8000251e:	01e75593          	srli	a1,a4,0x1e
    80002522:	97ae                	add	a5,a5,a1
    80002524:	89be                	mv	s3,a5
    80002526:	4384                	lw	s1,0(a5)
    80002528:	cc89                	beqz	s1,80002542 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000252a:	8552                	mv	a0,s4
    8000252c:	d1fff0ef          	jal	8000224a <brelse>
    return addr;
    80002530:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002532:	8526                	mv	a0,s1
    80002534:	70a2                	ld	ra,40(sp)
    80002536:	7402                	ld	s0,32(sp)
    80002538:	64e2                	ld	s1,24(sp)
    8000253a:	6942                	ld	s2,16(sp)
    8000253c:	69a2                	ld	s3,8(sp)
    8000253e:	6145                	addi	sp,sp,48
    80002540:	8082                	ret
      addr = balloc(ip->dev);
    80002542:	00092503          	lw	a0,0(s2)
    80002546:	e5dff0ef          	jal	800023a2 <balloc>
    8000254a:	84aa                	mv	s1,a0
      if(addr){
    8000254c:	dd79                	beqz	a0,8000252a <bmap+0x82>
        a[bn] = addr;
    8000254e:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002552:	8552                	mv	a0,s4
    80002554:	543000ef          	jal	80003296 <log_write>
    80002558:	bfc9                	j	8000252a <bmap+0x82>
    8000255a:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    8000255c:	00005517          	auipc	a0,0x5
    80002560:	f1c50513          	addi	a0,a0,-228 # 80007478 <etext+0x478>
    80002564:	13a030ef          	jal	8000569e <panic>

0000000080002568 <iget>:
{
    80002568:	7179                	addi	sp,sp,-48
    8000256a:	f406                	sd	ra,40(sp)
    8000256c:	f022                	sd	s0,32(sp)
    8000256e:	ec26                	sd	s1,24(sp)
    80002570:	e84a                	sd	s2,16(sp)
    80002572:	e44e                	sd	s3,8(sp)
    80002574:	e052                	sd	s4,0(sp)
    80002576:	1800                	addi	s0,sp,48
    80002578:	892a                	mv	s2,a0
    8000257a:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000257c:	00014517          	auipc	a0,0x14
    80002580:	b7c50513          	addi	a0,a0,-1156 # 800160f8 <itable>
    80002584:	458030ef          	jal	800059dc <acquire>
  empty = 0;
    80002588:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000258a:	00014497          	auipc	s1,0x14
    8000258e:	b8648493          	addi	s1,s1,-1146 # 80016110 <itable+0x18>
    80002592:	00015697          	auipc	a3,0x15
    80002596:	60e68693          	addi	a3,a3,1550 # 80017ba0 <log>
    8000259a:	a809                	j	800025ac <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    8000259c:	e781                	bnez	a5,800025a4 <iget+0x3c>
    8000259e:	00099363          	bnez	s3,800025a4 <iget+0x3c>
      empty = ip;
    800025a2:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800025a4:	08848493          	addi	s1,s1,136
    800025a8:	02d48563          	beq	s1,a3,800025d2 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800025ac:	449c                	lw	a5,8(s1)
    800025ae:	fef057e3          	blez	a5,8000259c <iget+0x34>
    800025b2:	4098                	lw	a4,0(s1)
    800025b4:	ff2718e3          	bne	a4,s2,800025a4 <iget+0x3c>
    800025b8:	40d8                	lw	a4,4(s1)
    800025ba:	ff4715e3          	bne	a4,s4,800025a4 <iget+0x3c>
      ip->ref++;
    800025be:	2785                	addiw	a5,a5,1
    800025c0:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800025c2:	00014517          	auipc	a0,0x14
    800025c6:	b3650513          	addi	a0,a0,-1226 # 800160f8 <itable>
    800025ca:	4a6030ef          	jal	80005a70 <release>
      return ip;
    800025ce:	89a6                	mv	s3,s1
    800025d0:	a015                	j	800025f4 <iget+0x8c>
  if(empty == 0)
    800025d2:	02098a63          	beqz	s3,80002606 <iget+0x9e>
  ip->dev = dev;
    800025d6:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    800025da:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    800025de:	4785                	li	a5,1
    800025e0:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    800025e4:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    800025e8:	00014517          	auipc	a0,0x14
    800025ec:	b1050513          	addi	a0,a0,-1264 # 800160f8 <itable>
    800025f0:	480030ef          	jal	80005a70 <release>
}
    800025f4:	854e                	mv	a0,s3
    800025f6:	70a2                	ld	ra,40(sp)
    800025f8:	7402                	ld	s0,32(sp)
    800025fa:	64e2                	ld	s1,24(sp)
    800025fc:	6942                	ld	s2,16(sp)
    800025fe:	69a2                	ld	s3,8(sp)
    80002600:	6a02                	ld	s4,0(sp)
    80002602:	6145                	addi	sp,sp,48
    80002604:	8082                	ret
    panic("iget: no inodes");
    80002606:	00005517          	auipc	a0,0x5
    8000260a:	e8a50513          	addi	a0,a0,-374 # 80007490 <etext+0x490>
    8000260e:	090030ef          	jal	8000569e <panic>

0000000080002612 <fsinit>:
fsinit(int dev) {
    80002612:	1101                	addi	sp,sp,-32
    80002614:	ec06                	sd	ra,24(sp)
    80002616:	e822                	sd	s0,16(sp)
    80002618:	e426                	sd	s1,8(sp)
    8000261a:	e04a                	sd	s2,0(sp)
    8000261c:	1000                	addi	s0,sp,32
    8000261e:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002620:	4585                	li	a1,1
    80002622:	b21ff0ef          	jal	80002142 <bread>
    80002626:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002628:	02000613          	li	a2,32
    8000262c:	05850593          	addi	a1,a0,88
    80002630:	00014517          	auipc	a0,0x14
    80002634:	aa850513          	addi	a0,a0,-1368 # 800160d8 <sb>
    80002638:	b87fd0ef          	jal	800001be <memmove>
  brelse(bp);
    8000263c:	8526                	mv	a0,s1
    8000263e:	c0dff0ef          	jal	8000224a <brelse>
  if(sb.magic != FSMAGIC)
    80002642:	00014717          	auipc	a4,0x14
    80002646:	a9672703          	lw	a4,-1386(a4) # 800160d8 <sb>
    8000264a:	102037b7          	lui	a5,0x10203
    8000264e:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002652:	00f71f63          	bne	a4,a5,80002670 <fsinit+0x5e>
  initlog(dev, &sb);
    80002656:	00014597          	auipc	a1,0x14
    8000265a:	a8258593          	addi	a1,a1,-1406 # 800160d8 <sb>
    8000265e:	854a                	mv	a0,s2
    80002660:	219000ef          	jal	80003078 <initlog>
}
    80002664:	60e2                	ld	ra,24(sp)
    80002666:	6442                	ld	s0,16(sp)
    80002668:	64a2                	ld	s1,8(sp)
    8000266a:	6902                	ld	s2,0(sp)
    8000266c:	6105                	addi	sp,sp,32
    8000266e:	8082                	ret
    panic("invalid file system");
    80002670:	00005517          	auipc	a0,0x5
    80002674:	e3050513          	addi	a0,a0,-464 # 800074a0 <etext+0x4a0>
    80002678:	026030ef          	jal	8000569e <panic>

000000008000267c <iinit>:
{
    8000267c:	7179                	addi	sp,sp,-48
    8000267e:	f406                	sd	ra,40(sp)
    80002680:	f022                	sd	s0,32(sp)
    80002682:	ec26                	sd	s1,24(sp)
    80002684:	e84a                	sd	s2,16(sp)
    80002686:	e44e                	sd	s3,8(sp)
    80002688:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000268a:	00005597          	auipc	a1,0x5
    8000268e:	e2e58593          	addi	a1,a1,-466 # 800074b8 <etext+0x4b8>
    80002692:	00014517          	auipc	a0,0x14
    80002696:	a6650513          	addi	a0,a0,-1434 # 800160f8 <itable>
    8000269a:	2b8030ef          	jal	80005952 <initlock>
  for(i = 0; i < NINODE; i++) {
    8000269e:	00014497          	auipc	s1,0x14
    800026a2:	a8248493          	addi	s1,s1,-1406 # 80016120 <itable+0x28>
    800026a6:	00015997          	auipc	s3,0x15
    800026aa:	50a98993          	addi	s3,s3,1290 # 80017bb0 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800026ae:	00005917          	auipc	s2,0x5
    800026b2:	e1290913          	addi	s2,s2,-494 # 800074c0 <etext+0x4c0>
    800026b6:	85ca                	mv	a1,s2
    800026b8:	8526                	mv	a0,s1
    800026ba:	4af000ef          	jal	80003368 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800026be:	08848493          	addi	s1,s1,136
    800026c2:	ff349ae3          	bne	s1,s3,800026b6 <iinit+0x3a>
}
    800026c6:	70a2                	ld	ra,40(sp)
    800026c8:	7402                	ld	s0,32(sp)
    800026ca:	64e2                	ld	s1,24(sp)
    800026cc:	6942                	ld	s2,16(sp)
    800026ce:	69a2                	ld	s3,8(sp)
    800026d0:	6145                	addi	sp,sp,48
    800026d2:	8082                	ret

00000000800026d4 <ialloc>:
{
    800026d4:	7139                	addi	sp,sp,-64
    800026d6:	fc06                	sd	ra,56(sp)
    800026d8:	f822                	sd	s0,48(sp)
    800026da:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    800026dc:	00014717          	auipc	a4,0x14
    800026e0:	a0872703          	lw	a4,-1528(a4) # 800160e4 <sb+0xc>
    800026e4:	4785                	li	a5,1
    800026e6:	06e7f063          	bgeu	a5,a4,80002746 <ialloc+0x72>
    800026ea:	f426                	sd	s1,40(sp)
    800026ec:	f04a                	sd	s2,32(sp)
    800026ee:	ec4e                	sd	s3,24(sp)
    800026f0:	e852                	sd	s4,16(sp)
    800026f2:	e456                	sd	s5,8(sp)
    800026f4:	e05a                	sd	s6,0(sp)
    800026f6:	8aaa                	mv	s5,a0
    800026f8:	8b2e                	mv	s6,a1
    800026fa:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    800026fc:	00014a17          	auipc	s4,0x14
    80002700:	9dca0a13          	addi	s4,s4,-1572 # 800160d8 <sb>
    80002704:	00495593          	srli	a1,s2,0x4
    80002708:	018a2783          	lw	a5,24(s4)
    8000270c:	9dbd                	addw	a1,a1,a5
    8000270e:	8556                	mv	a0,s5
    80002710:	a33ff0ef          	jal	80002142 <bread>
    80002714:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80002716:	05850993          	addi	s3,a0,88
    8000271a:	00f97793          	andi	a5,s2,15
    8000271e:	079a                	slli	a5,a5,0x6
    80002720:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002722:	00099783          	lh	a5,0(s3)
    80002726:	cb9d                	beqz	a5,8000275c <ialloc+0x88>
    brelse(bp);
    80002728:	b23ff0ef          	jal	8000224a <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000272c:	0905                	addi	s2,s2,1
    8000272e:	00ca2703          	lw	a4,12(s4)
    80002732:	0009079b          	sext.w	a5,s2
    80002736:	fce7e7e3          	bltu	a5,a4,80002704 <ialloc+0x30>
    8000273a:	74a2                	ld	s1,40(sp)
    8000273c:	7902                	ld	s2,32(sp)
    8000273e:	69e2                	ld	s3,24(sp)
    80002740:	6a42                	ld	s4,16(sp)
    80002742:	6aa2                	ld	s5,8(sp)
    80002744:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80002746:	00005517          	auipc	a0,0x5
    8000274a:	d8250513          	addi	a0,a0,-638 # 800074c8 <etext+0x4c8>
    8000274e:	441020ef          	jal	8000538e <printf>
  return 0;
    80002752:	4501                	li	a0,0
}
    80002754:	70e2                	ld	ra,56(sp)
    80002756:	7442                	ld	s0,48(sp)
    80002758:	6121                	addi	sp,sp,64
    8000275a:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    8000275c:	04000613          	li	a2,64
    80002760:	4581                	li	a1,0
    80002762:	854e                	mv	a0,s3
    80002764:	9fbfd0ef          	jal	8000015e <memset>
      dip->type = type;
    80002768:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    8000276c:	8526                	mv	a0,s1
    8000276e:	329000ef          	jal	80003296 <log_write>
      brelse(bp);
    80002772:	8526                	mv	a0,s1
    80002774:	ad7ff0ef          	jal	8000224a <brelse>
      return iget(dev, inum);
    80002778:	0009059b          	sext.w	a1,s2
    8000277c:	8556                	mv	a0,s5
    8000277e:	debff0ef          	jal	80002568 <iget>
    80002782:	74a2                	ld	s1,40(sp)
    80002784:	7902                	ld	s2,32(sp)
    80002786:	69e2                	ld	s3,24(sp)
    80002788:	6a42                	ld	s4,16(sp)
    8000278a:	6aa2                	ld	s5,8(sp)
    8000278c:	6b02                	ld	s6,0(sp)
    8000278e:	b7d9                	j	80002754 <ialloc+0x80>

0000000080002790 <iupdate>:
{
    80002790:	1101                	addi	sp,sp,-32
    80002792:	ec06                	sd	ra,24(sp)
    80002794:	e822                	sd	s0,16(sp)
    80002796:	e426                	sd	s1,8(sp)
    80002798:	e04a                	sd	s2,0(sp)
    8000279a:	1000                	addi	s0,sp,32
    8000279c:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000279e:	415c                	lw	a5,4(a0)
    800027a0:	0047d79b          	srliw	a5,a5,0x4
    800027a4:	00014597          	auipc	a1,0x14
    800027a8:	94c5a583          	lw	a1,-1716(a1) # 800160f0 <sb+0x18>
    800027ac:	9dbd                	addw	a1,a1,a5
    800027ae:	4108                	lw	a0,0(a0)
    800027b0:	993ff0ef          	jal	80002142 <bread>
    800027b4:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800027b6:	05850793          	addi	a5,a0,88
    800027ba:	40d8                	lw	a4,4(s1)
    800027bc:	8b3d                	andi	a4,a4,15
    800027be:	071a                	slli	a4,a4,0x6
    800027c0:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800027c2:	04449703          	lh	a4,68(s1)
    800027c6:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800027ca:	04649703          	lh	a4,70(s1)
    800027ce:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800027d2:	04849703          	lh	a4,72(s1)
    800027d6:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800027da:	04a49703          	lh	a4,74(s1)
    800027de:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800027e2:	44f8                	lw	a4,76(s1)
    800027e4:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800027e6:	03400613          	li	a2,52
    800027ea:	05048593          	addi	a1,s1,80
    800027ee:	00c78513          	addi	a0,a5,12
    800027f2:	9cdfd0ef          	jal	800001be <memmove>
  log_write(bp);
    800027f6:	854a                	mv	a0,s2
    800027f8:	29f000ef          	jal	80003296 <log_write>
  brelse(bp);
    800027fc:	854a                	mv	a0,s2
    800027fe:	a4dff0ef          	jal	8000224a <brelse>
}
    80002802:	60e2                	ld	ra,24(sp)
    80002804:	6442                	ld	s0,16(sp)
    80002806:	64a2                	ld	s1,8(sp)
    80002808:	6902                	ld	s2,0(sp)
    8000280a:	6105                	addi	sp,sp,32
    8000280c:	8082                	ret

000000008000280e <idup>:
{
    8000280e:	1101                	addi	sp,sp,-32
    80002810:	ec06                	sd	ra,24(sp)
    80002812:	e822                	sd	s0,16(sp)
    80002814:	e426                	sd	s1,8(sp)
    80002816:	1000                	addi	s0,sp,32
    80002818:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000281a:	00014517          	auipc	a0,0x14
    8000281e:	8de50513          	addi	a0,a0,-1826 # 800160f8 <itable>
    80002822:	1ba030ef          	jal	800059dc <acquire>
  ip->ref++;
    80002826:	449c                	lw	a5,8(s1)
    80002828:	2785                	addiw	a5,a5,1
    8000282a:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000282c:	00014517          	auipc	a0,0x14
    80002830:	8cc50513          	addi	a0,a0,-1844 # 800160f8 <itable>
    80002834:	23c030ef          	jal	80005a70 <release>
}
    80002838:	8526                	mv	a0,s1
    8000283a:	60e2                	ld	ra,24(sp)
    8000283c:	6442                	ld	s0,16(sp)
    8000283e:	64a2                	ld	s1,8(sp)
    80002840:	6105                	addi	sp,sp,32
    80002842:	8082                	ret

0000000080002844 <ilock>:
{
    80002844:	1101                	addi	sp,sp,-32
    80002846:	ec06                	sd	ra,24(sp)
    80002848:	e822                	sd	s0,16(sp)
    8000284a:	e426                	sd	s1,8(sp)
    8000284c:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000284e:	cd19                	beqz	a0,8000286c <ilock+0x28>
    80002850:	84aa                	mv	s1,a0
    80002852:	451c                	lw	a5,8(a0)
    80002854:	00f05c63          	blez	a5,8000286c <ilock+0x28>
  acquiresleep(&ip->lock);
    80002858:	0541                	addi	a0,a0,16
    8000285a:	345000ef          	jal	8000339e <acquiresleep>
  if(ip->valid == 0){
    8000285e:	40bc                	lw	a5,64(s1)
    80002860:	cf89                	beqz	a5,8000287a <ilock+0x36>
}
    80002862:	60e2                	ld	ra,24(sp)
    80002864:	6442                	ld	s0,16(sp)
    80002866:	64a2                	ld	s1,8(sp)
    80002868:	6105                	addi	sp,sp,32
    8000286a:	8082                	ret
    8000286c:	e04a                	sd	s2,0(sp)
    panic("ilock");
    8000286e:	00005517          	auipc	a0,0x5
    80002872:	c7250513          	addi	a0,a0,-910 # 800074e0 <etext+0x4e0>
    80002876:	629020ef          	jal	8000569e <panic>
    8000287a:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000287c:	40dc                	lw	a5,4(s1)
    8000287e:	0047d79b          	srliw	a5,a5,0x4
    80002882:	00014597          	auipc	a1,0x14
    80002886:	86e5a583          	lw	a1,-1938(a1) # 800160f0 <sb+0x18>
    8000288a:	9dbd                	addw	a1,a1,a5
    8000288c:	4088                	lw	a0,0(s1)
    8000288e:	8b5ff0ef          	jal	80002142 <bread>
    80002892:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80002894:	05850593          	addi	a1,a0,88
    80002898:	40dc                	lw	a5,4(s1)
    8000289a:	8bbd                	andi	a5,a5,15
    8000289c:	079a                	slli	a5,a5,0x6
    8000289e:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800028a0:	00059783          	lh	a5,0(a1)
    800028a4:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800028a8:	00259783          	lh	a5,2(a1)
    800028ac:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800028b0:	00459783          	lh	a5,4(a1)
    800028b4:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800028b8:	00659783          	lh	a5,6(a1)
    800028bc:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800028c0:	459c                	lw	a5,8(a1)
    800028c2:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800028c4:	03400613          	li	a2,52
    800028c8:	05b1                	addi	a1,a1,12
    800028ca:	05048513          	addi	a0,s1,80
    800028ce:	8f1fd0ef          	jal	800001be <memmove>
    brelse(bp);
    800028d2:	854a                	mv	a0,s2
    800028d4:	977ff0ef          	jal	8000224a <brelse>
    ip->valid = 1;
    800028d8:	4785                	li	a5,1
    800028da:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800028dc:	04449783          	lh	a5,68(s1)
    800028e0:	c399                	beqz	a5,800028e6 <ilock+0xa2>
    800028e2:	6902                	ld	s2,0(sp)
    800028e4:	bfbd                	j	80002862 <ilock+0x1e>
      panic("ilock: no type");
    800028e6:	00005517          	auipc	a0,0x5
    800028ea:	c0250513          	addi	a0,a0,-1022 # 800074e8 <etext+0x4e8>
    800028ee:	5b1020ef          	jal	8000569e <panic>

00000000800028f2 <iunlock>:
{
    800028f2:	1101                	addi	sp,sp,-32
    800028f4:	ec06                	sd	ra,24(sp)
    800028f6:	e822                	sd	s0,16(sp)
    800028f8:	e426                	sd	s1,8(sp)
    800028fa:	e04a                	sd	s2,0(sp)
    800028fc:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800028fe:	c505                	beqz	a0,80002926 <iunlock+0x34>
    80002900:	84aa                	mv	s1,a0
    80002902:	01050913          	addi	s2,a0,16
    80002906:	854a                	mv	a0,s2
    80002908:	315000ef          	jal	8000341c <holdingsleep>
    8000290c:	cd09                	beqz	a0,80002926 <iunlock+0x34>
    8000290e:	449c                	lw	a5,8(s1)
    80002910:	00f05b63          	blez	a5,80002926 <iunlock+0x34>
  releasesleep(&ip->lock);
    80002914:	854a                	mv	a0,s2
    80002916:	2cf000ef          	jal	800033e4 <releasesleep>
}
    8000291a:	60e2                	ld	ra,24(sp)
    8000291c:	6442                	ld	s0,16(sp)
    8000291e:	64a2                	ld	s1,8(sp)
    80002920:	6902                	ld	s2,0(sp)
    80002922:	6105                	addi	sp,sp,32
    80002924:	8082                	ret
    panic("iunlock");
    80002926:	00005517          	auipc	a0,0x5
    8000292a:	bd250513          	addi	a0,a0,-1070 # 800074f8 <etext+0x4f8>
    8000292e:	571020ef          	jal	8000569e <panic>

0000000080002932 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80002932:	7179                	addi	sp,sp,-48
    80002934:	f406                	sd	ra,40(sp)
    80002936:	f022                	sd	s0,32(sp)
    80002938:	ec26                	sd	s1,24(sp)
    8000293a:	e84a                	sd	s2,16(sp)
    8000293c:	e44e                	sd	s3,8(sp)
    8000293e:	1800                	addi	s0,sp,48
    80002940:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80002942:	05050493          	addi	s1,a0,80
    80002946:	08050913          	addi	s2,a0,128
    8000294a:	a021                	j	80002952 <itrunc+0x20>
    8000294c:	0491                	addi	s1,s1,4
    8000294e:	01248b63          	beq	s1,s2,80002964 <itrunc+0x32>
    if(ip->addrs[i]){
    80002952:	408c                	lw	a1,0(s1)
    80002954:	dde5                	beqz	a1,8000294c <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80002956:	0009a503          	lw	a0,0(s3)
    8000295a:	9ddff0ef          	jal	80002336 <bfree>
      ip->addrs[i] = 0;
    8000295e:	0004a023          	sw	zero,0(s1)
    80002962:	b7ed                	j	8000294c <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80002964:	0809a583          	lw	a1,128(s3)
    80002968:	ed89                	bnez	a1,80002982 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000296a:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    8000296e:	854e                	mv	a0,s3
    80002970:	e21ff0ef          	jal	80002790 <iupdate>
}
    80002974:	70a2                	ld	ra,40(sp)
    80002976:	7402                	ld	s0,32(sp)
    80002978:	64e2                	ld	s1,24(sp)
    8000297a:	6942                	ld	s2,16(sp)
    8000297c:	69a2                	ld	s3,8(sp)
    8000297e:	6145                	addi	sp,sp,48
    80002980:	8082                	ret
    80002982:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80002984:	0009a503          	lw	a0,0(s3)
    80002988:	fbaff0ef          	jal	80002142 <bread>
    8000298c:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    8000298e:	05850493          	addi	s1,a0,88
    80002992:	45850913          	addi	s2,a0,1112
    80002996:	a021                	j	8000299e <itrunc+0x6c>
    80002998:	0491                	addi	s1,s1,4
    8000299a:	01248963          	beq	s1,s2,800029ac <itrunc+0x7a>
      if(a[j])
    8000299e:	408c                	lw	a1,0(s1)
    800029a0:	dde5                	beqz	a1,80002998 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800029a2:	0009a503          	lw	a0,0(s3)
    800029a6:	991ff0ef          	jal	80002336 <bfree>
    800029aa:	b7fd                	j	80002998 <itrunc+0x66>
    brelse(bp);
    800029ac:	8552                	mv	a0,s4
    800029ae:	89dff0ef          	jal	8000224a <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800029b2:	0809a583          	lw	a1,128(s3)
    800029b6:	0009a503          	lw	a0,0(s3)
    800029ba:	97dff0ef          	jal	80002336 <bfree>
    ip->addrs[NDIRECT] = 0;
    800029be:	0809a023          	sw	zero,128(s3)
    800029c2:	6a02                	ld	s4,0(sp)
    800029c4:	b75d                	j	8000296a <itrunc+0x38>

00000000800029c6 <iput>:
{
    800029c6:	1101                	addi	sp,sp,-32
    800029c8:	ec06                	sd	ra,24(sp)
    800029ca:	e822                	sd	s0,16(sp)
    800029cc:	e426                	sd	s1,8(sp)
    800029ce:	1000                	addi	s0,sp,32
    800029d0:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800029d2:	00013517          	auipc	a0,0x13
    800029d6:	72650513          	addi	a0,a0,1830 # 800160f8 <itable>
    800029da:	002030ef          	jal	800059dc <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800029de:	4498                	lw	a4,8(s1)
    800029e0:	4785                	li	a5,1
    800029e2:	02f70063          	beq	a4,a5,80002a02 <iput+0x3c>
  ip->ref--;
    800029e6:	449c                	lw	a5,8(s1)
    800029e8:	37fd                	addiw	a5,a5,-1
    800029ea:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800029ec:	00013517          	auipc	a0,0x13
    800029f0:	70c50513          	addi	a0,a0,1804 # 800160f8 <itable>
    800029f4:	07c030ef          	jal	80005a70 <release>
}
    800029f8:	60e2                	ld	ra,24(sp)
    800029fa:	6442                	ld	s0,16(sp)
    800029fc:	64a2                	ld	s1,8(sp)
    800029fe:	6105                	addi	sp,sp,32
    80002a00:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a02:	40bc                	lw	a5,64(s1)
    80002a04:	d3ed                	beqz	a5,800029e6 <iput+0x20>
    80002a06:	04a49783          	lh	a5,74(s1)
    80002a0a:	fff1                	bnez	a5,800029e6 <iput+0x20>
    80002a0c:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80002a0e:	01048793          	addi	a5,s1,16
    80002a12:	893e                	mv	s2,a5
    80002a14:	853e                	mv	a0,a5
    80002a16:	189000ef          	jal	8000339e <acquiresleep>
    release(&itable.lock);
    80002a1a:	00013517          	auipc	a0,0x13
    80002a1e:	6de50513          	addi	a0,a0,1758 # 800160f8 <itable>
    80002a22:	04e030ef          	jal	80005a70 <release>
    itrunc(ip);
    80002a26:	8526                	mv	a0,s1
    80002a28:	f0bff0ef          	jal	80002932 <itrunc>
    ip->type = 0;
    80002a2c:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002a30:	8526                	mv	a0,s1
    80002a32:	d5fff0ef          	jal	80002790 <iupdate>
    ip->valid = 0;
    80002a36:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002a3a:	854a                	mv	a0,s2
    80002a3c:	1a9000ef          	jal	800033e4 <releasesleep>
    acquire(&itable.lock);
    80002a40:	00013517          	auipc	a0,0x13
    80002a44:	6b850513          	addi	a0,a0,1720 # 800160f8 <itable>
    80002a48:	795020ef          	jal	800059dc <acquire>
    80002a4c:	6902                	ld	s2,0(sp)
    80002a4e:	bf61                	j	800029e6 <iput+0x20>

0000000080002a50 <iunlockput>:
{
    80002a50:	1101                	addi	sp,sp,-32
    80002a52:	ec06                	sd	ra,24(sp)
    80002a54:	e822                	sd	s0,16(sp)
    80002a56:	e426                	sd	s1,8(sp)
    80002a58:	1000                	addi	s0,sp,32
    80002a5a:	84aa                	mv	s1,a0
  iunlock(ip);
    80002a5c:	e97ff0ef          	jal	800028f2 <iunlock>
  iput(ip);
    80002a60:	8526                	mv	a0,s1
    80002a62:	f65ff0ef          	jal	800029c6 <iput>
}
    80002a66:	60e2                	ld	ra,24(sp)
    80002a68:	6442                	ld	s0,16(sp)
    80002a6a:	64a2                	ld	s1,8(sp)
    80002a6c:	6105                	addi	sp,sp,32
    80002a6e:	8082                	ret

0000000080002a70 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002a70:	1141                	addi	sp,sp,-16
    80002a72:	e406                	sd	ra,8(sp)
    80002a74:	e022                	sd	s0,0(sp)
    80002a76:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80002a78:	411c                	lw	a5,0(a0)
    80002a7a:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002a7c:	415c                	lw	a5,4(a0)
    80002a7e:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002a80:	04451783          	lh	a5,68(a0)
    80002a84:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80002a88:	04a51783          	lh	a5,74(a0)
    80002a8c:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002a90:	04c56783          	lwu	a5,76(a0)
    80002a94:	e99c                	sd	a5,16(a1)
}
    80002a96:	60a2                	ld	ra,8(sp)
    80002a98:	6402                	ld	s0,0(sp)
    80002a9a:	0141                	addi	sp,sp,16
    80002a9c:	8082                	ret

0000000080002a9e <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002a9e:	457c                	lw	a5,76(a0)
    80002aa0:	0ed7e663          	bltu	a5,a3,80002b8c <readi+0xee>
{
    80002aa4:	7159                	addi	sp,sp,-112
    80002aa6:	f486                	sd	ra,104(sp)
    80002aa8:	f0a2                	sd	s0,96(sp)
    80002aaa:	eca6                	sd	s1,88(sp)
    80002aac:	e0d2                	sd	s4,64(sp)
    80002aae:	fc56                	sd	s5,56(sp)
    80002ab0:	f85a                	sd	s6,48(sp)
    80002ab2:	f45e                	sd	s7,40(sp)
    80002ab4:	1880                	addi	s0,sp,112
    80002ab6:	8b2a                	mv	s6,a0
    80002ab8:	8bae                	mv	s7,a1
    80002aba:	8a32                	mv	s4,a2
    80002abc:	84b6                	mv	s1,a3
    80002abe:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80002ac0:	9f35                	addw	a4,a4,a3
    return 0;
    80002ac2:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002ac4:	0ad76b63          	bltu	a4,a3,80002b7a <readi+0xdc>
    80002ac8:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80002aca:	00e7f463          	bgeu	a5,a4,80002ad2 <readi+0x34>
    n = ip->size - off;
    80002ace:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002ad2:	080a8b63          	beqz	s5,80002b68 <readi+0xca>
    80002ad6:	e8ca                	sd	s2,80(sp)
    80002ad8:	f062                	sd	s8,32(sp)
    80002ada:	ec66                	sd	s9,24(sp)
    80002adc:	e86a                	sd	s10,16(sp)
    80002ade:	e46e                	sd	s11,8(sp)
    80002ae0:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002ae2:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002ae6:	5c7d                	li	s8,-1
    80002ae8:	a80d                	j	80002b1a <readi+0x7c>
    80002aea:	020d1d93          	slli	s11,s10,0x20
    80002aee:	020ddd93          	srli	s11,s11,0x20
    80002af2:	05890613          	addi	a2,s2,88
    80002af6:	86ee                	mv	a3,s11
    80002af8:	963e                	add	a2,a2,a5
    80002afa:	85d2                	mv	a1,s4
    80002afc:	855e                	mv	a0,s7
    80002afe:	d69fe0ef          	jal	80001866 <either_copyout>
    80002b02:	05850363          	beq	a0,s8,80002b48 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002b06:	854a                	mv	a0,s2
    80002b08:	f42ff0ef          	jal	8000224a <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b0c:	013d09bb          	addw	s3,s10,s3
    80002b10:	009d04bb          	addw	s1,s10,s1
    80002b14:	9a6e                	add	s4,s4,s11
    80002b16:	0559f363          	bgeu	s3,s5,80002b5c <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002b1a:	00a4d59b          	srliw	a1,s1,0xa
    80002b1e:	855a                	mv	a0,s6
    80002b20:	989ff0ef          	jal	800024a8 <bmap>
    80002b24:	85aa                	mv	a1,a0
    if(addr == 0)
    80002b26:	c139                	beqz	a0,80002b6c <readi+0xce>
    bp = bread(ip->dev, addr);
    80002b28:	000b2503          	lw	a0,0(s6)
    80002b2c:	e16ff0ef          	jal	80002142 <bread>
    80002b30:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b32:	3ff4f793          	andi	a5,s1,1023
    80002b36:	40fc873b          	subw	a4,s9,a5
    80002b3a:	413a86bb          	subw	a3,s5,s3
    80002b3e:	8d3a                	mv	s10,a4
    80002b40:	fae6f5e3          	bgeu	a3,a4,80002aea <readi+0x4c>
    80002b44:	8d36                	mv	s10,a3
    80002b46:	b755                	j	80002aea <readi+0x4c>
      brelse(bp);
    80002b48:	854a                	mv	a0,s2
    80002b4a:	f00ff0ef          	jal	8000224a <brelse>
      tot = -1;
    80002b4e:	59fd                	li	s3,-1
      break;
    80002b50:	6946                	ld	s2,80(sp)
    80002b52:	7c02                	ld	s8,32(sp)
    80002b54:	6ce2                	ld	s9,24(sp)
    80002b56:	6d42                	ld	s10,16(sp)
    80002b58:	6da2                	ld	s11,8(sp)
    80002b5a:	a831                	j	80002b76 <readi+0xd8>
    80002b5c:	6946                	ld	s2,80(sp)
    80002b5e:	7c02                	ld	s8,32(sp)
    80002b60:	6ce2                	ld	s9,24(sp)
    80002b62:	6d42                	ld	s10,16(sp)
    80002b64:	6da2                	ld	s11,8(sp)
    80002b66:	a801                	j	80002b76 <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b68:	89d6                	mv	s3,s5
    80002b6a:	a031                	j	80002b76 <readi+0xd8>
    80002b6c:	6946                	ld	s2,80(sp)
    80002b6e:	7c02                	ld	s8,32(sp)
    80002b70:	6ce2                	ld	s9,24(sp)
    80002b72:	6d42                	ld	s10,16(sp)
    80002b74:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80002b76:	854e                	mv	a0,s3
    80002b78:	69a6                	ld	s3,72(sp)
}
    80002b7a:	70a6                	ld	ra,104(sp)
    80002b7c:	7406                	ld	s0,96(sp)
    80002b7e:	64e6                	ld	s1,88(sp)
    80002b80:	6a06                	ld	s4,64(sp)
    80002b82:	7ae2                	ld	s5,56(sp)
    80002b84:	7b42                	ld	s6,48(sp)
    80002b86:	7ba2                	ld	s7,40(sp)
    80002b88:	6165                	addi	sp,sp,112
    80002b8a:	8082                	ret
    return 0;
    80002b8c:	4501                	li	a0,0
}
    80002b8e:	8082                	ret

0000000080002b90 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002b90:	457c                	lw	a5,76(a0)
    80002b92:	0ed7eb63          	bltu	a5,a3,80002c88 <writei+0xf8>
{
    80002b96:	7159                	addi	sp,sp,-112
    80002b98:	f486                	sd	ra,104(sp)
    80002b9a:	f0a2                	sd	s0,96(sp)
    80002b9c:	e8ca                	sd	s2,80(sp)
    80002b9e:	e0d2                	sd	s4,64(sp)
    80002ba0:	fc56                	sd	s5,56(sp)
    80002ba2:	f85a                	sd	s6,48(sp)
    80002ba4:	f45e                	sd	s7,40(sp)
    80002ba6:	1880                	addi	s0,sp,112
    80002ba8:	8aaa                	mv	s5,a0
    80002baa:	8bae                	mv	s7,a1
    80002bac:	8a32                	mv	s4,a2
    80002bae:	8936                	mv	s2,a3
    80002bb0:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80002bb2:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80002bb6:	00043737          	lui	a4,0x43
    80002bba:	0cf76963          	bltu	a4,a5,80002c8c <writei+0xfc>
    80002bbe:	0cd7e763          	bltu	a5,a3,80002c8c <writei+0xfc>
    80002bc2:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002bc4:	0a0b0a63          	beqz	s6,80002c78 <writei+0xe8>
    80002bc8:	eca6                	sd	s1,88(sp)
    80002bca:	f062                	sd	s8,32(sp)
    80002bcc:	ec66                	sd	s9,24(sp)
    80002bce:	e86a                	sd	s10,16(sp)
    80002bd0:	e46e                	sd	s11,8(sp)
    80002bd2:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002bd4:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002bd8:	5c7d                	li	s8,-1
    80002bda:	a825                	j	80002c12 <writei+0x82>
    80002bdc:	020d1d93          	slli	s11,s10,0x20
    80002be0:	020ddd93          	srli	s11,s11,0x20
    80002be4:	05848513          	addi	a0,s1,88
    80002be8:	86ee                	mv	a3,s11
    80002bea:	8652                	mv	a2,s4
    80002bec:	85de                	mv	a1,s7
    80002bee:	953e                	add	a0,a0,a5
    80002bf0:	cc1fe0ef          	jal	800018b0 <either_copyin>
    80002bf4:	05850663          	beq	a0,s8,80002c40 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002bf8:	8526                	mv	a0,s1
    80002bfa:	69c000ef          	jal	80003296 <log_write>
    brelse(bp);
    80002bfe:	8526                	mv	a0,s1
    80002c00:	e4aff0ef          	jal	8000224a <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c04:	013d09bb          	addw	s3,s10,s3
    80002c08:	012d093b          	addw	s2,s10,s2
    80002c0c:	9a6e                	add	s4,s4,s11
    80002c0e:	0369fc63          	bgeu	s3,s6,80002c46 <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80002c12:	00a9559b          	srliw	a1,s2,0xa
    80002c16:	8556                	mv	a0,s5
    80002c18:	891ff0ef          	jal	800024a8 <bmap>
    80002c1c:	85aa                	mv	a1,a0
    if(addr == 0)
    80002c1e:	c505                	beqz	a0,80002c46 <writei+0xb6>
    bp = bread(ip->dev, addr);
    80002c20:	000aa503          	lw	a0,0(s5)
    80002c24:	d1eff0ef          	jal	80002142 <bread>
    80002c28:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002c2a:	3ff97793          	andi	a5,s2,1023
    80002c2e:	40fc873b          	subw	a4,s9,a5
    80002c32:	413b06bb          	subw	a3,s6,s3
    80002c36:	8d3a                	mv	s10,a4
    80002c38:	fae6f2e3          	bgeu	a3,a4,80002bdc <writei+0x4c>
    80002c3c:	8d36                	mv	s10,a3
    80002c3e:	bf79                	j	80002bdc <writei+0x4c>
      brelse(bp);
    80002c40:	8526                	mv	a0,s1
    80002c42:	e08ff0ef          	jal	8000224a <brelse>
  }

  if(off > ip->size)
    80002c46:	04caa783          	lw	a5,76(s5)
    80002c4a:	0327f963          	bgeu	a5,s2,80002c7c <writei+0xec>
    ip->size = off;
    80002c4e:	052aa623          	sw	s2,76(s5)
    80002c52:	64e6                	ld	s1,88(sp)
    80002c54:	7c02                	ld	s8,32(sp)
    80002c56:	6ce2                	ld	s9,24(sp)
    80002c58:	6d42                	ld	s10,16(sp)
    80002c5a:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002c5c:	8556                	mv	a0,s5
    80002c5e:	b33ff0ef          	jal	80002790 <iupdate>

  return tot;
    80002c62:	854e                	mv	a0,s3
    80002c64:	69a6                	ld	s3,72(sp)
}
    80002c66:	70a6                	ld	ra,104(sp)
    80002c68:	7406                	ld	s0,96(sp)
    80002c6a:	6946                	ld	s2,80(sp)
    80002c6c:	6a06                	ld	s4,64(sp)
    80002c6e:	7ae2                	ld	s5,56(sp)
    80002c70:	7b42                	ld	s6,48(sp)
    80002c72:	7ba2                	ld	s7,40(sp)
    80002c74:	6165                	addi	sp,sp,112
    80002c76:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c78:	89da                	mv	s3,s6
    80002c7a:	b7cd                	j	80002c5c <writei+0xcc>
    80002c7c:	64e6                	ld	s1,88(sp)
    80002c7e:	7c02                	ld	s8,32(sp)
    80002c80:	6ce2                	ld	s9,24(sp)
    80002c82:	6d42                	ld	s10,16(sp)
    80002c84:	6da2                	ld	s11,8(sp)
    80002c86:	bfd9                	j	80002c5c <writei+0xcc>
    return -1;
    80002c88:	557d                	li	a0,-1
}
    80002c8a:	8082                	ret
    return -1;
    80002c8c:	557d                	li	a0,-1
    80002c8e:	bfe1                	j	80002c66 <writei+0xd6>

0000000080002c90 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002c90:	1141                	addi	sp,sp,-16
    80002c92:	e406                	sd	ra,8(sp)
    80002c94:	e022                	sd	s0,0(sp)
    80002c96:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002c98:	4639                	li	a2,14
    80002c9a:	d98fd0ef          	jal	80000232 <strncmp>
}
    80002c9e:	60a2                	ld	ra,8(sp)
    80002ca0:	6402                	ld	s0,0(sp)
    80002ca2:	0141                	addi	sp,sp,16
    80002ca4:	8082                	ret

0000000080002ca6 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002ca6:	711d                	addi	sp,sp,-96
    80002ca8:	ec86                	sd	ra,88(sp)
    80002caa:	e8a2                	sd	s0,80(sp)
    80002cac:	e4a6                	sd	s1,72(sp)
    80002cae:	e0ca                	sd	s2,64(sp)
    80002cb0:	fc4e                	sd	s3,56(sp)
    80002cb2:	f852                	sd	s4,48(sp)
    80002cb4:	f456                	sd	s5,40(sp)
    80002cb6:	f05a                	sd	s6,32(sp)
    80002cb8:	ec5e                	sd	s7,24(sp)
    80002cba:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002cbc:	04451703          	lh	a4,68(a0)
    80002cc0:	4785                	li	a5,1
    80002cc2:	00f71f63          	bne	a4,a5,80002ce0 <dirlookup+0x3a>
    80002cc6:	892a                	mv	s2,a0
    80002cc8:	8aae                	mv	s5,a1
    80002cca:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ccc:	457c                	lw	a5,76(a0)
    80002cce:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002cd0:	fa040a13          	addi	s4,s0,-96
    80002cd4:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80002cd6:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002cda:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002cdc:	e39d                	bnez	a5,80002d02 <dirlookup+0x5c>
    80002cde:	a8b9                	j	80002d3c <dirlookup+0x96>
    panic("dirlookup not DIR");
    80002ce0:	00005517          	auipc	a0,0x5
    80002ce4:	82050513          	addi	a0,a0,-2016 # 80007500 <etext+0x500>
    80002ce8:	1b7020ef          	jal	8000569e <panic>
      panic("dirlookup read");
    80002cec:	00005517          	auipc	a0,0x5
    80002cf0:	82c50513          	addi	a0,a0,-2004 # 80007518 <etext+0x518>
    80002cf4:	1ab020ef          	jal	8000569e <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002cf8:	24c1                	addiw	s1,s1,16
    80002cfa:	04c92783          	lw	a5,76(s2)
    80002cfe:	02f4fe63          	bgeu	s1,a5,80002d3a <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d02:	874e                	mv	a4,s3
    80002d04:	86a6                	mv	a3,s1
    80002d06:	8652                	mv	a2,s4
    80002d08:	4581                	li	a1,0
    80002d0a:	854a                	mv	a0,s2
    80002d0c:	d93ff0ef          	jal	80002a9e <readi>
    80002d10:	fd351ee3          	bne	a0,s3,80002cec <dirlookup+0x46>
    if(de.inum == 0)
    80002d14:	fa045783          	lhu	a5,-96(s0)
    80002d18:	d3e5                	beqz	a5,80002cf8 <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80002d1a:	85da                	mv	a1,s6
    80002d1c:	8556                	mv	a0,s5
    80002d1e:	f73ff0ef          	jal	80002c90 <namecmp>
    80002d22:	f979                	bnez	a0,80002cf8 <dirlookup+0x52>
      if(poff)
    80002d24:	000b8463          	beqz	s7,80002d2c <dirlookup+0x86>
        *poff = off;
    80002d28:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80002d2c:	fa045583          	lhu	a1,-96(s0)
    80002d30:	00092503          	lw	a0,0(s2)
    80002d34:	835ff0ef          	jal	80002568 <iget>
    80002d38:	a011                	j	80002d3c <dirlookup+0x96>
  return 0;
    80002d3a:	4501                	li	a0,0
}
    80002d3c:	60e6                	ld	ra,88(sp)
    80002d3e:	6446                	ld	s0,80(sp)
    80002d40:	64a6                	ld	s1,72(sp)
    80002d42:	6906                	ld	s2,64(sp)
    80002d44:	79e2                	ld	s3,56(sp)
    80002d46:	7a42                	ld	s4,48(sp)
    80002d48:	7aa2                	ld	s5,40(sp)
    80002d4a:	7b02                	ld	s6,32(sp)
    80002d4c:	6be2                	ld	s7,24(sp)
    80002d4e:	6125                	addi	sp,sp,96
    80002d50:	8082                	ret

0000000080002d52 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002d52:	711d                	addi	sp,sp,-96
    80002d54:	ec86                	sd	ra,88(sp)
    80002d56:	e8a2                	sd	s0,80(sp)
    80002d58:	e4a6                	sd	s1,72(sp)
    80002d5a:	e0ca                	sd	s2,64(sp)
    80002d5c:	fc4e                	sd	s3,56(sp)
    80002d5e:	f852                	sd	s4,48(sp)
    80002d60:	f456                	sd	s5,40(sp)
    80002d62:	f05a                	sd	s6,32(sp)
    80002d64:	ec5e                	sd	s7,24(sp)
    80002d66:	e862                	sd	s8,16(sp)
    80002d68:	e466                	sd	s9,8(sp)
    80002d6a:	e06a                	sd	s10,0(sp)
    80002d6c:	1080                	addi	s0,sp,96
    80002d6e:	84aa                	mv	s1,a0
    80002d70:	8b2e                	mv	s6,a1
    80002d72:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002d74:	00054703          	lbu	a4,0(a0)
    80002d78:	02f00793          	li	a5,47
    80002d7c:	00f70f63          	beq	a4,a5,80002d9a <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002d80:	936fe0ef          	jal	80000eb6 <myproc>
    80002d84:	15853503          	ld	a0,344(a0)
    80002d88:	a87ff0ef          	jal	8000280e <idup>
    80002d8c:	8a2a                	mv	s4,a0
  while(*path == '/')
    80002d8e:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80002d92:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80002d94:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002d96:	4b85                	li	s7,1
    80002d98:	a879                	j	80002e36 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80002d9a:	4585                	li	a1,1
    80002d9c:	852e                	mv	a0,a1
    80002d9e:	fcaff0ef          	jal	80002568 <iget>
    80002da2:	8a2a                	mv	s4,a0
    80002da4:	b7ed                	j	80002d8e <namex+0x3c>
      iunlockput(ip);
    80002da6:	8552                	mv	a0,s4
    80002da8:	ca9ff0ef          	jal	80002a50 <iunlockput>
      return 0;
    80002dac:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002dae:	8552                	mv	a0,s4
    80002db0:	60e6                	ld	ra,88(sp)
    80002db2:	6446                	ld	s0,80(sp)
    80002db4:	64a6                	ld	s1,72(sp)
    80002db6:	6906                	ld	s2,64(sp)
    80002db8:	79e2                	ld	s3,56(sp)
    80002dba:	7a42                	ld	s4,48(sp)
    80002dbc:	7aa2                	ld	s5,40(sp)
    80002dbe:	7b02                	ld	s6,32(sp)
    80002dc0:	6be2                	ld	s7,24(sp)
    80002dc2:	6c42                	ld	s8,16(sp)
    80002dc4:	6ca2                	ld	s9,8(sp)
    80002dc6:	6d02                	ld	s10,0(sp)
    80002dc8:	6125                	addi	sp,sp,96
    80002dca:	8082                	ret
      iunlock(ip);
    80002dcc:	8552                	mv	a0,s4
    80002dce:	b25ff0ef          	jal	800028f2 <iunlock>
      return ip;
    80002dd2:	bff1                	j	80002dae <namex+0x5c>
      iunlockput(ip);
    80002dd4:	8552                	mv	a0,s4
    80002dd6:	c7bff0ef          	jal	80002a50 <iunlockput>
      return 0;
    80002dda:	8a4a                	mv	s4,s2
    80002ddc:	bfc9                	j	80002dae <namex+0x5c>
  len = path - s;
    80002dde:	40990633          	sub	a2,s2,s1
    80002de2:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80002de6:	09ac5463          	bge	s8,s10,80002e6e <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80002dea:	8666                	mv	a2,s9
    80002dec:	85a6                	mv	a1,s1
    80002dee:	8556                	mv	a0,s5
    80002df0:	bcefd0ef          	jal	800001be <memmove>
    80002df4:	84ca                	mv	s1,s2
  while(*path == '/')
    80002df6:	0004c783          	lbu	a5,0(s1)
    80002dfa:	01379763          	bne	a5,s3,80002e08 <namex+0xb6>
    path++;
    80002dfe:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e00:	0004c783          	lbu	a5,0(s1)
    80002e04:	ff378de3          	beq	a5,s3,80002dfe <namex+0xac>
    ilock(ip);
    80002e08:	8552                	mv	a0,s4
    80002e0a:	a3bff0ef          	jal	80002844 <ilock>
    if(ip->type != T_DIR){
    80002e0e:	044a1783          	lh	a5,68(s4)
    80002e12:	f9779ae3          	bne	a5,s7,80002da6 <namex+0x54>
    if(nameiparent && *path == '\0'){
    80002e16:	000b0563          	beqz	s6,80002e20 <namex+0xce>
    80002e1a:	0004c783          	lbu	a5,0(s1)
    80002e1e:	d7dd                	beqz	a5,80002dcc <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002e20:	4601                	li	a2,0
    80002e22:	85d6                	mv	a1,s5
    80002e24:	8552                	mv	a0,s4
    80002e26:	e81ff0ef          	jal	80002ca6 <dirlookup>
    80002e2a:	892a                	mv	s2,a0
    80002e2c:	d545                	beqz	a0,80002dd4 <namex+0x82>
    iunlockput(ip);
    80002e2e:	8552                	mv	a0,s4
    80002e30:	c21ff0ef          	jal	80002a50 <iunlockput>
    ip = next;
    80002e34:	8a4a                	mv	s4,s2
  while(*path == '/')
    80002e36:	0004c783          	lbu	a5,0(s1)
    80002e3a:	01379763          	bne	a5,s3,80002e48 <namex+0xf6>
    path++;
    80002e3e:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e40:	0004c783          	lbu	a5,0(s1)
    80002e44:	ff378de3          	beq	a5,s3,80002e3e <namex+0xec>
  if(*path == 0)
    80002e48:	cf8d                	beqz	a5,80002e82 <namex+0x130>
  while(*path != '/' && *path != 0)
    80002e4a:	0004c783          	lbu	a5,0(s1)
    80002e4e:	fd178713          	addi	a4,a5,-47
    80002e52:	cb19                	beqz	a4,80002e68 <namex+0x116>
    80002e54:	cb91                	beqz	a5,80002e68 <namex+0x116>
    80002e56:	8926                	mv	s2,s1
    path++;
    80002e58:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80002e5a:	00094783          	lbu	a5,0(s2)
    80002e5e:	fd178713          	addi	a4,a5,-47
    80002e62:	df35                	beqz	a4,80002dde <namex+0x8c>
    80002e64:	fbf5                	bnez	a5,80002e58 <namex+0x106>
    80002e66:	bfa5                	j	80002dde <namex+0x8c>
    80002e68:	8926                	mv	s2,s1
  len = path - s;
    80002e6a:	4d01                	li	s10,0
    80002e6c:	4601                	li	a2,0
    memmove(name, s, len);
    80002e6e:	2601                	sext.w	a2,a2
    80002e70:	85a6                	mv	a1,s1
    80002e72:	8556                	mv	a0,s5
    80002e74:	b4afd0ef          	jal	800001be <memmove>
    name[len] = 0;
    80002e78:	9d56                	add	s10,s10,s5
    80002e7a:	000d0023          	sb	zero,0(s10)
    80002e7e:	84ca                	mv	s1,s2
    80002e80:	bf9d                	j	80002df6 <namex+0xa4>
  if(nameiparent){
    80002e82:	f20b06e3          	beqz	s6,80002dae <namex+0x5c>
    iput(ip);
    80002e86:	8552                	mv	a0,s4
    80002e88:	b3fff0ef          	jal	800029c6 <iput>
    return 0;
    80002e8c:	4a01                	li	s4,0
    80002e8e:	b705                	j	80002dae <namex+0x5c>

0000000080002e90 <dirlink>:
{
    80002e90:	715d                	addi	sp,sp,-80
    80002e92:	e486                	sd	ra,72(sp)
    80002e94:	e0a2                	sd	s0,64(sp)
    80002e96:	f84a                	sd	s2,48(sp)
    80002e98:	ec56                	sd	s5,24(sp)
    80002e9a:	e85a                	sd	s6,16(sp)
    80002e9c:	0880                	addi	s0,sp,80
    80002e9e:	892a                	mv	s2,a0
    80002ea0:	8aae                	mv	s5,a1
    80002ea2:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002ea4:	4601                	li	a2,0
    80002ea6:	e01ff0ef          	jal	80002ca6 <dirlookup>
    80002eaa:	ed1d                	bnez	a0,80002ee8 <dirlink+0x58>
    80002eac:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002eae:	04c92483          	lw	s1,76(s2)
    80002eb2:	c4b9                	beqz	s1,80002f00 <dirlink+0x70>
    80002eb4:	f44e                	sd	s3,40(sp)
    80002eb6:	f052                	sd	s4,32(sp)
    80002eb8:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002eba:	fb040a13          	addi	s4,s0,-80
    80002ebe:	49c1                	li	s3,16
    80002ec0:	874e                	mv	a4,s3
    80002ec2:	86a6                	mv	a3,s1
    80002ec4:	8652                	mv	a2,s4
    80002ec6:	4581                	li	a1,0
    80002ec8:	854a                	mv	a0,s2
    80002eca:	bd5ff0ef          	jal	80002a9e <readi>
    80002ece:	03351163          	bne	a0,s3,80002ef0 <dirlink+0x60>
    if(de.inum == 0)
    80002ed2:	fb045783          	lhu	a5,-80(s0)
    80002ed6:	c39d                	beqz	a5,80002efc <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ed8:	24c1                	addiw	s1,s1,16
    80002eda:	04c92783          	lw	a5,76(s2)
    80002ede:	fef4e1e3          	bltu	s1,a5,80002ec0 <dirlink+0x30>
    80002ee2:	79a2                	ld	s3,40(sp)
    80002ee4:	7a02                	ld	s4,32(sp)
    80002ee6:	a829                	j	80002f00 <dirlink+0x70>
    iput(ip);
    80002ee8:	adfff0ef          	jal	800029c6 <iput>
    return -1;
    80002eec:	557d                	li	a0,-1
    80002eee:	a83d                	j	80002f2c <dirlink+0x9c>
      panic("dirlink read");
    80002ef0:	00004517          	auipc	a0,0x4
    80002ef4:	63850513          	addi	a0,a0,1592 # 80007528 <etext+0x528>
    80002ef8:	7a6020ef          	jal	8000569e <panic>
    80002efc:	79a2                	ld	s3,40(sp)
    80002efe:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80002f00:	4639                	li	a2,14
    80002f02:	85d6                	mv	a1,s5
    80002f04:	fb240513          	addi	a0,s0,-78
    80002f08:	b64fd0ef          	jal	8000026c <strncpy>
  de.inum = inum;
    80002f0c:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002f10:	4741                	li	a4,16
    80002f12:	86a6                	mv	a3,s1
    80002f14:	fb040613          	addi	a2,s0,-80
    80002f18:	4581                	li	a1,0
    80002f1a:	854a                	mv	a0,s2
    80002f1c:	c75ff0ef          	jal	80002b90 <writei>
    80002f20:	1541                	addi	a0,a0,-16
    80002f22:	00a03533          	snez	a0,a0
    80002f26:	40a0053b          	negw	a0,a0
    80002f2a:	74e2                	ld	s1,56(sp)
}
    80002f2c:	60a6                	ld	ra,72(sp)
    80002f2e:	6406                	ld	s0,64(sp)
    80002f30:	7942                	ld	s2,48(sp)
    80002f32:	6ae2                	ld	s5,24(sp)
    80002f34:	6b42                	ld	s6,16(sp)
    80002f36:	6161                	addi	sp,sp,80
    80002f38:	8082                	ret

0000000080002f3a <namei>:

struct inode*
namei(char *path)
{
    80002f3a:	1101                	addi	sp,sp,-32
    80002f3c:	ec06                	sd	ra,24(sp)
    80002f3e:	e822                	sd	s0,16(sp)
    80002f40:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002f42:	fe040613          	addi	a2,s0,-32
    80002f46:	4581                	li	a1,0
    80002f48:	e0bff0ef          	jal	80002d52 <namex>
}
    80002f4c:	60e2                	ld	ra,24(sp)
    80002f4e:	6442                	ld	s0,16(sp)
    80002f50:	6105                	addi	sp,sp,32
    80002f52:	8082                	ret

0000000080002f54 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002f54:	1141                	addi	sp,sp,-16
    80002f56:	e406                	sd	ra,8(sp)
    80002f58:	e022                	sd	s0,0(sp)
    80002f5a:	0800                	addi	s0,sp,16
    80002f5c:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002f5e:	4585                	li	a1,1
    80002f60:	df3ff0ef          	jal	80002d52 <namex>
}
    80002f64:	60a2                	ld	ra,8(sp)
    80002f66:	6402                	ld	s0,0(sp)
    80002f68:	0141                	addi	sp,sp,16
    80002f6a:	8082                	ret

0000000080002f6c <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002f6c:	1101                	addi	sp,sp,-32
    80002f6e:	ec06                	sd	ra,24(sp)
    80002f70:	e822                	sd	s0,16(sp)
    80002f72:	e426                	sd	s1,8(sp)
    80002f74:	e04a                	sd	s2,0(sp)
    80002f76:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002f78:	00015917          	auipc	s2,0x15
    80002f7c:	c2890913          	addi	s2,s2,-984 # 80017ba0 <log>
    80002f80:	01892583          	lw	a1,24(s2)
    80002f84:	02892503          	lw	a0,40(s2)
    80002f88:	9baff0ef          	jal	80002142 <bread>
    80002f8c:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002f8e:	02c92603          	lw	a2,44(s2)
    80002f92:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002f94:	00c05f63          	blez	a2,80002fb2 <write_head+0x46>
    80002f98:	00015717          	auipc	a4,0x15
    80002f9c:	c3870713          	addi	a4,a4,-968 # 80017bd0 <log+0x30>
    80002fa0:	87aa                	mv	a5,a0
    80002fa2:	060a                	slli	a2,a2,0x2
    80002fa4:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80002fa6:	4314                	lw	a3,0(a4)
    80002fa8:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80002faa:	0711                	addi	a4,a4,4
    80002fac:	0791                	addi	a5,a5,4
    80002fae:	fec79ce3          	bne	a5,a2,80002fa6 <write_head+0x3a>
  }
  bwrite(buf);
    80002fb2:	8526                	mv	a0,s1
    80002fb4:	a64ff0ef          	jal	80002218 <bwrite>
  brelse(buf);
    80002fb8:	8526                	mv	a0,s1
    80002fba:	a90ff0ef          	jal	8000224a <brelse>
}
    80002fbe:	60e2                	ld	ra,24(sp)
    80002fc0:	6442                	ld	s0,16(sp)
    80002fc2:	64a2                	ld	s1,8(sp)
    80002fc4:	6902                	ld	s2,0(sp)
    80002fc6:	6105                	addi	sp,sp,32
    80002fc8:	8082                	ret

0000000080002fca <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80002fca:	00015797          	auipc	a5,0x15
    80002fce:	c027a783          	lw	a5,-1022(a5) # 80017bcc <log+0x2c>
    80002fd2:	0af05263          	blez	a5,80003076 <install_trans+0xac>
{
    80002fd6:	715d                	addi	sp,sp,-80
    80002fd8:	e486                	sd	ra,72(sp)
    80002fda:	e0a2                	sd	s0,64(sp)
    80002fdc:	fc26                	sd	s1,56(sp)
    80002fde:	f84a                	sd	s2,48(sp)
    80002fe0:	f44e                	sd	s3,40(sp)
    80002fe2:	f052                	sd	s4,32(sp)
    80002fe4:	ec56                	sd	s5,24(sp)
    80002fe6:	e85a                	sd	s6,16(sp)
    80002fe8:	e45e                	sd	s7,8(sp)
    80002fea:	0880                	addi	s0,sp,80
    80002fec:	8b2a                	mv	s6,a0
    80002fee:	00015a97          	auipc	s5,0x15
    80002ff2:	be2a8a93          	addi	s5,s5,-1054 # 80017bd0 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002ff6:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002ff8:	00015997          	auipc	s3,0x15
    80002ffc:	ba898993          	addi	s3,s3,-1112 # 80017ba0 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003000:	40000b93          	li	s7,1024
    80003004:	a829                	j	8000301e <install_trans+0x54>
    brelse(lbuf);
    80003006:	854a                	mv	a0,s2
    80003008:	a42ff0ef          	jal	8000224a <brelse>
    brelse(dbuf);
    8000300c:	8526                	mv	a0,s1
    8000300e:	a3cff0ef          	jal	8000224a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003012:	2a05                	addiw	s4,s4,1
    80003014:	0a91                	addi	s5,s5,4
    80003016:	02c9a783          	lw	a5,44(s3)
    8000301a:	04fa5363          	bge	s4,a5,80003060 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000301e:	0189a583          	lw	a1,24(s3)
    80003022:	014585bb          	addw	a1,a1,s4
    80003026:	2585                	addiw	a1,a1,1
    80003028:	0289a503          	lw	a0,40(s3)
    8000302c:	916ff0ef          	jal	80002142 <bread>
    80003030:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003032:	000aa583          	lw	a1,0(s5)
    80003036:	0289a503          	lw	a0,40(s3)
    8000303a:	908ff0ef          	jal	80002142 <bread>
    8000303e:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003040:	865e                	mv	a2,s7
    80003042:	05890593          	addi	a1,s2,88
    80003046:	05850513          	addi	a0,a0,88
    8000304a:	974fd0ef          	jal	800001be <memmove>
    bwrite(dbuf);  // write dst to disk
    8000304e:	8526                	mv	a0,s1
    80003050:	9c8ff0ef          	jal	80002218 <bwrite>
    if(recovering == 0)
    80003054:	fa0b19e3          	bnez	s6,80003006 <install_trans+0x3c>
      bunpin(dbuf);
    80003058:	8526                	mv	a0,s1
    8000305a:	aa8ff0ef          	jal	80002302 <bunpin>
    8000305e:	b765                	j	80003006 <install_trans+0x3c>
}
    80003060:	60a6                	ld	ra,72(sp)
    80003062:	6406                	ld	s0,64(sp)
    80003064:	74e2                	ld	s1,56(sp)
    80003066:	7942                	ld	s2,48(sp)
    80003068:	79a2                	ld	s3,40(sp)
    8000306a:	7a02                	ld	s4,32(sp)
    8000306c:	6ae2                	ld	s5,24(sp)
    8000306e:	6b42                	ld	s6,16(sp)
    80003070:	6ba2                	ld	s7,8(sp)
    80003072:	6161                	addi	sp,sp,80
    80003074:	8082                	ret
    80003076:	8082                	ret

0000000080003078 <initlog>:
{
    80003078:	7179                	addi	sp,sp,-48
    8000307a:	f406                	sd	ra,40(sp)
    8000307c:	f022                	sd	s0,32(sp)
    8000307e:	ec26                	sd	s1,24(sp)
    80003080:	e84a                	sd	s2,16(sp)
    80003082:	e44e                	sd	s3,8(sp)
    80003084:	1800                	addi	s0,sp,48
    80003086:	892a                	mv	s2,a0
    80003088:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    8000308a:	00015497          	auipc	s1,0x15
    8000308e:	b1648493          	addi	s1,s1,-1258 # 80017ba0 <log>
    80003092:	00004597          	auipc	a1,0x4
    80003096:	4a658593          	addi	a1,a1,1190 # 80007538 <etext+0x538>
    8000309a:	8526                	mv	a0,s1
    8000309c:	0b7020ef          	jal	80005952 <initlock>
  log.start = sb->logstart;
    800030a0:	0149a583          	lw	a1,20(s3)
    800030a4:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    800030a6:	0109a783          	lw	a5,16(s3)
    800030aa:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    800030ac:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    800030b0:	854a                	mv	a0,s2
    800030b2:	890ff0ef          	jal	80002142 <bread>
  log.lh.n = lh->n;
    800030b6:	4d30                	lw	a2,88(a0)
    800030b8:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    800030ba:	00c05f63          	blez	a2,800030d8 <initlog+0x60>
    800030be:	87aa                	mv	a5,a0
    800030c0:	00015717          	auipc	a4,0x15
    800030c4:	b1070713          	addi	a4,a4,-1264 # 80017bd0 <log+0x30>
    800030c8:	060a                	slli	a2,a2,0x2
    800030ca:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    800030cc:	4ff4                	lw	a3,92(a5)
    800030ce:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    800030d0:	0791                	addi	a5,a5,4
    800030d2:	0711                	addi	a4,a4,4
    800030d4:	fec79ce3          	bne	a5,a2,800030cc <initlog+0x54>
  brelse(buf);
    800030d8:	972ff0ef          	jal	8000224a <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800030dc:	4505                	li	a0,1
    800030de:	eedff0ef          	jal	80002fca <install_trans>
  log.lh.n = 0;
    800030e2:	00015797          	auipc	a5,0x15
    800030e6:	ae07a523          	sw	zero,-1302(a5) # 80017bcc <log+0x2c>
  write_head(); // clear the log
    800030ea:	e83ff0ef          	jal	80002f6c <write_head>
}
    800030ee:	70a2                	ld	ra,40(sp)
    800030f0:	7402                	ld	s0,32(sp)
    800030f2:	64e2                	ld	s1,24(sp)
    800030f4:	6942                	ld	s2,16(sp)
    800030f6:	69a2                	ld	s3,8(sp)
    800030f8:	6145                	addi	sp,sp,48
    800030fa:	8082                	ret

00000000800030fc <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    800030fc:	1101                	addi	sp,sp,-32
    800030fe:	ec06                	sd	ra,24(sp)
    80003100:	e822                	sd	s0,16(sp)
    80003102:	e426                	sd	s1,8(sp)
    80003104:	e04a                	sd	s2,0(sp)
    80003106:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003108:	00015517          	auipc	a0,0x15
    8000310c:	a9850513          	addi	a0,a0,-1384 # 80017ba0 <log>
    80003110:	0cd020ef          	jal	800059dc <acquire>
  while(1){
    if(log.committing){
    80003114:	00015497          	auipc	s1,0x15
    80003118:	a8c48493          	addi	s1,s1,-1396 # 80017ba0 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    8000311c:	4979                	li	s2,30
    8000311e:	a029                	j	80003128 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003120:	85a6                	mv	a1,s1
    80003122:	8526                	mv	a0,s1
    80003124:	be8fe0ef          	jal	8000150c <sleep>
    if(log.committing){
    80003128:	50dc                	lw	a5,36(s1)
    8000312a:	fbfd                	bnez	a5,80003120 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    8000312c:	5098                	lw	a4,32(s1)
    8000312e:	2705                	addiw	a4,a4,1
    80003130:	0027179b          	slliw	a5,a4,0x2
    80003134:	9fb9                	addw	a5,a5,a4
    80003136:	0017979b          	slliw	a5,a5,0x1
    8000313a:	54d4                	lw	a3,44(s1)
    8000313c:	9fb5                	addw	a5,a5,a3
    8000313e:	00f95763          	bge	s2,a5,8000314c <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003142:	85a6                	mv	a1,s1
    80003144:	8526                	mv	a0,s1
    80003146:	bc6fe0ef          	jal	8000150c <sleep>
    8000314a:	bff9                	j	80003128 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    8000314c:	00015797          	auipc	a5,0x15
    80003150:	a6e7aa23          	sw	a4,-1420(a5) # 80017bc0 <log+0x20>
      release(&log.lock);
    80003154:	00015517          	auipc	a0,0x15
    80003158:	a4c50513          	addi	a0,a0,-1460 # 80017ba0 <log>
    8000315c:	115020ef          	jal	80005a70 <release>
      break;
    }
  }
}
    80003160:	60e2                	ld	ra,24(sp)
    80003162:	6442                	ld	s0,16(sp)
    80003164:	64a2                	ld	s1,8(sp)
    80003166:	6902                	ld	s2,0(sp)
    80003168:	6105                	addi	sp,sp,32
    8000316a:	8082                	ret

000000008000316c <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    8000316c:	7139                	addi	sp,sp,-64
    8000316e:	fc06                	sd	ra,56(sp)
    80003170:	f822                	sd	s0,48(sp)
    80003172:	f426                	sd	s1,40(sp)
    80003174:	f04a                	sd	s2,32(sp)
    80003176:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003178:	00015497          	auipc	s1,0x15
    8000317c:	a2848493          	addi	s1,s1,-1496 # 80017ba0 <log>
    80003180:	8526                	mv	a0,s1
    80003182:	05b020ef          	jal	800059dc <acquire>
  log.outstanding -= 1;
    80003186:	509c                	lw	a5,32(s1)
    80003188:	37fd                	addiw	a5,a5,-1
    8000318a:	893e                	mv	s2,a5
    8000318c:	d09c                	sw	a5,32(s1)
  if(log.committing)
    8000318e:	50dc                	lw	a5,36(s1)
    80003190:	e7b1                	bnez	a5,800031dc <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80003192:	04091e63          	bnez	s2,800031ee <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    80003196:	00015497          	auipc	s1,0x15
    8000319a:	a0a48493          	addi	s1,s1,-1526 # 80017ba0 <log>
    8000319e:	4785                	li	a5,1
    800031a0:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800031a2:	8526                	mv	a0,s1
    800031a4:	0cd020ef          	jal	80005a70 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800031a8:	54dc                	lw	a5,44(s1)
    800031aa:	06f04463          	bgtz	a5,80003212 <end_op+0xa6>
    acquire(&log.lock);
    800031ae:	00015517          	auipc	a0,0x15
    800031b2:	9f250513          	addi	a0,a0,-1550 # 80017ba0 <log>
    800031b6:	027020ef          	jal	800059dc <acquire>
    log.committing = 0;
    800031ba:	00015797          	auipc	a5,0x15
    800031be:	a007a523          	sw	zero,-1526(a5) # 80017bc4 <log+0x24>
    wakeup(&log);
    800031c2:	00015517          	auipc	a0,0x15
    800031c6:	9de50513          	addi	a0,a0,-1570 # 80017ba0 <log>
    800031ca:	b8efe0ef          	jal	80001558 <wakeup>
    release(&log.lock);
    800031ce:	00015517          	auipc	a0,0x15
    800031d2:	9d250513          	addi	a0,a0,-1582 # 80017ba0 <log>
    800031d6:	09b020ef          	jal	80005a70 <release>
}
    800031da:	a035                	j	80003206 <end_op+0x9a>
    800031dc:	ec4e                	sd	s3,24(sp)
    800031de:	e852                	sd	s4,16(sp)
    800031e0:	e456                	sd	s5,8(sp)
    panic("log.committing");
    800031e2:	00004517          	auipc	a0,0x4
    800031e6:	35e50513          	addi	a0,a0,862 # 80007540 <etext+0x540>
    800031ea:	4b4020ef          	jal	8000569e <panic>
    wakeup(&log);
    800031ee:	00015517          	auipc	a0,0x15
    800031f2:	9b250513          	addi	a0,a0,-1614 # 80017ba0 <log>
    800031f6:	b62fe0ef          	jal	80001558 <wakeup>
  release(&log.lock);
    800031fa:	00015517          	auipc	a0,0x15
    800031fe:	9a650513          	addi	a0,a0,-1626 # 80017ba0 <log>
    80003202:	06f020ef          	jal	80005a70 <release>
}
    80003206:	70e2                	ld	ra,56(sp)
    80003208:	7442                	ld	s0,48(sp)
    8000320a:	74a2                	ld	s1,40(sp)
    8000320c:	7902                	ld	s2,32(sp)
    8000320e:	6121                	addi	sp,sp,64
    80003210:	8082                	ret
    80003212:	ec4e                	sd	s3,24(sp)
    80003214:	e852                	sd	s4,16(sp)
    80003216:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003218:	00015a97          	auipc	s5,0x15
    8000321c:	9b8a8a93          	addi	s5,s5,-1608 # 80017bd0 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003220:	00015a17          	auipc	s4,0x15
    80003224:	980a0a13          	addi	s4,s4,-1664 # 80017ba0 <log>
    80003228:	018a2583          	lw	a1,24(s4)
    8000322c:	012585bb          	addw	a1,a1,s2
    80003230:	2585                	addiw	a1,a1,1
    80003232:	028a2503          	lw	a0,40(s4)
    80003236:	f0dfe0ef          	jal	80002142 <bread>
    8000323a:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    8000323c:	000aa583          	lw	a1,0(s5)
    80003240:	028a2503          	lw	a0,40(s4)
    80003244:	efffe0ef          	jal	80002142 <bread>
    80003248:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    8000324a:	40000613          	li	a2,1024
    8000324e:	05850593          	addi	a1,a0,88
    80003252:	05848513          	addi	a0,s1,88
    80003256:	f69fc0ef          	jal	800001be <memmove>
    bwrite(to);  // write the log
    8000325a:	8526                	mv	a0,s1
    8000325c:	fbdfe0ef          	jal	80002218 <bwrite>
    brelse(from);
    80003260:	854e                	mv	a0,s3
    80003262:	fe9fe0ef          	jal	8000224a <brelse>
    brelse(to);
    80003266:	8526                	mv	a0,s1
    80003268:	fe3fe0ef          	jal	8000224a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000326c:	2905                	addiw	s2,s2,1
    8000326e:	0a91                	addi	s5,s5,4
    80003270:	02ca2783          	lw	a5,44(s4)
    80003274:	faf94ae3          	blt	s2,a5,80003228 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003278:	cf5ff0ef          	jal	80002f6c <write_head>
    install_trans(0); // Now install writes to home locations
    8000327c:	4501                	li	a0,0
    8000327e:	d4dff0ef          	jal	80002fca <install_trans>
    log.lh.n = 0;
    80003282:	00015797          	auipc	a5,0x15
    80003286:	9407a523          	sw	zero,-1718(a5) # 80017bcc <log+0x2c>
    write_head();    // Erase the transaction from the log
    8000328a:	ce3ff0ef          	jal	80002f6c <write_head>
    8000328e:	69e2                	ld	s3,24(sp)
    80003290:	6a42                	ld	s4,16(sp)
    80003292:	6aa2                	ld	s5,8(sp)
    80003294:	bf29                	j	800031ae <end_op+0x42>

0000000080003296 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003296:	1101                	addi	sp,sp,-32
    80003298:	ec06                	sd	ra,24(sp)
    8000329a:	e822                	sd	s0,16(sp)
    8000329c:	e426                	sd	s1,8(sp)
    8000329e:	1000                	addi	s0,sp,32
    800032a0:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800032a2:	00015517          	auipc	a0,0x15
    800032a6:	8fe50513          	addi	a0,a0,-1794 # 80017ba0 <log>
    800032aa:	732020ef          	jal	800059dc <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800032ae:	00015617          	auipc	a2,0x15
    800032b2:	91e62603          	lw	a2,-1762(a2) # 80017bcc <log+0x2c>
    800032b6:	47f5                	li	a5,29
    800032b8:	06c7c463          	blt	a5,a2,80003320 <log_write+0x8a>
    800032bc:	00015797          	auipc	a5,0x15
    800032c0:	9007a783          	lw	a5,-1792(a5) # 80017bbc <log+0x1c>
    800032c4:	37fd                	addiw	a5,a5,-1
    800032c6:	04f65d63          	bge	a2,a5,80003320 <log_write+0x8a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800032ca:	00015797          	auipc	a5,0x15
    800032ce:	8f67a783          	lw	a5,-1802(a5) # 80017bc0 <log+0x20>
    800032d2:	04f05d63          	blez	a5,8000332c <log_write+0x96>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800032d6:	4781                	li	a5,0
    800032d8:	06c05063          	blez	a2,80003338 <log_write+0xa2>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800032dc:	44cc                	lw	a1,12(s1)
    800032de:	00015717          	auipc	a4,0x15
    800032e2:	8f270713          	addi	a4,a4,-1806 # 80017bd0 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800032e6:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800032e8:	4314                	lw	a3,0(a4)
    800032ea:	04b68763          	beq	a3,a1,80003338 <log_write+0xa2>
  for (i = 0; i < log.lh.n; i++) {
    800032ee:	2785                	addiw	a5,a5,1
    800032f0:	0711                	addi	a4,a4,4
    800032f2:	fef61be3          	bne	a2,a5,800032e8 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    800032f6:	060a                	slli	a2,a2,0x2
    800032f8:	02060613          	addi	a2,a2,32
    800032fc:	00015797          	auipc	a5,0x15
    80003300:	8a478793          	addi	a5,a5,-1884 # 80017ba0 <log>
    80003304:	97b2                	add	a5,a5,a2
    80003306:	44d8                	lw	a4,12(s1)
    80003308:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    8000330a:	8526                	mv	a0,s1
    8000330c:	fc3fe0ef          	jal	800022ce <bpin>
    log.lh.n++;
    80003310:	00015717          	auipc	a4,0x15
    80003314:	89070713          	addi	a4,a4,-1904 # 80017ba0 <log>
    80003318:	575c                	lw	a5,44(a4)
    8000331a:	2785                	addiw	a5,a5,1
    8000331c:	d75c                	sw	a5,44(a4)
    8000331e:	a815                	j	80003352 <log_write+0xbc>
    panic("too big a transaction");
    80003320:	00004517          	auipc	a0,0x4
    80003324:	23050513          	addi	a0,a0,560 # 80007550 <etext+0x550>
    80003328:	376020ef          	jal	8000569e <panic>
    panic("log_write outside of trans");
    8000332c:	00004517          	auipc	a0,0x4
    80003330:	23c50513          	addi	a0,a0,572 # 80007568 <etext+0x568>
    80003334:	36a020ef          	jal	8000569e <panic>
  log.lh.block[i] = b->blockno;
    80003338:	00279693          	slli	a3,a5,0x2
    8000333c:	02068693          	addi	a3,a3,32
    80003340:	00015717          	auipc	a4,0x15
    80003344:	86070713          	addi	a4,a4,-1952 # 80017ba0 <log>
    80003348:	9736                	add	a4,a4,a3
    8000334a:	44d4                	lw	a3,12(s1)
    8000334c:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000334e:	faf60ee3          	beq	a2,a5,8000330a <log_write+0x74>
  }
  release(&log.lock);
    80003352:	00015517          	auipc	a0,0x15
    80003356:	84e50513          	addi	a0,a0,-1970 # 80017ba0 <log>
    8000335a:	716020ef          	jal	80005a70 <release>
}
    8000335e:	60e2                	ld	ra,24(sp)
    80003360:	6442                	ld	s0,16(sp)
    80003362:	64a2                	ld	s1,8(sp)
    80003364:	6105                	addi	sp,sp,32
    80003366:	8082                	ret

0000000080003368 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003368:	1101                	addi	sp,sp,-32
    8000336a:	ec06                	sd	ra,24(sp)
    8000336c:	e822                	sd	s0,16(sp)
    8000336e:	e426                	sd	s1,8(sp)
    80003370:	e04a                	sd	s2,0(sp)
    80003372:	1000                	addi	s0,sp,32
    80003374:	84aa                	mv	s1,a0
    80003376:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003378:	00004597          	auipc	a1,0x4
    8000337c:	21058593          	addi	a1,a1,528 # 80007588 <etext+0x588>
    80003380:	0521                	addi	a0,a0,8
    80003382:	5d0020ef          	jal	80005952 <initlock>
  lk->name = name;
    80003386:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000338a:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000338e:	0204a423          	sw	zero,40(s1)
}
    80003392:	60e2                	ld	ra,24(sp)
    80003394:	6442                	ld	s0,16(sp)
    80003396:	64a2                	ld	s1,8(sp)
    80003398:	6902                	ld	s2,0(sp)
    8000339a:	6105                	addi	sp,sp,32
    8000339c:	8082                	ret

000000008000339e <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000339e:	1101                	addi	sp,sp,-32
    800033a0:	ec06                	sd	ra,24(sp)
    800033a2:	e822                	sd	s0,16(sp)
    800033a4:	e426                	sd	s1,8(sp)
    800033a6:	e04a                	sd	s2,0(sp)
    800033a8:	1000                	addi	s0,sp,32
    800033aa:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800033ac:	00850913          	addi	s2,a0,8
    800033b0:	854a                	mv	a0,s2
    800033b2:	62a020ef          	jal	800059dc <acquire>
  while (lk->locked) {
    800033b6:	409c                	lw	a5,0(s1)
    800033b8:	c799                	beqz	a5,800033c6 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    800033ba:	85ca                	mv	a1,s2
    800033bc:	8526                	mv	a0,s1
    800033be:	94efe0ef          	jal	8000150c <sleep>
  while (lk->locked) {
    800033c2:	409c                	lw	a5,0(s1)
    800033c4:	fbfd                	bnez	a5,800033ba <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800033c6:	4785                	li	a5,1
    800033c8:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800033ca:	aedfd0ef          	jal	80000eb6 <myproc>
    800033ce:	591c                	lw	a5,48(a0)
    800033d0:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800033d2:	854a                	mv	a0,s2
    800033d4:	69c020ef          	jal	80005a70 <release>
}
    800033d8:	60e2                	ld	ra,24(sp)
    800033da:	6442                	ld	s0,16(sp)
    800033dc:	64a2                	ld	s1,8(sp)
    800033de:	6902                	ld	s2,0(sp)
    800033e0:	6105                	addi	sp,sp,32
    800033e2:	8082                	ret

00000000800033e4 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800033e4:	1101                	addi	sp,sp,-32
    800033e6:	ec06                	sd	ra,24(sp)
    800033e8:	e822                	sd	s0,16(sp)
    800033ea:	e426                	sd	s1,8(sp)
    800033ec:	e04a                	sd	s2,0(sp)
    800033ee:	1000                	addi	s0,sp,32
    800033f0:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800033f2:	00850913          	addi	s2,a0,8
    800033f6:	854a                	mv	a0,s2
    800033f8:	5e4020ef          	jal	800059dc <acquire>
  lk->locked = 0;
    800033fc:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003400:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003404:	8526                	mv	a0,s1
    80003406:	952fe0ef          	jal	80001558 <wakeup>
  release(&lk->lk);
    8000340a:	854a                	mv	a0,s2
    8000340c:	664020ef          	jal	80005a70 <release>
}
    80003410:	60e2                	ld	ra,24(sp)
    80003412:	6442                	ld	s0,16(sp)
    80003414:	64a2                	ld	s1,8(sp)
    80003416:	6902                	ld	s2,0(sp)
    80003418:	6105                	addi	sp,sp,32
    8000341a:	8082                	ret

000000008000341c <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000341c:	7179                	addi	sp,sp,-48
    8000341e:	f406                	sd	ra,40(sp)
    80003420:	f022                	sd	s0,32(sp)
    80003422:	ec26                	sd	s1,24(sp)
    80003424:	e84a                	sd	s2,16(sp)
    80003426:	1800                	addi	s0,sp,48
    80003428:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000342a:	00850913          	addi	s2,a0,8
    8000342e:	854a                	mv	a0,s2
    80003430:	5ac020ef          	jal	800059dc <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003434:	409c                	lw	a5,0(s1)
    80003436:	ef81                	bnez	a5,8000344e <holdingsleep+0x32>
    80003438:	4481                	li	s1,0
  release(&lk->lk);
    8000343a:	854a                	mv	a0,s2
    8000343c:	634020ef          	jal	80005a70 <release>
  return r;
}
    80003440:	8526                	mv	a0,s1
    80003442:	70a2                	ld	ra,40(sp)
    80003444:	7402                	ld	s0,32(sp)
    80003446:	64e2                	ld	s1,24(sp)
    80003448:	6942                	ld	s2,16(sp)
    8000344a:	6145                	addi	sp,sp,48
    8000344c:	8082                	ret
    8000344e:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003450:	0284a983          	lw	s3,40(s1)
    80003454:	a63fd0ef          	jal	80000eb6 <myproc>
    80003458:	5904                	lw	s1,48(a0)
    8000345a:	413484b3          	sub	s1,s1,s3
    8000345e:	0014b493          	seqz	s1,s1
    80003462:	69a2                	ld	s3,8(sp)
    80003464:	bfd9                	j	8000343a <holdingsleep+0x1e>

0000000080003466 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003466:	1141                	addi	sp,sp,-16
    80003468:	e406                	sd	ra,8(sp)
    8000346a:	e022                	sd	s0,0(sp)
    8000346c:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000346e:	00004597          	auipc	a1,0x4
    80003472:	12a58593          	addi	a1,a1,298 # 80007598 <etext+0x598>
    80003476:	00015517          	auipc	a0,0x15
    8000347a:	87250513          	addi	a0,a0,-1934 # 80017ce8 <ftable>
    8000347e:	4d4020ef          	jal	80005952 <initlock>
}
    80003482:	60a2                	ld	ra,8(sp)
    80003484:	6402                	ld	s0,0(sp)
    80003486:	0141                	addi	sp,sp,16
    80003488:	8082                	ret

000000008000348a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000348a:	1101                	addi	sp,sp,-32
    8000348c:	ec06                	sd	ra,24(sp)
    8000348e:	e822                	sd	s0,16(sp)
    80003490:	e426                	sd	s1,8(sp)
    80003492:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003494:	00015517          	auipc	a0,0x15
    80003498:	85450513          	addi	a0,a0,-1964 # 80017ce8 <ftable>
    8000349c:	540020ef          	jal	800059dc <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800034a0:	00015497          	auipc	s1,0x15
    800034a4:	86048493          	addi	s1,s1,-1952 # 80017d00 <ftable+0x18>
    800034a8:	00015717          	auipc	a4,0x15
    800034ac:	7f870713          	addi	a4,a4,2040 # 80018ca0 <disk>
    if(f->ref == 0){
    800034b0:	40dc                	lw	a5,4(s1)
    800034b2:	cf89                	beqz	a5,800034cc <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800034b4:	02848493          	addi	s1,s1,40
    800034b8:	fee49ce3          	bne	s1,a4,800034b0 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800034bc:	00015517          	auipc	a0,0x15
    800034c0:	82c50513          	addi	a0,a0,-2004 # 80017ce8 <ftable>
    800034c4:	5ac020ef          	jal	80005a70 <release>
  return 0;
    800034c8:	4481                	li	s1,0
    800034ca:	a809                	j	800034dc <filealloc+0x52>
      f->ref = 1;
    800034cc:	4785                	li	a5,1
    800034ce:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800034d0:	00015517          	auipc	a0,0x15
    800034d4:	81850513          	addi	a0,a0,-2024 # 80017ce8 <ftable>
    800034d8:	598020ef          	jal	80005a70 <release>
}
    800034dc:	8526                	mv	a0,s1
    800034de:	60e2                	ld	ra,24(sp)
    800034e0:	6442                	ld	s0,16(sp)
    800034e2:	64a2                	ld	s1,8(sp)
    800034e4:	6105                	addi	sp,sp,32
    800034e6:	8082                	ret

00000000800034e8 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800034e8:	1101                	addi	sp,sp,-32
    800034ea:	ec06                	sd	ra,24(sp)
    800034ec:	e822                	sd	s0,16(sp)
    800034ee:	e426                	sd	s1,8(sp)
    800034f0:	1000                	addi	s0,sp,32
    800034f2:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800034f4:	00014517          	auipc	a0,0x14
    800034f8:	7f450513          	addi	a0,a0,2036 # 80017ce8 <ftable>
    800034fc:	4e0020ef          	jal	800059dc <acquire>
  if(f->ref < 1)
    80003500:	40dc                	lw	a5,4(s1)
    80003502:	02f05063          	blez	a5,80003522 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003506:	2785                	addiw	a5,a5,1
    80003508:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000350a:	00014517          	auipc	a0,0x14
    8000350e:	7de50513          	addi	a0,a0,2014 # 80017ce8 <ftable>
    80003512:	55e020ef          	jal	80005a70 <release>
  return f;
}
    80003516:	8526                	mv	a0,s1
    80003518:	60e2                	ld	ra,24(sp)
    8000351a:	6442                	ld	s0,16(sp)
    8000351c:	64a2                	ld	s1,8(sp)
    8000351e:	6105                	addi	sp,sp,32
    80003520:	8082                	ret
    panic("filedup");
    80003522:	00004517          	auipc	a0,0x4
    80003526:	07e50513          	addi	a0,a0,126 # 800075a0 <etext+0x5a0>
    8000352a:	174020ef          	jal	8000569e <panic>

000000008000352e <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000352e:	7139                	addi	sp,sp,-64
    80003530:	fc06                	sd	ra,56(sp)
    80003532:	f822                	sd	s0,48(sp)
    80003534:	f426                	sd	s1,40(sp)
    80003536:	0080                	addi	s0,sp,64
    80003538:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    8000353a:	00014517          	auipc	a0,0x14
    8000353e:	7ae50513          	addi	a0,a0,1966 # 80017ce8 <ftable>
    80003542:	49a020ef          	jal	800059dc <acquire>
  if(f->ref < 1)
    80003546:	40dc                	lw	a5,4(s1)
    80003548:	04f05a63          	blez	a5,8000359c <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    8000354c:	37fd                	addiw	a5,a5,-1
    8000354e:	c0dc                	sw	a5,4(s1)
    80003550:	06f04063          	bgtz	a5,800035b0 <fileclose+0x82>
    80003554:	f04a                	sd	s2,32(sp)
    80003556:	ec4e                	sd	s3,24(sp)
    80003558:	e852                	sd	s4,16(sp)
    8000355a:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000355c:	0004a903          	lw	s2,0(s1)
    80003560:	0094c783          	lbu	a5,9(s1)
    80003564:	89be                	mv	s3,a5
    80003566:	689c                	ld	a5,16(s1)
    80003568:	8a3e                	mv	s4,a5
    8000356a:	6c9c                	ld	a5,24(s1)
    8000356c:	8abe                	mv	s5,a5
  f->ref = 0;
    8000356e:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003572:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80003576:	00014517          	auipc	a0,0x14
    8000357a:	77250513          	addi	a0,a0,1906 # 80017ce8 <ftable>
    8000357e:	4f2020ef          	jal	80005a70 <release>

  if(ff.type == FD_PIPE){
    80003582:	4785                	li	a5,1
    80003584:	04f90163          	beq	s2,a5,800035c6 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80003588:	ffe9079b          	addiw	a5,s2,-2
    8000358c:	4705                	li	a4,1
    8000358e:	04f77563          	bgeu	a4,a5,800035d8 <fileclose+0xaa>
    80003592:	7902                	ld	s2,32(sp)
    80003594:	69e2                	ld	s3,24(sp)
    80003596:	6a42                	ld	s4,16(sp)
    80003598:	6aa2                	ld	s5,8(sp)
    8000359a:	a00d                	j	800035bc <fileclose+0x8e>
    8000359c:	f04a                	sd	s2,32(sp)
    8000359e:	ec4e                	sd	s3,24(sp)
    800035a0:	e852                	sd	s4,16(sp)
    800035a2:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800035a4:	00004517          	auipc	a0,0x4
    800035a8:	00450513          	addi	a0,a0,4 # 800075a8 <etext+0x5a8>
    800035ac:	0f2020ef          	jal	8000569e <panic>
    release(&ftable.lock);
    800035b0:	00014517          	auipc	a0,0x14
    800035b4:	73850513          	addi	a0,a0,1848 # 80017ce8 <ftable>
    800035b8:	4b8020ef          	jal	80005a70 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800035bc:	70e2                	ld	ra,56(sp)
    800035be:	7442                	ld	s0,48(sp)
    800035c0:	74a2                	ld	s1,40(sp)
    800035c2:	6121                	addi	sp,sp,64
    800035c4:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800035c6:	85ce                	mv	a1,s3
    800035c8:	8552                	mv	a0,s4
    800035ca:	348000ef          	jal	80003912 <pipeclose>
    800035ce:	7902                	ld	s2,32(sp)
    800035d0:	69e2                	ld	s3,24(sp)
    800035d2:	6a42                	ld	s4,16(sp)
    800035d4:	6aa2                	ld	s5,8(sp)
    800035d6:	b7dd                	j	800035bc <fileclose+0x8e>
    begin_op();
    800035d8:	b25ff0ef          	jal	800030fc <begin_op>
    iput(ff.ip);
    800035dc:	8556                	mv	a0,s5
    800035de:	be8ff0ef          	jal	800029c6 <iput>
    end_op();
    800035e2:	b8bff0ef          	jal	8000316c <end_op>
    800035e6:	7902                	ld	s2,32(sp)
    800035e8:	69e2                	ld	s3,24(sp)
    800035ea:	6a42                	ld	s4,16(sp)
    800035ec:	6aa2                	ld	s5,8(sp)
    800035ee:	b7f9                	j	800035bc <fileclose+0x8e>

00000000800035f0 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800035f0:	715d                	addi	sp,sp,-80
    800035f2:	e486                	sd	ra,72(sp)
    800035f4:	e0a2                	sd	s0,64(sp)
    800035f6:	fc26                	sd	s1,56(sp)
    800035f8:	f052                	sd	s4,32(sp)
    800035fa:	0880                	addi	s0,sp,80
    800035fc:	84aa                	mv	s1,a0
    800035fe:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80003600:	8b7fd0ef          	jal	80000eb6 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003604:	409c                	lw	a5,0(s1)
    80003606:	37f9                	addiw	a5,a5,-2
    80003608:	4705                	li	a4,1
    8000360a:	04f76263          	bltu	a4,a5,8000364e <filestat+0x5e>
    8000360e:	f84a                	sd	s2,48(sp)
    80003610:	f44e                	sd	s3,40(sp)
    80003612:	89aa                	mv	s3,a0
    ilock(f->ip);
    80003614:	6c88                	ld	a0,24(s1)
    80003616:	a2eff0ef          	jal	80002844 <ilock>
    stati(f->ip, &st);
    8000361a:	fb840913          	addi	s2,s0,-72
    8000361e:	85ca                	mv	a1,s2
    80003620:	6c88                	ld	a0,24(s1)
    80003622:	c4eff0ef          	jal	80002a70 <stati>
    iunlock(f->ip);
    80003626:	6c88                	ld	a0,24(s1)
    80003628:	acaff0ef          	jal	800028f2 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    8000362c:	46e1                	li	a3,24
    8000362e:	864a                	mv	a2,s2
    80003630:	85d2                	mv	a1,s4
    80003632:	0509b503          	ld	a0,80(s3)
    80003636:	cc0fd0ef          	jal	80000af6 <copyout>
    8000363a:	41f5551b          	sraiw	a0,a0,0x1f
    8000363e:	7942                	ld	s2,48(sp)
    80003640:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80003642:	60a6                	ld	ra,72(sp)
    80003644:	6406                	ld	s0,64(sp)
    80003646:	74e2                	ld	s1,56(sp)
    80003648:	7a02                	ld	s4,32(sp)
    8000364a:	6161                	addi	sp,sp,80
    8000364c:	8082                	ret
  return -1;
    8000364e:	557d                	li	a0,-1
    80003650:	bfcd                	j	80003642 <filestat+0x52>

0000000080003652 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003652:	7179                	addi	sp,sp,-48
    80003654:	f406                	sd	ra,40(sp)
    80003656:	f022                	sd	s0,32(sp)
    80003658:	e84a                	sd	s2,16(sp)
    8000365a:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    8000365c:	00854783          	lbu	a5,8(a0)
    80003660:	cfd1                	beqz	a5,800036fc <fileread+0xaa>
    80003662:	ec26                	sd	s1,24(sp)
    80003664:	e44e                	sd	s3,8(sp)
    80003666:	84aa                	mv	s1,a0
    80003668:	892e                	mv	s2,a1
    8000366a:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    8000366c:	411c                	lw	a5,0(a0)
    8000366e:	4705                	li	a4,1
    80003670:	04e78363          	beq	a5,a4,800036b6 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003674:	470d                	li	a4,3
    80003676:	04e78763          	beq	a5,a4,800036c4 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    8000367a:	4709                	li	a4,2
    8000367c:	06e79a63          	bne	a5,a4,800036f0 <fileread+0x9e>
    ilock(f->ip);
    80003680:	6d08                	ld	a0,24(a0)
    80003682:	9c2ff0ef          	jal	80002844 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80003686:	874e                	mv	a4,s3
    80003688:	5094                	lw	a3,32(s1)
    8000368a:	864a                	mv	a2,s2
    8000368c:	4585                	li	a1,1
    8000368e:	6c88                	ld	a0,24(s1)
    80003690:	c0eff0ef          	jal	80002a9e <readi>
    80003694:	892a                	mv	s2,a0
    80003696:	00a05563          	blez	a0,800036a0 <fileread+0x4e>
      f->off += r;
    8000369a:	509c                	lw	a5,32(s1)
    8000369c:	9fa9                	addw	a5,a5,a0
    8000369e:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800036a0:	6c88                	ld	a0,24(s1)
    800036a2:	a50ff0ef          	jal	800028f2 <iunlock>
    800036a6:	64e2                	ld	s1,24(sp)
    800036a8:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800036aa:	854a                	mv	a0,s2
    800036ac:	70a2                	ld	ra,40(sp)
    800036ae:	7402                	ld	s0,32(sp)
    800036b0:	6942                	ld	s2,16(sp)
    800036b2:	6145                	addi	sp,sp,48
    800036b4:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800036b6:	6908                	ld	a0,16(a0)
    800036b8:	3b0000ef          	jal	80003a68 <piperead>
    800036bc:	892a                	mv	s2,a0
    800036be:	64e2                	ld	s1,24(sp)
    800036c0:	69a2                	ld	s3,8(sp)
    800036c2:	b7e5                	j	800036aa <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800036c4:	02451783          	lh	a5,36(a0)
    800036c8:	03079693          	slli	a3,a5,0x30
    800036cc:	92c1                	srli	a3,a3,0x30
    800036ce:	4725                	li	a4,9
    800036d0:	02d76963          	bltu	a4,a3,80003702 <fileread+0xb0>
    800036d4:	0792                	slli	a5,a5,0x4
    800036d6:	00014717          	auipc	a4,0x14
    800036da:	57270713          	addi	a4,a4,1394 # 80017c48 <devsw>
    800036de:	97ba                	add	a5,a5,a4
    800036e0:	639c                	ld	a5,0(a5)
    800036e2:	c78d                	beqz	a5,8000370c <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    800036e4:	4505                	li	a0,1
    800036e6:	9782                	jalr	a5
    800036e8:	892a                	mv	s2,a0
    800036ea:	64e2                	ld	s1,24(sp)
    800036ec:	69a2                	ld	s3,8(sp)
    800036ee:	bf75                	j	800036aa <fileread+0x58>
    panic("fileread");
    800036f0:	00004517          	auipc	a0,0x4
    800036f4:	ec850513          	addi	a0,a0,-312 # 800075b8 <etext+0x5b8>
    800036f8:	7a7010ef          	jal	8000569e <panic>
    return -1;
    800036fc:	57fd                	li	a5,-1
    800036fe:	893e                	mv	s2,a5
    80003700:	b76d                	j	800036aa <fileread+0x58>
      return -1;
    80003702:	57fd                	li	a5,-1
    80003704:	893e                	mv	s2,a5
    80003706:	64e2                	ld	s1,24(sp)
    80003708:	69a2                	ld	s3,8(sp)
    8000370a:	b745                	j	800036aa <fileread+0x58>
    8000370c:	57fd                	li	a5,-1
    8000370e:	893e                	mv	s2,a5
    80003710:	64e2                	ld	s1,24(sp)
    80003712:	69a2                	ld	s3,8(sp)
    80003714:	bf59                	j	800036aa <fileread+0x58>

0000000080003716 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80003716:	00954783          	lbu	a5,9(a0)
    8000371a:	10078f63          	beqz	a5,80003838 <filewrite+0x122>
{
    8000371e:	711d                	addi	sp,sp,-96
    80003720:	ec86                	sd	ra,88(sp)
    80003722:	e8a2                	sd	s0,80(sp)
    80003724:	e0ca                	sd	s2,64(sp)
    80003726:	f456                	sd	s5,40(sp)
    80003728:	f05a                	sd	s6,32(sp)
    8000372a:	1080                	addi	s0,sp,96
    8000372c:	892a                	mv	s2,a0
    8000372e:	8b2e                	mv	s6,a1
    80003730:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    80003732:	411c                	lw	a5,0(a0)
    80003734:	4705                	li	a4,1
    80003736:	02e78a63          	beq	a5,a4,8000376a <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000373a:	470d                	li	a4,3
    8000373c:	02e78b63          	beq	a5,a4,80003772 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80003740:	4709                	li	a4,2
    80003742:	0ce79f63          	bne	a5,a4,80003820 <filewrite+0x10a>
    80003746:	f852                	sd	s4,48(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80003748:	0ac05a63          	blez	a2,800037fc <filewrite+0xe6>
    8000374c:	e4a6                	sd	s1,72(sp)
    8000374e:	fc4e                	sd	s3,56(sp)
    80003750:	ec5e                	sd	s7,24(sp)
    80003752:	e862                	sd	s8,16(sp)
    80003754:	e466                	sd	s9,8(sp)
    int i = 0;
    80003756:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    80003758:	6b85                	lui	s7,0x1
    8000375a:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    8000375e:	6785                	lui	a5,0x1
    80003760:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80003764:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80003766:	4c05                	li	s8,1
    80003768:	a8ad                	j	800037e2 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    8000376a:	6908                	ld	a0,16(a0)
    8000376c:	204000ef          	jal	80003970 <pipewrite>
    80003770:	a04d                	j	80003812 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80003772:	02451783          	lh	a5,36(a0)
    80003776:	03079693          	slli	a3,a5,0x30
    8000377a:	92c1                	srli	a3,a3,0x30
    8000377c:	4725                	li	a4,9
    8000377e:	0ad76f63          	bltu	a4,a3,8000383c <filewrite+0x126>
    80003782:	0792                	slli	a5,a5,0x4
    80003784:	00014717          	auipc	a4,0x14
    80003788:	4c470713          	addi	a4,a4,1220 # 80017c48 <devsw>
    8000378c:	97ba                	add	a5,a5,a4
    8000378e:	679c                	ld	a5,8(a5)
    80003790:	cbc5                	beqz	a5,80003840 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    80003792:	4505                	li	a0,1
    80003794:	9782                	jalr	a5
    80003796:	a8b5                	j	80003812 <filewrite+0xfc>
      if(n1 > max)
    80003798:	2981                	sext.w	s3,s3
      begin_op();
    8000379a:	963ff0ef          	jal	800030fc <begin_op>
      ilock(f->ip);
    8000379e:	01893503          	ld	a0,24(s2)
    800037a2:	8a2ff0ef          	jal	80002844 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800037a6:	874e                	mv	a4,s3
    800037a8:	02092683          	lw	a3,32(s2)
    800037ac:	016a0633          	add	a2,s4,s6
    800037b0:	85e2                	mv	a1,s8
    800037b2:	01893503          	ld	a0,24(s2)
    800037b6:	bdaff0ef          	jal	80002b90 <writei>
    800037ba:	84aa                	mv	s1,a0
    800037bc:	00a05763          	blez	a0,800037ca <filewrite+0xb4>
        f->off += r;
    800037c0:	02092783          	lw	a5,32(s2)
    800037c4:	9fa9                	addw	a5,a5,a0
    800037c6:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800037ca:	01893503          	ld	a0,24(s2)
    800037ce:	924ff0ef          	jal	800028f2 <iunlock>
      end_op();
    800037d2:	99bff0ef          	jal	8000316c <end_op>

      if(r != n1){
    800037d6:	02999563          	bne	s3,s1,80003800 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    800037da:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    800037de:	015a5963          	bge	s4,s5,800037f0 <filewrite+0xda>
      int n1 = n - i;
    800037e2:	414a87bb          	subw	a5,s5,s4
    800037e6:	89be                	mv	s3,a5
      if(n1 > max)
    800037e8:	fafbd8e3          	bge	s7,a5,80003798 <filewrite+0x82>
    800037ec:	89e6                	mv	s3,s9
    800037ee:	b76d                	j	80003798 <filewrite+0x82>
    800037f0:	64a6                	ld	s1,72(sp)
    800037f2:	79e2                	ld	s3,56(sp)
    800037f4:	6be2                	ld	s7,24(sp)
    800037f6:	6c42                	ld	s8,16(sp)
    800037f8:	6ca2                	ld	s9,8(sp)
    800037fa:	a801                	j	8000380a <filewrite+0xf4>
    int i = 0;
    800037fc:	4a01                	li	s4,0
    800037fe:	a031                	j	8000380a <filewrite+0xf4>
    80003800:	64a6                	ld	s1,72(sp)
    80003802:	79e2                	ld	s3,56(sp)
    80003804:	6be2                	ld	s7,24(sp)
    80003806:	6c42                	ld	s8,16(sp)
    80003808:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    8000380a:	034a9d63          	bne	s5,s4,80003844 <filewrite+0x12e>
    8000380e:	8556                	mv	a0,s5
    80003810:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80003812:	60e6                	ld	ra,88(sp)
    80003814:	6446                	ld	s0,80(sp)
    80003816:	6906                	ld	s2,64(sp)
    80003818:	7aa2                	ld	s5,40(sp)
    8000381a:	7b02                	ld	s6,32(sp)
    8000381c:	6125                	addi	sp,sp,96
    8000381e:	8082                	ret
    80003820:	e4a6                	sd	s1,72(sp)
    80003822:	fc4e                	sd	s3,56(sp)
    80003824:	f852                	sd	s4,48(sp)
    80003826:	ec5e                	sd	s7,24(sp)
    80003828:	e862                	sd	s8,16(sp)
    8000382a:	e466                	sd	s9,8(sp)
    panic("filewrite");
    8000382c:	00004517          	auipc	a0,0x4
    80003830:	d9c50513          	addi	a0,a0,-612 # 800075c8 <etext+0x5c8>
    80003834:	66b010ef          	jal	8000569e <panic>
    return -1;
    80003838:	557d                	li	a0,-1
}
    8000383a:	8082                	ret
      return -1;
    8000383c:	557d                	li	a0,-1
    8000383e:	bfd1                	j	80003812 <filewrite+0xfc>
    80003840:	557d                	li	a0,-1
    80003842:	bfc1                	j	80003812 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    80003844:	557d                	li	a0,-1
    80003846:	7a42                	ld	s4,48(sp)
    80003848:	b7e9                	j	80003812 <filewrite+0xfc>

000000008000384a <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    8000384a:	7179                	addi	sp,sp,-48
    8000384c:	f406                	sd	ra,40(sp)
    8000384e:	f022                	sd	s0,32(sp)
    80003850:	ec26                	sd	s1,24(sp)
    80003852:	e052                	sd	s4,0(sp)
    80003854:	1800                	addi	s0,sp,48
    80003856:	84aa                	mv	s1,a0
    80003858:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    8000385a:	0005b023          	sd	zero,0(a1)
    8000385e:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80003862:	c29ff0ef          	jal	8000348a <filealloc>
    80003866:	e088                	sd	a0,0(s1)
    80003868:	c549                	beqz	a0,800038f2 <pipealloc+0xa8>
    8000386a:	c21ff0ef          	jal	8000348a <filealloc>
    8000386e:	00aa3023          	sd	a0,0(s4)
    80003872:	cd25                	beqz	a0,800038ea <pipealloc+0xa0>
    80003874:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80003876:	88ffc0ef          	jal	80000104 <kalloc>
    8000387a:	892a                	mv	s2,a0
    8000387c:	c12d                	beqz	a0,800038de <pipealloc+0x94>
    8000387e:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80003880:	4985                	li	s3,1
    80003882:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80003886:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000388a:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000388e:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80003892:	00004597          	auipc	a1,0x4
    80003896:	d4658593          	addi	a1,a1,-698 # 800075d8 <etext+0x5d8>
    8000389a:	0b8020ef          	jal	80005952 <initlock>
  (*f0)->type = FD_PIPE;
    8000389e:	609c                	ld	a5,0(s1)
    800038a0:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800038a4:	609c                	ld	a5,0(s1)
    800038a6:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800038aa:	609c                	ld	a5,0(s1)
    800038ac:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800038b0:	609c                	ld	a5,0(s1)
    800038b2:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800038b6:	000a3783          	ld	a5,0(s4)
    800038ba:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800038be:	000a3783          	ld	a5,0(s4)
    800038c2:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800038c6:	000a3783          	ld	a5,0(s4)
    800038ca:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800038ce:	000a3783          	ld	a5,0(s4)
    800038d2:	0127b823          	sd	s2,16(a5)
  return 0;
    800038d6:	4501                	li	a0,0
    800038d8:	6942                	ld	s2,16(sp)
    800038da:	69a2                	ld	s3,8(sp)
    800038dc:	a01d                	j	80003902 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    800038de:	6088                	ld	a0,0(s1)
    800038e0:	c119                	beqz	a0,800038e6 <pipealloc+0x9c>
    800038e2:	6942                	ld	s2,16(sp)
    800038e4:	a029                	j	800038ee <pipealloc+0xa4>
    800038e6:	6942                	ld	s2,16(sp)
    800038e8:	a029                	j	800038f2 <pipealloc+0xa8>
    800038ea:	6088                	ld	a0,0(s1)
    800038ec:	c10d                	beqz	a0,8000390e <pipealloc+0xc4>
    fileclose(*f0);
    800038ee:	c41ff0ef          	jal	8000352e <fileclose>
  if(*f1)
    800038f2:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800038f6:	557d                	li	a0,-1
  if(*f1)
    800038f8:	c789                	beqz	a5,80003902 <pipealloc+0xb8>
    fileclose(*f1);
    800038fa:	853e                	mv	a0,a5
    800038fc:	c33ff0ef          	jal	8000352e <fileclose>
  return -1;
    80003900:	557d                	li	a0,-1
}
    80003902:	70a2                	ld	ra,40(sp)
    80003904:	7402                	ld	s0,32(sp)
    80003906:	64e2                	ld	s1,24(sp)
    80003908:	6a02                	ld	s4,0(sp)
    8000390a:	6145                	addi	sp,sp,48
    8000390c:	8082                	ret
  return -1;
    8000390e:	557d                	li	a0,-1
    80003910:	bfcd                	j	80003902 <pipealloc+0xb8>

0000000080003912 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80003912:	1101                	addi	sp,sp,-32
    80003914:	ec06                	sd	ra,24(sp)
    80003916:	e822                	sd	s0,16(sp)
    80003918:	e426                	sd	s1,8(sp)
    8000391a:	e04a                	sd	s2,0(sp)
    8000391c:	1000                	addi	s0,sp,32
    8000391e:	84aa                	mv	s1,a0
    80003920:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80003922:	0ba020ef          	jal	800059dc <acquire>
  if(writable){
    80003926:	02090763          	beqz	s2,80003954 <pipeclose+0x42>
    pi->writeopen = 0;
    8000392a:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    8000392e:	21848513          	addi	a0,s1,536
    80003932:	c27fd0ef          	jal	80001558 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80003936:	2204a783          	lw	a5,544(s1)
    8000393a:	e781                	bnez	a5,80003942 <pipeclose+0x30>
    8000393c:	2244a783          	lw	a5,548(s1)
    80003940:	c38d                	beqz	a5,80003962 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    80003942:	8526                	mv	a0,s1
    80003944:	12c020ef          	jal	80005a70 <release>
}
    80003948:	60e2                	ld	ra,24(sp)
    8000394a:	6442                	ld	s0,16(sp)
    8000394c:	64a2                	ld	s1,8(sp)
    8000394e:	6902                	ld	s2,0(sp)
    80003950:	6105                	addi	sp,sp,32
    80003952:	8082                	ret
    pi->readopen = 0;
    80003954:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80003958:	21c48513          	addi	a0,s1,540
    8000395c:	bfdfd0ef          	jal	80001558 <wakeup>
    80003960:	bfd9                	j	80003936 <pipeclose+0x24>
    release(&pi->lock);
    80003962:	8526                	mv	a0,s1
    80003964:	10c020ef          	jal	80005a70 <release>
    kfree((char*)pi);
    80003968:	8526                	mv	a0,s1
    8000396a:	eb2fc0ef          	jal	8000001c <kfree>
    8000396e:	bfe9                	j	80003948 <pipeclose+0x36>

0000000080003970 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80003970:	7159                	addi	sp,sp,-112
    80003972:	f486                	sd	ra,104(sp)
    80003974:	f0a2                	sd	s0,96(sp)
    80003976:	eca6                	sd	s1,88(sp)
    80003978:	e8ca                	sd	s2,80(sp)
    8000397a:	e4ce                	sd	s3,72(sp)
    8000397c:	e0d2                	sd	s4,64(sp)
    8000397e:	fc56                	sd	s5,56(sp)
    80003980:	1880                	addi	s0,sp,112
    80003982:	84aa                	mv	s1,a0
    80003984:	8aae                	mv	s5,a1
    80003986:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80003988:	d2efd0ef          	jal	80000eb6 <myproc>
    8000398c:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    8000398e:	8526                	mv	a0,s1
    80003990:	04c020ef          	jal	800059dc <acquire>
  while(i < n){
    80003994:	0d405263          	blez	s4,80003a58 <pipewrite+0xe8>
    80003998:	f85a                	sd	s6,48(sp)
    8000399a:	f45e                	sd	s7,40(sp)
    8000399c:	f062                	sd	s8,32(sp)
    8000399e:	ec66                	sd	s9,24(sp)
    800039a0:	e86a                	sd	s10,16(sp)
  int i = 0;
    800039a2:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800039a4:	f9f40c13          	addi	s8,s0,-97
    800039a8:	4b85                	li	s7,1
    800039aa:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800039ac:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    800039b0:	21c48c93          	addi	s9,s1,540
    800039b4:	a82d                	j	800039ee <pipewrite+0x7e>
      release(&pi->lock);
    800039b6:	8526                	mv	a0,s1
    800039b8:	0b8020ef          	jal	80005a70 <release>
      return -1;
    800039bc:	597d                	li	s2,-1
    800039be:	7b42                	ld	s6,48(sp)
    800039c0:	7ba2                	ld	s7,40(sp)
    800039c2:	7c02                	ld	s8,32(sp)
    800039c4:	6ce2                	ld	s9,24(sp)
    800039c6:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800039c8:	854a                	mv	a0,s2
    800039ca:	70a6                	ld	ra,104(sp)
    800039cc:	7406                	ld	s0,96(sp)
    800039ce:	64e6                	ld	s1,88(sp)
    800039d0:	6946                	ld	s2,80(sp)
    800039d2:	69a6                	ld	s3,72(sp)
    800039d4:	6a06                	ld	s4,64(sp)
    800039d6:	7ae2                	ld	s5,56(sp)
    800039d8:	6165                	addi	sp,sp,112
    800039da:	8082                	ret
      wakeup(&pi->nread);
    800039dc:	856a                	mv	a0,s10
    800039de:	b7bfd0ef          	jal	80001558 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    800039e2:	85a6                	mv	a1,s1
    800039e4:	8566                	mv	a0,s9
    800039e6:	b27fd0ef          	jal	8000150c <sleep>
  while(i < n){
    800039ea:	05495a63          	bge	s2,s4,80003a3e <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    800039ee:	2204a783          	lw	a5,544(s1)
    800039f2:	d3f1                	beqz	a5,800039b6 <pipewrite+0x46>
    800039f4:	854e                	mv	a0,s3
    800039f6:	d53fd0ef          	jal	80001748 <killed>
    800039fa:	fd55                	bnez	a0,800039b6 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    800039fc:	2184a783          	lw	a5,536(s1)
    80003a00:	21c4a703          	lw	a4,540(s1)
    80003a04:	2007879b          	addiw	a5,a5,512
    80003a08:	fcf70ae3          	beq	a4,a5,800039dc <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003a0c:	86de                	mv	a3,s7
    80003a0e:	01590633          	add	a2,s2,s5
    80003a12:	85e2                	mv	a1,s8
    80003a14:	0509b503          	ld	a0,80(s3)
    80003a18:	98efd0ef          	jal	80000ba6 <copyin>
    80003a1c:	05650063          	beq	a0,s6,80003a5c <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80003a20:	21c4a783          	lw	a5,540(s1)
    80003a24:	0017871b          	addiw	a4,a5,1
    80003a28:	20e4ae23          	sw	a4,540(s1)
    80003a2c:	1ff7f793          	andi	a5,a5,511
    80003a30:	97a6                	add	a5,a5,s1
    80003a32:	f9f44703          	lbu	a4,-97(s0)
    80003a36:	00e78c23          	sb	a4,24(a5)
      i++;
    80003a3a:	2905                	addiw	s2,s2,1
    80003a3c:	b77d                	j	800039ea <pipewrite+0x7a>
    80003a3e:	7b42                	ld	s6,48(sp)
    80003a40:	7ba2                	ld	s7,40(sp)
    80003a42:	7c02                	ld	s8,32(sp)
    80003a44:	6ce2                	ld	s9,24(sp)
    80003a46:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80003a48:	21848513          	addi	a0,s1,536
    80003a4c:	b0dfd0ef          	jal	80001558 <wakeup>
  release(&pi->lock);
    80003a50:	8526                	mv	a0,s1
    80003a52:	01e020ef          	jal	80005a70 <release>
  return i;
    80003a56:	bf8d                	j	800039c8 <pipewrite+0x58>
  int i = 0;
    80003a58:	4901                	li	s2,0
    80003a5a:	b7fd                	j	80003a48 <pipewrite+0xd8>
    80003a5c:	7b42                	ld	s6,48(sp)
    80003a5e:	7ba2                	ld	s7,40(sp)
    80003a60:	7c02                	ld	s8,32(sp)
    80003a62:	6ce2                	ld	s9,24(sp)
    80003a64:	6d42                	ld	s10,16(sp)
    80003a66:	b7cd                	j	80003a48 <pipewrite+0xd8>

0000000080003a68 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80003a68:	711d                	addi	sp,sp,-96
    80003a6a:	ec86                	sd	ra,88(sp)
    80003a6c:	e8a2                	sd	s0,80(sp)
    80003a6e:	e4a6                	sd	s1,72(sp)
    80003a70:	e0ca                	sd	s2,64(sp)
    80003a72:	fc4e                	sd	s3,56(sp)
    80003a74:	f852                	sd	s4,48(sp)
    80003a76:	f456                	sd	s5,40(sp)
    80003a78:	1080                	addi	s0,sp,96
    80003a7a:	84aa                	mv	s1,a0
    80003a7c:	892e                	mv	s2,a1
    80003a7e:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80003a80:	c36fd0ef          	jal	80000eb6 <myproc>
    80003a84:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80003a86:	8526                	mv	a0,s1
    80003a88:	755010ef          	jal	800059dc <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a8c:	2184a703          	lw	a4,536(s1)
    80003a90:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003a94:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a98:	02f71763          	bne	a4,a5,80003ac6 <piperead+0x5e>
    80003a9c:	2244a783          	lw	a5,548(s1)
    80003aa0:	cf85                	beqz	a5,80003ad8 <piperead+0x70>
    if(killed(pr)){
    80003aa2:	8552                	mv	a0,s4
    80003aa4:	ca5fd0ef          	jal	80001748 <killed>
    80003aa8:	e11d                	bnez	a0,80003ace <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003aaa:	85a6                	mv	a1,s1
    80003aac:	854e                	mv	a0,s3
    80003aae:	a5ffd0ef          	jal	8000150c <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003ab2:	2184a703          	lw	a4,536(s1)
    80003ab6:	21c4a783          	lw	a5,540(s1)
    80003aba:	fef701e3          	beq	a4,a5,80003a9c <piperead+0x34>
    80003abe:	f05a                	sd	s6,32(sp)
    80003ac0:	ec5e                	sd	s7,24(sp)
    80003ac2:	e862                	sd	s8,16(sp)
    80003ac4:	a829                	j	80003ade <piperead+0x76>
    80003ac6:	f05a                	sd	s6,32(sp)
    80003ac8:	ec5e                	sd	s7,24(sp)
    80003aca:	e862                	sd	s8,16(sp)
    80003acc:	a809                	j	80003ade <piperead+0x76>
      release(&pi->lock);
    80003ace:	8526                	mv	a0,s1
    80003ad0:	7a1010ef          	jal	80005a70 <release>
      return -1;
    80003ad4:	59fd                	li	s3,-1
    80003ad6:	a09d                	j	80003b3c <piperead+0xd4>
    80003ad8:	f05a                	sd	s6,32(sp)
    80003ada:	ec5e                	sd	s7,24(sp)
    80003adc:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003ade:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003ae0:	faf40c13          	addi	s8,s0,-81
    80003ae4:	4b85                	li	s7,1
    80003ae6:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003ae8:	05505063          	blez	s5,80003b28 <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    80003aec:	2184a783          	lw	a5,536(s1)
    80003af0:	21c4a703          	lw	a4,540(s1)
    80003af4:	02f70a63          	beq	a4,a5,80003b28 <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003af8:	0017871b          	addiw	a4,a5,1
    80003afc:	20e4ac23          	sw	a4,536(s1)
    80003b00:	1ff7f793          	andi	a5,a5,511
    80003b04:	97a6                	add	a5,a5,s1
    80003b06:	0187c783          	lbu	a5,24(a5)
    80003b0a:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003b0e:	86de                	mv	a3,s7
    80003b10:	8662                	mv	a2,s8
    80003b12:	85ca                	mv	a1,s2
    80003b14:	050a3503          	ld	a0,80(s4)
    80003b18:	fdffc0ef          	jal	80000af6 <copyout>
    80003b1c:	01650663          	beq	a0,s6,80003b28 <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003b20:	2985                	addiw	s3,s3,1
    80003b22:	0905                	addi	s2,s2,1
    80003b24:	fd3a94e3          	bne	s5,s3,80003aec <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003b28:	21c48513          	addi	a0,s1,540
    80003b2c:	a2dfd0ef          	jal	80001558 <wakeup>
  release(&pi->lock);
    80003b30:	8526                	mv	a0,s1
    80003b32:	73f010ef          	jal	80005a70 <release>
    80003b36:	7b02                	ld	s6,32(sp)
    80003b38:	6be2                	ld	s7,24(sp)
    80003b3a:	6c42                	ld	s8,16(sp)
  return i;
}
    80003b3c:	854e                	mv	a0,s3
    80003b3e:	60e6                	ld	ra,88(sp)
    80003b40:	6446                	ld	s0,80(sp)
    80003b42:	64a6                	ld	s1,72(sp)
    80003b44:	6906                	ld	s2,64(sp)
    80003b46:	79e2                	ld	s3,56(sp)
    80003b48:	7a42                	ld	s4,48(sp)
    80003b4a:	7aa2                	ld	s5,40(sp)
    80003b4c:	6125                	addi	sp,sp,96
    80003b4e:	8082                	ret

0000000080003b50 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003b50:	1141                	addi	sp,sp,-16
    80003b52:	e406                	sd	ra,8(sp)
    80003b54:	e022                	sd	s0,0(sp)
    80003b56:	0800                	addi	s0,sp,16
    80003b58:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003b5a:	0035151b          	slliw	a0,a0,0x3
    80003b5e:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80003b60:	8b89                	andi	a5,a5,2
    80003b62:	c399                	beqz	a5,80003b68 <flags2perm+0x18>
      perm |= PTE_W;
    80003b64:	00456513          	ori	a0,a0,4
    return perm;
}
    80003b68:	60a2                	ld	ra,8(sp)
    80003b6a:	6402                	ld	s0,0(sp)
    80003b6c:	0141                	addi	sp,sp,16
    80003b6e:	8082                	ret

0000000080003b70 <exec>:

int
exec(char *path, char **argv)
{
    80003b70:	de010113          	addi	sp,sp,-544
    80003b74:	20113c23          	sd	ra,536(sp)
    80003b78:	20813823          	sd	s0,528(sp)
    80003b7c:	20913423          	sd	s1,520(sp)
    80003b80:	21213023          	sd	s2,512(sp)
    80003b84:	1400                	addi	s0,sp,544
    80003b86:	892a                	mv	s2,a0
    80003b88:	dea43823          	sd	a0,-528(s0)
    80003b8c:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80003b90:	b26fd0ef          	jal	80000eb6 <myproc>
    80003b94:	84aa                	mv	s1,a0

  begin_op();
    80003b96:	d66ff0ef          	jal	800030fc <begin_op>

  if((ip = namei(path)) == 0){
    80003b9a:	854a                	mv	a0,s2
    80003b9c:	b9eff0ef          	jal	80002f3a <namei>
    80003ba0:	cd21                	beqz	a0,80003bf8 <exec+0x88>
    80003ba2:	fbd2                	sd	s4,496(sp)
    80003ba4:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80003ba6:	c9ffe0ef          	jal	80002844 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80003baa:	04000713          	li	a4,64
    80003bae:	4681                	li	a3,0
    80003bb0:	e5040613          	addi	a2,s0,-432
    80003bb4:	4581                	li	a1,0
    80003bb6:	8552                	mv	a0,s4
    80003bb8:	ee7fe0ef          	jal	80002a9e <readi>
    80003bbc:	04000793          	li	a5,64
    80003bc0:	00f51a63          	bne	a0,a5,80003bd4 <exec+0x64>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80003bc4:	e5042703          	lw	a4,-432(s0)
    80003bc8:	464c47b7          	lui	a5,0x464c4
    80003bcc:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003bd0:	02f70863          	beq	a4,a5,80003c00 <exec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003bd4:	8552                	mv	a0,s4
    80003bd6:	e7bfe0ef          	jal	80002a50 <iunlockput>
    end_op();
    80003bda:	d92ff0ef          	jal	8000316c <end_op>
  }
  return -1;
    80003bde:	557d                	li	a0,-1
    80003be0:	7a5e                	ld	s4,496(sp)
}
    80003be2:	21813083          	ld	ra,536(sp)
    80003be6:	21013403          	ld	s0,528(sp)
    80003bea:	20813483          	ld	s1,520(sp)
    80003bee:	20013903          	ld	s2,512(sp)
    80003bf2:	22010113          	addi	sp,sp,544
    80003bf6:	8082                	ret
    end_op();
    80003bf8:	d74ff0ef          	jal	8000316c <end_op>
    return -1;
    80003bfc:	557d                	li	a0,-1
    80003bfe:	b7d5                	j	80003be2 <exec+0x72>
    80003c00:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80003c02:	8526                	mv	a0,s1
    80003c04:	b5cfd0ef          	jal	80000f60 <proc_pagetable>
    80003c08:	8b2a                	mv	s6,a0
    80003c0a:	26050f63          	beqz	a0,80003e88 <exec+0x318>
    80003c0e:	ffce                	sd	s3,504(sp)
    80003c10:	f7d6                	sd	s5,488(sp)
    80003c12:	efde                	sd	s7,472(sp)
    80003c14:	ebe2                	sd	s8,464(sp)
    80003c16:	e7e6                	sd	s9,456(sp)
    80003c18:	e3ea                	sd	s10,448(sp)
    80003c1a:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003c1c:	e8845783          	lhu	a5,-376(s0)
    80003c20:	0e078963          	beqz	a5,80003d12 <exec+0x1a2>
    80003c24:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003c28:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003c2a:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003c2c:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80003c30:	6c85                	lui	s9,0x1
    80003c32:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80003c36:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80003c3a:	6a85                	lui	s5,0x1
    80003c3c:	a085                	j	80003c9c <exec+0x12c>
      panic("loadseg: address should exist");
    80003c3e:	00004517          	auipc	a0,0x4
    80003c42:	9a250513          	addi	a0,a0,-1630 # 800075e0 <etext+0x5e0>
    80003c46:	259010ef          	jal	8000569e <panic>
    if(sz - i < PGSIZE)
    80003c4a:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003c4c:	874a                	mv	a4,s2
    80003c4e:	009b86bb          	addw	a3,s7,s1
    80003c52:	4581                	li	a1,0
    80003c54:	8552                	mv	a0,s4
    80003c56:	e49fe0ef          	jal	80002a9e <readi>
    80003c5a:	22a91b63          	bne	s2,a0,80003e90 <exec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    80003c5e:	009a84bb          	addw	s1,s5,s1
    80003c62:	0334f263          	bgeu	s1,s3,80003c86 <exec+0x116>
    pa = walkaddr(pagetable, va + i);
    80003c66:	02049593          	slli	a1,s1,0x20
    80003c6a:	9181                	srli	a1,a1,0x20
    80003c6c:	95e2                	add	a1,a1,s8
    80003c6e:	855a                	mv	a0,s6
    80003c70:	901fc0ef          	jal	80000570 <walkaddr>
    80003c74:	862a                	mv	a2,a0
    if(pa == 0)
    80003c76:	d561                	beqz	a0,80003c3e <exec+0xce>
    if(sz - i < PGSIZE)
    80003c78:	409987bb          	subw	a5,s3,s1
    80003c7c:	893e                	mv	s2,a5
    80003c7e:	fcfcf6e3          	bgeu	s9,a5,80003c4a <exec+0xda>
    80003c82:	8956                	mv	s2,s5
    80003c84:	b7d9                	j	80003c4a <exec+0xda>
    sz = sz1;
    80003c86:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003c8a:	2d05                	addiw	s10,s10,1
    80003c8c:	e0843783          	ld	a5,-504(s0)
    80003c90:	0387869b          	addiw	a3,a5,56
    80003c94:	e8845783          	lhu	a5,-376(s0)
    80003c98:	06fd5e63          	bge	s10,a5,80003d14 <exec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003c9c:	e0d43423          	sd	a3,-504(s0)
    80003ca0:	876e                	mv	a4,s11
    80003ca2:	e1840613          	addi	a2,s0,-488
    80003ca6:	4581                	li	a1,0
    80003ca8:	8552                	mv	a0,s4
    80003caa:	df5fe0ef          	jal	80002a9e <readi>
    80003cae:	1db51f63          	bne	a0,s11,80003e8c <exec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80003cb2:	e1842783          	lw	a5,-488(s0)
    80003cb6:	4705                	li	a4,1
    80003cb8:	fce799e3          	bne	a5,a4,80003c8a <exec+0x11a>
    if(ph.memsz < ph.filesz)
    80003cbc:	e4043483          	ld	s1,-448(s0)
    80003cc0:	e3843783          	ld	a5,-456(s0)
    80003cc4:	1ef4e463          	bltu	s1,a5,80003eac <exec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003cc8:	e2843783          	ld	a5,-472(s0)
    80003ccc:	94be                	add	s1,s1,a5
    80003cce:	1ef4e263          	bltu	s1,a5,80003eb2 <exec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80003cd2:	de843703          	ld	a4,-536(s0)
    80003cd6:	8ff9                	and	a5,a5,a4
    80003cd8:	1e079063          	bnez	a5,80003eb8 <exec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003cdc:	e1c42503          	lw	a0,-484(s0)
    80003ce0:	e71ff0ef          	jal	80003b50 <flags2perm>
    80003ce4:	86aa                	mv	a3,a0
    80003ce6:	8626                	mv	a2,s1
    80003ce8:	85ca                	mv	a1,s2
    80003cea:	855a                	mv	a0,s6
    80003cec:	bfbfc0ef          	jal	800008e6 <uvmalloc>
    80003cf0:	dea43c23          	sd	a0,-520(s0)
    80003cf4:	1c050563          	beqz	a0,80003ebe <exec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003cf8:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003cfc:	00098863          	beqz	s3,80003d0c <exec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003d00:	e2843c03          	ld	s8,-472(s0)
    80003d04:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003d08:	4481                	li	s1,0
    80003d0a:	bfb1                	j	80003c66 <exec+0xf6>
    sz = sz1;
    80003d0c:	df843903          	ld	s2,-520(s0)
    80003d10:	bfad                	j	80003c8a <exec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003d12:	4901                	li	s2,0
  iunlockput(ip);
    80003d14:	8552                	mv	a0,s4
    80003d16:	d3bfe0ef          	jal	80002a50 <iunlockput>
  end_op();
    80003d1a:	c52ff0ef          	jal	8000316c <end_op>
  p = myproc();
    80003d1e:	998fd0ef          	jal	80000eb6 <myproc>
    80003d22:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80003d24:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003d28:	6985                	lui	s3,0x1
    80003d2a:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80003d2c:	99ca                	add	s3,s3,s2
    80003d2e:	77fd                	lui	a5,0xfffff
    80003d30:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003d34:	4691                	li	a3,4
    80003d36:	6609                	lui	a2,0x2
    80003d38:	964e                	add	a2,a2,s3
    80003d3a:	85ce                	mv	a1,s3
    80003d3c:	855a                	mv	a0,s6
    80003d3e:	ba9fc0ef          	jal	800008e6 <uvmalloc>
    80003d42:	8a2a                	mv	s4,a0
    80003d44:	e105                	bnez	a0,80003d64 <exec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80003d46:	85ce                	mv	a1,s3
    80003d48:	855a                	mv	a0,s6
    80003d4a:	ae4fd0ef          	jal	8000102e <proc_freepagetable>
  return -1;
    80003d4e:	557d                	li	a0,-1
    80003d50:	79fe                	ld	s3,504(sp)
    80003d52:	7a5e                	ld	s4,496(sp)
    80003d54:	7abe                	ld	s5,488(sp)
    80003d56:	7b1e                	ld	s6,480(sp)
    80003d58:	6bfe                	ld	s7,472(sp)
    80003d5a:	6c5e                	ld	s8,464(sp)
    80003d5c:	6cbe                	ld	s9,456(sp)
    80003d5e:	6d1e                	ld	s10,448(sp)
    80003d60:	7dfa                	ld	s11,440(sp)
    80003d62:	b541                	j	80003be2 <exec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003d64:	75f9                	lui	a1,0xffffe
    80003d66:	95aa                	add	a1,a1,a0
    80003d68:	855a                	mv	a0,s6
    80003d6a:	d63fc0ef          	jal	80000acc <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003d6e:	800a0b93          	addi	s7,s4,-2048
    80003d72:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80003d76:	e0043783          	ld	a5,-512(s0)
    80003d7a:	6388                	ld	a0,0(a5)
  sp = sz;
    80003d7c:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80003d7e:	4481                	li	s1,0
    ustack[argc] = sp;
    80003d80:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80003d84:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80003d88:	cd21                	beqz	a0,80003de0 <exec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80003d8a:	d5efc0ef          	jal	800002e8 <strlen>
    80003d8e:	0015079b          	addiw	a5,a0,1
    80003d92:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003d96:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80003d9a:	13796563          	bltu	s2,s7,80003ec4 <exec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003d9e:	e0043d83          	ld	s11,-512(s0)
    80003da2:	000db983          	ld	s3,0(s11)
    80003da6:	854e                	mv	a0,s3
    80003da8:	d40fc0ef          	jal	800002e8 <strlen>
    80003dac:	0015069b          	addiw	a3,a0,1
    80003db0:	864e                	mv	a2,s3
    80003db2:	85ca                	mv	a1,s2
    80003db4:	855a                	mv	a0,s6
    80003db6:	d41fc0ef          	jal	80000af6 <copyout>
    80003dba:	10054763          	bltz	a0,80003ec8 <exec+0x358>
    ustack[argc] = sp;
    80003dbe:	00349793          	slli	a5,s1,0x3
    80003dc2:	97e6                	add	a5,a5,s9
    80003dc4:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde120>
  for(argc = 0; argv[argc]; argc++) {
    80003dc8:	0485                	addi	s1,s1,1
    80003dca:	008d8793          	addi	a5,s11,8
    80003dce:	e0f43023          	sd	a5,-512(s0)
    80003dd2:	008db503          	ld	a0,8(s11)
    80003dd6:	c509                	beqz	a0,80003de0 <exec+0x270>
    if(argc >= MAXARG)
    80003dd8:	fb8499e3          	bne	s1,s8,80003d8a <exec+0x21a>
  sz = sz1;
    80003ddc:	89d2                	mv	s3,s4
    80003dde:	b7a5                	j	80003d46 <exec+0x1d6>
  ustack[argc] = 0;
    80003de0:	00349793          	slli	a5,s1,0x3
    80003de4:	f9078793          	addi	a5,a5,-112
    80003de8:	97a2                	add	a5,a5,s0
    80003dea:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80003dee:	00349693          	slli	a3,s1,0x3
    80003df2:	06a1                	addi	a3,a3,8
    80003df4:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003df8:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80003dfc:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80003dfe:	f57964e3          	bltu	s2,s7,80003d46 <exec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003e02:	e9040613          	addi	a2,s0,-368
    80003e06:	85ca                	mv	a1,s2
    80003e08:	855a                	mv	a0,s6
    80003e0a:	cedfc0ef          	jal	80000af6 <copyout>
    80003e0e:	f2054ce3          	bltz	a0,80003d46 <exec+0x1d6>
  p->trapframe->a1 = sp;
    80003e12:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80003e16:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003e1a:	df043783          	ld	a5,-528(s0)
    80003e1e:	0007c703          	lbu	a4,0(a5)
    80003e22:	cf11                	beqz	a4,80003e3e <exec+0x2ce>
    80003e24:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003e26:	02f00693          	li	a3,47
    80003e2a:	a029                	j	80003e34 <exec+0x2c4>
  for(last=s=path; *s; s++)
    80003e2c:	0785                	addi	a5,a5,1
    80003e2e:	fff7c703          	lbu	a4,-1(a5)
    80003e32:	c711                	beqz	a4,80003e3e <exec+0x2ce>
    if(*s == '/')
    80003e34:	fed71ce3          	bne	a4,a3,80003e2c <exec+0x2bc>
      last = s+1;
    80003e38:	def43823          	sd	a5,-528(s0)
    80003e3c:	bfc5                	j	80003e2c <exec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80003e3e:	4641                	li	a2,16
    80003e40:	df043583          	ld	a1,-528(s0)
    80003e44:	160a8513          	addi	a0,s5,352
    80003e48:	c6afc0ef          	jal	800002b2 <safestrcpy>
  oldpagetable = p->pagetable;
    80003e4c:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80003e50:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80003e54:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003e58:	058ab783          	ld	a5,88(s5)
    80003e5c:	e6843703          	ld	a4,-408(s0)
    80003e60:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003e62:	058ab783          	ld	a5,88(s5)
    80003e66:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003e6a:	85ea                	mv	a1,s10
    80003e6c:	9c2fd0ef          	jal	8000102e <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003e70:	0004851b          	sext.w	a0,s1
    80003e74:	79fe                	ld	s3,504(sp)
    80003e76:	7a5e                	ld	s4,496(sp)
    80003e78:	7abe                	ld	s5,488(sp)
    80003e7a:	7b1e                	ld	s6,480(sp)
    80003e7c:	6bfe                	ld	s7,472(sp)
    80003e7e:	6c5e                	ld	s8,464(sp)
    80003e80:	6cbe                	ld	s9,456(sp)
    80003e82:	6d1e                	ld	s10,448(sp)
    80003e84:	7dfa                	ld	s11,440(sp)
    80003e86:	bbb1                	j	80003be2 <exec+0x72>
    80003e88:	7b1e                	ld	s6,480(sp)
    80003e8a:	b3a9                	j	80003bd4 <exec+0x64>
    80003e8c:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003e90:	df843583          	ld	a1,-520(s0)
    80003e94:	855a                	mv	a0,s6
    80003e96:	998fd0ef          	jal	8000102e <proc_freepagetable>
  if(ip){
    80003e9a:	79fe                	ld	s3,504(sp)
    80003e9c:	7abe                	ld	s5,488(sp)
    80003e9e:	7b1e                	ld	s6,480(sp)
    80003ea0:	6bfe                	ld	s7,472(sp)
    80003ea2:	6c5e                	ld	s8,464(sp)
    80003ea4:	6cbe                	ld	s9,456(sp)
    80003ea6:	6d1e                	ld	s10,448(sp)
    80003ea8:	7dfa                	ld	s11,440(sp)
    80003eaa:	b32d                	j	80003bd4 <exec+0x64>
    80003eac:	df243c23          	sd	s2,-520(s0)
    80003eb0:	b7c5                	j	80003e90 <exec+0x320>
    80003eb2:	df243c23          	sd	s2,-520(s0)
    80003eb6:	bfe9                	j	80003e90 <exec+0x320>
    80003eb8:	df243c23          	sd	s2,-520(s0)
    80003ebc:	bfd1                	j	80003e90 <exec+0x320>
    80003ebe:	df243c23          	sd	s2,-520(s0)
    80003ec2:	b7f9                	j	80003e90 <exec+0x320>
  sz = sz1;
    80003ec4:	89d2                	mv	s3,s4
    80003ec6:	b541                	j	80003d46 <exec+0x1d6>
    80003ec8:	89d2                	mv	s3,s4
    80003eca:	bdb5                	j	80003d46 <exec+0x1d6>

0000000080003ecc <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003ecc:	7179                	addi	sp,sp,-48
    80003ece:	f406                	sd	ra,40(sp)
    80003ed0:	f022                	sd	s0,32(sp)
    80003ed2:	ec26                	sd	s1,24(sp)
    80003ed4:	e84a                	sd	s2,16(sp)
    80003ed6:	1800                	addi	s0,sp,48
    80003ed8:	892e                	mv	s2,a1
    80003eda:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003edc:	fdc40593          	addi	a1,s0,-36
    80003ee0:	f1bfd0ef          	jal	80001dfa <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003ee4:	fdc42703          	lw	a4,-36(s0)
    80003ee8:	47bd                	li	a5,15
    80003eea:	02e7ea63          	bltu	a5,a4,80003f1e <argfd+0x52>
    80003eee:	fc9fc0ef          	jal	80000eb6 <myproc>
    80003ef2:	fdc42703          	lw	a4,-36(s0)
    80003ef6:	00371793          	slli	a5,a4,0x3
    80003efa:	0d078793          	addi	a5,a5,208
    80003efe:	953e                	add	a0,a0,a5
    80003f00:	651c                	ld	a5,8(a0)
    80003f02:	c385                	beqz	a5,80003f22 <argfd+0x56>
    return -1;
  if(pfd)
    80003f04:	00090463          	beqz	s2,80003f0c <argfd+0x40>
    *pfd = fd;
    80003f08:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003f0c:	4501                	li	a0,0
  if(pf)
    80003f0e:	c091                	beqz	s1,80003f12 <argfd+0x46>
    *pf = f;
    80003f10:	e09c                	sd	a5,0(s1)
}
    80003f12:	70a2                	ld	ra,40(sp)
    80003f14:	7402                	ld	s0,32(sp)
    80003f16:	64e2                	ld	s1,24(sp)
    80003f18:	6942                	ld	s2,16(sp)
    80003f1a:	6145                	addi	sp,sp,48
    80003f1c:	8082                	ret
    return -1;
    80003f1e:	557d                	li	a0,-1
    80003f20:	bfcd                	j	80003f12 <argfd+0x46>
    80003f22:	557d                	li	a0,-1
    80003f24:	b7fd                	j	80003f12 <argfd+0x46>

0000000080003f26 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003f26:	1101                	addi	sp,sp,-32
    80003f28:	ec06                	sd	ra,24(sp)
    80003f2a:	e822                	sd	s0,16(sp)
    80003f2c:	e426                	sd	s1,8(sp)
    80003f2e:	1000                	addi	s0,sp,32
    80003f30:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003f32:	f85fc0ef          	jal	80000eb6 <myproc>
    80003f36:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003f38:	0d850793          	addi	a5,a0,216
    80003f3c:	4501                	li	a0,0
    80003f3e:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003f40:	6398                	ld	a4,0(a5)
    80003f42:	cb19                	beqz	a4,80003f58 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003f44:	2505                	addiw	a0,a0,1
    80003f46:	07a1                	addi	a5,a5,8
    80003f48:	fed51ce3          	bne	a0,a3,80003f40 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003f4c:	557d                	li	a0,-1
}
    80003f4e:	60e2                	ld	ra,24(sp)
    80003f50:	6442                	ld	s0,16(sp)
    80003f52:	64a2                	ld	s1,8(sp)
    80003f54:	6105                	addi	sp,sp,32
    80003f56:	8082                	ret
      p->ofile[fd] = f;
    80003f58:	00351793          	slli	a5,a0,0x3
    80003f5c:	0d078793          	addi	a5,a5,208
    80003f60:	963e                	add	a2,a2,a5
    80003f62:	e604                	sd	s1,8(a2)
      return fd;
    80003f64:	b7ed                	j	80003f4e <fdalloc+0x28>

0000000080003f66 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003f66:	715d                	addi	sp,sp,-80
    80003f68:	e486                	sd	ra,72(sp)
    80003f6a:	e0a2                	sd	s0,64(sp)
    80003f6c:	fc26                	sd	s1,56(sp)
    80003f6e:	f84a                	sd	s2,48(sp)
    80003f70:	f44e                	sd	s3,40(sp)
    80003f72:	f052                	sd	s4,32(sp)
    80003f74:	ec56                	sd	s5,24(sp)
    80003f76:	e85a                	sd	s6,16(sp)
    80003f78:	0880                	addi	s0,sp,80
    80003f7a:	892e                	mv	s2,a1
    80003f7c:	8a2e                	mv	s4,a1
    80003f7e:	8ab2                	mv	s5,a2
    80003f80:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003f82:	fb040593          	addi	a1,s0,-80
    80003f86:	fcffe0ef          	jal	80002f54 <nameiparent>
    80003f8a:	84aa                	mv	s1,a0
    80003f8c:	10050763          	beqz	a0,8000409a <create+0x134>
    return 0;

  ilock(dp);
    80003f90:	8b5fe0ef          	jal	80002844 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003f94:	4601                	li	a2,0
    80003f96:	fb040593          	addi	a1,s0,-80
    80003f9a:	8526                	mv	a0,s1
    80003f9c:	d0bfe0ef          	jal	80002ca6 <dirlookup>
    80003fa0:	89aa                	mv	s3,a0
    80003fa2:	c131                	beqz	a0,80003fe6 <create+0x80>
    iunlockput(dp);
    80003fa4:	8526                	mv	a0,s1
    80003fa6:	aabfe0ef          	jal	80002a50 <iunlockput>
    ilock(ip);
    80003faa:	854e                	mv	a0,s3
    80003fac:	899fe0ef          	jal	80002844 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80003fb0:	4789                	li	a5,2
    80003fb2:	02f91563          	bne	s2,a5,80003fdc <create+0x76>
    80003fb6:	0449d783          	lhu	a5,68(s3)
    80003fba:	37f9                	addiw	a5,a5,-2
    80003fbc:	17c2                	slli	a5,a5,0x30
    80003fbe:	93c1                	srli	a5,a5,0x30
    80003fc0:	4705                	li	a4,1
    80003fc2:	00f76d63          	bltu	a4,a5,80003fdc <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80003fc6:	854e                	mv	a0,s3
    80003fc8:	60a6                	ld	ra,72(sp)
    80003fca:	6406                	ld	s0,64(sp)
    80003fcc:	74e2                	ld	s1,56(sp)
    80003fce:	7942                	ld	s2,48(sp)
    80003fd0:	79a2                	ld	s3,40(sp)
    80003fd2:	7a02                	ld	s4,32(sp)
    80003fd4:	6ae2                	ld	s5,24(sp)
    80003fd6:	6b42                	ld	s6,16(sp)
    80003fd8:	6161                	addi	sp,sp,80
    80003fda:	8082                	ret
    iunlockput(ip);
    80003fdc:	854e                	mv	a0,s3
    80003fde:	a73fe0ef          	jal	80002a50 <iunlockput>
    return 0;
    80003fe2:	4981                	li	s3,0
    80003fe4:	b7cd                	j	80003fc6 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80003fe6:	85ca                	mv	a1,s2
    80003fe8:	4088                	lw	a0,0(s1)
    80003fea:	eeafe0ef          	jal	800026d4 <ialloc>
    80003fee:	892a                	mv	s2,a0
    80003ff0:	cd15                	beqz	a0,8000402c <create+0xc6>
  ilock(ip);
    80003ff2:	853fe0ef          	jal	80002844 <ilock>
  ip->major = major;
    80003ff6:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80003ffa:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80003ffe:	4785                	li	a5,1
    80004000:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004004:	854a                	mv	a0,s2
    80004006:	f8afe0ef          	jal	80002790 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    8000400a:	4705                	li	a4,1
    8000400c:	02ea0463          	beq	s4,a4,80004034 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004010:	00492603          	lw	a2,4(s2)
    80004014:	fb040593          	addi	a1,s0,-80
    80004018:	8526                	mv	a0,s1
    8000401a:	e77fe0ef          	jal	80002e90 <dirlink>
    8000401e:	06054263          	bltz	a0,80004082 <create+0x11c>
  iunlockput(dp);
    80004022:	8526                	mv	a0,s1
    80004024:	a2dfe0ef          	jal	80002a50 <iunlockput>
  return ip;
    80004028:	89ca                	mv	s3,s2
    8000402a:	bf71                	j	80003fc6 <create+0x60>
    iunlockput(dp);
    8000402c:	8526                	mv	a0,s1
    8000402e:	a23fe0ef          	jal	80002a50 <iunlockput>
    return 0;
    80004032:	bf51                	j	80003fc6 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004034:	00492603          	lw	a2,4(s2)
    80004038:	00003597          	auipc	a1,0x3
    8000403c:	5c858593          	addi	a1,a1,1480 # 80007600 <etext+0x600>
    80004040:	854a                	mv	a0,s2
    80004042:	e4ffe0ef          	jal	80002e90 <dirlink>
    80004046:	02054e63          	bltz	a0,80004082 <create+0x11c>
    8000404a:	40d0                	lw	a2,4(s1)
    8000404c:	00003597          	auipc	a1,0x3
    80004050:	5bc58593          	addi	a1,a1,1468 # 80007608 <etext+0x608>
    80004054:	854a                	mv	a0,s2
    80004056:	e3bfe0ef          	jal	80002e90 <dirlink>
    8000405a:	02054463          	bltz	a0,80004082 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    8000405e:	00492603          	lw	a2,4(s2)
    80004062:	fb040593          	addi	a1,s0,-80
    80004066:	8526                	mv	a0,s1
    80004068:	e29fe0ef          	jal	80002e90 <dirlink>
    8000406c:	00054b63          	bltz	a0,80004082 <create+0x11c>
    dp->nlink++;  // for ".."
    80004070:	04a4d783          	lhu	a5,74(s1)
    80004074:	2785                	addiw	a5,a5,1
    80004076:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000407a:	8526                	mv	a0,s1
    8000407c:	f14fe0ef          	jal	80002790 <iupdate>
    80004080:	b74d                	j	80004022 <create+0xbc>
  ip->nlink = 0;
    80004082:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80004086:	854a                	mv	a0,s2
    80004088:	f08fe0ef          	jal	80002790 <iupdate>
  iunlockput(ip);
    8000408c:	854a                	mv	a0,s2
    8000408e:	9c3fe0ef          	jal	80002a50 <iunlockput>
  iunlockput(dp);
    80004092:	8526                	mv	a0,s1
    80004094:	9bdfe0ef          	jal	80002a50 <iunlockput>
  return 0;
    80004098:	b73d                	j	80003fc6 <create+0x60>
    return 0;
    8000409a:	89aa                	mv	s3,a0
    8000409c:	b72d                	j	80003fc6 <create+0x60>

000000008000409e <sys_dup>:
{
    8000409e:	7179                	addi	sp,sp,-48
    800040a0:	f406                	sd	ra,40(sp)
    800040a2:	f022                	sd	s0,32(sp)
    800040a4:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    800040a6:	fd840613          	addi	a2,s0,-40
    800040aa:	4581                	li	a1,0
    800040ac:	4501                	li	a0,0
    800040ae:	e1fff0ef          	jal	80003ecc <argfd>
    return -1;
    800040b2:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    800040b4:	02054363          	bltz	a0,800040da <sys_dup+0x3c>
    800040b8:	ec26                	sd	s1,24(sp)
    800040ba:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    800040bc:	fd843483          	ld	s1,-40(s0)
    800040c0:	8526                	mv	a0,s1
    800040c2:	e65ff0ef          	jal	80003f26 <fdalloc>
    800040c6:	892a                	mv	s2,a0
    return -1;
    800040c8:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    800040ca:	00054d63          	bltz	a0,800040e4 <sys_dup+0x46>
  filedup(f);
    800040ce:	8526                	mv	a0,s1
    800040d0:	c18ff0ef          	jal	800034e8 <filedup>
  return fd;
    800040d4:	87ca                	mv	a5,s2
    800040d6:	64e2                	ld	s1,24(sp)
    800040d8:	6942                	ld	s2,16(sp)
}
    800040da:	853e                	mv	a0,a5
    800040dc:	70a2                	ld	ra,40(sp)
    800040de:	7402                	ld	s0,32(sp)
    800040e0:	6145                	addi	sp,sp,48
    800040e2:	8082                	ret
    800040e4:	64e2                	ld	s1,24(sp)
    800040e6:	6942                	ld	s2,16(sp)
    800040e8:	bfcd                	j	800040da <sys_dup+0x3c>

00000000800040ea <sys_read>:
{
    800040ea:	7179                	addi	sp,sp,-48
    800040ec:	f406                	sd	ra,40(sp)
    800040ee:	f022                	sd	s0,32(sp)
    800040f0:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800040f2:	fd840593          	addi	a1,s0,-40
    800040f6:	4505                	li	a0,1
    800040f8:	d1ffd0ef          	jal	80001e16 <argaddr>
  argint(2, &n);
    800040fc:	fe440593          	addi	a1,s0,-28
    80004100:	4509                	li	a0,2
    80004102:	cf9fd0ef          	jal	80001dfa <argint>
  if(argfd(0, 0, &f) < 0)
    80004106:	fe840613          	addi	a2,s0,-24
    8000410a:	4581                	li	a1,0
    8000410c:	4501                	li	a0,0
    8000410e:	dbfff0ef          	jal	80003ecc <argfd>
    80004112:	87aa                	mv	a5,a0
    return -1;
    80004114:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004116:	0007ca63          	bltz	a5,8000412a <sys_read+0x40>
  return fileread(f, p, n);
    8000411a:	fe442603          	lw	a2,-28(s0)
    8000411e:	fd843583          	ld	a1,-40(s0)
    80004122:	fe843503          	ld	a0,-24(s0)
    80004126:	d2cff0ef          	jal	80003652 <fileread>
}
    8000412a:	70a2                	ld	ra,40(sp)
    8000412c:	7402                	ld	s0,32(sp)
    8000412e:	6145                	addi	sp,sp,48
    80004130:	8082                	ret

0000000080004132 <sys_write>:
{
    80004132:	7179                	addi	sp,sp,-48
    80004134:	f406                	sd	ra,40(sp)
    80004136:	f022                	sd	s0,32(sp)
    80004138:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000413a:	fd840593          	addi	a1,s0,-40
    8000413e:	4505                	li	a0,1
    80004140:	cd7fd0ef          	jal	80001e16 <argaddr>
  argint(2, &n);
    80004144:	fe440593          	addi	a1,s0,-28
    80004148:	4509                	li	a0,2
    8000414a:	cb1fd0ef          	jal	80001dfa <argint>
  if(argfd(0, 0, &f) < 0)
    8000414e:	fe840613          	addi	a2,s0,-24
    80004152:	4581                	li	a1,0
    80004154:	4501                	li	a0,0
    80004156:	d77ff0ef          	jal	80003ecc <argfd>
    8000415a:	87aa                	mv	a5,a0
    return -1;
    8000415c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000415e:	0007ca63          	bltz	a5,80004172 <sys_write+0x40>
  return filewrite(f, p, n);
    80004162:	fe442603          	lw	a2,-28(s0)
    80004166:	fd843583          	ld	a1,-40(s0)
    8000416a:	fe843503          	ld	a0,-24(s0)
    8000416e:	da8ff0ef          	jal	80003716 <filewrite>
}
    80004172:	70a2                	ld	ra,40(sp)
    80004174:	7402                	ld	s0,32(sp)
    80004176:	6145                	addi	sp,sp,48
    80004178:	8082                	ret

000000008000417a <sys_close>:
{
    8000417a:	1101                	addi	sp,sp,-32
    8000417c:	ec06                	sd	ra,24(sp)
    8000417e:	e822                	sd	s0,16(sp)
    80004180:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004182:	fe040613          	addi	a2,s0,-32
    80004186:	fec40593          	addi	a1,s0,-20
    8000418a:	4501                	li	a0,0
    8000418c:	d41ff0ef          	jal	80003ecc <argfd>
    return -1;
    80004190:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004192:	02054163          	bltz	a0,800041b4 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80004196:	d21fc0ef          	jal	80000eb6 <myproc>
    8000419a:	fec42783          	lw	a5,-20(s0)
    8000419e:	078e                	slli	a5,a5,0x3
    800041a0:	0d078793          	addi	a5,a5,208
    800041a4:	953e                	add	a0,a0,a5
    800041a6:	00053423          	sd	zero,8(a0)
  fileclose(f);
    800041aa:	fe043503          	ld	a0,-32(s0)
    800041ae:	b80ff0ef          	jal	8000352e <fileclose>
  return 0;
    800041b2:	4781                	li	a5,0
}
    800041b4:	853e                	mv	a0,a5
    800041b6:	60e2                	ld	ra,24(sp)
    800041b8:	6442                	ld	s0,16(sp)
    800041ba:	6105                	addi	sp,sp,32
    800041bc:	8082                	ret

00000000800041be <sys_fstat>:
{
    800041be:	1101                	addi	sp,sp,-32
    800041c0:	ec06                	sd	ra,24(sp)
    800041c2:	e822                	sd	s0,16(sp)
    800041c4:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    800041c6:	fe040593          	addi	a1,s0,-32
    800041ca:	4505                	li	a0,1
    800041cc:	c4bfd0ef          	jal	80001e16 <argaddr>
  if(argfd(0, 0, &f) < 0)
    800041d0:	fe840613          	addi	a2,s0,-24
    800041d4:	4581                	li	a1,0
    800041d6:	4501                	li	a0,0
    800041d8:	cf5ff0ef          	jal	80003ecc <argfd>
    800041dc:	87aa                	mv	a5,a0
    return -1;
    800041de:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800041e0:	0007c863          	bltz	a5,800041f0 <sys_fstat+0x32>
  return filestat(f, st);
    800041e4:	fe043583          	ld	a1,-32(s0)
    800041e8:	fe843503          	ld	a0,-24(s0)
    800041ec:	c04ff0ef          	jal	800035f0 <filestat>
}
    800041f0:	60e2                	ld	ra,24(sp)
    800041f2:	6442                	ld	s0,16(sp)
    800041f4:	6105                	addi	sp,sp,32
    800041f6:	8082                	ret

00000000800041f8 <sys_link>:
{
    800041f8:	7169                	addi	sp,sp,-304
    800041fa:	f606                	sd	ra,296(sp)
    800041fc:	f222                	sd	s0,288(sp)
    800041fe:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004200:	08000613          	li	a2,128
    80004204:	ed040593          	addi	a1,s0,-304
    80004208:	4501                	li	a0,0
    8000420a:	c29fd0ef          	jal	80001e32 <argstr>
    return -1;
    8000420e:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004210:	0c054e63          	bltz	a0,800042ec <sys_link+0xf4>
    80004214:	08000613          	li	a2,128
    80004218:	f5040593          	addi	a1,s0,-176
    8000421c:	4505                	li	a0,1
    8000421e:	c15fd0ef          	jal	80001e32 <argstr>
    return -1;
    80004222:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004224:	0c054463          	bltz	a0,800042ec <sys_link+0xf4>
    80004228:	ee26                	sd	s1,280(sp)
  begin_op();
    8000422a:	ed3fe0ef          	jal	800030fc <begin_op>
  if((ip = namei(old)) == 0){
    8000422e:	ed040513          	addi	a0,s0,-304
    80004232:	d09fe0ef          	jal	80002f3a <namei>
    80004236:	84aa                	mv	s1,a0
    80004238:	c53d                	beqz	a0,800042a6 <sys_link+0xae>
  ilock(ip);
    8000423a:	e0afe0ef          	jal	80002844 <ilock>
  if(ip->type == T_DIR){
    8000423e:	04449703          	lh	a4,68(s1)
    80004242:	4785                	li	a5,1
    80004244:	06f70663          	beq	a4,a5,800042b0 <sys_link+0xb8>
    80004248:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    8000424a:	04a4d783          	lhu	a5,74(s1)
    8000424e:	2785                	addiw	a5,a5,1
    80004250:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004254:	8526                	mv	a0,s1
    80004256:	d3afe0ef          	jal	80002790 <iupdate>
  iunlock(ip);
    8000425a:	8526                	mv	a0,s1
    8000425c:	e96fe0ef          	jal	800028f2 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004260:	fd040593          	addi	a1,s0,-48
    80004264:	f5040513          	addi	a0,s0,-176
    80004268:	cedfe0ef          	jal	80002f54 <nameiparent>
    8000426c:	892a                	mv	s2,a0
    8000426e:	cd21                	beqz	a0,800042c6 <sys_link+0xce>
  ilock(dp);
    80004270:	dd4fe0ef          	jal	80002844 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004274:	854a                	mv	a0,s2
    80004276:	00092703          	lw	a4,0(s2)
    8000427a:	409c                	lw	a5,0(s1)
    8000427c:	04f71263          	bne	a4,a5,800042c0 <sys_link+0xc8>
    80004280:	40d0                	lw	a2,4(s1)
    80004282:	fd040593          	addi	a1,s0,-48
    80004286:	c0bfe0ef          	jal	80002e90 <dirlink>
    8000428a:	02054b63          	bltz	a0,800042c0 <sys_link+0xc8>
  iunlockput(dp);
    8000428e:	854a                	mv	a0,s2
    80004290:	fc0fe0ef          	jal	80002a50 <iunlockput>
  iput(ip);
    80004294:	8526                	mv	a0,s1
    80004296:	f30fe0ef          	jal	800029c6 <iput>
  end_op();
    8000429a:	ed3fe0ef          	jal	8000316c <end_op>
  return 0;
    8000429e:	4781                	li	a5,0
    800042a0:	64f2                	ld	s1,280(sp)
    800042a2:	6952                	ld	s2,272(sp)
    800042a4:	a0a1                	j	800042ec <sys_link+0xf4>
    end_op();
    800042a6:	ec7fe0ef          	jal	8000316c <end_op>
    return -1;
    800042aa:	57fd                	li	a5,-1
    800042ac:	64f2                	ld	s1,280(sp)
    800042ae:	a83d                	j	800042ec <sys_link+0xf4>
    iunlockput(ip);
    800042b0:	8526                	mv	a0,s1
    800042b2:	f9efe0ef          	jal	80002a50 <iunlockput>
    end_op();
    800042b6:	eb7fe0ef          	jal	8000316c <end_op>
    return -1;
    800042ba:	57fd                	li	a5,-1
    800042bc:	64f2                	ld	s1,280(sp)
    800042be:	a03d                	j	800042ec <sys_link+0xf4>
    iunlockput(dp);
    800042c0:	854a                	mv	a0,s2
    800042c2:	f8efe0ef          	jal	80002a50 <iunlockput>
  ilock(ip);
    800042c6:	8526                	mv	a0,s1
    800042c8:	d7cfe0ef          	jal	80002844 <ilock>
  ip->nlink--;
    800042cc:	04a4d783          	lhu	a5,74(s1)
    800042d0:	37fd                	addiw	a5,a5,-1
    800042d2:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800042d6:	8526                	mv	a0,s1
    800042d8:	cb8fe0ef          	jal	80002790 <iupdate>
  iunlockput(ip);
    800042dc:	8526                	mv	a0,s1
    800042de:	f72fe0ef          	jal	80002a50 <iunlockput>
  end_op();
    800042e2:	e8bfe0ef          	jal	8000316c <end_op>
  return -1;
    800042e6:	57fd                	li	a5,-1
    800042e8:	64f2                	ld	s1,280(sp)
    800042ea:	6952                	ld	s2,272(sp)
}
    800042ec:	853e                	mv	a0,a5
    800042ee:	70b2                	ld	ra,296(sp)
    800042f0:	7412                	ld	s0,288(sp)
    800042f2:	6155                	addi	sp,sp,304
    800042f4:	8082                	ret

00000000800042f6 <sys_unlink>:
{
    800042f6:	7151                	addi	sp,sp,-240
    800042f8:	f586                	sd	ra,232(sp)
    800042fa:	f1a2                	sd	s0,224(sp)
    800042fc:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    800042fe:	08000613          	li	a2,128
    80004302:	f3040593          	addi	a1,s0,-208
    80004306:	4501                	li	a0,0
    80004308:	b2bfd0ef          	jal	80001e32 <argstr>
    8000430c:	14054d63          	bltz	a0,80004466 <sys_unlink+0x170>
    80004310:	eda6                	sd	s1,216(sp)
  begin_op();
    80004312:	debfe0ef          	jal	800030fc <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004316:	fb040593          	addi	a1,s0,-80
    8000431a:	f3040513          	addi	a0,s0,-208
    8000431e:	c37fe0ef          	jal	80002f54 <nameiparent>
    80004322:	84aa                	mv	s1,a0
    80004324:	c955                	beqz	a0,800043d8 <sys_unlink+0xe2>
  ilock(dp);
    80004326:	d1efe0ef          	jal	80002844 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000432a:	00003597          	auipc	a1,0x3
    8000432e:	2d658593          	addi	a1,a1,726 # 80007600 <etext+0x600>
    80004332:	fb040513          	addi	a0,s0,-80
    80004336:	95bfe0ef          	jal	80002c90 <namecmp>
    8000433a:	10050b63          	beqz	a0,80004450 <sys_unlink+0x15a>
    8000433e:	00003597          	auipc	a1,0x3
    80004342:	2ca58593          	addi	a1,a1,714 # 80007608 <etext+0x608>
    80004346:	fb040513          	addi	a0,s0,-80
    8000434a:	947fe0ef          	jal	80002c90 <namecmp>
    8000434e:	10050163          	beqz	a0,80004450 <sys_unlink+0x15a>
    80004352:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004354:	f2c40613          	addi	a2,s0,-212
    80004358:	fb040593          	addi	a1,s0,-80
    8000435c:	8526                	mv	a0,s1
    8000435e:	949fe0ef          	jal	80002ca6 <dirlookup>
    80004362:	892a                	mv	s2,a0
    80004364:	0e050563          	beqz	a0,8000444e <sys_unlink+0x158>
    80004368:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    8000436a:	cdafe0ef          	jal	80002844 <ilock>
  if(ip->nlink < 1)
    8000436e:	04a91783          	lh	a5,74(s2)
    80004372:	06f05863          	blez	a5,800043e2 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004376:	04491703          	lh	a4,68(s2)
    8000437a:	4785                	li	a5,1
    8000437c:	06f70963          	beq	a4,a5,800043ee <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80004380:	fc040993          	addi	s3,s0,-64
    80004384:	4641                	li	a2,16
    80004386:	4581                	li	a1,0
    80004388:	854e                	mv	a0,s3
    8000438a:	dd5fb0ef          	jal	8000015e <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000438e:	4741                	li	a4,16
    80004390:	f2c42683          	lw	a3,-212(s0)
    80004394:	864e                	mv	a2,s3
    80004396:	4581                	li	a1,0
    80004398:	8526                	mv	a0,s1
    8000439a:	ff6fe0ef          	jal	80002b90 <writei>
    8000439e:	47c1                	li	a5,16
    800043a0:	08f51863          	bne	a0,a5,80004430 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    800043a4:	04491703          	lh	a4,68(s2)
    800043a8:	4785                	li	a5,1
    800043aa:	08f70963          	beq	a4,a5,8000443c <sys_unlink+0x146>
  iunlockput(dp);
    800043ae:	8526                	mv	a0,s1
    800043b0:	ea0fe0ef          	jal	80002a50 <iunlockput>
  ip->nlink--;
    800043b4:	04a95783          	lhu	a5,74(s2)
    800043b8:	37fd                	addiw	a5,a5,-1
    800043ba:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800043be:	854a                	mv	a0,s2
    800043c0:	bd0fe0ef          	jal	80002790 <iupdate>
  iunlockput(ip);
    800043c4:	854a                	mv	a0,s2
    800043c6:	e8afe0ef          	jal	80002a50 <iunlockput>
  end_op();
    800043ca:	da3fe0ef          	jal	8000316c <end_op>
  return 0;
    800043ce:	4501                	li	a0,0
    800043d0:	64ee                	ld	s1,216(sp)
    800043d2:	694e                	ld	s2,208(sp)
    800043d4:	69ae                	ld	s3,200(sp)
    800043d6:	a061                	j	8000445e <sys_unlink+0x168>
    end_op();
    800043d8:	d95fe0ef          	jal	8000316c <end_op>
    return -1;
    800043dc:	557d                	li	a0,-1
    800043de:	64ee                	ld	s1,216(sp)
    800043e0:	a8bd                	j	8000445e <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    800043e2:	00003517          	auipc	a0,0x3
    800043e6:	22e50513          	addi	a0,a0,558 # 80007610 <etext+0x610>
    800043ea:	2b4010ef          	jal	8000569e <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800043ee:	04c92703          	lw	a4,76(s2)
    800043f2:	02000793          	li	a5,32
    800043f6:	f8e7f5e3          	bgeu	a5,a4,80004380 <sys_unlink+0x8a>
    800043fa:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800043fc:	4741                	li	a4,16
    800043fe:	86ce                	mv	a3,s3
    80004400:	f1840613          	addi	a2,s0,-232
    80004404:	4581                	li	a1,0
    80004406:	854a                	mv	a0,s2
    80004408:	e96fe0ef          	jal	80002a9e <readi>
    8000440c:	47c1                	li	a5,16
    8000440e:	00f51b63          	bne	a0,a5,80004424 <sys_unlink+0x12e>
    if(de.inum != 0)
    80004412:	f1845783          	lhu	a5,-232(s0)
    80004416:	ebb1                	bnez	a5,8000446a <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004418:	29c1                	addiw	s3,s3,16
    8000441a:	04c92783          	lw	a5,76(s2)
    8000441e:	fcf9efe3          	bltu	s3,a5,800043fc <sys_unlink+0x106>
    80004422:	bfb9                	j	80004380 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004424:	00003517          	auipc	a0,0x3
    80004428:	20450513          	addi	a0,a0,516 # 80007628 <etext+0x628>
    8000442c:	272010ef          	jal	8000569e <panic>
    panic("unlink: writei");
    80004430:	00003517          	auipc	a0,0x3
    80004434:	21050513          	addi	a0,a0,528 # 80007640 <etext+0x640>
    80004438:	266010ef          	jal	8000569e <panic>
    dp->nlink--;
    8000443c:	04a4d783          	lhu	a5,74(s1)
    80004440:	37fd                	addiw	a5,a5,-1
    80004442:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004446:	8526                	mv	a0,s1
    80004448:	b48fe0ef          	jal	80002790 <iupdate>
    8000444c:	b78d                	j	800043ae <sys_unlink+0xb8>
    8000444e:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004450:	8526                	mv	a0,s1
    80004452:	dfefe0ef          	jal	80002a50 <iunlockput>
  end_op();
    80004456:	d17fe0ef          	jal	8000316c <end_op>
  return -1;
    8000445a:	557d                	li	a0,-1
    8000445c:	64ee                	ld	s1,216(sp)
}
    8000445e:	70ae                	ld	ra,232(sp)
    80004460:	740e                	ld	s0,224(sp)
    80004462:	616d                	addi	sp,sp,240
    80004464:	8082                	ret
    return -1;
    80004466:	557d                	li	a0,-1
    80004468:	bfdd                	j	8000445e <sys_unlink+0x168>
    iunlockput(ip);
    8000446a:	854a                	mv	a0,s2
    8000446c:	de4fe0ef          	jal	80002a50 <iunlockput>
    goto bad;
    80004470:	694e                	ld	s2,208(sp)
    80004472:	69ae                	ld	s3,200(sp)
    80004474:	bff1                	j	80004450 <sys_unlink+0x15a>

0000000080004476 <sys_open>:

uint64
sys_open(void)
{
    80004476:	7131                	addi	sp,sp,-192
    80004478:	fd06                	sd	ra,184(sp)
    8000447a:	f922                	sd	s0,176(sp)
    8000447c:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    8000447e:	f4c40593          	addi	a1,s0,-180
    80004482:	4505                	li	a0,1
    80004484:	977fd0ef          	jal	80001dfa <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004488:	08000613          	li	a2,128
    8000448c:	f5040593          	addi	a1,s0,-176
    80004490:	4501                	li	a0,0
    80004492:	9a1fd0ef          	jal	80001e32 <argstr>
    80004496:	87aa                	mv	a5,a0
    return -1;
    80004498:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000449a:	0a07c363          	bltz	a5,80004540 <sys_open+0xca>
    8000449e:	f526                	sd	s1,168(sp)

  begin_op();
    800044a0:	c5dfe0ef          	jal	800030fc <begin_op>

  if(omode & O_CREATE){
    800044a4:	f4c42783          	lw	a5,-180(s0)
    800044a8:	2007f793          	andi	a5,a5,512
    800044ac:	c3dd                	beqz	a5,80004552 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    800044ae:	4681                	li	a3,0
    800044b0:	4601                	li	a2,0
    800044b2:	4589                	li	a1,2
    800044b4:	f5040513          	addi	a0,s0,-176
    800044b8:	aafff0ef          	jal	80003f66 <create>
    800044bc:	84aa                	mv	s1,a0
    if(ip == 0){
    800044be:	c549                	beqz	a0,80004548 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800044c0:	04449703          	lh	a4,68(s1)
    800044c4:	478d                	li	a5,3
    800044c6:	00f71763          	bne	a4,a5,800044d4 <sys_open+0x5e>
    800044ca:	0464d703          	lhu	a4,70(s1)
    800044ce:	47a5                	li	a5,9
    800044d0:	0ae7ee63          	bltu	a5,a4,8000458c <sys_open+0x116>
    800044d4:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    800044d6:	fb5fe0ef          	jal	8000348a <filealloc>
    800044da:	892a                	mv	s2,a0
    800044dc:	c561                	beqz	a0,800045a4 <sys_open+0x12e>
    800044de:	ed4e                	sd	s3,152(sp)
    800044e0:	a47ff0ef          	jal	80003f26 <fdalloc>
    800044e4:	89aa                	mv	s3,a0
    800044e6:	0a054b63          	bltz	a0,8000459c <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    800044ea:	04449703          	lh	a4,68(s1)
    800044ee:	478d                	li	a5,3
    800044f0:	0cf70363          	beq	a4,a5,800045b6 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    800044f4:	4789                	li	a5,2
    800044f6:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800044fa:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800044fe:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004502:	f4c42783          	lw	a5,-180(s0)
    80004506:	0017f713          	andi	a4,a5,1
    8000450a:	00174713          	xori	a4,a4,1
    8000450e:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004512:	0037f713          	andi	a4,a5,3
    80004516:	00e03733          	snez	a4,a4
    8000451a:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000451e:	4007f793          	andi	a5,a5,1024
    80004522:	c791                	beqz	a5,8000452e <sys_open+0xb8>
    80004524:	04449703          	lh	a4,68(s1)
    80004528:	4789                	li	a5,2
    8000452a:	08f70d63          	beq	a4,a5,800045c4 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    8000452e:	8526                	mv	a0,s1
    80004530:	bc2fe0ef          	jal	800028f2 <iunlock>
  end_op();
    80004534:	c39fe0ef          	jal	8000316c <end_op>

  return fd;
    80004538:	854e                	mv	a0,s3
    8000453a:	74aa                	ld	s1,168(sp)
    8000453c:	790a                	ld	s2,160(sp)
    8000453e:	69ea                	ld	s3,152(sp)
}
    80004540:	70ea                	ld	ra,184(sp)
    80004542:	744a                	ld	s0,176(sp)
    80004544:	6129                	addi	sp,sp,192
    80004546:	8082                	ret
      end_op();
    80004548:	c25fe0ef          	jal	8000316c <end_op>
      return -1;
    8000454c:	557d                	li	a0,-1
    8000454e:	74aa                	ld	s1,168(sp)
    80004550:	bfc5                	j	80004540 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    80004552:	f5040513          	addi	a0,s0,-176
    80004556:	9e5fe0ef          	jal	80002f3a <namei>
    8000455a:	84aa                	mv	s1,a0
    8000455c:	c11d                	beqz	a0,80004582 <sys_open+0x10c>
    ilock(ip);
    8000455e:	ae6fe0ef          	jal	80002844 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004562:	04449703          	lh	a4,68(s1)
    80004566:	4785                	li	a5,1
    80004568:	f4f71ce3          	bne	a4,a5,800044c0 <sys_open+0x4a>
    8000456c:	f4c42783          	lw	a5,-180(s0)
    80004570:	d3b5                	beqz	a5,800044d4 <sys_open+0x5e>
      iunlockput(ip);
    80004572:	8526                	mv	a0,s1
    80004574:	cdcfe0ef          	jal	80002a50 <iunlockput>
      end_op();
    80004578:	bf5fe0ef          	jal	8000316c <end_op>
      return -1;
    8000457c:	557d                	li	a0,-1
    8000457e:	74aa                	ld	s1,168(sp)
    80004580:	b7c1                	j	80004540 <sys_open+0xca>
      end_op();
    80004582:	bebfe0ef          	jal	8000316c <end_op>
      return -1;
    80004586:	557d                	li	a0,-1
    80004588:	74aa                	ld	s1,168(sp)
    8000458a:	bf5d                	j	80004540 <sys_open+0xca>
    iunlockput(ip);
    8000458c:	8526                	mv	a0,s1
    8000458e:	cc2fe0ef          	jal	80002a50 <iunlockput>
    end_op();
    80004592:	bdbfe0ef          	jal	8000316c <end_op>
    return -1;
    80004596:	557d                	li	a0,-1
    80004598:	74aa                	ld	s1,168(sp)
    8000459a:	b75d                	j	80004540 <sys_open+0xca>
      fileclose(f);
    8000459c:	854a                	mv	a0,s2
    8000459e:	f91fe0ef          	jal	8000352e <fileclose>
    800045a2:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    800045a4:	8526                	mv	a0,s1
    800045a6:	caafe0ef          	jal	80002a50 <iunlockput>
    end_op();
    800045aa:	bc3fe0ef          	jal	8000316c <end_op>
    return -1;
    800045ae:	557d                	li	a0,-1
    800045b0:	74aa                	ld	s1,168(sp)
    800045b2:	790a                	ld	s2,160(sp)
    800045b4:	b771                	j	80004540 <sys_open+0xca>
    f->type = FD_DEVICE;
    800045b6:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800045ba:	04649783          	lh	a5,70(s1)
    800045be:	02f91223          	sh	a5,36(s2)
    800045c2:	bf35                	j	800044fe <sys_open+0x88>
    itrunc(ip);
    800045c4:	8526                	mv	a0,s1
    800045c6:	b6cfe0ef          	jal	80002932 <itrunc>
    800045ca:	b795                	j	8000452e <sys_open+0xb8>

00000000800045cc <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800045cc:	7175                	addi	sp,sp,-144
    800045ce:	e506                	sd	ra,136(sp)
    800045d0:	e122                	sd	s0,128(sp)
    800045d2:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800045d4:	b29fe0ef          	jal	800030fc <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800045d8:	08000613          	li	a2,128
    800045dc:	f7040593          	addi	a1,s0,-144
    800045e0:	4501                	li	a0,0
    800045e2:	851fd0ef          	jal	80001e32 <argstr>
    800045e6:	02054363          	bltz	a0,8000460c <sys_mkdir+0x40>
    800045ea:	4681                	li	a3,0
    800045ec:	4601                	li	a2,0
    800045ee:	4585                	li	a1,1
    800045f0:	f7040513          	addi	a0,s0,-144
    800045f4:	973ff0ef          	jal	80003f66 <create>
    800045f8:	c911                	beqz	a0,8000460c <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800045fa:	c56fe0ef          	jal	80002a50 <iunlockput>
  end_op();
    800045fe:	b6ffe0ef          	jal	8000316c <end_op>
  return 0;
    80004602:	4501                	li	a0,0
}
    80004604:	60aa                	ld	ra,136(sp)
    80004606:	640a                	ld	s0,128(sp)
    80004608:	6149                	addi	sp,sp,144
    8000460a:	8082                	ret
    end_op();
    8000460c:	b61fe0ef          	jal	8000316c <end_op>
    return -1;
    80004610:	557d                	li	a0,-1
    80004612:	bfcd                	j	80004604 <sys_mkdir+0x38>

0000000080004614 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004614:	7135                	addi	sp,sp,-160
    80004616:	ed06                	sd	ra,152(sp)
    80004618:	e922                	sd	s0,144(sp)
    8000461a:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000461c:	ae1fe0ef          	jal	800030fc <begin_op>
  argint(1, &major);
    80004620:	f6c40593          	addi	a1,s0,-148
    80004624:	4505                	li	a0,1
    80004626:	fd4fd0ef          	jal	80001dfa <argint>
  argint(2, &minor);
    8000462a:	f6840593          	addi	a1,s0,-152
    8000462e:	4509                	li	a0,2
    80004630:	fcafd0ef          	jal	80001dfa <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004634:	08000613          	li	a2,128
    80004638:	f7040593          	addi	a1,s0,-144
    8000463c:	4501                	li	a0,0
    8000463e:	ff4fd0ef          	jal	80001e32 <argstr>
    80004642:	02054563          	bltz	a0,8000466c <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004646:	f6841683          	lh	a3,-152(s0)
    8000464a:	f6c41603          	lh	a2,-148(s0)
    8000464e:	458d                	li	a1,3
    80004650:	f7040513          	addi	a0,s0,-144
    80004654:	913ff0ef          	jal	80003f66 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004658:	c911                	beqz	a0,8000466c <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000465a:	bf6fe0ef          	jal	80002a50 <iunlockput>
  end_op();
    8000465e:	b0ffe0ef          	jal	8000316c <end_op>
  return 0;
    80004662:	4501                	li	a0,0
}
    80004664:	60ea                	ld	ra,152(sp)
    80004666:	644a                	ld	s0,144(sp)
    80004668:	610d                	addi	sp,sp,160
    8000466a:	8082                	ret
    end_op();
    8000466c:	b01fe0ef          	jal	8000316c <end_op>
    return -1;
    80004670:	557d                	li	a0,-1
    80004672:	bfcd                	j	80004664 <sys_mknod+0x50>

0000000080004674 <sys_chdir>:

uint64
sys_chdir(void)
{
    80004674:	7135                	addi	sp,sp,-160
    80004676:	ed06                	sd	ra,152(sp)
    80004678:	e922                	sd	s0,144(sp)
    8000467a:	e14a                	sd	s2,128(sp)
    8000467c:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    8000467e:	839fc0ef          	jal	80000eb6 <myproc>
    80004682:	892a                	mv	s2,a0
  
  begin_op();
    80004684:	a79fe0ef          	jal	800030fc <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80004688:	08000613          	li	a2,128
    8000468c:	f6040593          	addi	a1,s0,-160
    80004690:	4501                	li	a0,0
    80004692:	fa0fd0ef          	jal	80001e32 <argstr>
    80004696:	04054363          	bltz	a0,800046dc <sys_chdir+0x68>
    8000469a:	e526                	sd	s1,136(sp)
    8000469c:	f6040513          	addi	a0,s0,-160
    800046a0:	89bfe0ef          	jal	80002f3a <namei>
    800046a4:	84aa                	mv	s1,a0
    800046a6:	c915                	beqz	a0,800046da <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800046a8:	99cfe0ef          	jal	80002844 <ilock>
  if(ip->type != T_DIR){
    800046ac:	04449703          	lh	a4,68(s1)
    800046b0:	4785                	li	a5,1
    800046b2:	02f71963          	bne	a4,a5,800046e4 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800046b6:	8526                	mv	a0,s1
    800046b8:	a3afe0ef          	jal	800028f2 <iunlock>
  iput(p->cwd);
    800046bc:	15893503          	ld	a0,344(s2)
    800046c0:	b06fe0ef          	jal	800029c6 <iput>
  end_op();
    800046c4:	aa9fe0ef          	jal	8000316c <end_op>
  p->cwd = ip;
    800046c8:	14993c23          	sd	s1,344(s2)
  return 0;
    800046cc:	4501                	li	a0,0
    800046ce:	64aa                	ld	s1,136(sp)
}
    800046d0:	60ea                	ld	ra,152(sp)
    800046d2:	644a                	ld	s0,144(sp)
    800046d4:	690a                	ld	s2,128(sp)
    800046d6:	610d                	addi	sp,sp,160
    800046d8:	8082                	ret
    800046da:	64aa                	ld	s1,136(sp)
    end_op();
    800046dc:	a91fe0ef          	jal	8000316c <end_op>
    return -1;
    800046e0:	557d                	li	a0,-1
    800046e2:	b7fd                	j	800046d0 <sys_chdir+0x5c>
    iunlockput(ip);
    800046e4:	8526                	mv	a0,s1
    800046e6:	b6afe0ef          	jal	80002a50 <iunlockput>
    end_op();
    800046ea:	a83fe0ef          	jal	8000316c <end_op>
    return -1;
    800046ee:	557d                	li	a0,-1
    800046f0:	64aa                	ld	s1,136(sp)
    800046f2:	bff9                	j	800046d0 <sys_chdir+0x5c>

00000000800046f4 <sys_exec>:

uint64
sys_exec(void)
{
    800046f4:	7105                	addi	sp,sp,-480
    800046f6:	ef86                	sd	ra,472(sp)
    800046f8:	eba2                	sd	s0,464(sp)
    800046fa:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800046fc:	e2840593          	addi	a1,s0,-472
    80004700:	4505                	li	a0,1
    80004702:	f14fd0ef          	jal	80001e16 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80004706:	08000613          	li	a2,128
    8000470a:	f3040593          	addi	a1,s0,-208
    8000470e:	4501                	li	a0,0
    80004710:	f22fd0ef          	jal	80001e32 <argstr>
    80004714:	87aa                	mv	a5,a0
    return -1;
    80004716:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80004718:	0e07c063          	bltz	a5,800047f8 <sys_exec+0x104>
    8000471c:	e7a6                	sd	s1,456(sp)
    8000471e:	e3ca                	sd	s2,448(sp)
    80004720:	ff4e                	sd	s3,440(sp)
    80004722:	fb52                	sd	s4,432(sp)
    80004724:	f756                	sd	s5,424(sp)
    80004726:	f35a                	sd	s6,416(sp)
    80004728:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000472a:	e3040a13          	addi	s4,s0,-464
    8000472e:	10000613          	li	a2,256
    80004732:	4581                	li	a1,0
    80004734:	8552                	mv	a0,s4
    80004736:	a29fb0ef          	jal	8000015e <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    8000473a:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    8000473c:	89d2                	mv	s3,s4
    8000473e:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004740:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80004744:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    80004746:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000474a:	00391513          	slli	a0,s2,0x3
    8000474e:	85d6                	mv	a1,s5
    80004750:	e2843783          	ld	a5,-472(s0)
    80004754:	953e                	add	a0,a0,a5
    80004756:	e1afd0ef          	jal	80001d70 <fetchaddr>
    8000475a:	02054663          	bltz	a0,80004786 <sys_exec+0x92>
    if(uarg == 0){
    8000475e:	e2043783          	ld	a5,-480(s0)
    80004762:	c7a1                	beqz	a5,800047aa <sys_exec+0xb6>
    argv[i] = kalloc();
    80004764:	9a1fb0ef          	jal	80000104 <kalloc>
    80004768:	85aa                	mv	a1,a0
    8000476a:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000476e:	cd01                	beqz	a0,80004786 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80004770:	865a                	mv	a2,s6
    80004772:	e2043503          	ld	a0,-480(s0)
    80004776:	e44fd0ef          	jal	80001dba <fetchstr>
    8000477a:	00054663          	bltz	a0,80004786 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    8000477e:	0905                	addi	s2,s2,1
    80004780:	09a1                	addi	s3,s3,8
    80004782:	fd7914e3          	bne	s2,s7,8000474a <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004786:	100a0a13          	addi	s4,s4,256
    8000478a:	6088                	ld	a0,0(s1)
    8000478c:	cd31                	beqz	a0,800047e8 <sys_exec+0xf4>
    kfree(argv[i]);
    8000478e:	88ffb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004792:	04a1                	addi	s1,s1,8
    80004794:	ff449be3          	bne	s1,s4,8000478a <sys_exec+0x96>
  return -1;
    80004798:	557d                	li	a0,-1
    8000479a:	64be                	ld	s1,456(sp)
    8000479c:	691e                	ld	s2,448(sp)
    8000479e:	79fa                	ld	s3,440(sp)
    800047a0:	7a5a                	ld	s4,432(sp)
    800047a2:	7aba                	ld	s5,424(sp)
    800047a4:	7b1a                	ld	s6,416(sp)
    800047a6:	6bfa                	ld	s7,408(sp)
    800047a8:	a881                	j	800047f8 <sys_exec+0x104>
      argv[i] = 0;
    800047aa:	0009079b          	sext.w	a5,s2
    800047ae:	e3040593          	addi	a1,s0,-464
    800047b2:	078e                	slli	a5,a5,0x3
    800047b4:	97ae                	add	a5,a5,a1
    800047b6:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    800047ba:	f3040513          	addi	a0,s0,-208
    800047be:	bb2ff0ef          	jal	80003b70 <exec>
    800047c2:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800047c4:	100a0a13          	addi	s4,s4,256
    800047c8:	6088                	ld	a0,0(s1)
    800047ca:	c511                	beqz	a0,800047d6 <sys_exec+0xe2>
    kfree(argv[i]);
    800047cc:	851fb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800047d0:	04a1                	addi	s1,s1,8
    800047d2:	ff449be3          	bne	s1,s4,800047c8 <sys_exec+0xd4>
  return ret;
    800047d6:	854a                	mv	a0,s2
    800047d8:	64be                	ld	s1,456(sp)
    800047da:	691e                	ld	s2,448(sp)
    800047dc:	79fa                	ld	s3,440(sp)
    800047de:	7a5a                	ld	s4,432(sp)
    800047e0:	7aba                	ld	s5,424(sp)
    800047e2:	7b1a                	ld	s6,416(sp)
    800047e4:	6bfa                	ld	s7,408(sp)
    800047e6:	a809                	j	800047f8 <sys_exec+0x104>
  return -1;
    800047e8:	557d                	li	a0,-1
    800047ea:	64be                	ld	s1,456(sp)
    800047ec:	691e                	ld	s2,448(sp)
    800047ee:	79fa                	ld	s3,440(sp)
    800047f0:	7a5a                	ld	s4,432(sp)
    800047f2:	7aba                	ld	s5,424(sp)
    800047f4:	7b1a                	ld	s6,416(sp)
    800047f6:	6bfa                	ld	s7,408(sp)
}
    800047f8:	60fe                	ld	ra,472(sp)
    800047fa:	645e                	ld	s0,464(sp)
    800047fc:	613d                	addi	sp,sp,480
    800047fe:	8082                	ret

0000000080004800 <sys_pipe>:

uint64
sys_pipe(void)
{
    80004800:	7139                	addi	sp,sp,-64
    80004802:	fc06                	sd	ra,56(sp)
    80004804:	f822                	sd	s0,48(sp)
    80004806:	f426                	sd	s1,40(sp)
    80004808:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000480a:	eacfc0ef          	jal	80000eb6 <myproc>
    8000480e:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80004810:	fd840593          	addi	a1,s0,-40
    80004814:	4501                	li	a0,0
    80004816:	e00fd0ef          	jal	80001e16 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000481a:	fc840593          	addi	a1,s0,-56
    8000481e:	fd040513          	addi	a0,s0,-48
    80004822:	828ff0ef          	jal	8000384a <pipealloc>
    return -1;
    80004826:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80004828:	0a054763          	bltz	a0,800048d6 <sys_pipe+0xd6>
  fd0 = -1;
    8000482c:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80004830:	fd043503          	ld	a0,-48(s0)
    80004834:	ef2ff0ef          	jal	80003f26 <fdalloc>
    80004838:	fca42223          	sw	a0,-60(s0)
    8000483c:	08054463          	bltz	a0,800048c4 <sys_pipe+0xc4>
    80004840:	fc843503          	ld	a0,-56(s0)
    80004844:	ee2ff0ef          	jal	80003f26 <fdalloc>
    80004848:	fca42023          	sw	a0,-64(s0)
    8000484c:	06054263          	bltz	a0,800048b0 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004850:	4691                	li	a3,4
    80004852:	fc440613          	addi	a2,s0,-60
    80004856:	fd843583          	ld	a1,-40(s0)
    8000485a:	68a8                	ld	a0,80(s1)
    8000485c:	a9afc0ef          	jal	80000af6 <copyout>
    80004860:	00054e63          	bltz	a0,8000487c <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80004864:	4691                	li	a3,4
    80004866:	fc040613          	addi	a2,s0,-64
    8000486a:	fd843583          	ld	a1,-40(s0)
    8000486e:	95b6                	add	a1,a1,a3
    80004870:	68a8                	ld	a0,80(s1)
    80004872:	a84fc0ef          	jal	80000af6 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80004876:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004878:	04055f63          	bgez	a0,800048d6 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    8000487c:	fc442783          	lw	a5,-60(s0)
    80004880:	078e                	slli	a5,a5,0x3
    80004882:	0d078793          	addi	a5,a5,208
    80004886:	97a6                	add	a5,a5,s1
    80004888:	0007b423          	sd	zero,8(a5)
    p->ofile[fd1] = 0;
    8000488c:	fc042783          	lw	a5,-64(s0)
    80004890:	078e                	slli	a5,a5,0x3
    80004892:	0d078793          	addi	a5,a5,208
    80004896:	97a6                	add	a5,a5,s1
    80004898:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    8000489c:	fd043503          	ld	a0,-48(s0)
    800048a0:	c8ffe0ef          	jal	8000352e <fileclose>
    fileclose(wf);
    800048a4:	fc843503          	ld	a0,-56(s0)
    800048a8:	c87fe0ef          	jal	8000352e <fileclose>
    return -1;
    800048ac:	57fd                	li	a5,-1
    800048ae:	a025                	j	800048d6 <sys_pipe+0xd6>
    if(fd0 >= 0)
    800048b0:	fc442783          	lw	a5,-60(s0)
    800048b4:	0007c863          	bltz	a5,800048c4 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    800048b8:	078e                	slli	a5,a5,0x3
    800048ba:	0d078793          	addi	a5,a5,208
    800048be:	97a6                	add	a5,a5,s1
    800048c0:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    800048c4:	fd043503          	ld	a0,-48(s0)
    800048c8:	c67fe0ef          	jal	8000352e <fileclose>
    fileclose(wf);
    800048cc:	fc843503          	ld	a0,-56(s0)
    800048d0:	c5ffe0ef          	jal	8000352e <fileclose>
    return -1;
    800048d4:	57fd                	li	a5,-1
}
    800048d6:	853e                	mv	a0,a5
    800048d8:	70e2                	ld	ra,56(sp)
    800048da:	7442                	ld	s0,48(sp)
    800048dc:	74a2                	ld	s1,40(sp)
    800048de:	6121                	addi	sp,sp,64
    800048e0:	8082                	ret
	...

00000000800048f0 <kernelvec>:
    800048f0:	7111                	addi	sp,sp,-256
    800048f2:	e006                	sd	ra,0(sp)
    800048f4:	e40a                	sd	sp,8(sp)
    800048f6:	e80e                	sd	gp,16(sp)
    800048f8:	ec12                	sd	tp,24(sp)
    800048fa:	f016                	sd	t0,32(sp)
    800048fc:	f41a                	sd	t1,40(sp)
    800048fe:	f81e                	sd	t2,48(sp)
    80004900:	e4aa                	sd	a0,72(sp)
    80004902:	e8ae                	sd	a1,80(sp)
    80004904:	ecb2                	sd	a2,88(sp)
    80004906:	f0b6                	sd	a3,96(sp)
    80004908:	f4ba                	sd	a4,104(sp)
    8000490a:	f8be                	sd	a5,112(sp)
    8000490c:	fcc2                	sd	a6,120(sp)
    8000490e:	e146                	sd	a7,128(sp)
    80004910:	edf2                	sd	t3,216(sp)
    80004912:	f1f6                	sd	t4,224(sp)
    80004914:	f5fa                	sd	t5,232(sp)
    80004916:	f9fe                	sd	t6,240(sp)
    80004918:	b66fd0ef          	jal	80001c7e <kerneltrap>
    8000491c:	6082                	ld	ra,0(sp)
    8000491e:	6122                	ld	sp,8(sp)
    80004920:	61c2                	ld	gp,16(sp)
    80004922:	7282                	ld	t0,32(sp)
    80004924:	7322                	ld	t1,40(sp)
    80004926:	73c2                	ld	t2,48(sp)
    80004928:	6526                	ld	a0,72(sp)
    8000492a:	65c6                	ld	a1,80(sp)
    8000492c:	6666                	ld	a2,88(sp)
    8000492e:	7686                	ld	a3,96(sp)
    80004930:	7726                	ld	a4,104(sp)
    80004932:	77c6                	ld	a5,112(sp)
    80004934:	7866                	ld	a6,120(sp)
    80004936:	688a                	ld	a7,128(sp)
    80004938:	6e6e                	ld	t3,216(sp)
    8000493a:	7e8e                	ld	t4,224(sp)
    8000493c:	7f2e                	ld	t5,232(sp)
    8000493e:	7fce                	ld	t6,240(sp)
    80004940:	6111                	addi	sp,sp,256
    80004942:	10200073          	sret
    80004946:	00000013          	nop
    8000494a:	00000013          	nop

000000008000494e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000494e:	1141                	addi	sp,sp,-16
    80004950:	e406                	sd	ra,8(sp)
    80004952:	e022                	sd	s0,0(sp)
    80004954:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004956:	0c000737          	lui	a4,0xc000
    8000495a:	4785                	li	a5,1
    8000495c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000495e:	c35c                	sw	a5,4(a4)
}
    80004960:	60a2                	ld	ra,8(sp)
    80004962:	6402                	ld	s0,0(sp)
    80004964:	0141                	addi	sp,sp,16
    80004966:	8082                	ret

0000000080004968 <plicinithart>:

void
plicinithart(void)
{
    80004968:	1141                	addi	sp,sp,-16
    8000496a:	e406                	sd	ra,8(sp)
    8000496c:	e022                	sd	s0,0(sp)
    8000496e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004970:	d12fc0ef          	jal	80000e82 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80004974:	0085171b          	slliw	a4,a0,0x8
    80004978:	0c0027b7          	lui	a5,0xc002
    8000497c:	97ba                	add	a5,a5,a4
    8000497e:	40200713          	li	a4,1026
    80004982:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80004986:	00d5151b          	slliw	a0,a0,0xd
    8000498a:	0c2017b7          	lui	a5,0xc201
    8000498e:	97aa                	add	a5,a5,a0
    80004990:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80004994:	60a2                	ld	ra,8(sp)
    80004996:	6402                	ld	s0,0(sp)
    80004998:	0141                	addi	sp,sp,16
    8000499a:	8082                	ret

000000008000499c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000499c:	1141                	addi	sp,sp,-16
    8000499e:	e406                	sd	ra,8(sp)
    800049a0:	e022                	sd	s0,0(sp)
    800049a2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800049a4:	cdefc0ef          	jal	80000e82 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800049a8:	00d5151b          	slliw	a0,a0,0xd
    800049ac:	0c2017b7          	lui	a5,0xc201
    800049b0:	97aa                	add	a5,a5,a0
  return irq;
}
    800049b2:	43c8                	lw	a0,4(a5)
    800049b4:	60a2                	ld	ra,8(sp)
    800049b6:	6402                	ld	s0,0(sp)
    800049b8:	0141                	addi	sp,sp,16
    800049ba:	8082                	ret

00000000800049bc <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800049bc:	1101                	addi	sp,sp,-32
    800049be:	ec06                	sd	ra,24(sp)
    800049c0:	e822                	sd	s0,16(sp)
    800049c2:	e426                	sd	s1,8(sp)
    800049c4:	1000                	addi	s0,sp,32
    800049c6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800049c8:	cbafc0ef          	jal	80000e82 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800049cc:	00d5179b          	slliw	a5,a0,0xd
    800049d0:	0c201737          	lui	a4,0xc201
    800049d4:	97ba                	add	a5,a5,a4
    800049d6:	c3c4                	sw	s1,4(a5)
}
    800049d8:	60e2                	ld	ra,24(sp)
    800049da:	6442                	ld	s0,16(sp)
    800049dc:	64a2                	ld	s1,8(sp)
    800049de:	6105                	addi	sp,sp,32
    800049e0:	8082                	ret

00000000800049e2 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800049e2:	1141                	addi	sp,sp,-16
    800049e4:	e406                	sd	ra,8(sp)
    800049e6:	e022                	sd	s0,0(sp)
    800049e8:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800049ea:	479d                	li	a5,7
    800049ec:	04a7ca63          	blt	a5,a0,80004a40 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800049f0:	00014797          	auipc	a5,0x14
    800049f4:	2b078793          	addi	a5,a5,688 # 80018ca0 <disk>
    800049f8:	97aa                	add	a5,a5,a0
    800049fa:	0187c783          	lbu	a5,24(a5)
    800049fe:	e7b9                	bnez	a5,80004a4c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80004a00:	00451693          	slli	a3,a0,0x4
    80004a04:	00014797          	auipc	a5,0x14
    80004a08:	29c78793          	addi	a5,a5,668 # 80018ca0 <disk>
    80004a0c:	6398                	ld	a4,0(a5)
    80004a0e:	9736                	add	a4,a4,a3
    80004a10:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80004a14:	6398                	ld	a4,0(a5)
    80004a16:	9736                	add	a4,a4,a3
    80004a18:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80004a1c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80004a20:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004a24:	97aa                	add	a5,a5,a0
    80004a26:	4705                	li	a4,1
    80004a28:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80004a2c:	00014517          	auipc	a0,0x14
    80004a30:	28c50513          	addi	a0,a0,652 # 80018cb8 <disk+0x18>
    80004a34:	b25fc0ef          	jal	80001558 <wakeup>
}
    80004a38:	60a2                	ld	ra,8(sp)
    80004a3a:	6402                	ld	s0,0(sp)
    80004a3c:	0141                	addi	sp,sp,16
    80004a3e:	8082                	ret
    panic("free_desc 1");
    80004a40:	00003517          	auipc	a0,0x3
    80004a44:	c1050513          	addi	a0,a0,-1008 # 80007650 <etext+0x650>
    80004a48:	457000ef          	jal	8000569e <panic>
    panic("free_desc 2");
    80004a4c:	00003517          	auipc	a0,0x3
    80004a50:	c1450513          	addi	a0,a0,-1004 # 80007660 <etext+0x660>
    80004a54:	44b000ef          	jal	8000569e <panic>

0000000080004a58 <virtio_disk_init>:
{
    80004a58:	1101                	addi	sp,sp,-32
    80004a5a:	ec06                	sd	ra,24(sp)
    80004a5c:	e822                	sd	s0,16(sp)
    80004a5e:	e426                	sd	s1,8(sp)
    80004a60:	e04a                	sd	s2,0(sp)
    80004a62:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004a64:	00003597          	auipc	a1,0x3
    80004a68:	c0c58593          	addi	a1,a1,-1012 # 80007670 <etext+0x670>
    80004a6c:	00014517          	auipc	a0,0x14
    80004a70:	35c50513          	addi	a0,a0,860 # 80018dc8 <disk+0x128>
    80004a74:	6df000ef          	jal	80005952 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004a78:	100017b7          	lui	a5,0x10001
    80004a7c:	4398                	lw	a4,0(a5)
    80004a7e:	2701                	sext.w	a4,a4
    80004a80:	747277b7          	lui	a5,0x74727
    80004a84:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80004a88:	14f71863          	bne	a4,a5,80004bd8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004a8c:	100017b7          	lui	a5,0x10001
    80004a90:	43dc                	lw	a5,4(a5)
    80004a92:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004a94:	4709                	li	a4,2
    80004a96:	14e79163          	bne	a5,a4,80004bd8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004a9a:	100017b7          	lui	a5,0x10001
    80004a9e:	479c                	lw	a5,8(a5)
    80004aa0:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004aa2:	12e79b63          	bne	a5,a4,80004bd8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80004aa6:	100017b7          	lui	a5,0x10001
    80004aaa:	47d8                	lw	a4,12(a5)
    80004aac:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004aae:	554d47b7          	lui	a5,0x554d4
    80004ab2:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80004ab6:	12f71163          	bne	a4,a5,80004bd8 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004aba:	100017b7          	lui	a5,0x10001
    80004abe:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004ac2:	4705                	li	a4,1
    80004ac4:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004ac6:	470d                	li	a4,3
    80004ac8:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80004aca:	10001737          	lui	a4,0x10001
    80004ace:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80004ad0:	c7ffe6b7          	lui	a3,0xc7ffe
    80004ad4:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd87f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80004ad8:	8f75                	and	a4,a4,a3
    80004ada:	100016b7          	lui	a3,0x10001
    80004ade:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004ae0:	472d                	li	a4,11
    80004ae2:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004ae4:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80004ae8:	439c                	lw	a5,0(a5)
    80004aea:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80004aee:	8ba1                	andi	a5,a5,8
    80004af0:	0e078a63          	beqz	a5,80004be4 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80004af4:	100017b7          	lui	a5,0x10001
    80004af8:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80004afc:	43fc                	lw	a5,68(a5)
    80004afe:	2781                	sext.w	a5,a5
    80004b00:	0e079863          	bnez	a5,80004bf0 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80004b04:	100017b7          	lui	a5,0x10001
    80004b08:	5bdc                	lw	a5,52(a5)
    80004b0a:	2781                	sext.w	a5,a5
  if(max == 0)
    80004b0c:	0e078863          	beqz	a5,80004bfc <virtio_disk_init+0x1a4>
  if(max < NUM)
    80004b10:	471d                	li	a4,7
    80004b12:	0ef77b63          	bgeu	a4,a5,80004c08 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80004b16:	deefb0ef          	jal	80000104 <kalloc>
    80004b1a:	00014497          	auipc	s1,0x14
    80004b1e:	18648493          	addi	s1,s1,390 # 80018ca0 <disk>
    80004b22:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004b24:	de0fb0ef          	jal	80000104 <kalloc>
    80004b28:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004b2a:	ddafb0ef          	jal	80000104 <kalloc>
    80004b2e:	87aa                	mv	a5,a0
    80004b30:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004b32:	6088                	ld	a0,0(s1)
    80004b34:	0e050063          	beqz	a0,80004c14 <virtio_disk_init+0x1bc>
    80004b38:	00014717          	auipc	a4,0x14
    80004b3c:	17073703          	ld	a4,368(a4) # 80018ca8 <disk+0x8>
    80004b40:	cb71                	beqz	a4,80004c14 <virtio_disk_init+0x1bc>
    80004b42:	cbe9                	beqz	a5,80004c14 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80004b44:	6605                	lui	a2,0x1
    80004b46:	4581                	li	a1,0
    80004b48:	e16fb0ef          	jal	8000015e <memset>
  memset(disk.avail, 0, PGSIZE);
    80004b4c:	00014497          	auipc	s1,0x14
    80004b50:	15448493          	addi	s1,s1,340 # 80018ca0 <disk>
    80004b54:	6605                	lui	a2,0x1
    80004b56:	4581                	li	a1,0
    80004b58:	6488                	ld	a0,8(s1)
    80004b5a:	e04fb0ef          	jal	8000015e <memset>
  memset(disk.used, 0, PGSIZE);
    80004b5e:	6605                	lui	a2,0x1
    80004b60:	4581                	li	a1,0
    80004b62:	6888                	ld	a0,16(s1)
    80004b64:	dfafb0ef          	jal	8000015e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004b68:	100017b7          	lui	a5,0x10001
    80004b6c:	4721                	li	a4,8
    80004b6e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004b70:	4098                	lw	a4,0(s1)
    80004b72:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004b76:	40d8                	lw	a4,4(s1)
    80004b78:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80004b7c:	649c                	ld	a5,8(s1)
    80004b7e:	0007869b          	sext.w	a3,a5
    80004b82:	10001737          	lui	a4,0x10001
    80004b86:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80004b8a:	9781                	srai	a5,a5,0x20
    80004b8c:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80004b90:	689c                	ld	a5,16(s1)
    80004b92:	0007869b          	sext.w	a3,a5
    80004b96:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80004b9a:	9781                	srai	a5,a5,0x20
    80004b9c:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80004ba0:	4785                	li	a5,1
    80004ba2:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80004ba4:	00f48c23          	sb	a5,24(s1)
    80004ba8:	00f48ca3          	sb	a5,25(s1)
    80004bac:	00f48d23          	sb	a5,26(s1)
    80004bb0:	00f48da3          	sb	a5,27(s1)
    80004bb4:	00f48e23          	sb	a5,28(s1)
    80004bb8:	00f48ea3          	sb	a5,29(s1)
    80004bbc:	00f48f23          	sb	a5,30(s1)
    80004bc0:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80004bc4:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80004bc8:	07272823          	sw	s2,112(a4)
}
    80004bcc:	60e2                	ld	ra,24(sp)
    80004bce:	6442                	ld	s0,16(sp)
    80004bd0:	64a2                	ld	s1,8(sp)
    80004bd2:	6902                	ld	s2,0(sp)
    80004bd4:	6105                	addi	sp,sp,32
    80004bd6:	8082                	ret
    panic("could not find virtio disk");
    80004bd8:	00003517          	auipc	a0,0x3
    80004bdc:	aa850513          	addi	a0,a0,-1368 # 80007680 <etext+0x680>
    80004be0:	2bf000ef          	jal	8000569e <panic>
    panic("virtio disk FEATURES_OK unset");
    80004be4:	00003517          	auipc	a0,0x3
    80004be8:	abc50513          	addi	a0,a0,-1348 # 800076a0 <etext+0x6a0>
    80004bec:	2b3000ef          	jal	8000569e <panic>
    panic("virtio disk should not be ready");
    80004bf0:	00003517          	auipc	a0,0x3
    80004bf4:	ad050513          	addi	a0,a0,-1328 # 800076c0 <etext+0x6c0>
    80004bf8:	2a7000ef          	jal	8000569e <panic>
    panic("virtio disk has no queue 0");
    80004bfc:	00003517          	auipc	a0,0x3
    80004c00:	ae450513          	addi	a0,a0,-1308 # 800076e0 <etext+0x6e0>
    80004c04:	29b000ef          	jal	8000569e <panic>
    panic("virtio disk max queue too short");
    80004c08:	00003517          	auipc	a0,0x3
    80004c0c:	af850513          	addi	a0,a0,-1288 # 80007700 <etext+0x700>
    80004c10:	28f000ef          	jal	8000569e <panic>
    panic("virtio disk kalloc");
    80004c14:	00003517          	auipc	a0,0x3
    80004c18:	b0c50513          	addi	a0,a0,-1268 # 80007720 <etext+0x720>
    80004c1c:	283000ef          	jal	8000569e <panic>

0000000080004c20 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004c20:	711d                	addi	sp,sp,-96
    80004c22:	ec86                	sd	ra,88(sp)
    80004c24:	e8a2                	sd	s0,80(sp)
    80004c26:	e4a6                	sd	s1,72(sp)
    80004c28:	e0ca                	sd	s2,64(sp)
    80004c2a:	fc4e                	sd	s3,56(sp)
    80004c2c:	f852                	sd	s4,48(sp)
    80004c2e:	f456                	sd	s5,40(sp)
    80004c30:	f05a                	sd	s6,32(sp)
    80004c32:	ec5e                	sd	s7,24(sp)
    80004c34:	e862                	sd	s8,16(sp)
    80004c36:	1080                	addi	s0,sp,96
    80004c38:	89aa                	mv	s3,a0
    80004c3a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004c3c:	00c52b83          	lw	s7,12(a0)
    80004c40:	001b9b9b          	slliw	s7,s7,0x1
    80004c44:	1b82                	slli	s7,s7,0x20
    80004c46:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80004c4a:	00014517          	auipc	a0,0x14
    80004c4e:	17e50513          	addi	a0,a0,382 # 80018dc8 <disk+0x128>
    80004c52:	58b000ef          	jal	800059dc <acquire>
  for(int i = 0; i < NUM; i++){
    80004c56:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004c58:	00014a97          	auipc	s5,0x14
    80004c5c:	048a8a93          	addi	s5,s5,72 # 80018ca0 <disk>
  for(int i = 0; i < 3; i++){
    80004c60:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80004c62:	5c7d                	li	s8,-1
    80004c64:	a095                	j	80004cc8 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80004c66:	00fa8733          	add	a4,s5,a5
    80004c6a:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004c6e:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004c70:	0207c563          	bltz	a5,80004c9a <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80004c74:	2905                	addiw	s2,s2,1
    80004c76:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80004c78:	05490c63          	beq	s2,s4,80004cd0 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    80004c7c:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004c7e:	00014717          	auipc	a4,0x14
    80004c82:	02270713          	addi	a4,a4,34 # 80018ca0 <disk>
    80004c86:	4781                	li	a5,0
    if(disk.free[i]){
    80004c88:	01874683          	lbu	a3,24(a4)
    80004c8c:	fee9                	bnez	a3,80004c66 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80004c8e:	2785                	addiw	a5,a5,1
    80004c90:	0705                	addi	a4,a4,1
    80004c92:	fe979be3          	bne	a5,s1,80004c88 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80004c96:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80004c9a:	01205d63          	blez	s2,80004cb4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004c9e:	fa042503          	lw	a0,-96(s0)
    80004ca2:	d41ff0ef          	jal	800049e2 <free_desc>
      for(int j = 0; j < i; j++)
    80004ca6:	4785                	li	a5,1
    80004ca8:	0127d663          	bge	a5,s2,80004cb4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004cac:	fa442503          	lw	a0,-92(s0)
    80004cb0:	d33ff0ef          	jal	800049e2 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004cb4:	00014597          	auipc	a1,0x14
    80004cb8:	11458593          	addi	a1,a1,276 # 80018dc8 <disk+0x128>
    80004cbc:	00014517          	auipc	a0,0x14
    80004cc0:	ffc50513          	addi	a0,a0,-4 # 80018cb8 <disk+0x18>
    80004cc4:	849fc0ef          	jal	8000150c <sleep>
  for(int i = 0; i < 3; i++){
    80004cc8:	fa040613          	addi	a2,s0,-96
    80004ccc:	4901                	li	s2,0
    80004cce:	b77d                	j	80004c7c <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004cd0:	fa042503          	lw	a0,-96(s0)
    80004cd4:	00451693          	slli	a3,a0,0x4

  if(write)
    80004cd8:	00014797          	auipc	a5,0x14
    80004cdc:	fc878793          	addi	a5,a5,-56 # 80018ca0 <disk>
    80004ce0:	00451713          	slli	a4,a0,0x4
    80004ce4:	0a070713          	addi	a4,a4,160
    80004ce8:	973e                	add	a4,a4,a5
    80004cea:	01603633          	snez	a2,s6
    80004cee:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004cf0:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004cf4:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004cf8:	6398                	ld	a4,0(a5)
    80004cfa:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004cfc:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80004d00:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004d02:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004d04:	6390                	ld	a2,0(a5)
    80004d06:	00d60833          	add	a6,a2,a3
    80004d0a:	4741                	li	a4,16
    80004d0c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004d10:	4585                	li	a1,1
    80004d12:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80004d16:	fa442703          	lw	a4,-92(s0)
    80004d1a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004d1e:	0712                	slli	a4,a4,0x4
    80004d20:	963a                	add	a2,a2,a4
    80004d22:	05898813          	addi	a6,s3,88
    80004d26:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80004d2a:	0007b883          	ld	a7,0(a5)
    80004d2e:	9746                	add	a4,a4,a7
    80004d30:	40000613          	li	a2,1024
    80004d34:	c710                	sw	a2,8(a4)
  if(write)
    80004d36:	001b3613          	seqz	a2,s6
    80004d3a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004d3e:	8e4d                	or	a2,a2,a1
    80004d40:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004d44:	fa842603          	lw	a2,-88(s0)
    80004d48:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004d4c:	00451813          	slli	a6,a0,0x4
    80004d50:	02080813          	addi	a6,a6,32
    80004d54:	983e                	add	a6,a6,a5
    80004d56:	577d                	li	a4,-1
    80004d58:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004d5c:	0612                	slli	a2,a2,0x4
    80004d5e:	98b2                	add	a7,a7,a2
    80004d60:	03068713          	addi	a4,a3,48
    80004d64:	973e                	add	a4,a4,a5
    80004d66:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80004d6a:	6398                	ld	a4,0(a5)
    80004d6c:	9732                	add	a4,a4,a2
    80004d6e:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004d70:	4689                	li	a3,2
    80004d72:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80004d76:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004d7a:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80004d7e:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004d82:	6794                	ld	a3,8(a5)
    80004d84:	0026d703          	lhu	a4,2(a3)
    80004d88:	8b1d                	andi	a4,a4,7
    80004d8a:	0706                	slli	a4,a4,0x1
    80004d8c:	96ba                	add	a3,a3,a4
    80004d8e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80004d92:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004d96:	6798                	ld	a4,8(a5)
    80004d98:	00275783          	lhu	a5,2(a4)
    80004d9c:	2785                	addiw	a5,a5,1
    80004d9e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004da2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004da6:	100017b7          	lui	a5,0x10001
    80004daa:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004dae:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80004db2:	00014917          	auipc	s2,0x14
    80004db6:	01690913          	addi	s2,s2,22 # 80018dc8 <disk+0x128>
  while(b->disk == 1) {
    80004dba:	84ae                	mv	s1,a1
    80004dbc:	00b79a63          	bne	a5,a1,80004dd0 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80004dc0:	85ca                	mv	a1,s2
    80004dc2:	854e                	mv	a0,s3
    80004dc4:	f48fc0ef          	jal	8000150c <sleep>
  while(b->disk == 1) {
    80004dc8:	0049a783          	lw	a5,4(s3)
    80004dcc:	fe978ae3          	beq	a5,s1,80004dc0 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80004dd0:	fa042903          	lw	s2,-96(s0)
    80004dd4:	00491713          	slli	a4,s2,0x4
    80004dd8:	02070713          	addi	a4,a4,32
    80004ddc:	00014797          	auipc	a5,0x14
    80004de0:	ec478793          	addi	a5,a5,-316 # 80018ca0 <disk>
    80004de4:	97ba                	add	a5,a5,a4
    80004de6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004dea:	00014997          	auipc	s3,0x14
    80004dee:	eb698993          	addi	s3,s3,-330 # 80018ca0 <disk>
    80004df2:	00491713          	slli	a4,s2,0x4
    80004df6:	0009b783          	ld	a5,0(s3)
    80004dfa:	97ba                	add	a5,a5,a4
    80004dfc:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004e00:	854a                	mv	a0,s2
    80004e02:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004e06:	bddff0ef          	jal	800049e2 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004e0a:	8885                	andi	s1,s1,1
    80004e0c:	f0fd                	bnez	s1,80004df2 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004e0e:	00014517          	auipc	a0,0x14
    80004e12:	fba50513          	addi	a0,a0,-70 # 80018dc8 <disk+0x128>
    80004e16:	45b000ef          	jal	80005a70 <release>
}
    80004e1a:	60e6                	ld	ra,88(sp)
    80004e1c:	6446                	ld	s0,80(sp)
    80004e1e:	64a6                	ld	s1,72(sp)
    80004e20:	6906                	ld	s2,64(sp)
    80004e22:	79e2                	ld	s3,56(sp)
    80004e24:	7a42                	ld	s4,48(sp)
    80004e26:	7aa2                	ld	s5,40(sp)
    80004e28:	7b02                	ld	s6,32(sp)
    80004e2a:	6be2                	ld	s7,24(sp)
    80004e2c:	6c42                	ld	s8,16(sp)
    80004e2e:	6125                	addi	sp,sp,96
    80004e30:	8082                	ret

0000000080004e32 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004e32:	1101                	addi	sp,sp,-32
    80004e34:	ec06                	sd	ra,24(sp)
    80004e36:	e822                	sd	s0,16(sp)
    80004e38:	e426                	sd	s1,8(sp)
    80004e3a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004e3c:	00014497          	auipc	s1,0x14
    80004e40:	e6448493          	addi	s1,s1,-412 # 80018ca0 <disk>
    80004e44:	00014517          	auipc	a0,0x14
    80004e48:	f8450513          	addi	a0,a0,-124 # 80018dc8 <disk+0x128>
    80004e4c:	391000ef          	jal	800059dc <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004e50:	100017b7          	lui	a5,0x10001
    80004e54:	53bc                	lw	a5,96(a5)
    80004e56:	8b8d                	andi	a5,a5,3
    80004e58:	10001737          	lui	a4,0x10001
    80004e5c:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004e5e:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004e62:	689c                	ld	a5,16(s1)
    80004e64:	0204d703          	lhu	a4,32(s1)
    80004e68:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80004e6c:	04f70863          	beq	a4,a5,80004ebc <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80004e70:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004e74:	6898                	ld	a4,16(s1)
    80004e76:	0204d783          	lhu	a5,32(s1)
    80004e7a:	8b9d                	andi	a5,a5,7
    80004e7c:	078e                	slli	a5,a5,0x3
    80004e7e:	97ba                	add	a5,a5,a4
    80004e80:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004e82:	00479713          	slli	a4,a5,0x4
    80004e86:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80004e8a:	9726                	add	a4,a4,s1
    80004e8c:	01074703          	lbu	a4,16(a4)
    80004e90:	e329                	bnez	a4,80004ed2 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004e92:	0792                	slli	a5,a5,0x4
    80004e94:	02078793          	addi	a5,a5,32
    80004e98:	97a6                	add	a5,a5,s1
    80004e9a:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004e9c:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004ea0:	eb8fc0ef          	jal	80001558 <wakeup>

    disk.used_idx += 1;
    80004ea4:	0204d783          	lhu	a5,32(s1)
    80004ea8:	2785                	addiw	a5,a5,1
    80004eaa:	17c2                	slli	a5,a5,0x30
    80004eac:	93c1                	srli	a5,a5,0x30
    80004eae:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004eb2:	6898                	ld	a4,16(s1)
    80004eb4:	00275703          	lhu	a4,2(a4)
    80004eb8:	faf71ce3          	bne	a4,a5,80004e70 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80004ebc:	00014517          	auipc	a0,0x14
    80004ec0:	f0c50513          	addi	a0,a0,-244 # 80018dc8 <disk+0x128>
    80004ec4:	3ad000ef          	jal	80005a70 <release>
}
    80004ec8:	60e2                	ld	ra,24(sp)
    80004eca:	6442                	ld	s0,16(sp)
    80004ecc:	64a2                	ld	s1,8(sp)
    80004ece:	6105                	addi	sp,sp,32
    80004ed0:	8082                	ret
      panic("virtio_disk_intr status");
    80004ed2:	00003517          	auipc	a0,0x3
    80004ed6:	86650513          	addi	a0,a0,-1946 # 80007738 <etext+0x738>
    80004eda:	7c4000ef          	jal	8000569e <panic>

0000000080004ede <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80004ede:	1141                	addi	sp,sp,-16
    80004ee0:	e406                	sd	ra,8(sp)
    80004ee2:	e022                	sd	s0,0(sp)
    80004ee4:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80004ee6:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80004eea:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80004eee:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80004ef2:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80004ef6:	577d                	li	a4,-1
    80004ef8:	177e                	slli	a4,a4,0x3f
    80004efa:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80004efc:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80004f00:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80004f04:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80004f08:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80004f0c:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80004f10:	000f4737          	lui	a4,0xf4
    80004f14:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80004f18:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80004f1a:	14d79073          	csrw	stimecmp,a5
}
    80004f1e:	60a2                	ld	ra,8(sp)
    80004f20:	6402                	ld	s0,0(sp)
    80004f22:	0141                	addi	sp,sp,16
    80004f24:	8082                	ret

0000000080004f26 <start>:
{
    80004f26:	1141                	addi	sp,sp,-16
    80004f28:	e406                	sd	ra,8(sp)
    80004f2a:	e022                	sd	s0,0(sp)
    80004f2c:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80004f2e:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80004f32:	7779                	lui	a4,0xffffe
    80004f34:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd91f>
    80004f38:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80004f3a:	6705                	lui	a4,0x1
    80004f3c:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80004f40:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80004f42:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80004f46:	ffffb797          	auipc	a5,0xffffb
    80004f4a:	3ce78793          	addi	a5,a5,974 # 80000314 <main>
    80004f4e:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80004f52:	4781                	li	a5,0
    80004f54:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80004f58:	67c1                	lui	a5,0x10
    80004f5a:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80004f5c:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80004f60:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80004f64:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80004f68:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80004f6c:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80004f70:	57fd                	li	a5,-1
    80004f72:	83a9                	srli	a5,a5,0xa
    80004f74:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80004f78:	47bd                	li	a5,15
    80004f7a:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80004f7e:	f61ff0ef          	jal	80004ede <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80004f82:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80004f86:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80004f88:	823e                	mv	tp,a5
  asm volatile("mret");
    80004f8a:	30200073          	mret
}
    80004f8e:	60a2                	ld	ra,8(sp)
    80004f90:	6402                	ld	s0,0(sp)
    80004f92:	0141                	addi	sp,sp,16
    80004f94:	8082                	ret

0000000080004f96 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80004f96:	711d                	addi	sp,sp,-96
    80004f98:	ec86                	sd	ra,88(sp)
    80004f9a:	e8a2                	sd	s0,80(sp)
    80004f9c:	e0ca                	sd	s2,64(sp)
    80004f9e:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    80004fa0:	04c05763          	blez	a2,80004fee <consolewrite+0x58>
    80004fa4:	e4a6                	sd	s1,72(sp)
    80004fa6:	fc4e                	sd	s3,56(sp)
    80004fa8:	f852                	sd	s4,48(sp)
    80004faa:	f456                	sd	s5,40(sp)
    80004fac:	f05a                	sd	s6,32(sp)
    80004fae:	ec5e                	sd	s7,24(sp)
    80004fb0:	8a2a                	mv	s4,a0
    80004fb2:	84ae                	mv	s1,a1
    80004fb4:	89b2                	mv	s3,a2
    80004fb6:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80004fb8:	faf40b93          	addi	s7,s0,-81
    80004fbc:	4b05                	li	s6,1
    80004fbe:	5afd                	li	s5,-1
    80004fc0:	86da                	mv	a3,s6
    80004fc2:	8626                	mv	a2,s1
    80004fc4:	85d2                	mv	a1,s4
    80004fc6:	855e                	mv	a0,s7
    80004fc8:	8e9fc0ef          	jal	800018b0 <either_copyin>
    80004fcc:	03550363          	beq	a0,s5,80004ff2 <consolewrite+0x5c>
      break;
    uartputc(c);
    80004fd0:	faf44503          	lbu	a0,-81(s0)
    80004fd4:	06b000ef          	jal	8000583e <uartputc>
  for(i = 0; i < n; i++){
    80004fd8:	2905                	addiw	s2,s2,1
    80004fda:	0485                	addi	s1,s1,1
    80004fdc:	ff2992e3          	bne	s3,s2,80004fc0 <consolewrite+0x2a>
    80004fe0:	64a6                	ld	s1,72(sp)
    80004fe2:	79e2                	ld	s3,56(sp)
    80004fe4:	7a42                	ld	s4,48(sp)
    80004fe6:	7aa2                	ld	s5,40(sp)
    80004fe8:	7b02                	ld	s6,32(sp)
    80004fea:	6be2                	ld	s7,24(sp)
    80004fec:	a809                	j	80004ffe <consolewrite+0x68>
    80004fee:	4901                	li	s2,0
    80004ff0:	a039                	j	80004ffe <consolewrite+0x68>
    80004ff2:	64a6                	ld	s1,72(sp)
    80004ff4:	79e2                	ld	s3,56(sp)
    80004ff6:	7a42                	ld	s4,48(sp)
    80004ff8:	7aa2                	ld	s5,40(sp)
    80004ffa:	7b02                	ld	s6,32(sp)
    80004ffc:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    80004ffe:	854a                	mv	a0,s2
    80005000:	60e6                	ld	ra,88(sp)
    80005002:	6446                	ld	s0,80(sp)
    80005004:	6906                	ld	s2,64(sp)
    80005006:	6125                	addi	sp,sp,96
    80005008:	8082                	ret

000000008000500a <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000500a:	711d                	addi	sp,sp,-96
    8000500c:	ec86                	sd	ra,88(sp)
    8000500e:	e8a2                	sd	s0,80(sp)
    80005010:	e4a6                	sd	s1,72(sp)
    80005012:	e0ca                	sd	s2,64(sp)
    80005014:	fc4e                	sd	s3,56(sp)
    80005016:	f852                	sd	s4,48(sp)
    80005018:	f05a                	sd	s6,32(sp)
    8000501a:	ec5e                	sd	s7,24(sp)
    8000501c:	1080                	addi	s0,sp,96
    8000501e:	8b2a                	mv	s6,a0
    80005020:	8a2e                	mv	s4,a1
    80005022:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80005024:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80005026:	0001c517          	auipc	a0,0x1c
    8000502a:	dba50513          	addi	a0,a0,-582 # 80020de0 <cons>
    8000502e:	1af000ef          	jal	800059dc <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80005032:	0001c497          	auipc	s1,0x1c
    80005036:	dae48493          	addi	s1,s1,-594 # 80020de0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    8000503a:	0001c917          	auipc	s2,0x1c
    8000503e:	e3e90913          	addi	s2,s2,-450 # 80020e78 <cons+0x98>
  while(n > 0){
    80005042:	0b305b63          	blez	s3,800050f8 <consoleread+0xee>
    while(cons.r == cons.w){
    80005046:	0984a783          	lw	a5,152(s1)
    8000504a:	09c4a703          	lw	a4,156(s1)
    8000504e:	0af71063          	bne	a4,a5,800050ee <consoleread+0xe4>
      if(killed(myproc())){
    80005052:	e65fb0ef          	jal	80000eb6 <myproc>
    80005056:	ef2fc0ef          	jal	80001748 <killed>
    8000505a:	e12d                	bnez	a0,800050bc <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    8000505c:	85a6                	mv	a1,s1
    8000505e:	854a                	mv	a0,s2
    80005060:	cacfc0ef          	jal	8000150c <sleep>
    while(cons.r == cons.w){
    80005064:	0984a783          	lw	a5,152(s1)
    80005068:	09c4a703          	lw	a4,156(s1)
    8000506c:	fef703e3          	beq	a4,a5,80005052 <consoleread+0x48>
    80005070:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80005072:	0001c717          	auipc	a4,0x1c
    80005076:	d6e70713          	addi	a4,a4,-658 # 80020de0 <cons>
    8000507a:	0017869b          	addiw	a3,a5,1
    8000507e:	08d72c23          	sw	a3,152(a4)
    80005082:	07f7f693          	andi	a3,a5,127
    80005086:	9736                	add	a4,a4,a3
    80005088:	01874703          	lbu	a4,24(a4)
    8000508c:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    80005090:	4691                	li	a3,4
    80005092:	04da8663          	beq	s5,a3,800050de <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80005096:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    8000509a:	4685                	li	a3,1
    8000509c:	faf40613          	addi	a2,s0,-81
    800050a0:	85d2                	mv	a1,s4
    800050a2:	855a                	mv	a0,s6
    800050a4:	fc2fc0ef          	jal	80001866 <either_copyout>
    800050a8:	57fd                	li	a5,-1
    800050aa:	04f50663          	beq	a0,a5,800050f6 <consoleread+0xec>
      break;

    dst++;
    800050ae:	0a05                	addi	s4,s4,1
    --n;
    800050b0:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    800050b2:	47a9                	li	a5,10
    800050b4:	04fa8b63          	beq	s5,a5,8000510a <consoleread+0x100>
    800050b8:	7aa2                	ld	s5,40(sp)
    800050ba:	b761                	j	80005042 <consoleread+0x38>
        release(&cons.lock);
    800050bc:	0001c517          	auipc	a0,0x1c
    800050c0:	d2450513          	addi	a0,a0,-732 # 80020de0 <cons>
    800050c4:	1ad000ef          	jal	80005a70 <release>
        return -1;
    800050c8:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    800050ca:	60e6                	ld	ra,88(sp)
    800050cc:	6446                	ld	s0,80(sp)
    800050ce:	64a6                	ld	s1,72(sp)
    800050d0:	6906                	ld	s2,64(sp)
    800050d2:	79e2                	ld	s3,56(sp)
    800050d4:	7a42                	ld	s4,48(sp)
    800050d6:	7b02                	ld	s6,32(sp)
    800050d8:	6be2                	ld	s7,24(sp)
    800050da:	6125                	addi	sp,sp,96
    800050dc:	8082                	ret
      if(n < target){
    800050de:	0179fa63          	bgeu	s3,s7,800050f2 <consoleread+0xe8>
        cons.r--;
    800050e2:	0001c717          	auipc	a4,0x1c
    800050e6:	d8f72b23          	sw	a5,-618(a4) # 80020e78 <cons+0x98>
    800050ea:	7aa2                	ld	s5,40(sp)
    800050ec:	a031                	j	800050f8 <consoleread+0xee>
    800050ee:	f456                	sd	s5,40(sp)
    800050f0:	b749                	j	80005072 <consoleread+0x68>
    800050f2:	7aa2                	ld	s5,40(sp)
    800050f4:	a011                	j	800050f8 <consoleread+0xee>
    800050f6:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    800050f8:	0001c517          	auipc	a0,0x1c
    800050fc:	ce850513          	addi	a0,a0,-792 # 80020de0 <cons>
    80005100:	171000ef          	jal	80005a70 <release>
  return target - n;
    80005104:	413b853b          	subw	a0,s7,s3
    80005108:	b7c9                	j	800050ca <consoleread+0xc0>
    8000510a:	7aa2                	ld	s5,40(sp)
    8000510c:	b7f5                	j	800050f8 <consoleread+0xee>

000000008000510e <consputc>:
{
    8000510e:	1141                	addi	sp,sp,-16
    80005110:	e406                	sd	ra,8(sp)
    80005112:	e022                	sd	s0,0(sp)
    80005114:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80005116:	10000793          	li	a5,256
    8000511a:	00f50863          	beq	a0,a5,8000512a <consputc+0x1c>
    uartputc_sync(c);
    8000511e:	63e000ef          	jal	8000575c <uartputc_sync>
}
    80005122:	60a2                	ld	ra,8(sp)
    80005124:	6402                	ld	s0,0(sp)
    80005126:	0141                	addi	sp,sp,16
    80005128:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000512a:	4521                	li	a0,8
    8000512c:	630000ef          	jal	8000575c <uartputc_sync>
    80005130:	02000513          	li	a0,32
    80005134:	628000ef          	jal	8000575c <uartputc_sync>
    80005138:	4521                	li	a0,8
    8000513a:	622000ef          	jal	8000575c <uartputc_sync>
    8000513e:	b7d5                	j	80005122 <consputc+0x14>

0000000080005140 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80005140:	1101                	addi	sp,sp,-32
    80005142:	ec06                	sd	ra,24(sp)
    80005144:	e822                	sd	s0,16(sp)
    80005146:	e426                	sd	s1,8(sp)
    80005148:	1000                	addi	s0,sp,32
    8000514a:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    8000514c:	0001c517          	auipc	a0,0x1c
    80005150:	c9450513          	addi	a0,a0,-876 # 80020de0 <cons>
    80005154:	089000ef          	jal	800059dc <acquire>

  switch(c){
    80005158:	47d5                	li	a5,21
    8000515a:	08f48d63          	beq	s1,a5,800051f4 <consoleintr+0xb4>
    8000515e:	0297c563          	blt	a5,s1,80005188 <consoleintr+0x48>
    80005162:	47a1                	li	a5,8
    80005164:	0ef48263          	beq	s1,a5,80005248 <consoleintr+0x108>
    80005168:	47c1                	li	a5,16
    8000516a:	10f49363          	bne	s1,a5,80005270 <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    8000516e:	f8cfc0ef          	jal	800018fa <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    80005172:	0001c517          	auipc	a0,0x1c
    80005176:	c6e50513          	addi	a0,a0,-914 # 80020de0 <cons>
    8000517a:	0f7000ef          	jal	80005a70 <release>
}
    8000517e:	60e2                	ld	ra,24(sp)
    80005180:	6442                	ld	s0,16(sp)
    80005182:	64a2                	ld	s1,8(sp)
    80005184:	6105                	addi	sp,sp,32
    80005186:	8082                	ret
  switch(c){
    80005188:	07f00793          	li	a5,127
    8000518c:	0af48e63          	beq	s1,a5,80005248 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005190:	0001c717          	auipc	a4,0x1c
    80005194:	c5070713          	addi	a4,a4,-944 # 80020de0 <cons>
    80005198:	0a072783          	lw	a5,160(a4)
    8000519c:	09872703          	lw	a4,152(a4)
    800051a0:	9f99                	subw	a5,a5,a4
    800051a2:	07f00713          	li	a4,127
    800051a6:	fcf766e3          	bltu	a4,a5,80005172 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    800051aa:	47b5                	li	a5,13
    800051ac:	0cf48563          	beq	s1,a5,80005276 <consoleintr+0x136>
      consputc(c);
    800051b0:	8526                	mv	a0,s1
    800051b2:	f5dff0ef          	jal	8000510e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800051b6:	0001c717          	auipc	a4,0x1c
    800051ba:	c2a70713          	addi	a4,a4,-982 # 80020de0 <cons>
    800051be:	0a072683          	lw	a3,160(a4)
    800051c2:	0016879b          	addiw	a5,a3,1
    800051c6:	863e                	mv	a2,a5
    800051c8:	0af72023          	sw	a5,160(a4)
    800051cc:	07f6f693          	andi	a3,a3,127
    800051d0:	9736                	add	a4,a4,a3
    800051d2:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    800051d6:	ff648713          	addi	a4,s1,-10
    800051da:	c371                	beqz	a4,8000529e <consoleintr+0x15e>
    800051dc:	14f1                	addi	s1,s1,-4
    800051de:	c0e1                	beqz	s1,8000529e <consoleintr+0x15e>
    800051e0:	0001c717          	auipc	a4,0x1c
    800051e4:	c9872703          	lw	a4,-872(a4) # 80020e78 <cons+0x98>
    800051e8:	9f99                	subw	a5,a5,a4
    800051ea:	08000713          	li	a4,128
    800051ee:	f8e792e3          	bne	a5,a4,80005172 <consoleintr+0x32>
    800051f2:	a075                	j	8000529e <consoleintr+0x15e>
    800051f4:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    800051f6:	0001c717          	auipc	a4,0x1c
    800051fa:	bea70713          	addi	a4,a4,-1046 # 80020de0 <cons>
    800051fe:	0a072783          	lw	a5,160(a4)
    80005202:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005206:	0001c497          	auipc	s1,0x1c
    8000520a:	bda48493          	addi	s1,s1,-1062 # 80020de0 <cons>
    while(cons.e != cons.w &&
    8000520e:	4929                	li	s2,10
    80005210:	02f70863          	beq	a4,a5,80005240 <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005214:	37fd                	addiw	a5,a5,-1
    80005216:	07f7f713          	andi	a4,a5,127
    8000521a:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000521c:	01874703          	lbu	a4,24(a4)
    80005220:	03270263          	beq	a4,s2,80005244 <consoleintr+0x104>
      cons.e--;
    80005224:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005228:	10000513          	li	a0,256
    8000522c:	ee3ff0ef          	jal	8000510e <consputc>
    while(cons.e != cons.w &&
    80005230:	0a04a783          	lw	a5,160(s1)
    80005234:	09c4a703          	lw	a4,156(s1)
    80005238:	fcf71ee3          	bne	a4,a5,80005214 <consoleintr+0xd4>
    8000523c:	6902                	ld	s2,0(sp)
    8000523e:	bf15                	j	80005172 <consoleintr+0x32>
    80005240:	6902                	ld	s2,0(sp)
    80005242:	bf05                	j	80005172 <consoleintr+0x32>
    80005244:	6902                	ld	s2,0(sp)
    80005246:	b735                	j	80005172 <consoleintr+0x32>
    if(cons.e != cons.w){
    80005248:	0001c717          	auipc	a4,0x1c
    8000524c:	b9870713          	addi	a4,a4,-1128 # 80020de0 <cons>
    80005250:	0a072783          	lw	a5,160(a4)
    80005254:	09c72703          	lw	a4,156(a4)
    80005258:	f0f70de3          	beq	a4,a5,80005172 <consoleintr+0x32>
      cons.e--;
    8000525c:	37fd                	addiw	a5,a5,-1
    8000525e:	0001c717          	auipc	a4,0x1c
    80005262:	c2f72123          	sw	a5,-990(a4) # 80020e80 <cons+0xa0>
      consputc(BACKSPACE);
    80005266:	10000513          	li	a0,256
    8000526a:	ea5ff0ef          	jal	8000510e <consputc>
    8000526e:	b711                	j	80005172 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005270:	f00481e3          	beqz	s1,80005172 <consoleintr+0x32>
    80005274:	bf31                	j	80005190 <consoleintr+0x50>
      consputc(c);
    80005276:	4529                	li	a0,10
    80005278:	e97ff0ef          	jal	8000510e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    8000527c:	0001c797          	auipc	a5,0x1c
    80005280:	b6478793          	addi	a5,a5,-1180 # 80020de0 <cons>
    80005284:	0a07a703          	lw	a4,160(a5)
    80005288:	0017069b          	addiw	a3,a4,1
    8000528c:	8636                	mv	a2,a3
    8000528e:	0ad7a023          	sw	a3,160(a5)
    80005292:	07f77713          	andi	a4,a4,127
    80005296:	97ba                	add	a5,a5,a4
    80005298:	4729                	li	a4,10
    8000529a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000529e:	0001c797          	auipc	a5,0x1c
    800052a2:	bcc7af23          	sw	a2,-1058(a5) # 80020e7c <cons+0x9c>
        wakeup(&cons.r);
    800052a6:	0001c517          	auipc	a0,0x1c
    800052aa:	bd250513          	addi	a0,a0,-1070 # 80020e78 <cons+0x98>
    800052ae:	aaafc0ef          	jal	80001558 <wakeup>
    800052b2:	b5c1                	j	80005172 <consoleintr+0x32>

00000000800052b4 <consoleinit>:

void
consoleinit(void)
{
    800052b4:	1141                	addi	sp,sp,-16
    800052b6:	e406                	sd	ra,8(sp)
    800052b8:	e022                	sd	s0,0(sp)
    800052ba:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800052bc:	00002597          	auipc	a1,0x2
    800052c0:	49458593          	addi	a1,a1,1172 # 80007750 <etext+0x750>
    800052c4:	0001c517          	auipc	a0,0x1c
    800052c8:	b1c50513          	addi	a0,a0,-1252 # 80020de0 <cons>
    800052cc:	686000ef          	jal	80005952 <initlock>

  uartinit();
    800052d0:	436000ef          	jal	80005706 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    800052d4:	00013797          	auipc	a5,0x13
    800052d8:	97478793          	addi	a5,a5,-1676 # 80017c48 <devsw>
    800052dc:	00000717          	auipc	a4,0x0
    800052e0:	d2e70713          	addi	a4,a4,-722 # 8000500a <consoleread>
    800052e4:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    800052e6:	00000717          	auipc	a4,0x0
    800052ea:	cb070713          	addi	a4,a4,-848 # 80004f96 <consolewrite>
    800052ee:	ef98                	sd	a4,24(a5)
}
    800052f0:	60a2                	ld	ra,8(sp)
    800052f2:	6402                	ld	s0,0(sp)
    800052f4:	0141                	addi	sp,sp,16
    800052f6:	8082                	ret

00000000800052f8 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    800052f8:	7179                	addi	sp,sp,-48
    800052fa:	f406                	sd	ra,40(sp)
    800052fc:	f022                	sd	s0,32(sp)
    800052fe:	e84a                	sd	s2,16(sp)
    80005300:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80005302:	c219                	beqz	a2,80005308 <printint+0x10>
    80005304:	08054163          	bltz	a0,80005386 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80005308:	4301                	li	t1,0

  i = 0;
    8000530a:	fd040913          	addi	s2,s0,-48
    x = xx;
    8000530e:	86ca                	mv	a3,s2
  i = 0;
    80005310:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005312:	00002817          	auipc	a6,0x2
    80005316:	5fe80813          	addi	a6,a6,1534 # 80007910 <digits>
    8000531a:	88ba                	mv	a7,a4
    8000531c:	0017061b          	addiw	a2,a4,1
    80005320:	8732                	mv	a4,a2
    80005322:	02b577b3          	remu	a5,a0,a1
    80005326:	97c2                	add	a5,a5,a6
    80005328:	0007c783          	lbu	a5,0(a5)
    8000532c:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005330:	87aa                	mv	a5,a0
    80005332:	02b55533          	divu	a0,a0,a1
    80005336:	0685                	addi	a3,a3,1
    80005338:	feb7f1e3          	bgeu	a5,a1,8000531a <printint+0x22>

  if(sign)
    8000533c:	00030c63          	beqz	t1,80005354 <printint+0x5c>
    buf[i++] = '-';
    80005340:	fe060793          	addi	a5,a2,-32
    80005344:	00878633          	add	a2,a5,s0
    80005348:	02d00793          	li	a5,45
    8000534c:	fef60823          	sb	a5,-16(a2)
    80005350:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80005354:	02e05463          	blez	a4,8000537c <printint+0x84>
    80005358:	ec26                	sd	s1,24(sp)
    8000535a:	377d                	addiw	a4,a4,-1
    8000535c:	00e904b3          	add	s1,s2,a4
    80005360:	197d                	addi	s2,s2,-1
    80005362:	993a                	add	s2,s2,a4
    80005364:	1702                	slli	a4,a4,0x20
    80005366:	9301                	srli	a4,a4,0x20
    80005368:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    8000536c:	0004c503          	lbu	a0,0(s1)
    80005370:	d9fff0ef          	jal	8000510e <consputc>
  while(--i >= 0)
    80005374:	14fd                	addi	s1,s1,-1
    80005376:	ff249be3          	bne	s1,s2,8000536c <printint+0x74>
    8000537a:	64e2                	ld	s1,24(sp)
}
    8000537c:	70a2                	ld	ra,40(sp)
    8000537e:	7402                	ld	s0,32(sp)
    80005380:	6942                	ld	s2,16(sp)
    80005382:	6145                	addi	sp,sp,48
    80005384:	8082                	ret
    x = -xx;
    80005386:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    8000538a:	4305                	li	t1,1
    x = -xx;
    8000538c:	bfbd                	j	8000530a <printint+0x12>

000000008000538e <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    8000538e:	7131                	addi	sp,sp,-192
    80005390:	fc86                	sd	ra,120(sp)
    80005392:	f8a2                	sd	s0,112(sp)
    80005394:	f0ca                	sd	s2,96(sp)
    80005396:	ec6e                	sd	s11,24(sp)
    80005398:	0100                	addi	s0,sp,128
    8000539a:	892a                	mv	s2,a0
    8000539c:	e40c                	sd	a1,8(s0)
    8000539e:	e810                	sd	a2,16(s0)
    800053a0:	ec14                	sd	a3,24(s0)
    800053a2:	f018                	sd	a4,32(s0)
    800053a4:	f41c                	sd	a5,40(s0)
    800053a6:	03043823          	sd	a6,48(s0)
    800053aa:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800053ae:	0001cd97          	auipc	s11,0x1c
    800053b2:	af2dad83          	lw	s11,-1294(s11) # 80020ea0 <pr+0x18>
  if(locking)
    800053b6:	020d9d63          	bnez	s11,800053f0 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800053ba:	00840793          	addi	a5,s0,8
    800053be:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800053c2:	00054503          	lbu	a0,0(a0)
    800053c6:	20050f63          	beqz	a0,800055e4 <printf+0x256>
    800053ca:	f4a6                	sd	s1,104(sp)
    800053cc:	ecce                	sd	s3,88(sp)
    800053ce:	e8d2                	sd	s4,80(sp)
    800053d0:	e4d6                	sd	s5,72(sp)
    800053d2:	e0da                	sd	s6,64(sp)
    800053d4:	fc5e                	sd	s7,56(sp)
    800053d6:	f862                	sd	s8,48(sp)
    800053d8:	f06a                	sd	s10,32(sp)
    800053da:	4a81                	li	s5,0
    if(cx != '%'){
    800053dc:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    800053e0:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    800053e4:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    800053e8:	4b29                	li	s6,10
    if(c0 == 'd'){
    800053ea:	06400b93          	li	s7,100
    800053ee:	a80d                	j	80005420 <printf+0x92>
    acquire(&pr.lock);
    800053f0:	0001c517          	auipc	a0,0x1c
    800053f4:	a9850513          	addi	a0,a0,-1384 # 80020e88 <pr>
    800053f8:	5e4000ef          	jal	800059dc <acquire>
  va_start(ap, fmt);
    800053fc:	00840793          	addi	a5,s0,8
    80005400:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005404:	00094503          	lbu	a0,0(s2)
    80005408:	f169                	bnez	a0,800053ca <printf+0x3c>
    8000540a:	aae5                	j	80005602 <printf+0x274>
      consputc(cx);
    8000540c:	d03ff0ef          	jal	8000510e <consputc>
      continue;
    80005410:	84d6                	mv	s1,s5
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005412:	2485                	addiw	s1,s1,1
    80005414:	8aa6                	mv	s5,s1
    80005416:	94ca                	add	s1,s1,s2
    80005418:	0004c503          	lbu	a0,0(s1)
    8000541c:	1a050a63          	beqz	a0,800055d0 <printf+0x242>
    if(cx != '%'){
    80005420:	ff3516e3          	bne	a0,s3,8000540c <printf+0x7e>
    i++;
    80005424:	001a879b          	addiw	a5,s5,1
    80005428:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000542a:	00f90733          	add	a4,s2,a5
    8000542e:	00074a03          	lbu	s4,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005432:	1e0a0863          	beqz	s4,80005622 <printf+0x294>
    80005436:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000543a:	1c068b63          	beqz	a3,80005610 <printf+0x282>
    if(c0 == 'd'){
    8000543e:	037a0863          	beq	s4,s7,8000546e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005442:	f94a0713          	addi	a4,s4,-108
    80005446:	00173713          	seqz	a4,a4
    8000544a:	f9c68613          	addi	a2,a3,-100
    8000544e:	ee05                	bnez	a2,80005486 <printf+0xf8>
    80005450:	cb1d                	beqz	a4,80005486 <printf+0xf8>
      printint(va_arg(ap, uint64), 10, 1);
    80005452:	f8843783          	ld	a5,-120(s0)
    80005456:	00878713          	addi	a4,a5,8
    8000545a:	f8e43423          	sd	a4,-120(s0)
    8000545e:	4605                	li	a2,1
    80005460:	85da                	mv	a1,s6
    80005462:	6388                	ld	a0,0(a5)
    80005464:	e95ff0ef          	jal	800052f8 <printint>
      i += 1;
    80005468:	002a849b          	addiw	s1,s5,2
    8000546c:	b75d                	j	80005412 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    8000546e:	f8843783          	ld	a5,-120(s0)
    80005472:	00878713          	addi	a4,a5,8
    80005476:	f8e43423          	sd	a4,-120(s0)
    8000547a:	4605                	li	a2,1
    8000547c:	85da                	mv	a1,s6
    8000547e:	4388                	lw	a0,0(a5)
    80005480:	e79ff0ef          	jal	800052f8 <printint>
    80005484:	b779                	j	80005412 <printf+0x84>
    if(c1) c2 = fmt[i+2] & 0xff;
    80005486:	97ca                	add	a5,a5,s2
    80005488:	8636                	mv	a2,a3
    8000548a:	0027c683          	lbu	a3,2(a5)
    8000548e:	a245                	j	8000562e <printf+0x2a0>
      printint(va_arg(ap, uint64), 10, 1);
    80005490:	f8843783          	ld	a5,-120(s0)
    80005494:	00878713          	addi	a4,a5,8
    80005498:	f8e43423          	sd	a4,-120(s0)
    8000549c:	4605                	li	a2,1
    8000549e:	45a9                	li	a1,10
    800054a0:	6388                	ld	a0,0(a5)
    800054a2:	e57ff0ef          	jal	800052f8 <printint>
      i += 2;
    800054a6:	003a849b          	addiw	s1,s5,3
    800054aa:	b7a5                	j	80005412 <printf+0x84>
      printint(va_arg(ap, int), 10, 0);
    800054ac:	f8843783          	ld	a5,-120(s0)
    800054b0:	00878713          	addi	a4,a5,8
    800054b4:	f8e43423          	sd	a4,-120(s0)
    800054b8:	4601                	li	a2,0
    800054ba:	85da                	mv	a1,s6
    800054bc:	4388                	lw	a0,0(a5)
    800054be:	e3bff0ef          	jal	800052f8 <printint>
    800054c2:	bf81                	j	80005412 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800054c4:	f8843783          	ld	a5,-120(s0)
    800054c8:	00878713          	addi	a4,a5,8
    800054cc:	f8e43423          	sd	a4,-120(s0)
    800054d0:	4601                	li	a2,0
    800054d2:	85da                	mv	a1,s6
    800054d4:	6388                	ld	a0,0(a5)
    800054d6:	e23ff0ef          	jal	800052f8 <printint>
      i += 1;
    800054da:	002a849b          	addiw	s1,s5,2
    800054de:	bf15                	j	80005412 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800054e0:	f8843783          	ld	a5,-120(s0)
    800054e4:	00878713          	addi	a4,a5,8
    800054e8:	f8e43423          	sd	a4,-120(s0)
    800054ec:	4601                	li	a2,0
    800054ee:	45a9                	li	a1,10
    800054f0:	6388                	ld	a0,0(a5)
    800054f2:	e07ff0ef          	jal	800052f8 <printint>
      i += 2;
    800054f6:	003a849b          	addiw	s1,s5,3
    800054fa:	bf21                	j	80005412 <printf+0x84>
      printint(va_arg(ap, int), 16, 0);
    800054fc:	f8843783          	ld	a5,-120(s0)
    80005500:	00878713          	addi	a4,a5,8
    80005504:	f8e43423          	sd	a4,-120(s0)
    80005508:	4601                	li	a2,0
    8000550a:	45c1                	li	a1,16
    8000550c:	4388                	lw	a0,0(a5)
    8000550e:	debff0ef          	jal	800052f8 <printint>
    80005512:	b701                	j	80005412 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80005514:	f8843783          	ld	a5,-120(s0)
    80005518:	00878713          	addi	a4,a5,8
    8000551c:	f8e43423          	sd	a4,-120(s0)
    80005520:	45c1                	li	a1,16
    80005522:	6388                	ld	a0,0(a5)
    80005524:	dd5ff0ef          	jal	800052f8 <printint>
      i += 1;
    80005528:	002a849b          	addiw	s1,s5,2
    8000552c:	b5dd                	j	80005412 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    8000552e:	f8843783          	ld	a5,-120(s0)
    80005532:	00878713          	addi	a4,a5,8
    80005536:	f8e43423          	sd	a4,-120(s0)
    8000553a:	4601                	li	a2,0
    8000553c:	45c1                	li	a1,16
    8000553e:	6388                	ld	a0,0(a5)
    80005540:	db9ff0ef          	jal	800052f8 <printint>
      i += 2;
    80005544:	003a849b          	addiw	s1,s5,3
    80005548:	b5e9                	j	80005412 <printf+0x84>
    8000554a:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    8000554c:	f8843783          	ld	a5,-120(s0)
    80005550:	00878713          	addi	a4,a5,8
    80005554:	f8e43423          	sd	a4,-120(s0)
    80005558:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    8000555c:	03000513          	li	a0,48
    80005560:	bafff0ef          	jal	8000510e <consputc>
  consputc('x');
    80005564:	07800513          	li	a0,120
    80005568:	ba7ff0ef          	jal	8000510e <consputc>
    8000556c:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000556e:	00002c97          	auipc	s9,0x2
    80005572:	3a2c8c93          	addi	s9,s9,930 # 80007910 <digits>
    80005576:	03cad793          	srli	a5,s5,0x3c
    8000557a:	97e6                	add	a5,a5,s9
    8000557c:	0007c503          	lbu	a0,0(a5)
    80005580:	b8fff0ef          	jal	8000510e <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    80005584:	0a92                	slli	s5,s5,0x4
    80005586:	3a7d                	addiw	s4,s4,-1
    80005588:	fe0a17e3          	bnez	s4,80005576 <printf+0x1e8>
    8000558c:	7ca2                	ld	s9,40(sp)
    8000558e:	b551                	j	80005412 <printf+0x84>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80005590:	f8843783          	ld	a5,-120(s0)
    80005594:	00878713          	addi	a4,a5,8
    80005598:	f8e43423          	sd	a4,-120(s0)
    8000559c:	0007ba03          	ld	s4,0(a5)
    800055a0:	000a0d63          	beqz	s4,800055ba <printf+0x22c>
        s = "(null)";
      for(; *s; s++)
    800055a4:	000a4503          	lbu	a0,0(s4)
    800055a8:	e60505e3          	beqz	a0,80005412 <printf+0x84>
        consputc(*s);
    800055ac:	b63ff0ef          	jal	8000510e <consputc>
      for(; *s; s++)
    800055b0:	0a05                	addi	s4,s4,1
    800055b2:	000a4503          	lbu	a0,0(s4)
    800055b6:	f97d                	bnez	a0,800055ac <printf+0x21e>
    800055b8:	bda9                	j	80005412 <printf+0x84>
        s = "(null)";
    800055ba:	00002a17          	auipc	s4,0x2
    800055be:	19ea0a13          	addi	s4,s4,414 # 80007758 <etext+0x758>
      for(; *s; s++)
    800055c2:	02800513          	li	a0,40
    800055c6:	b7dd                	j	800055ac <printf+0x21e>
    } else if(c0 == '%'){
      consputc('%');
    800055c8:	8552                	mv	a0,s4
    800055ca:	b45ff0ef          	jal	8000510e <consputc>
    800055ce:	b591                	j	80005412 <printf+0x84>
    }
#endif
  }
  va_end(ap);

  if(locking)
    800055d0:	020d9163          	bnez	s11,800055f2 <printf+0x264>
    800055d4:	74a6                	ld	s1,104(sp)
    800055d6:	69e6                	ld	s3,88(sp)
    800055d8:	6a46                	ld	s4,80(sp)
    800055da:	6aa6                	ld	s5,72(sp)
    800055dc:	6b06                	ld	s6,64(sp)
    800055de:	7be2                	ld	s7,56(sp)
    800055e0:	7c42                	ld	s8,48(sp)
    800055e2:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    800055e4:	4501                	li	a0,0
    800055e6:	70e6                	ld	ra,120(sp)
    800055e8:	7446                	ld	s0,112(sp)
    800055ea:	7906                	ld	s2,96(sp)
    800055ec:	6de2                	ld	s11,24(sp)
    800055ee:	6129                	addi	sp,sp,192
    800055f0:	8082                	ret
    800055f2:	74a6                	ld	s1,104(sp)
    800055f4:	69e6                	ld	s3,88(sp)
    800055f6:	6a46                	ld	s4,80(sp)
    800055f8:	6aa6                	ld	s5,72(sp)
    800055fa:	6b06                	ld	s6,64(sp)
    800055fc:	7be2                	ld	s7,56(sp)
    800055fe:	7c42                	ld	s8,48(sp)
    80005600:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80005602:	0001c517          	auipc	a0,0x1c
    80005606:	88650513          	addi	a0,a0,-1914 # 80020e88 <pr>
    8000560a:	466000ef          	jal	80005a70 <release>
    8000560e:	bfd9                	j	800055e4 <printf+0x256>
    if(c0 == 'd'){
    80005610:	e57a0fe3          	beq	s4,s7,8000546e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005614:	f94a0713          	addi	a4,s4,-108
    80005618:	00173713          	seqz	a4,a4
    8000561c:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000561e:	4781                	li	a5,0
    80005620:	a00d                	j	80005642 <printf+0x2b4>
    } else if(c0 == 'l' && c1 == 'd'){
    80005622:	f94a0713          	addi	a4,s4,-108
    80005626:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    8000562a:	8652                	mv	a2,s4
    8000562c:	86d2                	mv	a3,s4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000562e:	f9460793          	addi	a5,a2,-108
    80005632:	0017b793          	seqz	a5,a5
    80005636:	8ff9                	and	a5,a5,a4
    80005638:	f9c68593          	addi	a1,a3,-100
    8000563c:	e199                	bnez	a1,80005642 <printf+0x2b4>
    8000563e:	e40799e3          	bnez	a5,80005490 <printf+0x102>
    } else if(c0 == 'u'){
    80005642:	e78a05e3          	beq	s4,s8,800054ac <printf+0x11e>
    } else if(c0 == 'l' && c1 == 'u'){
    80005646:	f8b60593          	addi	a1,a2,-117
    8000564a:	e199                	bnez	a1,80005650 <printf+0x2c2>
    8000564c:	e6071ce3          	bnez	a4,800054c4 <printf+0x136>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005650:	f8b68593          	addi	a1,a3,-117
    80005654:	e199                	bnez	a1,8000565a <printf+0x2cc>
    80005656:	e80795e3          	bnez	a5,800054e0 <printf+0x152>
    } else if(c0 == 'x'){
    8000565a:	ebaa01e3          	beq	s4,s10,800054fc <printf+0x16e>
    } else if(c0 == 'l' && c1 == 'x'){
    8000565e:	f8860613          	addi	a2,a2,-120
    80005662:	e219                	bnez	a2,80005668 <printf+0x2da>
    80005664:	ea0718e3          	bnez	a4,80005514 <printf+0x186>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    80005668:	f8868693          	addi	a3,a3,-120
    8000566c:	e299                	bnez	a3,80005672 <printf+0x2e4>
    8000566e:	ec0790e3          	bnez	a5,8000552e <printf+0x1a0>
    } else if(c0 == 'p'){
    80005672:	07000793          	li	a5,112
    80005676:	ecfa0ae3          	beq	s4,a5,8000554a <printf+0x1bc>
    } else if(c0 == 's'){
    8000567a:	07300793          	li	a5,115
    8000567e:	f0fa09e3          	beq	s4,a5,80005590 <printf+0x202>
    } else if(c0 == '%'){
    80005682:	02500793          	li	a5,37
    80005686:	f4fa01e3          	beq	s4,a5,800055c8 <printf+0x23a>
    } else if(c0 == 0){
    8000568a:	f40a03e3          	beqz	s4,800055d0 <printf+0x242>
      consputc('%');
    8000568e:	02500513          	li	a0,37
    80005692:	a7dff0ef          	jal	8000510e <consputc>
      consputc(c0);
    80005696:	8552                	mv	a0,s4
    80005698:	a77ff0ef          	jal	8000510e <consputc>
    8000569c:	bb9d                	j	80005412 <printf+0x84>

000000008000569e <panic>:

void
panic(char *s)
{
    8000569e:	1101                	addi	sp,sp,-32
    800056a0:	ec06                	sd	ra,24(sp)
    800056a2:	e822                	sd	s0,16(sp)
    800056a4:	e426                	sd	s1,8(sp)
    800056a6:	1000                	addi	s0,sp,32
    800056a8:	84aa                	mv	s1,a0
  pr.locking = 0;
    800056aa:	0001b797          	auipc	a5,0x1b
    800056ae:	7e07ab23          	sw	zero,2038(a5) # 80020ea0 <pr+0x18>
  printf("panic: ");
    800056b2:	00002517          	auipc	a0,0x2
    800056b6:	0ae50513          	addi	a0,a0,174 # 80007760 <etext+0x760>
    800056ba:	cd5ff0ef          	jal	8000538e <printf>
  printf("%s\n", s);
    800056be:	85a6                	mv	a1,s1
    800056c0:	00002517          	auipc	a0,0x2
    800056c4:	0a850513          	addi	a0,a0,168 # 80007768 <etext+0x768>
    800056c8:	cc7ff0ef          	jal	8000538e <printf>
  panicked = 1; // freeze uart output from other CPUs
    800056cc:	4785                	li	a5,1
    800056ce:	00002717          	auipc	a4,0x2
    800056d2:	2cf72723          	sw	a5,718(a4) # 8000799c <panicked>
  for(;;)
    800056d6:	a001                	j	800056d6 <panic+0x38>

00000000800056d8 <printfinit>:
    ;
}

void
printfinit(void)
{
    800056d8:	1141                	addi	sp,sp,-16
    800056da:	e406                	sd	ra,8(sp)
    800056dc:	e022                	sd	s0,0(sp)
    800056de:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    800056e0:	00002597          	auipc	a1,0x2
    800056e4:	09058593          	addi	a1,a1,144 # 80007770 <etext+0x770>
    800056e8:	0001b517          	auipc	a0,0x1b
    800056ec:	7a050513          	addi	a0,a0,1952 # 80020e88 <pr>
    800056f0:	262000ef          	jal	80005952 <initlock>
  pr.locking = 1;
    800056f4:	4785                	li	a5,1
    800056f6:	0001b717          	auipc	a4,0x1b
    800056fa:	7af72523          	sw	a5,1962(a4) # 80020ea0 <pr+0x18>
}
    800056fe:	60a2                	ld	ra,8(sp)
    80005700:	6402                	ld	s0,0(sp)
    80005702:	0141                	addi	sp,sp,16
    80005704:	8082                	ret

0000000080005706 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80005706:	1141                	addi	sp,sp,-16
    80005708:	e406                	sd	ra,8(sp)
    8000570a:	e022                	sd	s0,0(sp)
    8000570c:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000570e:	100007b7          	lui	a5,0x10000
    80005712:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80005716:	10000737          	lui	a4,0x10000
    8000571a:	f8000693          	li	a3,-128
    8000571e:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005722:	468d                	li	a3,3
    80005724:	10000637          	lui	a2,0x10000
    80005728:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000572c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80005730:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80005734:	8732                	mv	a4,a2
    80005736:	461d                	li	a2,7
    80005738:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000573c:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80005740:	00002597          	auipc	a1,0x2
    80005744:	03858593          	addi	a1,a1,56 # 80007778 <etext+0x778>
    80005748:	0001b517          	auipc	a0,0x1b
    8000574c:	76050513          	addi	a0,a0,1888 # 80020ea8 <uart_tx_lock>
    80005750:	202000ef          	jal	80005952 <initlock>
}
    80005754:	60a2                	ld	ra,8(sp)
    80005756:	6402                	ld	s0,0(sp)
    80005758:	0141                	addi	sp,sp,16
    8000575a:	8082                	ret

000000008000575c <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000575c:	1101                	addi	sp,sp,-32
    8000575e:	ec06                	sd	ra,24(sp)
    80005760:	e822                	sd	s0,16(sp)
    80005762:	e426                	sd	s1,8(sp)
    80005764:	1000                	addi	s0,sp,32
    80005766:	84aa                	mv	s1,a0
  push_off();
    80005768:	230000ef          	jal	80005998 <push_off>

  if(panicked){
    8000576c:	00002797          	auipc	a5,0x2
    80005770:	2307a783          	lw	a5,560(a5) # 8000799c <panicked>
    80005774:	e795                	bnez	a5,800057a0 <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80005776:	10000737          	lui	a4,0x10000
    8000577a:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    8000577c:	00074783          	lbu	a5,0(a4)
    80005780:	0207f793          	andi	a5,a5,32
    80005784:	dfe5                	beqz	a5,8000577c <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    80005786:	0ff4f513          	zext.b	a0,s1
    8000578a:	100007b7          	lui	a5,0x10000
    8000578e:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80005792:	28e000ef          	jal	80005a20 <pop_off>
}
    80005796:	60e2                	ld	ra,24(sp)
    80005798:	6442                	ld	s0,16(sp)
    8000579a:	64a2                	ld	s1,8(sp)
    8000579c:	6105                	addi	sp,sp,32
    8000579e:	8082                	ret
    for(;;)
    800057a0:	a001                	j	800057a0 <uartputc_sync+0x44>

00000000800057a2 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800057a2:	00002797          	auipc	a5,0x2
    800057a6:	1fe7b783          	ld	a5,510(a5) # 800079a0 <uart_tx_r>
    800057aa:	00002717          	auipc	a4,0x2
    800057ae:	1fe73703          	ld	a4,510(a4) # 800079a8 <uart_tx_w>
    800057b2:	08f70163          	beq	a4,a5,80005834 <uartstart+0x92>
{
    800057b6:	7139                	addi	sp,sp,-64
    800057b8:	fc06                	sd	ra,56(sp)
    800057ba:	f822                	sd	s0,48(sp)
    800057bc:	f426                	sd	s1,40(sp)
    800057be:	f04a                	sd	s2,32(sp)
    800057c0:	ec4e                	sd	s3,24(sp)
    800057c2:	e852                	sd	s4,16(sp)
    800057c4:	e456                	sd	s5,8(sp)
    800057c6:	e05a                	sd	s6,0(sp)
    800057c8:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800057ca:	10000937          	lui	s2,0x10000
    800057ce:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800057d0:	0001ba97          	auipc	s5,0x1b
    800057d4:	6d8a8a93          	addi	s5,s5,1752 # 80020ea8 <uart_tx_lock>
    uart_tx_r += 1;
    800057d8:	00002497          	auipc	s1,0x2
    800057dc:	1c848493          	addi	s1,s1,456 # 800079a0 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    800057e0:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    800057e4:	00002997          	auipc	s3,0x2
    800057e8:	1c498993          	addi	s3,s3,452 # 800079a8 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800057ec:	00094703          	lbu	a4,0(s2)
    800057f0:	02077713          	andi	a4,a4,32
    800057f4:	c715                	beqz	a4,80005820 <uartstart+0x7e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800057f6:	01f7f713          	andi	a4,a5,31
    800057fa:	9756                	add	a4,a4,s5
    800057fc:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    80005800:	0785                	addi	a5,a5,1
    80005802:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80005804:	8526                	mv	a0,s1
    80005806:	d53fb0ef          	jal	80001558 <wakeup>
    WriteReg(THR, c);
    8000580a:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    8000580e:	609c                	ld	a5,0(s1)
    80005810:	0009b703          	ld	a4,0(s3)
    80005814:	fcf71ce3          	bne	a4,a5,800057ec <uartstart+0x4a>
      ReadReg(ISR);
    80005818:	100007b7          	lui	a5,0x10000
    8000581c:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005820:	70e2                	ld	ra,56(sp)
    80005822:	7442                	ld	s0,48(sp)
    80005824:	74a2                	ld	s1,40(sp)
    80005826:	7902                	ld	s2,32(sp)
    80005828:	69e2                	ld	s3,24(sp)
    8000582a:	6a42                	ld	s4,16(sp)
    8000582c:	6aa2                	ld	s5,8(sp)
    8000582e:	6b02                	ld	s6,0(sp)
    80005830:	6121                	addi	sp,sp,64
    80005832:	8082                	ret
      ReadReg(ISR);
    80005834:	100007b7          	lui	a5,0x10000
    80005838:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    8000583c:	8082                	ret

000000008000583e <uartputc>:
{
    8000583e:	7179                	addi	sp,sp,-48
    80005840:	f406                	sd	ra,40(sp)
    80005842:	f022                	sd	s0,32(sp)
    80005844:	ec26                	sd	s1,24(sp)
    80005846:	e84a                	sd	s2,16(sp)
    80005848:	e44e                	sd	s3,8(sp)
    8000584a:	e052                	sd	s4,0(sp)
    8000584c:	1800                	addi	s0,sp,48
    8000584e:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    80005850:	0001b517          	auipc	a0,0x1b
    80005854:	65850513          	addi	a0,a0,1624 # 80020ea8 <uart_tx_lock>
    80005858:	184000ef          	jal	800059dc <acquire>
  if(panicked){
    8000585c:	00002797          	auipc	a5,0x2
    80005860:	1407a783          	lw	a5,320(a5) # 8000799c <panicked>
    80005864:	e3d1                	bnez	a5,800058e8 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80005866:	00002717          	auipc	a4,0x2
    8000586a:	14273703          	ld	a4,322(a4) # 800079a8 <uart_tx_w>
    8000586e:	00002797          	auipc	a5,0x2
    80005872:	1327b783          	ld	a5,306(a5) # 800079a0 <uart_tx_r>
    80005876:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    8000587a:	0001b997          	auipc	s3,0x1b
    8000587e:	62e98993          	addi	s3,s3,1582 # 80020ea8 <uart_tx_lock>
    80005882:	00002497          	auipc	s1,0x2
    80005886:	11e48493          	addi	s1,s1,286 # 800079a0 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000588a:	00002917          	auipc	s2,0x2
    8000588e:	11e90913          	addi	s2,s2,286 # 800079a8 <uart_tx_w>
    80005892:	00e79d63          	bne	a5,a4,800058ac <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    80005896:	85ce                	mv	a1,s3
    80005898:	8526                	mv	a0,s1
    8000589a:	c73fb0ef          	jal	8000150c <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000589e:	00093703          	ld	a4,0(s2)
    800058a2:	609c                	ld	a5,0(s1)
    800058a4:	02078793          	addi	a5,a5,32
    800058a8:	fee787e3          	beq	a5,a4,80005896 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800058ac:	01f77693          	andi	a3,a4,31
    800058b0:	0001b797          	auipc	a5,0x1b
    800058b4:	5f878793          	addi	a5,a5,1528 # 80020ea8 <uart_tx_lock>
    800058b8:	97b6                	add	a5,a5,a3
    800058ba:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800058be:	0705                	addi	a4,a4,1
    800058c0:	00002797          	auipc	a5,0x2
    800058c4:	0ee7b423          	sd	a4,232(a5) # 800079a8 <uart_tx_w>
  uartstart();
    800058c8:	edbff0ef          	jal	800057a2 <uartstart>
  release(&uart_tx_lock);
    800058cc:	0001b517          	auipc	a0,0x1b
    800058d0:	5dc50513          	addi	a0,a0,1500 # 80020ea8 <uart_tx_lock>
    800058d4:	19c000ef          	jal	80005a70 <release>
}
    800058d8:	70a2                	ld	ra,40(sp)
    800058da:	7402                	ld	s0,32(sp)
    800058dc:	64e2                	ld	s1,24(sp)
    800058de:	6942                	ld	s2,16(sp)
    800058e0:	69a2                	ld	s3,8(sp)
    800058e2:	6a02                	ld	s4,0(sp)
    800058e4:	6145                	addi	sp,sp,48
    800058e6:	8082                	ret
    for(;;)
    800058e8:	a001                	j	800058e8 <uartputc+0xaa>

00000000800058ea <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800058ea:	1141                	addi	sp,sp,-16
    800058ec:	e406                	sd	ra,8(sp)
    800058ee:	e022                	sd	s0,0(sp)
    800058f0:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    800058f2:	100007b7          	lui	a5,0x10000
    800058f6:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800058fa:	8b85                	andi	a5,a5,1
    800058fc:	cb89                	beqz	a5,8000590e <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800058fe:	100007b7          	lui	a5,0x10000
    80005902:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80005906:	60a2                	ld	ra,8(sp)
    80005908:	6402                	ld	s0,0(sp)
    8000590a:	0141                	addi	sp,sp,16
    8000590c:	8082                	ret
    return -1;
    8000590e:	557d                	li	a0,-1
    80005910:	bfdd                	j	80005906 <uartgetc+0x1c>

0000000080005912 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80005912:	1101                	addi	sp,sp,-32
    80005914:	ec06                	sd	ra,24(sp)
    80005916:	e822                	sd	s0,16(sp)
    80005918:	e426                	sd	s1,8(sp)
    8000591a:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    8000591c:	54fd                	li	s1,-1
    int c = uartgetc();
    8000591e:	fcdff0ef          	jal	800058ea <uartgetc>
    if(c == -1)
    80005922:	00950563          	beq	a0,s1,8000592c <uartintr+0x1a>
      break;
    consoleintr(c);
    80005926:	81bff0ef          	jal	80005140 <consoleintr>
  while(1){
    8000592a:	bfd5                	j	8000591e <uartintr+0xc>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    8000592c:	0001b517          	auipc	a0,0x1b
    80005930:	57c50513          	addi	a0,a0,1404 # 80020ea8 <uart_tx_lock>
    80005934:	0a8000ef          	jal	800059dc <acquire>
  uartstart();
    80005938:	e6bff0ef          	jal	800057a2 <uartstart>
  release(&uart_tx_lock);
    8000593c:	0001b517          	auipc	a0,0x1b
    80005940:	56c50513          	addi	a0,a0,1388 # 80020ea8 <uart_tx_lock>
    80005944:	12c000ef          	jal	80005a70 <release>
}
    80005948:	60e2                	ld	ra,24(sp)
    8000594a:	6442                	ld	s0,16(sp)
    8000594c:	64a2                	ld	s1,8(sp)
    8000594e:	6105                	addi	sp,sp,32
    80005950:	8082                	ret

0000000080005952 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80005952:	1141                	addi	sp,sp,-16
    80005954:	e406                	sd	ra,8(sp)
    80005956:	e022                	sd	s0,0(sp)
    80005958:	0800                	addi	s0,sp,16
  lk->name = name;
    8000595a:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    8000595c:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80005960:	00053823          	sd	zero,16(a0)
}
    80005964:	60a2                	ld	ra,8(sp)
    80005966:	6402                	ld	s0,0(sp)
    80005968:	0141                	addi	sp,sp,16
    8000596a:	8082                	ret

000000008000596c <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    8000596c:	411c                	lw	a5,0(a0)
    8000596e:	e399                	bnez	a5,80005974 <holding+0x8>
    80005970:	4501                	li	a0,0
  return r;
}
    80005972:	8082                	ret
{
    80005974:	1101                	addi	sp,sp,-32
    80005976:	ec06                	sd	ra,24(sp)
    80005978:	e822                	sd	s0,16(sp)
    8000597a:	e426                	sd	s1,8(sp)
    8000597c:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    8000597e:	691c                	ld	a5,16(a0)
    80005980:	84be                	mv	s1,a5
    80005982:	d14fb0ef          	jal	80000e96 <mycpu>
    80005986:	40a48533          	sub	a0,s1,a0
    8000598a:	00153513          	seqz	a0,a0
}
    8000598e:	60e2                	ld	ra,24(sp)
    80005990:	6442                	ld	s0,16(sp)
    80005992:	64a2                	ld	s1,8(sp)
    80005994:	6105                	addi	sp,sp,32
    80005996:	8082                	ret

0000000080005998 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80005998:	1101                	addi	sp,sp,-32
    8000599a:	ec06                	sd	ra,24(sp)
    8000599c:	e822                	sd	s0,16(sp)
    8000599e:	e426                	sd	s1,8(sp)
    800059a0:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800059a2:	100027f3          	csrr	a5,sstatus
    800059a6:	84be                	mv	s1,a5
    800059a8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800059ac:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800059ae:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    800059b2:	ce4fb0ef          	jal	80000e96 <mycpu>
    800059b6:	5d3c                	lw	a5,120(a0)
    800059b8:	cb99                	beqz	a5,800059ce <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    800059ba:	cdcfb0ef          	jal	80000e96 <mycpu>
    800059be:	5d3c                	lw	a5,120(a0)
    800059c0:	2785                	addiw	a5,a5,1
    800059c2:	dd3c                	sw	a5,120(a0)
}
    800059c4:	60e2                	ld	ra,24(sp)
    800059c6:	6442                	ld	s0,16(sp)
    800059c8:	64a2                	ld	s1,8(sp)
    800059ca:	6105                	addi	sp,sp,32
    800059cc:	8082                	ret
    mycpu()->intena = old;
    800059ce:	cc8fb0ef          	jal	80000e96 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    800059d2:	0014d793          	srli	a5,s1,0x1
    800059d6:	8b85                	andi	a5,a5,1
    800059d8:	dd7c                	sw	a5,124(a0)
    800059da:	b7c5                	j	800059ba <push_off+0x22>

00000000800059dc <acquire>:
{
    800059dc:	1101                	addi	sp,sp,-32
    800059de:	ec06                	sd	ra,24(sp)
    800059e0:	e822                	sd	s0,16(sp)
    800059e2:	e426                	sd	s1,8(sp)
    800059e4:	1000                	addi	s0,sp,32
    800059e6:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    800059e8:	fb1ff0ef          	jal	80005998 <push_off>
  if(holding(lk))
    800059ec:	8526                	mv	a0,s1
    800059ee:	f7fff0ef          	jal	8000596c <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    800059f2:	4705                	li	a4,1
  if(holding(lk))
    800059f4:	e105                	bnez	a0,80005a14 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    800059f6:	87ba                	mv	a5,a4
    800059f8:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    800059fc:	2781                	sext.w	a5,a5
    800059fe:	ffe5                	bnez	a5,800059f6 <acquire+0x1a>
  __sync_synchronize();
    80005a00:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80005a04:	c92fb0ef          	jal	80000e96 <mycpu>
    80005a08:	e888                	sd	a0,16(s1)
}
    80005a0a:	60e2                	ld	ra,24(sp)
    80005a0c:	6442                	ld	s0,16(sp)
    80005a0e:	64a2                	ld	s1,8(sp)
    80005a10:	6105                	addi	sp,sp,32
    80005a12:	8082                	ret
    panic("acquire");
    80005a14:	00002517          	auipc	a0,0x2
    80005a18:	d6c50513          	addi	a0,a0,-660 # 80007780 <etext+0x780>
    80005a1c:	c83ff0ef          	jal	8000569e <panic>

0000000080005a20 <pop_off>:

void
pop_off(void)
{
    80005a20:	1141                	addi	sp,sp,-16
    80005a22:	e406                	sd	ra,8(sp)
    80005a24:	e022                	sd	s0,0(sp)
    80005a26:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005a28:	c6efb0ef          	jal	80000e96 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005a2c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80005a30:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005a32:	e39d                	bnez	a5,80005a58 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005a34:	5d3c                	lw	a5,120(a0)
    80005a36:	02f05763          	blez	a5,80005a64 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80005a3a:	37fd                	addiw	a5,a5,-1
    80005a3c:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80005a3e:	eb89                	bnez	a5,80005a50 <pop_off+0x30>
    80005a40:	5d7c                	lw	a5,124(a0)
    80005a42:	c799                	beqz	a5,80005a50 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005a44:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80005a48:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80005a4c:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80005a50:	60a2                	ld	ra,8(sp)
    80005a52:	6402                	ld	s0,0(sp)
    80005a54:	0141                	addi	sp,sp,16
    80005a56:	8082                	ret
    panic("pop_off - interruptible");
    80005a58:	00002517          	auipc	a0,0x2
    80005a5c:	d3050513          	addi	a0,a0,-720 # 80007788 <etext+0x788>
    80005a60:	c3fff0ef          	jal	8000569e <panic>
    panic("pop_off");
    80005a64:	00002517          	auipc	a0,0x2
    80005a68:	d3c50513          	addi	a0,a0,-708 # 800077a0 <etext+0x7a0>
    80005a6c:	c33ff0ef          	jal	8000569e <panic>

0000000080005a70 <release>:
{
    80005a70:	1101                	addi	sp,sp,-32
    80005a72:	ec06                	sd	ra,24(sp)
    80005a74:	e822                	sd	s0,16(sp)
    80005a76:	e426                	sd	s1,8(sp)
    80005a78:	1000                	addi	s0,sp,32
    80005a7a:	84aa                	mv	s1,a0
  if(!holding(lk))
    80005a7c:	ef1ff0ef          	jal	8000596c <holding>
    80005a80:	c105                	beqz	a0,80005aa0 <release+0x30>
  lk->cpu = 0;
    80005a82:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80005a86:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80005a8a:	0310000f          	fence	rw,w
    80005a8e:	0004a023          	sw	zero,0(s1)
  pop_off();
    80005a92:	f8fff0ef          	jal	80005a20 <pop_off>
}
    80005a96:	60e2                	ld	ra,24(sp)
    80005a98:	6442                	ld	s0,16(sp)
    80005a9a:	64a2                	ld	s1,8(sp)
    80005a9c:	6105                	addi	sp,sp,32
    80005a9e:	8082                	ret
    panic("release");
    80005aa0:	00002517          	auipc	a0,0x2
    80005aa4:	d0850513          	addi	a0,a0,-760 # 800077a8 <etext+0x7a8>
    80005aa8:	bf7ff0ef          	jal	8000569e <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
