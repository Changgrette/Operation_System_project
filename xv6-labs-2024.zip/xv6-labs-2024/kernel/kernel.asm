
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00019117          	auipc	sp,0x19
    80000004:	c0010113          	addi	sp,sp,-1024 # 80018c00 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	771040ef          	jal	80004f86 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
        kfree(p);
}

void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	1000                	addi	s0,sp,32
    struct run *r;

    if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end+8*PGSIZE || (uint64)pa >= PHYSTOP)
    80000026:	00029797          	auipc	a5,0x29
    8000002a:	cda78793          	addi	a5,a5,-806 # 80028d00 <end+0x8000>
    8000002e:	00f53733          	sltu	a4,a0,a5
    80000032:	47c5                	li	a5,17
    80000034:	07ee                	slli	a5,a5,0x1b
    80000036:	17fd                	addi	a5,a5,-1
    80000038:	00a7b7b3          	sltu	a5,a5,a0
    8000003c:	8fd9                	or	a5,a5,a4
    8000003e:	ef95                	bnez	a5,8000007a <kfree+0x5e>
    80000040:	84aa                	mv	s1,a0
    80000042:	03451793          	slli	a5,a0,0x34
    80000046:	eb95                	bnez	a5,8000007a <kfree+0x5e>
        panic("kfree");

    if(ref_cnt[((uint64)pa - (uint64)end) / PGSIZE] > 1){  // 修改了变量名
    80000048:	00021797          	auipc	a5,0x21
    8000004c:	cb878793          	addi	a5,a5,-840 # 80020d00 <end>
    80000050:	40f507b3          	sub	a5,a0,a5
    80000054:	83b1                	srli	a5,a5,0xc
    80000056:	00008717          	auipc	a4,0x8
    8000005a:	93a73703          	ld	a4,-1734(a4) # 80007990 <ref_cnt>
    8000005e:	97ba                	add	a5,a5,a4
    80000060:	0007c703          	lbu	a4,0(a5)
    80000064:	4685                	li	a3,1
    80000066:	02e6f063          	bgeu	a3,a4,80000086 <kfree+0x6a>
        ref_cnt[((uint64)pa - (uint64)end) / PGSIZE]--;  // 修改了变量名
    8000006a:	377d                	addiw	a4,a4,-1
    8000006c:	00e78023          	sb	a4,0(a5)

    acquire(&kmem.lock);
    r->next = kmem.freelist;
    kmem.freelist = r;
    release(&kmem.lock);
}
    80000070:	60e2                	ld	ra,24(sp)
    80000072:	6442                	ld	s0,16(sp)
    80000074:	64a2                	ld	s1,8(sp)
    80000076:	6105                	addi	sp,sp,32
    80000078:	8082                	ret
        panic("kfree");
    8000007a:	00007517          	auipc	a0,0x7
    8000007e:	f8650513          	addi	a0,a0,-122 # 80007000 <etext>
    80000082:	67c050ef          	jal	800056fe <panic>
    memset(pa, 1, PGSIZE);
    80000086:	6605                	lui	a2,0x1
    80000088:	4585                	li	a1,1
    8000008a:	192000ef          	jal	8000021c <memset>
    acquire(&kmem.lock);
    8000008e:	00008517          	auipc	a0,0x8
    80000092:	94250513          	addi	a0,a0,-1726 # 800079d0 <kmem>
    80000096:	1a7050ef          	jal	80005a3c <acquire>
    r->next = kmem.freelist;
    8000009a:	00008717          	auipc	a4,0x8
    8000009e:	93670713          	addi	a4,a4,-1738 # 800079d0 <kmem>
    800000a2:	6f1c                	ld	a5,24(a4)
    800000a4:	e09c                	sd	a5,0(s1)
    kmem.freelist = r;
    800000a6:	ef04                	sd	s1,24(a4)
    release(&kmem.lock);
    800000a8:	853a                	mv	a0,a4
    800000aa:	227050ef          	jal	80005ad0 <release>
    800000ae:	b7c9                	j	80000070 <kfree+0x54>

00000000800000b0 <freerange>:
{
    800000b0:	7179                	addi	sp,sp,-48
    800000b2:	f406                	sd	ra,40(sp)
    800000b4:	f022                	sd	s0,32(sp)
    800000b6:	ec26                	sd	s1,24(sp)
    800000b8:	1800                	addi	s0,sp,48
    p = (char*)PGROUNDUP((uint64)pa_start);
    800000ba:	6785                	lui	a5,0x1
    800000bc:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    800000c0:	00e504b3          	add	s1,a0,a4
    800000c4:	777d                	lui	a4,0xfffff
    800000c6:	8cf9                	and	s1,s1,a4
    for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000c8:	94be                	add	s1,s1,a5
    800000ca:	0295e263          	bltu	a1,s1,800000ee <freerange+0x3e>
    800000ce:	e84a                	sd	s2,16(sp)
    800000d0:	e44e                	sd	s3,8(sp)
    800000d2:	e052                	sd	s4,0(sp)
    800000d4:	892e                	mv	s2,a1
        kfree(p);
    800000d6:	8a3a                	mv	s4,a4
    for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000d8:	89be                	mv	s3,a5
        kfree(p);
    800000da:	01448533          	add	a0,s1,s4
    800000de:	f3fff0ef          	jal	8000001c <kfree>
    for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000e2:	94ce                	add	s1,s1,s3
    800000e4:	fe997be3          	bgeu	s2,s1,800000da <freerange+0x2a>
    800000e8:	6942                	ld	s2,16(sp)
    800000ea:	69a2                	ld	s3,8(sp)
    800000ec:	6a02                	ld	s4,0(sp)
}
    800000ee:	70a2                	ld	ra,40(sp)
    800000f0:	7402                	ld	s0,32(sp)
    800000f2:	64e2                	ld	s1,24(sp)
    800000f4:	6145                	addi	sp,sp,48
    800000f6:	8082                	ret

00000000800000f8 <kinit>:
{
    800000f8:	1141                	addi	sp,sp,-16
    800000fa:	e406                	sd	ra,8(sp)
    800000fc:	e022                	sd	s0,0(sp)
    800000fe:	0800                	addi	s0,sp,16
    initlock(&kmem.lock, "kmem");
    80000100:	00007597          	auipc	a1,0x7
    80000104:	f1058593          	addi	a1,a1,-240 # 80007010 <etext+0x10>
    80000108:	00008517          	auipc	a0,0x8
    8000010c:	8c850513          	addi	a0,a0,-1848 # 800079d0 <kmem>
    80000110:	0a3050ef          	jal	800059b2 <initlock>
    ref_cnt = (uint8*)end;  // 修改了变量名
    80000114:	00021797          	auipc	a5,0x21
    80000118:	bec78793          	addi	a5,a5,-1044 # 80020d00 <end>
    8000011c:	00008717          	auipc	a4,0x8
    80000120:	86f73a23          	sd	a5,-1932(a4) # 80007990 <ref_cnt>
    memset(ref_cnt, 0, 8*PGSIZE);
    80000124:	6621                	lui	a2,0x8
    80000126:	4581                	li	a1,0
    80000128:	853e                	mv	a0,a5
    8000012a:	0f2000ef          	jal	8000021c <memset>
    freerange(end+8*PGSIZE, (void*)PHYSTOP);
    8000012e:	45c5                	li	a1,17
    80000130:	05ee                	slli	a1,a1,0x1b
    80000132:	00029517          	auipc	a0,0x29
    80000136:	bce50513          	addi	a0,a0,-1074 # 80028d00 <end+0x8000>
    8000013a:	f77ff0ef          	jal	800000b0 <freerange>
}
    8000013e:	60a2                	ld	ra,8(sp)
    80000140:	6402                	ld	s0,0(sp)
    80000142:	0141                	addi	sp,sp,16
    80000144:	8082                	ret

0000000080000146 <kalloc>:

void *
kalloc(void)
{
    80000146:	1101                	addi	sp,sp,-32
    80000148:	ec06                	sd	ra,24(sp)
    8000014a:	e822                	sd	s0,16(sp)
    8000014c:	e426                	sd	s1,8(sp)
    8000014e:	1000                	addi	s0,sp,32
    struct run *r;

    acquire(&kmem.lock);
    80000150:	00008517          	auipc	a0,0x8
    80000154:	88050513          	addi	a0,a0,-1920 # 800079d0 <kmem>
    80000158:	0e5050ef          	jal	80005a3c <acquire>
    r = kmem.freelist;
    8000015c:	00008497          	auipc	s1,0x8
    80000160:	88c4b483          	ld	s1,-1908(s1) # 800079e8 <kmem+0x18>
    if(r)
    80000164:	c4b1                	beqz	s1,800001b0 <kalloc+0x6a>
        kmem.freelist = r->next;
    80000166:	609c                	ld	a5,0(s1)
    80000168:	00008717          	auipc	a4,0x8
    8000016c:	88f73023          	sd	a5,-1920(a4) # 800079e8 <kmem+0x18>
    release(&kmem.lock);
    80000170:	00008517          	auipc	a0,0x8
    80000174:	86050513          	addi	a0,a0,-1952 # 800079d0 <kmem>
    80000178:	159050ef          	jal	80005ad0 <release>

    if(r){
        memset((char*)r, 5, PGSIZE);
    8000017c:	6605                	lui	a2,0x1
    8000017e:	4595                	li	a1,5
    80000180:	8526                	mv	a0,s1
    80000182:	09a000ef          	jal	8000021c <memset>
        ref_cnt[((uint64)r - (uint64)end) / PGSIZE] = 1;
    80000186:	00021797          	auipc	a5,0x21
    8000018a:	b7a78793          	addi	a5,a5,-1158 # 80020d00 <end>
    8000018e:	40f487b3          	sub	a5,s1,a5
    80000192:	83b1                	srli	a5,a5,0xc
    80000194:	00007717          	auipc	a4,0x7
    80000198:	7fc73703          	ld	a4,2044(a4) # 80007990 <ref_cnt>
    8000019c:	97ba                	add	a5,a5,a4
    8000019e:	4705                	li	a4,1
    800001a0:	00e78023          	sb	a4,0(a5)
    }
    return (void*)r;
}
    800001a4:	8526                	mv	a0,s1
    800001a6:	60e2                	ld	ra,24(sp)
    800001a8:	6442                	ld	s0,16(sp)
    800001aa:	64a2                	ld	s1,8(sp)
    800001ac:	6105                	addi	sp,sp,32
    800001ae:	8082                	ret
    release(&kmem.lock);
    800001b0:	00008517          	auipc	a0,0x8
    800001b4:	82050513          	addi	a0,a0,-2016 # 800079d0 <kmem>
    800001b8:	119050ef          	jal	80005ad0 <release>
    if(r){
    800001bc:	b7e5                	j	800001a4 <kalloc+0x5e>

00000000800001be <ref_inc>:

int
ref_inc(void *pa)
{
    800001be:	1141                	addi	sp,sp,-16
    800001c0:	e406                	sd	ra,8(sp)
    800001c2:	e022                	sd	s0,0(sp)
    800001c4:	0800                	addi	s0,sp,16
    if ((uint64)pa < (uint64)end+8*PGSIZE || (uint64)pa >= PHYSTOP)
    800001c6:	00029797          	auipc	a5,0x29
    800001ca:	b3a78793          	addi	a5,a5,-1222 # 80028d00 <end+0x8000>
    800001ce:	04f56363          	bltu	a0,a5,80000214 <ref_inc+0x56>
    800001d2:	47c5                	li	a5,17
    800001d4:	07ee                	slli	a5,a5,0x1b
    800001d6:	17fd                	addi	a5,a5,-1
    800001d8:	02a7ee63          	bltu	a5,a0,80000214 <ref_inc+0x56>
        return -1;
    uint64 index = ((uint64)pa - (uint64)end) / PGSIZE;
    800001dc:	00021797          	auipc	a5,0x21
    800001e0:	b2478793          	addi	a5,a5,-1244 # 80020d00 <end>
    800001e4:	8d1d                	sub	a0,a0,a5
    800001e6:	8131                	srli	a0,a0,0xc
    if (ref_cnt[index] == 0)
    800001e8:	00007797          	auipc	a5,0x7
    800001ec:	7a87b783          	ld	a5,1960(a5) # 80007990 <ref_cnt>
    800001f0:	97aa                	add	a5,a5,a0
    800001f2:	0007c703          	lbu	a4,0(a5)
    800001f6:	c30d                	beqz	a4,80000218 <ref_inc+0x5a>
        return -1;
    ref_cnt[index]++;
    800001f8:	2705                	addiw	a4,a4,1
    800001fa:	00e78023          	sb	a4,0(a5)
    return ref_cnt[index];
    800001fe:	00007797          	auipc	a5,0x7
    80000202:	7927b783          	ld	a5,1938(a5) # 80007990 <ref_cnt>
    80000206:	97aa                	add	a5,a5,a0
    80000208:	0007c503          	lbu	a0,0(a5)
    8000020c:	60a2                	ld	ra,8(sp)
    8000020e:	6402                	ld	s0,0(sp)
    80000210:	0141                	addi	sp,sp,16
    80000212:	8082                	ret
        return -1;
    80000214:	557d                	li	a0,-1
    80000216:	bfdd                	j	8000020c <ref_inc+0x4e>
        return -1;
    80000218:	557d                	li	a0,-1
    8000021a:	bfcd                	j	8000020c <ref_inc+0x4e>

000000008000021c <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000021c:	1141                	addi	sp,sp,-16
    8000021e:	e406                	sd	ra,8(sp)
    80000220:	e022                	sd	s0,0(sp)
    80000222:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000224:	ca19                	beqz	a2,8000023a <memset+0x1e>
    80000226:	87aa                	mv	a5,a0
    80000228:	1602                	slli	a2,a2,0x20
    8000022a:	9201                	srli	a2,a2,0x20
    8000022c:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000230:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000234:	0785                	addi	a5,a5,1
    80000236:	fee79de3          	bne	a5,a4,80000230 <memset+0x14>
  }
  return dst;
}
    8000023a:	60a2                	ld	ra,8(sp)
    8000023c:	6402                	ld	s0,0(sp)
    8000023e:	0141                	addi	sp,sp,16
    80000240:	8082                	ret

0000000080000242 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000242:	1141                	addi	sp,sp,-16
    80000244:	e406                	sd	ra,8(sp)
    80000246:	e022                	sd	s0,0(sp)
    80000248:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    8000024a:	c61d                	beqz	a2,80000278 <memcmp+0x36>
    8000024c:	1602                	slli	a2,a2,0x20
    8000024e:	9201                	srli	a2,a2,0x20
    80000250:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000254:	00054783          	lbu	a5,0(a0)
    80000258:	0005c703          	lbu	a4,0(a1)
    8000025c:	00e79863          	bne	a5,a4,8000026c <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000260:	0505                	addi	a0,a0,1
    80000262:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000264:	fed518e3          	bne	a0,a3,80000254 <memcmp+0x12>
  }

  return 0;
    80000268:	4501                	li	a0,0
    8000026a:	a019                	j	80000270 <memcmp+0x2e>
      return *s1 - *s2;
    8000026c:	40e7853b          	subw	a0,a5,a4
}
    80000270:	60a2                	ld	ra,8(sp)
    80000272:	6402                	ld	s0,0(sp)
    80000274:	0141                	addi	sp,sp,16
    80000276:	8082                	ret
  return 0;
    80000278:	4501                	li	a0,0
    8000027a:	bfdd                	j	80000270 <memcmp+0x2e>

000000008000027c <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    8000027c:	1141                	addi	sp,sp,-16
    8000027e:	e406                	sd	ra,8(sp)
    80000280:	e022                	sd	s0,0(sp)
    80000282:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000284:	c205                	beqz	a2,800002a4 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000286:	02a5e363          	bltu	a1,a0,800002ac <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    8000028a:	1602                	slli	a2,a2,0x20
    8000028c:	9201                	srli	a2,a2,0x20
    8000028e:	00c587b3          	add	a5,a1,a2
{
    80000292:	872a                	mv	a4,a0
      *d++ = *s++;
    80000294:	0585                	addi	a1,a1,1
    80000296:	0705                	addi	a4,a4,1
    80000298:	fff5c683          	lbu	a3,-1(a1)
    8000029c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800002a0:	feb79ae3          	bne	a5,a1,80000294 <memmove+0x18>

  return dst;
}
    800002a4:	60a2                	ld	ra,8(sp)
    800002a6:	6402                	ld	s0,0(sp)
    800002a8:	0141                	addi	sp,sp,16
    800002aa:	8082                	ret
  if(s < d && s + n > d){
    800002ac:	02061693          	slli	a3,a2,0x20
    800002b0:	9281                	srli	a3,a3,0x20
    800002b2:	00d58733          	add	a4,a1,a3
    800002b6:	fce57ae3          	bgeu	a0,a4,8000028a <memmove+0xe>
    d += n;
    800002ba:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800002bc:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    800002c0:	1782                	slli	a5,a5,0x20
    800002c2:	9381                	srli	a5,a5,0x20
    800002c4:	fff7c793          	not	a5,a5
    800002c8:	97ba                	add	a5,a5,a4
      *--d = *--s;
    800002ca:	177d                	addi	a4,a4,-1
    800002cc:	16fd                	addi	a3,a3,-1
    800002ce:	00074603          	lbu	a2,0(a4)
    800002d2:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    800002d6:	fee79ae3          	bne	a5,a4,800002ca <memmove+0x4e>
    800002da:	b7e9                	j	800002a4 <memmove+0x28>

00000000800002dc <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    800002dc:	1141                	addi	sp,sp,-16
    800002de:	e406                	sd	ra,8(sp)
    800002e0:	e022                	sd	s0,0(sp)
    800002e2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    800002e4:	f99ff0ef          	jal	8000027c <memmove>
}
    800002e8:	60a2                	ld	ra,8(sp)
    800002ea:	6402                	ld	s0,0(sp)
    800002ec:	0141                	addi	sp,sp,16
    800002ee:	8082                	ret

00000000800002f0 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    800002f0:	1141                	addi	sp,sp,-16
    800002f2:	e406                	sd	ra,8(sp)
    800002f4:	e022                	sd	s0,0(sp)
    800002f6:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    800002f8:	ce11                	beqz	a2,80000314 <strncmp+0x24>
    800002fa:	00054783          	lbu	a5,0(a0)
    800002fe:	cf89                	beqz	a5,80000318 <strncmp+0x28>
    80000300:	0005c703          	lbu	a4,0(a1)
    80000304:	00f71a63          	bne	a4,a5,80000318 <strncmp+0x28>
    n--, p++, q++;
    80000308:	367d                	addiw	a2,a2,-1
    8000030a:	0505                	addi	a0,a0,1
    8000030c:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    8000030e:	f675                	bnez	a2,800002fa <strncmp+0xa>
  if(n == 0)
    return 0;
    80000310:	4501                	li	a0,0
    80000312:	a801                	j	80000322 <strncmp+0x32>
    80000314:	4501                	li	a0,0
    80000316:	a031                	j	80000322 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000318:	00054503          	lbu	a0,0(a0)
    8000031c:	0005c783          	lbu	a5,0(a1)
    80000320:	9d1d                	subw	a0,a0,a5
}
    80000322:	60a2                	ld	ra,8(sp)
    80000324:	6402                	ld	s0,0(sp)
    80000326:	0141                	addi	sp,sp,16
    80000328:	8082                	ret

000000008000032a <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    8000032a:	1141                	addi	sp,sp,-16
    8000032c:	e406                	sd	ra,8(sp)
    8000032e:	e022                	sd	s0,0(sp)
    80000330:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000332:	87aa                	mv	a5,a0
    80000334:	a011                	j	80000338 <strncpy+0xe>
    80000336:	8636                	mv	a2,a3
    80000338:	02c05863          	blez	a2,80000368 <strncpy+0x3e>
    8000033c:	fff6069b          	addiw	a3,a2,-1
    80000340:	8836                	mv	a6,a3
    80000342:	0785                	addi	a5,a5,1
    80000344:	0005c703          	lbu	a4,0(a1)
    80000348:	fee78fa3          	sb	a4,-1(a5)
    8000034c:	0585                	addi	a1,a1,1
    8000034e:	f765                	bnez	a4,80000336 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000350:	873e                	mv	a4,a5
    80000352:	01005b63          	blez	a6,80000368 <strncpy+0x3e>
    80000356:	9fb1                	addw	a5,a5,a2
    80000358:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    8000035a:	0705                	addi	a4,a4,1
    8000035c:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000360:	40e786bb          	subw	a3,a5,a4
    80000364:	fed04be3          	bgtz	a3,8000035a <strncpy+0x30>
  return os;
}
    80000368:	60a2                	ld	ra,8(sp)
    8000036a:	6402                	ld	s0,0(sp)
    8000036c:	0141                	addi	sp,sp,16
    8000036e:	8082                	ret

0000000080000370 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000370:	1141                	addi	sp,sp,-16
    80000372:	e406                	sd	ra,8(sp)
    80000374:	e022                	sd	s0,0(sp)
    80000376:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000378:	02c05363          	blez	a2,8000039e <safestrcpy+0x2e>
    8000037c:	fff6069b          	addiw	a3,a2,-1
    80000380:	1682                	slli	a3,a3,0x20
    80000382:	9281                	srli	a3,a3,0x20
    80000384:	96ae                	add	a3,a3,a1
    80000386:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000388:	00d58963          	beq	a1,a3,8000039a <safestrcpy+0x2a>
    8000038c:	0585                	addi	a1,a1,1
    8000038e:	0785                	addi	a5,a5,1
    80000390:	fff5c703          	lbu	a4,-1(a1)
    80000394:	fee78fa3          	sb	a4,-1(a5)
    80000398:	fb65                	bnez	a4,80000388 <safestrcpy+0x18>
    ;
  *s = 0;
    8000039a:	00078023          	sb	zero,0(a5)
  return os;
}
    8000039e:	60a2                	ld	ra,8(sp)
    800003a0:	6402                	ld	s0,0(sp)
    800003a2:	0141                	addi	sp,sp,16
    800003a4:	8082                	ret

00000000800003a6 <strlen>:

int
strlen(const char *s)
{
    800003a6:	1141                	addi	sp,sp,-16
    800003a8:	e406                	sd	ra,8(sp)
    800003aa:	e022                	sd	s0,0(sp)
    800003ac:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800003ae:	00054783          	lbu	a5,0(a0)
    800003b2:	cf91                	beqz	a5,800003ce <strlen+0x28>
    800003b4:	00150793          	addi	a5,a0,1
    800003b8:	86be                	mv	a3,a5
    800003ba:	0785                	addi	a5,a5,1
    800003bc:	fff7c703          	lbu	a4,-1(a5)
    800003c0:	ff65                	bnez	a4,800003b8 <strlen+0x12>
    800003c2:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    800003c6:	60a2                	ld	ra,8(sp)
    800003c8:	6402                	ld	s0,0(sp)
    800003ca:	0141                	addi	sp,sp,16
    800003cc:	8082                	ret
  for(n = 0; s[n]; n++)
    800003ce:	4501                	li	a0,0
    800003d0:	bfdd                	j	800003c6 <strlen+0x20>

00000000800003d2 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    800003d2:	1141                	addi	sp,sp,-16
    800003d4:	e406                	sd	ra,8(sp)
    800003d6:	e022                	sd	s0,0(sp)
    800003d8:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800003da:	3d1000ef          	jal	80000faa <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    800003de:	00007717          	auipc	a4,0x7
    800003e2:	5ba70713          	addi	a4,a4,1466 # 80007998 <started>
  if(cpuid() == 0){
    800003e6:	c51d                	beqz	a0,80000414 <main+0x42>
    while(started == 0)
    800003e8:	431c                	lw	a5,0(a4)
    800003ea:	2781                	sext.w	a5,a5
    800003ec:	dff5                	beqz	a5,800003e8 <main+0x16>
      ;
    __sync_synchronize();
    800003ee:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    800003f2:	3b9000ef          	jal	80000faa <cpuid>
    800003f6:	85aa                	mv	a1,a0
    800003f8:	00007517          	auipc	a0,0x7
    800003fc:	c4050513          	addi	a0,a0,-960 # 80007038 <etext+0x38>
    80000400:	7ef040ef          	jal	800053ee <printf>
    kvminithart();    // turn on paging
    80000404:	080000ef          	jal	80000484 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000408:	6c8010ef          	jal	80001ad0 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    8000040c:	5bc040ef          	jal	800049c8 <plicinithart>
  }

  scheduler();        
    80000410:	004010ef          	jal	80001414 <scheduler>
    consoleinit();
    80000414:	701040ef          	jal	80005314 <consoleinit>
    printfinit();
    80000418:	320050ef          	jal	80005738 <printfinit>
    printf("\n");
    8000041c:	00007517          	auipc	a0,0x7
    80000420:	bfc50513          	addi	a0,a0,-1028 # 80007018 <etext+0x18>
    80000424:	7cb040ef          	jal	800053ee <printf>
    printf("xv6 kernel is booting\n");
    80000428:	00007517          	auipc	a0,0x7
    8000042c:	bf850513          	addi	a0,a0,-1032 # 80007020 <etext+0x20>
    80000430:	7bf040ef          	jal	800053ee <printf>
    printf("\n");
    80000434:	00007517          	auipc	a0,0x7
    80000438:	be450513          	addi	a0,a0,-1052 # 80007018 <etext+0x18>
    8000043c:	7b3040ef          	jal	800053ee <printf>
    kinit();         // physical page allocator
    80000440:	cb9ff0ef          	jal	800000f8 <kinit>
    kvminit();       // create kernel page table
    80000444:	2cc000ef          	jal	80000710 <kvminit>
    kvminithart();   // turn on paging
    80000448:	03c000ef          	jal	80000484 <kvminithart>
    procinit();      // process table
    8000044c:	2a9000ef          	jal	80000ef4 <procinit>
    trapinit();      // trap vectors
    80000450:	65c010ef          	jal	80001aac <trapinit>
    trapinithart();  // install kernel trap vector
    80000454:	67c010ef          	jal	80001ad0 <trapinithart>
    plicinit();      // set up interrupt controller
    80000458:	556040ef          	jal	800049ae <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    8000045c:	56c040ef          	jal	800049c8 <plicinithart>
    binit();         // buffer cache
    80000460:	4c1010ef          	jal	80002120 <binit>
    iinit();         // inode table
    80000464:	27c020ef          	jal	800026e0 <iinit>
    fileinit();      // file table
    80000468:	062030ef          	jal	800034ca <fileinit>
    virtio_disk_init(); // emulated hard disk
    8000046c:	64c040ef          	jal	80004ab8 <virtio_disk_init>
    userinit();      // first user process
    80000470:	5d9000ef          	jal	80001248 <userinit>
    __sync_synchronize();
    80000474:	0330000f          	fence	rw,rw
    started = 1;
    80000478:	4785                	li	a5,1
    8000047a:	00007717          	auipc	a4,0x7
    8000047e:	50f72f23          	sw	a5,1310(a4) # 80007998 <started>
    80000482:	b779                	j	80000410 <main+0x3e>

0000000080000484 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000484:	1141                	addi	sp,sp,-16
    80000486:	e406                	sd	ra,8(sp)
    80000488:	e022                	sd	s0,0(sp)
    8000048a:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    8000048c:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000490:	00007797          	auipc	a5,0x7
    80000494:	5107b783          	ld	a5,1296(a5) # 800079a0 <kernel_pagetable>
    80000498:	83b1                	srli	a5,a5,0xc
    8000049a:	577d                	li	a4,-1
    8000049c:	177e                	slli	a4,a4,0x3f
    8000049e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800004a0:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800004a4:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    800004a8:	60a2                	ld	ra,8(sp)
    800004aa:	6402                	ld	s0,0(sp)
    800004ac:	0141                	addi	sp,sp,16
    800004ae:	8082                	ret

00000000800004b0 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800004b0:	7139                	addi	sp,sp,-64
    800004b2:	fc06                	sd	ra,56(sp)
    800004b4:	f822                	sd	s0,48(sp)
    800004b6:	f426                	sd	s1,40(sp)
    800004b8:	f04a                	sd	s2,32(sp)
    800004ba:	ec4e                	sd	s3,24(sp)
    800004bc:	e852                	sd	s4,16(sp)
    800004be:	e456                	sd	s5,8(sp)
    800004c0:	e05a                	sd	s6,0(sp)
    800004c2:	0080                	addi	s0,sp,64
    800004c4:	84aa                	mv	s1,a0
    800004c6:	89ae                	mv	s3,a1
    800004c8:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    800004ca:	57fd                	li	a5,-1
    800004cc:	83e9                	srli	a5,a5,0x1a
    800004ce:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    800004d0:	4ab1                	li	s5,12
  if(va >= MAXVA)
    800004d2:	04b7e263          	bltu	a5,a1,80000516 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    800004d6:	0149d933          	srl	s2,s3,s4
    800004da:	1ff97913          	andi	s2,s2,511
    800004de:	090e                	slli	s2,s2,0x3
    800004e0:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    800004e2:	00093483          	ld	s1,0(s2)
    800004e6:	0014f793          	andi	a5,s1,1
    800004ea:	cf85                	beqz	a5,80000522 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    800004ec:	80a9                	srli	s1,s1,0xa
    800004ee:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    800004f0:	3a5d                	addiw	s4,s4,-9
    800004f2:	ff5a12e3          	bne	s4,s5,800004d6 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    800004f6:	00c9d513          	srli	a0,s3,0xc
    800004fa:	1ff57513          	andi	a0,a0,511
    800004fe:	050e                	slli	a0,a0,0x3
    80000500:	9526                	add	a0,a0,s1
}
    80000502:	70e2                	ld	ra,56(sp)
    80000504:	7442                	ld	s0,48(sp)
    80000506:	74a2                	ld	s1,40(sp)
    80000508:	7902                	ld	s2,32(sp)
    8000050a:	69e2                	ld	s3,24(sp)
    8000050c:	6a42                	ld	s4,16(sp)
    8000050e:	6aa2                	ld	s5,8(sp)
    80000510:	6b02                	ld	s6,0(sp)
    80000512:	6121                	addi	sp,sp,64
    80000514:	8082                	ret
    panic("walk");
    80000516:	00007517          	auipc	a0,0x7
    8000051a:	b3a50513          	addi	a0,a0,-1222 # 80007050 <etext+0x50>
    8000051e:	1e0050ef          	jal	800056fe <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000522:	020b0263          	beqz	s6,80000546 <walk+0x96>
    80000526:	c21ff0ef          	jal	80000146 <kalloc>
    8000052a:	84aa                	mv	s1,a0
    8000052c:	d979                	beqz	a0,80000502 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    8000052e:	6605                	lui	a2,0x1
    80000530:	4581                	li	a1,0
    80000532:	cebff0ef          	jal	8000021c <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000536:	00c4d793          	srli	a5,s1,0xc
    8000053a:	07aa                	slli	a5,a5,0xa
    8000053c:	0017e793          	ori	a5,a5,1
    80000540:	00f93023          	sd	a5,0(s2)
    80000544:	b775                	j	800004f0 <walk+0x40>
        return 0;
    80000546:	4501                	li	a0,0
    80000548:	bf6d                	j	80000502 <walk+0x52>

000000008000054a <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000054a:	57fd                	li	a5,-1
    8000054c:	83e9                	srli	a5,a5,0x1a
    8000054e:	00b7f463          	bgeu	a5,a1,80000556 <walkaddr+0xc>
    return 0;
    80000552:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000554:	8082                	ret
{
    80000556:	1141                	addi	sp,sp,-16
    80000558:	e406                	sd	ra,8(sp)
    8000055a:	e022                	sd	s0,0(sp)
    8000055c:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000055e:	4601                	li	a2,0
    80000560:	f51ff0ef          	jal	800004b0 <walk>
  if(pte == 0)
    80000564:	c901                	beqz	a0,80000574 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    80000566:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000568:	0117f693          	andi	a3,a5,17
    8000056c:	4745                	li	a4,17
    return 0;
    8000056e:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000570:	00e68663          	beq	a3,a4,8000057c <walkaddr+0x32>
}
    80000574:	60a2                	ld	ra,8(sp)
    80000576:	6402                	ld	s0,0(sp)
    80000578:	0141                	addi	sp,sp,16
    8000057a:	8082                	ret
  pa = PTE2PA(*pte);
    8000057c:	83a9                	srli	a5,a5,0xa
    8000057e:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000582:	bfcd                	j	80000574 <walkaddr+0x2a>

0000000080000584 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000584:	715d                	addi	sp,sp,-80
    80000586:	e486                	sd	ra,72(sp)
    80000588:	e0a2                	sd	s0,64(sp)
    8000058a:	fc26                	sd	s1,56(sp)
    8000058c:	f84a                	sd	s2,48(sp)
    8000058e:	f44e                	sd	s3,40(sp)
    80000590:	f052                	sd	s4,32(sp)
    80000592:	ec56                	sd	s5,24(sp)
    80000594:	e85a                	sd	s6,16(sp)
    80000596:	e45e                	sd	s7,8(sp)
    80000598:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000059a:	03459793          	slli	a5,a1,0x34
    8000059e:	eba1                	bnez	a5,800005ee <mappages+0x6a>
    800005a0:	8a2a                	mv	s4,a0
    800005a2:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800005a4:	03461793          	slli	a5,a2,0x34
    800005a8:	eba9                	bnez	a5,800005fa <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    800005aa:	ce31                	beqz	a2,80000606 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800005ac:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    800005b0:	80060613          	addi	a2,a2,-2048
    800005b4:	00b60933          	add	s2,a2,a1
  a = va;
    800005b8:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800005ba:	4b05                	li	s6,1
    800005bc:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800005c0:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    800005c2:	865a                	mv	a2,s6
    800005c4:	85a6                	mv	a1,s1
    800005c6:	8552                	mv	a0,s4
    800005c8:	ee9ff0ef          	jal	800004b0 <walk>
    800005cc:	c929                	beqz	a0,8000061e <mappages+0x9a>
    if(*pte & PTE_V)
    800005ce:	611c                	ld	a5,0(a0)
    800005d0:	8b85                	andi	a5,a5,1
    800005d2:	e3a1                	bnez	a5,80000612 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800005d4:	013487b3          	add	a5,s1,s3
    800005d8:	83b1                	srli	a5,a5,0xc
    800005da:	07aa                	slli	a5,a5,0xa
    800005dc:	0157e7b3          	or	a5,a5,s5
    800005e0:	0017e793          	ori	a5,a5,1
    800005e4:	e11c                	sd	a5,0(a0)
    if(a == last)
    800005e6:	05248863          	beq	s1,s2,80000636 <mappages+0xb2>
    a += PGSIZE;
    800005ea:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800005ec:	bfd9                	j	800005c2 <mappages+0x3e>
    panic("mappages: va not aligned");
    800005ee:	00007517          	auipc	a0,0x7
    800005f2:	a6a50513          	addi	a0,a0,-1430 # 80007058 <etext+0x58>
    800005f6:	108050ef          	jal	800056fe <panic>
    panic("mappages: size not aligned");
    800005fa:	00007517          	auipc	a0,0x7
    800005fe:	a7e50513          	addi	a0,a0,-1410 # 80007078 <etext+0x78>
    80000602:	0fc050ef          	jal	800056fe <panic>
    panic("mappages: size");
    80000606:	00007517          	auipc	a0,0x7
    8000060a:	a9250513          	addi	a0,a0,-1390 # 80007098 <etext+0x98>
    8000060e:	0f0050ef          	jal	800056fe <panic>
      panic("mappages: remap");
    80000612:	00007517          	auipc	a0,0x7
    80000616:	a9650513          	addi	a0,a0,-1386 # 800070a8 <etext+0xa8>
    8000061a:	0e4050ef          	jal	800056fe <panic>
      return -1;
    8000061e:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80000620:	60a6                	ld	ra,72(sp)
    80000622:	6406                	ld	s0,64(sp)
    80000624:	74e2                	ld	s1,56(sp)
    80000626:	7942                	ld	s2,48(sp)
    80000628:	79a2                	ld	s3,40(sp)
    8000062a:	7a02                	ld	s4,32(sp)
    8000062c:	6ae2                	ld	s5,24(sp)
    8000062e:	6b42                	ld	s6,16(sp)
    80000630:	6ba2                	ld	s7,8(sp)
    80000632:	6161                	addi	sp,sp,80
    80000634:	8082                	ret
  return 0;
    80000636:	4501                	li	a0,0
    80000638:	b7e5                	j	80000620 <mappages+0x9c>

000000008000063a <kvmmap>:
{
    8000063a:	1141                	addi	sp,sp,-16
    8000063c:	e406                	sd	ra,8(sp)
    8000063e:	e022                	sd	s0,0(sp)
    80000640:	0800                	addi	s0,sp,16
    80000642:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000644:	86b2                	mv	a3,a2
    80000646:	863e                	mv	a2,a5
    80000648:	f3dff0ef          	jal	80000584 <mappages>
    8000064c:	e509                	bnez	a0,80000656 <kvmmap+0x1c>
}
    8000064e:	60a2                	ld	ra,8(sp)
    80000650:	6402                	ld	s0,0(sp)
    80000652:	0141                	addi	sp,sp,16
    80000654:	8082                	ret
    panic("kvmmap");
    80000656:	00007517          	auipc	a0,0x7
    8000065a:	a6250513          	addi	a0,a0,-1438 # 800070b8 <etext+0xb8>
    8000065e:	0a0050ef          	jal	800056fe <panic>

0000000080000662 <kvmmake>:
{
    80000662:	1101                	addi	sp,sp,-32
    80000664:	ec06                	sd	ra,24(sp)
    80000666:	e822                	sd	s0,16(sp)
    80000668:	e426                	sd	s1,8(sp)
    8000066a:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000066c:	adbff0ef          	jal	80000146 <kalloc>
    80000670:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80000672:	6605                	lui	a2,0x1
    80000674:	4581                	li	a1,0
    80000676:	ba7ff0ef          	jal	8000021c <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000067a:	4719                	li	a4,6
    8000067c:	6685                	lui	a3,0x1
    8000067e:	10000637          	lui	a2,0x10000
    80000682:	85b2                	mv	a1,a2
    80000684:	8526                	mv	a0,s1
    80000686:	fb5ff0ef          	jal	8000063a <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000068a:	4719                	li	a4,6
    8000068c:	6685                	lui	a3,0x1
    8000068e:	10001637          	lui	a2,0x10001
    80000692:	85b2                	mv	a1,a2
    80000694:	8526                	mv	a0,s1
    80000696:	fa5ff0ef          	jal	8000063a <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000069a:	4719                	li	a4,6
    8000069c:	040006b7          	lui	a3,0x4000
    800006a0:	0c000637          	lui	a2,0xc000
    800006a4:	85b2                	mv	a1,a2
    800006a6:	8526                	mv	a0,s1
    800006a8:	f93ff0ef          	jal	8000063a <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800006ac:	4729                	li	a4,10
    800006ae:	80007697          	auipc	a3,0x80007
    800006b2:	95268693          	addi	a3,a3,-1710 # 7000 <_entry-0x7fff9000>
    800006b6:	4605                	li	a2,1
    800006b8:	067e                	slli	a2,a2,0x1f
    800006ba:	85b2                	mv	a1,a2
    800006bc:	8526                	mv	a0,s1
    800006be:	f7dff0ef          	jal	8000063a <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800006c2:	4719                	li	a4,6
    800006c4:	00007697          	auipc	a3,0x7
    800006c8:	93c68693          	addi	a3,a3,-1732 # 80007000 <etext>
    800006cc:	47c5                	li	a5,17
    800006ce:	07ee                	slli	a5,a5,0x1b
    800006d0:	40d786b3          	sub	a3,a5,a3
    800006d4:	00007617          	auipc	a2,0x7
    800006d8:	92c60613          	addi	a2,a2,-1748 # 80007000 <etext>
    800006dc:	85b2                	mv	a1,a2
    800006de:	8526                	mv	a0,s1
    800006e0:	f5bff0ef          	jal	8000063a <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800006e4:	4729                	li	a4,10
    800006e6:	6685                	lui	a3,0x1
    800006e8:	00006617          	auipc	a2,0x6
    800006ec:	91860613          	addi	a2,a2,-1768 # 80006000 <_trampoline>
    800006f0:	040005b7          	lui	a1,0x4000
    800006f4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800006f6:	05b2                	slli	a1,a1,0xc
    800006f8:	8526                	mv	a0,s1
    800006fa:	f41ff0ef          	jal	8000063a <kvmmap>
  proc_mapstacks(kpgtbl);
    800006fe:	8526                	mv	a0,s1
    80000700:	750000ef          	jal	80000e50 <proc_mapstacks>
}
    80000704:	8526                	mv	a0,s1
    80000706:	60e2                	ld	ra,24(sp)
    80000708:	6442                	ld	s0,16(sp)
    8000070a:	64a2                	ld	s1,8(sp)
    8000070c:	6105                	addi	sp,sp,32
    8000070e:	8082                	ret

0000000080000710 <kvminit>:
{
    80000710:	1141                	addi	sp,sp,-16
    80000712:	e406                	sd	ra,8(sp)
    80000714:	e022                	sd	s0,0(sp)
    80000716:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80000718:	f4bff0ef          	jal	80000662 <kvmmake>
    8000071c:	00007797          	auipc	a5,0x7
    80000720:	28a7b223          	sd	a0,644(a5) # 800079a0 <kernel_pagetable>
}
    80000724:	60a2                	ld	ra,8(sp)
    80000726:	6402                	ld	s0,0(sp)
    80000728:	0141                	addi	sp,sp,16
    8000072a:	8082                	ret

000000008000072c <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000072c:	715d                	addi	sp,sp,-80
    8000072e:	e486                	sd	ra,72(sp)
    80000730:	e0a2                	sd	s0,64(sp)
    80000732:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80000734:	03459793          	slli	a5,a1,0x34
    80000738:	e39d                	bnez	a5,8000075e <uvmunmap+0x32>
    8000073a:	f84a                	sd	s2,48(sp)
    8000073c:	f44e                	sd	s3,40(sp)
    8000073e:	f052                	sd	s4,32(sp)
    80000740:	ec56                	sd	s5,24(sp)
    80000742:	e85a                	sd	s6,16(sp)
    80000744:	e45e                	sd	s7,8(sp)
    80000746:	8a2a                	mv	s4,a0
    80000748:	892e                	mv	s2,a1
    8000074a:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000074c:	0632                	slli	a2,a2,0xc
    8000074e:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    80000752:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80000754:	6b05                	lui	s6,0x1
    80000756:	0735ff63          	bgeu	a1,s3,800007d4 <uvmunmap+0xa8>
    8000075a:	fc26                	sd	s1,56(sp)
    8000075c:	a0a9                	j	800007a6 <uvmunmap+0x7a>
    8000075e:	fc26                	sd	s1,56(sp)
    80000760:	f84a                	sd	s2,48(sp)
    80000762:	f44e                	sd	s3,40(sp)
    80000764:	f052                	sd	s4,32(sp)
    80000766:	ec56                	sd	s5,24(sp)
    80000768:	e85a                	sd	s6,16(sp)
    8000076a:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    8000076c:	00007517          	auipc	a0,0x7
    80000770:	95450513          	addi	a0,a0,-1708 # 800070c0 <etext+0xc0>
    80000774:	78b040ef          	jal	800056fe <panic>
      panic("uvmunmap: walk");
    80000778:	00007517          	auipc	a0,0x7
    8000077c:	96050513          	addi	a0,a0,-1696 # 800070d8 <etext+0xd8>
    80000780:	77f040ef          	jal	800056fe <panic>
      panic("uvmunmap: not mapped");
    80000784:	00007517          	auipc	a0,0x7
    80000788:	96450513          	addi	a0,a0,-1692 # 800070e8 <etext+0xe8>
    8000078c:	773040ef          	jal	800056fe <panic>
      panic("uvmunmap: not a leaf");
    80000790:	00007517          	auipc	a0,0x7
    80000794:	97050513          	addi	a0,a0,-1680 # 80007100 <etext+0x100>
    80000798:	767040ef          	jal	800056fe <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    8000079c:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800007a0:	995a                	add	s2,s2,s6
    800007a2:	03397863          	bgeu	s2,s3,800007d2 <uvmunmap+0xa6>
    if((pte = walk(pagetable, a, 0)) == 0)
    800007a6:	4601                	li	a2,0
    800007a8:	85ca                	mv	a1,s2
    800007aa:	8552                	mv	a0,s4
    800007ac:	d05ff0ef          	jal	800004b0 <walk>
    800007b0:	84aa                	mv	s1,a0
    800007b2:	d179                	beqz	a0,80000778 <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0)
    800007b4:	6108                	ld	a0,0(a0)
    800007b6:	00157793          	andi	a5,a0,1
    800007ba:	d7e9                	beqz	a5,80000784 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    800007bc:	3ff57793          	andi	a5,a0,1023
    800007c0:	fd7788e3          	beq	a5,s7,80000790 <uvmunmap+0x64>
    if(do_free){
    800007c4:	fc0a8ce3          	beqz	s5,8000079c <uvmunmap+0x70>
      uint64 pa = PTE2PA(*pte);
    800007c8:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    800007ca:	0532                	slli	a0,a0,0xc
    800007cc:	851ff0ef          	jal	8000001c <kfree>
    800007d0:	b7f1                	j	8000079c <uvmunmap+0x70>
    800007d2:	74e2                	ld	s1,56(sp)
    800007d4:	7942                	ld	s2,48(sp)
    800007d6:	79a2                	ld	s3,40(sp)
    800007d8:	7a02                	ld	s4,32(sp)
    800007da:	6ae2                	ld	s5,24(sp)
    800007dc:	6b42                	ld	s6,16(sp)
    800007de:	6ba2                	ld	s7,8(sp)
  }
}
    800007e0:	60a6                	ld	ra,72(sp)
    800007e2:	6406                	ld	s0,64(sp)
    800007e4:	6161                	addi	sp,sp,80
    800007e6:	8082                	ret

00000000800007e8 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800007e8:	1101                	addi	sp,sp,-32
    800007ea:	ec06                	sd	ra,24(sp)
    800007ec:	e822                	sd	s0,16(sp)
    800007ee:	e426                	sd	s1,8(sp)
    800007f0:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    800007f2:	955ff0ef          	jal	80000146 <kalloc>
    800007f6:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800007f8:	c509                	beqz	a0,80000802 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800007fa:	6605                	lui	a2,0x1
    800007fc:	4581                	li	a1,0
    800007fe:	a1fff0ef          	jal	8000021c <memset>
  return pagetable;
}
    80000802:	8526                	mv	a0,s1
    80000804:	60e2                	ld	ra,24(sp)
    80000806:	6442                	ld	s0,16(sp)
    80000808:	64a2                	ld	s1,8(sp)
    8000080a:	6105                	addi	sp,sp,32
    8000080c:	8082                	ret

000000008000080e <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    8000080e:	7179                	addi	sp,sp,-48
    80000810:	f406                	sd	ra,40(sp)
    80000812:	f022                	sd	s0,32(sp)
    80000814:	ec26                	sd	s1,24(sp)
    80000816:	e84a                	sd	s2,16(sp)
    80000818:	e44e                	sd	s3,8(sp)
    8000081a:	e052                	sd	s4,0(sp)
    8000081c:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    8000081e:	6785                	lui	a5,0x1
    80000820:	04f67063          	bgeu	a2,a5,80000860 <uvmfirst+0x52>
    80000824:	89aa                	mv	s3,a0
    80000826:	8a2e                	mv	s4,a1
    80000828:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    8000082a:	91dff0ef          	jal	80000146 <kalloc>
    8000082e:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000830:	6605                	lui	a2,0x1
    80000832:	4581                	li	a1,0
    80000834:	9e9ff0ef          	jal	8000021c <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    80000838:	4779                	li	a4,30
    8000083a:	86ca                	mv	a3,s2
    8000083c:	6605                	lui	a2,0x1
    8000083e:	4581                	li	a1,0
    80000840:	854e                	mv	a0,s3
    80000842:	d43ff0ef          	jal	80000584 <mappages>
  memmove(mem, src, sz);
    80000846:	8626                	mv	a2,s1
    80000848:	85d2                	mv	a1,s4
    8000084a:	854a                	mv	a0,s2
    8000084c:	a31ff0ef          	jal	8000027c <memmove>
}
    80000850:	70a2                	ld	ra,40(sp)
    80000852:	7402                	ld	s0,32(sp)
    80000854:	64e2                	ld	s1,24(sp)
    80000856:	6942                	ld	s2,16(sp)
    80000858:	69a2                	ld	s3,8(sp)
    8000085a:	6a02                	ld	s4,0(sp)
    8000085c:	6145                	addi	sp,sp,48
    8000085e:	8082                	ret
    panic("uvmfirst: more than a page");
    80000860:	00007517          	auipc	a0,0x7
    80000864:	8b850513          	addi	a0,a0,-1864 # 80007118 <etext+0x118>
    80000868:	697040ef          	jal	800056fe <panic>

000000008000086c <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    8000086c:	1101                	addi	sp,sp,-32
    8000086e:	ec06                	sd	ra,24(sp)
    80000870:	e822                	sd	s0,16(sp)
    80000872:	e426                	sd	s1,8(sp)
    80000874:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80000876:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    80000878:	00b67d63          	bgeu	a2,a1,80000892 <uvmdealloc+0x26>
    8000087c:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    8000087e:	6785                	lui	a5,0x1
    80000880:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000882:	00f60733          	add	a4,a2,a5
    80000886:	76fd                	lui	a3,0xfffff
    80000888:	8f75                	and	a4,a4,a3
    8000088a:	97ae                	add	a5,a5,a1
    8000088c:	8ff5                	and	a5,a5,a3
    8000088e:	00f76863          	bltu	a4,a5,8000089e <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80000892:	8526                	mv	a0,s1
    80000894:	60e2                	ld	ra,24(sp)
    80000896:	6442                	ld	s0,16(sp)
    80000898:	64a2                	ld	s1,8(sp)
    8000089a:	6105                	addi	sp,sp,32
    8000089c:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000089e:	8f99                	sub	a5,a5,a4
    800008a0:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800008a2:	4685                	li	a3,1
    800008a4:	0007861b          	sext.w	a2,a5
    800008a8:	85ba                	mv	a1,a4
    800008aa:	e83ff0ef          	jal	8000072c <uvmunmap>
    800008ae:	b7d5                	j	80000892 <uvmdealloc+0x26>

00000000800008b0 <uvmalloc>:
  if(newsz < oldsz)
    800008b0:	0ab66163          	bltu	a2,a1,80000952 <uvmalloc+0xa2>
{
    800008b4:	715d                	addi	sp,sp,-80
    800008b6:	e486                	sd	ra,72(sp)
    800008b8:	e0a2                	sd	s0,64(sp)
    800008ba:	f84a                	sd	s2,48(sp)
    800008bc:	f052                	sd	s4,32(sp)
    800008be:	ec56                	sd	s5,24(sp)
    800008c0:	e45e                	sd	s7,8(sp)
    800008c2:	0880                	addi	s0,sp,80
    800008c4:	8aaa                	mv	s5,a0
    800008c6:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800008c8:	6785                	lui	a5,0x1
    800008ca:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800008cc:	95be                	add	a1,a1,a5
    800008ce:	77fd                	lui	a5,0xfffff
    800008d0:	00f5f933          	and	s2,a1,a5
    800008d4:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    800008d6:	08c97063          	bgeu	s2,a2,80000956 <uvmalloc+0xa6>
    800008da:	fc26                	sd	s1,56(sp)
    800008dc:	f44e                	sd	s3,40(sp)
    800008de:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    800008e0:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800008e2:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800008e6:	861ff0ef          	jal	80000146 <kalloc>
    800008ea:	84aa                	mv	s1,a0
    if(mem == 0){
    800008ec:	c50d                	beqz	a0,80000916 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    800008ee:	864e                	mv	a2,s3
    800008f0:	4581                	li	a1,0
    800008f2:	92bff0ef          	jal	8000021c <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800008f6:	875a                	mv	a4,s6
    800008f8:	86a6                	mv	a3,s1
    800008fa:	864e                	mv	a2,s3
    800008fc:	85ca                	mv	a1,s2
    800008fe:	8556                	mv	a0,s5
    80000900:	c85ff0ef          	jal	80000584 <mappages>
    80000904:	e915                	bnez	a0,80000938 <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000906:	994e                	add	s2,s2,s3
    80000908:	fd496fe3          	bltu	s2,s4,800008e6 <uvmalloc+0x36>
  return newsz;
    8000090c:	8552                	mv	a0,s4
    8000090e:	74e2                	ld	s1,56(sp)
    80000910:	79a2                	ld	s3,40(sp)
    80000912:	6b42                	ld	s6,16(sp)
    80000914:	a811                	j	80000928 <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80000916:	865e                	mv	a2,s7
    80000918:	85ca                	mv	a1,s2
    8000091a:	8556                	mv	a0,s5
    8000091c:	f51ff0ef          	jal	8000086c <uvmdealloc>
      return 0;
    80000920:	4501                	li	a0,0
    80000922:	74e2                	ld	s1,56(sp)
    80000924:	79a2                	ld	s3,40(sp)
    80000926:	6b42                	ld	s6,16(sp)
}
    80000928:	60a6                	ld	ra,72(sp)
    8000092a:	6406                	ld	s0,64(sp)
    8000092c:	7942                	ld	s2,48(sp)
    8000092e:	7a02                	ld	s4,32(sp)
    80000930:	6ae2                	ld	s5,24(sp)
    80000932:	6ba2                	ld	s7,8(sp)
    80000934:	6161                	addi	sp,sp,80
    80000936:	8082                	ret
      kfree(mem);
    80000938:	8526                	mv	a0,s1
    8000093a:	ee2ff0ef          	jal	8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000093e:	865e                	mv	a2,s7
    80000940:	85ca                	mv	a1,s2
    80000942:	8556                	mv	a0,s5
    80000944:	f29ff0ef          	jal	8000086c <uvmdealloc>
      return 0;
    80000948:	4501                	li	a0,0
    8000094a:	74e2                	ld	s1,56(sp)
    8000094c:	79a2                	ld	s3,40(sp)
    8000094e:	6b42                	ld	s6,16(sp)
    80000950:	bfe1                	j	80000928 <uvmalloc+0x78>
    return oldsz;
    80000952:	852e                	mv	a0,a1
}
    80000954:	8082                	ret
  return newsz;
    80000956:	8532                	mv	a0,a2
    80000958:	bfc1                	j	80000928 <uvmalloc+0x78>

000000008000095a <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000095a:	7179                	addi	sp,sp,-48
    8000095c:	f406                	sd	ra,40(sp)
    8000095e:	f022                	sd	s0,32(sp)
    80000960:	ec26                	sd	s1,24(sp)
    80000962:	e84a                	sd	s2,16(sp)
    80000964:	e44e                	sd	s3,8(sp)
    80000966:	1800                	addi	s0,sp,48
    80000968:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000096a:	84aa                	mv	s1,a0
    8000096c:	6905                	lui	s2,0x1
    8000096e:	992a                	add	s2,s2,a0
    80000970:	a811                	j	80000984 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    80000972:	00006517          	auipc	a0,0x6
    80000976:	7c650513          	addi	a0,a0,1990 # 80007138 <etext+0x138>
    8000097a:	585040ef          	jal	800056fe <panic>
  for(int i = 0; i < 512; i++){
    8000097e:	04a1                	addi	s1,s1,8
    80000980:	03248163          	beq	s1,s2,800009a2 <freewalk+0x48>
    pte_t pte = pagetable[i];
    80000984:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000986:	0017f713          	andi	a4,a5,1
    8000098a:	db75                	beqz	a4,8000097e <freewalk+0x24>
    8000098c:	00e7f713          	andi	a4,a5,14
    80000990:	f36d                	bnez	a4,80000972 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80000992:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80000994:	00c79513          	slli	a0,a5,0xc
    80000998:	fc3ff0ef          	jal	8000095a <freewalk>
      pagetable[i] = 0;
    8000099c:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800009a0:	bff9                	j	8000097e <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800009a2:	854e                	mv	a0,s3
    800009a4:	e78ff0ef          	jal	8000001c <kfree>
}
    800009a8:	70a2                	ld	ra,40(sp)
    800009aa:	7402                	ld	s0,32(sp)
    800009ac:	64e2                	ld	s1,24(sp)
    800009ae:	6942                	ld	s2,16(sp)
    800009b0:	69a2                	ld	s3,8(sp)
    800009b2:	6145                	addi	sp,sp,48
    800009b4:	8082                	ret

00000000800009b6 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800009b6:	1101                	addi	sp,sp,-32
    800009b8:	ec06                	sd	ra,24(sp)
    800009ba:	e822                	sd	s0,16(sp)
    800009bc:	e426                	sd	s1,8(sp)
    800009be:	1000                	addi	s0,sp,32
    800009c0:	84aa                	mv	s1,a0
  if(sz > 0)
    800009c2:	e989                	bnez	a1,800009d4 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800009c4:	8526                	mv	a0,s1
    800009c6:	f95ff0ef          	jal	8000095a <freewalk>
}
    800009ca:	60e2                	ld	ra,24(sp)
    800009cc:	6442                	ld	s0,16(sp)
    800009ce:	64a2                	ld	s1,8(sp)
    800009d0:	6105                	addi	sp,sp,32
    800009d2:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800009d4:	6785                	lui	a5,0x1
    800009d6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800009d8:	95be                	add	a1,a1,a5
    800009da:	4685                	li	a3,1
    800009dc:	00c5d613          	srli	a2,a1,0xc
    800009e0:	4581                	li	a1,0
    800009e2:	d4bff0ef          	jal	8000072c <uvmunmap>
    800009e6:	bff9                	j	800009c4 <uvmfree+0xe>

00000000800009e8 <uvmcopy>:
// physical memory.
// returns 0 on success, -1 on failure.
// frees any allocated pages on failure.
int
uvmcopy(pagetable_t old, pagetable_t new, uint64 sz)
{
    800009e8:	715d                	addi	sp,sp,-80
    800009ea:	e486                	sd	ra,72(sp)
    800009ec:	e0a2                	sd	s0,64(sp)
    800009ee:	e45e                	sd	s7,8(sp)
    800009f0:	0880                	addi	s0,sp,80
    pte_t *pte;
    uint64 pa, i;
    uint flags;

    for(i = 0; i < sz; i += PGSIZE){
    800009f2:	ca55                	beqz	a2,80000aa6 <uvmcopy+0xbe>
    800009f4:	fc26                	sd	s1,56(sp)
    800009f6:	f84a                	sd	s2,48(sp)
    800009f8:	f44e                	sd	s3,40(sp)
    800009fa:	f052                	sd	s4,32(sp)
    800009fc:	ec56                	sd	s5,24(sp)
    800009fe:	e85a                	sd	s6,16(sp)
    80000a00:	8b2a                	mv	s6,a0
    80000a02:	8aae                	mv	s5,a1
    80000a04:	8a32                	mv	s4,a2
    80000a06:	4481                	li	s1,0
            *pte &= ~PTE_W;
            *pte |= PTE_COW;
        }
        pa = PTE2PA(*pte);
        flags = PTE_FLAGS(*pte);
        if(mappages(new, i, PGSIZE, (uint64)pa, flags) != 0)
    80000a08:	6985                	lui	s3,0x1
    80000a0a:	a089                	j	80000a4c <uvmcopy+0x64>
            panic("uvmcopy: pte should exist");
    80000a0c:	00006517          	auipc	a0,0x6
    80000a10:	73c50513          	addi	a0,a0,1852 # 80007148 <etext+0x148>
    80000a14:	4eb040ef          	jal	800056fe <panic>
            panic("uvmcopy: page not present");
    80000a18:	00006517          	auipc	a0,0x6
    80000a1c:	75050513          	addi	a0,a0,1872 # 80007168 <etext+0x168>
    80000a20:	4df040ef          	jal	800056fe <panic>
        pa = PTE2PA(*pte);
    80000a24:	6118                	ld	a4,0(a0)
    80000a26:	00a75913          	srli	s2,a4,0xa
    80000a2a:	0932                	slli	s2,s2,0xc
        if(mappages(new, i, PGSIZE, (uint64)pa, flags) != 0)
    80000a2c:	3ff77713          	andi	a4,a4,1023
    80000a30:	86ca                	mv	a3,s2
    80000a32:	864e                	mv	a2,s3
    80000a34:	85a6                	mv	a1,s1
    80000a36:	8556                	mv	a0,s5
    80000a38:	b4dff0ef          	jal	80000584 <mappages>
    80000a3c:	8baa                	mv	s7,a0
    80000a3e:	e90d                	bnez	a0,80000a70 <uvmcopy+0x88>
            goto err;
        ref_inc((void*)pa);  // 修改了函数名
    80000a40:	854a                	mv	a0,s2
    80000a42:	f7cff0ef          	jal	800001be <ref_inc>
    for(i = 0; i < sz; i += PGSIZE){
    80000a46:	94ce                	add	s1,s1,s3
    80000a48:	0544f863          	bgeu	s1,s4,80000a98 <uvmcopy+0xb0>
        if((pte = walk(old, i, 0)) == 0)
    80000a4c:	4601                	li	a2,0
    80000a4e:	85a6                	mv	a1,s1
    80000a50:	855a                	mv	a0,s6
    80000a52:	a5fff0ef          	jal	800004b0 <walk>
    80000a56:	d95d                	beqz	a0,80000a0c <uvmcopy+0x24>
        if((*pte & PTE_V) == 0)
    80000a58:	611c                	ld	a5,0(a0)
    80000a5a:	0017f713          	andi	a4,a5,1
    80000a5e:	df4d                	beqz	a4,80000a18 <uvmcopy+0x30>
        if(*pte & PTE_W){
    80000a60:	0047f713          	andi	a4,a5,4
    80000a64:	d361                	beqz	a4,80000a24 <uvmcopy+0x3c>
            *pte &= ~PTE_W;
    80000a66:	9bed                	andi	a5,a5,-5
            *pte |= PTE_COW;
    80000a68:	1007e793          	ori	a5,a5,256
    80000a6c:	e11c                	sd	a5,0(a0)
    80000a6e:	bf5d                	j	80000a24 <uvmcopy+0x3c>
    }
    return 0;

    err:
    uvmunmap(new, 0, i / PGSIZE, 1);
    80000a70:	4685                	li	a3,1
    80000a72:	00c4d613          	srli	a2,s1,0xc
    80000a76:	4581                	li	a1,0
    80000a78:	8556                	mv	a0,s5
    80000a7a:	cb3ff0ef          	jal	8000072c <uvmunmap>
    return -1;
    80000a7e:	5bfd                	li	s7,-1
    80000a80:	74e2                	ld	s1,56(sp)
    80000a82:	7942                	ld	s2,48(sp)
    80000a84:	79a2                	ld	s3,40(sp)
    80000a86:	7a02                	ld	s4,32(sp)
    80000a88:	6ae2                	ld	s5,24(sp)
    80000a8a:	6b42                	ld	s6,16(sp)
}
    80000a8c:	855e                	mv	a0,s7
    80000a8e:	60a6                	ld	ra,72(sp)
    80000a90:	6406                	ld	s0,64(sp)
    80000a92:	6ba2                	ld	s7,8(sp)
    80000a94:	6161                	addi	sp,sp,80
    80000a96:	8082                	ret
    80000a98:	74e2                	ld	s1,56(sp)
    80000a9a:	7942                	ld	s2,48(sp)
    80000a9c:	79a2                	ld	s3,40(sp)
    80000a9e:	7a02                	ld	s4,32(sp)
    80000aa0:	6ae2                	ld	s5,24(sp)
    80000aa2:	6b42                	ld	s6,16(sp)
    80000aa4:	b7e5                	j	80000a8c <uvmcopy+0xa4>
    return 0;
    80000aa6:	4b81                	li	s7,0
    80000aa8:	b7d5                	j	80000a8c <uvmcopy+0xa4>

0000000080000aaa <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80000aaa:	1141                	addi	sp,sp,-16
    80000aac:	e406                	sd	ra,8(sp)
    80000aae:	e022                	sd	s0,0(sp)
    80000ab0:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80000ab2:	4601                	li	a2,0
    80000ab4:	9fdff0ef          	jal	800004b0 <walk>
  if(pte == 0)
    80000ab8:	c901                	beqz	a0,80000ac8 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80000aba:	611c                	ld	a5,0(a0)
    80000abc:	9bbd                	andi	a5,a5,-17
    80000abe:	e11c                	sd	a5,0(a0)
}
    80000ac0:	60a2                	ld	ra,8(sp)
    80000ac2:	6402                	ld	s0,0(sp)
    80000ac4:	0141                	addi	sp,sp,16
    80000ac6:	8082                	ret
    panic("uvmclear");
    80000ac8:	00006517          	auipc	a0,0x6
    80000acc:	6c050513          	addi	a0,a0,1728 # 80007188 <etext+0x188>
    80000ad0:	42f040ef          	jal	800056fe <panic>

0000000080000ad4 <copyout>:
// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error.
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
    80000ad4:	7119                	addi	sp,sp,-128
    80000ad6:	fc86                	sd	ra,120(sp)
    80000ad8:	f8a2                	sd	s0,112(sp)
    80000ada:	0100                	addi	s0,sp,128
    80000adc:	f8a43423          	sd	a0,-120(s0)
    uint64 n, va0, pa0;
    pte_t *pte;

    while(len > 0){
    80000ae0:	cef9                	beqz	a3,80000bbe <copyout+0xea>
    80000ae2:	f4a6                	sd	s1,104(sp)
    80000ae4:	f0ca                	sd	s2,96(sp)
    80000ae6:	ecce                	sd	s3,88(sp)
    80000ae8:	e8d2                	sd	s4,80(sp)
    80000aea:	e4d6                	sd	s5,72(sp)
    80000aec:	e0da                	sd	s6,64(sp)
    80000aee:	fc5e                	sd	s7,56(sp)
    80000af0:	f862                	sd	s8,48(sp)
    80000af2:	f466                	sd	s9,40(sp)
    80000af4:	f06a                	sd	s10,32(sp)
    80000af6:	ec6e                	sd	s11,24(sp)
    80000af8:	892e                	mv	s2,a1
    80000afa:	8b32                	mv	s6,a2
    80000afc:	8ab6                	mv	s5,a3
        va0 = PGROUNDDOWN(dstva);
    80000afe:	7d7d                	lui	s10,0xfffff
        if(va0 >= MAXVA)
    80000b00:	5cfd                	li	s9,-1
    80000b02:	01acdc93          	srli	s9,s9,0x1a
            return -1;
        pte = walk(pagetable, va0, 0);
        if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000b06:	4dc5                	li	s11,17
            return -1;
        pa0 = PTE2PA(*pte);
        n = PGSIZE - (dstva - va0);
        if(n > len)
            n = len;
        if((*pte & PTE_W) == 0 && (*pte & PTE_COW) != 0){  // 修改了标志名
    80000b08:	10000b93          	li	s7,256
            char *mem = kalloc();
            if (mem == 0)
                return -1;
            memmove(mem, (char*)pa0, PGSIZE);
    80000b0c:	6c05                	lui	s8,0x1
    80000b0e:	a8a1                	j	80000b66 <copyout+0x92>
            char *mem = kalloc();
    80000b10:	e36ff0ef          	jal	80000146 <kalloc>
            if (mem == 0)
    80000b14:	10050e63          	beqz	a0,80000c30 <copyout+0x15c>
            memmove(mem, (char*)pa0, PGSIZE);
    80000b18:	f8943023          	sd	s1,-128(s0)
    80000b1c:	8662                	mv	a2,s8
    80000b1e:	85a6                	mv	a1,s1
    80000b20:	84aa                	mv	s1,a0
    80000b22:	f5aff0ef          	jal	8000027c <memmove>
            *pte = PA2PTE(mem) | PTE_FLAGS(*pte) | PTE_W;
    80000b26:	00c4d793          	srli	a5,s1,0xc
    80000b2a:	07aa                	slli	a5,a5,0xa
    80000b2c:	000a3703          	ld	a4,0(s4)
    80000b30:	3ff77713          	andi	a4,a4,1023
    80000b34:	8fd9                	or	a5,a5,a4
    80000b36:	0047e793          	ori	a5,a5,4
    80000b3a:	00fa3023          	sd	a5,0(s4)
            kfree((void*)pa0);
    80000b3e:	f8043503          	ld	a0,-128(s0)
    80000b42:	cdaff0ef          	jal	8000001c <kfree>
            pa0 = (uint64)mem;
    80000b46:	a881                	j	80000b96 <copyout+0xc2>
        }
        memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000b48:	41390533          	sub	a0,s2,s3
    80000b4c:	000a061b          	sext.w	a2,s4
    80000b50:	85da                	mv	a1,s6
    80000b52:	9526                	add	a0,a0,s1
    80000b54:	f28ff0ef          	jal	8000027c <memmove>

        len -= n;
    80000b58:	414a8ab3          	sub	s5,s5,s4
        src += n;
    80000b5c:	9b52                	add	s6,s6,s4
        dstva = va0 + PGSIZE;
    80000b5e:	01898933          	add	s2,s3,s8
    while(len > 0){
    80000b62:	040a8163          	beqz	s5,80000ba4 <copyout+0xd0>
        va0 = PGROUNDDOWN(dstva);
    80000b66:	01a979b3          	and	s3,s2,s10
        if(va0 >= MAXVA)
    80000b6a:	053cec63          	bltu	s9,s3,80000bc2 <copyout+0xee>
        pte = walk(pagetable, va0, 0);
    80000b6e:	4601                	li	a2,0
    80000b70:	85ce                	mv	a1,s3
    80000b72:	f8843503          	ld	a0,-120(s0)
    80000b76:	93bff0ef          	jal	800004b0 <walk>
    80000b7a:	8a2a                	mv	s4,a0
        if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000b7c:	c125                	beqz	a0,80000bdc <copyout+0x108>
    80000b7e:	6104                	ld	s1,0(a0)
    80000b80:	0114f793          	andi	a5,s1,17
    80000b84:	07b79963          	bne	a5,s11,80000bf6 <copyout+0x122>
    80000b88:	1044f793          	andi	a5,s1,260
           ((*pte & PTE_W) == 0 && (*pte & PTE_COW) == 0))  // 修改了标志名
    80000b8c:	c7c9                	beqz	a5,80000c16 <copyout+0x142>
        pa0 = PTE2PA(*pte);
    80000b8e:	80a9                	srli	s1,s1,0xa
    80000b90:	04b2                	slli	s1,s1,0xc
        if((*pte & PTE_W) == 0 && (*pte & PTE_COW) != 0){  // 修改了标志名
    80000b92:	f7778fe3          	beq	a5,s7,80000b10 <copyout+0x3c>
        n = PGSIZE - (dstva - va0);
    80000b96:	41298a33          	sub	s4,s3,s2
    80000b9a:	9a62                	add	s4,s4,s8
        if(n > len)
    80000b9c:	fb4af6e3          	bgeu	s5,s4,80000b48 <copyout+0x74>
    80000ba0:	8a56                	mv	s4,s5
    80000ba2:	b75d                	j	80000b48 <copyout+0x74>
    }
    return 0;
    80000ba4:	4501                	li	a0,0
    80000ba6:	74a6                	ld	s1,104(sp)
    80000ba8:	7906                	ld	s2,96(sp)
    80000baa:	69e6                	ld	s3,88(sp)
    80000bac:	6a46                	ld	s4,80(sp)
    80000bae:	6aa6                	ld	s5,72(sp)
    80000bb0:	6b06                	ld	s6,64(sp)
    80000bb2:	7be2                	ld	s7,56(sp)
    80000bb4:	7c42                	ld	s8,48(sp)
    80000bb6:	7ca2                	ld	s9,40(sp)
    80000bb8:	7d02                	ld	s10,32(sp)
    80000bba:	6de2                	ld	s11,24(sp)
    80000bbc:	a889                	j	80000c0e <copyout+0x13a>
    80000bbe:	4501                	li	a0,0
    80000bc0:	a0b9                	j	80000c0e <copyout+0x13a>
            return -1;
    80000bc2:	557d                	li	a0,-1
    80000bc4:	74a6                	ld	s1,104(sp)
    80000bc6:	7906                	ld	s2,96(sp)
    80000bc8:	69e6                	ld	s3,88(sp)
    80000bca:	6a46                	ld	s4,80(sp)
    80000bcc:	6aa6                	ld	s5,72(sp)
    80000bce:	6b06                	ld	s6,64(sp)
    80000bd0:	7be2                	ld	s7,56(sp)
    80000bd2:	7c42                	ld	s8,48(sp)
    80000bd4:	7ca2                	ld	s9,40(sp)
    80000bd6:	7d02                	ld	s10,32(sp)
    80000bd8:	6de2                	ld	s11,24(sp)
    80000bda:	a815                	j	80000c0e <copyout+0x13a>
            return -1;
    80000bdc:	557d                	li	a0,-1
    80000bde:	74a6                	ld	s1,104(sp)
    80000be0:	7906                	ld	s2,96(sp)
    80000be2:	69e6                	ld	s3,88(sp)
    80000be4:	6a46                	ld	s4,80(sp)
    80000be6:	6aa6                	ld	s5,72(sp)
    80000be8:	6b06                	ld	s6,64(sp)
    80000bea:	7be2                	ld	s7,56(sp)
    80000bec:	7c42                	ld	s8,48(sp)
    80000bee:	7ca2                	ld	s9,40(sp)
    80000bf0:	7d02                	ld	s10,32(sp)
    80000bf2:	6de2                	ld	s11,24(sp)
    80000bf4:	a829                	j	80000c0e <copyout+0x13a>
    80000bf6:	557d                	li	a0,-1
    80000bf8:	74a6                	ld	s1,104(sp)
    80000bfa:	7906                	ld	s2,96(sp)
    80000bfc:	69e6                	ld	s3,88(sp)
    80000bfe:	6a46                	ld	s4,80(sp)
    80000c00:	6aa6                	ld	s5,72(sp)
    80000c02:	6b06                	ld	s6,64(sp)
    80000c04:	7be2                	ld	s7,56(sp)
    80000c06:	7c42                	ld	s8,48(sp)
    80000c08:	7ca2                	ld	s9,40(sp)
    80000c0a:	7d02                	ld	s10,32(sp)
    80000c0c:	6de2                	ld	s11,24(sp)
}
    80000c0e:	70e6                	ld	ra,120(sp)
    80000c10:	7446                	ld	s0,112(sp)
    80000c12:	6109                	addi	sp,sp,128
    80000c14:	8082                	ret
            return -1;
    80000c16:	557d                	li	a0,-1
    80000c18:	74a6                	ld	s1,104(sp)
    80000c1a:	7906                	ld	s2,96(sp)
    80000c1c:	69e6                	ld	s3,88(sp)
    80000c1e:	6a46                	ld	s4,80(sp)
    80000c20:	6aa6                	ld	s5,72(sp)
    80000c22:	6b06                	ld	s6,64(sp)
    80000c24:	7be2                	ld	s7,56(sp)
    80000c26:	7c42                	ld	s8,48(sp)
    80000c28:	7ca2                	ld	s9,40(sp)
    80000c2a:	7d02                	ld	s10,32(sp)
    80000c2c:	6de2                	ld	s11,24(sp)
    80000c2e:	b7c5                	j	80000c0e <copyout+0x13a>
                return -1;
    80000c30:	557d                	li	a0,-1
    80000c32:	74a6                	ld	s1,104(sp)
    80000c34:	7906                	ld	s2,96(sp)
    80000c36:	69e6                	ld	s3,88(sp)
    80000c38:	6a46                	ld	s4,80(sp)
    80000c3a:	6aa6                	ld	s5,72(sp)
    80000c3c:	6b06                	ld	s6,64(sp)
    80000c3e:	7be2                	ld	s7,56(sp)
    80000c40:	7c42                	ld	s8,48(sp)
    80000c42:	7ca2                	ld	s9,40(sp)
    80000c44:	7d02                	ld	s10,32(sp)
    80000c46:	6de2                	ld	s11,24(sp)
    80000c48:	b7d9                	j	80000c0e <copyout+0x13a>

0000000080000c4a <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80000c4a:	c6a5                	beqz	a3,80000cb2 <copyin+0x68>
{
    80000c4c:	715d                	addi	sp,sp,-80
    80000c4e:	e486                	sd	ra,72(sp)
    80000c50:	e0a2                	sd	s0,64(sp)
    80000c52:	fc26                	sd	s1,56(sp)
    80000c54:	f84a                	sd	s2,48(sp)
    80000c56:	f44e                	sd	s3,40(sp)
    80000c58:	f052                	sd	s4,32(sp)
    80000c5a:	ec56                	sd	s5,24(sp)
    80000c5c:	e85a                	sd	s6,16(sp)
    80000c5e:	e45e                	sd	s7,8(sp)
    80000c60:	e062                	sd	s8,0(sp)
    80000c62:	0880                	addi	s0,sp,80
    80000c64:	8b2a                	mv	s6,a0
    80000c66:	8a2e                	mv	s4,a1
    80000c68:	8c32                	mv	s8,a2
    80000c6a:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000c6c:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000c6e:	6a85                	lui	s5,0x1
    80000c70:	a00d                	j	80000c92 <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000c72:	018505b3          	add	a1,a0,s8
    80000c76:	0004861b          	sext.w	a2,s1
    80000c7a:	412585b3          	sub	a1,a1,s2
    80000c7e:	8552                	mv	a0,s4
    80000c80:	dfcff0ef          	jal	8000027c <memmove>

    len -= n;
    80000c84:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000c88:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000c8a:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000c8e:	02098063          	beqz	s3,80000cae <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000c92:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000c96:	85ca                	mv	a1,s2
    80000c98:	855a                	mv	a0,s6
    80000c9a:	8b1ff0ef          	jal	8000054a <walkaddr>
    if(pa0 == 0)
    80000c9e:	cd01                	beqz	a0,80000cb6 <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000ca0:	418904b3          	sub	s1,s2,s8
    80000ca4:	94d6                	add	s1,s1,s5
    if(n > len)
    80000ca6:	fc99f6e3          	bgeu	s3,s1,80000c72 <copyin+0x28>
    80000caa:	84ce                	mv	s1,s3
    80000cac:	b7d9                	j	80000c72 <copyin+0x28>
  }
  return 0;
    80000cae:	4501                	li	a0,0
    80000cb0:	a021                	j	80000cb8 <copyin+0x6e>
    80000cb2:	4501                	li	a0,0
}
    80000cb4:	8082                	ret
      return -1;
    80000cb6:	557d                	li	a0,-1
}
    80000cb8:	60a6                	ld	ra,72(sp)
    80000cba:	6406                	ld	s0,64(sp)
    80000cbc:	74e2                	ld	s1,56(sp)
    80000cbe:	7942                	ld	s2,48(sp)
    80000cc0:	79a2                	ld	s3,40(sp)
    80000cc2:	7a02                	ld	s4,32(sp)
    80000cc4:	6ae2                	ld	s5,24(sp)
    80000cc6:	6b42                	ld	s6,16(sp)
    80000cc8:	6ba2                	ld	s7,8(sp)
    80000cca:	6c02                	ld	s8,0(sp)
    80000ccc:	6161                	addi	sp,sp,80
    80000cce:	8082                	ret

0000000080000cd0 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000cd0:	cac5                	beqz	a3,80000d80 <copyinstr+0xb0>
{
    80000cd2:	715d                	addi	sp,sp,-80
    80000cd4:	e486                	sd	ra,72(sp)
    80000cd6:	e0a2                	sd	s0,64(sp)
    80000cd8:	fc26                	sd	s1,56(sp)
    80000cda:	f84a                	sd	s2,48(sp)
    80000cdc:	f44e                	sd	s3,40(sp)
    80000cde:	f052                	sd	s4,32(sp)
    80000ce0:	ec56                	sd	s5,24(sp)
    80000ce2:	e85a                	sd	s6,16(sp)
    80000ce4:	e45e                	sd	s7,8(sp)
    80000ce6:	0880                	addi	s0,sp,80
    80000ce8:	8aaa                	mv	s5,a0
    80000cea:	84ae                	mv	s1,a1
    80000cec:	8bb2                	mv	s7,a2
    80000cee:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000cf0:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000cf2:	6a05                	lui	s4,0x1
    80000cf4:	a82d                	j	80000d2e <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000cf6:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80000cfa:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000cfc:	0017c793          	xori	a5,a5,1
    80000d00:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000d04:	60a6                	ld	ra,72(sp)
    80000d06:	6406                	ld	s0,64(sp)
    80000d08:	74e2                	ld	s1,56(sp)
    80000d0a:	7942                	ld	s2,48(sp)
    80000d0c:	79a2                	ld	s3,40(sp)
    80000d0e:	7a02                	ld	s4,32(sp)
    80000d10:	6ae2                	ld	s5,24(sp)
    80000d12:	6b42                	ld	s6,16(sp)
    80000d14:	6ba2                	ld	s7,8(sp)
    80000d16:	6161                	addi	sp,sp,80
    80000d18:	8082                	ret
    80000d1a:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80000d1e:	9726                	add	a4,a4,s1
      --max;
    80000d20:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80000d24:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80000d28:	04e58463          	beq	a1,a4,80000d70 <copyinstr+0xa0>
{
    80000d2c:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80000d2e:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80000d32:	85ca                	mv	a1,s2
    80000d34:	8556                	mv	a0,s5
    80000d36:	815ff0ef          	jal	8000054a <walkaddr>
    if(pa0 == 0)
    80000d3a:	cd0d                	beqz	a0,80000d74 <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80000d3c:	417906b3          	sub	a3,s2,s7
    80000d40:	96d2                	add	a3,a3,s4
    if(n > max)
    80000d42:	00d9f363          	bgeu	s3,a3,80000d48 <copyinstr+0x78>
    80000d46:	86ce                	mv	a3,s3
    while(n > 0){
    80000d48:	ca85                	beqz	a3,80000d78 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80000d4a:	01750633          	add	a2,a0,s7
    80000d4e:	41260633          	sub	a2,a2,s2
    80000d52:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80000d54:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80000d56:	96a6                	add	a3,a3,s1
    80000d58:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000d5a:	00f60733          	add	a4,a2,a5
    80000d5e:	00074703          	lbu	a4,0(a4)
    80000d62:	db51                	beqz	a4,80000cf6 <copyinstr+0x26>
        *dst = *p;
    80000d64:	00e78023          	sb	a4,0(a5)
      dst++;
    80000d68:	0785                	addi	a5,a5,1
    while(n > 0){
    80000d6a:	fed797e3          	bne	a5,a3,80000d58 <copyinstr+0x88>
    80000d6e:	b775                	j	80000d1a <copyinstr+0x4a>
    80000d70:	4781                	li	a5,0
    80000d72:	b769                	j	80000cfc <copyinstr+0x2c>
      return -1;
    80000d74:	557d                	li	a0,-1
    80000d76:	b779                	j	80000d04 <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80000d78:	6b85                	lui	s7,0x1
    80000d7a:	9bca                	add	s7,s7,s2
    80000d7c:	87a6                	mv	a5,s1
    80000d7e:	b77d                	j	80000d2c <copyinstr+0x5c>
  int got_null = 0;
    80000d80:	4781                	li	a5,0
  if(got_null){
    80000d82:	0017c793          	xori	a5,a5,1
    80000d86:	40f0053b          	negw	a0,a5
}
    80000d8a:	8082                	ret

0000000080000d8c <cow_handler>:
void cow_handler(uint64 va) {
    80000d8c:	7179                	addi	sp,sp,-48
    80000d8e:	f406                	sd	ra,40(sp)
    80000d90:	f022                	sd	s0,32(sp)
    80000d92:	ec26                	sd	s1,24(sp)
    80000d94:	e84a                	sd	s2,16(sp)
    80000d96:	e44e                	sd	s3,8(sp)
    80000d98:	1800                	addi	s0,sp,48
    80000d9a:	84aa                	mv	s1,a0
    va = PGROUNDDOWN(va);

    struct proc *p = myproc();
    80000d9c:	242000ef          	jal	80000fde <myproc>
    if(p == 0)
    80000da0:	c525                	beqz	a0,80000e08 <cow_handler+0x7c>
        panic("cow_handler: no process");

    pagetable_t pagetable = p->pagetable;
    pte_t *pte = walk(pagetable, va, 0);
    80000da2:	4601                	li	a2,0
    80000da4:	75fd                	lui	a1,0xfffff
    80000da6:	8de5                	and	a1,a1,s1
    80000da8:	6928                	ld	a0,80(a0)
    80000daa:	f06ff0ef          	jal	800004b0 <walk>
    80000dae:	89aa                	mv	s3,a0

    if(pte == 0)
    80000db0:	c135                	beqz	a0,80000e14 <cow_handler+0x88>
        panic("cow_handler: pte not exist");
    if((*pte & PTE_V) == 0)
    80000db2:	6104                	ld	s1,0(a0)
    80000db4:	0014f793          	andi	a5,s1,1
    80000db8:	c7a5                	beqz	a5,80000e20 <cow_handler+0x94>
        panic("cow_handler: page not present");
    if((*pte & PTE_U) == 0)
    80000dba:	0104f793          	andi	a5,s1,16
    80000dbe:	c7bd                	beqz	a5,80000e2c <cow_handler+0xa0>
        panic("cow_handler: page not user");

    if((*pte & PTE_COW) == 0)
    80000dc0:	1004f793          	andi	a5,s1,256
    80000dc4:	cbb5                	beqz	a5,80000e38 <cow_handler+0xac>
        panic("cow_handler: not a COW page");

    uint64 pa = PTE2PA(*pte);
    uint64 new_pa = (uint64)kalloc();
    80000dc6:	b80ff0ef          	jal	80000146 <kalloc>
    80000dca:	892a                	mv	s2,a0

    if(new_pa == 0) {
    80000dcc:	cd25                	beqz	a0,80000e44 <cow_handler+0xb8>
    uint64 pa = PTE2PA(*pte);
    80000dce:	80a9                	srli	s1,s1,0xa
    80000dd0:	04b2                	slli	s1,s1,0xc
        panic("cow_handler: kalloc failed");
    }

    memmove((void*)new_pa, (void*)pa, PGSIZE);
    80000dd2:	6605                	lui	a2,0x1
    80000dd4:	85a6                	mv	a1,s1
    80000dd6:	ca6ff0ef          	jal	8000027c <memmove>

    // 更新 PTE 标记
    uint flags = (PTE_FLAGS(*pte) | PTE_W) & ~PTE_COW;
    80000dda:	0009b783          	ld	a5,0(s3)
    80000dde:	2fb7f793          	andi	a5,a5,763
    *pte = PA2PTE(new_pa) | flags;
    80000de2:	0047e793          	ori	a5,a5,4
    80000de6:	00c95913          	srli	s2,s2,0xc
    80000dea:	092a                	slli	s2,s2,0xa
    80000dec:	0127e7b3          	or	a5,a5,s2
    80000df0:	00f9b023          	sd	a5,0(s3)

    // 减少旧页面的引用计数
    kfree((void*)pa);
    80000df4:	8526                	mv	a0,s1
    80000df6:	a26ff0ef          	jal	8000001c <kfree>
    80000dfa:	70a2                	ld	ra,40(sp)
    80000dfc:	7402                	ld	s0,32(sp)
    80000dfe:	64e2                	ld	s1,24(sp)
    80000e00:	6942                	ld	s2,16(sp)
    80000e02:	69a2                	ld	s3,8(sp)
    80000e04:	6145                	addi	sp,sp,48
    80000e06:	8082                	ret
        panic("cow_handler: no process");
    80000e08:	00006517          	auipc	a0,0x6
    80000e0c:	39050513          	addi	a0,a0,912 # 80007198 <etext+0x198>
    80000e10:	0ef040ef          	jal	800056fe <panic>
        panic("cow_handler: pte not exist");
    80000e14:	00006517          	auipc	a0,0x6
    80000e18:	39c50513          	addi	a0,a0,924 # 800071b0 <etext+0x1b0>
    80000e1c:	0e3040ef          	jal	800056fe <panic>
        panic("cow_handler: page not present");
    80000e20:	00006517          	auipc	a0,0x6
    80000e24:	3b050513          	addi	a0,a0,944 # 800071d0 <etext+0x1d0>
    80000e28:	0d7040ef          	jal	800056fe <panic>
        panic("cow_handler: page not user");
    80000e2c:	00006517          	auipc	a0,0x6
    80000e30:	3c450513          	addi	a0,a0,964 # 800071f0 <etext+0x1f0>
    80000e34:	0cb040ef          	jal	800056fe <panic>
        panic("cow_handler: not a COW page");
    80000e38:	00006517          	auipc	a0,0x6
    80000e3c:	3d850513          	addi	a0,a0,984 # 80007210 <etext+0x210>
    80000e40:	0bf040ef          	jal	800056fe <panic>
        panic("cow_handler: kalloc failed");
    80000e44:	00006517          	auipc	a0,0x6
    80000e48:	3ec50513          	addi	a0,a0,1004 # 80007230 <etext+0x230>
    80000e4c:	0b3040ef          	jal	800056fe <panic>

0000000080000e50 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000e50:	715d                	addi	sp,sp,-80
    80000e52:	e486                	sd	ra,72(sp)
    80000e54:	e0a2                	sd	s0,64(sp)
    80000e56:	fc26                	sd	s1,56(sp)
    80000e58:	f84a                	sd	s2,48(sp)
    80000e5a:	f44e                	sd	s3,40(sp)
    80000e5c:	f052                	sd	s4,32(sp)
    80000e5e:	ec56                	sd	s5,24(sp)
    80000e60:	e85a                	sd	s6,16(sp)
    80000e62:	e45e                	sd	s7,8(sp)
    80000e64:	e062                	sd	s8,0(sp)
    80000e66:	0880                	addi	s0,sp,80
    80000e68:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000e6a:	00007497          	auipc	s1,0x7
    80000e6e:	fb648493          	addi	s1,s1,-74 # 80007e20 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000e72:	8c26                	mv	s8,s1
    80000e74:	000a57b7          	lui	a5,0xa5
    80000e78:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80000e7c:	07b2                	slli	a5,a5,0xc
    80000e7e:	fa578793          	addi	a5,a5,-91
    80000e82:	4fa50937          	lui	s2,0x4fa50
    80000e86:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80000e8a:	1902                	slli	s2,s2,0x20
    80000e8c:	993e                	add	s2,s2,a5
    80000e8e:	040009b7          	lui	s3,0x4000
    80000e92:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000e94:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000e96:	4b99                	li	s7,6
    80000e98:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80000e9a:	0000da97          	auipc	s5,0xd
    80000e9e:	986a8a93          	addi	s5,s5,-1658 # 8000d820 <tickslock>
    char *pa = kalloc();
    80000ea2:	aa4ff0ef          	jal	80000146 <kalloc>
    80000ea6:	862a                	mv	a2,a0
    if(pa == 0)
    80000ea8:	c121                	beqz	a0,80000ee8 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    80000eaa:	418485b3          	sub	a1,s1,s8
    80000eae:	858d                	srai	a1,a1,0x3
    80000eb0:	032585b3          	mul	a1,a1,s2
    80000eb4:	05b6                	slli	a1,a1,0xd
    80000eb6:	6789                	lui	a5,0x2
    80000eb8:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000eba:	875e                	mv	a4,s7
    80000ebc:	86da                	mv	a3,s6
    80000ebe:	40b985b3          	sub	a1,s3,a1
    80000ec2:	8552                	mv	a0,s4
    80000ec4:	f76ff0ef          	jal	8000063a <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000ec8:	16848493          	addi	s1,s1,360
    80000ecc:	fd549be3          	bne	s1,s5,80000ea2 <proc_mapstacks+0x52>
  }
}
    80000ed0:	60a6                	ld	ra,72(sp)
    80000ed2:	6406                	ld	s0,64(sp)
    80000ed4:	74e2                	ld	s1,56(sp)
    80000ed6:	7942                	ld	s2,48(sp)
    80000ed8:	79a2                	ld	s3,40(sp)
    80000eda:	7a02                	ld	s4,32(sp)
    80000edc:	6ae2                	ld	s5,24(sp)
    80000ede:	6b42                	ld	s6,16(sp)
    80000ee0:	6ba2                	ld	s7,8(sp)
    80000ee2:	6c02                	ld	s8,0(sp)
    80000ee4:	6161                	addi	sp,sp,80
    80000ee6:	8082                	ret
      panic("kalloc");
    80000ee8:	00006517          	auipc	a0,0x6
    80000eec:	36850513          	addi	a0,a0,872 # 80007250 <etext+0x250>
    80000ef0:	00f040ef          	jal	800056fe <panic>

0000000080000ef4 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000ef4:	7139                	addi	sp,sp,-64
    80000ef6:	fc06                	sd	ra,56(sp)
    80000ef8:	f822                	sd	s0,48(sp)
    80000efa:	f426                	sd	s1,40(sp)
    80000efc:	f04a                	sd	s2,32(sp)
    80000efe:	ec4e                	sd	s3,24(sp)
    80000f00:	e852                	sd	s4,16(sp)
    80000f02:	e456                	sd	s5,8(sp)
    80000f04:	e05a                	sd	s6,0(sp)
    80000f06:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000f08:	00006597          	auipc	a1,0x6
    80000f0c:	35058593          	addi	a1,a1,848 # 80007258 <etext+0x258>
    80000f10:	00007517          	auipc	a0,0x7
    80000f14:	ae050513          	addi	a0,a0,-1312 # 800079f0 <pid_lock>
    80000f18:	29b040ef          	jal	800059b2 <initlock>
  initlock(&wait_lock, "wait_lock");
    80000f1c:	00006597          	auipc	a1,0x6
    80000f20:	34458593          	addi	a1,a1,836 # 80007260 <etext+0x260>
    80000f24:	00007517          	auipc	a0,0x7
    80000f28:	ae450513          	addi	a0,a0,-1308 # 80007a08 <wait_lock>
    80000f2c:	287040ef          	jal	800059b2 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f30:	00007497          	auipc	s1,0x7
    80000f34:	ef048493          	addi	s1,s1,-272 # 80007e20 <proc>
      initlock(&p->lock, "proc");
    80000f38:	00006b17          	auipc	s6,0x6
    80000f3c:	338b0b13          	addi	s6,s6,824 # 80007270 <etext+0x270>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000f40:	8aa6                	mv	s5,s1
    80000f42:	000a57b7          	lui	a5,0xa5
    80000f46:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80000f4a:	07b2                	slli	a5,a5,0xc
    80000f4c:	fa578793          	addi	a5,a5,-91
    80000f50:	4fa50937          	lui	s2,0x4fa50
    80000f54:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80000f58:	1902                	slli	s2,s2,0x20
    80000f5a:	993e                	add	s2,s2,a5
    80000f5c:	040009b7          	lui	s3,0x4000
    80000f60:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000f62:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f64:	0000da17          	auipc	s4,0xd
    80000f68:	8bca0a13          	addi	s4,s4,-1860 # 8000d820 <tickslock>
      initlock(&p->lock, "proc");
    80000f6c:	85da                	mv	a1,s6
    80000f6e:	8526                	mv	a0,s1
    80000f70:	243040ef          	jal	800059b2 <initlock>
      p->state = UNUSED;
    80000f74:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000f78:	415487b3          	sub	a5,s1,s5
    80000f7c:	878d                	srai	a5,a5,0x3
    80000f7e:	032787b3          	mul	a5,a5,s2
    80000f82:	07b6                	slli	a5,a5,0xd
    80000f84:	6709                	lui	a4,0x2
    80000f86:	9fb9                	addw	a5,a5,a4
    80000f88:	40f987b3          	sub	a5,s3,a5
    80000f8c:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f8e:	16848493          	addi	s1,s1,360
    80000f92:	fd449de3          	bne	s1,s4,80000f6c <procinit+0x78>
  }
}
    80000f96:	70e2                	ld	ra,56(sp)
    80000f98:	7442                	ld	s0,48(sp)
    80000f9a:	74a2                	ld	s1,40(sp)
    80000f9c:	7902                	ld	s2,32(sp)
    80000f9e:	69e2                	ld	s3,24(sp)
    80000fa0:	6a42                	ld	s4,16(sp)
    80000fa2:	6aa2                	ld	s5,8(sp)
    80000fa4:	6b02                	ld	s6,0(sp)
    80000fa6:	6121                	addi	sp,sp,64
    80000fa8:	8082                	ret

0000000080000faa <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000faa:	1141                	addi	sp,sp,-16
    80000fac:	e406                	sd	ra,8(sp)
    80000fae:	e022                	sd	s0,0(sp)
    80000fb0:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000fb2:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000fb4:	2501                	sext.w	a0,a0
    80000fb6:	60a2                	ld	ra,8(sp)
    80000fb8:	6402                	ld	s0,0(sp)
    80000fba:	0141                	addi	sp,sp,16
    80000fbc:	8082                	ret

0000000080000fbe <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000fbe:	1141                	addi	sp,sp,-16
    80000fc0:	e406                	sd	ra,8(sp)
    80000fc2:	e022                	sd	s0,0(sp)
    80000fc4:	0800                	addi	s0,sp,16
    80000fc6:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000fc8:	2781                	sext.w	a5,a5
    80000fca:	079e                	slli	a5,a5,0x7
  return c;
}
    80000fcc:	00007517          	auipc	a0,0x7
    80000fd0:	a5450513          	addi	a0,a0,-1452 # 80007a20 <cpus>
    80000fd4:	953e                	add	a0,a0,a5
    80000fd6:	60a2                	ld	ra,8(sp)
    80000fd8:	6402                	ld	s0,0(sp)
    80000fda:	0141                	addi	sp,sp,16
    80000fdc:	8082                	ret

0000000080000fde <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000fde:	1101                	addi	sp,sp,-32
    80000fe0:	ec06                	sd	ra,24(sp)
    80000fe2:	e822                	sd	s0,16(sp)
    80000fe4:	e426                	sd	s1,8(sp)
    80000fe6:	1000                	addi	s0,sp,32
  push_off();
    80000fe8:	211040ef          	jal	800059f8 <push_off>
    80000fec:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000fee:	2781                	sext.w	a5,a5
    80000ff0:	079e                	slli	a5,a5,0x7
    80000ff2:	00007717          	auipc	a4,0x7
    80000ff6:	9fe70713          	addi	a4,a4,-1538 # 800079f0 <pid_lock>
    80000ffa:	97ba                	add	a5,a5,a4
    80000ffc:	7b9c                	ld	a5,48(a5)
    80000ffe:	84be                	mv	s1,a5
  pop_off();
    80001000:	281040ef          	jal	80005a80 <pop_off>
  return p;
}
    80001004:	8526                	mv	a0,s1
    80001006:	60e2                	ld	ra,24(sp)
    80001008:	6442                	ld	s0,16(sp)
    8000100a:	64a2                	ld	s1,8(sp)
    8000100c:	6105                	addi	sp,sp,32
    8000100e:	8082                	ret

0000000080001010 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001010:	1141                	addi	sp,sp,-16
    80001012:	e406                	sd	ra,8(sp)
    80001014:	e022                	sd	s0,0(sp)
    80001016:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80001018:	fc7ff0ef          	jal	80000fde <myproc>
    8000101c:	2b5040ef          	jal	80005ad0 <release>

  if (first) {
    80001020:	00007797          	auipc	a5,0x7
    80001024:	9207a783          	lw	a5,-1760(a5) # 80007940 <first.1>
    80001028:	e799                	bnez	a5,80001036 <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    8000102a:	2c3000ef          	jal	80001aec <usertrapret>
}
    8000102e:	60a2                	ld	ra,8(sp)
    80001030:	6402                	ld	s0,0(sp)
    80001032:	0141                	addi	sp,sp,16
    80001034:	8082                	ret
    fsinit(ROOTDEV);
    80001036:	4505                	li	a0,1
    80001038:	63e010ef          	jal	80002676 <fsinit>
    first = 0;
    8000103c:	00007797          	auipc	a5,0x7
    80001040:	9007a223          	sw	zero,-1788(a5) # 80007940 <first.1>
    __sync_synchronize();
    80001044:	0330000f          	fence	rw,rw
    80001048:	b7cd                	j	8000102a <forkret+0x1a>

000000008000104a <allocpid>:
{
    8000104a:	1101                	addi	sp,sp,-32
    8000104c:	ec06                	sd	ra,24(sp)
    8000104e:	e822                	sd	s0,16(sp)
    80001050:	e426                	sd	s1,8(sp)
    80001052:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001054:	00007517          	auipc	a0,0x7
    80001058:	99c50513          	addi	a0,a0,-1636 # 800079f0 <pid_lock>
    8000105c:	1e1040ef          	jal	80005a3c <acquire>
  pid = nextpid;
    80001060:	00007797          	auipc	a5,0x7
    80001064:	8e478793          	addi	a5,a5,-1820 # 80007944 <nextpid>
    80001068:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    8000106a:	0014871b          	addiw	a4,s1,1
    8000106e:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001070:	00007517          	auipc	a0,0x7
    80001074:	98050513          	addi	a0,a0,-1664 # 800079f0 <pid_lock>
    80001078:	259040ef          	jal	80005ad0 <release>
}
    8000107c:	8526                	mv	a0,s1
    8000107e:	60e2                	ld	ra,24(sp)
    80001080:	6442                	ld	s0,16(sp)
    80001082:	64a2                	ld	s1,8(sp)
    80001084:	6105                	addi	sp,sp,32
    80001086:	8082                	ret

0000000080001088 <proc_pagetable>:
{
    80001088:	1101                	addi	sp,sp,-32
    8000108a:	ec06                	sd	ra,24(sp)
    8000108c:	e822                	sd	s0,16(sp)
    8000108e:	e426                	sd	s1,8(sp)
    80001090:	e04a                	sd	s2,0(sp)
    80001092:	1000                	addi	s0,sp,32
    80001094:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001096:	f52ff0ef          	jal	800007e8 <uvmcreate>
    8000109a:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000109c:	cd05                	beqz	a0,800010d4 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    8000109e:	4729                	li	a4,10
    800010a0:	00005697          	auipc	a3,0x5
    800010a4:	f6068693          	addi	a3,a3,-160 # 80006000 <_trampoline>
    800010a8:	6605                	lui	a2,0x1
    800010aa:	040005b7          	lui	a1,0x4000
    800010ae:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800010b0:	05b2                	slli	a1,a1,0xc
    800010b2:	cd2ff0ef          	jal	80000584 <mappages>
    800010b6:	02054663          	bltz	a0,800010e2 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    800010ba:	4719                	li	a4,6
    800010bc:	05893683          	ld	a3,88(s2)
    800010c0:	6605                	lui	a2,0x1
    800010c2:	020005b7          	lui	a1,0x2000
    800010c6:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    800010c8:	05b6                	slli	a1,a1,0xd
    800010ca:	8526                	mv	a0,s1
    800010cc:	cb8ff0ef          	jal	80000584 <mappages>
    800010d0:	00054f63          	bltz	a0,800010ee <proc_pagetable+0x66>
}
    800010d4:	8526                	mv	a0,s1
    800010d6:	60e2                	ld	ra,24(sp)
    800010d8:	6442                	ld	s0,16(sp)
    800010da:	64a2                	ld	s1,8(sp)
    800010dc:	6902                	ld	s2,0(sp)
    800010de:	6105                	addi	sp,sp,32
    800010e0:	8082                	ret
    uvmfree(pagetable, 0);
    800010e2:	4581                	li	a1,0
    800010e4:	8526                	mv	a0,s1
    800010e6:	8d1ff0ef          	jal	800009b6 <uvmfree>
    return 0;
    800010ea:	4481                	li	s1,0
    800010ec:	b7e5                	j	800010d4 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    800010ee:	4681                	li	a3,0
    800010f0:	4605                	li	a2,1
    800010f2:	040005b7          	lui	a1,0x4000
    800010f6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800010f8:	05b2                	slli	a1,a1,0xc
    800010fa:	8526                	mv	a0,s1
    800010fc:	e30ff0ef          	jal	8000072c <uvmunmap>
    uvmfree(pagetable, 0);
    80001100:	4581                	li	a1,0
    80001102:	8526                	mv	a0,s1
    80001104:	8b3ff0ef          	jal	800009b6 <uvmfree>
    return 0;
    80001108:	4481                	li	s1,0
    8000110a:	b7e9                	j	800010d4 <proc_pagetable+0x4c>

000000008000110c <proc_freepagetable>:
{
    8000110c:	1101                	addi	sp,sp,-32
    8000110e:	ec06                	sd	ra,24(sp)
    80001110:	e822                	sd	s0,16(sp)
    80001112:	e426                	sd	s1,8(sp)
    80001114:	e04a                	sd	s2,0(sp)
    80001116:	1000                	addi	s0,sp,32
    80001118:	84aa                	mv	s1,a0
    8000111a:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    8000111c:	4681                	li	a3,0
    8000111e:	4605                	li	a2,1
    80001120:	040005b7          	lui	a1,0x4000
    80001124:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001126:	05b2                	slli	a1,a1,0xc
    80001128:	e04ff0ef          	jal	8000072c <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    8000112c:	4681                	li	a3,0
    8000112e:	4605                	li	a2,1
    80001130:	020005b7          	lui	a1,0x2000
    80001134:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001136:	05b6                	slli	a1,a1,0xd
    80001138:	8526                	mv	a0,s1
    8000113a:	df2ff0ef          	jal	8000072c <uvmunmap>
  uvmfree(pagetable, sz);
    8000113e:	85ca                	mv	a1,s2
    80001140:	8526                	mv	a0,s1
    80001142:	875ff0ef          	jal	800009b6 <uvmfree>
}
    80001146:	60e2                	ld	ra,24(sp)
    80001148:	6442                	ld	s0,16(sp)
    8000114a:	64a2                	ld	s1,8(sp)
    8000114c:	6902                	ld	s2,0(sp)
    8000114e:	6105                	addi	sp,sp,32
    80001150:	8082                	ret

0000000080001152 <freeproc>:
{
    80001152:	1101                	addi	sp,sp,-32
    80001154:	ec06                	sd	ra,24(sp)
    80001156:	e822                	sd	s0,16(sp)
    80001158:	e426                	sd	s1,8(sp)
    8000115a:	1000                	addi	s0,sp,32
    8000115c:	84aa                	mv	s1,a0
  if(p->trapframe)
    8000115e:	6d28                	ld	a0,88(a0)
    80001160:	c119                	beqz	a0,80001166 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001162:	ebbfe0ef          	jal	8000001c <kfree>
  p->trapframe = 0;
    80001166:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    8000116a:	68a8                	ld	a0,80(s1)
    8000116c:	c501                	beqz	a0,80001174 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    8000116e:	64ac                	ld	a1,72(s1)
    80001170:	f9dff0ef          	jal	8000110c <proc_freepagetable>
  p->pagetable = 0;
    80001174:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001178:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    8000117c:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001180:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001184:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001188:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    8000118c:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001190:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001194:	0004ac23          	sw	zero,24(s1)
}
    80001198:	60e2                	ld	ra,24(sp)
    8000119a:	6442                	ld	s0,16(sp)
    8000119c:	64a2                	ld	s1,8(sp)
    8000119e:	6105                	addi	sp,sp,32
    800011a0:	8082                	ret

00000000800011a2 <allocproc>:
{
    800011a2:	1101                	addi	sp,sp,-32
    800011a4:	ec06                	sd	ra,24(sp)
    800011a6:	e822                	sd	s0,16(sp)
    800011a8:	e426                	sd	s1,8(sp)
    800011aa:	e04a                	sd	s2,0(sp)
    800011ac:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    800011ae:	00007497          	auipc	s1,0x7
    800011b2:	c7248493          	addi	s1,s1,-910 # 80007e20 <proc>
    800011b6:	0000c917          	auipc	s2,0xc
    800011ba:	66a90913          	addi	s2,s2,1642 # 8000d820 <tickslock>
    acquire(&p->lock);
    800011be:	8526                	mv	a0,s1
    800011c0:	07d040ef          	jal	80005a3c <acquire>
    if(p->state == UNUSED) {
    800011c4:	4c9c                	lw	a5,24(s1)
    800011c6:	cb91                	beqz	a5,800011da <allocproc+0x38>
      release(&p->lock);
    800011c8:	8526                	mv	a0,s1
    800011ca:	107040ef          	jal	80005ad0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800011ce:	16848493          	addi	s1,s1,360
    800011d2:	ff2496e3          	bne	s1,s2,800011be <allocproc+0x1c>
  return 0;
    800011d6:	4481                	li	s1,0
    800011d8:	a089                	j	8000121a <allocproc+0x78>
  p->pid = allocpid();
    800011da:	e71ff0ef          	jal	8000104a <allocpid>
    800011de:	d888                	sw	a0,48(s1)
  p->state = USED;
    800011e0:	4785                	li	a5,1
    800011e2:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    800011e4:	f63fe0ef          	jal	80000146 <kalloc>
    800011e8:	892a                	mv	s2,a0
    800011ea:	eca8                	sd	a0,88(s1)
    800011ec:	cd15                	beqz	a0,80001228 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    800011ee:	8526                	mv	a0,s1
    800011f0:	e99ff0ef          	jal	80001088 <proc_pagetable>
    800011f4:	892a                	mv	s2,a0
    800011f6:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    800011f8:	c121                	beqz	a0,80001238 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    800011fa:	07000613          	li	a2,112
    800011fe:	4581                	li	a1,0
    80001200:	06048513          	addi	a0,s1,96
    80001204:	818ff0ef          	jal	8000021c <memset>
  p->context.ra = (uint64)forkret;
    80001208:	00000797          	auipc	a5,0x0
    8000120c:	e0878793          	addi	a5,a5,-504 # 80001010 <forkret>
    80001210:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001212:	60bc                	ld	a5,64(s1)
    80001214:	6705                	lui	a4,0x1
    80001216:	97ba                	add	a5,a5,a4
    80001218:	f4bc                	sd	a5,104(s1)
}
    8000121a:	8526                	mv	a0,s1
    8000121c:	60e2                	ld	ra,24(sp)
    8000121e:	6442                	ld	s0,16(sp)
    80001220:	64a2                	ld	s1,8(sp)
    80001222:	6902                	ld	s2,0(sp)
    80001224:	6105                	addi	sp,sp,32
    80001226:	8082                	ret
    freeproc(p);
    80001228:	8526                	mv	a0,s1
    8000122a:	f29ff0ef          	jal	80001152 <freeproc>
    release(&p->lock);
    8000122e:	8526                	mv	a0,s1
    80001230:	0a1040ef          	jal	80005ad0 <release>
    return 0;
    80001234:	84ca                	mv	s1,s2
    80001236:	b7d5                	j	8000121a <allocproc+0x78>
    freeproc(p);
    80001238:	8526                	mv	a0,s1
    8000123a:	f19ff0ef          	jal	80001152 <freeproc>
    release(&p->lock);
    8000123e:	8526                	mv	a0,s1
    80001240:	091040ef          	jal	80005ad0 <release>
    return 0;
    80001244:	84ca                	mv	s1,s2
    80001246:	bfd1                	j	8000121a <allocproc+0x78>

0000000080001248 <userinit>:
{
    80001248:	1101                	addi	sp,sp,-32
    8000124a:	ec06                	sd	ra,24(sp)
    8000124c:	e822                	sd	s0,16(sp)
    8000124e:	e426                	sd	s1,8(sp)
    80001250:	1000                	addi	s0,sp,32
  p = allocproc();
    80001252:	f51ff0ef          	jal	800011a2 <allocproc>
    80001256:	84aa                	mv	s1,a0
  initproc = p;
    80001258:	00006797          	auipc	a5,0x6
    8000125c:	74a7b823          	sd	a0,1872(a5) # 800079a8 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001260:	03400613          	li	a2,52
    80001264:	00006597          	auipc	a1,0x6
    80001268:	6ec58593          	addi	a1,a1,1772 # 80007950 <initcode>
    8000126c:	6928                	ld	a0,80(a0)
    8000126e:	da0ff0ef          	jal	8000080e <uvmfirst>
  p->sz = PGSIZE;
    80001272:	6785                	lui	a5,0x1
    80001274:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001276:	6cb8                	ld	a4,88(s1)
    80001278:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    8000127c:	6cb8                	ld	a4,88(s1)
    8000127e:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001280:	4641                	li	a2,16
    80001282:	00006597          	auipc	a1,0x6
    80001286:	ff658593          	addi	a1,a1,-10 # 80007278 <etext+0x278>
    8000128a:	15848513          	addi	a0,s1,344
    8000128e:	8e2ff0ef          	jal	80000370 <safestrcpy>
  p->cwd = namei("/");
    80001292:	00006517          	auipc	a0,0x6
    80001296:	ff650513          	addi	a0,a0,-10 # 80007288 <etext+0x288>
    8000129a:	505010ef          	jal	80002f9e <namei>
    8000129e:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    800012a2:	478d                	li	a5,3
    800012a4:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    800012a6:	8526                	mv	a0,s1
    800012a8:	029040ef          	jal	80005ad0 <release>
}
    800012ac:	60e2                	ld	ra,24(sp)
    800012ae:	6442                	ld	s0,16(sp)
    800012b0:	64a2                	ld	s1,8(sp)
    800012b2:	6105                	addi	sp,sp,32
    800012b4:	8082                	ret

00000000800012b6 <growproc>:
{
    800012b6:	1101                	addi	sp,sp,-32
    800012b8:	ec06                	sd	ra,24(sp)
    800012ba:	e822                	sd	s0,16(sp)
    800012bc:	e426                	sd	s1,8(sp)
    800012be:	e04a                	sd	s2,0(sp)
    800012c0:	1000                	addi	s0,sp,32
    800012c2:	892a                	mv	s2,a0
  struct proc *p = myproc();
    800012c4:	d1bff0ef          	jal	80000fde <myproc>
    800012c8:	84aa                	mv	s1,a0
  sz = p->sz;
    800012ca:	652c                	ld	a1,72(a0)
  if(n > 0){
    800012cc:	01204c63          	bgtz	s2,800012e4 <growproc+0x2e>
  } else if(n < 0){
    800012d0:	02094463          	bltz	s2,800012f8 <growproc+0x42>
  p->sz = sz;
    800012d4:	e4ac                	sd	a1,72(s1)
  return 0;
    800012d6:	4501                	li	a0,0
}
    800012d8:	60e2                	ld	ra,24(sp)
    800012da:	6442                	ld	s0,16(sp)
    800012dc:	64a2                	ld	s1,8(sp)
    800012de:	6902                	ld	s2,0(sp)
    800012e0:	6105                	addi	sp,sp,32
    800012e2:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    800012e4:	4691                	li	a3,4
    800012e6:	00b90633          	add	a2,s2,a1
    800012ea:	6928                	ld	a0,80(a0)
    800012ec:	dc4ff0ef          	jal	800008b0 <uvmalloc>
    800012f0:	85aa                	mv	a1,a0
    800012f2:	f16d                	bnez	a0,800012d4 <growproc+0x1e>
      return -1;
    800012f4:	557d                	li	a0,-1
    800012f6:	b7cd                	j	800012d8 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    800012f8:	00b90633          	add	a2,s2,a1
    800012fc:	6928                	ld	a0,80(a0)
    800012fe:	d6eff0ef          	jal	8000086c <uvmdealloc>
    80001302:	85aa                	mv	a1,a0
    80001304:	bfc1                	j	800012d4 <growproc+0x1e>

0000000080001306 <fork>:
{
    80001306:	7139                	addi	sp,sp,-64
    80001308:	fc06                	sd	ra,56(sp)
    8000130a:	f822                	sd	s0,48(sp)
    8000130c:	f426                	sd	s1,40(sp)
    8000130e:	e456                	sd	s5,8(sp)
    80001310:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001312:	ccdff0ef          	jal	80000fde <myproc>
    80001316:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001318:	e8bff0ef          	jal	800011a2 <allocproc>
    8000131c:	0e050a63          	beqz	a0,80001410 <fork+0x10a>
    80001320:	e852                	sd	s4,16(sp)
    80001322:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001324:	048ab603          	ld	a2,72(s5)
    80001328:	692c                	ld	a1,80(a0)
    8000132a:	050ab503          	ld	a0,80(s5)
    8000132e:	ebaff0ef          	jal	800009e8 <uvmcopy>
    80001332:	04054863          	bltz	a0,80001382 <fork+0x7c>
    80001336:	f04a                	sd	s2,32(sp)
    80001338:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    8000133a:	048ab783          	ld	a5,72(s5)
    8000133e:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001342:	058ab683          	ld	a3,88(s5)
    80001346:	87b6                	mv	a5,a3
    80001348:	058a3703          	ld	a4,88(s4)
    8000134c:	12068693          	addi	a3,a3,288
    80001350:	6388                	ld	a0,0(a5)
    80001352:	678c                	ld	a1,8(a5)
    80001354:	6b90                	ld	a2,16(a5)
    80001356:	e308                	sd	a0,0(a4)
    80001358:	e70c                	sd	a1,8(a4)
    8000135a:	eb10                	sd	a2,16(a4)
    8000135c:	6f90                	ld	a2,24(a5)
    8000135e:	ef10                	sd	a2,24(a4)
    80001360:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    80001364:	02070713          	addi	a4,a4,32
    80001368:	fed794e3          	bne	a5,a3,80001350 <fork+0x4a>
  np->trapframe->a0 = 0;
    8000136c:	058a3783          	ld	a5,88(s4)
    80001370:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001374:	0d0a8493          	addi	s1,s5,208
    80001378:	0d0a0913          	addi	s2,s4,208
    8000137c:	150a8993          	addi	s3,s5,336
    80001380:	a831                	j	8000139c <fork+0x96>
    freeproc(np);
    80001382:	8552                	mv	a0,s4
    80001384:	dcfff0ef          	jal	80001152 <freeproc>
    release(&np->lock);
    80001388:	8552                	mv	a0,s4
    8000138a:	746040ef          	jal	80005ad0 <release>
    return -1;
    8000138e:	54fd                	li	s1,-1
    80001390:	6a42                	ld	s4,16(sp)
    80001392:	a885                	j	80001402 <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001394:	04a1                	addi	s1,s1,8
    80001396:	0921                	addi	s2,s2,8
    80001398:	01348963          	beq	s1,s3,800013aa <fork+0xa4>
    if(p->ofile[i])
    8000139c:	6088                	ld	a0,0(s1)
    8000139e:	d97d                	beqz	a0,80001394 <fork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    800013a0:	1ac020ef          	jal	8000354c <filedup>
    800013a4:	00a93023          	sd	a0,0(s2)
    800013a8:	b7f5                	j	80001394 <fork+0x8e>
  np->cwd = idup(p->cwd);
    800013aa:	150ab503          	ld	a0,336(s5)
    800013ae:	4c4010ef          	jal	80002872 <idup>
    800013b2:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    800013b6:	4641                	li	a2,16
    800013b8:	158a8593          	addi	a1,s5,344
    800013bc:	158a0513          	addi	a0,s4,344
    800013c0:	fb1fe0ef          	jal	80000370 <safestrcpy>
  pid = np->pid;
    800013c4:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    800013c8:	8552                	mv	a0,s4
    800013ca:	706040ef          	jal	80005ad0 <release>
  acquire(&wait_lock);
    800013ce:	00006517          	auipc	a0,0x6
    800013d2:	63a50513          	addi	a0,a0,1594 # 80007a08 <wait_lock>
    800013d6:	666040ef          	jal	80005a3c <acquire>
  np->parent = p;
    800013da:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    800013de:	00006517          	auipc	a0,0x6
    800013e2:	62a50513          	addi	a0,a0,1578 # 80007a08 <wait_lock>
    800013e6:	6ea040ef          	jal	80005ad0 <release>
  acquire(&np->lock);
    800013ea:	8552                	mv	a0,s4
    800013ec:	650040ef          	jal	80005a3c <acquire>
  np->state = RUNNABLE;
    800013f0:	478d                	li	a5,3
    800013f2:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    800013f6:	8552                	mv	a0,s4
    800013f8:	6d8040ef          	jal	80005ad0 <release>
  return pid;
    800013fc:	7902                	ld	s2,32(sp)
    800013fe:	69e2                	ld	s3,24(sp)
    80001400:	6a42                	ld	s4,16(sp)
}
    80001402:	8526                	mv	a0,s1
    80001404:	70e2                	ld	ra,56(sp)
    80001406:	7442                	ld	s0,48(sp)
    80001408:	74a2                	ld	s1,40(sp)
    8000140a:	6aa2                	ld	s5,8(sp)
    8000140c:	6121                	addi	sp,sp,64
    8000140e:	8082                	ret
    return -1;
    80001410:	54fd                	li	s1,-1
    80001412:	bfc5                	j	80001402 <fork+0xfc>

0000000080001414 <scheduler>:
{
    80001414:	715d                	addi	sp,sp,-80
    80001416:	e486                	sd	ra,72(sp)
    80001418:	e0a2                	sd	s0,64(sp)
    8000141a:	fc26                	sd	s1,56(sp)
    8000141c:	f84a                	sd	s2,48(sp)
    8000141e:	f44e                	sd	s3,40(sp)
    80001420:	f052                	sd	s4,32(sp)
    80001422:	ec56                	sd	s5,24(sp)
    80001424:	e85a                	sd	s6,16(sp)
    80001426:	e45e                	sd	s7,8(sp)
    80001428:	e062                	sd	s8,0(sp)
    8000142a:	0880                	addi	s0,sp,80
    8000142c:	8792                	mv	a5,tp
  int id = r_tp();
    8000142e:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001430:	00779b13          	slli	s6,a5,0x7
    80001434:	00006717          	auipc	a4,0x6
    80001438:	5bc70713          	addi	a4,a4,1468 # 800079f0 <pid_lock>
    8000143c:	975a                	add	a4,a4,s6
    8000143e:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001442:	00006717          	auipc	a4,0x6
    80001446:	5e670713          	addi	a4,a4,1510 # 80007a28 <cpus+0x8>
    8000144a:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    8000144c:	4c11                	li	s8,4
        c->proc = p;
    8000144e:	079e                	slli	a5,a5,0x7
    80001450:	00006a17          	auipc	s4,0x6
    80001454:	5a0a0a13          	addi	s4,s4,1440 # 800079f0 <pid_lock>
    80001458:	9a3e                	add	s4,s4,a5
        found = 1;
    8000145a:	4b85                	li	s7,1
    8000145c:	a0a9                	j	800014a6 <scheduler+0x92>
      release(&p->lock);
    8000145e:	8526                	mv	a0,s1
    80001460:	670040ef          	jal	80005ad0 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001464:	16848493          	addi	s1,s1,360
    80001468:	03248563          	beq	s1,s2,80001492 <scheduler+0x7e>
      acquire(&p->lock);
    8000146c:	8526                	mv	a0,s1
    8000146e:	5ce040ef          	jal	80005a3c <acquire>
      if(p->state == RUNNABLE) {
    80001472:	4c9c                	lw	a5,24(s1)
    80001474:	ff3795e3          	bne	a5,s3,8000145e <scheduler+0x4a>
        p->state = RUNNING;
    80001478:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    8000147c:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001480:	06048593          	addi	a1,s1,96
    80001484:	855a                	mv	a0,s6
    80001486:	5bc000ef          	jal	80001a42 <swtch>
        c->proc = 0;
    8000148a:	020a3823          	sd	zero,48(s4)
        found = 1;
    8000148e:	8ade                	mv	s5,s7
    80001490:	b7f9                	j	8000145e <scheduler+0x4a>
    if(found == 0) {
    80001492:	000a9a63          	bnez	s5,800014a6 <scheduler+0x92>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001496:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000149a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000149e:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    800014a2:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800014a6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800014aa:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800014ae:	10079073          	csrw	sstatus,a5
    int found = 0;
    800014b2:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    800014b4:	00007497          	auipc	s1,0x7
    800014b8:	96c48493          	addi	s1,s1,-1684 # 80007e20 <proc>
      if(p->state == RUNNABLE) {
    800014bc:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    800014be:	0000c917          	auipc	s2,0xc
    800014c2:	36290913          	addi	s2,s2,866 # 8000d820 <tickslock>
    800014c6:	b75d                	j	8000146c <scheduler+0x58>

00000000800014c8 <sched>:
{
    800014c8:	7179                	addi	sp,sp,-48
    800014ca:	f406                	sd	ra,40(sp)
    800014cc:	f022                	sd	s0,32(sp)
    800014ce:	ec26                	sd	s1,24(sp)
    800014d0:	e84a                	sd	s2,16(sp)
    800014d2:	e44e                	sd	s3,8(sp)
    800014d4:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    800014d6:	b09ff0ef          	jal	80000fde <myproc>
    800014da:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    800014dc:	4f0040ef          	jal	800059cc <holding>
    800014e0:	c935                	beqz	a0,80001554 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    800014e2:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    800014e4:	2781                	sext.w	a5,a5
    800014e6:	079e                	slli	a5,a5,0x7
    800014e8:	00006717          	auipc	a4,0x6
    800014ec:	50870713          	addi	a4,a4,1288 # 800079f0 <pid_lock>
    800014f0:	97ba                	add	a5,a5,a4
    800014f2:	0a87a703          	lw	a4,168(a5)
    800014f6:	4785                	li	a5,1
    800014f8:	06f71463          	bne	a4,a5,80001560 <sched+0x98>
  if(p->state == RUNNING)
    800014fc:	4c98                	lw	a4,24(s1)
    800014fe:	4791                	li	a5,4
    80001500:	06f70663          	beq	a4,a5,8000156c <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001504:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001508:	8b89                	andi	a5,a5,2
  if(intr_get())
    8000150a:	e7bd                	bnez	a5,80001578 <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000150c:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    8000150e:	00006917          	auipc	s2,0x6
    80001512:	4e290913          	addi	s2,s2,1250 # 800079f0 <pid_lock>
    80001516:	2781                	sext.w	a5,a5
    80001518:	079e                	slli	a5,a5,0x7
    8000151a:	97ca                	add	a5,a5,s2
    8000151c:	0ac7a983          	lw	s3,172(a5)
    80001520:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001522:	2781                	sext.w	a5,a5
    80001524:	079e                	slli	a5,a5,0x7
    80001526:	07a1                	addi	a5,a5,8
    80001528:	00006597          	auipc	a1,0x6
    8000152c:	4f858593          	addi	a1,a1,1272 # 80007a20 <cpus>
    80001530:	95be                	add	a1,a1,a5
    80001532:	06048513          	addi	a0,s1,96
    80001536:	50c000ef          	jal	80001a42 <swtch>
    8000153a:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    8000153c:	2781                	sext.w	a5,a5
    8000153e:	079e                	slli	a5,a5,0x7
    80001540:	993e                	add	s2,s2,a5
    80001542:	0b392623          	sw	s3,172(s2)
}
    80001546:	70a2                	ld	ra,40(sp)
    80001548:	7402                	ld	s0,32(sp)
    8000154a:	64e2                	ld	s1,24(sp)
    8000154c:	6942                	ld	s2,16(sp)
    8000154e:	69a2                	ld	s3,8(sp)
    80001550:	6145                	addi	sp,sp,48
    80001552:	8082                	ret
    panic("sched p->lock");
    80001554:	00006517          	auipc	a0,0x6
    80001558:	d3c50513          	addi	a0,a0,-708 # 80007290 <etext+0x290>
    8000155c:	1a2040ef          	jal	800056fe <panic>
    panic("sched locks");
    80001560:	00006517          	auipc	a0,0x6
    80001564:	d4050513          	addi	a0,a0,-704 # 800072a0 <etext+0x2a0>
    80001568:	196040ef          	jal	800056fe <panic>
    panic("sched running");
    8000156c:	00006517          	auipc	a0,0x6
    80001570:	d4450513          	addi	a0,a0,-700 # 800072b0 <etext+0x2b0>
    80001574:	18a040ef          	jal	800056fe <panic>
    panic("sched interruptible");
    80001578:	00006517          	auipc	a0,0x6
    8000157c:	d4850513          	addi	a0,a0,-696 # 800072c0 <etext+0x2c0>
    80001580:	17e040ef          	jal	800056fe <panic>

0000000080001584 <yield>:
{
    80001584:	1101                	addi	sp,sp,-32
    80001586:	ec06                	sd	ra,24(sp)
    80001588:	e822                	sd	s0,16(sp)
    8000158a:	e426                	sd	s1,8(sp)
    8000158c:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    8000158e:	a51ff0ef          	jal	80000fde <myproc>
    80001592:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001594:	4a8040ef          	jal	80005a3c <acquire>
  p->state = RUNNABLE;
    80001598:	478d                	li	a5,3
    8000159a:	cc9c                	sw	a5,24(s1)
  sched();
    8000159c:	f2dff0ef          	jal	800014c8 <sched>
  release(&p->lock);
    800015a0:	8526                	mv	a0,s1
    800015a2:	52e040ef          	jal	80005ad0 <release>
}
    800015a6:	60e2                	ld	ra,24(sp)
    800015a8:	6442                	ld	s0,16(sp)
    800015aa:	64a2                	ld	s1,8(sp)
    800015ac:	6105                	addi	sp,sp,32
    800015ae:	8082                	ret

00000000800015b0 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    800015b0:	7179                	addi	sp,sp,-48
    800015b2:	f406                	sd	ra,40(sp)
    800015b4:	f022                	sd	s0,32(sp)
    800015b6:	ec26                	sd	s1,24(sp)
    800015b8:	e84a                	sd	s2,16(sp)
    800015ba:	e44e                	sd	s3,8(sp)
    800015bc:	1800                	addi	s0,sp,48
    800015be:	89aa                	mv	s3,a0
    800015c0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800015c2:	a1dff0ef          	jal	80000fde <myproc>
    800015c6:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    800015c8:	474040ef          	jal	80005a3c <acquire>
  release(lk);
    800015cc:	854a                	mv	a0,s2
    800015ce:	502040ef          	jal	80005ad0 <release>

  // Go to sleep.
  p->chan = chan;
    800015d2:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    800015d6:	4789                	li	a5,2
    800015d8:	cc9c                	sw	a5,24(s1)

  sched();
    800015da:	eefff0ef          	jal	800014c8 <sched>

  // Tidy up.
  p->chan = 0;
    800015de:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    800015e2:	8526                	mv	a0,s1
    800015e4:	4ec040ef          	jal	80005ad0 <release>
  acquire(lk);
    800015e8:	854a                	mv	a0,s2
    800015ea:	452040ef          	jal	80005a3c <acquire>
}
    800015ee:	70a2                	ld	ra,40(sp)
    800015f0:	7402                	ld	s0,32(sp)
    800015f2:	64e2                	ld	s1,24(sp)
    800015f4:	6942                	ld	s2,16(sp)
    800015f6:	69a2                	ld	s3,8(sp)
    800015f8:	6145                	addi	sp,sp,48
    800015fa:	8082                	ret

00000000800015fc <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800015fc:	7139                	addi	sp,sp,-64
    800015fe:	fc06                	sd	ra,56(sp)
    80001600:	f822                	sd	s0,48(sp)
    80001602:	f426                	sd	s1,40(sp)
    80001604:	f04a                	sd	s2,32(sp)
    80001606:	ec4e                	sd	s3,24(sp)
    80001608:	e852                	sd	s4,16(sp)
    8000160a:	e456                	sd	s5,8(sp)
    8000160c:	0080                	addi	s0,sp,64
    8000160e:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001610:	00007497          	auipc	s1,0x7
    80001614:	81048493          	addi	s1,s1,-2032 # 80007e20 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001618:	4989                	li	s3,2
        p->state = RUNNABLE;
    8000161a:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    8000161c:	0000c917          	auipc	s2,0xc
    80001620:	20490913          	addi	s2,s2,516 # 8000d820 <tickslock>
    80001624:	a801                	j	80001634 <wakeup+0x38>
      }
      release(&p->lock);
    80001626:	8526                	mv	a0,s1
    80001628:	4a8040ef          	jal	80005ad0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000162c:	16848493          	addi	s1,s1,360
    80001630:	03248263          	beq	s1,s2,80001654 <wakeup+0x58>
    if(p != myproc()){
    80001634:	9abff0ef          	jal	80000fde <myproc>
    80001638:	fe950ae3          	beq	a0,s1,8000162c <wakeup+0x30>
      acquire(&p->lock);
    8000163c:	8526                	mv	a0,s1
    8000163e:	3fe040ef          	jal	80005a3c <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001642:	4c9c                	lw	a5,24(s1)
    80001644:	ff3791e3          	bne	a5,s3,80001626 <wakeup+0x2a>
    80001648:	709c                	ld	a5,32(s1)
    8000164a:	fd479ee3          	bne	a5,s4,80001626 <wakeup+0x2a>
        p->state = RUNNABLE;
    8000164e:	0154ac23          	sw	s5,24(s1)
    80001652:	bfd1                	j	80001626 <wakeup+0x2a>
    }
  }
}
    80001654:	70e2                	ld	ra,56(sp)
    80001656:	7442                	ld	s0,48(sp)
    80001658:	74a2                	ld	s1,40(sp)
    8000165a:	7902                	ld	s2,32(sp)
    8000165c:	69e2                	ld	s3,24(sp)
    8000165e:	6a42                	ld	s4,16(sp)
    80001660:	6aa2                	ld	s5,8(sp)
    80001662:	6121                	addi	sp,sp,64
    80001664:	8082                	ret

0000000080001666 <reparent>:
{
    80001666:	7179                	addi	sp,sp,-48
    80001668:	f406                	sd	ra,40(sp)
    8000166a:	f022                	sd	s0,32(sp)
    8000166c:	ec26                	sd	s1,24(sp)
    8000166e:	e84a                	sd	s2,16(sp)
    80001670:	e44e                	sd	s3,8(sp)
    80001672:	e052                	sd	s4,0(sp)
    80001674:	1800                	addi	s0,sp,48
    80001676:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001678:	00006497          	auipc	s1,0x6
    8000167c:	7a848493          	addi	s1,s1,1960 # 80007e20 <proc>
      pp->parent = initproc;
    80001680:	00006a17          	auipc	s4,0x6
    80001684:	328a0a13          	addi	s4,s4,808 # 800079a8 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001688:	0000c997          	auipc	s3,0xc
    8000168c:	19898993          	addi	s3,s3,408 # 8000d820 <tickslock>
    80001690:	a029                	j	8000169a <reparent+0x34>
    80001692:	16848493          	addi	s1,s1,360
    80001696:	01348b63          	beq	s1,s3,800016ac <reparent+0x46>
    if(pp->parent == p){
    8000169a:	7c9c                	ld	a5,56(s1)
    8000169c:	ff279be3          	bne	a5,s2,80001692 <reparent+0x2c>
      pp->parent = initproc;
    800016a0:	000a3503          	ld	a0,0(s4)
    800016a4:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    800016a6:	f57ff0ef          	jal	800015fc <wakeup>
    800016aa:	b7e5                	j	80001692 <reparent+0x2c>
}
    800016ac:	70a2                	ld	ra,40(sp)
    800016ae:	7402                	ld	s0,32(sp)
    800016b0:	64e2                	ld	s1,24(sp)
    800016b2:	6942                	ld	s2,16(sp)
    800016b4:	69a2                	ld	s3,8(sp)
    800016b6:	6a02                	ld	s4,0(sp)
    800016b8:	6145                	addi	sp,sp,48
    800016ba:	8082                	ret

00000000800016bc <exit>:
{
    800016bc:	7179                	addi	sp,sp,-48
    800016be:	f406                	sd	ra,40(sp)
    800016c0:	f022                	sd	s0,32(sp)
    800016c2:	ec26                	sd	s1,24(sp)
    800016c4:	e84a                	sd	s2,16(sp)
    800016c6:	e44e                	sd	s3,8(sp)
    800016c8:	e052                	sd	s4,0(sp)
    800016ca:	1800                	addi	s0,sp,48
    800016cc:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800016ce:	911ff0ef          	jal	80000fde <myproc>
    800016d2:	89aa                	mv	s3,a0
  if(p == initproc)
    800016d4:	00006797          	auipc	a5,0x6
    800016d8:	2d47b783          	ld	a5,724(a5) # 800079a8 <initproc>
    800016dc:	0d050493          	addi	s1,a0,208
    800016e0:	15050913          	addi	s2,a0,336
    800016e4:	00a79b63          	bne	a5,a0,800016fa <exit+0x3e>
    panic("init exiting");
    800016e8:	00006517          	auipc	a0,0x6
    800016ec:	bf050513          	addi	a0,a0,-1040 # 800072d8 <etext+0x2d8>
    800016f0:	00e040ef          	jal	800056fe <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    800016f4:	04a1                	addi	s1,s1,8
    800016f6:	01248963          	beq	s1,s2,80001708 <exit+0x4c>
    if(p->ofile[fd]){
    800016fa:	6088                	ld	a0,0(s1)
    800016fc:	dd65                	beqz	a0,800016f4 <exit+0x38>
      fileclose(f);
    800016fe:	695010ef          	jal	80003592 <fileclose>
      p->ofile[fd] = 0;
    80001702:	0004b023          	sd	zero,0(s1)
    80001706:	b7fd                	j	800016f4 <exit+0x38>
  begin_op();
    80001708:	259010ef          	jal	80003160 <begin_op>
  iput(p->cwd);
    8000170c:	1509b503          	ld	a0,336(s3)
    80001710:	31a010ef          	jal	80002a2a <iput>
  end_op();
    80001714:	2bd010ef          	jal	800031d0 <end_op>
  p->cwd = 0;
    80001718:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000171c:	00006517          	auipc	a0,0x6
    80001720:	2ec50513          	addi	a0,a0,748 # 80007a08 <wait_lock>
    80001724:	318040ef          	jal	80005a3c <acquire>
  reparent(p);
    80001728:	854e                	mv	a0,s3
    8000172a:	f3dff0ef          	jal	80001666 <reparent>
  wakeup(p->parent);
    8000172e:	0389b503          	ld	a0,56(s3)
    80001732:	ecbff0ef          	jal	800015fc <wakeup>
  acquire(&p->lock);
    80001736:	854e                	mv	a0,s3
    80001738:	304040ef          	jal	80005a3c <acquire>
  p->xstate = status;
    8000173c:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80001740:	4795                	li	a5,5
    80001742:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80001746:	00006517          	auipc	a0,0x6
    8000174a:	2c250513          	addi	a0,a0,706 # 80007a08 <wait_lock>
    8000174e:	382040ef          	jal	80005ad0 <release>
  sched();
    80001752:	d77ff0ef          	jal	800014c8 <sched>
  panic("zombie exit");
    80001756:	00006517          	auipc	a0,0x6
    8000175a:	b9250513          	addi	a0,a0,-1134 # 800072e8 <etext+0x2e8>
    8000175e:	7a1030ef          	jal	800056fe <panic>

0000000080001762 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80001762:	7179                	addi	sp,sp,-48
    80001764:	f406                	sd	ra,40(sp)
    80001766:	f022                	sd	s0,32(sp)
    80001768:	ec26                	sd	s1,24(sp)
    8000176a:	e84a                	sd	s2,16(sp)
    8000176c:	e44e                	sd	s3,8(sp)
    8000176e:	1800                	addi	s0,sp,48
    80001770:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80001772:	00006497          	auipc	s1,0x6
    80001776:	6ae48493          	addi	s1,s1,1710 # 80007e20 <proc>
    8000177a:	0000c997          	auipc	s3,0xc
    8000177e:	0a698993          	addi	s3,s3,166 # 8000d820 <tickslock>
    acquire(&p->lock);
    80001782:	8526                	mv	a0,s1
    80001784:	2b8040ef          	jal	80005a3c <acquire>
    if(p->pid == pid){
    80001788:	589c                	lw	a5,48(s1)
    8000178a:	01278b63          	beq	a5,s2,800017a0 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000178e:	8526                	mv	a0,s1
    80001790:	340040ef          	jal	80005ad0 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80001794:	16848493          	addi	s1,s1,360
    80001798:	ff3495e3          	bne	s1,s3,80001782 <kill+0x20>
  }
  return -1;
    8000179c:	557d                	li	a0,-1
    8000179e:	a819                	j	800017b4 <kill+0x52>
      p->killed = 1;
    800017a0:	4785                	li	a5,1
    800017a2:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800017a4:	4c98                	lw	a4,24(s1)
    800017a6:	4789                	li	a5,2
    800017a8:	00f70d63          	beq	a4,a5,800017c2 <kill+0x60>
      release(&p->lock);
    800017ac:	8526                	mv	a0,s1
    800017ae:	322040ef          	jal	80005ad0 <release>
      return 0;
    800017b2:	4501                	li	a0,0
}
    800017b4:	70a2                	ld	ra,40(sp)
    800017b6:	7402                	ld	s0,32(sp)
    800017b8:	64e2                	ld	s1,24(sp)
    800017ba:	6942                	ld	s2,16(sp)
    800017bc:	69a2                	ld	s3,8(sp)
    800017be:	6145                	addi	sp,sp,48
    800017c0:	8082                	ret
        p->state = RUNNABLE;
    800017c2:	478d                	li	a5,3
    800017c4:	cc9c                	sw	a5,24(s1)
    800017c6:	b7dd                	j	800017ac <kill+0x4a>

00000000800017c8 <setkilled>:

void
setkilled(struct proc *p)
{
    800017c8:	1101                	addi	sp,sp,-32
    800017ca:	ec06                	sd	ra,24(sp)
    800017cc:	e822                	sd	s0,16(sp)
    800017ce:	e426                	sd	s1,8(sp)
    800017d0:	1000                	addi	s0,sp,32
    800017d2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800017d4:	268040ef          	jal	80005a3c <acquire>
  p->killed = 1;
    800017d8:	4785                	li	a5,1
    800017da:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800017dc:	8526                	mv	a0,s1
    800017de:	2f2040ef          	jal	80005ad0 <release>
}
    800017e2:	60e2                	ld	ra,24(sp)
    800017e4:	6442                	ld	s0,16(sp)
    800017e6:	64a2                	ld	s1,8(sp)
    800017e8:	6105                	addi	sp,sp,32
    800017ea:	8082                	ret

00000000800017ec <killed>:

int
killed(struct proc *p)
{
    800017ec:	1101                	addi	sp,sp,-32
    800017ee:	ec06                	sd	ra,24(sp)
    800017f0:	e822                	sd	s0,16(sp)
    800017f2:	e426                	sd	s1,8(sp)
    800017f4:	e04a                	sd	s2,0(sp)
    800017f6:	1000                	addi	s0,sp,32
    800017f8:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800017fa:	242040ef          	jal	80005a3c <acquire>
  k = p->killed;
    800017fe:	549c                	lw	a5,40(s1)
    80001800:	893e                	mv	s2,a5
  release(&p->lock);
    80001802:	8526                	mv	a0,s1
    80001804:	2cc040ef          	jal	80005ad0 <release>
  return k;
}
    80001808:	854a                	mv	a0,s2
    8000180a:	60e2                	ld	ra,24(sp)
    8000180c:	6442                	ld	s0,16(sp)
    8000180e:	64a2                	ld	s1,8(sp)
    80001810:	6902                	ld	s2,0(sp)
    80001812:	6105                	addi	sp,sp,32
    80001814:	8082                	ret

0000000080001816 <wait>:
{
    80001816:	715d                	addi	sp,sp,-80
    80001818:	e486                	sd	ra,72(sp)
    8000181a:	e0a2                	sd	s0,64(sp)
    8000181c:	fc26                	sd	s1,56(sp)
    8000181e:	f84a                	sd	s2,48(sp)
    80001820:	f44e                	sd	s3,40(sp)
    80001822:	f052                	sd	s4,32(sp)
    80001824:	ec56                	sd	s5,24(sp)
    80001826:	e85a                	sd	s6,16(sp)
    80001828:	e45e                	sd	s7,8(sp)
    8000182a:	0880                	addi	s0,sp,80
    8000182c:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    8000182e:	fb0ff0ef          	jal	80000fde <myproc>
    80001832:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80001834:	00006517          	auipc	a0,0x6
    80001838:	1d450513          	addi	a0,a0,468 # 80007a08 <wait_lock>
    8000183c:	200040ef          	jal	80005a3c <acquire>
        if(pp->state == ZOMBIE){
    80001840:	4a15                	li	s4,5
        havekids = 1;
    80001842:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001844:	0000c997          	auipc	s3,0xc
    80001848:	fdc98993          	addi	s3,s3,-36 # 8000d820 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000184c:	00006b17          	auipc	s6,0x6
    80001850:	1bcb0b13          	addi	s6,s6,444 # 80007a08 <wait_lock>
    80001854:	a869                	j	800018ee <wait+0xd8>
          pid = pp->pid;
    80001856:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000185a:	000b8c63          	beqz	s7,80001872 <wait+0x5c>
    8000185e:	4691                	li	a3,4
    80001860:	02c48613          	addi	a2,s1,44
    80001864:	85de                	mv	a1,s7
    80001866:	05093503          	ld	a0,80(s2)
    8000186a:	a6aff0ef          	jal	80000ad4 <copyout>
    8000186e:	02054a63          	bltz	a0,800018a2 <wait+0x8c>
          freeproc(pp);
    80001872:	8526                	mv	a0,s1
    80001874:	8dfff0ef          	jal	80001152 <freeproc>
          release(&pp->lock);
    80001878:	8526                	mv	a0,s1
    8000187a:	256040ef          	jal	80005ad0 <release>
          release(&wait_lock);
    8000187e:	00006517          	auipc	a0,0x6
    80001882:	18a50513          	addi	a0,a0,394 # 80007a08 <wait_lock>
    80001886:	24a040ef          	jal	80005ad0 <release>
}
    8000188a:	854e                	mv	a0,s3
    8000188c:	60a6                	ld	ra,72(sp)
    8000188e:	6406                	ld	s0,64(sp)
    80001890:	74e2                	ld	s1,56(sp)
    80001892:	7942                	ld	s2,48(sp)
    80001894:	79a2                	ld	s3,40(sp)
    80001896:	7a02                	ld	s4,32(sp)
    80001898:	6ae2                	ld	s5,24(sp)
    8000189a:	6b42                	ld	s6,16(sp)
    8000189c:	6ba2                	ld	s7,8(sp)
    8000189e:	6161                	addi	sp,sp,80
    800018a0:	8082                	ret
            release(&pp->lock);
    800018a2:	8526                	mv	a0,s1
    800018a4:	22c040ef          	jal	80005ad0 <release>
            release(&wait_lock);
    800018a8:	00006517          	auipc	a0,0x6
    800018ac:	16050513          	addi	a0,a0,352 # 80007a08 <wait_lock>
    800018b0:	220040ef          	jal	80005ad0 <release>
            return -1;
    800018b4:	59fd                	li	s3,-1
    800018b6:	bfd1                	j	8000188a <wait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800018b8:	16848493          	addi	s1,s1,360
    800018bc:	03348063          	beq	s1,s3,800018dc <wait+0xc6>
      if(pp->parent == p){
    800018c0:	7c9c                	ld	a5,56(s1)
    800018c2:	ff279be3          	bne	a5,s2,800018b8 <wait+0xa2>
        acquire(&pp->lock);
    800018c6:	8526                	mv	a0,s1
    800018c8:	174040ef          	jal	80005a3c <acquire>
        if(pp->state == ZOMBIE){
    800018cc:	4c9c                	lw	a5,24(s1)
    800018ce:	f94784e3          	beq	a5,s4,80001856 <wait+0x40>
        release(&pp->lock);
    800018d2:	8526                	mv	a0,s1
    800018d4:	1fc040ef          	jal	80005ad0 <release>
        havekids = 1;
    800018d8:	8756                	mv	a4,s5
    800018da:	bff9                	j	800018b8 <wait+0xa2>
    if(!havekids || killed(p)){
    800018dc:	cf19                	beqz	a4,800018fa <wait+0xe4>
    800018de:	854a                	mv	a0,s2
    800018e0:	f0dff0ef          	jal	800017ec <killed>
    800018e4:	e919                	bnez	a0,800018fa <wait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800018e6:	85da                	mv	a1,s6
    800018e8:	854a                	mv	a0,s2
    800018ea:	cc7ff0ef          	jal	800015b0 <sleep>
    havekids = 0;
    800018ee:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800018f0:	00006497          	auipc	s1,0x6
    800018f4:	53048493          	addi	s1,s1,1328 # 80007e20 <proc>
    800018f8:	b7e1                	j	800018c0 <wait+0xaa>
      release(&wait_lock);
    800018fa:	00006517          	auipc	a0,0x6
    800018fe:	10e50513          	addi	a0,a0,270 # 80007a08 <wait_lock>
    80001902:	1ce040ef          	jal	80005ad0 <release>
      return -1;
    80001906:	59fd                	li	s3,-1
    80001908:	b749                	j	8000188a <wait+0x74>

000000008000190a <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000190a:	7179                	addi	sp,sp,-48
    8000190c:	f406                	sd	ra,40(sp)
    8000190e:	f022                	sd	s0,32(sp)
    80001910:	ec26                	sd	s1,24(sp)
    80001912:	e84a                	sd	s2,16(sp)
    80001914:	e44e                	sd	s3,8(sp)
    80001916:	e052                	sd	s4,0(sp)
    80001918:	1800                	addi	s0,sp,48
    8000191a:	84aa                	mv	s1,a0
    8000191c:	8a2e                	mv	s4,a1
    8000191e:	89b2                	mv	s3,a2
    80001920:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80001922:	ebcff0ef          	jal	80000fde <myproc>
  if(user_dst){
    80001926:	cc99                	beqz	s1,80001944 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80001928:	86ca                	mv	a3,s2
    8000192a:	864e                	mv	a2,s3
    8000192c:	85d2                	mv	a1,s4
    8000192e:	6928                	ld	a0,80(a0)
    80001930:	9a4ff0ef          	jal	80000ad4 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80001934:	70a2                	ld	ra,40(sp)
    80001936:	7402                	ld	s0,32(sp)
    80001938:	64e2                	ld	s1,24(sp)
    8000193a:	6942                	ld	s2,16(sp)
    8000193c:	69a2                	ld	s3,8(sp)
    8000193e:	6a02                	ld	s4,0(sp)
    80001940:	6145                	addi	sp,sp,48
    80001942:	8082                	ret
    memmove((char *)dst, src, len);
    80001944:	0009061b          	sext.w	a2,s2
    80001948:	85ce                	mv	a1,s3
    8000194a:	8552                	mv	a0,s4
    8000194c:	931fe0ef          	jal	8000027c <memmove>
    return 0;
    80001950:	8526                	mv	a0,s1
    80001952:	b7cd                	j	80001934 <either_copyout+0x2a>

0000000080001954 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80001954:	7179                	addi	sp,sp,-48
    80001956:	f406                	sd	ra,40(sp)
    80001958:	f022                	sd	s0,32(sp)
    8000195a:	ec26                	sd	s1,24(sp)
    8000195c:	e84a                	sd	s2,16(sp)
    8000195e:	e44e                	sd	s3,8(sp)
    80001960:	e052                	sd	s4,0(sp)
    80001962:	1800                	addi	s0,sp,48
    80001964:	8a2a                	mv	s4,a0
    80001966:	84ae                	mv	s1,a1
    80001968:	89b2                	mv	s3,a2
    8000196a:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000196c:	e72ff0ef          	jal	80000fde <myproc>
  if(user_src){
    80001970:	cc99                	beqz	s1,8000198e <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80001972:	86ca                	mv	a3,s2
    80001974:	864e                	mv	a2,s3
    80001976:	85d2                	mv	a1,s4
    80001978:	6928                	ld	a0,80(a0)
    8000197a:	ad0ff0ef          	jal	80000c4a <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    8000197e:	70a2                	ld	ra,40(sp)
    80001980:	7402                	ld	s0,32(sp)
    80001982:	64e2                	ld	s1,24(sp)
    80001984:	6942                	ld	s2,16(sp)
    80001986:	69a2                	ld	s3,8(sp)
    80001988:	6a02                	ld	s4,0(sp)
    8000198a:	6145                	addi	sp,sp,48
    8000198c:	8082                	ret
    memmove(dst, (char*)src, len);
    8000198e:	0009061b          	sext.w	a2,s2
    80001992:	85ce                	mv	a1,s3
    80001994:	8552                	mv	a0,s4
    80001996:	8e7fe0ef          	jal	8000027c <memmove>
    return 0;
    8000199a:	8526                	mv	a0,s1
    8000199c:	b7cd                	j	8000197e <either_copyin+0x2a>

000000008000199e <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000199e:	715d                	addi	sp,sp,-80
    800019a0:	e486                	sd	ra,72(sp)
    800019a2:	e0a2                	sd	s0,64(sp)
    800019a4:	fc26                	sd	s1,56(sp)
    800019a6:	f84a                	sd	s2,48(sp)
    800019a8:	f44e                	sd	s3,40(sp)
    800019aa:	f052                	sd	s4,32(sp)
    800019ac:	ec56                	sd	s5,24(sp)
    800019ae:	e85a                	sd	s6,16(sp)
    800019b0:	e45e                	sd	s7,8(sp)
    800019b2:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800019b4:	00005517          	auipc	a0,0x5
    800019b8:	66450513          	addi	a0,a0,1636 # 80007018 <etext+0x18>
    800019bc:	233030ef          	jal	800053ee <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800019c0:	00006497          	auipc	s1,0x6
    800019c4:	5b848493          	addi	s1,s1,1464 # 80007f78 <proc+0x158>
    800019c8:	0000c917          	auipc	s2,0xc
    800019cc:	fb090913          	addi	s2,s2,-80 # 8000d978 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800019d0:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800019d2:	00006997          	auipc	s3,0x6
    800019d6:	92698993          	addi	s3,s3,-1754 # 800072f8 <etext+0x2f8>
    printf("%d %s %s", p->pid, state, p->name);
    800019da:	00006a97          	auipc	s5,0x6
    800019de:	926a8a93          	addi	s5,s5,-1754 # 80007300 <etext+0x300>
    printf("\n");
    800019e2:	00005a17          	auipc	s4,0x5
    800019e6:	636a0a13          	addi	s4,s4,1590 # 80007018 <etext+0x18>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800019ea:	00006b97          	auipc	s7,0x6
    800019ee:	e3eb8b93          	addi	s7,s7,-450 # 80007828 <states.0>
    800019f2:	a829                	j	80001a0c <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800019f4:	ed86a583          	lw	a1,-296(a3)
    800019f8:	8556                	mv	a0,s5
    800019fa:	1f5030ef          	jal	800053ee <printf>
    printf("\n");
    800019fe:	8552                	mv	a0,s4
    80001a00:	1ef030ef          	jal	800053ee <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001a04:	16848493          	addi	s1,s1,360
    80001a08:	03248263          	beq	s1,s2,80001a2c <procdump+0x8e>
    if(p->state == UNUSED)
    80001a0c:	86a6                	mv	a3,s1
    80001a0e:	ec04a783          	lw	a5,-320(s1)
    80001a12:	dbed                	beqz	a5,80001a04 <procdump+0x66>
      state = "???";
    80001a14:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001a16:	fcfb6fe3          	bltu	s6,a5,800019f4 <procdump+0x56>
    80001a1a:	02079713          	slli	a4,a5,0x20
    80001a1e:	01d75793          	srli	a5,a4,0x1d
    80001a22:	97de                	add	a5,a5,s7
    80001a24:	6390                	ld	a2,0(a5)
    80001a26:	f679                	bnez	a2,800019f4 <procdump+0x56>
      state = "???";
    80001a28:	864e                	mv	a2,s3
    80001a2a:	b7e9                	j	800019f4 <procdump+0x56>
  }
}
    80001a2c:	60a6                	ld	ra,72(sp)
    80001a2e:	6406                	ld	s0,64(sp)
    80001a30:	74e2                	ld	s1,56(sp)
    80001a32:	7942                	ld	s2,48(sp)
    80001a34:	79a2                	ld	s3,40(sp)
    80001a36:	7a02                	ld	s4,32(sp)
    80001a38:	6ae2                	ld	s5,24(sp)
    80001a3a:	6b42                	ld	s6,16(sp)
    80001a3c:	6ba2                	ld	s7,8(sp)
    80001a3e:	6161                	addi	sp,sp,80
    80001a40:	8082                	ret

0000000080001a42 <swtch>:
    80001a42:	00153023          	sd	ra,0(a0)
    80001a46:	00253423          	sd	sp,8(a0)
    80001a4a:	e900                	sd	s0,16(a0)
    80001a4c:	ed04                	sd	s1,24(a0)
    80001a4e:	03253023          	sd	s2,32(a0)
    80001a52:	03353423          	sd	s3,40(a0)
    80001a56:	03453823          	sd	s4,48(a0)
    80001a5a:	03553c23          	sd	s5,56(a0)
    80001a5e:	05653023          	sd	s6,64(a0)
    80001a62:	05753423          	sd	s7,72(a0)
    80001a66:	05853823          	sd	s8,80(a0)
    80001a6a:	05953c23          	sd	s9,88(a0)
    80001a6e:	07a53023          	sd	s10,96(a0)
    80001a72:	07b53423          	sd	s11,104(a0)
    80001a76:	0005b083          	ld	ra,0(a1)
    80001a7a:	0085b103          	ld	sp,8(a1)
    80001a7e:	6980                	ld	s0,16(a1)
    80001a80:	6d84                	ld	s1,24(a1)
    80001a82:	0205b903          	ld	s2,32(a1)
    80001a86:	0285b983          	ld	s3,40(a1)
    80001a8a:	0305ba03          	ld	s4,48(a1)
    80001a8e:	0385ba83          	ld	s5,56(a1)
    80001a92:	0405bb03          	ld	s6,64(a1)
    80001a96:	0485bb83          	ld	s7,72(a1)
    80001a9a:	0505bc03          	ld	s8,80(a1)
    80001a9e:	0585bc83          	ld	s9,88(a1)
    80001aa2:	0605bd03          	ld	s10,96(a1)
    80001aa6:	0685bd83          	ld	s11,104(a1)
    80001aaa:	8082                	ret

0000000080001aac <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001aac:	1141                	addi	sp,sp,-16
    80001aae:	e406                	sd	ra,8(sp)
    80001ab0:	e022                	sd	s0,0(sp)
    80001ab2:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001ab4:	00006597          	auipc	a1,0x6
    80001ab8:	88c58593          	addi	a1,a1,-1908 # 80007340 <etext+0x340>
    80001abc:	0000c517          	auipc	a0,0xc
    80001ac0:	d6450513          	addi	a0,a0,-668 # 8000d820 <tickslock>
    80001ac4:	6ef030ef          	jal	800059b2 <initlock>
}
    80001ac8:	60a2                	ld	ra,8(sp)
    80001aca:	6402                	ld	s0,0(sp)
    80001acc:	0141                	addi	sp,sp,16
    80001ace:	8082                	ret

0000000080001ad0 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80001ad0:	1141                	addi	sp,sp,-16
    80001ad2:	e406                	sd	ra,8(sp)
    80001ad4:	e022                	sd	s0,0(sp)
    80001ad6:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001ad8:	00003797          	auipc	a5,0x3
    80001adc:	e7878793          	addi	a5,a5,-392 # 80004950 <kernelvec>
    80001ae0:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80001ae4:	60a2                	ld	ra,8(sp)
    80001ae6:	6402                	ld	s0,0(sp)
    80001ae8:	0141                	addi	sp,sp,16
    80001aea:	8082                	ret

0000000080001aec <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80001aec:	1141                	addi	sp,sp,-16
    80001aee:	e406                	sd	ra,8(sp)
    80001af0:	e022                	sd	s0,0(sp)
    80001af2:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80001af4:	ceaff0ef          	jal	80000fde <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001af8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001afc:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001afe:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80001b02:	00004697          	auipc	a3,0x4
    80001b06:	4fe68693          	addi	a3,a3,1278 # 80006000 <_trampoline>
    80001b0a:	00004717          	auipc	a4,0x4
    80001b0e:	4f670713          	addi	a4,a4,1270 # 80006000 <_trampoline>
    80001b12:	8f15                	sub	a4,a4,a3
    80001b14:	040007b7          	lui	a5,0x4000
    80001b18:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80001b1a:	07b2                	slli	a5,a5,0xc
    80001b1c:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001b1e:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80001b22:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80001b24:	18002673          	csrr	a2,satp
    80001b28:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80001b2a:	6d30                	ld	a2,88(a0)
    80001b2c:	6138                	ld	a4,64(a0)
    80001b2e:	6585                	lui	a1,0x1
    80001b30:	972e                	add	a4,a4,a1
    80001b32:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80001b34:	6d38                	ld	a4,88(a0)
    80001b36:	00000617          	auipc	a2,0x0
    80001b3a:	11460613          	addi	a2,a2,276 # 80001c4a <usertrap>
    80001b3e:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80001b40:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80001b42:	8612                	mv	a2,tp
    80001b44:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b46:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80001b4a:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80001b4e:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001b52:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80001b56:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001b58:	6f18                	ld	a4,24(a4)
    80001b5a:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001b5e:	6928                	ld	a0,80(a0)
    80001b60:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001b62:	00004717          	auipc	a4,0x4
    80001b66:	53a70713          	addi	a4,a4,1338 # 8000609c <userret>
    80001b6a:	8f15                	sub	a4,a4,a3
    80001b6c:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001b6e:	577d                	li	a4,-1
    80001b70:	177e                	slli	a4,a4,0x3f
    80001b72:	8d59                	or	a0,a0,a4
    80001b74:	9782                	jalr	a5
}
    80001b76:	60a2                	ld	ra,8(sp)
    80001b78:	6402                	ld	s0,0(sp)
    80001b7a:	0141                	addi	sp,sp,16
    80001b7c:	8082                	ret

0000000080001b7e <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001b7e:	1141                	addi	sp,sp,-16
    80001b80:	e406                	sd	ra,8(sp)
    80001b82:	e022                	sd	s0,0(sp)
    80001b84:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80001b86:	c24ff0ef          	jal	80000faa <cpuid>
    80001b8a:	cd11                	beqz	a0,80001ba6 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001b8c:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001b90:	000f4737          	lui	a4,0xf4
    80001b94:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80001b98:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80001b9a:	14d79073          	csrw	stimecmp,a5
}
    80001b9e:	60a2                	ld	ra,8(sp)
    80001ba0:	6402                	ld	s0,0(sp)
    80001ba2:	0141                	addi	sp,sp,16
    80001ba4:	8082                	ret
    acquire(&tickslock);
    80001ba6:	0000c517          	auipc	a0,0xc
    80001baa:	c7a50513          	addi	a0,a0,-902 # 8000d820 <tickslock>
    80001bae:	68f030ef          	jal	80005a3c <acquire>
    ticks++;
    80001bb2:	00006717          	auipc	a4,0x6
    80001bb6:	dfe70713          	addi	a4,a4,-514 # 800079b0 <ticks>
    80001bba:	431c                	lw	a5,0(a4)
    80001bbc:	2785                	addiw	a5,a5,1
    80001bbe:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80001bc0:	853a                	mv	a0,a4
    80001bc2:	a3bff0ef          	jal	800015fc <wakeup>
    release(&tickslock);
    80001bc6:	0000c517          	auipc	a0,0xc
    80001bca:	c5a50513          	addi	a0,a0,-934 # 8000d820 <tickslock>
    80001bce:	703030ef          	jal	80005ad0 <release>
    80001bd2:	bf6d                	j	80001b8c <clockintr+0xe>

0000000080001bd4 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001bd4:	1101                	addi	sp,sp,-32
    80001bd6:	ec06                	sd	ra,24(sp)
    80001bd8:	e822                	sd	s0,16(sp)
    80001bda:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001bdc:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001be0:	57fd                	li	a5,-1
    80001be2:	17fe                	slli	a5,a5,0x3f
    80001be4:	07a5                	addi	a5,a5,9
    80001be6:	00f70c63          	beq	a4,a5,80001bfe <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80001bea:	57fd                	li	a5,-1
    80001bec:	17fe                	slli	a5,a5,0x3f
    80001bee:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001bf0:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001bf2:	04f70863          	beq	a4,a5,80001c42 <devintr+0x6e>
  }
}
    80001bf6:	60e2                	ld	ra,24(sp)
    80001bf8:	6442                	ld	s0,16(sp)
    80001bfa:	6105                	addi	sp,sp,32
    80001bfc:	8082                	ret
    80001bfe:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80001c00:	5fd020ef          	jal	800049fc <plic_claim>
    80001c04:	872a                	mv	a4,a0
    80001c06:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001c08:	47a9                	li	a5,10
    80001c0a:	00f50963          	beq	a0,a5,80001c1c <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    80001c0e:	4785                	li	a5,1
    80001c10:	00f50963          	beq	a0,a5,80001c22 <devintr+0x4e>
    return 1;
    80001c14:	4505                	li	a0,1
    } else if(irq){
    80001c16:	eb09                	bnez	a4,80001c28 <devintr+0x54>
    80001c18:	64a2                	ld	s1,8(sp)
    80001c1a:	bff1                	j	80001bf6 <devintr+0x22>
      uartintr();
    80001c1c:	557030ef          	jal	80005972 <uartintr>
    if(irq)
    80001c20:	a819                	j	80001c36 <devintr+0x62>
      virtio_disk_intr();
    80001c22:	270030ef          	jal	80004e92 <virtio_disk_intr>
    if(irq)
    80001c26:	a801                	j	80001c36 <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    80001c28:	85ba                	mv	a1,a4
    80001c2a:	00005517          	auipc	a0,0x5
    80001c2e:	71e50513          	addi	a0,a0,1822 # 80007348 <etext+0x348>
    80001c32:	7bc030ef          	jal	800053ee <printf>
      plic_complete(irq);
    80001c36:	8526                	mv	a0,s1
    80001c38:	5e5020ef          	jal	80004a1c <plic_complete>
    return 1;
    80001c3c:	4505                	li	a0,1
    80001c3e:	64a2                	ld	s1,8(sp)
    80001c40:	bf5d                	j	80001bf6 <devintr+0x22>
    clockintr();
    80001c42:	f3dff0ef          	jal	80001b7e <clockintr>
    return 2;
    80001c46:	4509                	li	a0,2
    80001c48:	b77d                	j	80001bf6 <devintr+0x22>

0000000080001c4a <usertrap>:
{
    80001c4a:	1101                	addi	sp,sp,-32
    80001c4c:	ec06                	sd	ra,24(sp)
    80001c4e:	e822                	sd	s0,16(sp)
    80001c50:	e426                	sd	s1,8(sp)
    80001c52:	e04a                	sd	s2,0(sp)
    80001c54:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c56:	100027f3          	csrr	a5,sstatus
    if((r_sstatus() & SSTATUS_SPP) != 0)
    80001c5a:	1007f793          	andi	a5,a5,256
    80001c5e:	e3a9                	bnez	a5,80001ca0 <usertrap+0x56>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001c60:	00003797          	auipc	a5,0x3
    80001c64:	cf078793          	addi	a5,a5,-784 # 80004950 <kernelvec>
    80001c68:	10579073          	csrw	stvec,a5
    struct proc *p = myproc();
    80001c6c:	b72ff0ef          	jal	80000fde <myproc>
    80001c70:	84aa                	mv	s1,a0
    p->trapframe->epc = r_sepc();
    80001c72:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001c74:	14102773          	csrr	a4,sepc
    80001c78:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001c7a:	14202773          	csrr	a4,scause
    if(r_scause() == 8){
    80001c7e:	47a1                	li	a5,8
    80001c80:	02f70663          	beq	a4,a5,80001cac <usertrap+0x62>
    80001c84:	14202773          	csrr	a4,scause
    } else if(r_scause() == 15){
    80001c88:	47bd                	li	a5,15
    80001c8a:	04f70563          	beq	a4,a5,80001cd4 <usertrap+0x8a>
    } else if((which_dev = devintr()) != 0){
    80001c8e:	f47ff0ef          	jal	80001bd4 <devintr>
    80001c92:	892a                	mv	s2,a0
    80001c94:	c125                	beqz	a0,80001cf4 <usertrap+0xaa>
    if(killed(p))
    80001c96:	8526                	mv	a0,s1
    80001c98:	b55ff0ef          	jal	800017ec <killed>
    80001c9c:	c559                	beqz	a0,80001d2a <usertrap+0xe0>
    80001c9e:	a059                	j	80001d24 <usertrap+0xda>
        panic("usertrap: not from user mode");
    80001ca0:	00005517          	auipc	a0,0x5
    80001ca4:	6c850513          	addi	a0,a0,1736 # 80007368 <etext+0x368>
    80001ca8:	257030ef          	jal	800056fe <panic>
        if(killed(p))
    80001cac:	b41ff0ef          	jal	800017ec <killed>
    80001cb0:	ed11                	bnez	a0,80001ccc <usertrap+0x82>
        p->trapframe->epc += 4;
    80001cb2:	6cb8                	ld	a4,88(s1)
    80001cb4:	6f1c                	ld	a5,24(a4)
    80001cb6:	0791                	addi	a5,a5,4
    80001cb8:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001cba:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001cbe:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001cc2:	10079073          	csrw	sstatus,a5
        syscall();
    80001cc6:	24c000ef          	jal	80001f12 <syscall>
    80001cca:	a809                	j	80001cdc <usertrap+0x92>
            exit(-1);
    80001ccc:	557d                	li	a0,-1
    80001cce:	9efff0ef          	jal	800016bc <exit>
    80001cd2:	b7c5                	j	80001cb2 <usertrap+0x68>
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001cd4:	14302573          	csrr	a0,stval
        cow_handler(r_stval());  // 修改了函数名
    80001cd8:	8b4ff0ef          	jal	80000d8c <cow_handler>
    if(killed(p))
    80001cdc:	8526                	mv	a0,s1
    80001cde:	b0fff0ef          	jal	800017ec <killed>
    80001ce2:	e121                	bnez	a0,80001d22 <usertrap+0xd8>
    usertrapret();
    80001ce4:	e09ff0ef          	jal	80001aec <usertrapret>
}
    80001ce8:	60e2                	ld	ra,24(sp)
    80001cea:	6442                	ld	s0,16(sp)
    80001cec:	64a2                	ld	s1,8(sp)
    80001cee:	6902                	ld	s2,0(sp)
    80001cf0:	6105                	addi	sp,sp,32
    80001cf2:	8082                	ret
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001cf4:	142025f3          	csrr	a1,scause
        printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001cf8:	5890                	lw	a2,48(s1)
    80001cfa:	00005517          	auipc	a0,0x5
    80001cfe:	68e50513          	addi	a0,a0,1678 # 80007388 <etext+0x388>
    80001d02:	6ec030ef          	jal	800053ee <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001d06:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001d0a:	14302673          	csrr	a2,stval
        printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001d0e:	00005517          	auipc	a0,0x5
    80001d12:	6aa50513          	addi	a0,a0,1706 # 800073b8 <etext+0x3b8>
    80001d16:	6d8030ef          	jal	800053ee <printf>
        setkilled(p);
    80001d1a:	8526                	mv	a0,s1
    80001d1c:	aadff0ef          	jal	800017c8 <setkilled>
    80001d20:	bf75                	j	80001cdc <usertrap+0x92>
    if(killed(p))
    80001d22:	4901                	li	s2,0
        exit(-1);
    80001d24:	557d                	li	a0,-1
    80001d26:	997ff0ef          	jal	800016bc <exit>
    if(which_dev == 2)
    80001d2a:	4789                	li	a5,2
    80001d2c:	faf91ce3          	bne	s2,a5,80001ce4 <usertrap+0x9a>
        yield();
    80001d30:	855ff0ef          	jal	80001584 <yield>
    80001d34:	bf45                	j	80001ce4 <usertrap+0x9a>

0000000080001d36 <kerneltrap>:
{
    80001d36:	7179                	addi	sp,sp,-48
    80001d38:	f406                	sd	ra,40(sp)
    80001d3a:	f022                	sd	s0,32(sp)
    80001d3c:	ec26                	sd	s1,24(sp)
    80001d3e:	e84a                	sd	s2,16(sp)
    80001d40:	e44e                	sd	s3,8(sp)
    80001d42:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001d44:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001d48:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001d4c:	142027f3          	csrr	a5,scause
    80001d50:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80001d52:	1004f793          	andi	a5,s1,256
    80001d56:	c795                	beqz	a5,80001d82 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001d58:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001d5c:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001d5e:	eb85                	bnez	a5,80001d8e <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80001d60:	e75ff0ef          	jal	80001bd4 <devintr>
    80001d64:	c91d                	beqz	a0,80001d9a <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80001d66:	4789                	li	a5,2
    80001d68:	04f50a63          	beq	a0,a5,80001dbc <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001d6c:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001d70:	10049073          	csrw	sstatus,s1
}
    80001d74:	70a2                	ld	ra,40(sp)
    80001d76:	7402                	ld	s0,32(sp)
    80001d78:	64e2                	ld	s1,24(sp)
    80001d7a:	6942                	ld	s2,16(sp)
    80001d7c:	69a2                	ld	s3,8(sp)
    80001d7e:	6145                	addi	sp,sp,48
    80001d80:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001d82:	00005517          	auipc	a0,0x5
    80001d86:	65e50513          	addi	a0,a0,1630 # 800073e0 <etext+0x3e0>
    80001d8a:	175030ef          	jal	800056fe <panic>
    panic("kerneltrap: interrupts enabled");
    80001d8e:	00005517          	auipc	a0,0x5
    80001d92:	67a50513          	addi	a0,a0,1658 # 80007408 <etext+0x408>
    80001d96:	169030ef          	jal	800056fe <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001d9a:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001d9e:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001da2:	85ce                	mv	a1,s3
    80001da4:	00005517          	auipc	a0,0x5
    80001da8:	68450513          	addi	a0,a0,1668 # 80007428 <etext+0x428>
    80001dac:	642030ef          	jal	800053ee <printf>
    panic("kerneltrap");
    80001db0:	00005517          	auipc	a0,0x5
    80001db4:	6a050513          	addi	a0,a0,1696 # 80007450 <etext+0x450>
    80001db8:	147030ef          	jal	800056fe <panic>
  if(which_dev == 2 && myproc() != 0)
    80001dbc:	a22ff0ef          	jal	80000fde <myproc>
    80001dc0:	d555                	beqz	a0,80001d6c <kerneltrap+0x36>
    yield();
    80001dc2:	fc2ff0ef          	jal	80001584 <yield>
    80001dc6:	b75d                	j	80001d6c <kerneltrap+0x36>

0000000080001dc8 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001dc8:	1101                	addi	sp,sp,-32
    80001dca:	ec06                	sd	ra,24(sp)
    80001dcc:	e822                	sd	s0,16(sp)
    80001dce:	e426                	sd	s1,8(sp)
    80001dd0:	1000                	addi	s0,sp,32
    80001dd2:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001dd4:	a0aff0ef          	jal	80000fde <myproc>
  switch (n) {
    80001dd8:	4795                	li	a5,5
    80001dda:	0497e163          	bltu	a5,s1,80001e1c <argraw+0x54>
    80001dde:	048a                	slli	s1,s1,0x2
    80001de0:	00006717          	auipc	a4,0x6
    80001de4:	a7870713          	addi	a4,a4,-1416 # 80007858 <states.0+0x30>
    80001de8:	94ba                	add	s1,s1,a4
    80001dea:	409c                	lw	a5,0(s1)
    80001dec:	97ba                	add	a5,a5,a4
    80001dee:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001df0:	6d3c                	ld	a5,88(a0)
    80001df2:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001df4:	60e2                	ld	ra,24(sp)
    80001df6:	6442                	ld	s0,16(sp)
    80001df8:	64a2                	ld	s1,8(sp)
    80001dfa:	6105                	addi	sp,sp,32
    80001dfc:	8082                	ret
    return p->trapframe->a1;
    80001dfe:	6d3c                	ld	a5,88(a0)
    80001e00:	7fa8                	ld	a0,120(a5)
    80001e02:	bfcd                	j	80001df4 <argraw+0x2c>
    return p->trapframe->a2;
    80001e04:	6d3c                	ld	a5,88(a0)
    80001e06:	63c8                	ld	a0,128(a5)
    80001e08:	b7f5                	j	80001df4 <argraw+0x2c>
    return p->trapframe->a3;
    80001e0a:	6d3c                	ld	a5,88(a0)
    80001e0c:	67c8                	ld	a0,136(a5)
    80001e0e:	b7dd                	j	80001df4 <argraw+0x2c>
    return p->trapframe->a4;
    80001e10:	6d3c                	ld	a5,88(a0)
    80001e12:	6bc8                	ld	a0,144(a5)
    80001e14:	b7c5                	j	80001df4 <argraw+0x2c>
    return p->trapframe->a5;
    80001e16:	6d3c                	ld	a5,88(a0)
    80001e18:	6fc8                	ld	a0,152(a5)
    80001e1a:	bfe9                	j	80001df4 <argraw+0x2c>
  panic("argraw");
    80001e1c:	00005517          	auipc	a0,0x5
    80001e20:	64450513          	addi	a0,a0,1604 # 80007460 <etext+0x460>
    80001e24:	0db030ef          	jal	800056fe <panic>

0000000080001e28 <fetchaddr>:
{
    80001e28:	1101                	addi	sp,sp,-32
    80001e2a:	ec06                	sd	ra,24(sp)
    80001e2c:	e822                	sd	s0,16(sp)
    80001e2e:	e426                	sd	s1,8(sp)
    80001e30:	e04a                	sd	s2,0(sp)
    80001e32:	1000                	addi	s0,sp,32
    80001e34:	84aa                	mv	s1,a0
    80001e36:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001e38:	9a6ff0ef          	jal	80000fde <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001e3c:	653c                	ld	a5,72(a0)
    80001e3e:	02f4f663          	bgeu	s1,a5,80001e6a <fetchaddr+0x42>
    80001e42:	00848713          	addi	a4,s1,8
    80001e46:	02e7e463          	bltu	a5,a4,80001e6e <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001e4a:	46a1                	li	a3,8
    80001e4c:	8626                	mv	a2,s1
    80001e4e:	85ca                	mv	a1,s2
    80001e50:	6928                	ld	a0,80(a0)
    80001e52:	df9fe0ef          	jal	80000c4a <copyin>
    80001e56:	00a03533          	snez	a0,a0
    80001e5a:	40a0053b          	negw	a0,a0
}
    80001e5e:	60e2                	ld	ra,24(sp)
    80001e60:	6442                	ld	s0,16(sp)
    80001e62:	64a2                	ld	s1,8(sp)
    80001e64:	6902                	ld	s2,0(sp)
    80001e66:	6105                	addi	sp,sp,32
    80001e68:	8082                	ret
    return -1;
    80001e6a:	557d                	li	a0,-1
    80001e6c:	bfcd                	j	80001e5e <fetchaddr+0x36>
    80001e6e:	557d                	li	a0,-1
    80001e70:	b7fd                	j	80001e5e <fetchaddr+0x36>

0000000080001e72 <fetchstr>:
{
    80001e72:	7179                	addi	sp,sp,-48
    80001e74:	f406                	sd	ra,40(sp)
    80001e76:	f022                	sd	s0,32(sp)
    80001e78:	ec26                	sd	s1,24(sp)
    80001e7a:	e84a                	sd	s2,16(sp)
    80001e7c:	e44e                	sd	s3,8(sp)
    80001e7e:	1800                	addi	s0,sp,48
    80001e80:	89aa                	mv	s3,a0
    80001e82:	84ae                	mv	s1,a1
    80001e84:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80001e86:	958ff0ef          	jal	80000fde <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001e8a:	86ca                	mv	a3,s2
    80001e8c:	864e                	mv	a2,s3
    80001e8e:	85a6                	mv	a1,s1
    80001e90:	6928                	ld	a0,80(a0)
    80001e92:	e3ffe0ef          	jal	80000cd0 <copyinstr>
    80001e96:	00054c63          	bltz	a0,80001eae <fetchstr+0x3c>
  return strlen(buf);
    80001e9a:	8526                	mv	a0,s1
    80001e9c:	d0afe0ef          	jal	800003a6 <strlen>
}
    80001ea0:	70a2                	ld	ra,40(sp)
    80001ea2:	7402                	ld	s0,32(sp)
    80001ea4:	64e2                	ld	s1,24(sp)
    80001ea6:	6942                	ld	s2,16(sp)
    80001ea8:	69a2                	ld	s3,8(sp)
    80001eaa:	6145                	addi	sp,sp,48
    80001eac:	8082                	ret
    return -1;
    80001eae:	557d                	li	a0,-1
    80001eb0:	bfc5                	j	80001ea0 <fetchstr+0x2e>

0000000080001eb2 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001eb2:	1101                	addi	sp,sp,-32
    80001eb4:	ec06                	sd	ra,24(sp)
    80001eb6:	e822                	sd	s0,16(sp)
    80001eb8:	e426                	sd	s1,8(sp)
    80001eba:	1000                	addi	s0,sp,32
    80001ebc:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001ebe:	f0bff0ef          	jal	80001dc8 <argraw>
    80001ec2:	c088                	sw	a0,0(s1)
}
    80001ec4:	60e2                	ld	ra,24(sp)
    80001ec6:	6442                	ld	s0,16(sp)
    80001ec8:	64a2                	ld	s1,8(sp)
    80001eca:	6105                	addi	sp,sp,32
    80001ecc:	8082                	ret

0000000080001ece <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001ece:	1101                	addi	sp,sp,-32
    80001ed0:	ec06                	sd	ra,24(sp)
    80001ed2:	e822                	sd	s0,16(sp)
    80001ed4:	e426                	sd	s1,8(sp)
    80001ed6:	1000                	addi	s0,sp,32
    80001ed8:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001eda:	eefff0ef          	jal	80001dc8 <argraw>
    80001ede:	e088                	sd	a0,0(s1)
}
    80001ee0:	60e2                	ld	ra,24(sp)
    80001ee2:	6442                	ld	s0,16(sp)
    80001ee4:	64a2                	ld	s1,8(sp)
    80001ee6:	6105                	addi	sp,sp,32
    80001ee8:	8082                	ret

0000000080001eea <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001eea:	1101                	addi	sp,sp,-32
    80001eec:	ec06                	sd	ra,24(sp)
    80001eee:	e822                	sd	s0,16(sp)
    80001ef0:	e426                	sd	s1,8(sp)
    80001ef2:	e04a                	sd	s2,0(sp)
    80001ef4:	1000                	addi	s0,sp,32
    80001ef6:	892e                	mv	s2,a1
    80001ef8:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80001efa:	ecfff0ef          	jal	80001dc8 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80001efe:	8626                	mv	a2,s1
    80001f00:	85ca                	mv	a1,s2
    80001f02:	f71ff0ef          	jal	80001e72 <fetchstr>
}
    80001f06:	60e2                	ld	ra,24(sp)
    80001f08:	6442                	ld	s0,16(sp)
    80001f0a:	64a2                	ld	s1,8(sp)
    80001f0c:	6902                	ld	s2,0(sp)
    80001f0e:	6105                	addi	sp,sp,32
    80001f10:	8082                	ret

0000000080001f12 <syscall>:
[SYS_close]   sys_close,
};

void
syscall(void)
{
    80001f12:	1101                	addi	sp,sp,-32
    80001f14:	ec06                	sd	ra,24(sp)
    80001f16:	e822                	sd	s0,16(sp)
    80001f18:	e426                	sd	s1,8(sp)
    80001f1a:	e04a                	sd	s2,0(sp)
    80001f1c:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001f1e:	8c0ff0ef          	jal	80000fde <myproc>
    80001f22:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001f24:	05853903          	ld	s2,88(a0)
    80001f28:	0a893783          	ld	a5,168(s2)
    80001f2c:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001f30:	37fd                	addiw	a5,a5,-1
    80001f32:	4751                	li	a4,20
    80001f34:	00f76f63          	bltu	a4,a5,80001f52 <syscall+0x40>
    80001f38:	00369713          	slli	a4,a3,0x3
    80001f3c:	00006797          	auipc	a5,0x6
    80001f40:	93478793          	addi	a5,a5,-1740 # 80007870 <syscalls>
    80001f44:	97ba                	add	a5,a5,a4
    80001f46:	639c                	ld	a5,0(a5)
    80001f48:	c789                	beqz	a5,80001f52 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001f4a:	9782                	jalr	a5
    80001f4c:	06a93823          	sd	a0,112(s2)
    80001f50:	a829                	j	80001f6a <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001f52:	15848613          	addi	a2,s1,344
    80001f56:	588c                	lw	a1,48(s1)
    80001f58:	00005517          	auipc	a0,0x5
    80001f5c:	51050513          	addi	a0,a0,1296 # 80007468 <etext+0x468>
    80001f60:	48e030ef          	jal	800053ee <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001f64:	6cbc                	ld	a5,88(s1)
    80001f66:	577d                	li	a4,-1
    80001f68:	fbb8                	sd	a4,112(a5)
  }
}
    80001f6a:	60e2                	ld	ra,24(sp)
    80001f6c:	6442                	ld	s0,16(sp)
    80001f6e:	64a2                	ld	s1,8(sp)
    80001f70:	6902                	ld	s2,0(sp)
    80001f72:	6105                	addi	sp,sp,32
    80001f74:	8082                	ret

0000000080001f76 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001f76:	1101                	addi	sp,sp,-32
    80001f78:	ec06                	sd	ra,24(sp)
    80001f7a:	e822                	sd	s0,16(sp)
    80001f7c:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001f7e:	fec40593          	addi	a1,s0,-20
    80001f82:	4501                	li	a0,0
    80001f84:	f2fff0ef          	jal	80001eb2 <argint>
  exit(n);
    80001f88:	fec42503          	lw	a0,-20(s0)
    80001f8c:	f30ff0ef          	jal	800016bc <exit>
  return 0;  // not reached
}
    80001f90:	4501                	li	a0,0
    80001f92:	60e2                	ld	ra,24(sp)
    80001f94:	6442                	ld	s0,16(sp)
    80001f96:	6105                	addi	sp,sp,32
    80001f98:	8082                	ret

0000000080001f9a <sys_getpid>:

uint64
sys_getpid(void)
{
    80001f9a:	1141                	addi	sp,sp,-16
    80001f9c:	e406                	sd	ra,8(sp)
    80001f9e:	e022                	sd	s0,0(sp)
    80001fa0:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001fa2:	83cff0ef          	jal	80000fde <myproc>
}
    80001fa6:	5908                	lw	a0,48(a0)
    80001fa8:	60a2                	ld	ra,8(sp)
    80001faa:	6402                	ld	s0,0(sp)
    80001fac:	0141                	addi	sp,sp,16
    80001fae:	8082                	ret

0000000080001fb0 <sys_fork>:

uint64
sys_fork(void)
{
    80001fb0:	1141                	addi	sp,sp,-16
    80001fb2:	e406                	sd	ra,8(sp)
    80001fb4:	e022                	sd	s0,0(sp)
    80001fb6:	0800                	addi	s0,sp,16
  return fork();
    80001fb8:	b4eff0ef          	jal	80001306 <fork>
}
    80001fbc:	60a2                	ld	ra,8(sp)
    80001fbe:	6402                	ld	s0,0(sp)
    80001fc0:	0141                	addi	sp,sp,16
    80001fc2:	8082                	ret

0000000080001fc4 <sys_wait>:

uint64
sys_wait(void)
{
    80001fc4:	1101                	addi	sp,sp,-32
    80001fc6:	ec06                	sd	ra,24(sp)
    80001fc8:	e822                	sd	s0,16(sp)
    80001fca:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001fcc:	fe840593          	addi	a1,s0,-24
    80001fd0:	4501                	li	a0,0
    80001fd2:	efdff0ef          	jal	80001ece <argaddr>
  return wait(p);
    80001fd6:	fe843503          	ld	a0,-24(s0)
    80001fda:	83dff0ef          	jal	80001816 <wait>
}
    80001fde:	60e2                	ld	ra,24(sp)
    80001fe0:	6442                	ld	s0,16(sp)
    80001fe2:	6105                	addi	sp,sp,32
    80001fe4:	8082                	ret

0000000080001fe6 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001fe6:	7179                	addi	sp,sp,-48
    80001fe8:	f406                	sd	ra,40(sp)
    80001fea:	f022                	sd	s0,32(sp)
    80001fec:	ec26                	sd	s1,24(sp)
    80001fee:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001ff0:	fdc40593          	addi	a1,s0,-36
    80001ff4:	4501                	li	a0,0
    80001ff6:	ebdff0ef          	jal	80001eb2 <argint>
  addr = myproc()->sz;
    80001ffa:	fe5fe0ef          	jal	80000fde <myproc>
    80001ffe:	653c                	ld	a5,72(a0)
    80002000:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80002002:	fdc42503          	lw	a0,-36(s0)
    80002006:	ab0ff0ef          	jal	800012b6 <growproc>
    8000200a:	00054863          	bltz	a0,8000201a <sys_sbrk+0x34>
    return -1;
  return addr;
}
    8000200e:	8526                	mv	a0,s1
    80002010:	70a2                	ld	ra,40(sp)
    80002012:	7402                	ld	s0,32(sp)
    80002014:	64e2                	ld	s1,24(sp)
    80002016:	6145                	addi	sp,sp,48
    80002018:	8082                	ret
    return -1;
    8000201a:	57fd                	li	a5,-1
    8000201c:	84be                	mv	s1,a5
    8000201e:	bfc5                	j	8000200e <sys_sbrk+0x28>

0000000080002020 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002020:	7139                	addi	sp,sp,-64
    80002022:	fc06                	sd	ra,56(sp)
    80002024:	f822                	sd	s0,48(sp)
    80002026:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002028:	fcc40593          	addi	a1,s0,-52
    8000202c:	4501                	li	a0,0
    8000202e:	e85ff0ef          	jal	80001eb2 <argint>
  if(n < 0)
    80002032:	fcc42783          	lw	a5,-52(s0)
    80002036:	0607c863          	bltz	a5,800020a6 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    8000203a:	0000b517          	auipc	a0,0xb
    8000203e:	7e650513          	addi	a0,a0,2022 # 8000d820 <tickslock>
    80002042:	1fb030ef          	jal	80005a3c <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002046:	fcc42783          	lw	a5,-52(s0)
    8000204a:	c3b9                	beqz	a5,80002090 <sys_sleep+0x70>
    8000204c:	f426                	sd	s1,40(sp)
    8000204e:	f04a                	sd	s2,32(sp)
    80002050:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002052:	00006997          	auipc	s3,0x6
    80002056:	95e9a983          	lw	s3,-1698(s3) # 800079b0 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    8000205a:	0000b917          	auipc	s2,0xb
    8000205e:	7c690913          	addi	s2,s2,1990 # 8000d820 <tickslock>
    80002062:	00006497          	auipc	s1,0x6
    80002066:	94e48493          	addi	s1,s1,-1714 # 800079b0 <ticks>
    if(killed(myproc())){
    8000206a:	f75fe0ef          	jal	80000fde <myproc>
    8000206e:	f7eff0ef          	jal	800017ec <killed>
    80002072:	ed0d                	bnez	a0,800020ac <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80002074:	85ca                	mv	a1,s2
    80002076:	8526                	mv	a0,s1
    80002078:	d38ff0ef          	jal	800015b0 <sleep>
  while(ticks - ticks0 < n){
    8000207c:	409c                	lw	a5,0(s1)
    8000207e:	413787bb          	subw	a5,a5,s3
    80002082:	fcc42703          	lw	a4,-52(s0)
    80002086:	fee7e2e3          	bltu	a5,a4,8000206a <sys_sleep+0x4a>
    8000208a:	74a2                	ld	s1,40(sp)
    8000208c:	7902                	ld	s2,32(sp)
    8000208e:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002090:	0000b517          	auipc	a0,0xb
    80002094:	79050513          	addi	a0,a0,1936 # 8000d820 <tickslock>
    80002098:	239030ef          	jal	80005ad0 <release>
  return 0;
    8000209c:	4501                	li	a0,0
}
    8000209e:	70e2                	ld	ra,56(sp)
    800020a0:	7442                	ld	s0,48(sp)
    800020a2:	6121                	addi	sp,sp,64
    800020a4:	8082                	ret
    n = 0;
    800020a6:	fc042623          	sw	zero,-52(s0)
    800020aa:	bf41                	j	8000203a <sys_sleep+0x1a>
      release(&tickslock);
    800020ac:	0000b517          	auipc	a0,0xb
    800020b0:	77450513          	addi	a0,a0,1908 # 8000d820 <tickslock>
    800020b4:	21d030ef          	jal	80005ad0 <release>
      return -1;
    800020b8:	557d                	li	a0,-1
    800020ba:	74a2                	ld	s1,40(sp)
    800020bc:	7902                	ld	s2,32(sp)
    800020be:	69e2                	ld	s3,24(sp)
    800020c0:	bff9                	j	8000209e <sys_sleep+0x7e>

00000000800020c2 <sys_kill>:

uint64
sys_kill(void)
{
    800020c2:	1101                	addi	sp,sp,-32
    800020c4:	ec06                	sd	ra,24(sp)
    800020c6:	e822                	sd	s0,16(sp)
    800020c8:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    800020ca:	fec40593          	addi	a1,s0,-20
    800020ce:	4501                	li	a0,0
    800020d0:	de3ff0ef          	jal	80001eb2 <argint>
  return kill(pid);
    800020d4:	fec42503          	lw	a0,-20(s0)
    800020d8:	e8aff0ef          	jal	80001762 <kill>
}
    800020dc:	60e2                	ld	ra,24(sp)
    800020de:	6442                	ld	s0,16(sp)
    800020e0:	6105                	addi	sp,sp,32
    800020e2:	8082                	ret

00000000800020e4 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    800020e4:	1101                	addi	sp,sp,-32
    800020e6:	ec06                	sd	ra,24(sp)
    800020e8:	e822                	sd	s0,16(sp)
    800020ea:	e426                	sd	s1,8(sp)
    800020ec:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    800020ee:	0000b517          	auipc	a0,0xb
    800020f2:	73250513          	addi	a0,a0,1842 # 8000d820 <tickslock>
    800020f6:	147030ef          	jal	80005a3c <acquire>
  xticks = ticks;
    800020fa:	00006797          	auipc	a5,0x6
    800020fe:	8b67a783          	lw	a5,-1866(a5) # 800079b0 <ticks>
    80002102:	84be                	mv	s1,a5
  release(&tickslock);
    80002104:	0000b517          	auipc	a0,0xb
    80002108:	71c50513          	addi	a0,a0,1820 # 8000d820 <tickslock>
    8000210c:	1c5030ef          	jal	80005ad0 <release>
  return xticks;
}
    80002110:	02049513          	slli	a0,s1,0x20
    80002114:	9101                	srli	a0,a0,0x20
    80002116:	60e2                	ld	ra,24(sp)
    80002118:	6442                	ld	s0,16(sp)
    8000211a:	64a2                	ld	s1,8(sp)
    8000211c:	6105                	addi	sp,sp,32
    8000211e:	8082                	ret

0000000080002120 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002120:	7179                	addi	sp,sp,-48
    80002122:	f406                	sd	ra,40(sp)
    80002124:	f022                	sd	s0,32(sp)
    80002126:	ec26                	sd	s1,24(sp)
    80002128:	e84a                	sd	s2,16(sp)
    8000212a:	e44e                	sd	s3,8(sp)
    8000212c:	e052                	sd	s4,0(sp)
    8000212e:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002130:	00005597          	auipc	a1,0x5
    80002134:	35858593          	addi	a1,a1,856 # 80007488 <etext+0x488>
    80002138:	0000b517          	auipc	a0,0xb
    8000213c:	70050513          	addi	a0,a0,1792 # 8000d838 <bcache>
    80002140:	073030ef          	jal	800059b2 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002144:	00013797          	auipc	a5,0x13
    80002148:	6f478793          	addi	a5,a5,1780 # 80015838 <bcache+0x8000>
    8000214c:	00014717          	auipc	a4,0x14
    80002150:	95470713          	addi	a4,a4,-1708 # 80015aa0 <bcache+0x8268>
    80002154:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002158:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000215c:	0000b497          	auipc	s1,0xb
    80002160:	6f448493          	addi	s1,s1,1780 # 8000d850 <bcache+0x18>
    b->next = bcache.head.next;
    80002164:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002166:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002168:	00005a17          	auipc	s4,0x5
    8000216c:	328a0a13          	addi	s4,s4,808 # 80007490 <etext+0x490>
    b->next = bcache.head.next;
    80002170:	2b893783          	ld	a5,696(s2)
    80002174:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002176:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    8000217a:	85d2                	mv	a1,s4
    8000217c:	01048513          	addi	a0,s1,16
    80002180:	24c010ef          	jal	800033cc <initsleeplock>
    bcache.head.next->prev = b;
    80002184:	2b893783          	ld	a5,696(s2)
    80002188:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    8000218a:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000218e:	45848493          	addi	s1,s1,1112
    80002192:	fd349fe3          	bne	s1,s3,80002170 <binit+0x50>
  }
}
    80002196:	70a2                	ld	ra,40(sp)
    80002198:	7402                	ld	s0,32(sp)
    8000219a:	64e2                	ld	s1,24(sp)
    8000219c:	6942                	ld	s2,16(sp)
    8000219e:	69a2                	ld	s3,8(sp)
    800021a0:	6a02                	ld	s4,0(sp)
    800021a2:	6145                	addi	sp,sp,48
    800021a4:	8082                	ret

00000000800021a6 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    800021a6:	7179                	addi	sp,sp,-48
    800021a8:	f406                	sd	ra,40(sp)
    800021aa:	f022                	sd	s0,32(sp)
    800021ac:	ec26                	sd	s1,24(sp)
    800021ae:	e84a                	sd	s2,16(sp)
    800021b0:	e44e                	sd	s3,8(sp)
    800021b2:	1800                	addi	s0,sp,48
    800021b4:	892a                	mv	s2,a0
    800021b6:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    800021b8:	0000b517          	auipc	a0,0xb
    800021bc:	68050513          	addi	a0,a0,1664 # 8000d838 <bcache>
    800021c0:	07d030ef          	jal	80005a3c <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    800021c4:	00014497          	auipc	s1,0x14
    800021c8:	92c4b483          	ld	s1,-1748(s1) # 80015af0 <bcache+0x82b8>
    800021cc:	00014797          	auipc	a5,0x14
    800021d0:	8d478793          	addi	a5,a5,-1836 # 80015aa0 <bcache+0x8268>
    800021d4:	02f48b63          	beq	s1,a5,8000220a <bread+0x64>
    800021d8:	873e                	mv	a4,a5
    800021da:	a021                	j	800021e2 <bread+0x3c>
    800021dc:	68a4                	ld	s1,80(s1)
    800021de:	02e48663          	beq	s1,a4,8000220a <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    800021e2:	449c                	lw	a5,8(s1)
    800021e4:	ff279ce3          	bne	a5,s2,800021dc <bread+0x36>
    800021e8:	44dc                	lw	a5,12(s1)
    800021ea:	ff3799e3          	bne	a5,s3,800021dc <bread+0x36>
      b->refcnt++;
    800021ee:	40bc                	lw	a5,64(s1)
    800021f0:	2785                	addiw	a5,a5,1
    800021f2:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800021f4:	0000b517          	auipc	a0,0xb
    800021f8:	64450513          	addi	a0,a0,1604 # 8000d838 <bcache>
    800021fc:	0d5030ef          	jal	80005ad0 <release>
      acquiresleep(&b->lock);
    80002200:	01048513          	addi	a0,s1,16
    80002204:	1fe010ef          	jal	80003402 <acquiresleep>
      return b;
    80002208:	a889                	j	8000225a <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    8000220a:	00014497          	auipc	s1,0x14
    8000220e:	8de4b483          	ld	s1,-1826(s1) # 80015ae8 <bcache+0x82b0>
    80002212:	00014797          	auipc	a5,0x14
    80002216:	88e78793          	addi	a5,a5,-1906 # 80015aa0 <bcache+0x8268>
    8000221a:	00f48863          	beq	s1,a5,8000222a <bread+0x84>
    8000221e:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002220:	40bc                	lw	a5,64(s1)
    80002222:	cb91                	beqz	a5,80002236 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002224:	64a4                	ld	s1,72(s1)
    80002226:	fee49de3          	bne	s1,a4,80002220 <bread+0x7a>
  panic("bget: no buffers");
    8000222a:	00005517          	auipc	a0,0x5
    8000222e:	26e50513          	addi	a0,a0,622 # 80007498 <etext+0x498>
    80002232:	4cc030ef          	jal	800056fe <panic>
      b->dev = dev;
    80002236:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    8000223a:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    8000223e:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002242:	4785                	li	a5,1
    80002244:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002246:	0000b517          	auipc	a0,0xb
    8000224a:	5f250513          	addi	a0,a0,1522 # 8000d838 <bcache>
    8000224e:	083030ef          	jal	80005ad0 <release>
      acquiresleep(&b->lock);
    80002252:	01048513          	addi	a0,s1,16
    80002256:	1ac010ef          	jal	80003402 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    8000225a:	409c                	lw	a5,0(s1)
    8000225c:	cb89                	beqz	a5,8000226e <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000225e:	8526                	mv	a0,s1
    80002260:	70a2                	ld	ra,40(sp)
    80002262:	7402                	ld	s0,32(sp)
    80002264:	64e2                	ld	s1,24(sp)
    80002266:	6942                	ld	s2,16(sp)
    80002268:	69a2                	ld	s3,8(sp)
    8000226a:	6145                	addi	sp,sp,48
    8000226c:	8082                	ret
    virtio_disk_rw(b, 0);
    8000226e:	4581                	li	a1,0
    80002270:	8526                	mv	a0,s1
    80002272:	20f020ef          	jal	80004c80 <virtio_disk_rw>
    b->valid = 1;
    80002276:	4785                	li	a5,1
    80002278:	c09c                	sw	a5,0(s1)
  return b;
    8000227a:	b7d5                	j	8000225e <bread+0xb8>

000000008000227c <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000227c:	1101                	addi	sp,sp,-32
    8000227e:	ec06                	sd	ra,24(sp)
    80002280:	e822                	sd	s0,16(sp)
    80002282:	e426                	sd	s1,8(sp)
    80002284:	1000                	addi	s0,sp,32
    80002286:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002288:	0541                	addi	a0,a0,16
    8000228a:	1f6010ef          	jal	80003480 <holdingsleep>
    8000228e:	c911                	beqz	a0,800022a2 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002290:	4585                	li	a1,1
    80002292:	8526                	mv	a0,s1
    80002294:	1ed020ef          	jal	80004c80 <virtio_disk_rw>
}
    80002298:	60e2                	ld	ra,24(sp)
    8000229a:	6442                	ld	s0,16(sp)
    8000229c:	64a2                	ld	s1,8(sp)
    8000229e:	6105                	addi	sp,sp,32
    800022a0:	8082                	ret
    panic("bwrite");
    800022a2:	00005517          	auipc	a0,0x5
    800022a6:	20e50513          	addi	a0,a0,526 # 800074b0 <etext+0x4b0>
    800022aa:	454030ef          	jal	800056fe <panic>

00000000800022ae <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    800022ae:	1101                	addi	sp,sp,-32
    800022b0:	ec06                	sd	ra,24(sp)
    800022b2:	e822                	sd	s0,16(sp)
    800022b4:	e426                	sd	s1,8(sp)
    800022b6:	e04a                	sd	s2,0(sp)
    800022b8:	1000                	addi	s0,sp,32
    800022ba:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    800022bc:	01050913          	addi	s2,a0,16
    800022c0:	854a                	mv	a0,s2
    800022c2:	1be010ef          	jal	80003480 <holdingsleep>
    800022c6:	c125                	beqz	a0,80002326 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    800022c8:	854a                	mv	a0,s2
    800022ca:	17e010ef          	jal	80003448 <releasesleep>

  acquire(&bcache.lock);
    800022ce:	0000b517          	auipc	a0,0xb
    800022d2:	56a50513          	addi	a0,a0,1386 # 8000d838 <bcache>
    800022d6:	766030ef          	jal	80005a3c <acquire>
  b->refcnt--;
    800022da:	40bc                	lw	a5,64(s1)
    800022dc:	37fd                	addiw	a5,a5,-1
    800022de:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800022e0:	e79d                	bnez	a5,8000230e <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800022e2:	68b8                	ld	a4,80(s1)
    800022e4:	64bc                	ld	a5,72(s1)
    800022e6:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    800022e8:	68b8                	ld	a4,80(s1)
    800022ea:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800022ec:	00013797          	auipc	a5,0x13
    800022f0:	54c78793          	addi	a5,a5,1356 # 80015838 <bcache+0x8000>
    800022f4:	2b87b703          	ld	a4,696(a5)
    800022f8:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800022fa:	00013717          	auipc	a4,0x13
    800022fe:	7a670713          	addi	a4,a4,1958 # 80015aa0 <bcache+0x8268>
    80002302:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002304:	2b87b703          	ld	a4,696(a5)
    80002308:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    8000230a:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    8000230e:	0000b517          	auipc	a0,0xb
    80002312:	52a50513          	addi	a0,a0,1322 # 8000d838 <bcache>
    80002316:	7ba030ef          	jal	80005ad0 <release>
}
    8000231a:	60e2                	ld	ra,24(sp)
    8000231c:	6442                	ld	s0,16(sp)
    8000231e:	64a2                	ld	s1,8(sp)
    80002320:	6902                	ld	s2,0(sp)
    80002322:	6105                	addi	sp,sp,32
    80002324:	8082                	ret
    panic("brelse");
    80002326:	00005517          	auipc	a0,0x5
    8000232a:	19250513          	addi	a0,a0,402 # 800074b8 <etext+0x4b8>
    8000232e:	3d0030ef          	jal	800056fe <panic>

0000000080002332 <bpin>:

void
bpin(struct buf *b) {
    80002332:	1101                	addi	sp,sp,-32
    80002334:	ec06                	sd	ra,24(sp)
    80002336:	e822                	sd	s0,16(sp)
    80002338:	e426                	sd	s1,8(sp)
    8000233a:	1000                	addi	s0,sp,32
    8000233c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000233e:	0000b517          	auipc	a0,0xb
    80002342:	4fa50513          	addi	a0,a0,1274 # 8000d838 <bcache>
    80002346:	6f6030ef          	jal	80005a3c <acquire>
  b->refcnt++;
    8000234a:	40bc                	lw	a5,64(s1)
    8000234c:	2785                	addiw	a5,a5,1
    8000234e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002350:	0000b517          	auipc	a0,0xb
    80002354:	4e850513          	addi	a0,a0,1256 # 8000d838 <bcache>
    80002358:	778030ef          	jal	80005ad0 <release>
}
    8000235c:	60e2                	ld	ra,24(sp)
    8000235e:	6442                	ld	s0,16(sp)
    80002360:	64a2                	ld	s1,8(sp)
    80002362:	6105                	addi	sp,sp,32
    80002364:	8082                	ret

0000000080002366 <bunpin>:

void
bunpin(struct buf *b) {
    80002366:	1101                	addi	sp,sp,-32
    80002368:	ec06                	sd	ra,24(sp)
    8000236a:	e822                	sd	s0,16(sp)
    8000236c:	e426                	sd	s1,8(sp)
    8000236e:	1000                	addi	s0,sp,32
    80002370:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002372:	0000b517          	auipc	a0,0xb
    80002376:	4c650513          	addi	a0,a0,1222 # 8000d838 <bcache>
    8000237a:	6c2030ef          	jal	80005a3c <acquire>
  b->refcnt--;
    8000237e:	40bc                	lw	a5,64(s1)
    80002380:	37fd                	addiw	a5,a5,-1
    80002382:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002384:	0000b517          	auipc	a0,0xb
    80002388:	4b450513          	addi	a0,a0,1204 # 8000d838 <bcache>
    8000238c:	744030ef          	jal	80005ad0 <release>
}
    80002390:	60e2                	ld	ra,24(sp)
    80002392:	6442                	ld	s0,16(sp)
    80002394:	64a2                	ld	s1,8(sp)
    80002396:	6105                	addi	sp,sp,32
    80002398:	8082                	ret

000000008000239a <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    8000239a:	1101                	addi	sp,sp,-32
    8000239c:	ec06                	sd	ra,24(sp)
    8000239e:	e822                	sd	s0,16(sp)
    800023a0:	e426                	sd	s1,8(sp)
    800023a2:	e04a                	sd	s2,0(sp)
    800023a4:	1000                	addi	s0,sp,32
    800023a6:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    800023a8:	00d5d79b          	srliw	a5,a1,0xd
    800023ac:	00014597          	auipc	a1,0x14
    800023b0:	b685a583          	lw	a1,-1176(a1) # 80015f14 <sb+0x1c>
    800023b4:	9dbd                	addw	a1,a1,a5
    800023b6:	df1ff0ef          	jal	800021a6 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    800023ba:	0074f713          	andi	a4,s1,7
    800023be:	4785                	li	a5,1
    800023c0:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    800023c4:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    800023c6:	90d9                	srli	s1,s1,0x36
    800023c8:	00950733          	add	a4,a0,s1
    800023cc:	05874703          	lbu	a4,88(a4)
    800023d0:	00e7f6b3          	and	a3,a5,a4
    800023d4:	c29d                	beqz	a3,800023fa <bfree+0x60>
    800023d6:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800023d8:	94aa                	add	s1,s1,a0
    800023da:	fff7c793          	not	a5,a5
    800023de:	8f7d                	and	a4,a4,a5
    800023e0:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    800023e4:	717000ef          	jal	800032fa <log_write>
  brelse(bp);
    800023e8:	854a                	mv	a0,s2
    800023ea:	ec5ff0ef          	jal	800022ae <brelse>
}
    800023ee:	60e2                	ld	ra,24(sp)
    800023f0:	6442                	ld	s0,16(sp)
    800023f2:	64a2                	ld	s1,8(sp)
    800023f4:	6902                	ld	s2,0(sp)
    800023f6:	6105                	addi	sp,sp,32
    800023f8:	8082                	ret
    panic("freeing free block");
    800023fa:	00005517          	auipc	a0,0x5
    800023fe:	0c650513          	addi	a0,a0,198 # 800074c0 <etext+0x4c0>
    80002402:	2fc030ef          	jal	800056fe <panic>

0000000080002406 <balloc>:
{
    80002406:	715d                	addi	sp,sp,-80
    80002408:	e486                	sd	ra,72(sp)
    8000240a:	e0a2                	sd	s0,64(sp)
    8000240c:	fc26                	sd	s1,56(sp)
    8000240e:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002410:	00014797          	auipc	a5,0x14
    80002414:	aec7a783          	lw	a5,-1300(a5) # 80015efc <sb+0x4>
    80002418:	0e078263          	beqz	a5,800024fc <balloc+0xf6>
    8000241c:	f84a                	sd	s2,48(sp)
    8000241e:	f44e                	sd	s3,40(sp)
    80002420:	f052                	sd	s4,32(sp)
    80002422:	ec56                	sd	s5,24(sp)
    80002424:	e85a                	sd	s6,16(sp)
    80002426:	e45e                	sd	s7,8(sp)
    80002428:	e062                	sd	s8,0(sp)
    8000242a:	8baa                	mv	s7,a0
    8000242c:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    8000242e:	00014b17          	auipc	s6,0x14
    80002432:	acab0b13          	addi	s6,s6,-1334 # 80015ef8 <sb>
      m = 1 << (bi % 8);
    80002436:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002438:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    8000243a:	6c09                	lui	s8,0x2
    8000243c:	a09d                	j	800024a2 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    8000243e:	97ca                	add	a5,a5,s2
    80002440:	8e55                	or	a2,a2,a3
    80002442:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002446:	854a                	mv	a0,s2
    80002448:	6b3000ef          	jal	800032fa <log_write>
        brelse(bp);
    8000244c:	854a                	mv	a0,s2
    8000244e:	e61ff0ef          	jal	800022ae <brelse>
  bp = bread(dev, bno);
    80002452:	85a6                	mv	a1,s1
    80002454:	855e                	mv	a0,s7
    80002456:	d51ff0ef          	jal	800021a6 <bread>
    8000245a:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    8000245c:	40000613          	li	a2,1024
    80002460:	4581                	li	a1,0
    80002462:	05850513          	addi	a0,a0,88
    80002466:	db7fd0ef          	jal	8000021c <memset>
  log_write(bp);
    8000246a:	854a                	mv	a0,s2
    8000246c:	68f000ef          	jal	800032fa <log_write>
  brelse(bp);
    80002470:	854a                	mv	a0,s2
    80002472:	e3dff0ef          	jal	800022ae <brelse>
}
    80002476:	7942                	ld	s2,48(sp)
    80002478:	79a2                	ld	s3,40(sp)
    8000247a:	7a02                	ld	s4,32(sp)
    8000247c:	6ae2                	ld	s5,24(sp)
    8000247e:	6b42                	ld	s6,16(sp)
    80002480:	6ba2                	ld	s7,8(sp)
    80002482:	6c02                	ld	s8,0(sp)
}
    80002484:	8526                	mv	a0,s1
    80002486:	60a6                	ld	ra,72(sp)
    80002488:	6406                	ld	s0,64(sp)
    8000248a:	74e2                	ld	s1,56(sp)
    8000248c:	6161                	addi	sp,sp,80
    8000248e:	8082                	ret
    brelse(bp);
    80002490:	854a                	mv	a0,s2
    80002492:	e1dff0ef          	jal	800022ae <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002496:	015c0abb          	addw	s5,s8,s5
    8000249a:	004b2783          	lw	a5,4(s6)
    8000249e:	04faf863          	bgeu	s5,a5,800024ee <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    800024a2:	40dad59b          	sraiw	a1,s5,0xd
    800024a6:	01cb2783          	lw	a5,28(s6)
    800024aa:	9dbd                	addw	a1,a1,a5
    800024ac:	855e                	mv	a0,s7
    800024ae:	cf9ff0ef          	jal	800021a6 <bread>
    800024b2:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800024b4:	004b2503          	lw	a0,4(s6)
    800024b8:	84d6                	mv	s1,s5
    800024ba:	4701                	li	a4,0
    800024bc:	fca4fae3          	bgeu	s1,a0,80002490 <balloc+0x8a>
      m = 1 << (bi % 8);
    800024c0:	00777693          	andi	a3,a4,7
    800024c4:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800024c8:	41f7579b          	sraiw	a5,a4,0x1f
    800024cc:	01d7d79b          	srliw	a5,a5,0x1d
    800024d0:	9fb9                	addw	a5,a5,a4
    800024d2:	4037d79b          	sraiw	a5,a5,0x3
    800024d6:	00f90633          	add	a2,s2,a5
    800024da:	05864603          	lbu	a2,88(a2)
    800024de:	00c6f5b3          	and	a1,a3,a2
    800024e2:	ddb1                	beqz	a1,8000243e <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800024e4:	2705                	addiw	a4,a4,1
    800024e6:	2485                	addiw	s1,s1,1
    800024e8:	fd471ae3          	bne	a4,s4,800024bc <balloc+0xb6>
    800024ec:	b755                	j	80002490 <balloc+0x8a>
    800024ee:	7942                	ld	s2,48(sp)
    800024f0:	79a2                	ld	s3,40(sp)
    800024f2:	7a02                	ld	s4,32(sp)
    800024f4:	6ae2                	ld	s5,24(sp)
    800024f6:	6b42                	ld	s6,16(sp)
    800024f8:	6ba2                	ld	s7,8(sp)
    800024fa:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    800024fc:	00005517          	auipc	a0,0x5
    80002500:	fdc50513          	addi	a0,a0,-36 # 800074d8 <etext+0x4d8>
    80002504:	6eb020ef          	jal	800053ee <printf>
  return 0;
    80002508:	4481                	li	s1,0
    8000250a:	bfad                	j	80002484 <balloc+0x7e>

000000008000250c <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000250c:	7179                	addi	sp,sp,-48
    8000250e:	f406                	sd	ra,40(sp)
    80002510:	f022                	sd	s0,32(sp)
    80002512:	ec26                	sd	s1,24(sp)
    80002514:	e84a                	sd	s2,16(sp)
    80002516:	e44e                	sd	s3,8(sp)
    80002518:	1800                	addi	s0,sp,48
    8000251a:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    8000251c:	47ad                	li	a5,11
    8000251e:	02b7e363          	bltu	a5,a1,80002544 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80002522:	02059793          	slli	a5,a1,0x20
    80002526:	01e7d593          	srli	a1,a5,0x1e
    8000252a:	00b509b3          	add	s3,a0,a1
    8000252e:	0509a483          	lw	s1,80(s3)
    80002532:	e0b5                	bnez	s1,80002596 <bmap+0x8a>
      addr = balloc(ip->dev);
    80002534:	4108                	lw	a0,0(a0)
    80002536:	ed1ff0ef          	jal	80002406 <balloc>
    8000253a:	84aa                	mv	s1,a0
      if(addr == 0)
    8000253c:	cd29                	beqz	a0,80002596 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    8000253e:	04a9a823          	sw	a0,80(s3)
    80002542:	a891                	j	80002596 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002544:	ff45879b          	addiw	a5,a1,-12
    80002548:	873e                	mv	a4,a5
    8000254a:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    8000254c:	0ff00793          	li	a5,255
    80002550:	06e7e763          	bltu	a5,a4,800025be <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002554:	08052483          	lw	s1,128(a0)
    80002558:	e891                	bnez	s1,8000256c <bmap+0x60>
      addr = balloc(ip->dev);
    8000255a:	4108                	lw	a0,0(a0)
    8000255c:	eabff0ef          	jal	80002406 <balloc>
    80002560:	84aa                	mv	s1,a0
      if(addr == 0)
    80002562:	c915                	beqz	a0,80002596 <bmap+0x8a>
    80002564:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002566:	08a92023          	sw	a0,128(s2)
    8000256a:	a011                	j	8000256e <bmap+0x62>
    8000256c:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000256e:	85a6                	mv	a1,s1
    80002570:	00092503          	lw	a0,0(s2)
    80002574:	c33ff0ef          	jal	800021a6 <bread>
    80002578:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    8000257a:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000257e:	02099713          	slli	a4,s3,0x20
    80002582:	01e75593          	srli	a1,a4,0x1e
    80002586:	97ae                	add	a5,a5,a1
    80002588:	89be                	mv	s3,a5
    8000258a:	4384                	lw	s1,0(a5)
    8000258c:	cc89                	beqz	s1,800025a6 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000258e:	8552                	mv	a0,s4
    80002590:	d1fff0ef          	jal	800022ae <brelse>
    return addr;
    80002594:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002596:	8526                	mv	a0,s1
    80002598:	70a2                	ld	ra,40(sp)
    8000259a:	7402                	ld	s0,32(sp)
    8000259c:	64e2                	ld	s1,24(sp)
    8000259e:	6942                	ld	s2,16(sp)
    800025a0:	69a2                	ld	s3,8(sp)
    800025a2:	6145                	addi	sp,sp,48
    800025a4:	8082                	ret
      addr = balloc(ip->dev);
    800025a6:	00092503          	lw	a0,0(s2)
    800025aa:	e5dff0ef          	jal	80002406 <balloc>
    800025ae:	84aa                	mv	s1,a0
      if(addr){
    800025b0:	dd79                	beqz	a0,8000258e <bmap+0x82>
        a[bn] = addr;
    800025b2:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    800025b6:	8552                	mv	a0,s4
    800025b8:	543000ef          	jal	800032fa <log_write>
    800025bc:	bfc9                	j	8000258e <bmap+0x82>
    800025be:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800025c0:	00005517          	auipc	a0,0x5
    800025c4:	f3050513          	addi	a0,a0,-208 # 800074f0 <etext+0x4f0>
    800025c8:	136030ef          	jal	800056fe <panic>

00000000800025cc <iget>:
{
    800025cc:	7179                	addi	sp,sp,-48
    800025ce:	f406                	sd	ra,40(sp)
    800025d0:	f022                	sd	s0,32(sp)
    800025d2:	ec26                	sd	s1,24(sp)
    800025d4:	e84a                	sd	s2,16(sp)
    800025d6:	e44e                	sd	s3,8(sp)
    800025d8:	e052                	sd	s4,0(sp)
    800025da:	1800                	addi	s0,sp,48
    800025dc:	892a                	mv	s2,a0
    800025de:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800025e0:	00014517          	auipc	a0,0x14
    800025e4:	93850513          	addi	a0,a0,-1736 # 80015f18 <itable>
    800025e8:	454030ef          	jal	80005a3c <acquire>
  empty = 0;
    800025ec:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800025ee:	00014497          	auipc	s1,0x14
    800025f2:	94248493          	addi	s1,s1,-1726 # 80015f30 <itable+0x18>
    800025f6:	00015697          	auipc	a3,0x15
    800025fa:	3ca68693          	addi	a3,a3,970 # 800179c0 <log>
    800025fe:	a809                	j	80002610 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002600:	e781                	bnez	a5,80002608 <iget+0x3c>
    80002602:	00099363          	bnez	s3,80002608 <iget+0x3c>
      empty = ip;
    80002606:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002608:	08848493          	addi	s1,s1,136
    8000260c:	02d48563          	beq	s1,a3,80002636 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80002610:	449c                	lw	a5,8(s1)
    80002612:	fef057e3          	blez	a5,80002600 <iget+0x34>
    80002616:	4098                	lw	a4,0(s1)
    80002618:	ff2718e3          	bne	a4,s2,80002608 <iget+0x3c>
    8000261c:	40d8                	lw	a4,4(s1)
    8000261e:	ff4715e3          	bne	a4,s4,80002608 <iget+0x3c>
      ip->ref++;
    80002622:	2785                	addiw	a5,a5,1
    80002624:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002626:	00014517          	auipc	a0,0x14
    8000262a:	8f250513          	addi	a0,a0,-1806 # 80015f18 <itable>
    8000262e:	4a2030ef          	jal	80005ad0 <release>
      return ip;
    80002632:	89a6                	mv	s3,s1
    80002634:	a015                	j	80002658 <iget+0x8c>
  if(empty == 0)
    80002636:	02098a63          	beqz	s3,8000266a <iget+0x9e>
  ip->dev = dev;
    8000263a:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    8000263e:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80002642:	4785                	li	a5,1
    80002644:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    80002648:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    8000264c:	00014517          	auipc	a0,0x14
    80002650:	8cc50513          	addi	a0,a0,-1844 # 80015f18 <itable>
    80002654:	47c030ef          	jal	80005ad0 <release>
}
    80002658:	854e                	mv	a0,s3
    8000265a:	70a2                	ld	ra,40(sp)
    8000265c:	7402                	ld	s0,32(sp)
    8000265e:	64e2                	ld	s1,24(sp)
    80002660:	6942                	ld	s2,16(sp)
    80002662:	69a2                	ld	s3,8(sp)
    80002664:	6a02                	ld	s4,0(sp)
    80002666:	6145                	addi	sp,sp,48
    80002668:	8082                	ret
    panic("iget: no inodes");
    8000266a:	00005517          	auipc	a0,0x5
    8000266e:	e9e50513          	addi	a0,a0,-354 # 80007508 <etext+0x508>
    80002672:	08c030ef          	jal	800056fe <panic>

0000000080002676 <fsinit>:
fsinit(int dev) {
    80002676:	1101                	addi	sp,sp,-32
    80002678:	ec06                	sd	ra,24(sp)
    8000267a:	e822                	sd	s0,16(sp)
    8000267c:	e426                	sd	s1,8(sp)
    8000267e:	e04a                	sd	s2,0(sp)
    80002680:	1000                	addi	s0,sp,32
    80002682:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002684:	4585                	li	a1,1
    80002686:	b21ff0ef          	jal	800021a6 <bread>
    8000268a:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000268c:	02000613          	li	a2,32
    80002690:	05850593          	addi	a1,a0,88
    80002694:	00014517          	auipc	a0,0x14
    80002698:	86450513          	addi	a0,a0,-1948 # 80015ef8 <sb>
    8000269c:	be1fd0ef          	jal	8000027c <memmove>
  brelse(bp);
    800026a0:	8526                	mv	a0,s1
    800026a2:	c0dff0ef          	jal	800022ae <brelse>
  if(sb.magic != FSMAGIC)
    800026a6:	00014717          	auipc	a4,0x14
    800026aa:	85272703          	lw	a4,-1966(a4) # 80015ef8 <sb>
    800026ae:	102037b7          	lui	a5,0x10203
    800026b2:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800026b6:	00f71f63          	bne	a4,a5,800026d4 <fsinit+0x5e>
  initlog(dev, &sb);
    800026ba:	00014597          	auipc	a1,0x14
    800026be:	83e58593          	addi	a1,a1,-1986 # 80015ef8 <sb>
    800026c2:	854a                	mv	a0,s2
    800026c4:	219000ef          	jal	800030dc <initlog>
}
    800026c8:	60e2                	ld	ra,24(sp)
    800026ca:	6442                	ld	s0,16(sp)
    800026cc:	64a2                	ld	s1,8(sp)
    800026ce:	6902                	ld	s2,0(sp)
    800026d0:	6105                	addi	sp,sp,32
    800026d2:	8082                	ret
    panic("invalid file system");
    800026d4:	00005517          	auipc	a0,0x5
    800026d8:	e4450513          	addi	a0,a0,-444 # 80007518 <etext+0x518>
    800026dc:	022030ef          	jal	800056fe <panic>

00000000800026e0 <iinit>:
{
    800026e0:	7179                	addi	sp,sp,-48
    800026e2:	f406                	sd	ra,40(sp)
    800026e4:	f022                	sd	s0,32(sp)
    800026e6:	ec26                	sd	s1,24(sp)
    800026e8:	e84a                	sd	s2,16(sp)
    800026ea:	e44e                	sd	s3,8(sp)
    800026ec:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800026ee:	00005597          	auipc	a1,0x5
    800026f2:	e4258593          	addi	a1,a1,-446 # 80007530 <etext+0x530>
    800026f6:	00014517          	auipc	a0,0x14
    800026fa:	82250513          	addi	a0,a0,-2014 # 80015f18 <itable>
    800026fe:	2b4030ef          	jal	800059b2 <initlock>
  for(i = 0; i < NINODE; i++) {
    80002702:	00014497          	auipc	s1,0x14
    80002706:	83e48493          	addi	s1,s1,-1986 # 80015f40 <itable+0x28>
    8000270a:	00015997          	auipc	s3,0x15
    8000270e:	2c698993          	addi	s3,s3,710 # 800179d0 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80002712:	00005917          	auipc	s2,0x5
    80002716:	e2690913          	addi	s2,s2,-474 # 80007538 <etext+0x538>
    8000271a:	85ca                	mv	a1,s2
    8000271c:	8526                	mv	a0,s1
    8000271e:	4af000ef          	jal	800033cc <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80002722:	08848493          	addi	s1,s1,136
    80002726:	ff349ae3          	bne	s1,s3,8000271a <iinit+0x3a>
}
    8000272a:	70a2                	ld	ra,40(sp)
    8000272c:	7402                	ld	s0,32(sp)
    8000272e:	64e2                	ld	s1,24(sp)
    80002730:	6942                	ld	s2,16(sp)
    80002732:	69a2                	ld	s3,8(sp)
    80002734:	6145                	addi	sp,sp,48
    80002736:	8082                	ret

0000000080002738 <ialloc>:
{
    80002738:	7139                	addi	sp,sp,-64
    8000273a:	fc06                	sd	ra,56(sp)
    8000273c:	f822                	sd	s0,48(sp)
    8000273e:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80002740:	00013717          	auipc	a4,0x13
    80002744:	7c472703          	lw	a4,1988(a4) # 80015f04 <sb+0xc>
    80002748:	4785                	li	a5,1
    8000274a:	06e7f063          	bgeu	a5,a4,800027aa <ialloc+0x72>
    8000274e:	f426                	sd	s1,40(sp)
    80002750:	f04a                	sd	s2,32(sp)
    80002752:	ec4e                	sd	s3,24(sp)
    80002754:	e852                	sd	s4,16(sp)
    80002756:	e456                	sd	s5,8(sp)
    80002758:	e05a                	sd	s6,0(sp)
    8000275a:	8aaa                	mv	s5,a0
    8000275c:	8b2e                	mv	s6,a1
    8000275e:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80002760:	00013a17          	auipc	s4,0x13
    80002764:	798a0a13          	addi	s4,s4,1944 # 80015ef8 <sb>
    80002768:	00495593          	srli	a1,s2,0x4
    8000276c:	018a2783          	lw	a5,24(s4)
    80002770:	9dbd                	addw	a1,a1,a5
    80002772:	8556                	mv	a0,s5
    80002774:	a33ff0ef          	jal	800021a6 <bread>
    80002778:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    8000277a:	05850993          	addi	s3,a0,88
    8000277e:	00f97793          	andi	a5,s2,15
    80002782:	079a                	slli	a5,a5,0x6
    80002784:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002786:	00099783          	lh	a5,0(s3)
    8000278a:	cb9d                	beqz	a5,800027c0 <ialloc+0x88>
    brelse(bp);
    8000278c:	b23ff0ef          	jal	800022ae <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80002790:	0905                	addi	s2,s2,1
    80002792:	00ca2703          	lw	a4,12(s4)
    80002796:	0009079b          	sext.w	a5,s2
    8000279a:	fce7e7e3          	bltu	a5,a4,80002768 <ialloc+0x30>
    8000279e:	74a2                	ld	s1,40(sp)
    800027a0:	7902                	ld	s2,32(sp)
    800027a2:	69e2                	ld	s3,24(sp)
    800027a4:	6a42                	ld	s4,16(sp)
    800027a6:	6aa2                	ld	s5,8(sp)
    800027a8:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800027aa:	00005517          	auipc	a0,0x5
    800027ae:	d9650513          	addi	a0,a0,-618 # 80007540 <etext+0x540>
    800027b2:	43d020ef          	jal	800053ee <printf>
  return 0;
    800027b6:	4501                	li	a0,0
}
    800027b8:	70e2                	ld	ra,56(sp)
    800027ba:	7442                	ld	s0,48(sp)
    800027bc:	6121                	addi	sp,sp,64
    800027be:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800027c0:	04000613          	li	a2,64
    800027c4:	4581                	li	a1,0
    800027c6:	854e                	mv	a0,s3
    800027c8:	a55fd0ef          	jal	8000021c <memset>
      dip->type = type;
    800027cc:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800027d0:	8526                	mv	a0,s1
    800027d2:	329000ef          	jal	800032fa <log_write>
      brelse(bp);
    800027d6:	8526                	mv	a0,s1
    800027d8:	ad7ff0ef          	jal	800022ae <brelse>
      return iget(dev, inum);
    800027dc:	0009059b          	sext.w	a1,s2
    800027e0:	8556                	mv	a0,s5
    800027e2:	debff0ef          	jal	800025cc <iget>
    800027e6:	74a2                	ld	s1,40(sp)
    800027e8:	7902                	ld	s2,32(sp)
    800027ea:	69e2                	ld	s3,24(sp)
    800027ec:	6a42                	ld	s4,16(sp)
    800027ee:	6aa2                	ld	s5,8(sp)
    800027f0:	6b02                	ld	s6,0(sp)
    800027f2:	b7d9                	j	800027b8 <ialloc+0x80>

00000000800027f4 <iupdate>:
{
    800027f4:	1101                	addi	sp,sp,-32
    800027f6:	ec06                	sd	ra,24(sp)
    800027f8:	e822                	sd	s0,16(sp)
    800027fa:	e426                	sd	s1,8(sp)
    800027fc:	e04a                	sd	s2,0(sp)
    800027fe:	1000                	addi	s0,sp,32
    80002800:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002802:	415c                	lw	a5,4(a0)
    80002804:	0047d79b          	srliw	a5,a5,0x4
    80002808:	00013597          	auipc	a1,0x13
    8000280c:	7085a583          	lw	a1,1800(a1) # 80015f10 <sb+0x18>
    80002810:	9dbd                	addw	a1,a1,a5
    80002812:	4108                	lw	a0,0(a0)
    80002814:	993ff0ef          	jal	800021a6 <bread>
    80002818:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000281a:	05850793          	addi	a5,a0,88
    8000281e:	40d8                	lw	a4,4(s1)
    80002820:	8b3d                	andi	a4,a4,15
    80002822:	071a                	slli	a4,a4,0x6
    80002824:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80002826:	04449703          	lh	a4,68(s1)
    8000282a:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000282e:	04649703          	lh	a4,70(s1)
    80002832:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80002836:	04849703          	lh	a4,72(s1)
    8000283a:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000283e:	04a49703          	lh	a4,74(s1)
    80002842:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80002846:	44f8                	lw	a4,76(s1)
    80002848:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000284a:	03400613          	li	a2,52
    8000284e:	05048593          	addi	a1,s1,80
    80002852:	00c78513          	addi	a0,a5,12
    80002856:	a27fd0ef          	jal	8000027c <memmove>
  log_write(bp);
    8000285a:	854a                	mv	a0,s2
    8000285c:	29f000ef          	jal	800032fa <log_write>
  brelse(bp);
    80002860:	854a                	mv	a0,s2
    80002862:	a4dff0ef          	jal	800022ae <brelse>
}
    80002866:	60e2                	ld	ra,24(sp)
    80002868:	6442                	ld	s0,16(sp)
    8000286a:	64a2                	ld	s1,8(sp)
    8000286c:	6902                	ld	s2,0(sp)
    8000286e:	6105                	addi	sp,sp,32
    80002870:	8082                	ret

0000000080002872 <idup>:
{
    80002872:	1101                	addi	sp,sp,-32
    80002874:	ec06                	sd	ra,24(sp)
    80002876:	e822                	sd	s0,16(sp)
    80002878:	e426                	sd	s1,8(sp)
    8000287a:	1000                	addi	s0,sp,32
    8000287c:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000287e:	00013517          	auipc	a0,0x13
    80002882:	69a50513          	addi	a0,a0,1690 # 80015f18 <itable>
    80002886:	1b6030ef          	jal	80005a3c <acquire>
  ip->ref++;
    8000288a:	449c                	lw	a5,8(s1)
    8000288c:	2785                	addiw	a5,a5,1
    8000288e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002890:	00013517          	auipc	a0,0x13
    80002894:	68850513          	addi	a0,a0,1672 # 80015f18 <itable>
    80002898:	238030ef          	jal	80005ad0 <release>
}
    8000289c:	8526                	mv	a0,s1
    8000289e:	60e2                	ld	ra,24(sp)
    800028a0:	6442                	ld	s0,16(sp)
    800028a2:	64a2                	ld	s1,8(sp)
    800028a4:	6105                	addi	sp,sp,32
    800028a6:	8082                	ret

00000000800028a8 <ilock>:
{
    800028a8:	1101                	addi	sp,sp,-32
    800028aa:	ec06                	sd	ra,24(sp)
    800028ac:	e822                	sd	s0,16(sp)
    800028ae:	e426                	sd	s1,8(sp)
    800028b0:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800028b2:	cd19                	beqz	a0,800028d0 <ilock+0x28>
    800028b4:	84aa                	mv	s1,a0
    800028b6:	451c                	lw	a5,8(a0)
    800028b8:	00f05c63          	blez	a5,800028d0 <ilock+0x28>
  acquiresleep(&ip->lock);
    800028bc:	0541                	addi	a0,a0,16
    800028be:	345000ef          	jal	80003402 <acquiresleep>
  if(ip->valid == 0){
    800028c2:	40bc                	lw	a5,64(s1)
    800028c4:	cf89                	beqz	a5,800028de <ilock+0x36>
}
    800028c6:	60e2                	ld	ra,24(sp)
    800028c8:	6442                	ld	s0,16(sp)
    800028ca:	64a2                	ld	s1,8(sp)
    800028cc:	6105                	addi	sp,sp,32
    800028ce:	8082                	ret
    800028d0:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800028d2:	00005517          	auipc	a0,0x5
    800028d6:	c8650513          	addi	a0,a0,-890 # 80007558 <etext+0x558>
    800028da:	625020ef          	jal	800056fe <panic>
    800028de:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800028e0:	40dc                	lw	a5,4(s1)
    800028e2:	0047d79b          	srliw	a5,a5,0x4
    800028e6:	00013597          	auipc	a1,0x13
    800028ea:	62a5a583          	lw	a1,1578(a1) # 80015f10 <sb+0x18>
    800028ee:	9dbd                	addw	a1,a1,a5
    800028f0:	4088                	lw	a0,0(s1)
    800028f2:	8b5ff0ef          	jal	800021a6 <bread>
    800028f6:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800028f8:	05850593          	addi	a1,a0,88
    800028fc:	40dc                	lw	a5,4(s1)
    800028fe:	8bbd                	andi	a5,a5,15
    80002900:	079a                	slli	a5,a5,0x6
    80002902:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80002904:	00059783          	lh	a5,0(a1)
    80002908:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000290c:	00259783          	lh	a5,2(a1)
    80002910:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80002914:	00459783          	lh	a5,4(a1)
    80002918:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000291c:	00659783          	lh	a5,6(a1)
    80002920:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80002924:	459c                	lw	a5,8(a1)
    80002926:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80002928:	03400613          	li	a2,52
    8000292c:	05b1                	addi	a1,a1,12
    8000292e:	05048513          	addi	a0,s1,80
    80002932:	94bfd0ef          	jal	8000027c <memmove>
    brelse(bp);
    80002936:	854a                	mv	a0,s2
    80002938:	977ff0ef          	jal	800022ae <brelse>
    ip->valid = 1;
    8000293c:	4785                	li	a5,1
    8000293e:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80002940:	04449783          	lh	a5,68(s1)
    80002944:	c399                	beqz	a5,8000294a <ilock+0xa2>
    80002946:	6902                	ld	s2,0(sp)
    80002948:	bfbd                	j	800028c6 <ilock+0x1e>
      panic("ilock: no type");
    8000294a:	00005517          	auipc	a0,0x5
    8000294e:	c1650513          	addi	a0,a0,-1002 # 80007560 <etext+0x560>
    80002952:	5ad020ef          	jal	800056fe <panic>

0000000080002956 <iunlock>:
{
    80002956:	1101                	addi	sp,sp,-32
    80002958:	ec06                	sd	ra,24(sp)
    8000295a:	e822                	sd	s0,16(sp)
    8000295c:	e426                	sd	s1,8(sp)
    8000295e:	e04a                	sd	s2,0(sp)
    80002960:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80002962:	c505                	beqz	a0,8000298a <iunlock+0x34>
    80002964:	84aa                	mv	s1,a0
    80002966:	01050913          	addi	s2,a0,16
    8000296a:	854a                	mv	a0,s2
    8000296c:	315000ef          	jal	80003480 <holdingsleep>
    80002970:	cd09                	beqz	a0,8000298a <iunlock+0x34>
    80002972:	449c                	lw	a5,8(s1)
    80002974:	00f05b63          	blez	a5,8000298a <iunlock+0x34>
  releasesleep(&ip->lock);
    80002978:	854a                	mv	a0,s2
    8000297a:	2cf000ef          	jal	80003448 <releasesleep>
}
    8000297e:	60e2                	ld	ra,24(sp)
    80002980:	6442                	ld	s0,16(sp)
    80002982:	64a2                	ld	s1,8(sp)
    80002984:	6902                	ld	s2,0(sp)
    80002986:	6105                	addi	sp,sp,32
    80002988:	8082                	ret
    panic("iunlock");
    8000298a:	00005517          	auipc	a0,0x5
    8000298e:	be650513          	addi	a0,a0,-1050 # 80007570 <etext+0x570>
    80002992:	56d020ef          	jal	800056fe <panic>

0000000080002996 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80002996:	7179                	addi	sp,sp,-48
    80002998:	f406                	sd	ra,40(sp)
    8000299a:	f022                	sd	s0,32(sp)
    8000299c:	ec26                	sd	s1,24(sp)
    8000299e:	e84a                	sd	s2,16(sp)
    800029a0:	e44e                	sd	s3,8(sp)
    800029a2:	1800                	addi	s0,sp,48
    800029a4:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800029a6:	05050493          	addi	s1,a0,80
    800029aa:	08050913          	addi	s2,a0,128
    800029ae:	a021                	j	800029b6 <itrunc+0x20>
    800029b0:	0491                	addi	s1,s1,4
    800029b2:	01248b63          	beq	s1,s2,800029c8 <itrunc+0x32>
    if(ip->addrs[i]){
    800029b6:	408c                	lw	a1,0(s1)
    800029b8:	dde5                	beqz	a1,800029b0 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800029ba:	0009a503          	lw	a0,0(s3)
    800029be:	9ddff0ef          	jal	8000239a <bfree>
      ip->addrs[i] = 0;
    800029c2:	0004a023          	sw	zero,0(s1)
    800029c6:	b7ed                	j	800029b0 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800029c8:	0809a583          	lw	a1,128(s3)
    800029cc:	ed89                	bnez	a1,800029e6 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800029ce:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800029d2:	854e                	mv	a0,s3
    800029d4:	e21ff0ef          	jal	800027f4 <iupdate>
}
    800029d8:	70a2                	ld	ra,40(sp)
    800029da:	7402                	ld	s0,32(sp)
    800029dc:	64e2                	ld	s1,24(sp)
    800029de:	6942                	ld	s2,16(sp)
    800029e0:	69a2                	ld	s3,8(sp)
    800029e2:	6145                	addi	sp,sp,48
    800029e4:	8082                	ret
    800029e6:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800029e8:	0009a503          	lw	a0,0(s3)
    800029ec:	fbaff0ef          	jal	800021a6 <bread>
    800029f0:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800029f2:	05850493          	addi	s1,a0,88
    800029f6:	45850913          	addi	s2,a0,1112
    800029fa:	a021                	j	80002a02 <itrunc+0x6c>
    800029fc:	0491                	addi	s1,s1,4
    800029fe:	01248963          	beq	s1,s2,80002a10 <itrunc+0x7a>
      if(a[j])
    80002a02:	408c                	lw	a1,0(s1)
    80002a04:	dde5                	beqz	a1,800029fc <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80002a06:	0009a503          	lw	a0,0(s3)
    80002a0a:	991ff0ef          	jal	8000239a <bfree>
    80002a0e:	b7fd                	j	800029fc <itrunc+0x66>
    brelse(bp);
    80002a10:	8552                	mv	a0,s4
    80002a12:	89dff0ef          	jal	800022ae <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80002a16:	0809a583          	lw	a1,128(s3)
    80002a1a:	0009a503          	lw	a0,0(s3)
    80002a1e:	97dff0ef          	jal	8000239a <bfree>
    ip->addrs[NDIRECT] = 0;
    80002a22:	0809a023          	sw	zero,128(s3)
    80002a26:	6a02                	ld	s4,0(sp)
    80002a28:	b75d                	j	800029ce <itrunc+0x38>

0000000080002a2a <iput>:
{
    80002a2a:	1101                	addi	sp,sp,-32
    80002a2c:	ec06                	sd	ra,24(sp)
    80002a2e:	e822                	sd	s0,16(sp)
    80002a30:	e426                	sd	s1,8(sp)
    80002a32:	1000                	addi	s0,sp,32
    80002a34:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002a36:	00013517          	auipc	a0,0x13
    80002a3a:	4e250513          	addi	a0,a0,1250 # 80015f18 <itable>
    80002a3e:	7ff020ef          	jal	80005a3c <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a42:	4498                	lw	a4,8(s1)
    80002a44:	4785                	li	a5,1
    80002a46:	02f70063          	beq	a4,a5,80002a66 <iput+0x3c>
  ip->ref--;
    80002a4a:	449c                	lw	a5,8(s1)
    80002a4c:	37fd                	addiw	a5,a5,-1
    80002a4e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002a50:	00013517          	auipc	a0,0x13
    80002a54:	4c850513          	addi	a0,a0,1224 # 80015f18 <itable>
    80002a58:	078030ef          	jal	80005ad0 <release>
}
    80002a5c:	60e2                	ld	ra,24(sp)
    80002a5e:	6442                	ld	s0,16(sp)
    80002a60:	64a2                	ld	s1,8(sp)
    80002a62:	6105                	addi	sp,sp,32
    80002a64:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a66:	40bc                	lw	a5,64(s1)
    80002a68:	d3ed                	beqz	a5,80002a4a <iput+0x20>
    80002a6a:	04a49783          	lh	a5,74(s1)
    80002a6e:	fff1                	bnez	a5,80002a4a <iput+0x20>
    80002a70:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80002a72:	01048793          	addi	a5,s1,16
    80002a76:	893e                	mv	s2,a5
    80002a78:	853e                	mv	a0,a5
    80002a7a:	189000ef          	jal	80003402 <acquiresleep>
    release(&itable.lock);
    80002a7e:	00013517          	auipc	a0,0x13
    80002a82:	49a50513          	addi	a0,a0,1178 # 80015f18 <itable>
    80002a86:	04a030ef          	jal	80005ad0 <release>
    itrunc(ip);
    80002a8a:	8526                	mv	a0,s1
    80002a8c:	f0bff0ef          	jal	80002996 <itrunc>
    ip->type = 0;
    80002a90:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002a94:	8526                	mv	a0,s1
    80002a96:	d5fff0ef          	jal	800027f4 <iupdate>
    ip->valid = 0;
    80002a9a:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002a9e:	854a                	mv	a0,s2
    80002aa0:	1a9000ef          	jal	80003448 <releasesleep>
    acquire(&itable.lock);
    80002aa4:	00013517          	auipc	a0,0x13
    80002aa8:	47450513          	addi	a0,a0,1140 # 80015f18 <itable>
    80002aac:	791020ef          	jal	80005a3c <acquire>
    80002ab0:	6902                	ld	s2,0(sp)
    80002ab2:	bf61                	j	80002a4a <iput+0x20>

0000000080002ab4 <iunlockput>:
{
    80002ab4:	1101                	addi	sp,sp,-32
    80002ab6:	ec06                	sd	ra,24(sp)
    80002ab8:	e822                	sd	s0,16(sp)
    80002aba:	e426                	sd	s1,8(sp)
    80002abc:	1000                	addi	s0,sp,32
    80002abe:	84aa                	mv	s1,a0
  iunlock(ip);
    80002ac0:	e97ff0ef          	jal	80002956 <iunlock>
  iput(ip);
    80002ac4:	8526                	mv	a0,s1
    80002ac6:	f65ff0ef          	jal	80002a2a <iput>
}
    80002aca:	60e2                	ld	ra,24(sp)
    80002acc:	6442                	ld	s0,16(sp)
    80002ace:	64a2                	ld	s1,8(sp)
    80002ad0:	6105                	addi	sp,sp,32
    80002ad2:	8082                	ret

0000000080002ad4 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002ad4:	1141                	addi	sp,sp,-16
    80002ad6:	e406                	sd	ra,8(sp)
    80002ad8:	e022                	sd	s0,0(sp)
    80002ada:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80002adc:	411c                	lw	a5,0(a0)
    80002ade:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002ae0:	415c                	lw	a5,4(a0)
    80002ae2:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002ae4:	04451783          	lh	a5,68(a0)
    80002ae8:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80002aec:	04a51783          	lh	a5,74(a0)
    80002af0:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002af4:	04c56783          	lwu	a5,76(a0)
    80002af8:	e99c                	sd	a5,16(a1)
}
    80002afa:	60a2                	ld	ra,8(sp)
    80002afc:	6402                	ld	s0,0(sp)
    80002afe:	0141                	addi	sp,sp,16
    80002b00:	8082                	ret

0000000080002b02 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002b02:	457c                	lw	a5,76(a0)
    80002b04:	0ed7e663          	bltu	a5,a3,80002bf0 <readi+0xee>
{
    80002b08:	7159                	addi	sp,sp,-112
    80002b0a:	f486                	sd	ra,104(sp)
    80002b0c:	f0a2                	sd	s0,96(sp)
    80002b0e:	eca6                	sd	s1,88(sp)
    80002b10:	e0d2                	sd	s4,64(sp)
    80002b12:	fc56                	sd	s5,56(sp)
    80002b14:	f85a                	sd	s6,48(sp)
    80002b16:	f45e                	sd	s7,40(sp)
    80002b18:	1880                	addi	s0,sp,112
    80002b1a:	8b2a                	mv	s6,a0
    80002b1c:	8bae                	mv	s7,a1
    80002b1e:	8a32                	mv	s4,a2
    80002b20:	84b6                	mv	s1,a3
    80002b22:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80002b24:	9f35                	addw	a4,a4,a3
    return 0;
    80002b26:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002b28:	0ad76b63          	bltu	a4,a3,80002bde <readi+0xdc>
    80002b2c:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80002b2e:	00e7f463          	bgeu	a5,a4,80002b36 <readi+0x34>
    n = ip->size - off;
    80002b32:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b36:	080a8b63          	beqz	s5,80002bcc <readi+0xca>
    80002b3a:	e8ca                	sd	s2,80(sp)
    80002b3c:	f062                	sd	s8,32(sp)
    80002b3e:	ec66                	sd	s9,24(sp)
    80002b40:	e86a                	sd	s10,16(sp)
    80002b42:	e46e                	sd	s11,8(sp)
    80002b44:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b46:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002b4a:	5c7d                	li	s8,-1
    80002b4c:	a80d                	j	80002b7e <readi+0x7c>
    80002b4e:	020d1d93          	slli	s11,s10,0x20
    80002b52:	020ddd93          	srli	s11,s11,0x20
    80002b56:	05890613          	addi	a2,s2,88
    80002b5a:	86ee                	mv	a3,s11
    80002b5c:	963e                	add	a2,a2,a5
    80002b5e:	85d2                	mv	a1,s4
    80002b60:	855e                	mv	a0,s7
    80002b62:	da9fe0ef          	jal	8000190a <either_copyout>
    80002b66:	05850363          	beq	a0,s8,80002bac <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002b6a:	854a                	mv	a0,s2
    80002b6c:	f42ff0ef          	jal	800022ae <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b70:	013d09bb          	addw	s3,s10,s3
    80002b74:	009d04bb          	addw	s1,s10,s1
    80002b78:	9a6e                	add	s4,s4,s11
    80002b7a:	0559f363          	bgeu	s3,s5,80002bc0 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002b7e:	00a4d59b          	srliw	a1,s1,0xa
    80002b82:	855a                	mv	a0,s6
    80002b84:	989ff0ef          	jal	8000250c <bmap>
    80002b88:	85aa                	mv	a1,a0
    if(addr == 0)
    80002b8a:	c139                	beqz	a0,80002bd0 <readi+0xce>
    bp = bread(ip->dev, addr);
    80002b8c:	000b2503          	lw	a0,0(s6)
    80002b90:	e16ff0ef          	jal	800021a6 <bread>
    80002b94:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b96:	3ff4f793          	andi	a5,s1,1023
    80002b9a:	40fc873b          	subw	a4,s9,a5
    80002b9e:	413a86bb          	subw	a3,s5,s3
    80002ba2:	8d3a                	mv	s10,a4
    80002ba4:	fae6f5e3          	bgeu	a3,a4,80002b4e <readi+0x4c>
    80002ba8:	8d36                	mv	s10,a3
    80002baa:	b755                	j	80002b4e <readi+0x4c>
      brelse(bp);
    80002bac:	854a                	mv	a0,s2
    80002bae:	f00ff0ef          	jal	800022ae <brelse>
      tot = -1;
    80002bb2:	59fd                	li	s3,-1
      break;
    80002bb4:	6946                	ld	s2,80(sp)
    80002bb6:	7c02                	ld	s8,32(sp)
    80002bb8:	6ce2                	ld	s9,24(sp)
    80002bba:	6d42                	ld	s10,16(sp)
    80002bbc:	6da2                	ld	s11,8(sp)
    80002bbe:	a831                	j	80002bda <readi+0xd8>
    80002bc0:	6946                	ld	s2,80(sp)
    80002bc2:	7c02                	ld	s8,32(sp)
    80002bc4:	6ce2                	ld	s9,24(sp)
    80002bc6:	6d42                	ld	s10,16(sp)
    80002bc8:	6da2                	ld	s11,8(sp)
    80002bca:	a801                	j	80002bda <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002bcc:	89d6                	mv	s3,s5
    80002bce:	a031                	j	80002bda <readi+0xd8>
    80002bd0:	6946                	ld	s2,80(sp)
    80002bd2:	7c02                	ld	s8,32(sp)
    80002bd4:	6ce2                	ld	s9,24(sp)
    80002bd6:	6d42                	ld	s10,16(sp)
    80002bd8:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80002bda:	854e                	mv	a0,s3
    80002bdc:	69a6                	ld	s3,72(sp)
}
    80002bde:	70a6                	ld	ra,104(sp)
    80002be0:	7406                	ld	s0,96(sp)
    80002be2:	64e6                	ld	s1,88(sp)
    80002be4:	6a06                	ld	s4,64(sp)
    80002be6:	7ae2                	ld	s5,56(sp)
    80002be8:	7b42                	ld	s6,48(sp)
    80002bea:	7ba2                	ld	s7,40(sp)
    80002bec:	6165                	addi	sp,sp,112
    80002bee:	8082                	ret
    return 0;
    80002bf0:	4501                	li	a0,0
}
    80002bf2:	8082                	ret

0000000080002bf4 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002bf4:	457c                	lw	a5,76(a0)
    80002bf6:	0ed7eb63          	bltu	a5,a3,80002cec <writei+0xf8>
{
    80002bfa:	7159                	addi	sp,sp,-112
    80002bfc:	f486                	sd	ra,104(sp)
    80002bfe:	f0a2                	sd	s0,96(sp)
    80002c00:	e8ca                	sd	s2,80(sp)
    80002c02:	e0d2                	sd	s4,64(sp)
    80002c04:	fc56                	sd	s5,56(sp)
    80002c06:	f85a                	sd	s6,48(sp)
    80002c08:	f45e                	sd	s7,40(sp)
    80002c0a:	1880                	addi	s0,sp,112
    80002c0c:	8aaa                	mv	s5,a0
    80002c0e:	8bae                	mv	s7,a1
    80002c10:	8a32                	mv	s4,a2
    80002c12:	8936                	mv	s2,a3
    80002c14:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80002c16:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80002c1a:	00043737          	lui	a4,0x43
    80002c1e:	0cf76963          	bltu	a4,a5,80002cf0 <writei+0xfc>
    80002c22:	0cd7e763          	bltu	a5,a3,80002cf0 <writei+0xfc>
    80002c26:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c28:	0a0b0a63          	beqz	s6,80002cdc <writei+0xe8>
    80002c2c:	eca6                	sd	s1,88(sp)
    80002c2e:	f062                	sd	s8,32(sp)
    80002c30:	ec66                	sd	s9,24(sp)
    80002c32:	e86a                	sd	s10,16(sp)
    80002c34:	e46e                	sd	s11,8(sp)
    80002c36:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002c38:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002c3c:	5c7d                	li	s8,-1
    80002c3e:	a825                	j	80002c76 <writei+0x82>
    80002c40:	020d1d93          	slli	s11,s10,0x20
    80002c44:	020ddd93          	srli	s11,s11,0x20
    80002c48:	05848513          	addi	a0,s1,88
    80002c4c:	86ee                	mv	a3,s11
    80002c4e:	8652                	mv	a2,s4
    80002c50:	85de                	mv	a1,s7
    80002c52:	953e                	add	a0,a0,a5
    80002c54:	d01fe0ef          	jal	80001954 <either_copyin>
    80002c58:	05850663          	beq	a0,s8,80002ca4 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002c5c:	8526                	mv	a0,s1
    80002c5e:	69c000ef          	jal	800032fa <log_write>
    brelse(bp);
    80002c62:	8526                	mv	a0,s1
    80002c64:	e4aff0ef          	jal	800022ae <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c68:	013d09bb          	addw	s3,s10,s3
    80002c6c:	012d093b          	addw	s2,s10,s2
    80002c70:	9a6e                	add	s4,s4,s11
    80002c72:	0369fc63          	bgeu	s3,s6,80002caa <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80002c76:	00a9559b          	srliw	a1,s2,0xa
    80002c7a:	8556                	mv	a0,s5
    80002c7c:	891ff0ef          	jal	8000250c <bmap>
    80002c80:	85aa                	mv	a1,a0
    if(addr == 0)
    80002c82:	c505                	beqz	a0,80002caa <writei+0xb6>
    bp = bread(ip->dev, addr);
    80002c84:	000aa503          	lw	a0,0(s5)
    80002c88:	d1eff0ef          	jal	800021a6 <bread>
    80002c8c:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002c8e:	3ff97793          	andi	a5,s2,1023
    80002c92:	40fc873b          	subw	a4,s9,a5
    80002c96:	413b06bb          	subw	a3,s6,s3
    80002c9a:	8d3a                	mv	s10,a4
    80002c9c:	fae6f2e3          	bgeu	a3,a4,80002c40 <writei+0x4c>
    80002ca0:	8d36                	mv	s10,a3
    80002ca2:	bf79                	j	80002c40 <writei+0x4c>
      brelse(bp);
    80002ca4:	8526                	mv	a0,s1
    80002ca6:	e08ff0ef          	jal	800022ae <brelse>
  }

  if(off > ip->size)
    80002caa:	04caa783          	lw	a5,76(s5)
    80002cae:	0327f963          	bgeu	a5,s2,80002ce0 <writei+0xec>
    ip->size = off;
    80002cb2:	052aa623          	sw	s2,76(s5)
    80002cb6:	64e6                	ld	s1,88(sp)
    80002cb8:	7c02                	ld	s8,32(sp)
    80002cba:	6ce2                	ld	s9,24(sp)
    80002cbc:	6d42                	ld	s10,16(sp)
    80002cbe:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002cc0:	8556                	mv	a0,s5
    80002cc2:	b33ff0ef          	jal	800027f4 <iupdate>

  return tot;
    80002cc6:	854e                	mv	a0,s3
    80002cc8:	69a6                	ld	s3,72(sp)
}
    80002cca:	70a6                	ld	ra,104(sp)
    80002ccc:	7406                	ld	s0,96(sp)
    80002cce:	6946                	ld	s2,80(sp)
    80002cd0:	6a06                	ld	s4,64(sp)
    80002cd2:	7ae2                	ld	s5,56(sp)
    80002cd4:	7b42                	ld	s6,48(sp)
    80002cd6:	7ba2                	ld	s7,40(sp)
    80002cd8:	6165                	addi	sp,sp,112
    80002cda:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002cdc:	89da                	mv	s3,s6
    80002cde:	b7cd                	j	80002cc0 <writei+0xcc>
    80002ce0:	64e6                	ld	s1,88(sp)
    80002ce2:	7c02                	ld	s8,32(sp)
    80002ce4:	6ce2                	ld	s9,24(sp)
    80002ce6:	6d42                	ld	s10,16(sp)
    80002ce8:	6da2                	ld	s11,8(sp)
    80002cea:	bfd9                	j	80002cc0 <writei+0xcc>
    return -1;
    80002cec:	557d                	li	a0,-1
}
    80002cee:	8082                	ret
    return -1;
    80002cf0:	557d                	li	a0,-1
    80002cf2:	bfe1                	j	80002cca <writei+0xd6>

0000000080002cf4 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002cf4:	1141                	addi	sp,sp,-16
    80002cf6:	e406                	sd	ra,8(sp)
    80002cf8:	e022                	sd	s0,0(sp)
    80002cfa:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002cfc:	4639                	li	a2,14
    80002cfe:	df2fd0ef          	jal	800002f0 <strncmp>
}
    80002d02:	60a2                	ld	ra,8(sp)
    80002d04:	6402                	ld	s0,0(sp)
    80002d06:	0141                	addi	sp,sp,16
    80002d08:	8082                	ret

0000000080002d0a <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002d0a:	711d                	addi	sp,sp,-96
    80002d0c:	ec86                	sd	ra,88(sp)
    80002d0e:	e8a2                	sd	s0,80(sp)
    80002d10:	e4a6                	sd	s1,72(sp)
    80002d12:	e0ca                	sd	s2,64(sp)
    80002d14:	fc4e                	sd	s3,56(sp)
    80002d16:	f852                	sd	s4,48(sp)
    80002d18:	f456                	sd	s5,40(sp)
    80002d1a:	f05a                	sd	s6,32(sp)
    80002d1c:	ec5e                	sd	s7,24(sp)
    80002d1e:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002d20:	04451703          	lh	a4,68(a0)
    80002d24:	4785                	li	a5,1
    80002d26:	00f71f63          	bne	a4,a5,80002d44 <dirlookup+0x3a>
    80002d2a:	892a                	mv	s2,a0
    80002d2c:	8aae                	mv	s5,a1
    80002d2e:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d30:	457c                	lw	a5,76(a0)
    80002d32:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d34:	fa040a13          	addi	s4,s0,-96
    80002d38:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80002d3a:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002d3e:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d40:	e39d                	bnez	a5,80002d66 <dirlookup+0x5c>
    80002d42:	a8b9                	j	80002da0 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80002d44:	00005517          	auipc	a0,0x5
    80002d48:	83450513          	addi	a0,a0,-1996 # 80007578 <etext+0x578>
    80002d4c:	1b3020ef          	jal	800056fe <panic>
      panic("dirlookup read");
    80002d50:	00005517          	auipc	a0,0x5
    80002d54:	84050513          	addi	a0,a0,-1984 # 80007590 <etext+0x590>
    80002d58:	1a7020ef          	jal	800056fe <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d5c:	24c1                	addiw	s1,s1,16
    80002d5e:	04c92783          	lw	a5,76(s2)
    80002d62:	02f4fe63          	bgeu	s1,a5,80002d9e <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d66:	874e                	mv	a4,s3
    80002d68:	86a6                	mv	a3,s1
    80002d6a:	8652                	mv	a2,s4
    80002d6c:	4581                	li	a1,0
    80002d6e:	854a                	mv	a0,s2
    80002d70:	d93ff0ef          	jal	80002b02 <readi>
    80002d74:	fd351ee3          	bne	a0,s3,80002d50 <dirlookup+0x46>
    if(de.inum == 0)
    80002d78:	fa045783          	lhu	a5,-96(s0)
    80002d7c:	d3e5                	beqz	a5,80002d5c <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80002d7e:	85da                	mv	a1,s6
    80002d80:	8556                	mv	a0,s5
    80002d82:	f73ff0ef          	jal	80002cf4 <namecmp>
    80002d86:	f979                	bnez	a0,80002d5c <dirlookup+0x52>
      if(poff)
    80002d88:	000b8463          	beqz	s7,80002d90 <dirlookup+0x86>
        *poff = off;
    80002d8c:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80002d90:	fa045583          	lhu	a1,-96(s0)
    80002d94:	00092503          	lw	a0,0(s2)
    80002d98:	835ff0ef          	jal	800025cc <iget>
    80002d9c:	a011                	j	80002da0 <dirlookup+0x96>
  return 0;
    80002d9e:	4501                	li	a0,0
}
    80002da0:	60e6                	ld	ra,88(sp)
    80002da2:	6446                	ld	s0,80(sp)
    80002da4:	64a6                	ld	s1,72(sp)
    80002da6:	6906                	ld	s2,64(sp)
    80002da8:	79e2                	ld	s3,56(sp)
    80002daa:	7a42                	ld	s4,48(sp)
    80002dac:	7aa2                	ld	s5,40(sp)
    80002dae:	7b02                	ld	s6,32(sp)
    80002db0:	6be2                	ld	s7,24(sp)
    80002db2:	6125                	addi	sp,sp,96
    80002db4:	8082                	ret

0000000080002db6 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002db6:	711d                	addi	sp,sp,-96
    80002db8:	ec86                	sd	ra,88(sp)
    80002dba:	e8a2                	sd	s0,80(sp)
    80002dbc:	e4a6                	sd	s1,72(sp)
    80002dbe:	e0ca                	sd	s2,64(sp)
    80002dc0:	fc4e                	sd	s3,56(sp)
    80002dc2:	f852                	sd	s4,48(sp)
    80002dc4:	f456                	sd	s5,40(sp)
    80002dc6:	f05a                	sd	s6,32(sp)
    80002dc8:	ec5e                	sd	s7,24(sp)
    80002dca:	e862                	sd	s8,16(sp)
    80002dcc:	e466                	sd	s9,8(sp)
    80002dce:	e06a                	sd	s10,0(sp)
    80002dd0:	1080                	addi	s0,sp,96
    80002dd2:	84aa                	mv	s1,a0
    80002dd4:	8b2e                	mv	s6,a1
    80002dd6:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002dd8:	00054703          	lbu	a4,0(a0)
    80002ddc:	02f00793          	li	a5,47
    80002de0:	00f70f63          	beq	a4,a5,80002dfe <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002de4:	9fafe0ef          	jal	80000fde <myproc>
    80002de8:	15053503          	ld	a0,336(a0)
    80002dec:	a87ff0ef          	jal	80002872 <idup>
    80002df0:	8a2a                	mv	s4,a0
  while(*path == '/')
    80002df2:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80002df6:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80002df8:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002dfa:	4b85                	li	s7,1
    80002dfc:	a879                	j	80002e9a <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80002dfe:	4585                	li	a1,1
    80002e00:	852e                	mv	a0,a1
    80002e02:	fcaff0ef          	jal	800025cc <iget>
    80002e06:	8a2a                	mv	s4,a0
    80002e08:	b7ed                	j	80002df2 <namex+0x3c>
      iunlockput(ip);
    80002e0a:	8552                	mv	a0,s4
    80002e0c:	ca9ff0ef          	jal	80002ab4 <iunlockput>
      return 0;
    80002e10:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002e12:	8552                	mv	a0,s4
    80002e14:	60e6                	ld	ra,88(sp)
    80002e16:	6446                	ld	s0,80(sp)
    80002e18:	64a6                	ld	s1,72(sp)
    80002e1a:	6906                	ld	s2,64(sp)
    80002e1c:	79e2                	ld	s3,56(sp)
    80002e1e:	7a42                	ld	s4,48(sp)
    80002e20:	7aa2                	ld	s5,40(sp)
    80002e22:	7b02                	ld	s6,32(sp)
    80002e24:	6be2                	ld	s7,24(sp)
    80002e26:	6c42                	ld	s8,16(sp)
    80002e28:	6ca2                	ld	s9,8(sp)
    80002e2a:	6d02                	ld	s10,0(sp)
    80002e2c:	6125                	addi	sp,sp,96
    80002e2e:	8082                	ret
      iunlock(ip);
    80002e30:	8552                	mv	a0,s4
    80002e32:	b25ff0ef          	jal	80002956 <iunlock>
      return ip;
    80002e36:	bff1                	j	80002e12 <namex+0x5c>
      iunlockput(ip);
    80002e38:	8552                	mv	a0,s4
    80002e3a:	c7bff0ef          	jal	80002ab4 <iunlockput>
      return 0;
    80002e3e:	8a4a                	mv	s4,s2
    80002e40:	bfc9                	j	80002e12 <namex+0x5c>
  len = path - s;
    80002e42:	40990633          	sub	a2,s2,s1
    80002e46:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80002e4a:	09ac5463          	bge	s8,s10,80002ed2 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80002e4e:	8666                	mv	a2,s9
    80002e50:	85a6                	mv	a1,s1
    80002e52:	8556                	mv	a0,s5
    80002e54:	c28fd0ef          	jal	8000027c <memmove>
    80002e58:	84ca                	mv	s1,s2
  while(*path == '/')
    80002e5a:	0004c783          	lbu	a5,0(s1)
    80002e5e:	01379763          	bne	a5,s3,80002e6c <namex+0xb6>
    path++;
    80002e62:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e64:	0004c783          	lbu	a5,0(s1)
    80002e68:	ff378de3          	beq	a5,s3,80002e62 <namex+0xac>
    ilock(ip);
    80002e6c:	8552                	mv	a0,s4
    80002e6e:	a3bff0ef          	jal	800028a8 <ilock>
    if(ip->type != T_DIR){
    80002e72:	044a1783          	lh	a5,68(s4)
    80002e76:	f9779ae3          	bne	a5,s7,80002e0a <namex+0x54>
    if(nameiparent && *path == '\0'){
    80002e7a:	000b0563          	beqz	s6,80002e84 <namex+0xce>
    80002e7e:	0004c783          	lbu	a5,0(s1)
    80002e82:	d7dd                	beqz	a5,80002e30 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002e84:	4601                	li	a2,0
    80002e86:	85d6                	mv	a1,s5
    80002e88:	8552                	mv	a0,s4
    80002e8a:	e81ff0ef          	jal	80002d0a <dirlookup>
    80002e8e:	892a                	mv	s2,a0
    80002e90:	d545                	beqz	a0,80002e38 <namex+0x82>
    iunlockput(ip);
    80002e92:	8552                	mv	a0,s4
    80002e94:	c21ff0ef          	jal	80002ab4 <iunlockput>
    ip = next;
    80002e98:	8a4a                	mv	s4,s2
  while(*path == '/')
    80002e9a:	0004c783          	lbu	a5,0(s1)
    80002e9e:	01379763          	bne	a5,s3,80002eac <namex+0xf6>
    path++;
    80002ea2:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002ea4:	0004c783          	lbu	a5,0(s1)
    80002ea8:	ff378de3          	beq	a5,s3,80002ea2 <namex+0xec>
  if(*path == 0)
    80002eac:	cf8d                	beqz	a5,80002ee6 <namex+0x130>
  while(*path != '/' && *path != 0)
    80002eae:	0004c783          	lbu	a5,0(s1)
    80002eb2:	fd178713          	addi	a4,a5,-47
    80002eb6:	cb19                	beqz	a4,80002ecc <namex+0x116>
    80002eb8:	cb91                	beqz	a5,80002ecc <namex+0x116>
    80002eba:	8926                	mv	s2,s1
    path++;
    80002ebc:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80002ebe:	00094783          	lbu	a5,0(s2)
    80002ec2:	fd178713          	addi	a4,a5,-47
    80002ec6:	df35                	beqz	a4,80002e42 <namex+0x8c>
    80002ec8:	fbf5                	bnez	a5,80002ebc <namex+0x106>
    80002eca:	bfa5                	j	80002e42 <namex+0x8c>
    80002ecc:	8926                	mv	s2,s1
  len = path - s;
    80002ece:	4d01                	li	s10,0
    80002ed0:	4601                	li	a2,0
    memmove(name, s, len);
    80002ed2:	2601                	sext.w	a2,a2
    80002ed4:	85a6                	mv	a1,s1
    80002ed6:	8556                	mv	a0,s5
    80002ed8:	ba4fd0ef          	jal	8000027c <memmove>
    name[len] = 0;
    80002edc:	9d56                	add	s10,s10,s5
    80002ede:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffde300>
    80002ee2:	84ca                	mv	s1,s2
    80002ee4:	bf9d                	j	80002e5a <namex+0xa4>
  if(nameiparent){
    80002ee6:	f20b06e3          	beqz	s6,80002e12 <namex+0x5c>
    iput(ip);
    80002eea:	8552                	mv	a0,s4
    80002eec:	b3fff0ef          	jal	80002a2a <iput>
    return 0;
    80002ef0:	4a01                	li	s4,0
    80002ef2:	b705                	j	80002e12 <namex+0x5c>

0000000080002ef4 <dirlink>:
{
    80002ef4:	715d                	addi	sp,sp,-80
    80002ef6:	e486                	sd	ra,72(sp)
    80002ef8:	e0a2                	sd	s0,64(sp)
    80002efa:	f84a                	sd	s2,48(sp)
    80002efc:	ec56                	sd	s5,24(sp)
    80002efe:	e85a                	sd	s6,16(sp)
    80002f00:	0880                	addi	s0,sp,80
    80002f02:	892a                	mv	s2,a0
    80002f04:	8aae                	mv	s5,a1
    80002f06:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002f08:	4601                	li	a2,0
    80002f0a:	e01ff0ef          	jal	80002d0a <dirlookup>
    80002f0e:	ed1d                	bnez	a0,80002f4c <dirlink+0x58>
    80002f10:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002f12:	04c92483          	lw	s1,76(s2)
    80002f16:	c4b9                	beqz	s1,80002f64 <dirlink+0x70>
    80002f18:	f44e                	sd	s3,40(sp)
    80002f1a:	f052                	sd	s4,32(sp)
    80002f1c:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002f1e:	fb040a13          	addi	s4,s0,-80
    80002f22:	49c1                	li	s3,16
    80002f24:	874e                	mv	a4,s3
    80002f26:	86a6                	mv	a3,s1
    80002f28:	8652                	mv	a2,s4
    80002f2a:	4581                	li	a1,0
    80002f2c:	854a                	mv	a0,s2
    80002f2e:	bd5ff0ef          	jal	80002b02 <readi>
    80002f32:	03351163          	bne	a0,s3,80002f54 <dirlink+0x60>
    if(de.inum == 0)
    80002f36:	fb045783          	lhu	a5,-80(s0)
    80002f3a:	c39d                	beqz	a5,80002f60 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002f3c:	24c1                	addiw	s1,s1,16
    80002f3e:	04c92783          	lw	a5,76(s2)
    80002f42:	fef4e1e3          	bltu	s1,a5,80002f24 <dirlink+0x30>
    80002f46:	79a2                	ld	s3,40(sp)
    80002f48:	7a02                	ld	s4,32(sp)
    80002f4a:	a829                	j	80002f64 <dirlink+0x70>
    iput(ip);
    80002f4c:	adfff0ef          	jal	80002a2a <iput>
    return -1;
    80002f50:	557d                	li	a0,-1
    80002f52:	a83d                	j	80002f90 <dirlink+0x9c>
      panic("dirlink read");
    80002f54:	00004517          	auipc	a0,0x4
    80002f58:	64c50513          	addi	a0,a0,1612 # 800075a0 <etext+0x5a0>
    80002f5c:	7a2020ef          	jal	800056fe <panic>
    80002f60:	79a2                	ld	s3,40(sp)
    80002f62:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80002f64:	4639                	li	a2,14
    80002f66:	85d6                	mv	a1,s5
    80002f68:	fb240513          	addi	a0,s0,-78
    80002f6c:	bbefd0ef          	jal	8000032a <strncpy>
  de.inum = inum;
    80002f70:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002f74:	4741                	li	a4,16
    80002f76:	86a6                	mv	a3,s1
    80002f78:	fb040613          	addi	a2,s0,-80
    80002f7c:	4581                	li	a1,0
    80002f7e:	854a                	mv	a0,s2
    80002f80:	c75ff0ef          	jal	80002bf4 <writei>
    80002f84:	1541                	addi	a0,a0,-16
    80002f86:	00a03533          	snez	a0,a0
    80002f8a:	40a0053b          	negw	a0,a0
    80002f8e:	74e2                	ld	s1,56(sp)
}
    80002f90:	60a6                	ld	ra,72(sp)
    80002f92:	6406                	ld	s0,64(sp)
    80002f94:	7942                	ld	s2,48(sp)
    80002f96:	6ae2                	ld	s5,24(sp)
    80002f98:	6b42                	ld	s6,16(sp)
    80002f9a:	6161                	addi	sp,sp,80
    80002f9c:	8082                	ret

0000000080002f9e <namei>:

struct inode*
namei(char *path)
{
    80002f9e:	1101                	addi	sp,sp,-32
    80002fa0:	ec06                	sd	ra,24(sp)
    80002fa2:	e822                	sd	s0,16(sp)
    80002fa4:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002fa6:	fe040613          	addi	a2,s0,-32
    80002faa:	4581                	li	a1,0
    80002fac:	e0bff0ef          	jal	80002db6 <namex>
}
    80002fb0:	60e2                	ld	ra,24(sp)
    80002fb2:	6442                	ld	s0,16(sp)
    80002fb4:	6105                	addi	sp,sp,32
    80002fb6:	8082                	ret

0000000080002fb8 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002fb8:	1141                	addi	sp,sp,-16
    80002fba:	e406                	sd	ra,8(sp)
    80002fbc:	e022                	sd	s0,0(sp)
    80002fbe:	0800                	addi	s0,sp,16
    80002fc0:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002fc2:	4585                	li	a1,1
    80002fc4:	df3ff0ef          	jal	80002db6 <namex>
}
    80002fc8:	60a2                	ld	ra,8(sp)
    80002fca:	6402                	ld	s0,0(sp)
    80002fcc:	0141                	addi	sp,sp,16
    80002fce:	8082                	ret

0000000080002fd0 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002fd0:	1101                	addi	sp,sp,-32
    80002fd2:	ec06                	sd	ra,24(sp)
    80002fd4:	e822                	sd	s0,16(sp)
    80002fd6:	e426                	sd	s1,8(sp)
    80002fd8:	e04a                	sd	s2,0(sp)
    80002fda:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002fdc:	00015917          	auipc	s2,0x15
    80002fe0:	9e490913          	addi	s2,s2,-1564 # 800179c0 <log>
    80002fe4:	01892583          	lw	a1,24(s2)
    80002fe8:	02892503          	lw	a0,40(s2)
    80002fec:	9baff0ef          	jal	800021a6 <bread>
    80002ff0:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002ff2:	02c92603          	lw	a2,44(s2)
    80002ff6:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002ff8:	00c05f63          	blez	a2,80003016 <write_head+0x46>
    80002ffc:	00015717          	auipc	a4,0x15
    80003000:	9f470713          	addi	a4,a4,-1548 # 800179f0 <log+0x30>
    80003004:	87aa                	mv	a5,a0
    80003006:	060a                	slli	a2,a2,0x2
    80003008:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    8000300a:	4314                	lw	a3,0(a4)
    8000300c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    8000300e:	0711                	addi	a4,a4,4
    80003010:	0791                	addi	a5,a5,4
    80003012:	fec79ce3          	bne	a5,a2,8000300a <write_head+0x3a>
  }
  bwrite(buf);
    80003016:	8526                	mv	a0,s1
    80003018:	a64ff0ef          	jal	8000227c <bwrite>
  brelse(buf);
    8000301c:	8526                	mv	a0,s1
    8000301e:	a90ff0ef          	jal	800022ae <brelse>
}
    80003022:	60e2                	ld	ra,24(sp)
    80003024:	6442                	ld	s0,16(sp)
    80003026:	64a2                	ld	s1,8(sp)
    80003028:	6902                	ld	s2,0(sp)
    8000302a:	6105                	addi	sp,sp,32
    8000302c:	8082                	ret

000000008000302e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    8000302e:	00015797          	auipc	a5,0x15
    80003032:	9be7a783          	lw	a5,-1602(a5) # 800179ec <log+0x2c>
    80003036:	0af05263          	blez	a5,800030da <install_trans+0xac>
{
    8000303a:	715d                	addi	sp,sp,-80
    8000303c:	e486                	sd	ra,72(sp)
    8000303e:	e0a2                	sd	s0,64(sp)
    80003040:	fc26                	sd	s1,56(sp)
    80003042:	f84a                	sd	s2,48(sp)
    80003044:	f44e                	sd	s3,40(sp)
    80003046:	f052                	sd	s4,32(sp)
    80003048:	ec56                	sd	s5,24(sp)
    8000304a:	e85a                	sd	s6,16(sp)
    8000304c:	e45e                	sd	s7,8(sp)
    8000304e:	0880                	addi	s0,sp,80
    80003050:	8b2a                	mv	s6,a0
    80003052:	00015a97          	auipc	s5,0x15
    80003056:	99ea8a93          	addi	s5,s5,-1634 # 800179f0 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000305a:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000305c:	00015997          	auipc	s3,0x15
    80003060:	96498993          	addi	s3,s3,-1692 # 800179c0 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003064:	40000b93          	li	s7,1024
    80003068:	a829                	j	80003082 <install_trans+0x54>
    brelse(lbuf);
    8000306a:	854a                	mv	a0,s2
    8000306c:	a42ff0ef          	jal	800022ae <brelse>
    brelse(dbuf);
    80003070:	8526                	mv	a0,s1
    80003072:	a3cff0ef          	jal	800022ae <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003076:	2a05                	addiw	s4,s4,1
    80003078:	0a91                	addi	s5,s5,4
    8000307a:	02c9a783          	lw	a5,44(s3)
    8000307e:	04fa5363          	bge	s4,a5,800030c4 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003082:	0189a583          	lw	a1,24(s3)
    80003086:	014585bb          	addw	a1,a1,s4
    8000308a:	2585                	addiw	a1,a1,1
    8000308c:	0289a503          	lw	a0,40(s3)
    80003090:	916ff0ef          	jal	800021a6 <bread>
    80003094:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003096:	000aa583          	lw	a1,0(s5)
    8000309a:	0289a503          	lw	a0,40(s3)
    8000309e:	908ff0ef          	jal	800021a6 <bread>
    800030a2:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    800030a4:	865e                	mv	a2,s7
    800030a6:	05890593          	addi	a1,s2,88
    800030aa:	05850513          	addi	a0,a0,88
    800030ae:	9cefd0ef          	jal	8000027c <memmove>
    bwrite(dbuf);  // write dst to disk
    800030b2:	8526                	mv	a0,s1
    800030b4:	9c8ff0ef          	jal	8000227c <bwrite>
    if(recovering == 0)
    800030b8:	fa0b19e3          	bnez	s6,8000306a <install_trans+0x3c>
      bunpin(dbuf);
    800030bc:	8526                	mv	a0,s1
    800030be:	aa8ff0ef          	jal	80002366 <bunpin>
    800030c2:	b765                	j	8000306a <install_trans+0x3c>
}
    800030c4:	60a6                	ld	ra,72(sp)
    800030c6:	6406                	ld	s0,64(sp)
    800030c8:	74e2                	ld	s1,56(sp)
    800030ca:	7942                	ld	s2,48(sp)
    800030cc:	79a2                	ld	s3,40(sp)
    800030ce:	7a02                	ld	s4,32(sp)
    800030d0:	6ae2                	ld	s5,24(sp)
    800030d2:	6b42                	ld	s6,16(sp)
    800030d4:	6ba2                	ld	s7,8(sp)
    800030d6:	6161                	addi	sp,sp,80
    800030d8:	8082                	ret
    800030da:	8082                	ret

00000000800030dc <initlog>:
{
    800030dc:	7179                	addi	sp,sp,-48
    800030de:	f406                	sd	ra,40(sp)
    800030e0:	f022                	sd	s0,32(sp)
    800030e2:	ec26                	sd	s1,24(sp)
    800030e4:	e84a                	sd	s2,16(sp)
    800030e6:	e44e                	sd	s3,8(sp)
    800030e8:	1800                	addi	s0,sp,48
    800030ea:	892a                	mv	s2,a0
    800030ec:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    800030ee:	00015497          	auipc	s1,0x15
    800030f2:	8d248493          	addi	s1,s1,-1838 # 800179c0 <log>
    800030f6:	00004597          	auipc	a1,0x4
    800030fa:	4ba58593          	addi	a1,a1,1210 # 800075b0 <etext+0x5b0>
    800030fe:	8526                	mv	a0,s1
    80003100:	0b3020ef          	jal	800059b2 <initlock>
  log.start = sb->logstart;
    80003104:	0149a583          	lw	a1,20(s3)
    80003108:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    8000310a:	0109a783          	lw	a5,16(s3)
    8000310e:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003110:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003114:	854a                	mv	a0,s2
    80003116:	890ff0ef          	jal	800021a6 <bread>
  log.lh.n = lh->n;
    8000311a:	4d30                	lw	a2,88(a0)
    8000311c:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    8000311e:	00c05f63          	blez	a2,8000313c <initlog+0x60>
    80003122:	87aa                	mv	a5,a0
    80003124:	00015717          	auipc	a4,0x15
    80003128:	8cc70713          	addi	a4,a4,-1844 # 800179f0 <log+0x30>
    8000312c:	060a                	slli	a2,a2,0x2
    8000312e:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003130:	4ff4                	lw	a3,92(a5)
    80003132:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003134:	0791                	addi	a5,a5,4
    80003136:	0711                	addi	a4,a4,4
    80003138:	fec79ce3          	bne	a5,a2,80003130 <initlog+0x54>
  brelse(buf);
    8000313c:	972ff0ef          	jal	800022ae <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003140:	4505                	li	a0,1
    80003142:	eedff0ef          	jal	8000302e <install_trans>
  log.lh.n = 0;
    80003146:	00015797          	auipc	a5,0x15
    8000314a:	8a07a323          	sw	zero,-1882(a5) # 800179ec <log+0x2c>
  write_head(); // clear the log
    8000314e:	e83ff0ef          	jal	80002fd0 <write_head>
}
    80003152:	70a2                	ld	ra,40(sp)
    80003154:	7402                	ld	s0,32(sp)
    80003156:	64e2                	ld	s1,24(sp)
    80003158:	6942                	ld	s2,16(sp)
    8000315a:	69a2                	ld	s3,8(sp)
    8000315c:	6145                	addi	sp,sp,48
    8000315e:	8082                	ret

0000000080003160 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003160:	1101                	addi	sp,sp,-32
    80003162:	ec06                	sd	ra,24(sp)
    80003164:	e822                	sd	s0,16(sp)
    80003166:	e426                	sd	s1,8(sp)
    80003168:	e04a                	sd	s2,0(sp)
    8000316a:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000316c:	00015517          	auipc	a0,0x15
    80003170:	85450513          	addi	a0,a0,-1964 # 800179c0 <log>
    80003174:	0c9020ef          	jal	80005a3c <acquire>
  while(1){
    if(log.committing){
    80003178:	00015497          	auipc	s1,0x15
    8000317c:	84848493          	addi	s1,s1,-1976 # 800179c0 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003180:	4979                	li	s2,30
    80003182:	a029                	j	8000318c <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003184:	85a6                	mv	a1,s1
    80003186:	8526                	mv	a0,s1
    80003188:	c28fe0ef          	jal	800015b0 <sleep>
    if(log.committing){
    8000318c:	50dc                	lw	a5,36(s1)
    8000318e:	fbfd                	bnez	a5,80003184 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003190:	5098                	lw	a4,32(s1)
    80003192:	2705                	addiw	a4,a4,1
    80003194:	0027179b          	slliw	a5,a4,0x2
    80003198:	9fb9                	addw	a5,a5,a4
    8000319a:	0017979b          	slliw	a5,a5,0x1
    8000319e:	54d4                	lw	a3,44(s1)
    800031a0:	9fb5                	addw	a5,a5,a3
    800031a2:	00f95763          	bge	s2,a5,800031b0 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    800031a6:	85a6                	mv	a1,s1
    800031a8:	8526                	mv	a0,s1
    800031aa:	c06fe0ef          	jal	800015b0 <sleep>
    800031ae:	bff9                	j	8000318c <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    800031b0:	00015797          	auipc	a5,0x15
    800031b4:	82e7a823          	sw	a4,-2000(a5) # 800179e0 <log+0x20>
      release(&log.lock);
    800031b8:	00015517          	auipc	a0,0x15
    800031bc:	80850513          	addi	a0,a0,-2040 # 800179c0 <log>
    800031c0:	111020ef          	jal	80005ad0 <release>
      break;
    }
  }
}
    800031c4:	60e2                	ld	ra,24(sp)
    800031c6:	6442                	ld	s0,16(sp)
    800031c8:	64a2                	ld	s1,8(sp)
    800031ca:	6902                	ld	s2,0(sp)
    800031cc:	6105                	addi	sp,sp,32
    800031ce:	8082                	ret

00000000800031d0 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    800031d0:	7139                	addi	sp,sp,-64
    800031d2:	fc06                	sd	ra,56(sp)
    800031d4:	f822                	sd	s0,48(sp)
    800031d6:	f426                	sd	s1,40(sp)
    800031d8:	f04a                	sd	s2,32(sp)
    800031da:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    800031dc:	00014497          	auipc	s1,0x14
    800031e0:	7e448493          	addi	s1,s1,2020 # 800179c0 <log>
    800031e4:	8526                	mv	a0,s1
    800031e6:	057020ef          	jal	80005a3c <acquire>
  log.outstanding -= 1;
    800031ea:	509c                	lw	a5,32(s1)
    800031ec:	37fd                	addiw	a5,a5,-1
    800031ee:	893e                	mv	s2,a5
    800031f0:	d09c                	sw	a5,32(s1)
  if(log.committing)
    800031f2:	50dc                	lw	a5,36(s1)
    800031f4:	e7b1                	bnez	a5,80003240 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    800031f6:	04091e63          	bnez	s2,80003252 <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    800031fa:	00014497          	auipc	s1,0x14
    800031fe:	7c648493          	addi	s1,s1,1990 # 800179c0 <log>
    80003202:	4785                	li	a5,1
    80003204:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003206:	8526                	mv	a0,s1
    80003208:	0c9020ef          	jal	80005ad0 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    8000320c:	54dc                	lw	a5,44(s1)
    8000320e:	06f04463          	bgtz	a5,80003276 <end_op+0xa6>
    acquire(&log.lock);
    80003212:	00014517          	auipc	a0,0x14
    80003216:	7ae50513          	addi	a0,a0,1966 # 800179c0 <log>
    8000321a:	023020ef          	jal	80005a3c <acquire>
    log.committing = 0;
    8000321e:	00014797          	auipc	a5,0x14
    80003222:	7c07a323          	sw	zero,1990(a5) # 800179e4 <log+0x24>
    wakeup(&log);
    80003226:	00014517          	auipc	a0,0x14
    8000322a:	79a50513          	addi	a0,a0,1946 # 800179c0 <log>
    8000322e:	bcefe0ef          	jal	800015fc <wakeup>
    release(&log.lock);
    80003232:	00014517          	auipc	a0,0x14
    80003236:	78e50513          	addi	a0,a0,1934 # 800179c0 <log>
    8000323a:	097020ef          	jal	80005ad0 <release>
}
    8000323e:	a035                	j	8000326a <end_op+0x9a>
    80003240:	ec4e                	sd	s3,24(sp)
    80003242:	e852                	sd	s4,16(sp)
    80003244:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003246:	00004517          	auipc	a0,0x4
    8000324a:	37250513          	addi	a0,a0,882 # 800075b8 <etext+0x5b8>
    8000324e:	4b0020ef          	jal	800056fe <panic>
    wakeup(&log);
    80003252:	00014517          	auipc	a0,0x14
    80003256:	76e50513          	addi	a0,a0,1902 # 800179c0 <log>
    8000325a:	ba2fe0ef          	jal	800015fc <wakeup>
  release(&log.lock);
    8000325e:	00014517          	auipc	a0,0x14
    80003262:	76250513          	addi	a0,a0,1890 # 800179c0 <log>
    80003266:	06b020ef          	jal	80005ad0 <release>
}
    8000326a:	70e2                	ld	ra,56(sp)
    8000326c:	7442                	ld	s0,48(sp)
    8000326e:	74a2                	ld	s1,40(sp)
    80003270:	7902                	ld	s2,32(sp)
    80003272:	6121                	addi	sp,sp,64
    80003274:	8082                	ret
    80003276:	ec4e                	sd	s3,24(sp)
    80003278:	e852                	sd	s4,16(sp)
    8000327a:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    8000327c:	00014a97          	auipc	s5,0x14
    80003280:	774a8a93          	addi	s5,s5,1908 # 800179f0 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003284:	00014a17          	auipc	s4,0x14
    80003288:	73ca0a13          	addi	s4,s4,1852 # 800179c0 <log>
    8000328c:	018a2583          	lw	a1,24(s4)
    80003290:	012585bb          	addw	a1,a1,s2
    80003294:	2585                	addiw	a1,a1,1
    80003296:	028a2503          	lw	a0,40(s4)
    8000329a:	f0dfe0ef          	jal	800021a6 <bread>
    8000329e:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    800032a0:	000aa583          	lw	a1,0(s5)
    800032a4:	028a2503          	lw	a0,40(s4)
    800032a8:	efffe0ef          	jal	800021a6 <bread>
    800032ac:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    800032ae:	40000613          	li	a2,1024
    800032b2:	05850593          	addi	a1,a0,88
    800032b6:	05848513          	addi	a0,s1,88
    800032ba:	fc3fc0ef          	jal	8000027c <memmove>
    bwrite(to);  // write the log
    800032be:	8526                	mv	a0,s1
    800032c0:	fbdfe0ef          	jal	8000227c <bwrite>
    brelse(from);
    800032c4:	854e                	mv	a0,s3
    800032c6:	fe9fe0ef          	jal	800022ae <brelse>
    brelse(to);
    800032ca:	8526                	mv	a0,s1
    800032cc:	fe3fe0ef          	jal	800022ae <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800032d0:	2905                	addiw	s2,s2,1
    800032d2:	0a91                	addi	s5,s5,4
    800032d4:	02ca2783          	lw	a5,44(s4)
    800032d8:	faf94ae3          	blt	s2,a5,8000328c <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800032dc:	cf5ff0ef          	jal	80002fd0 <write_head>
    install_trans(0); // Now install writes to home locations
    800032e0:	4501                	li	a0,0
    800032e2:	d4dff0ef          	jal	8000302e <install_trans>
    log.lh.n = 0;
    800032e6:	00014797          	auipc	a5,0x14
    800032ea:	7007a323          	sw	zero,1798(a5) # 800179ec <log+0x2c>
    write_head();    // Erase the transaction from the log
    800032ee:	ce3ff0ef          	jal	80002fd0 <write_head>
    800032f2:	69e2                	ld	s3,24(sp)
    800032f4:	6a42                	ld	s4,16(sp)
    800032f6:	6aa2                	ld	s5,8(sp)
    800032f8:	bf29                	j	80003212 <end_op+0x42>

00000000800032fa <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800032fa:	1101                	addi	sp,sp,-32
    800032fc:	ec06                	sd	ra,24(sp)
    800032fe:	e822                	sd	s0,16(sp)
    80003300:	e426                	sd	s1,8(sp)
    80003302:	1000                	addi	s0,sp,32
    80003304:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003306:	00014517          	auipc	a0,0x14
    8000330a:	6ba50513          	addi	a0,a0,1722 # 800179c0 <log>
    8000330e:	72e020ef          	jal	80005a3c <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003312:	00014617          	auipc	a2,0x14
    80003316:	6da62603          	lw	a2,1754(a2) # 800179ec <log+0x2c>
    8000331a:	47f5                	li	a5,29
    8000331c:	06c7c463          	blt	a5,a2,80003384 <log_write+0x8a>
    80003320:	00014797          	auipc	a5,0x14
    80003324:	6bc7a783          	lw	a5,1724(a5) # 800179dc <log+0x1c>
    80003328:	37fd                	addiw	a5,a5,-1
    8000332a:	04f65d63          	bge	a2,a5,80003384 <log_write+0x8a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000332e:	00014797          	auipc	a5,0x14
    80003332:	6b27a783          	lw	a5,1714(a5) # 800179e0 <log+0x20>
    80003336:	04f05d63          	blez	a5,80003390 <log_write+0x96>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    8000333a:	4781                	li	a5,0
    8000333c:	06c05063          	blez	a2,8000339c <log_write+0xa2>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003340:	44cc                	lw	a1,12(s1)
    80003342:	00014717          	auipc	a4,0x14
    80003346:	6ae70713          	addi	a4,a4,1710 # 800179f0 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    8000334a:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000334c:	4314                	lw	a3,0(a4)
    8000334e:	04b68763          	beq	a3,a1,8000339c <log_write+0xa2>
  for (i = 0; i < log.lh.n; i++) {
    80003352:	2785                	addiw	a5,a5,1
    80003354:	0711                	addi	a4,a4,4
    80003356:	fef61be3          	bne	a2,a5,8000334c <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    8000335a:	060a                	slli	a2,a2,0x2
    8000335c:	02060613          	addi	a2,a2,32
    80003360:	00014797          	auipc	a5,0x14
    80003364:	66078793          	addi	a5,a5,1632 # 800179c0 <log>
    80003368:	97b2                	add	a5,a5,a2
    8000336a:	44d8                	lw	a4,12(s1)
    8000336c:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    8000336e:	8526                	mv	a0,s1
    80003370:	fc3fe0ef          	jal	80002332 <bpin>
    log.lh.n++;
    80003374:	00014717          	auipc	a4,0x14
    80003378:	64c70713          	addi	a4,a4,1612 # 800179c0 <log>
    8000337c:	575c                	lw	a5,44(a4)
    8000337e:	2785                	addiw	a5,a5,1
    80003380:	d75c                	sw	a5,44(a4)
    80003382:	a815                	j	800033b6 <log_write+0xbc>
    panic("too big a transaction");
    80003384:	00004517          	auipc	a0,0x4
    80003388:	24450513          	addi	a0,a0,580 # 800075c8 <etext+0x5c8>
    8000338c:	372020ef          	jal	800056fe <panic>
    panic("log_write outside of trans");
    80003390:	00004517          	auipc	a0,0x4
    80003394:	25050513          	addi	a0,a0,592 # 800075e0 <etext+0x5e0>
    80003398:	366020ef          	jal	800056fe <panic>
  log.lh.block[i] = b->blockno;
    8000339c:	00279693          	slli	a3,a5,0x2
    800033a0:	02068693          	addi	a3,a3,32
    800033a4:	00014717          	auipc	a4,0x14
    800033a8:	61c70713          	addi	a4,a4,1564 # 800179c0 <log>
    800033ac:	9736                	add	a4,a4,a3
    800033ae:	44d4                	lw	a3,12(s1)
    800033b0:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    800033b2:	faf60ee3          	beq	a2,a5,8000336e <log_write+0x74>
  }
  release(&log.lock);
    800033b6:	00014517          	auipc	a0,0x14
    800033ba:	60a50513          	addi	a0,a0,1546 # 800179c0 <log>
    800033be:	712020ef          	jal	80005ad0 <release>
}
    800033c2:	60e2                	ld	ra,24(sp)
    800033c4:	6442                	ld	s0,16(sp)
    800033c6:	64a2                	ld	s1,8(sp)
    800033c8:	6105                	addi	sp,sp,32
    800033ca:	8082                	ret

00000000800033cc <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800033cc:	1101                	addi	sp,sp,-32
    800033ce:	ec06                	sd	ra,24(sp)
    800033d0:	e822                	sd	s0,16(sp)
    800033d2:	e426                	sd	s1,8(sp)
    800033d4:	e04a                	sd	s2,0(sp)
    800033d6:	1000                	addi	s0,sp,32
    800033d8:	84aa                	mv	s1,a0
    800033da:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800033dc:	00004597          	auipc	a1,0x4
    800033e0:	22458593          	addi	a1,a1,548 # 80007600 <etext+0x600>
    800033e4:	0521                	addi	a0,a0,8
    800033e6:	5cc020ef          	jal	800059b2 <initlock>
  lk->name = name;
    800033ea:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800033ee:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800033f2:	0204a423          	sw	zero,40(s1)
}
    800033f6:	60e2                	ld	ra,24(sp)
    800033f8:	6442                	ld	s0,16(sp)
    800033fa:	64a2                	ld	s1,8(sp)
    800033fc:	6902                	ld	s2,0(sp)
    800033fe:	6105                	addi	sp,sp,32
    80003400:	8082                	ret

0000000080003402 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003402:	1101                	addi	sp,sp,-32
    80003404:	ec06                	sd	ra,24(sp)
    80003406:	e822                	sd	s0,16(sp)
    80003408:	e426                	sd	s1,8(sp)
    8000340a:	e04a                	sd	s2,0(sp)
    8000340c:	1000                	addi	s0,sp,32
    8000340e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003410:	00850913          	addi	s2,a0,8
    80003414:	854a                	mv	a0,s2
    80003416:	626020ef          	jal	80005a3c <acquire>
  while (lk->locked) {
    8000341a:	409c                	lw	a5,0(s1)
    8000341c:	c799                	beqz	a5,8000342a <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    8000341e:	85ca                	mv	a1,s2
    80003420:	8526                	mv	a0,s1
    80003422:	98efe0ef          	jal	800015b0 <sleep>
  while (lk->locked) {
    80003426:	409c                	lw	a5,0(s1)
    80003428:	fbfd                	bnez	a5,8000341e <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000342a:	4785                	li	a5,1
    8000342c:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    8000342e:	bb1fd0ef          	jal	80000fde <myproc>
    80003432:	591c                	lw	a5,48(a0)
    80003434:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003436:	854a                	mv	a0,s2
    80003438:	698020ef          	jal	80005ad0 <release>
}
    8000343c:	60e2                	ld	ra,24(sp)
    8000343e:	6442                	ld	s0,16(sp)
    80003440:	64a2                	ld	s1,8(sp)
    80003442:	6902                	ld	s2,0(sp)
    80003444:	6105                	addi	sp,sp,32
    80003446:	8082                	ret

0000000080003448 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003448:	1101                	addi	sp,sp,-32
    8000344a:	ec06                	sd	ra,24(sp)
    8000344c:	e822                	sd	s0,16(sp)
    8000344e:	e426                	sd	s1,8(sp)
    80003450:	e04a                	sd	s2,0(sp)
    80003452:	1000                	addi	s0,sp,32
    80003454:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003456:	00850913          	addi	s2,a0,8
    8000345a:	854a                	mv	a0,s2
    8000345c:	5e0020ef          	jal	80005a3c <acquire>
  lk->locked = 0;
    80003460:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003464:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003468:	8526                	mv	a0,s1
    8000346a:	992fe0ef          	jal	800015fc <wakeup>
  release(&lk->lk);
    8000346e:	854a                	mv	a0,s2
    80003470:	660020ef          	jal	80005ad0 <release>
}
    80003474:	60e2                	ld	ra,24(sp)
    80003476:	6442                	ld	s0,16(sp)
    80003478:	64a2                	ld	s1,8(sp)
    8000347a:	6902                	ld	s2,0(sp)
    8000347c:	6105                	addi	sp,sp,32
    8000347e:	8082                	ret

0000000080003480 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003480:	7179                	addi	sp,sp,-48
    80003482:	f406                	sd	ra,40(sp)
    80003484:	f022                	sd	s0,32(sp)
    80003486:	ec26                	sd	s1,24(sp)
    80003488:	e84a                	sd	s2,16(sp)
    8000348a:	1800                	addi	s0,sp,48
    8000348c:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000348e:	00850913          	addi	s2,a0,8
    80003492:	854a                	mv	a0,s2
    80003494:	5a8020ef          	jal	80005a3c <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003498:	409c                	lw	a5,0(s1)
    8000349a:	ef81                	bnez	a5,800034b2 <holdingsleep+0x32>
    8000349c:	4481                	li	s1,0
  release(&lk->lk);
    8000349e:	854a                	mv	a0,s2
    800034a0:	630020ef          	jal	80005ad0 <release>
  return r;
}
    800034a4:	8526                	mv	a0,s1
    800034a6:	70a2                	ld	ra,40(sp)
    800034a8:	7402                	ld	s0,32(sp)
    800034aa:	64e2                	ld	s1,24(sp)
    800034ac:	6942                	ld	s2,16(sp)
    800034ae:	6145                	addi	sp,sp,48
    800034b0:	8082                	ret
    800034b2:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800034b4:	0284a983          	lw	s3,40(s1)
    800034b8:	b27fd0ef          	jal	80000fde <myproc>
    800034bc:	5904                	lw	s1,48(a0)
    800034be:	413484b3          	sub	s1,s1,s3
    800034c2:	0014b493          	seqz	s1,s1
    800034c6:	69a2                	ld	s3,8(sp)
    800034c8:	bfd9                	j	8000349e <holdingsleep+0x1e>

00000000800034ca <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800034ca:	1141                	addi	sp,sp,-16
    800034cc:	e406                	sd	ra,8(sp)
    800034ce:	e022                	sd	s0,0(sp)
    800034d0:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800034d2:	00004597          	auipc	a1,0x4
    800034d6:	13e58593          	addi	a1,a1,318 # 80007610 <etext+0x610>
    800034da:	00014517          	auipc	a0,0x14
    800034de:	62e50513          	addi	a0,a0,1582 # 80017b08 <ftable>
    800034e2:	4d0020ef          	jal	800059b2 <initlock>
}
    800034e6:	60a2                	ld	ra,8(sp)
    800034e8:	6402                	ld	s0,0(sp)
    800034ea:	0141                	addi	sp,sp,16
    800034ec:	8082                	ret

00000000800034ee <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    800034ee:	1101                	addi	sp,sp,-32
    800034f0:	ec06                	sd	ra,24(sp)
    800034f2:	e822                	sd	s0,16(sp)
    800034f4:	e426                	sd	s1,8(sp)
    800034f6:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800034f8:	00014517          	auipc	a0,0x14
    800034fc:	61050513          	addi	a0,a0,1552 # 80017b08 <ftable>
    80003500:	53c020ef          	jal	80005a3c <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003504:	00014497          	auipc	s1,0x14
    80003508:	61c48493          	addi	s1,s1,1564 # 80017b20 <ftable+0x18>
    8000350c:	00015717          	auipc	a4,0x15
    80003510:	5b470713          	addi	a4,a4,1460 # 80018ac0 <disk>
    if(f->ref == 0){
    80003514:	40dc                	lw	a5,4(s1)
    80003516:	cf89                	beqz	a5,80003530 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003518:	02848493          	addi	s1,s1,40
    8000351c:	fee49ce3          	bne	s1,a4,80003514 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003520:	00014517          	auipc	a0,0x14
    80003524:	5e850513          	addi	a0,a0,1512 # 80017b08 <ftable>
    80003528:	5a8020ef          	jal	80005ad0 <release>
  return 0;
    8000352c:	4481                	li	s1,0
    8000352e:	a809                	j	80003540 <filealloc+0x52>
      f->ref = 1;
    80003530:	4785                	li	a5,1
    80003532:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003534:	00014517          	auipc	a0,0x14
    80003538:	5d450513          	addi	a0,a0,1492 # 80017b08 <ftable>
    8000353c:	594020ef          	jal	80005ad0 <release>
}
    80003540:	8526                	mv	a0,s1
    80003542:	60e2                	ld	ra,24(sp)
    80003544:	6442                	ld	s0,16(sp)
    80003546:	64a2                	ld	s1,8(sp)
    80003548:	6105                	addi	sp,sp,32
    8000354a:	8082                	ret

000000008000354c <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    8000354c:	1101                	addi	sp,sp,-32
    8000354e:	ec06                	sd	ra,24(sp)
    80003550:	e822                	sd	s0,16(sp)
    80003552:	e426                	sd	s1,8(sp)
    80003554:	1000                	addi	s0,sp,32
    80003556:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003558:	00014517          	auipc	a0,0x14
    8000355c:	5b050513          	addi	a0,a0,1456 # 80017b08 <ftable>
    80003560:	4dc020ef          	jal	80005a3c <acquire>
  if(f->ref < 1)
    80003564:	40dc                	lw	a5,4(s1)
    80003566:	02f05063          	blez	a5,80003586 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000356a:	2785                	addiw	a5,a5,1
    8000356c:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000356e:	00014517          	auipc	a0,0x14
    80003572:	59a50513          	addi	a0,a0,1434 # 80017b08 <ftable>
    80003576:	55a020ef          	jal	80005ad0 <release>
  return f;
}
    8000357a:	8526                	mv	a0,s1
    8000357c:	60e2                	ld	ra,24(sp)
    8000357e:	6442                	ld	s0,16(sp)
    80003580:	64a2                	ld	s1,8(sp)
    80003582:	6105                	addi	sp,sp,32
    80003584:	8082                	ret
    panic("filedup");
    80003586:	00004517          	auipc	a0,0x4
    8000358a:	09250513          	addi	a0,a0,146 # 80007618 <etext+0x618>
    8000358e:	170020ef          	jal	800056fe <panic>

0000000080003592 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003592:	7139                	addi	sp,sp,-64
    80003594:	fc06                	sd	ra,56(sp)
    80003596:	f822                	sd	s0,48(sp)
    80003598:	f426                	sd	s1,40(sp)
    8000359a:	0080                	addi	s0,sp,64
    8000359c:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    8000359e:	00014517          	auipc	a0,0x14
    800035a2:	56a50513          	addi	a0,a0,1386 # 80017b08 <ftable>
    800035a6:	496020ef          	jal	80005a3c <acquire>
  if(f->ref < 1)
    800035aa:	40dc                	lw	a5,4(s1)
    800035ac:	04f05a63          	blez	a5,80003600 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    800035b0:	37fd                	addiw	a5,a5,-1
    800035b2:	c0dc                	sw	a5,4(s1)
    800035b4:	06f04063          	bgtz	a5,80003614 <fileclose+0x82>
    800035b8:	f04a                	sd	s2,32(sp)
    800035ba:	ec4e                	sd	s3,24(sp)
    800035bc:	e852                	sd	s4,16(sp)
    800035be:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800035c0:	0004a903          	lw	s2,0(s1)
    800035c4:	0094c783          	lbu	a5,9(s1)
    800035c8:	89be                	mv	s3,a5
    800035ca:	689c                	ld	a5,16(s1)
    800035cc:	8a3e                	mv	s4,a5
    800035ce:	6c9c                	ld	a5,24(s1)
    800035d0:	8abe                	mv	s5,a5
  f->ref = 0;
    800035d2:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800035d6:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800035da:	00014517          	auipc	a0,0x14
    800035de:	52e50513          	addi	a0,a0,1326 # 80017b08 <ftable>
    800035e2:	4ee020ef          	jal	80005ad0 <release>

  if(ff.type == FD_PIPE){
    800035e6:	4785                	li	a5,1
    800035e8:	04f90163          	beq	s2,a5,8000362a <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800035ec:	ffe9079b          	addiw	a5,s2,-2
    800035f0:	4705                	li	a4,1
    800035f2:	04f77563          	bgeu	a4,a5,8000363c <fileclose+0xaa>
    800035f6:	7902                	ld	s2,32(sp)
    800035f8:	69e2                	ld	s3,24(sp)
    800035fa:	6a42                	ld	s4,16(sp)
    800035fc:	6aa2                	ld	s5,8(sp)
    800035fe:	a00d                	j	80003620 <fileclose+0x8e>
    80003600:	f04a                	sd	s2,32(sp)
    80003602:	ec4e                	sd	s3,24(sp)
    80003604:	e852                	sd	s4,16(sp)
    80003606:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80003608:	00004517          	auipc	a0,0x4
    8000360c:	01850513          	addi	a0,a0,24 # 80007620 <etext+0x620>
    80003610:	0ee020ef          	jal	800056fe <panic>
    release(&ftable.lock);
    80003614:	00014517          	auipc	a0,0x14
    80003618:	4f450513          	addi	a0,a0,1268 # 80017b08 <ftable>
    8000361c:	4b4020ef          	jal	80005ad0 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80003620:	70e2                	ld	ra,56(sp)
    80003622:	7442                	ld	s0,48(sp)
    80003624:	74a2                	ld	s1,40(sp)
    80003626:	6121                	addi	sp,sp,64
    80003628:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    8000362a:	85ce                	mv	a1,s3
    8000362c:	8552                	mv	a0,s4
    8000362e:	348000ef          	jal	80003976 <pipeclose>
    80003632:	7902                	ld	s2,32(sp)
    80003634:	69e2                	ld	s3,24(sp)
    80003636:	6a42                	ld	s4,16(sp)
    80003638:	6aa2                	ld	s5,8(sp)
    8000363a:	b7dd                	j	80003620 <fileclose+0x8e>
    begin_op();
    8000363c:	b25ff0ef          	jal	80003160 <begin_op>
    iput(ff.ip);
    80003640:	8556                	mv	a0,s5
    80003642:	be8ff0ef          	jal	80002a2a <iput>
    end_op();
    80003646:	b8bff0ef          	jal	800031d0 <end_op>
    8000364a:	7902                	ld	s2,32(sp)
    8000364c:	69e2                	ld	s3,24(sp)
    8000364e:	6a42                	ld	s4,16(sp)
    80003650:	6aa2                	ld	s5,8(sp)
    80003652:	b7f9                	j	80003620 <fileclose+0x8e>

0000000080003654 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80003654:	715d                	addi	sp,sp,-80
    80003656:	e486                	sd	ra,72(sp)
    80003658:	e0a2                	sd	s0,64(sp)
    8000365a:	fc26                	sd	s1,56(sp)
    8000365c:	f052                	sd	s4,32(sp)
    8000365e:	0880                	addi	s0,sp,80
    80003660:	84aa                	mv	s1,a0
    80003662:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80003664:	97bfd0ef          	jal	80000fde <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003668:	409c                	lw	a5,0(s1)
    8000366a:	37f9                	addiw	a5,a5,-2
    8000366c:	4705                	li	a4,1
    8000366e:	04f76263          	bltu	a4,a5,800036b2 <filestat+0x5e>
    80003672:	f84a                	sd	s2,48(sp)
    80003674:	f44e                	sd	s3,40(sp)
    80003676:	89aa                	mv	s3,a0
    ilock(f->ip);
    80003678:	6c88                	ld	a0,24(s1)
    8000367a:	a2eff0ef          	jal	800028a8 <ilock>
    stati(f->ip, &st);
    8000367e:	fb840913          	addi	s2,s0,-72
    80003682:	85ca                	mv	a1,s2
    80003684:	6c88                	ld	a0,24(s1)
    80003686:	c4eff0ef          	jal	80002ad4 <stati>
    iunlock(f->ip);
    8000368a:	6c88                	ld	a0,24(s1)
    8000368c:	acaff0ef          	jal	80002956 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003690:	46e1                	li	a3,24
    80003692:	864a                	mv	a2,s2
    80003694:	85d2                	mv	a1,s4
    80003696:	0509b503          	ld	a0,80(s3)
    8000369a:	c3afd0ef          	jal	80000ad4 <copyout>
    8000369e:	41f5551b          	sraiw	a0,a0,0x1f
    800036a2:	7942                	ld	s2,48(sp)
    800036a4:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800036a6:	60a6                	ld	ra,72(sp)
    800036a8:	6406                	ld	s0,64(sp)
    800036aa:	74e2                	ld	s1,56(sp)
    800036ac:	7a02                	ld	s4,32(sp)
    800036ae:	6161                	addi	sp,sp,80
    800036b0:	8082                	ret
  return -1;
    800036b2:	557d                	li	a0,-1
    800036b4:	bfcd                	j	800036a6 <filestat+0x52>

00000000800036b6 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800036b6:	7179                	addi	sp,sp,-48
    800036b8:	f406                	sd	ra,40(sp)
    800036ba:	f022                	sd	s0,32(sp)
    800036bc:	e84a                	sd	s2,16(sp)
    800036be:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800036c0:	00854783          	lbu	a5,8(a0)
    800036c4:	cfd1                	beqz	a5,80003760 <fileread+0xaa>
    800036c6:	ec26                	sd	s1,24(sp)
    800036c8:	e44e                	sd	s3,8(sp)
    800036ca:	84aa                	mv	s1,a0
    800036cc:	892e                	mv	s2,a1
    800036ce:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    800036d0:	411c                	lw	a5,0(a0)
    800036d2:	4705                	li	a4,1
    800036d4:	04e78363          	beq	a5,a4,8000371a <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800036d8:	470d                	li	a4,3
    800036da:	04e78763          	beq	a5,a4,80003728 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800036de:	4709                	li	a4,2
    800036e0:	06e79a63          	bne	a5,a4,80003754 <fileread+0x9e>
    ilock(f->ip);
    800036e4:	6d08                	ld	a0,24(a0)
    800036e6:	9c2ff0ef          	jal	800028a8 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800036ea:	874e                	mv	a4,s3
    800036ec:	5094                	lw	a3,32(s1)
    800036ee:	864a                	mv	a2,s2
    800036f0:	4585                	li	a1,1
    800036f2:	6c88                	ld	a0,24(s1)
    800036f4:	c0eff0ef          	jal	80002b02 <readi>
    800036f8:	892a                	mv	s2,a0
    800036fa:	00a05563          	blez	a0,80003704 <fileread+0x4e>
      f->off += r;
    800036fe:	509c                	lw	a5,32(s1)
    80003700:	9fa9                	addw	a5,a5,a0
    80003702:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80003704:	6c88                	ld	a0,24(s1)
    80003706:	a50ff0ef          	jal	80002956 <iunlock>
    8000370a:	64e2                	ld	s1,24(sp)
    8000370c:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000370e:	854a                	mv	a0,s2
    80003710:	70a2                	ld	ra,40(sp)
    80003712:	7402                	ld	s0,32(sp)
    80003714:	6942                	ld	s2,16(sp)
    80003716:	6145                	addi	sp,sp,48
    80003718:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000371a:	6908                	ld	a0,16(a0)
    8000371c:	3b0000ef          	jal	80003acc <piperead>
    80003720:	892a                	mv	s2,a0
    80003722:	64e2                	ld	s1,24(sp)
    80003724:	69a2                	ld	s3,8(sp)
    80003726:	b7e5                	j	8000370e <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80003728:	02451783          	lh	a5,36(a0)
    8000372c:	03079693          	slli	a3,a5,0x30
    80003730:	92c1                	srli	a3,a3,0x30
    80003732:	4725                	li	a4,9
    80003734:	02d76963          	bltu	a4,a3,80003766 <fileread+0xb0>
    80003738:	0792                	slli	a5,a5,0x4
    8000373a:	00014717          	auipc	a4,0x14
    8000373e:	32e70713          	addi	a4,a4,814 # 80017a68 <devsw>
    80003742:	97ba                	add	a5,a5,a4
    80003744:	639c                	ld	a5,0(a5)
    80003746:	c78d                	beqz	a5,80003770 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80003748:	4505                	li	a0,1
    8000374a:	9782                	jalr	a5
    8000374c:	892a                	mv	s2,a0
    8000374e:	64e2                	ld	s1,24(sp)
    80003750:	69a2                	ld	s3,8(sp)
    80003752:	bf75                	j	8000370e <fileread+0x58>
    panic("fileread");
    80003754:	00004517          	auipc	a0,0x4
    80003758:	edc50513          	addi	a0,a0,-292 # 80007630 <etext+0x630>
    8000375c:	7a3010ef          	jal	800056fe <panic>
    return -1;
    80003760:	57fd                	li	a5,-1
    80003762:	893e                	mv	s2,a5
    80003764:	b76d                	j	8000370e <fileread+0x58>
      return -1;
    80003766:	57fd                	li	a5,-1
    80003768:	893e                	mv	s2,a5
    8000376a:	64e2                	ld	s1,24(sp)
    8000376c:	69a2                	ld	s3,8(sp)
    8000376e:	b745                	j	8000370e <fileread+0x58>
    80003770:	57fd                	li	a5,-1
    80003772:	893e                	mv	s2,a5
    80003774:	64e2                	ld	s1,24(sp)
    80003776:	69a2                	ld	s3,8(sp)
    80003778:	bf59                	j	8000370e <fileread+0x58>

000000008000377a <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    8000377a:	00954783          	lbu	a5,9(a0)
    8000377e:	10078f63          	beqz	a5,8000389c <filewrite+0x122>
{
    80003782:	711d                	addi	sp,sp,-96
    80003784:	ec86                	sd	ra,88(sp)
    80003786:	e8a2                	sd	s0,80(sp)
    80003788:	e0ca                	sd	s2,64(sp)
    8000378a:	f456                	sd	s5,40(sp)
    8000378c:	f05a                	sd	s6,32(sp)
    8000378e:	1080                	addi	s0,sp,96
    80003790:	892a                	mv	s2,a0
    80003792:	8b2e                	mv	s6,a1
    80003794:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    80003796:	411c                	lw	a5,0(a0)
    80003798:	4705                	li	a4,1
    8000379a:	02e78a63          	beq	a5,a4,800037ce <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000379e:	470d                	li	a4,3
    800037a0:	02e78b63          	beq	a5,a4,800037d6 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800037a4:	4709                	li	a4,2
    800037a6:	0ce79f63          	bne	a5,a4,80003884 <filewrite+0x10a>
    800037aa:	f852                	sd	s4,48(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800037ac:	0ac05a63          	blez	a2,80003860 <filewrite+0xe6>
    800037b0:	e4a6                	sd	s1,72(sp)
    800037b2:	fc4e                	sd	s3,56(sp)
    800037b4:	ec5e                	sd	s7,24(sp)
    800037b6:	e862                	sd	s8,16(sp)
    800037b8:	e466                	sd	s9,8(sp)
    int i = 0;
    800037ba:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    800037bc:	6b85                	lui	s7,0x1
    800037be:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800037c2:	6785                	lui	a5,0x1
    800037c4:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800037c8:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800037ca:	4c05                	li	s8,1
    800037cc:	a8ad                	j	80003846 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800037ce:	6908                	ld	a0,16(a0)
    800037d0:	204000ef          	jal	800039d4 <pipewrite>
    800037d4:	a04d                	j	80003876 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800037d6:	02451783          	lh	a5,36(a0)
    800037da:	03079693          	slli	a3,a5,0x30
    800037de:	92c1                	srli	a3,a3,0x30
    800037e0:	4725                	li	a4,9
    800037e2:	0ad76f63          	bltu	a4,a3,800038a0 <filewrite+0x126>
    800037e6:	0792                	slli	a5,a5,0x4
    800037e8:	00014717          	auipc	a4,0x14
    800037ec:	28070713          	addi	a4,a4,640 # 80017a68 <devsw>
    800037f0:	97ba                	add	a5,a5,a4
    800037f2:	679c                	ld	a5,8(a5)
    800037f4:	cbc5                	beqz	a5,800038a4 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    800037f6:	4505                	li	a0,1
    800037f8:	9782                	jalr	a5
    800037fa:	a8b5                	j	80003876 <filewrite+0xfc>
      if(n1 > max)
    800037fc:	2981                	sext.w	s3,s3
      begin_op();
    800037fe:	963ff0ef          	jal	80003160 <begin_op>
      ilock(f->ip);
    80003802:	01893503          	ld	a0,24(s2)
    80003806:	8a2ff0ef          	jal	800028a8 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000380a:	874e                	mv	a4,s3
    8000380c:	02092683          	lw	a3,32(s2)
    80003810:	016a0633          	add	a2,s4,s6
    80003814:	85e2                	mv	a1,s8
    80003816:	01893503          	ld	a0,24(s2)
    8000381a:	bdaff0ef          	jal	80002bf4 <writei>
    8000381e:	84aa                	mv	s1,a0
    80003820:	00a05763          	blez	a0,8000382e <filewrite+0xb4>
        f->off += r;
    80003824:	02092783          	lw	a5,32(s2)
    80003828:	9fa9                	addw	a5,a5,a0
    8000382a:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000382e:	01893503          	ld	a0,24(s2)
    80003832:	924ff0ef          	jal	80002956 <iunlock>
      end_op();
    80003836:	99bff0ef          	jal	800031d0 <end_op>

      if(r != n1){
    8000383a:	02999563          	bne	s3,s1,80003864 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    8000383e:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80003842:	015a5963          	bge	s4,s5,80003854 <filewrite+0xda>
      int n1 = n - i;
    80003846:	414a87bb          	subw	a5,s5,s4
    8000384a:	89be                	mv	s3,a5
      if(n1 > max)
    8000384c:	fafbd8e3          	bge	s7,a5,800037fc <filewrite+0x82>
    80003850:	89e6                	mv	s3,s9
    80003852:	b76d                	j	800037fc <filewrite+0x82>
    80003854:	64a6                	ld	s1,72(sp)
    80003856:	79e2                	ld	s3,56(sp)
    80003858:	6be2                	ld	s7,24(sp)
    8000385a:	6c42                	ld	s8,16(sp)
    8000385c:	6ca2                	ld	s9,8(sp)
    8000385e:	a801                	j	8000386e <filewrite+0xf4>
    int i = 0;
    80003860:	4a01                	li	s4,0
    80003862:	a031                	j	8000386e <filewrite+0xf4>
    80003864:	64a6                	ld	s1,72(sp)
    80003866:	79e2                	ld	s3,56(sp)
    80003868:	6be2                	ld	s7,24(sp)
    8000386a:	6c42                	ld	s8,16(sp)
    8000386c:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    8000386e:	034a9d63          	bne	s5,s4,800038a8 <filewrite+0x12e>
    80003872:	8556                	mv	a0,s5
    80003874:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80003876:	60e6                	ld	ra,88(sp)
    80003878:	6446                	ld	s0,80(sp)
    8000387a:	6906                	ld	s2,64(sp)
    8000387c:	7aa2                	ld	s5,40(sp)
    8000387e:	7b02                	ld	s6,32(sp)
    80003880:	6125                	addi	sp,sp,96
    80003882:	8082                	ret
    80003884:	e4a6                	sd	s1,72(sp)
    80003886:	fc4e                	sd	s3,56(sp)
    80003888:	f852                	sd	s4,48(sp)
    8000388a:	ec5e                	sd	s7,24(sp)
    8000388c:	e862                	sd	s8,16(sp)
    8000388e:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80003890:	00004517          	auipc	a0,0x4
    80003894:	db050513          	addi	a0,a0,-592 # 80007640 <etext+0x640>
    80003898:	667010ef          	jal	800056fe <panic>
    return -1;
    8000389c:	557d                	li	a0,-1
}
    8000389e:	8082                	ret
      return -1;
    800038a0:	557d                	li	a0,-1
    800038a2:	bfd1                	j	80003876 <filewrite+0xfc>
    800038a4:	557d                	li	a0,-1
    800038a6:	bfc1                	j	80003876 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    800038a8:	557d                	li	a0,-1
    800038aa:	7a42                	ld	s4,48(sp)
    800038ac:	b7e9                	j	80003876 <filewrite+0xfc>

00000000800038ae <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800038ae:	7179                	addi	sp,sp,-48
    800038b0:	f406                	sd	ra,40(sp)
    800038b2:	f022                	sd	s0,32(sp)
    800038b4:	ec26                	sd	s1,24(sp)
    800038b6:	e052                	sd	s4,0(sp)
    800038b8:	1800                	addi	s0,sp,48
    800038ba:	84aa                	mv	s1,a0
    800038bc:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800038be:	0005b023          	sd	zero,0(a1)
    800038c2:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800038c6:	c29ff0ef          	jal	800034ee <filealloc>
    800038ca:	e088                	sd	a0,0(s1)
    800038cc:	c549                	beqz	a0,80003956 <pipealloc+0xa8>
    800038ce:	c21ff0ef          	jal	800034ee <filealloc>
    800038d2:	00aa3023          	sd	a0,0(s4)
    800038d6:	cd25                	beqz	a0,8000394e <pipealloc+0xa0>
    800038d8:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800038da:	86dfc0ef          	jal	80000146 <kalloc>
    800038de:	892a                	mv	s2,a0
    800038e0:	c12d                	beqz	a0,80003942 <pipealloc+0x94>
    800038e2:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800038e4:	4985                	li	s3,1
    800038e6:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800038ea:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800038ee:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800038f2:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800038f6:	00004597          	auipc	a1,0x4
    800038fa:	d5a58593          	addi	a1,a1,-678 # 80007650 <etext+0x650>
    800038fe:	0b4020ef          	jal	800059b2 <initlock>
  (*f0)->type = FD_PIPE;
    80003902:	609c                	ld	a5,0(s1)
    80003904:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80003908:	609c                	ld	a5,0(s1)
    8000390a:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000390e:	609c                	ld	a5,0(s1)
    80003910:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80003914:	609c                	ld	a5,0(s1)
    80003916:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    8000391a:	000a3783          	ld	a5,0(s4)
    8000391e:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80003922:	000a3783          	ld	a5,0(s4)
    80003926:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    8000392a:	000a3783          	ld	a5,0(s4)
    8000392e:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80003932:	000a3783          	ld	a5,0(s4)
    80003936:	0127b823          	sd	s2,16(a5)
  return 0;
    8000393a:	4501                	li	a0,0
    8000393c:	6942                	ld	s2,16(sp)
    8000393e:	69a2                	ld	s3,8(sp)
    80003940:	a01d                	j	80003966 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80003942:	6088                	ld	a0,0(s1)
    80003944:	c119                	beqz	a0,8000394a <pipealloc+0x9c>
    80003946:	6942                	ld	s2,16(sp)
    80003948:	a029                	j	80003952 <pipealloc+0xa4>
    8000394a:	6942                	ld	s2,16(sp)
    8000394c:	a029                	j	80003956 <pipealloc+0xa8>
    8000394e:	6088                	ld	a0,0(s1)
    80003950:	c10d                	beqz	a0,80003972 <pipealloc+0xc4>
    fileclose(*f0);
    80003952:	c41ff0ef          	jal	80003592 <fileclose>
  if(*f1)
    80003956:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    8000395a:	557d                	li	a0,-1
  if(*f1)
    8000395c:	c789                	beqz	a5,80003966 <pipealloc+0xb8>
    fileclose(*f1);
    8000395e:	853e                	mv	a0,a5
    80003960:	c33ff0ef          	jal	80003592 <fileclose>
  return -1;
    80003964:	557d                	li	a0,-1
}
    80003966:	70a2                	ld	ra,40(sp)
    80003968:	7402                	ld	s0,32(sp)
    8000396a:	64e2                	ld	s1,24(sp)
    8000396c:	6a02                	ld	s4,0(sp)
    8000396e:	6145                	addi	sp,sp,48
    80003970:	8082                	ret
  return -1;
    80003972:	557d                	li	a0,-1
    80003974:	bfcd                	j	80003966 <pipealloc+0xb8>

0000000080003976 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80003976:	1101                	addi	sp,sp,-32
    80003978:	ec06                	sd	ra,24(sp)
    8000397a:	e822                	sd	s0,16(sp)
    8000397c:	e426                	sd	s1,8(sp)
    8000397e:	e04a                	sd	s2,0(sp)
    80003980:	1000                	addi	s0,sp,32
    80003982:	84aa                	mv	s1,a0
    80003984:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80003986:	0b6020ef          	jal	80005a3c <acquire>
  if(writable){
    8000398a:	02090763          	beqz	s2,800039b8 <pipeclose+0x42>
    pi->writeopen = 0;
    8000398e:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80003992:	21848513          	addi	a0,s1,536
    80003996:	c67fd0ef          	jal	800015fc <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    8000399a:	2204a783          	lw	a5,544(s1)
    8000399e:	e781                	bnez	a5,800039a6 <pipeclose+0x30>
    800039a0:	2244a783          	lw	a5,548(s1)
    800039a4:	c38d                	beqz	a5,800039c6 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    800039a6:	8526                	mv	a0,s1
    800039a8:	128020ef          	jal	80005ad0 <release>
}
    800039ac:	60e2                	ld	ra,24(sp)
    800039ae:	6442                	ld	s0,16(sp)
    800039b0:	64a2                	ld	s1,8(sp)
    800039b2:	6902                	ld	s2,0(sp)
    800039b4:	6105                	addi	sp,sp,32
    800039b6:	8082                	ret
    pi->readopen = 0;
    800039b8:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800039bc:	21c48513          	addi	a0,s1,540
    800039c0:	c3dfd0ef          	jal	800015fc <wakeup>
    800039c4:	bfd9                	j	8000399a <pipeclose+0x24>
    release(&pi->lock);
    800039c6:	8526                	mv	a0,s1
    800039c8:	108020ef          	jal	80005ad0 <release>
    kfree((char*)pi);
    800039cc:	8526                	mv	a0,s1
    800039ce:	e4efc0ef          	jal	8000001c <kfree>
    800039d2:	bfe9                	j	800039ac <pipeclose+0x36>

00000000800039d4 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800039d4:	7159                	addi	sp,sp,-112
    800039d6:	f486                	sd	ra,104(sp)
    800039d8:	f0a2                	sd	s0,96(sp)
    800039da:	eca6                	sd	s1,88(sp)
    800039dc:	e8ca                	sd	s2,80(sp)
    800039de:	e4ce                	sd	s3,72(sp)
    800039e0:	e0d2                	sd	s4,64(sp)
    800039e2:	fc56                	sd	s5,56(sp)
    800039e4:	1880                	addi	s0,sp,112
    800039e6:	84aa                	mv	s1,a0
    800039e8:	8aae                	mv	s5,a1
    800039ea:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800039ec:	df2fd0ef          	jal	80000fde <myproc>
    800039f0:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800039f2:	8526                	mv	a0,s1
    800039f4:	048020ef          	jal	80005a3c <acquire>
  while(i < n){
    800039f8:	0d405263          	blez	s4,80003abc <pipewrite+0xe8>
    800039fc:	f85a                	sd	s6,48(sp)
    800039fe:	f45e                	sd	s7,40(sp)
    80003a00:	f062                	sd	s8,32(sp)
    80003a02:	ec66                	sd	s9,24(sp)
    80003a04:	e86a                	sd	s10,16(sp)
  int i = 0;
    80003a06:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003a08:	f9f40c13          	addi	s8,s0,-97
    80003a0c:	4b85                	li	s7,1
    80003a0e:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80003a10:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80003a14:	21c48c93          	addi	s9,s1,540
    80003a18:	a82d                	j	80003a52 <pipewrite+0x7e>
      release(&pi->lock);
    80003a1a:	8526                	mv	a0,s1
    80003a1c:	0b4020ef          	jal	80005ad0 <release>
      return -1;
    80003a20:	597d                	li	s2,-1
    80003a22:	7b42                	ld	s6,48(sp)
    80003a24:	7ba2                	ld	s7,40(sp)
    80003a26:	7c02                	ld	s8,32(sp)
    80003a28:	6ce2                	ld	s9,24(sp)
    80003a2a:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80003a2c:	854a                	mv	a0,s2
    80003a2e:	70a6                	ld	ra,104(sp)
    80003a30:	7406                	ld	s0,96(sp)
    80003a32:	64e6                	ld	s1,88(sp)
    80003a34:	6946                	ld	s2,80(sp)
    80003a36:	69a6                	ld	s3,72(sp)
    80003a38:	6a06                	ld	s4,64(sp)
    80003a3a:	7ae2                	ld	s5,56(sp)
    80003a3c:	6165                	addi	sp,sp,112
    80003a3e:	8082                	ret
      wakeup(&pi->nread);
    80003a40:	856a                	mv	a0,s10
    80003a42:	bbbfd0ef          	jal	800015fc <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80003a46:	85a6                	mv	a1,s1
    80003a48:	8566                	mv	a0,s9
    80003a4a:	b67fd0ef          	jal	800015b0 <sleep>
  while(i < n){
    80003a4e:	05495a63          	bge	s2,s4,80003aa2 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80003a52:	2204a783          	lw	a5,544(s1)
    80003a56:	d3f1                	beqz	a5,80003a1a <pipewrite+0x46>
    80003a58:	854e                	mv	a0,s3
    80003a5a:	d93fd0ef          	jal	800017ec <killed>
    80003a5e:	fd55                	bnez	a0,80003a1a <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80003a60:	2184a783          	lw	a5,536(s1)
    80003a64:	21c4a703          	lw	a4,540(s1)
    80003a68:	2007879b          	addiw	a5,a5,512
    80003a6c:	fcf70ae3          	beq	a4,a5,80003a40 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003a70:	86de                	mv	a3,s7
    80003a72:	01590633          	add	a2,s2,s5
    80003a76:	85e2                	mv	a1,s8
    80003a78:	0509b503          	ld	a0,80(s3)
    80003a7c:	9cefd0ef          	jal	80000c4a <copyin>
    80003a80:	05650063          	beq	a0,s6,80003ac0 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80003a84:	21c4a783          	lw	a5,540(s1)
    80003a88:	0017871b          	addiw	a4,a5,1
    80003a8c:	20e4ae23          	sw	a4,540(s1)
    80003a90:	1ff7f793          	andi	a5,a5,511
    80003a94:	97a6                	add	a5,a5,s1
    80003a96:	f9f44703          	lbu	a4,-97(s0)
    80003a9a:	00e78c23          	sb	a4,24(a5)
      i++;
    80003a9e:	2905                	addiw	s2,s2,1
    80003aa0:	b77d                	j	80003a4e <pipewrite+0x7a>
    80003aa2:	7b42                	ld	s6,48(sp)
    80003aa4:	7ba2                	ld	s7,40(sp)
    80003aa6:	7c02                	ld	s8,32(sp)
    80003aa8:	6ce2                	ld	s9,24(sp)
    80003aaa:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80003aac:	21848513          	addi	a0,s1,536
    80003ab0:	b4dfd0ef          	jal	800015fc <wakeup>
  release(&pi->lock);
    80003ab4:	8526                	mv	a0,s1
    80003ab6:	01a020ef          	jal	80005ad0 <release>
  return i;
    80003aba:	bf8d                	j	80003a2c <pipewrite+0x58>
  int i = 0;
    80003abc:	4901                	li	s2,0
    80003abe:	b7fd                	j	80003aac <pipewrite+0xd8>
    80003ac0:	7b42                	ld	s6,48(sp)
    80003ac2:	7ba2                	ld	s7,40(sp)
    80003ac4:	7c02                	ld	s8,32(sp)
    80003ac6:	6ce2                	ld	s9,24(sp)
    80003ac8:	6d42                	ld	s10,16(sp)
    80003aca:	b7cd                	j	80003aac <pipewrite+0xd8>

0000000080003acc <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80003acc:	711d                	addi	sp,sp,-96
    80003ace:	ec86                	sd	ra,88(sp)
    80003ad0:	e8a2                	sd	s0,80(sp)
    80003ad2:	e4a6                	sd	s1,72(sp)
    80003ad4:	e0ca                	sd	s2,64(sp)
    80003ad6:	fc4e                	sd	s3,56(sp)
    80003ad8:	f852                	sd	s4,48(sp)
    80003ada:	f456                	sd	s5,40(sp)
    80003adc:	1080                	addi	s0,sp,96
    80003ade:	84aa                	mv	s1,a0
    80003ae0:	892e                	mv	s2,a1
    80003ae2:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80003ae4:	cfafd0ef          	jal	80000fde <myproc>
    80003ae8:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80003aea:	8526                	mv	a0,s1
    80003aec:	751010ef          	jal	80005a3c <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003af0:	2184a703          	lw	a4,536(s1)
    80003af4:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003af8:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003afc:	02f71763          	bne	a4,a5,80003b2a <piperead+0x5e>
    80003b00:	2244a783          	lw	a5,548(s1)
    80003b04:	cf85                	beqz	a5,80003b3c <piperead+0x70>
    if(killed(pr)){
    80003b06:	8552                	mv	a0,s4
    80003b08:	ce5fd0ef          	jal	800017ec <killed>
    80003b0c:	e11d                	bnez	a0,80003b32 <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003b0e:	85a6                	mv	a1,s1
    80003b10:	854e                	mv	a0,s3
    80003b12:	a9ffd0ef          	jal	800015b0 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003b16:	2184a703          	lw	a4,536(s1)
    80003b1a:	21c4a783          	lw	a5,540(s1)
    80003b1e:	fef701e3          	beq	a4,a5,80003b00 <piperead+0x34>
    80003b22:	f05a                	sd	s6,32(sp)
    80003b24:	ec5e                	sd	s7,24(sp)
    80003b26:	e862                	sd	s8,16(sp)
    80003b28:	a829                	j	80003b42 <piperead+0x76>
    80003b2a:	f05a                	sd	s6,32(sp)
    80003b2c:	ec5e                	sd	s7,24(sp)
    80003b2e:	e862                	sd	s8,16(sp)
    80003b30:	a809                	j	80003b42 <piperead+0x76>
      release(&pi->lock);
    80003b32:	8526                	mv	a0,s1
    80003b34:	79d010ef          	jal	80005ad0 <release>
      return -1;
    80003b38:	59fd                	li	s3,-1
    80003b3a:	a09d                	j	80003ba0 <piperead+0xd4>
    80003b3c:	f05a                	sd	s6,32(sp)
    80003b3e:	ec5e                	sd	s7,24(sp)
    80003b40:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003b42:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003b44:	faf40c13          	addi	s8,s0,-81
    80003b48:	4b85                	li	s7,1
    80003b4a:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003b4c:	05505063          	blez	s5,80003b8c <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    80003b50:	2184a783          	lw	a5,536(s1)
    80003b54:	21c4a703          	lw	a4,540(s1)
    80003b58:	02f70a63          	beq	a4,a5,80003b8c <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003b5c:	0017871b          	addiw	a4,a5,1
    80003b60:	20e4ac23          	sw	a4,536(s1)
    80003b64:	1ff7f793          	andi	a5,a5,511
    80003b68:	97a6                	add	a5,a5,s1
    80003b6a:	0187c783          	lbu	a5,24(a5)
    80003b6e:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003b72:	86de                	mv	a3,s7
    80003b74:	8662                	mv	a2,s8
    80003b76:	85ca                	mv	a1,s2
    80003b78:	050a3503          	ld	a0,80(s4)
    80003b7c:	f59fc0ef          	jal	80000ad4 <copyout>
    80003b80:	01650663          	beq	a0,s6,80003b8c <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003b84:	2985                	addiw	s3,s3,1
    80003b86:	0905                	addi	s2,s2,1
    80003b88:	fd3a94e3          	bne	s5,s3,80003b50 <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003b8c:	21c48513          	addi	a0,s1,540
    80003b90:	a6dfd0ef          	jal	800015fc <wakeup>
  release(&pi->lock);
    80003b94:	8526                	mv	a0,s1
    80003b96:	73b010ef          	jal	80005ad0 <release>
    80003b9a:	7b02                	ld	s6,32(sp)
    80003b9c:	6be2                	ld	s7,24(sp)
    80003b9e:	6c42                	ld	s8,16(sp)
  return i;
}
    80003ba0:	854e                	mv	a0,s3
    80003ba2:	60e6                	ld	ra,88(sp)
    80003ba4:	6446                	ld	s0,80(sp)
    80003ba6:	64a6                	ld	s1,72(sp)
    80003ba8:	6906                	ld	s2,64(sp)
    80003baa:	79e2                	ld	s3,56(sp)
    80003bac:	7a42                	ld	s4,48(sp)
    80003bae:	7aa2                	ld	s5,40(sp)
    80003bb0:	6125                	addi	sp,sp,96
    80003bb2:	8082                	ret

0000000080003bb4 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003bb4:	1141                	addi	sp,sp,-16
    80003bb6:	e406                	sd	ra,8(sp)
    80003bb8:	e022                	sd	s0,0(sp)
    80003bba:	0800                	addi	s0,sp,16
    80003bbc:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003bbe:	0035151b          	slliw	a0,a0,0x3
    80003bc2:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80003bc4:	8b89                	andi	a5,a5,2
    80003bc6:	c399                	beqz	a5,80003bcc <flags2perm+0x18>
      perm |= PTE_W;
    80003bc8:	00456513          	ori	a0,a0,4
    return perm;
}
    80003bcc:	60a2                	ld	ra,8(sp)
    80003bce:	6402                	ld	s0,0(sp)
    80003bd0:	0141                	addi	sp,sp,16
    80003bd2:	8082                	ret

0000000080003bd4 <exec>:

int
exec(char *path, char **argv)
{
    80003bd4:	de010113          	addi	sp,sp,-544
    80003bd8:	20113c23          	sd	ra,536(sp)
    80003bdc:	20813823          	sd	s0,528(sp)
    80003be0:	20913423          	sd	s1,520(sp)
    80003be4:	21213023          	sd	s2,512(sp)
    80003be8:	1400                	addi	s0,sp,544
    80003bea:	892a                	mv	s2,a0
    80003bec:	dea43823          	sd	a0,-528(s0)
    80003bf0:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80003bf4:	beafd0ef          	jal	80000fde <myproc>
    80003bf8:	84aa                	mv	s1,a0

  begin_op();
    80003bfa:	d66ff0ef          	jal	80003160 <begin_op>

  if((ip = namei(path)) == 0){
    80003bfe:	854a                	mv	a0,s2
    80003c00:	b9eff0ef          	jal	80002f9e <namei>
    80003c04:	cd21                	beqz	a0,80003c5c <exec+0x88>
    80003c06:	fbd2                	sd	s4,496(sp)
    80003c08:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80003c0a:	c9ffe0ef          	jal	800028a8 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80003c0e:	04000713          	li	a4,64
    80003c12:	4681                	li	a3,0
    80003c14:	e5040613          	addi	a2,s0,-432
    80003c18:	4581                	li	a1,0
    80003c1a:	8552                	mv	a0,s4
    80003c1c:	ee7fe0ef          	jal	80002b02 <readi>
    80003c20:	04000793          	li	a5,64
    80003c24:	00f51a63          	bne	a0,a5,80003c38 <exec+0x64>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80003c28:	e5042703          	lw	a4,-432(s0)
    80003c2c:	464c47b7          	lui	a5,0x464c4
    80003c30:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003c34:	02f70863          	beq	a4,a5,80003c64 <exec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003c38:	8552                	mv	a0,s4
    80003c3a:	e7bfe0ef          	jal	80002ab4 <iunlockput>
    end_op();
    80003c3e:	d92ff0ef          	jal	800031d0 <end_op>
  }
  return -1;
    80003c42:	557d                	li	a0,-1
    80003c44:	7a5e                	ld	s4,496(sp)
}
    80003c46:	21813083          	ld	ra,536(sp)
    80003c4a:	21013403          	ld	s0,528(sp)
    80003c4e:	20813483          	ld	s1,520(sp)
    80003c52:	20013903          	ld	s2,512(sp)
    80003c56:	22010113          	addi	sp,sp,544
    80003c5a:	8082                	ret
    end_op();
    80003c5c:	d74ff0ef          	jal	800031d0 <end_op>
    return -1;
    80003c60:	557d                	li	a0,-1
    80003c62:	b7d5                	j	80003c46 <exec+0x72>
    80003c64:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80003c66:	8526                	mv	a0,s1
    80003c68:	c20fd0ef          	jal	80001088 <proc_pagetable>
    80003c6c:	8b2a                	mv	s6,a0
    80003c6e:	26050f63          	beqz	a0,80003eec <exec+0x318>
    80003c72:	ffce                	sd	s3,504(sp)
    80003c74:	f7d6                	sd	s5,488(sp)
    80003c76:	efde                	sd	s7,472(sp)
    80003c78:	ebe2                	sd	s8,464(sp)
    80003c7a:	e7e6                	sd	s9,456(sp)
    80003c7c:	e3ea                	sd	s10,448(sp)
    80003c7e:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003c80:	e8845783          	lhu	a5,-376(s0)
    80003c84:	0e078963          	beqz	a5,80003d76 <exec+0x1a2>
    80003c88:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003c8c:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003c8e:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003c90:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80003c94:	6c85                	lui	s9,0x1
    80003c96:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80003c9a:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80003c9e:	6a85                	lui	s5,0x1
    80003ca0:	a085                	j	80003d00 <exec+0x12c>
      panic("loadseg: address should exist");
    80003ca2:	00004517          	auipc	a0,0x4
    80003ca6:	9b650513          	addi	a0,a0,-1610 # 80007658 <etext+0x658>
    80003caa:	255010ef          	jal	800056fe <panic>
    if(sz - i < PGSIZE)
    80003cae:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003cb0:	874a                	mv	a4,s2
    80003cb2:	009b86bb          	addw	a3,s7,s1
    80003cb6:	4581                	li	a1,0
    80003cb8:	8552                	mv	a0,s4
    80003cba:	e49fe0ef          	jal	80002b02 <readi>
    80003cbe:	22a91b63          	bne	s2,a0,80003ef4 <exec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    80003cc2:	009a84bb          	addw	s1,s5,s1
    80003cc6:	0334f263          	bgeu	s1,s3,80003cea <exec+0x116>
    pa = walkaddr(pagetable, va + i);
    80003cca:	02049593          	slli	a1,s1,0x20
    80003cce:	9181                	srli	a1,a1,0x20
    80003cd0:	95e2                	add	a1,a1,s8
    80003cd2:	855a                	mv	a0,s6
    80003cd4:	877fc0ef          	jal	8000054a <walkaddr>
    80003cd8:	862a                	mv	a2,a0
    if(pa == 0)
    80003cda:	d561                	beqz	a0,80003ca2 <exec+0xce>
    if(sz - i < PGSIZE)
    80003cdc:	409987bb          	subw	a5,s3,s1
    80003ce0:	893e                	mv	s2,a5
    80003ce2:	fcfcf6e3          	bgeu	s9,a5,80003cae <exec+0xda>
    80003ce6:	8956                	mv	s2,s5
    80003ce8:	b7d9                	j	80003cae <exec+0xda>
    sz = sz1;
    80003cea:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003cee:	2d05                	addiw	s10,s10,1
    80003cf0:	e0843783          	ld	a5,-504(s0)
    80003cf4:	0387869b          	addiw	a3,a5,56
    80003cf8:	e8845783          	lhu	a5,-376(s0)
    80003cfc:	06fd5e63          	bge	s10,a5,80003d78 <exec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003d00:	e0d43423          	sd	a3,-504(s0)
    80003d04:	876e                	mv	a4,s11
    80003d06:	e1840613          	addi	a2,s0,-488
    80003d0a:	4581                	li	a1,0
    80003d0c:	8552                	mv	a0,s4
    80003d0e:	df5fe0ef          	jal	80002b02 <readi>
    80003d12:	1db51f63          	bne	a0,s11,80003ef0 <exec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80003d16:	e1842783          	lw	a5,-488(s0)
    80003d1a:	4705                	li	a4,1
    80003d1c:	fce799e3          	bne	a5,a4,80003cee <exec+0x11a>
    if(ph.memsz < ph.filesz)
    80003d20:	e4043483          	ld	s1,-448(s0)
    80003d24:	e3843783          	ld	a5,-456(s0)
    80003d28:	1ef4e463          	bltu	s1,a5,80003f10 <exec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003d2c:	e2843783          	ld	a5,-472(s0)
    80003d30:	94be                	add	s1,s1,a5
    80003d32:	1ef4e263          	bltu	s1,a5,80003f16 <exec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80003d36:	de843703          	ld	a4,-536(s0)
    80003d3a:	8ff9                	and	a5,a5,a4
    80003d3c:	1e079063          	bnez	a5,80003f1c <exec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003d40:	e1c42503          	lw	a0,-484(s0)
    80003d44:	e71ff0ef          	jal	80003bb4 <flags2perm>
    80003d48:	86aa                	mv	a3,a0
    80003d4a:	8626                	mv	a2,s1
    80003d4c:	85ca                	mv	a1,s2
    80003d4e:	855a                	mv	a0,s6
    80003d50:	b61fc0ef          	jal	800008b0 <uvmalloc>
    80003d54:	dea43c23          	sd	a0,-520(s0)
    80003d58:	1c050563          	beqz	a0,80003f22 <exec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003d5c:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003d60:	00098863          	beqz	s3,80003d70 <exec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003d64:	e2843c03          	ld	s8,-472(s0)
    80003d68:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003d6c:	4481                	li	s1,0
    80003d6e:	bfb1                	j	80003cca <exec+0xf6>
    sz = sz1;
    80003d70:	df843903          	ld	s2,-520(s0)
    80003d74:	bfad                	j	80003cee <exec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003d76:	4901                	li	s2,0
  iunlockput(ip);
    80003d78:	8552                	mv	a0,s4
    80003d7a:	d3bfe0ef          	jal	80002ab4 <iunlockput>
  end_op();
    80003d7e:	c52ff0ef          	jal	800031d0 <end_op>
  p = myproc();
    80003d82:	a5cfd0ef          	jal	80000fde <myproc>
    80003d86:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80003d88:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003d8c:	6985                	lui	s3,0x1
    80003d8e:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80003d90:	99ca                	add	s3,s3,s2
    80003d92:	77fd                	lui	a5,0xfffff
    80003d94:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003d98:	4691                	li	a3,4
    80003d9a:	6609                	lui	a2,0x2
    80003d9c:	964e                	add	a2,a2,s3
    80003d9e:	85ce                	mv	a1,s3
    80003da0:	855a                	mv	a0,s6
    80003da2:	b0ffc0ef          	jal	800008b0 <uvmalloc>
    80003da6:	8a2a                	mv	s4,a0
    80003da8:	e105                	bnez	a0,80003dc8 <exec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80003daa:	85ce                	mv	a1,s3
    80003dac:	855a                	mv	a0,s6
    80003dae:	b5efd0ef          	jal	8000110c <proc_freepagetable>
  return -1;
    80003db2:	557d                	li	a0,-1
    80003db4:	79fe                	ld	s3,504(sp)
    80003db6:	7a5e                	ld	s4,496(sp)
    80003db8:	7abe                	ld	s5,488(sp)
    80003dba:	7b1e                	ld	s6,480(sp)
    80003dbc:	6bfe                	ld	s7,472(sp)
    80003dbe:	6c5e                	ld	s8,464(sp)
    80003dc0:	6cbe                	ld	s9,456(sp)
    80003dc2:	6d1e                	ld	s10,448(sp)
    80003dc4:	7dfa                	ld	s11,440(sp)
    80003dc6:	b541                	j	80003c46 <exec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003dc8:	75f9                	lui	a1,0xffffe
    80003dca:	95aa                	add	a1,a1,a0
    80003dcc:	855a                	mv	a0,s6
    80003dce:	cddfc0ef          	jal	80000aaa <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003dd2:	800a0b93          	addi	s7,s4,-2048
    80003dd6:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80003dda:	e0043783          	ld	a5,-512(s0)
    80003dde:	6388                	ld	a0,0(a5)
  sp = sz;
    80003de0:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80003de2:	4481                	li	s1,0
    ustack[argc] = sp;
    80003de4:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80003de8:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80003dec:	cd21                	beqz	a0,80003e44 <exec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80003dee:	db8fc0ef          	jal	800003a6 <strlen>
    80003df2:	0015079b          	addiw	a5,a0,1
    80003df6:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003dfa:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80003dfe:	13796563          	bltu	s2,s7,80003f28 <exec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003e02:	e0043d83          	ld	s11,-512(s0)
    80003e06:	000db983          	ld	s3,0(s11)
    80003e0a:	854e                	mv	a0,s3
    80003e0c:	d9afc0ef          	jal	800003a6 <strlen>
    80003e10:	0015069b          	addiw	a3,a0,1
    80003e14:	864e                	mv	a2,s3
    80003e16:	85ca                	mv	a1,s2
    80003e18:	855a                	mv	a0,s6
    80003e1a:	cbbfc0ef          	jal	80000ad4 <copyout>
    80003e1e:	10054763          	bltz	a0,80003f2c <exec+0x358>
    ustack[argc] = sp;
    80003e22:	00349793          	slli	a5,s1,0x3
    80003e26:	97e6                	add	a5,a5,s9
    80003e28:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde300>
  for(argc = 0; argv[argc]; argc++) {
    80003e2c:	0485                	addi	s1,s1,1
    80003e2e:	008d8793          	addi	a5,s11,8
    80003e32:	e0f43023          	sd	a5,-512(s0)
    80003e36:	008db503          	ld	a0,8(s11)
    80003e3a:	c509                	beqz	a0,80003e44 <exec+0x270>
    if(argc >= MAXARG)
    80003e3c:	fb8499e3          	bne	s1,s8,80003dee <exec+0x21a>
  sz = sz1;
    80003e40:	89d2                	mv	s3,s4
    80003e42:	b7a5                	j	80003daa <exec+0x1d6>
  ustack[argc] = 0;
    80003e44:	00349793          	slli	a5,s1,0x3
    80003e48:	f9078793          	addi	a5,a5,-112
    80003e4c:	97a2                	add	a5,a5,s0
    80003e4e:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80003e52:	00349693          	slli	a3,s1,0x3
    80003e56:	06a1                	addi	a3,a3,8
    80003e58:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003e5c:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80003e60:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80003e62:	f57964e3          	bltu	s2,s7,80003daa <exec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003e66:	e9040613          	addi	a2,s0,-368
    80003e6a:	85ca                	mv	a1,s2
    80003e6c:	855a                	mv	a0,s6
    80003e6e:	c67fc0ef          	jal	80000ad4 <copyout>
    80003e72:	f2054ce3          	bltz	a0,80003daa <exec+0x1d6>
  p->trapframe->a1 = sp;
    80003e76:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80003e7a:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003e7e:	df043783          	ld	a5,-528(s0)
    80003e82:	0007c703          	lbu	a4,0(a5)
    80003e86:	cf11                	beqz	a4,80003ea2 <exec+0x2ce>
    80003e88:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003e8a:	02f00693          	li	a3,47
    80003e8e:	a029                	j	80003e98 <exec+0x2c4>
  for(last=s=path; *s; s++)
    80003e90:	0785                	addi	a5,a5,1
    80003e92:	fff7c703          	lbu	a4,-1(a5)
    80003e96:	c711                	beqz	a4,80003ea2 <exec+0x2ce>
    if(*s == '/')
    80003e98:	fed71ce3          	bne	a4,a3,80003e90 <exec+0x2bc>
      last = s+1;
    80003e9c:	def43823          	sd	a5,-528(s0)
    80003ea0:	bfc5                	j	80003e90 <exec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80003ea2:	4641                	li	a2,16
    80003ea4:	df043583          	ld	a1,-528(s0)
    80003ea8:	158a8513          	addi	a0,s5,344
    80003eac:	cc4fc0ef          	jal	80000370 <safestrcpy>
  oldpagetable = p->pagetable;
    80003eb0:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80003eb4:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80003eb8:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003ebc:	058ab783          	ld	a5,88(s5)
    80003ec0:	e6843703          	ld	a4,-408(s0)
    80003ec4:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003ec6:	058ab783          	ld	a5,88(s5)
    80003eca:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003ece:	85ea                	mv	a1,s10
    80003ed0:	a3cfd0ef          	jal	8000110c <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003ed4:	0004851b          	sext.w	a0,s1
    80003ed8:	79fe                	ld	s3,504(sp)
    80003eda:	7a5e                	ld	s4,496(sp)
    80003edc:	7abe                	ld	s5,488(sp)
    80003ede:	7b1e                	ld	s6,480(sp)
    80003ee0:	6bfe                	ld	s7,472(sp)
    80003ee2:	6c5e                	ld	s8,464(sp)
    80003ee4:	6cbe                	ld	s9,456(sp)
    80003ee6:	6d1e                	ld	s10,448(sp)
    80003ee8:	7dfa                	ld	s11,440(sp)
    80003eea:	bbb1                	j	80003c46 <exec+0x72>
    80003eec:	7b1e                	ld	s6,480(sp)
    80003eee:	b3a9                	j	80003c38 <exec+0x64>
    80003ef0:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003ef4:	df843583          	ld	a1,-520(s0)
    80003ef8:	855a                	mv	a0,s6
    80003efa:	a12fd0ef          	jal	8000110c <proc_freepagetable>
  if(ip){
    80003efe:	79fe                	ld	s3,504(sp)
    80003f00:	7abe                	ld	s5,488(sp)
    80003f02:	7b1e                	ld	s6,480(sp)
    80003f04:	6bfe                	ld	s7,472(sp)
    80003f06:	6c5e                	ld	s8,464(sp)
    80003f08:	6cbe                	ld	s9,456(sp)
    80003f0a:	6d1e                	ld	s10,448(sp)
    80003f0c:	7dfa                	ld	s11,440(sp)
    80003f0e:	b32d                	j	80003c38 <exec+0x64>
    80003f10:	df243c23          	sd	s2,-520(s0)
    80003f14:	b7c5                	j	80003ef4 <exec+0x320>
    80003f16:	df243c23          	sd	s2,-520(s0)
    80003f1a:	bfe9                	j	80003ef4 <exec+0x320>
    80003f1c:	df243c23          	sd	s2,-520(s0)
    80003f20:	bfd1                	j	80003ef4 <exec+0x320>
    80003f22:	df243c23          	sd	s2,-520(s0)
    80003f26:	b7f9                	j	80003ef4 <exec+0x320>
  sz = sz1;
    80003f28:	89d2                	mv	s3,s4
    80003f2a:	b541                	j	80003daa <exec+0x1d6>
    80003f2c:	89d2                	mv	s3,s4
    80003f2e:	bdb5                	j	80003daa <exec+0x1d6>

0000000080003f30 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003f30:	7179                	addi	sp,sp,-48
    80003f32:	f406                	sd	ra,40(sp)
    80003f34:	f022                	sd	s0,32(sp)
    80003f36:	ec26                	sd	s1,24(sp)
    80003f38:	e84a                	sd	s2,16(sp)
    80003f3a:	1800                	addi	s0,sp,48
    80003f3c:	892e                	mv	s2,a1
    80003f3e:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003f40:	fdc40593          	addi	a1,s0,-36
    80003f44:	f6ffd0ef          	jal	80001eb2 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003f48:	fdc42703          	lw	a4,-36(s0)
    80003f4c:	47bd                	li	a5,15
    80003f4e:	02e7ea63          	bltu	a5,a4,80003f82 <argfd+0x52>
    80003f52:	88cfd0ef          	jal	80000fde <myproc>
    80003f56:	fdc42703          	lw	a4,-36(s0)
    80003f5a:	00371793          	slli	a5,a4,0x3
    80003f5e:	0d078793          	addi	a5,a5,208
    80003f62:	953e                	add	a0,a0,a5
    80003f64:	611c                	ld	a5,0(a0)
    80003f66:	c385                	beqz	a5,80003f86 <argfd+0x56>
    return -1;
  if(pfd)
    80003f68:	00090463          	beqz	s2,80003f70 <argfd+0x40>
    *pfd = fd;
    80003f6c:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003f70:	4501                	li	a0,0
  if(pf)
    80003f72:	c091                	beqz	s1,80003f76 <argfd+0x46>
    *pf = f;
    80003f74:	e09c                	sd	a5,0(s1)
}
    80003f76:	70a2                	ld	ra,40(sp)
    80003f78:	7402                	ld	s0,32(sp)
    80003f7a:	64e2                	ld	s1,24(sp)
    80003f7c:	6942                	ld	s2,16(sp)
    80003f7e:	6145                	addi	sp,sp,48
    80003f80:	8082                	ret
    return -1;
    80003f82:	557d                	li	a0,-1
    80003f84:	bfcd                	j	80003f76 <argfd+0x46>
    80003f86:	557d                	li	a0,-1
    80003f88:	b7fd                	j	80003f76 <argfd+0x46>

0000000080003f8a <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003f8a:	1101                	addi	sp,sp,-32
    80003f8c:	ec06                	sd	ra,24(sp)
    80003f8e:	e822                	sd	s0,16(sp)
    80003f90:	e426                	sd	s1,8(sp)
    80003f92:	1000                	addi	s0,sp,32
    80003f94:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003f96:	848fd0ef          	jal	80000fde <myproc>
    80003f9a:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003f9c:	0d050793          	addi	a5,a0,208
    80003fa0:	4501                	li	a0,0
    80003fa2:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003fa4:	6398                	ld	a4,0(a5)
    80003fa6:	cb19                	beqz	a4,80003fbc <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003fa8:	2505                	addiw	a0,a0,1
    80003faa:	07a1                	addi	a5,a5,8
    80003fac:	fed51ce3          	bne	a0,a3,80003fa4 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003fb0:	557d                	li	a0,-1
}
    80003fb2:	60e2                	ld	ra,24(sp)
    80003fb4:	6442                	ld	s0,16(sp)
    80003fb6:	64a2                	ld	s1,8(sp)
    80003fb8:	6105                	addi	sp,sp,32
    80003fba:	8082                	ret
      p->ofile[fd] = f;
    80003fbc:	00351793          	slli	a5,a0,0x3
    80003fc0:	0d078793          	addi	a5,a5,208
    80003fc4:	963e                	add	a2,a2,a5
    80003fc6:	e204                	sd	s1,0(a2)
      return fd;
    80003fc8:	b7ed                	j	80003fb2 <fdalloc+0x28>

0000000080003fca <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003fca:	715d                	addi	sp,sp,-80
    80003fcc:	e486                	sd	ra,72(sp)
    80003fce:	e0a2                	sd	s0,64(sp)
    80003fd0:	fc26                	sd	s1,56(sp)
    80003fd2:	f84a                	sd	s2,48(sp)
    80003fd4:	f44e                	sd	s3,40(sp)
    80003fd6:	f052                	sd	s4,32(sp)
    80003fd8:	ec56                	sd	s5,24(sp)
    80003fda:	e85a                	sd	s6,16(sp)
    80003fdc:	0880                	addi	s0,sp,80
    80003fde:	892e                	mv	s2,a1
    80003fe0:	8a2e                	mv	s4,a1
    80003fe2:	8ab2                	mv	s5,a2
    80003fe4:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003fe6:	fb040593          	addi	a1,s0,-80
    80003fea:	fcffe0ef          	jal	80002fb8 <nameiparent>
    80003fee:	84aa                	mv	s1,a0
    80003ff0:	10050763          	beqz	a0,800040fe <create+0x134>
    return 0;

  ilock(dp);
    80003ff4:	8b5fe0ef          	jal	800028a8 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003ff8:	4601                	li	a2,0
    80003ffa:	fb040593          	addi	a1,s0,-80
    80003ffe:	8526                	mv	a0,s1
    80004000:	d0bfe0ef          	jal	80002d0a <dirlookup>
    80004004:	89aa                	mv	s3,a0
    80004006:	c131                	beqz	a0,8000404a <create+0x80>
    iunlockput(dp);
    80004008:	8526                	mv	a0,s1
    8000400a:	aabfe0ef          	jal	80002ab4 <iunlockput>
    ilock(ip);
    8000400e:	854e                	mv	a0,s3
    80004010:	899fe0ef          	jal	800028a8 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004014:	4789                	li	a5,2
    80004016:	02f91563          	bne	s2,a5,80004040 <create+0x76>
    8000401a:	0449d783          	lhu	a5,68(s3)
    8000401e:	37f9                	addiw	a5,a5,-2
    80004020:	17c2                	slli	a5,a5,0x30
    80004022:	93c1                	srli	a5,a5,0x30
    80004024:	4705                	li	a4,1
    80004026:	00f76d63          	bltu	a4,a5,80004040 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    8000402a:	854e                	mv	a0,s3
    8000402c:	60a6                	ld	ra,72(sp)
    8000402e:	6406                	ld	s0,64(sp)
    80004030:	74e2                	ld	s1,56(sp)
    80004032:	7942                	ld	s2,48(sp)
    80004034:	79a2                	ld	s3,40(sp)
    80004036:	7a02                	ld	s4,32(sp)
    80004038:	6ae2                	ld	s5,24(sp)
    8000403a:	6b42                	ld	s6,16(sp)
    8000403c:	6161                	addi	sp,sp,80
    8000403e:	8082                	ret
    iunlockput(ip);
    80004040:	854e                	mv	a0,s3
    80004042:	a73fe0ef          	jal	80002ab4 <iunlockput>
    return 0;
    80004046:	4981                	li	s3,0
    80004048:	b7cd                	j	8000402a <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    8000404a:	85ca                	mv	a1,s2
    8000404c:	4088                	lw	a0,0(s1)
    8000404e:	eeafe0ef          	jal	80002738 <ialloc>
    80004052:	892a                	mv	s2,a0
    80004054:	cd15                	beqz	a0,80004090 <create+0xc6>
  ilock(ip);
    80004056:	853fe0ef          	jal	800028a8 <ilock>
  ip->major = major;
    8000405a:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    8000405e:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004062:	4785                	li	a5,1
    80004064:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004068:	854a                	mv	a0,s2
    8000406a:	f8afe0ef          	jal	800027f4 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    8000406e:	4705                	li	a4,1
    80004070:	02ea0463          	beq	s4,a4,80004098 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004074:	00492603          	lw	a2,4(s2)
    80004078:	fb040593          	addi	a1,s0,-80
    8000407c:	8526                	mv	a0,s1
    8000407e:	e77fe0ef          	jal	80002ef4 <dirlink>
    80004082:	06054263          	bltz	a0,800040e6 <create+0x11c>
  iunlockput(dp);
    80004086:	8526                	mv	a0,s1
    80004088:	a2dfe0ef          	jal	80002ab4 <iunlockput>
  return ip;
    8000408c:	89ca                	mv	s3,s2
    8000408e:	bf71                	j	8000402a <create+0x60>
    iunlockput(dp);
    80004090:	8526                	mv	a0,s1
    80004092:	a23fe0ef          	jal	80002ab4 <iunlockput>
    return 0;
    80004096:	bf51                	j	8000402a <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004098:	00492603          	lw	a2,4(s2)
    8000409c:	00003597          	auipc	a1,0x3
    800040a0:	5dc58593          	addi	a1,a1,1500 # 80007678 <etext+0x678>
    800040a4:	854a                	mv	a0,s2
    800040a6:	e4ffe0ef          	jal	80002ef4 <dirlink>
    800040aa:	02054e63          	bltz	a0,800040e6 <create+0x11c>
    800040ae:	40d0                	lw	a2,4(s1)
    800040b0:	00003597          	auipc	a1,0x3
    800040b4:	5d058593          	addi	a1,a1,1488 # 80007680 <etext+0x680>
    800040b8:	854a                	mv	a0,s2
    800040ba:	e3bfe0ef          	jal	80002ef4 <dirlink>
    800040be:	02054463          	bltz	a0,800040e6 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    800040c2:	00492603          	lw	a2,4(s2)
    800040c6:	fb040593          	addi	a1,s0,-80
    800040ca:	8526                	mv	a0,s1
    800040cc:	e29fe0ef          	jal	80002ef4 <dirlink>
    800040d0:	00054b63          	bltz	a0,800040e6 <create+0x11c>
    dp->nlink++;  // for ".."
    800040d4:	04a4d783          	lhu	a5,74(s1)
    800040d8:	2785                	addiw	a5,a5,1
    800040da:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800040de:	8526                	mv	a0,s1
    800040e0:	f14fe0ef          	jal	800027f4 <iupdate>
    800040e4:	b74d                	j	80004086 <create+0xbc>
  ip->nlink = 0;
    800040e6:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    800040ea:	854a                	mv	a0,s2
    800040ec:	f08fe0ef          	jal	800027f4 <iupdate>
  iunlockput(ip);
    800040f0:	854a                	mv	a0,s2
    800040f2:	9c3fe0ef          	jal	80002ab4 <iunlockput>
  iunlockput(dp);
    800040f6:	8526                	mv	a0,s1
    800040f8:	9bdfe0ef          	jal	80002ab4 <iunlockput>
  return 0;
    800040fc:	b73d                	j	8000402a <create+0x60>
    return 0;
    800040fe:	89aa                	mv	s3,a0
    80004100:	b72d                	j	8000402a <create+0x60>

0000000080004102 <sys_dup>:
{
    80004102:	7179                	addi	sp,sp,-48
    80004104:	f406                	sd	ra,40(sp)
    80004106:	f022                	sd	s0,32(sp)
    80004108:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    8000410a:	fd840613          	addi	a2,s0,-40
    8000410e:	4581                	li	a1,0
    80004110:	4501                	li	a0,0
    80004112:	e1fff0ef          	jal	80003f30 <argfd>
    return -1;
    80004116:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004118:	02054363          	bltz	a0,8000413e <sys_dup+0x3c>
    8000411c:	ec26                	sd	s1,24(sp)
    8000411e:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004120:	fd843483          	ld	s1,-40(s0)
    80004124:	8526                	mv	a0,s1
    80004126:	e65ff0ef          	jal	80003f8a <fdalloc>
    8000412a:	892a                	mv	s2,a0
    return -1;
    8000412c:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    8000412e:	00054d63          	bltz	a0,80004148 <sys_dup+0x46>
  filedup(f);
    80004132:	8526                	mv	a0,s1
    80004134:	c18ff0ef          	jal	8000354c <filedup>
  return fd;
    80004138:	87ca                	mv	a5,s2
    8000413a:	64e2                	ld	s1,24(sp)
    8000413c:	6942                	ld	s2,16(sp)
}
    8000413e:	853e                	mv	a0,a5
    80004140:	70a2                	ld	ra,40(sp)
    80004142:	7402                	ld	s0,32(sp)
    80004144:	6145                	addi	sp,sp,48
    80004146:	8082                	ret
    80004148:	64e2                	ld	s1,24(sp)
    8000414a:	6942                	ld	s2,16(sp)
    8000414c:	bfcd                	j	8000413e <sys_dup+0x3c>

000000008000414e <sys_read>:
{
    8000414e:	7179                	addi	sp,sp,-48
    80004150:	f406                	sd	ra,40(sp)
    80004152:	f022                	sd	s0,32(sp)
    80004154:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004156:	fd840593          	addi	a1,s0,-40
    8000415a:	4505                	li	a0,1
    8000415c:	d73fd0ef          	jal	80001ece <argaddr>
  argint(2, &n);
    80004160:	fe440593          	addi	a1,s0,-28
    80004164:	4509                	li	a0,2
    80004166:	d4dfd0ef          	jal	80001eb2 <argint>
  if(argfd(0, 0, &f) < 0)
    8000416a:	fe840613          	addi	a2,s0,-24
    8000416e:	4581                	li	a1,0
    80004170:	4501                	li	a0,0
    80004172:	dbfff0ef          	jal	80003f30 <argfd>
    80004176:	87aa                	mv	a5,a0
    return -1;
    80004178:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000417a:	0007ca63          	bltz	a5,8000418e <sys_read+0x40>
  return fileread(f, p, n);
    8000417e:	fe442603          	lw	a2,-28(s0)
    80004182:	fd843583          	ld	a1,-40(s0)
    80004186:	fe843503          	ld	a0,-24(s0)
    8000418a:	d2cff0ef          	jal	800036b6 <fileread>
}
    8000418e:	70a2                	ld	ra,40(sp)
    80004190:	7402                	ld	s0,32(sp)
    80004192:	6145                	addi	sp,sp,48
    80004194:	8082                	ret

0000000080004196 <sys_write>:
{
    80004196:	7179                	addi	sp,sp,-48
    80004198:	f406                	sd	ra,40(sp)
    8000419a:	f022                	sd	s0,32(sp)
    8000419c:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000419e:	fd840593          	addi	a1,s0,-40
    800041a2:	4505                	li	a0,1
    800041a4:	d2bfd0ef          	jal	80001ece <argaddr>
  argint(2, &n);
    800041a8:	fe440593          	addi	a1,s0,-28
    800041ac:	4509                	li	a0,2
    800041ae:	d05fd0ef          	jal	80001eb2 <argint>
  if(argfd(0, 0, &f) < 0)
    800041b2:	fe840613          	addi	a2,s0,-24
    800041b6:	4581                	li	a1,0
    800041b8:	4501                	li	a0,0
    800041ba:	d77ff0ef          	jal	80003f30 <argfd>
    800041be:	87aa                	mv	a5,a0
    return -1;
    800041c0:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800041c2:	0007ca63          	bltz	a5,800041d6 <sys_write+0x40>
  return filewrite(f, p, n);
    800041c6:	fe442603          	lw	a2,-28(s0)
    800041ca:	fd843583          	ld	a1,-40(s0)
    800041ce:	fe843503          	ld	a0,-24(s0)
    800041d2:	da8ff0ef          	jal	8000377a <filewrite>
}
    800041d6:	70a2                	ld	ra,40(sp)
    800041d8:	7402                	ld	s0,32(sp)
    800041da:	6145                	addi	sp,sp,48
    800041dc:	8082                	ret

00000000800041de <sys_close>:
{
    800041de:	1101                	addi	sp,sp,-32
    800041e0:	ec06                	sd	ra,24(sp)
    800041e2:	e822                	sd	s0,16(sp)
    800041e4:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    800041e6:	fe040613          	addi	a2,s0,-32
    800041ea:	fec40593          	addi	a1,s0,-20
    800041ee:	4501                	li	a0,0
    800041f0:	d41ff0ef          	jal	80003f30 <argfd>
    return -1;
    800041f4:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    800041f6:	02054163          	bltz	a0,80004218 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    800041fa:	de5fc0ef          	jal	80000fde <myproc>
    800041fe:	fec42783          	lw	a5,-20(s0)
    80004202:	078e                	slli	a5,a5,0x3
    80004204:	0d078793          	addi	a5,a5,208
    80004208:	953e                	add	a0,a0,a5
    8000420a:	00053023          	sd	zero,0(a0)
  fileclose(f);
    8000420e:	fe043503          	ld	a0,-32(s0)
    80004212:	b80ff0ef          	jal	80003592 <fileclose>
  return 0;
    80004216:	4781                	li	a5,0
}
    80004218:	853e                	mv	a0,a5
    8000421a:	60e2                	ld	ra,24(sp)
    8000421c:	6442                	ld	s0,16(sp)
    8000421e:	6105                	addi	sp,sp,32
    80004220:	8082                	ret

0000000080004222 <sys_fstat>:
{
    80004222:	1101                	addi	sp,sp,-32
    80004224:	ec06                	sd	ra,24(sp)
    80004226:	e822                	sd	s0,16(sp)
    80004228:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    8000422a:	fe040593          	addi	a1,s0,-32
    8000422e:	4505                	li	a0,1
    80004230:	c9ffd0ef          	jal	80001ece <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004234:	fe840613          	addi	a2,s0,-24
    80004238:	4581                	li	a1,0
    8000423a:	4501                	li	a0,0
    8000423c:	cf5ff0ef          	jal	80003f30 <argfd>
    80004240:	87aa                	mv	a5,a0
    return -1;
    80004242:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004244:	0007c863          	bltz	a5,80004254 <sys_fstat+0x32>
  return filestat(f, st);
    80004248:	fe043583          	ld	a1,-32(s0)
    8000424c:	fe843503          	ld	a0,-24(s0)
    80004250:	c04ff0ef          	jal	80003654 <filestat>
}
    80004254:	60e2                	ld	ra,24(sp)
    80004256:	6442                	ld	s0,16(sp)
    80004258:	6105                	addi	sp,sp,32
    8000425a:	8082                	ret

000000008000425c <sys_link>:
{
    8000425c:	7169                	addi	sp,sp,-304
    8000425e:	f606                	sd	ra,296(sp)
    80004260:	f222                	sd	s0,288(sp)
    80004262:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004264:	08000613          	li	a2,128
    80004268:	ed040593          	addi	a1,s0,-304
    8000426c:	4501                	li	a0,0
    8000426e:	c7dfd0ef          	jal	80001eea <argstr>
    return -1;
    80004272:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004274:	0c054e63          	bltz	a0,80004350 <sys_link+0xf4>
    80004278:	08000613          	li	a2,128
    8000427c:	f5040593          	addi	a1,s0,-176
    80004280:	4505                	li	a0,1
    80004282:	c69fd0ef          	jal	80001eea <argstr>
    return -1;
    80004286:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004288:	0c054463          	bltz	a0,80004350 <sys_link+0xf4>
    8000428c:	ee26                	sd	s1,280(sp)
  begin_op();
    8000428e:	ed3fe0ef          	jal	80003160 <begin_op>
  if((ip = namei(old)) == 0){
    80004292:	ed040513          	addi	a0,s0,-304
    80004296:	d09fe0ef          	jal	80002f9e <namei>
    8000429a:	84aa                	mv	s1,a0
    8000429c:	c53d                	beqz	a0,8000430a <sys_link+0xae>
  ilock(ip);
    8000429e:	e0afe0ef          	jal	800028a8 <ilock>
  if(ip->type == T_DIR){
    800042a2:	04449703          	lh	a4,68(s1)
    800042a6:	4785                	li	a5,1
    800042a8:	06f70663          	beq	a4,a5,80004314 <sys_link+0xb8>
    800042ac:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    800042ae:	04a4d783          	lhu	a5,74(s1)
    800042b2:	2785                	addiw	a5,a5,1
    800042b4:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800042b8:	8526                	mv	a0,s1
    800042ba:	d3afe0ef          	jal	800027f4 <iupdate>
  iunlock(ip);
    800042be:	8526                	mv	a0,s1
    800042c0:	e96fe0ef          	jal	80002956 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800042c4:	fd040593          	addi	a1,s0,-48
    800042c8:	f5040513          	addi	a0,s0,-176
    800042cc:	cedfe0ef          	jal	80002fb8 <nameiparent>
    800042d0:	892a                	mv	s2,a0
    800042d2:	cd21                	beqz	a0,8000432a <sys_link+0xce>
  ilock(dp);
    800042d4:	dd4fe0ef          	jal	800028a8 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800042d8:	854a                	mv	a0,s2
    800042da:	00092703          	lw	a4,0(s2)
    800042de:	409c                	lw	a5,0(s1)
    800042e0:	04f71263          	bne	a4,a5,80004324 <sys_link+0xc8>
    800042e4:	40d0                	lw	a2,4(s1)
    800042e6:	fd040593          	addi	a1,s0,-48
    800042ea:	c0bfe0ef          	jal	80002ef4 <dirlink>
    800042ee:	02054b63          	bltz	a0,80004324 <sys_link+0xc8>
  iunlockput(dp);
    800042f2:	854a                	mv	a0,s2
    800042f4:	fc0fe0ef          	jal	80002ab4 <iunlockput>
  iput(ip);
    800042f8:	8526                	mv	a0,s1
    800042fa:	f30fe0ef          	jal	80002a2a <iput>
  end_op();
    800042fe:	ed3fe0ef          	jal	800031d0 <end_op>
  return 0;
    80004302:	4781                	li	a5,0
    80004304:	64f2                	ld	s1,280(sp)
    80004306:	6952                	ld	s2,272(sp)
    80004308:	a0a1                	j	80004350 <sys_link+0xf4>
    end_op();
    8000430a:	ec7fe0ef          	jal	800031d0 <end_op>
    return -1;
    8000430e:	57fd                	li	a5,-1
    80004310:	64f2                	ld	s1,280(sp)
    80004312:	a83d                	j	80004350 <sys_link+0xf4>
    iunlockput(ip);
    80004314:	8526                	mv	a0,s1
    80004316:	f9efe0ef          	jal	80002ab4 <iunlockput>
    end_op();
    8000431a:	eb7fe0ef          	jal	800031d0 <end_op>
    return -1;
    8000431e:	57fd                	li	a5,-1
    80004320:	64f2                	ld	s1,280(sp)
    80004322:	a03d                	j	80004350 <sys_link+0xf4>
    iunlockput(dp);
    80004324:	854a                	mv	a0,s2
    80004326:	f8efe0ef          	jal	80002ab4 <iunlockput>
  ilock(ip);
    8000432a:	8526                	mv	a0,s1
    8000432c:	d7cfe0ef          	jal	800028a8 <ilock>
  ip->nlink--;
    80004330:	04a4d783          	lhu	a5,74(s1)
    80004334:	37fd                	addiw	a5,a5,-1
    80004336:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000433a:	8526                	mv	a0,s1
    8000433c:	cb8fe0ef          	jal	800027f4 <iupdate>
  iunlockput(ip);
    80004340:	8526                	mv	a0,s1
    80004342:	f72fe0ef          	jal	80002ab4 <iunlockput>
  end_op();
    80004346:	e8bfe0ef          	jal	800031d0 <end_op>
  return -1;
    8000434a:	57fd                	li	a5,-1
    8000434c:	64f2                	ld	s1,280(sp)
    8000434e:	6952                	ld	s2,272(sp)
}
    80004350:	853e                	mv	a0,a5
    80004352:	70b2                	ld	ra,296(sp)
    80004354:	7412                	ld	s0,288(sp)
    80004356:	6155                	addi	sp,sp,304
    80004358:	8082                	ret

000000008000435a <sys_unlink>:
{
    8000435a:	7151                	addi	sp,sp,-240
    8000435c:	f586                	sd	ra,232(sp)
    8000435e:	f1a2                	sd	s0,224(sp)
    80004360:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004362:	08000613          	li	a2,128
    80004366:	f3040593          	addi	a1,s0,-208
    8000436a:	4501                	li	a0,0
    8000436c:	b7ffd0ef          	jal	80001eea <argstr>
    80004370:	14054d63          	bltz	a0,800044ca <sys_unlink+0x170>
    80004374:	eda6                	sd	s1,216(sp)
  begin_op();
    80004376:	debfe0ef          	jal	80003160 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    8000437a:	fb040593          	addi	a1,s0,-80
    8000437e:	f3040513          	addi	a0,s0,-208
    80004382:	c37fe0ef          	jal	80002fb8 <nameiparent>
    80004386:	84aa                	mv	s1,a0
    80004388:	c955                	beqz	a0,8000443c <sys_unlink+0xe2>
  ilock(dp);
    8000438a:	d1efe0ef          	jal	800028a8 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000438e:	00003597          	auipc	a1,0x3
    80004392:	2ea58593          	addi	a1,a1,746 # 80007678 <etext+0x678>
    80004396:	fb040513          	addi	a0,s0,-80
    8000439a:	95bfe0ef          	jal	80002cf4 <namecmp>
    8000439e:	10050b63          	beqz	a0,800044b4 <sys_unlink+0x15a>
    800043a2:	00003597          	auipc	a1,0x3
    800043a6:	2de58593          	addi	a1,a1,734 # 80007680 <etext+0x680>
    800043aa:	fb040513          	addi	a0,s0,-80
    800043ae:	947fe0ef          	jal	80002cf4 <namecmp>
    800043b2:	10050163          	beqz	a0,800044b4 <sys_unlink+0x15a>
    800043b6:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    800043b8:	f2c40613          	addi	a2,s0,-212
    800043bc:	fb040593          	addi	a1,s0,-80
    800043c0:	8526                	mv	a0,s1
    800043c2:	949fe0ef          	jal	80002d0a <dirlookup>
    800043c6:	892a                	mv	s2,a0
    800043c8:	0e050563          	beqz	a0,800044b2 <sys_unlink+0x158>
    800043cc:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800043ce:	cdafe0ef          	jal	800028a8 <ilock>
  if(ip->nlink < 1)
    800043d2:	04a91783          	lh	a5,74(s2)
    800043d6:	06f05863          	blez	a5,80004446 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800043da:	04491703          	lh	a4,68(s2)
    800043de:	4785                	li	a5,1
    800043e0:	06f70963          	beq	a4,a5,80004452 <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    800043e4:	fc040993          	addi	s3,s0,-64
    800043e8:	4641                	li	a2,16
    800043ea:	4581                	li	a1,0
    800043ec:	854e                	mv	a0,s3
    800043ee:	e2ffb0ef          	jal	8000021c <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800043f2:	4741                	li	a4,16
    800043f4:	f2c42683          	lw	a3,-212(s0)
    800043f8:	864e                	mv	a2,s3
    800043fa:	4581                	li	a1,0
    800043fc:	8526                	mv	a0,s1
    800043fe:	ff6fe0ef          	jal	80002bf4 <writei>
    80004402:	47c1                	li	a5,16
    80004404:	08f51863          	bne	a0,a5,80004494 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    80004408:	04491703          	lh	a4,68(s2)
    8000440c:	4785                	li	a5,1
    8000440e:	08f70963          	beq	a4,a5,800044a0 <sys_unlink+0x146>
  iunlockput(dp);
    80004412:	8526                	mv	a0,s1
    80004414:	ea0fe0ef          	jal	80002ab4 <iunlockput>
  ip->nlink--;
    80004418:	04a95783          	lhu	a5,74(s2)
    8000441c:	37fd                	addiw	a5,a5,-1
    8000441e:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004422:	854a                	mv	a0,s2
    80004424:	bd0fe0ef          	jal	800027f4 <iupdate>
  iunlockput(ip);
    80004428:	854a                	mv	a0,s2
    8000442a:	e8afe0ef          	jal	80002ab4 <iunlockput>
  end_op();
    8000442e:	da3fe0ef          	jal	800031d0 <end_op>
  return 0;
    80004432:	4501                	li	a0,0
    80004434:	64ee                	ld	s1,216(sp)
    80004436:	694e                	ld	s2,208(sp)
    80004438:	69ae                	ld	s3,200(sp)
    8000443a:	a061                	j	800044c2 <sys_unlink+0x168>
    end_op();
    8000443c:	d95fe0ef          	jal	800031d0 <end_op>
    return -1;
    80004440:	557d                	li	a0,-1
    80004442:	64ee                	ld	s1,216(sp)
    80004444:	a8bd                	j	800044c2 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004446:	00003517          	auipc	a0,0x3
    8000444a:	24250513          	addi	a0,a0,578 # 80007688 <etext+0x688>
    8000444e:	2b0010ef          	jal	800056fe <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004452:	04c92703          	lw	a4,76(s2)
    80004456:	02000793          	li	a5,32
    8000445a:	f8e7f5e3          	bgeu	a5,a4,800043e4 <sys_unlink+0x8a>
    8000445e:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004460:	4741                	li	a4,16
    80004462:	86ce                	mv	a3,s3
    80004464:	f1840613          	addi	a2,s0,-232
    80004468:	4581                	li	a1,0
    8000446a:	854a                	mv	a0,s2
    8000446c:	e96fe0ef          	jal	80002b02 <readi>
    80004470:	47c1                	li	a5,16
    80004472:	00f51b63          	bne	a0,a5,80004488 <sys_unlink+0x12e>
    if(de.inum != 0)
    80004476:	f1845783          	lhu	a5,-232(s0)
    8000447a:	ebb1                	bnez	a5,800044ce <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000447c:	29c1                	addiw	s3,s3,16
    8000447e:	04c92783          	lw	a5,76(s2)
    80004482:	fcf9efe3          	bltu	s3,a5,80004460 <sys_unlink+0x106>
    80004486:	bfb9                	j	800043e4 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004488:	00003517          	auipc	a0,0x3
    8000448c:	21850513          	addi	a0,a0,536 # 800076a0 <etext+0x6a0>
    80004490:	26e010ef          	jal	800056fe <panic>
    panic("unlink: writei");
    80004494:	00003517          	auipc	a0,0x3
    80004498:	22450513          	addi	a0,a0,548 # 800076b8 <etext+0x6b8>
    8000449c:	262010ef          	jal	800056fe <panic>
    dp->nlink--;
    800044a0:	04a4d783          	lhu	a5,74(s1)
    800044a4:	37fd                	addiw	a5,a5,-1
    800044a6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800044aa:	8526                	mv	a0,s1
    800044ac:	b48fe0ef          	jal	800027f4 <iupdate>
    800044b0:	b78d                	j	80004412 <sys_unlink+0xb8>
    800044b2:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800044b4:	8526                	mv	a0,s1
    800044b6:	dfefe0ef          	jal	80002ab4 <iunlockput>
  end_op();
    800044ba:	d17fe0ef          	jal	800031d0 <end_op>
  return -1;
    800044be:	557d                	li	a0,-1
    800044c0:	64ee                	ld	s1,216(sp)
}
    800044c2:	70ae                	ld	ra,232(sp)
    800044c4:	740e                	ld	s0,224(sp)
    800044c6:	616d                	addi	sp,sp,240
    800044c8:	8082                	ret
    return -1;
    800044ca:	557d                	li	a0,-1
    800044cc:	bfdd                	j	800044c2 <sys_unlink+0x168>
    iunlockput(ip);
    800044ce:	854a                	mv	a0,s2
    800044d0:	de4fe0ef          	jal	80002ab4 <iunlockput>
    goto bad;
    800044d4:	694e                	ld	s2,208(sp)
    800044d6:	69ae                	ld	s3,200(sp)
    800044d8:	bff1                	j	800044b4 <sys_unlink+0x15a>

00000000800044da <sys_open>:

uint64
sys_open(void)
{
    800044da:	7131                	addi	sp,sp,-192
    800044dc:	fd06                	sd	ra,184(sp)
    800044de:	f922                	sd	s0,176(sp)
    800044e0:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800044e2:	f4c40593          	addi	a1,s0,-180
    800044e6:	4505                	li	a0,1
    800044e8:	9cbfd0ef          	jal	80001eb2 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800044ec:	08000613          	li	a2,128
    800044f0:	f5040593          	addi	a1,s0,-176
    800044f4:	4501                	li	a0,0
    800044f6:	9f5fd0ef          	jal	80001eea <argstr>
    800044fa:	87aa                	mv	a5,a0
    return -1;
    800044fc:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800044fe:	0a07c363          	bltz	a5,800045a4 <sys_open+0xca>
    80004502:	f526                	sd	s1,168(sp)

  begin_op();
    80004504:	c5dfe0ef          	jal	80003160 <begin_op>

  if(omode & O_CREATE){
    80004508:	f4c42783          	lw	a5,-180(s0)
    8000450c:	2007f793          	andi	a5,a5,512
    80004510:	c3dd                	beqz	a5,800045b6 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    80004512:	4681                	li	a3,0
    80004514:	4601                	li	a2,0
    80004516:	4589                	li	a1,2
    80004518:	f5040513          	addi	a0,s0,-176
    8000451c:	aafff0ef          	jal	80003fca <create>
    80004520:	84aa                	mv	s1,a0
    if(ip == 0){
    80004522:	c549                	beqz	a0,800045ac <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004524:	04449703          	lh	a4,68(s1)
    80004528:	478d                	li	a5,3
    8000452a:	00f71763          	bne	a4,a5,80004538 <sys_open+0x5e>
    8000452e:	0464d703          	lhu	a4,70(s1)
    80004532:	47a5                	li	a5,9
    80004534:	0ae7ee63          	bltu	a5,a4,800045f0 <sys_open+0x116>
    80004538:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000453a:	fb5fe0ef          	jal	800034ee <filealloc>
    8000453e:	892a                	mv	s2,a0
    80004540:	c561                	beqz	a0,80004608 <sys_open+0x12e>
    80004542:	ed4e                	sd	s3,152(sp)
    80004544:	a47ff0ef          	jal	80003f8a <fdalloc>
    80004548:	89aa                	mv	s3,a0
    8000454a:	0a054b63          	bltz	a0,80004600 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000454e:	04449703          	lh	a4,68(s1)
    80004552:	478d                	li	a5,3
    80004554:	0cf70363          	beq	a4,a5,8000461a <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004558:	4789                	li	a5,2
    8000455a:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    8000455e:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004562:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004566:	f4c42783          	lw	a5,-180(s0)
    8000456a:	0017f713          	andi	a4,a5,1
    8000456e:	00174713          	xori	a4,a4,1
    80004572:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004576:	0037f713          	andi	a4,a5,3
    8000457a:	00e03733          	snez	a4,a4
    8000457e:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004582:	4007f793          	andi	a5,a5,1024
    80004586:	c791                	beqz	a5,80004592 <sys_open+0xb8>
    80004588:	04449703          	lh	a4,68(s1)
    8000458c:	4789                	li	a5,2
    8000458e:	08f70d63          	beq	a4,a5,80004628 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    80004592:	8526                	mv	a0,s1
    80004594:	bc2fe0ef          	jal	80002956 <iunlock>
  end_op();
    80004598:	c39fe0ef          	jal	800031d0 <end_op>

  return fd;
    8000459c:	854e                	mv	a0,s3
    8000459e:	74aa                	ld	s1,168(sp)
    800045a0:	790a                	ld	s2,160(sp)
    800045a2:	69ea                	ld	s3,152(sp)
}
    800045a4:	70ea                	ld	ra,184(sp)
    800045a6:	744a                	ld	s0,176(sp)
    800045a8:	6129                	addi	sp,sp,192
    800045aa:	8082                	ret
      end_op();
    800045ac:	c25fe0ef          	jal	800031d0 <end_op>
      return -1;
    800045b0:	557d                	li	a0,-1
    800045b2:	74aa                	ld	s1,168(sp)
    800045b4:	bfc5                	j	800045a4 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    800045b6:	f5040513          	addi	a0,s0,-176
    800045ba:	9e5fe0ef          	jal	80002f9e <namei>
    800045be:	84aa                	mv	s1,a0
    800045c0:	c11d                	beqz	a0,800045e6 <sys_open+0x10c>
    ilock(ip);
    800045c2:	ae6fe0ef          	jal	800028a8 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800045c6:	04449703          	lh	a4,68(s1)
    800045ca:	4785                	li	a5,1
    800045cc:	f4f71ce3          	bne	a4,a5,80004524 <sys_open+0x4a>
    800045d0:	f4c42783          	lw	a5,-180(s0)
    800045d4:	d3b5                	beqz	a5,80004538 <sys_open+0x5e>
      iunlockput(ip);
    800045d6:	8526                	mv	a0,s1
    800045d8:	cdcfe0ef          	jal	80002ab4 <iunlockput>
      end_op();
    800045dc:	bf5fe0ef          	jal	800031d0 <end_op>
      return -1;
    800045e0:	557d                	li	a0,-1
    800045e2:	74aa                	ld	s1,168(sp)
    800045e4:	b7c1                	j	800045a4 <sys_open+0xca>
      end_op();
    800045e6:	bebfe0ef          	jal	800031d0 <end_op>
      return -1;
    800045ea:	557d                	li	a0,-1
    800045ec:	74aa                	ld	s1,168(sp)
    800045ee:	bf5d                	j	800045a4 <sys_open+0xca>
    iunlockput(ip);
    800045f0:	8526                	mv	a0,s1
    800045f2:	cc2fe0ef          	jal	80002ab4 <iunlockput>
    end_op();
    800045f6:	bdbfe0ef          	jal	800031d0 <end_op>
    return -1;
    800045fa:	557d                	li	a0,-1
    800045fc:	74aa                	ld	s1,168(sp)
    800045fe:	b75d                	j	800045a4 <sys_open+0xca>
      fileclose(f);
    80004600:	854a                	mv	a0,s2
    80004602:	f91fe0ef          	jal	80003592 <fileclose>
    80004606:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80004608:	8526                	mv	a0,s1
    8000460a:	caafe0ef          	jal	80002ab4 <iunlockput>
    end_op();
    8000460e:	bc3fe0ef          	jal	800031d0 <end_op>
    return -1;
    80004612:	557d                	li	a0,-1
    80004614:	74aa                	ld	s1,168(sp)
    80004616:	790a                	ld	s2,160(sp)
    80004618:	b771                	j	800045a4 <sys_open+0xca>
    f->type = FD_DEVICE;
    8000461a:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    8000461e:	04649783          	lh	a5,70(s1)
    80004622:	02f91223          	sh	a5,36(s2)
    80004626:	bf35                	j	80004562 <sys_open+0x88>
    itrunc(ip);
    80004628:	8526                	mv	a0,s1
    8000462a:	b6cfe0ef          	jal	80002996 <itrunc>
    8000462e:	b795                	j	80004592 <sys_open+0xb8>

0000000080004630 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004630:	7175                	addi	sp,sp,-144
    80004632:	e506                	sd	ra,136(sp)
    80004634:	e122                	sd	s0,128(sp)
    80004636:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004638:	b29fe0ef          	jal	80003160 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000463c:	08000613          	li	a2,128
    80004640:	f7040593          	addi	a1,s0,-144
    80004644:	4501                	li	a0,0
    80004646:	8a5fd0ef          	jal	80001eea <argstr>
    8000464a:	02054363          	bltz	a0,80004670 <sys_mkdir+0x40>
    8000464e:	4681                	li	a3,0
    80004650:	4601                	li	a2,0
    80004652:	4585                	li	a1,1
    80004654:	f7040513          	addi	a0,s0,-144
    80004658:	973ff0ef          	jal	80003fca <create>
    8000465c:	c911                	beqz	a0,80004670 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000465e:	c56fe0ef          	jal	80002ab4 <iunlockput>
  end_op();
    80004662:	b6ffe0ef          	jal	800031d0 <end_op>
  return 0;
    80004666:	4501                	li	a0,0
}
    80004668:	60aa                	ld	ra,136(sp)
    8000466a:	640a                	ld	s0,128(sp)
    8000466c:	6149                	addi	sp,sp,144
    8000466e:	8082                	ret
    end_op();
    80004670:	b61fe0ef          	jal	800031d0 <end_op>
    return -1;
    80004674:	557d                	li	a0,-1
    80004676:	bfcd                	j	80004668 <sys_mkdir+0x38>

0000000080004678 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004678:	7135                	addi	sp,sp,-160
    8000467a:	ed06                	sd	ra,152(sp)
    8000467c:	e922                	sd	s0,144(sp)
    8000467e:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004680:	ae1fe0ef          	jal	80003160 <begin_op>
  argint(1, &major);
    80004684:	f6c40593          	addi	a1,s0,-148
    80004688:	4505                	li	a0,1
    8000468a:	829fd0ef          	jal	80001eb2 <argint>
  argint(2, &minor);
    8000468e:	f6840593          	addi	a1,s0,-152
    80004692:	4509                	li	a0,2
    80004694:	81ffd0ef          	jal	80001eb2 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004698:	08000613          	li	a2,128
    8000469c:	f7040593          	addi	a1,s0,-144
    800046a0:	4501                	li	a0,0
    800046a2:	849fd0ef          	jal	80001eea <argstr>
    800046a6:	02054563          	bltz	a0,800046d0 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800046aa:	f6841683          	lh	a3,-152(s0)
    800046ae:	f6c41603          	lh	a2,-148(s0)
    800046b2:	458d                	li	a1,3
    800046b4:	f7040513          	addi	a0,s0,-144
    800046b8:	913ff0ef          	jal	80003fca <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800046bc:	c911                	beqz	a0,800046d0 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800046be:	bf6fe0ef          	jal	80002ab4 <iunlockput>
  end_op();
    800046c2:	b0ffe0ef          	jal	800031d0 <end_op>
  return 0;
    800046c6:	4501                	li	a0,0
}
    800046c8:	60ea                	ld	ra,152(sp)
    800046ca:	644a                	ld	s0,144(sp)
    800046cc:	610d                	addi	sp,sp,160
    800046ce:	8082                	ret
    end_op();
    800046d0:	b01fe0ef          	jal	800031d0 <end_op>
    return -1;
    800046d4:	557d                	li	a0,-1
    800046d6:	bfcd                	j	800046c8 <sys_mknod+0x50>

00000000800046d8 <sys_chdir>:

uint64
sys_chdir(void)
{
    800046d8:	7135                	addi	sp,sp,-160
    800046da:	ed06                	sd	ra,152(sp)
    800046dc:	e922                	sd	s0,144(sp)
    800046de:	e14a                	sd	s2,128(sp)
    800046e0:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800046e2:	8fdfc0ef          	jal	80000fde <myproc>
    800046e6:	892a                	mv	s2,a0
  
  begin_op();
    800046e8:	a79fe0ef          	jal	80003160 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800046ec:	08000613          	li	a2,128
    800046f0:	f6040593          	addi	a1,s0,-160
    800046f4:	4501                	li	a0,0
    800046f6:	ff4fd0ef          	jal	80001eea <argstr>
    800046fa:	04054363          	bltz	a0,80004740 <sys_chdir+0x68>
    800046fe:	e526                	sd	s1,136(sp)
    80004700:	f6040513          	addi	a0,s0,-160
    80004704:	89bfe0ef          	jal	80002f9e <namei>
    80004708:	84aa                	mv	s1,a0
    8000470a:	c915                	beqz	a0,8000473e <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    8000470c:	99cfe0ef          	jal	800028a8 <ilock>
  if(ip->type != T_DIR){
    80004710:	04449703          	lh	a4,68(s1)
    80004714:	4785                	li	a5,1
    80004716:	02f71963          	bne	a4,a5,80004748 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000471a:	8526                	mv	a0,s1
    8000471c:	a3afe0ef          	jal	80002956 <iunlock>
  iput(p->cwd);
    80004720:	15093503          	ld	a0,336(s2)
    80004724:	b06fe0ef          	jal	80002a2a <iput>
  end_op();
    80004728:	aa9fe0ef          	jal	800031d0 <end_op>
  p->cwd = ip;
    8000472c:	14993823          	sd	s1,336(s2)
  return 0;
    80004730:	4501                	li	a0,0
    80004732:	64aa                	ld	s1,136(sp)
}
    80004734:	60ea                	ld	ra,152(sp)
    80004736:	644a                	ld	s0,144(sp)
    80004738:	690a                	ld	s2,128(sp)
    8000473a:	610d                	addi	sp,sp,160
    8000473c:	8082                	ret
    8000473e:	64aa                	ld	s1,136(sp)
    end_op();
    80004740:	a91fe0ef          	jal	800031d0 <end_op>
    return -1;
    80004744:	557d                	li	a0,-1
    80004746:	b7fd                	j	80004734 <sys_chdir+0x5c>
    iunlockput(ip);
    80004748:	8526                	mv	a0,s1
    8000474a:	b6afe0ef          	jal	80002ab4 <iunlockput>
    end_op();
    8000474e:	a83fe0ef          	jal	800031d0 <end_op>
    return -1;
    80004752:	557d                	li	a0,-1
    80004754:	64aa                	ld	s1,136(sp)
    80004756:	bff9                	j	80004734 <sys_chdir+0x5c>

0000000080004758 <sys_exec>:

uint64
sys_exec(void)
{
    80004758:	7105                	addi	sp,sp,-480
    8000475a:	ef86                	sd	ra,472(sp)
    8000475c:	eba2                	sd	s0,464(sp)
    8000475e:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004760:	e2840593          	addi	a1,s0,-472
    80004764:	4505                	li	a0,1
    80004766:	f68fd0ef          	jal	80001ece <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    8000476a:	08000613          	li	a2,128
    8000476e:	f3040593          	addi	a1,s0,-208
    80004772:	4501                	li	a0,0
    80004774:	f76fd0ef          	jal	80001eea <argstr>
    80004778:	87aa                	mv	a5,a0
    return -1;
    8000477a:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    8000477c:	0e07c063          	bltz	a5,8000485c <sys_exec+0x104>
    80004780:	e7a6                	sd	s1,456(sp)
    80004782:	e3ca                	sd	s2,448(sp)
    80004784:	ff4e                	sd	s3,440(sp)
    80004786:	fb52                	sd	s4,432(sp)
    80004788:	f756                	sd	s5,424(sp)
    8000478a:	f35a                	sd	s6,416(sp)
    8000478c:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000478e:	e3040a13          	addi	s4,s0,-464
    80004792:	10000613          	li	a2,256
    80004796:	4581                	li	a1,0
    80004798:	8552                	mv	a0,s4
    8000479a:	a83fb0ef          	jal	8000021c <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    8000479e:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    800047a0:	89d2                	mv	s3,s4
    800047a2:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800047a4:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800047a8:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    800047aa:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800047ae:	00391513          	slli	a0,s2,0x3
    800047b2:	85d6                	mv	a1,s5
    800047b4:	e2843783          	ld	a5,-472(s0)
    800047b8:	953e                	add	a0,a0,a5
    800047ba:	e6efd0ef          	jal	80001e28 <fetchaddr>
    800047be:	02054663          	bltz	a0,800047ea <sys_exec+0x92>
    if(uarg == 0){
    800047c2:	e2043783          	ld	a5,-480(s0)
    800047c6:	c7a1                	beqz	a5,8000480e <sys_exec+0xb6>
    argv[i] = kalloc();
    800047c8:	97ffb0ef          	jal	80000146 <kalloc>
    800047cc:	85aa                	mv	a1,a0
    800047ce:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800047d2:	cd01                	beqz	a0,800047ea <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800047d4:	865a                	mv	a2,s6
    800047d6:	e2043503          	ld	a0,-480(s0)
    800047da:	e98fd0ef          	jal	80001e72 <fetchstr>
    800047de:	00054663          	bltz	a0,800047ea <sys_exec+0x92>
    if(i >= NELEM(argv)){
    800047e2:	0905                	addi	s2,s2,1
    800047e4:	09a1                	addi	s3,s3,8
    800047e6:	fd7914e3          	bne	s2,s7,800047ae <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800047ea:	100a0a13          	addi	s4,s4,256
    800047ee:	6088                	ld	a0,0(s1)
    800047f0:	cd31                	beqz	a0,8000484c <sys_exec+0xf4>
    kfree(argv[i]);
    800047f2:	82bfb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800047f6:	04a1                	addi	s1,s1,8
    800047f8:	ff449be3          	bne	s1,s4,800047ee <sys_exec+0x96>
  return -1;
    800047fc:	557d                	li	a0,-1
    800047fe:	64be                	ld	s1,456(sp)
    80004800:	691e                	ld	s2,448(sp)
    80004802:	79fa                	ld	s3,440(sp)
    80004804:	7a5a                	ld	s4,432(sp)
    80004806:	7aba                	ld	s5,424(sp)
    80004808:	7b1a                	ld	s6,416(sp)
    8000480a:	6bfa                	ld	s7,408(sp)
    8000480c:	a881                	j	8000485c <sys_exec+0x104>
      argv[i] = 0;
    8000480e:	0009079b          	sext.w	a5,s2
    80004812:	e3040593          	addi	a1,s0,-464
    80004816:	078e                	slli	a5,a5,0x3
    80004818:	97ae                	add	a5,a5,a1
    8000481a:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    8000481e:	f3040513          	addi	a0,s0,-208
    80004822:	bb2ff0ef          	jal	80003bd4 <exec>
    80004826:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004828:	100a0a13          	addi	s4,s4,256
    8000482c:	6088                	ld	a0,0(s1)
    8000482e:	c511                	beqz	a0,8000483a <sys_exec+0xe2>
    kfree(argv[i]);
    80004830:	fecfb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004834:	04a1                	addi	s1,s1,8
    80004836:	ff449be3          	bne	s1,s4,8000482c <sys_exec+0xd4>
  return ret;
    8000483a:	854a                	mv	a0,s2
    8000483c:	64be                	ld	s1,456(sp)
    8000483e:	691e                	ld	s2,448(sp)
    80004840:	79fa                	ld	s3,440(sp)
    80004842:	7a5a                	ld	s4,432(sp)
    80004844:	7aba                	ld	s5,424(sp)
    80004846:	7b1a                	ld	s6,416(sp)
    80004848:	6bfa                	ld	s7,408(sp)
    8000484a:	a809                	j	8000485c <sys_exec+0x104>
  return -1;
    8000484c:	557d                	li	a0,-1
    8000484e:	64be                	ld	s1,456(sp)
    80004850:	691e                	ld	s2,448(sp)
    80004852:	79fa                	ld	s3,440(sp)
    80004854:	7a5a                	ld	s4,432(sp)
    80004856:	7aba                	ld	s5,424(sp)
    80004858:	7b1a                	ld	s6,416(sp)
    8000485a:	6bfa                	ld	s7,408(sp)
}
    8000485c:	60fe                	ld	ra,472(sp)
    8000485e:	645e                	ld	s0,464(sp)
    80004860:	613d                	addi	sp,sp,480
    80004862:	8082                	ret

0000000080004864 <sys_pipe>:

uint64
sys_pipe(void)
{
    80004864:	7139                	addi	sp,sp,-64
    80004866:	fc06                	sd	ra,56(sp)
    80004868:	f822                	sd	s0,48(sp)
    8000486a:	f426                	sd	s1,40(sp)
    8000486c:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000486e:	f70fc0ef          	jal	80000fde <myproc>
    80004872:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80004874:	fd840593          	addi	a1,s0,-40
    80004878:	4501                	li	a0,0
    8000487a:	e54fd0ef          	jal	80001ece <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000487e:	fc840593          	addi	a1,s0,-56
    80004882:	fd040513          	addi	a0,s0,-48
    80004886:	828ff0ef          	jal	800038ae <pipealloc>
    return -1;
    8000488a:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    8000488c:	0a054763          	bltz	a0,8000493a <sys_pipe+0xd6>
  fd0 = -1;
    80004890:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80004894:	fd043503          	ld	a0,-48(s0)
    80004898:	ef2ff0ef          	jal	80003f8a <fdalloc>
    8000489c:	fca42223          	sw	a0,-60(s0)
    800048a0:	08054463          	bltz	a0,80004928 <sys_pipe+0xc4>
    800048a4:	fc843503          	ld	a0,-56(s0)
    800048a8:	ee2ff0ef          	jal	80003f8a <fdalloc>
    800048ac:	fca42023          	sw	a0,-64(s0)
    800048b0:	06054263          	bltz	a0,80004914 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800048b4:	4691                	li	a3,4
    800048b6:	fc440613          	addi	a2,s0,-60
    800048ba:	fd843583          	ld	a1,-40(s0)
    800048be:	68a8                	ld	a0,80(s1)
    800048c0:	a14fc0ef          	jal	80000ad4 <copyout>
    800048c4:	00054e63          	bltz	a0,800048e0 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800048c8:	4691                	li	a3,4
    800048ca:	fc040613          	addi	a2,s0,-64
    800048ce:	fd843583          	ld	a1,-40(s0)
    800048d2:	95b6                	add	a1,a1,a3
    800048d4:	68a8                	ld	a0,80(s1)
    800048d6:	9fefc0ef          	jal	80000ad4 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800048da:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800048dc:	04055f63          	bgez	a0,8000493a <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    800048e0:	fc442783          	lw	a5,-60(s0)
    800048e4:	078e                	slli	a5,a5,0x3
    800048e6:	0d078793          	addi	a5,a5,208
    800048ea:	97a6                	add	a5,a5,s1
    800048ec:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800048f0:	fc042783          	lw	a5,-64(s0)
    800048f4:	078e                	slli	a5,a5,0x3
    800048f6:	0d078793          	addi	a5,a5,208
    800048fa:	97a6                	add	a5,a5,s1
    800048fc:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80004900:	fd043503          	ld	a0,-48(s0)
    80004904:	c8ffe0ef          	jal	80003592 <fileclose>
    fileclose(wf);
    80004908:	fc843503          	ld	a0,-56(s0)
    8000490c:	c87fe0ef          	jal	80003592 <fileclose>
    return -1;
    80004910:	57fd                	li	a5,-1
    80004912:	a025                	j	8000493a <sys_pipe+0xd6>
    if(fd0 >= 0)
    80004914:	fc442783          	lw	a5,-60(s0)
    80004918:	0007c863          	bltz	a5,80004928 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    8000491c:	078e                	slli	a5,a5,0x3
    8000491e:	0d078793          	addi	a5,a5,208
    80004922:	97a6                	add	a5,a5,s1
    80004924:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80004928:	fd043503          	ld	a0,-48(s0)
    8000492c:	c67fe0ef          	jal	80003592 <fileclose>
    fileclose(wf);
    80004930:	fc843503          	ld	a0,-56(s0)
    80004934:	c5ffe0ef          	jal	80003592 <fileclose>
    return -1;
    80004938:	57fd                	li	a5,-1
}
    8000493a:	853e                	mv	a0,a5
    8000493c:	70e2                	ld	ra,56(sp)
    8000493e:	7442                	ld	s0,48(sp)
    80004940:	74a2                	ld	s1,40(sp)
    80004942:	6121                	addi	sp,sp,64
    80004944:	8082                	ret
	...

0000000080004950 <kernelvec>:
    80004950:	7111                	addi	sp,sp,-256
    80004952:	e006                	sd	ra,0(sp)
    80004954:	e40a                	sd	sp,8(sp)
    80004956:	e80e                	sd	gp,16(sp)
    80004958:	ec12                	sd	tp,24(sp)
    8000495a:	f016                	sd	t0,32(sp)
    8000495c:	f41a                	sd	t1,40(sp)
    8000495e:	f81e                	sd	t2,48(sp)
    80004960:	e4aa                	sd	a0,72(sp)
    80004962:	e8ae                	sd	a1,80(sp)
    80004964:	ecb2                	sd	a2,88(sp)
    80004966:	f0b6                	sd	a3,96(sp)
    80004968:	f4ba                	sd	a4,104(sp)
    8000496a:	f8be                	sd	a5,112(sp)
    8000496c:	fcc2                	sd	a6,120(sp)
    8000496e:	e146                	sd	a7,128(sp)
    80004970:	edf2                	sd	t3,216(sp)
    80004972:	f1f6                	sd	t4,224(sp)
    80004974:	f5fa                	sd	t5,232(sp)
    80004976:	f9fe                	sd	t6,240(sp)
    80004978:	bbefd0ef          	jal	80001d36 <kerneltrap>
    8000497c:	6082                	ld	ra,0(sp)
    8000497e:	6122                	ld	sp,8(sp)
    80004980:	61c2                	ld	gp,16(sp)
    80004982:	7282                	ld	t0,32(sp)
    80004984:	7322                	ld	t1,40(sp)
    80004986:	73c2                	ld	t2,48(sp)
    80004988:	6526                	ld	a0,72(sp)
    8000498a:	65c6                	ld	a1,80(sp)
    8000498c:	6666                	ld	a2,88(sp)
    8000498e:	7686                	ld	a3,96(sp)
    80004990:	7726                	ld	a4,104(sp)
    80004992:	77c6                	ld	a5,112(sp)
    80004994:	7866                	ld	a6,120(sp)
    80004996:	688a                	ld	a7,128(sp)
    80004998:	6e6e                	ld	t3,216(sp)
    8000499a:	7e8e                	ld	t4,224(sp)
    8000499c:	7f2e                	ld	t5,232(sp)
    8000499e:	7fce                	ld	t6,240(sp)
    800049a0:	6111                	addi	sp,sp,256
    800049a2:	10200073          	sret
    800049a6:	00000013          	nop
    800049aa:	00000013          	nop

00000000800049ae <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800049ae:	1141                	addi	sp,sp,-16
    800049b0:	e406                	sd	ra,8(sp)
    800049b2:	e022                	sd	s0,0(sp)
    800049b4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800049b6:	0c000737          	lui	a4,0xc000
    800049ba:	4785                	li	a5,1
    800049bc:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800049be:	c35c                	sw	a5,4(a4)
}
    800049c0:	60a2                	ld	ra,8(sp)
    800049c2:	6402                	ld	s0,0(sp)
    800049c4:	0141                	addi	sp,sp,16
    800049c6:	8082                	ret

00000000800049c8 <plicinithart>:

void
plicinithart(void)
{
    800049c8:	1141                	addi	sp,sp,-16
    800049ca:	e406                	sd	ra,8(sp)
    800049cc:	e022                	sd	s0,0(sp)
    800049ce:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800049d0:	ddafc0ef          	jal	80000faa <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800049d4:	0085171b          	slliw	a4,a0,0x8
    800049d8:	0c0027b7          	lui	a5,0xc002
    800049dc:	97ba                	add	a5,a5,a4
    800049de:	40200713          	li	a4,1026
    800049e2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800049e6:	00d5151b          	slliw	a0,a0,0xd
    800049ea:	0c2017b7          	lui	a5,0xc201
    800049ee:	97aa                	add	a5,a5,a0
    800049f0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800049f4:	60a2                	ld	ra,8(sp)
    800049f6:	6402                	ld	s0,0(sp)
    800049f8:	0141                	addi	sp,sp,16
    800049fa:	8082                	ret

00000000800049fc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800049fc:	1141                	addi	sp,sp,-16
    800049fe:	e406                	sd	ra,8(sp)
    80004a00:	e022                	sd	s0,0(sp)
    80004a02:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004a04:	da6fc0ef          	jal	80000faa <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80004a08:	00d5151b          	slliw	a0,a0,0xd
    80004a0c:	0c2017b7          	lui	a5,0xc201
    80004a10:	97aa                	add	a5,a5,a0
  return irq;
}
    80004a12:	43c8                	lw	a0,4(a5)
    80004a14:	60a2                	ld	ra,8(sp)
    80004a16:	6402                	ld	s0,0(sp)
    80004a18:	0141                	addi	sp,sp,16
    80004a1a:	8082                	ret

0000000080004a1c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80004a1c:	1101                	addi	sp,sp,-32
    80004a1e:	ec06                	sd	ra,24(sp)
    80004a20:	e822                	sd	s0,16(sp)
    80004a22:	e426                	sd	s1,8(sp)
    80004a24:	1000                	addi	s0,sp,32
    80004a26:	84aa                	mv	s1,a0
  int hart = cpuid();
    80004a28:	d82fc0ef          	jal	80000faa <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80004a2c:	00d5179b          	slliw	a5,a0,0xd
    80004a30:	0c201737          	lui	a4,0xc201
    80004a34:	97ba                	add	a5,a5,a4
    80004a36:	c3c4                	sw	s1,4(a5)
}
    80004a38:	60e2                	ld	ra,24(sp)
    80004a3a:	6442                	ld	s0,16(sp)
    80004a3c:	64a2                	ld	s1,8(sp)
    80004a3e:	6105                	addi	sp,sp,32
    80004a40:	8082                	ret

0000000080004a42 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80004a42:	1141                	addi	sp,sp,-16
    80004a44:	e406                	sd	ra,8(sp)
    80004a46:	e022                	sd	s0,0(sp)
    80004a48:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80004a4a:	479d                	li	a5,7
    80004a4c:	04a7ca63          	blt	a5,a0,80004aa0 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80004a50:	00014797          	auipc	a5,0x14
    80004a54:	07078793          	addi	a5,a5,112 # 80018ac0 <disk>
    80004a58:	97aa                	add	a5,a5,a0
    80004a5a:	0187c783          	lbu	a5,24(a5)
    80004a5e:	e7b9                	bnez	a5,80004aac <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80004a60:	00451693          	slli	a3,a0,0x4
    80004a64:	00014797          	auipc	a5,0x14
    80004a68:	05c78793          	addi	a5,a5,92 # 80018ac0 <disk>
    80004a6c:	6398                	ld	a4,0(a5)
    80004a6e:	9736                	add	a4,a4,a3
    80004a70:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80004a74:	6398                	ld	a4,0(a5)
    80004a76:	9736                	add	a4,a4,a3
    80004a78:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80004a7c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80004a80:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004a84:	97aa                	add	a5,a5,a0
    80004a86:	4705                	li	a4,1
    80004a88:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80004a8c:	00014517          	auipc	a0,0x14
    80004a90:	04c50513          	addi	a0,a0,76 # 80018ad8 <disk+0x18>
    80004a94:	b69fc0ef          	jal	800015fc <wakeup>
}
    80004a98:	60a2                	ld	ra,8(sp)
    80004a9a:	6402                	ld	s0,0(sp)
    80004a9c:	0141                	addi	sp,sp,16
    80004a9e:	8082                	ret
    panic("free_desc 1");
    80004aa0:	00003517          	auipc	a0,0x3
    80004aa4:	c2850513          	addi	a0,a0,-984 # 800076c8 <etext+0x6c8>
    80004aa8:	457000ef          	jal	800056fe <panic>
    panic("free_desc 2");
    80004aac:	00003517          	auipc	a0,0x3
    80004ab0:	c2c50513          	addi	a0,a0,-980 # 800076d8 <etext+0x6d8>
    80004ab4:	44b000ef          	jal	800056fe <panic>

0000000080004ab8 <virtio_disk_init>:
{
    80004ab8:	1101                	addi	sp,sp,-32
    80004aba:	ec06                	sd	ra,24(sp)
    80004abc:	e822                	sd	s0,16(sp)
    80004abe:	e426                	sd	s1,8(sp)
    80004ac0:	e04a                	sd	s2,0(sp)
    80004ac2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004ac4:	00003597          	auipc	a1,0x3
    80004ac8:	c2458593          	addi	a1,a1,-988 # 800076e8 <etext+0x6e8>
    80004acc:	00014517          	auipc	a0,0x14
    80004ad0:	11c50513          	addi	a0,a0,284 # 80018be8 <disk+0x128>
    80004ad4:	6df000ef          	jal	800059b2 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004ad8:	100017b7          	lui	a5,0x10001
    80004adc:	4398                	lw	a4,0(a5)
    80004ade:	2701                	sext.w	a4,a4
    80004ae0:	747277b7          	lui	a5,0x74727
    80004ae4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80004ae8:	14f71863          	bne	a4,a5,80004c38 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004aec:	100017b7          	lui	a5,0x10001
    80004af0:	43dc                	lw	a5,4(a5)
    80004af2:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004af4:	4709                	li	a4,2
    80004af6:	14e79163          	bne	a5,a4,80004c38 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004afa:	100017b7          	lui	a5,0x10001
    80004afe:	479c                	lw	a5,8(a5)
    80004b00:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004b02:	12e79b63          	bne	a5,a4,80004c38 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80004b06:	100017b7          	lui	a5,0x10001
    80004b0a:	47d8                	lw	a4,12(a5)
    80004b0c:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004b0e:	554d47b7          	lui	a5,0x554d4
    80004b12:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80004b16:	12f71163          	bne	a4,a5,80004c38 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004b1a:	100017b7          	lui	a5,0x10001
    80004b1e:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004b22:	4705                	li	a4,1
    80004b24:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004b26:	470d                	li	a4,3
    80004b28:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80004b2a:	10001737          	lui	a4,0x10001
    80004b2e:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80004b30:	c7ffe6b7          	lui	a3,0xc7ffe
    80004b34:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdda5f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80004b38:	8f75                	and	a4,a4,a3
    80004b3a:	100016b7          	lui	a3,0x10001
    80004b3e:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004b40:	472d                	li	a4,11
    80004b42:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004b44:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80004b48:	439c                	lw	a5,0(a5)
    80004b4a:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80004b4e:	8ba1                	andi	a5,a5,8
    80004b50:	0e078a63          	beqz	a5,80004c44 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80004b54:	100017b7          	lui	a5,0x10001
    80004b58:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80004b5c:	43fc                	lw	a5,68(a5)
    80004b5e:	2781                	sext.w	a5,a5
    80004b60:	0e079863          	bnez	a5,80004c50 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80004b64:	100017b7          	lui	a5,0x10001
    80004b68:	5bdc                	lw	a5,52(a5)
    80004b6a:	2781                	sext.w	a5,a5
  if(max == 0)
    80004b6c:	0e078863          	beqz	a5,80004c5c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80004b70:	471d                	li	a4,7
    80004b72:	0ef77b63          	bgeu	a4,a5,80004c68 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80004b76:	dd0fb0ef          	jal	80000146 <kalloc>
    80004b7a:	00014497          	auipc	s1,0x14
    80004b7e:	f4648493          	addi	s1,s1,-186 # 80018ac0 <disk>
    80004b82:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004b84:	dc2fb0ef          	jal	80000146 <kalloc>
    80004b88:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004b8a:	dbcfb0ef          	jal	80000146 <kalloc>
    80004b8e:	87aa                	mv	a5,a0
    80004b90:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004b92:	6088                	ld	a0,0(s1)
    80004b94:	0e050063          	beqz	a0,80004c74 <virtio_disk_init+0x1bc>
    80004b98:	00014717          	auipc	a4,0x14
    80004b9c:	f3073703          	ld	a4,-208(a4) # 80018ac8 <disk+0x8>
    80004ba0:	cb71                	beqz	a4,80004c74 <virtio_disk_init+0x1bc>
    80004ba2:	cbe9                	beqz	a5,80004c74 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80004ba4:	6605                	lui	a2,0x1
    80004ba6:	4581                	li	a1,0
    80004ba8:	e74fb0ef          	jal	8000021c <memset>
  memset(disk.avail, 0, PGSIZE);
    80004bac:	00014497          	auipc	s1,0x14
    80004bb0:	f1448493          	addi	s1,s1,-236 # 80018ac0 <disk>
    80004bb4:	6605                	lui	a2,0x1
    80004bb6:	4581                	li	a1,0
    80004bb8:	6488                	ld	a0,8(s1)
    80004bba:	e62fb0ef          	jal	8000021c <memset>
  memset(disk.used, 0, PGSIZE);
    80004bbe:	6605                	lui	a2,0x1
    80004bc0:	4581                	li	a1,0
    80004bc2:	6888                	ld	a0,16(s1)
    80004bc4:	e58fb0ef          	jal	8000021c <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004bc8:	100017b7          	lui	a5,0x10001
    80004bcc:	4721                	li	a4,8
    80004bce:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004bd0:	4098                	lw	a4,0(s1)
    80004bd2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004bd6:	40d8                	lw	a4,4(s1)
    80004bd8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80004bdc:	649c                	ld	a5,8(s1)
    80004bde:	0007869b          	sext.w	a3,a5
    80004be2:	10001737          	lui	a4,0x10001
    80004be6:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80004bea:	9781                	srai	a5,a5,0x20
    80004bec:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80004bf0:	689c                	ld	a5,16(s1)
    80004bf2:	0007869b          	sext.w	a3,a5
    80004bf6:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80004bfa:	9781                	srai	a5,a5,0x20
    80004bfc:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80004c00:	4785                	li	a5,1
    80004c02:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80004c04:	00f48c23          	sb	a5,24(s1)
    80004c08:	00f48ca3          	sb	a5,25(s1)
    80004c0c:	00f48d23          	sb	a5,26(s1)
    80004c10:	00f48da3          	sb	a5,27(s1)
    80004c14:	00f48e23          	sb	a5,28(s1)
    80004c18:	00f48ea3          	sb	a5,29(s1)
    80004c1c:	00f48f23          	sb	a5,30(s1)
    80004c20:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80004c24:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80004c28:	07272823          	sw	s2,112(a4)
}
    80004c2c:	60e2                	ld	ra,24(sp)
    80004c2e:	6442                	ld	s0,16(sp)
    80004c30:	64a2                	ld	s1,8(sp)
    80004c32:	6902                	ld	s2,0(sp)
    80004c34:	6105                	addi	sp,sp,32
    80004c36:	8082                	ret
    panic("could not find virtio disk");
    80004c38:	00003517          	auipc	a0,0x3
    80004c3c:	ac050513          	addi	a0,a0,-1344 # 800076f8 <etext+0x6f8>
    80004c40:	2bf000ef          	jal	800056fe <panic>
    panic("virtio disk FEATURES_OK unset");
    80004c44:	00003517          	auipc	a0,0x3
    80004c48:	ad450513          	addi	a0,a0,-1324 # 80007718 <etext+0x718>
    80004c4c:	2b3000ef          	jal	800056fe <panic>
    panic("virtio disk should not be ready");
    80004c50:	00003517          	auipc	a0,0x3
    80004c54:	ae850513          	addi	a0,a0,-1304 # 80007738 <etext+0x738>
    80004c58:	2a7000ef          	jal	800056fe <panic>
    panic("virtio disk has no queue 0");
    80004c5c:	00003517          	auipc	a0,0x3
    80004c60:	afc50513          	addi	a0,a0,-1284 # 80007758 <etext+0x758>
    80004c64:	29b000ef          	jal	800056fe <panic>
    panic("virtio disk max queue too short");
    80004c68:	00003517          	auipc	a0,0x3
    80004c6c:	b1050513          	addi	a0,a0,-1264 # 80007778 <etext+0x778>
    80004c70:	28f000ef          	jal	800056fe <panic>
    panic("virtio disk kalloc");
    80004c74:	00003517          	auipc	a0,0x3
    80004c78:	b2450513          	addi	a0,a0,-1244 # 80007798 <etext+0x798>
    80004c7c:	283000ef          	jal	800056fe <panic>

0000000080004c80 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004c80:	711d                	addi	sp,sp,-96
    80004c82:	ec86                	sd	ra,88(sp)
    80004c84:	e8a2                	sd	s0,80(sp)
    80004c86:	e4a6                	sd	s1,72(sp)
    80004c88:	e0ca                	sd	s2,64(sp)
    80004c8a:	fc4e                	sd	s3,56(sp)
    80004c8c:	f852                	sd	s4,48(sp)
    80004c8e:	f456                	sd	s5,40(sp)
    80004c90:	f05a                	sd	s6,32(sp)
    80004c92:	ec5e                	sd	s7,24(sp)
    80004c94:	e862                	sd	s8,16(sp)
    80004c96:	1080                	addi	s0,sp,96
    80004c98:	89aa                	mv	s3,a0
    80004c9a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004c9c:	00c52b83          	lw	s7,12(a0)
    80004ca0:	001b9b9b          	slliw	s7,s7,0x1
    80004ca4:	1b82                	slli	s7,s7,0x20
    80004ca6:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80004caa:	00014517          	auipc	a0,0x14
    80004cae:	f3e50513          	addi	a0,a0,-194 # 80018be8 <disk+0x128>
    80004cb2:	58b000ef          	jal	80005a3c <acquire>
  for(int i = 0; i < NUM; i++){
    80004cb6:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004cb8:	00014a97          	auipc	s5,0x14
    80004cbc:	e08a8a93          	addi	s5,s5,-504 # 80018ac0 <disk>
  for(int i = 0; i < 3; i++){
    80004cc0:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80004cc2:	5c7d                	li	s8,-1
    80004cc4:	a095                	j	80004d28 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80004cc6:	00fa8733          	add	a4,s5,a5
    80004cca:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004cce:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004cd0:	0207c563          	bltz	a5,80004cfa <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80004cd4:	2905                	addiw	s2,s2,1
    80004cd6:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80004cd8:	05490c63          	beq	s2,s4,80004d30 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    80004cdc:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004cde:	00014717          	auipc	a4,0x14
    80004ce2:	de270713          	addi	a4,a4,-542 # 80018ac0 <disk>
    80004ce6:	4781                	li	a5,0
    if(disk.free[i]){
    80004ce8:	01874683          	lbu	a3,24(a4)
    80004cec:	fee9                	bnez	a3,80004cc6 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80004cee:	2785                	addiw	a5,a5,1
    80004cf0:	0705                	addi	a4,a4,1
    80004cf2:	fe979be3          	bne	a5,s1,80004ce8 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80004cf6:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80004cfa:	01205d63          	blez	s2,80004d14 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004cfe:	fa042503          	lw	a0,-96(s0)
    80004d02:	d41ff0ef          	jal	80004a42 <free_desc>
      for(int j = 0; j < i; j++)
    80004d06:	4785                	li	a5,1
    80004d08:	0127d663          	bge	a5,s2,80004d14 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004d0c:	fa442503          	lw	a0,-92(s0)
    80004d10:	d33ff0ef          	jal	80004a42 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004d14:	00014597          	auipc	a1,0x14
    80004d18:	ed458593          	addi	a1,a1,-300 # 80018be8 <disk+0x128>
    80004d1c:	00014517          	auipc	a0,0x14
    80004d20:	dbc50513          	addi	a0,a0,-580 # 80018ad8 <disk+0x18>
    80004d24:	88dfc0ef          	jal	800015b0 <sleep>
  for(int i = 0; i < 3; i++){
    80004d28:	fa040613          	addi	a2,s0,-96
    80004d2c:	4901                	li	s2,0
    80004d2e:	b77d                	j	80004cdc <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004d30:	fa042503          	lw	a0,-96(s0)
    80004d34:	00451693          	slli	a3,a0,0x4

  if(write)
    80004d38:	00014797          	auipc	a5,0x14
    80004d3c:	d8878793          	addi	a5,a5,-632 # 80018ac0 <disk>
    80004d40:	00451713          	slli	a4,a0,0x4
    80004d44:	0a070713          	addi	a4,a4,160
    80004d48:	973e                	add	a4,a4,a5
    80004d4a:	01603633          	snez	a2,s6
    80004d4e:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004d50:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004d54:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004d58:	6398                	ld	a4,0(a5)
    80004d5a:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004d5c:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80004d60:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004d62:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004d64:	6390                	ld	a2,0(a5)
    80004d66:	00d60833          	add	a6,a2,a3
    80004d6a:	4741                	li	a4,16
    80004d6c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004d70:	4585                	li	a1,1
    80004d72:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80004d76:	fa442703          	lw	a4,-92(s0)
    80004d7a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004d7e:	0712                	slli	a4,a4,0x4
    80004d80:	963a                	add	a2,a2,a4
    80004d82:	05898813          	addi	a6,s3,88
    80004d86:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80004d8a:	0007b883          	ld	a7,0(a5)
    80004d8e:	9746                	add	a4,a4,a7
    80004d90:	40000613          	li	a2,1024
    80004d94:	c710                	sw	a2,8(a4)
  if(write)
    80004d96:	001b3613          	seqz	a2,s6
    80004d9a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004d9e:	8e4d                	or	a2,a2,a1
    80004da0:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004da4:	fa842603          	lw	a2,-88(s0)
    80004da8:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004dac:	00451813          	slli	a6,a0,0x4
    80004db0:	02080813          	addi	a6,a6,32
    80004db4:	983e                	add	a6,a6,a5
    80004db6:	577d                	li	a4,-1
    80004db8:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004dbc:	0612                	slli	a2,a2,0x4
    80004dbe:	98b2                	add	a7,a7,a2
    80004dc0:	03068713          	addi	a4,a3,48
    80004dc4:	973e                	add	a4,a4,a5
    80004dc6:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80004dca:	6398                	ld	a4,0(a5)
    80004dcc:	9732                	add	a4,a4,a2
    80004dce:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004dd0:	4689                	li	a3,2
    80004dd2:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80004dd6:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004dda:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80004dde:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004de2:	6794                	ld	a3,8(a5)
    80004de4:	0026d703          	lhu	a4,2(a3)
    80004de8:	8b1d                	andi	a4,a4,7
    80004dea:	0706                	slli	a4,a4,0x1
    80004dec:	96ba                	add	a3,a3,a4
    80004dee:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80004df2:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004df6:	6798                	ld	a4,8(a5)
    80004df8:	00275783          	lhu	a5,2(a4)
    80004dfc:	2785                	addiw	a5,a5,1
    80004dfe:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004e02:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004e06:	100017b7          	lui	a5,0x10001
    80004e0a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004e0e:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80004e12:	00014917          	auipc	s2,0x14
    80004e16:	dd690913          	addi	s2,s2,-554 # 80018be8 <disk+0x128>
  while(b->disk == 1) {
    80004e1a:	84ae                	mv	s1,a1
    80004e1c:	00b79a63          	bne	a5,a1,80004e30 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80004e20:	85ca                	mv	a1,s2
    80004e22:	854e                	mv	a0,s3
    80004e24:	f8cfc0ef          	jal	800015b0 <sleep>
  while(b->disk == 1) {
    80004e28:	0049a783          	lw	a5,4(s3)
    80004e2c:	fe978ae3          	beq	a5,s1,80004e20 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80004e30:	fa042903          	lw	s2,-96(s0)
    80004e34:	00491713          	slli	a4,s2,0x4
    80004e38:	02070713          	addi	a4,a4,32
    80004e3c:	00014797          	auipc	a5,0x14
    80004e40:	c8478793          	addi	a5,a5,-892 # 80018ac0 <disk>
    80004e44:	97ba                	add	a5,a5,a4
    80004e46:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004e4a:	00014997          	auipc	s3,0x14
    80004e4e:	c7698993          	addi	s3,s3,-906 # 80018ac0 <disk>
    80004e52:	00491713          	slli	a4,s2,0x4
    80004e56:	0009b783          	ld	a5,0(s3)
    80004e5a:	97ba                	add	a5,a5,a4
    80004e5c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004e60:	854a                	mv	a0,s2
    80004e62:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004e66:	bddff0ef          	jal	80004a42 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004e6a:	8885                	andi	s1,s1,1
    80004e6c:	f0fd                	bnez	s1,80004e52 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004e6e:	00014517          	auipc	a0,0x14
    80004e72:	d7a50513          	addi	a0,a0,-646 # 80018be8 <disk+0x128>
    80004e76:	45b000ef          	jal	80005ad0 <release>
}
    80004e7a:	60e6                	ld	ra,88(sp)
    80004e7c:	6446                	ld	s0,80(sp)
    80004e7e:	64a6                	ld	s1,72(sp)
    80004e80:	6906                	ld	s2,64(sp)
    80004e82:	79e2                	ld	s3,56(sp)
    80004e84:	7a42                	ld	s4,48(sp)
    80004e86:	7aa2                	ld	s5,40(sp)
    80004e88:	7b02                	ld	s6,32(sp)
    80004e8a:	6be2                	ld	s7,24(sp)
    80004e8c:	6c42                	ld	s8,16(sp)
    80004e8e:	6125                	addi	sp,sp,96
    80004e90:	8082                	ret

0000000080004e92 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004e92:	1101                	addi	sp,sp,-32
    80004e94:	ec06                	sd	ra,24(sp)
    80004e96:	e822                	sd	s0,16(sp)
    80004e98:	e426                	sd	s1,8(sp)
    80004e9a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004e9c:	00014497          	auipc	s1,0x14
    80004ea0:	c2448493          	addi	s1,s1,-988 # 80018ac0 <disk>
    80004ea4:	00014517          	auipc	a0,0x14
    80004ea8:	d4450513          	addi	a0,a0,-700 # 80018be8 <disk+0x128>
    80004eac:	391000ef          	jal	80005a3c <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004eb0:	100017b7          	lui	a5,0x10001
    80004eb4:	53bc                	lw	a5,96(a5)
    80004eb6:	8b8d                	andi	a5,a5,3
    80004eb8:	10001737          	lui	a4,0x10001
    80004ebc:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004ebe:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004ec2:	689c                	ld	a5,16(s1)
    80004ec4:	0204d703          	lhu	a4,32(s1)
    80004ec8:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80004ecc:	04f70863          	beq	a4,a5,80004f1c <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80004ed0:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004ed4:	6898                	ld	a4,16(s1)
    80004ed6:	0204d783          	lhu	a5,32(s1)
    80004eda:	8b9d                	andi	a5,a5,7
    80004edc:	078e                	slli	a5,a5,0x3
    80004ede:	97ba                	add	a5,a5,a4
    80004ee0:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004ee2:	00479713          	slli	a4,a5,0x4
    80004ee6:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80004eea:	9726                	add	a4,a4,s1
    80004eec:	01074703          	lbu	a4,16(a4)
    80004ef0:	e329                	bnez	a4,80004f32 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004ef2:	0792                	slli	a5,a5,0x4
    80004ef4:	02078793          	addi	a5,a5,32
    80004ef8:	97a6                	add	a5,a5,s1
    80004efa:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004efc:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004f00:	efcfc0ef          	jal	800015fc <wakeup>

    disk.used_idx += 1;
    80004f04:	0204d783          	lhu	a5,32(s1)
    80004f08:	2785                	addiw	a5,a5,1
    80004f0a:	17c2                	slli	a5,a5,0x30
    80004f0c:	93c1                	srli	a5,a5,0x30
    80004f0e:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004f12:	6898                	ld	a4,16(s1)
    80004f14:	00275703          	lhu	a4,2(a4)
    80004f18:	faf71ce3          	bne	a4,a5,80004ed0 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80004f1c:	00014517          	auipc	a0,0x14
    80004f20:	ccc50513          	addi	a0,a0,-820 # 80018be8 <disk+0x128>
    80004f24:	3ad000ef          	jal	80005ad0 <release>
}
    80004f28:	60e2                	ld	ra,24(sp)
    80004f2a:	6442                	ld	s0,16(sp)
    80004f2c:	64a2                	ld	s1,8(sp)
    80004f2e:	6105                	addi	sp,sp,32
    80004f30:	8082                	ret
      panic("virtio_disk_intr status");
    80004f32:	00003517          	auipc	a0,0x3
    80004f36:	87e50513          	addi	a0,a0,-1922 # 800077b0 <etext+0x7b0>
    80004f3a:	7c4000ef          	jal	800056fe <panic>

0000000080004f3e <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80004f3e:	1141                	addi	sp,sp,-16
    80004f40:	e406                	sd	ra,8(sp)
    80004f42:	e022                	sd	s0,0(sp)
    80004f44:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80004f46:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80004f4a:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80004f4e:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80004f52:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80004f56:	577d                	li	a4,-1
    80004f58:	177e                	slli	a4,a4,0x3f
    80004f5a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80004f5c:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80004f60:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80004f64:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80004f68:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80004f6c:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80004f70:	000f4737          	lui	a4,0xf4
    80004f74:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80004f78:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80004f7a:	14d79073          	csrw	stimecmp,a5
}
    80004f7e:	60a2                	ld	ra,8(sp)
    80004f80:	6402                	ld	s0,0(sp)
    80004f82:	0141                	addi	sp,sp,16
    80004f84:	8082                	ret

0000000080004f86 <start>:
{
    80004f86:	1141                	addi	sp,sp,-16
    80004f88:	e406                	sd	ra,8(sp)
    80004f8a:	e022                	sd	s0,0(sp)
    80004f8c:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80004f8e:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80004f92:	7779                	lui	a4,0xffffe
    80004f94:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffddaff>
    80004f98:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80004f9a:	6705                	lui	a4,0x1
    80004f9c:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80004fa0:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80004fa2:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80004fa6:	ffffb797          	auipc	a5,0xffffb
    80004faa:	42c78793          	addi	a5,a5,1068 # 800003d2 <main>
    80004fae:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80004fb2:	4781                	li	a5,0
    80004fb4:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80004fb8:	67c1                	lui	a5,0x10
    80004fba:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80004fbc:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80004fc0:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80004fc4:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80004fc8:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80004fcc:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80004fd0:	57fd                	li	a5,-1
    80004fd2:	83a9                	srli	a5,a5,0xa
    80004fd4:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80004fd8:	47bd                	li	a5,15
    80004fda:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80004fde:	f61ff0ef          	jal	80004f3e <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80004fe2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80004fe6:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80004fe8:	823e                	mv	tp,a5
  asm volatile("mret");
    80004fea:	30200073          	mret
}
    80004fee:	60a2                	ld	ra,8(sp)
    80004ff0:	6402                	ld	s0,0(sp)
    80004ff2:	0141                	addi	sp,sp,16
    80004ff4:	8082                	ret

0000000080004ff6 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80004ff6:	711d                	addi	sp,sp,-96
    80004ff8:	ec86                	sd	ra,88(sp)
    80004ffa:	e8a2                	sd	s0,80(sp)
    80004ffc:	e0ca                	sd	s2,64(sp)
    80004ffe:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    80005000:	04c05763          	blez	a2,8000504e <consolewrite+0x58>
    80005004:	e4a6                	sd	s1,72(sp)
    80005006:	fc4e                	sd	s3,56(sp)
    80005008:	f852                	sd	s4,48(sp)
    8000500a:	f456                	sd	s5,40(sp)
    8000500c:	f05a                	sd	s6,32(sp)
    8000500e:	ec5e                	sd	s7,24(sp)
    80005010:	8a2a                	mv	s4,a0
    80005012:	84ae                	mv	s1,a1
    80005014:	89b2                	mv	s3,a2
    80005016:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80005018:	faf40b93          	addi	s7,s0,-81
    8000501c:	4b05                	li	s6,1
    8000501e:	5afd                	li	s5,-1
    80005020:	86da                	mv	a3,s6
    80005022:	8626                	mv	a2,s1
    80005024:	85d2                	mv	a1,s4
    80005026:	855e                	mv	a0,s7
    80005028:	92dfc0ef          	jal	80001954 <either_copyin>
    8000502c:	03550363          	beq	a0,s5,80005052 <consolewrite+0x5c>
      break;
    uartputc(c);
    80005030:	faf44503          	lbu	a0,-81(s0)
    80005034:	06b000ef          	jal	8000589e <uartputc>
  for(i = 0; i < n; i++){
    80005038:	2905                	addiw	s2,s2,1
    8000503a:	0485                	addi	s1,s1,1
    8000503c:	ff2992e3          	bne	s3,s2,80005020 <consolewrite+0x2a>
    80005040:	64a6                	ld	s1,72(sp)
    80005042:	79e2                	ld	s3,56(sp)
    80005044:	7a42                	ld	s4,48(sp)
    80005046:	7aa2                	ld	s5,40(sp)
    80005048:	7b02                	ld	s6,32(sp)
    8000504a:	6be2                	ld	s7,24(sp)
    8000504c:	a809                	j	8000505e <consolewrite+0x68>
    8000504e:	4901                	li	s2,0
    80005050:	a039                	j	8000505e <consolewrite+0x68>
    80005052:	64a6                	ld	s1,72(sp)
    80005054:	79e2                	ld	s3,56(sp)
    80005056:	7a42                	ld	s4,48(sp)
    80005058:	7aa2                	ld	s5,40(sp)
    8000505a:	7b02                	ld	s6,32(sp)
    8000505c:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    8000505e:	854a                	mv	a0,s2
    80005060:	60e6                	ld	ra,88(sp)
    80005062:	6446                	ld	s0,80(sp)
    80005064:	6906                	ld	s2,64(sp)
    80005066:	6125                	addi	sp,sp,96
    80005068:	8082                	ret

000000008000506a <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000506a:	711d                	addi	sp,sp,-96
    8000506c:	ec86                	sd	ra,88(sp)
    8000506e:	e8a2                	sd	s0,80(sp)
    80005070:	e4a6                	sd	s1,72(sp)
    80005072:	e0ca                	sd	s2,64(sp)
    80005074:	fc4e                	sd	s3,56(sp)
    80005076:	f852                	sd	s4,48(sp)
    80005078:	f05a                	sd	s6,32(sp)
    8000507a:	ec5e                	sd	s7,24(sp)
    8000507c:	1080                	addi	s0,sp,96
    8000507e:	8b2a                	mv	s6,a0
    80005080:	8a2e                	mv	s4,a1
    80005082:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80005084:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80005086:	0001c517          	auipc	a0,0x1c
    8000508a:	b7a50513          	addi	a0,a0,-1158 # 80020c00 <cons>
    8000508e:	1af000ef          	jal	80005a3c <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80005092:	0001c497          	auipc	s1,0x1c
    80005096:	b6e48493          	addi	s1,s1,-1170 # 80020c00 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    8000509a:	0001c917          	auipc	s2,0x1c
    8000509e:	bfe90913          	addi	s2,s2,-1026 # 80020c98 <cons+0x98>
  while(n > 0){
    800050a2:	0b305b63          	blez	s3,80005158 <consoleread+0xee>
    while(cons.r == cons.w){
    800050a6:	0984a783          	lw	a5,152(s1)
    800050aa:	09c4a703          	lw	a4,156(s1)
    800050ae:	0af71063          	bne	a4,a5,8000514e <consoleread+0xe4>
      if(killed(myproc())){
    800050b2:	f2dfb0ef          	jal	80000fde <myproc>
    800050b6:	f36fc0ef          	jal	800017ec <killed>
    800050ba:	e12d                	bnez	a0,8000511c <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    800050bc:	85a6                	mv	a1,s1
    800050be:	854a                	mv	a0,s2
    800050c0:	cf0fc0ef          	jal	800015b0 <sleep>
    while(cons.r == cons.w){
    800050c4:	0984a783          	lw	a5,152(s1)
    800050c8:	09c4a703          	lw	a4,156(s1)
    800050cc:	fef703e3          	beq	a4,a5,800050b2 <consoleread+0x48>
    800050d0:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800050d2:	0001c717          	auipc	a4,0x1c
    800050d6:	b2e70713          	addi	a4,a4,-1234 # 80020c00 <cons>
    800050da:	0017869b          	addiw	a3,a5,1
    800050de:	08d72c23          	sw	a3,152(a4)
    800050e2:	07f7f693          	andi	a3,a5,127
    800050e6:	9736                	add	a4,a4,a3
    800050e8:	01874703          	lbu	a4,24(a4)
    800050ec:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800050f0:	4691                	li	a3,4
    800050f2:	04da8663          	beq	s5,a3,8000513e <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800050f6:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800050fa:	4685                	li	a3,1
    800050fc:	faf40613          	addi	a2,s0,-81
    80005100:	85d2                	mv	a1,s4
    80005102:	855a                	mv	a0,s6
    80005104:	807fc0ef          	jal	8000190a <either_copyout>
    80005108:	57fd                	li	a5,-1
    8000510a:	04f50663          	beq	a0,a5,80005156 <consoleread+0xec>
      break;

    dst++;
    8000510e:	0a05                	addi	s4,s4,1
    --n;
    80005110:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80005112:	47a9                	li	a5,10
    80005114:	04fa8b63          	beq	s5,a5,8000516a <consoleread+0x100>
    80005118:	7aa2                	ld	s5,40(sp)
    8000511a:	b761                	j	800050a2 <consoleread+0x38>
        release(&cons.lock);
    8000511c:	0001c517          	auipc	a0,0x1c
    80005120:	ae450513          	addi	a0,a0,-1308 # 80020c00 <cons>
    80005124:	1ad000ef          	jal	80005ad0 <release>
        return -1;
    80005128:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    8000512a:	60e6                	ld	ra,88(sp)
    8000512c:	6446                	ld	s0,80(sp)
    8000512e:	64a6                	ld	s1,72(sp)
    80005130:	6906                	ld	s2,64(sp)
    80005132:	79e2                	ld	s3,56(sp)
    80005134:	7a42                	ld	s4,48(sp)
    80005136:	7b02                	ld	s6,32(sp)
    80005138:	6be2                	ld	s7,24(sp)
    8000513a:	6125                	addi	sp,sp,96
    8000513c:	8082                	ret
      if(n < target){
    8000513e:	0179fa63          	bgeu	s3,s7,80005152 <consoleread+0xe8>
        cons.r--;
    80005142:	0001c717          	auipc	a4,0x1c
    80005146:	b4f72b23          	sw	a5,-1194(a4) # 80020c98 <cons+0x98>
    8000514a:	7aa2                	ld	s5,40(sp)
    8000514c:	a031                	j	80005158 <consoleread+0xee>
    8000514e:	f456                	sd	s5,40(sp)
    80005150:	b749                	j	800050d2 <consoleread+0x68>
    80005152:	7aa2                	ld	s5,40(sp)
    80005154:	a011                	j	80005158 <consoleread+0xee>
    80005156:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80005158:	0001c517          	auipc	a0,0x1c
    8000515c:	aa850513          	addi	a0,a0,-1368 # 80020c00 <cons>
    80005160:	171000ef          	jal	80005ad0 <release>
  return target - n;
    80005164:	413b853b          	subw	a0,s7,s3
    80005168:	b7c9                	j	8000512a <consoleread+0xc0>
    8000516a:	7aa2                	ld	s5,40(sp)
    8000516c:	b7f5                	j	80005158 <consoleread+0xee>

000000008000516e <consputc>:
{
    8000516e:	1141                	addi	sp,sp,-16
    80005170:	e406                	sd	ra,8(sp)
    80005172:	e022                	sd	s0,0(sp)
    80005174:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80005176:	10000793          	li	a5,256
    8000517a:	00f50863          	beq	a0,a5,8000518a <consputc+0x1c>
    uartputc_sync(c);
    8000517e:	63e000ef          	jal	800057bc <uartputc_sync>
}
    80005182:	60a2                	ld	ra,8(sp)
    80005184:	6402                	ld	s0,0(sp)
    80005186:	0141                	addi	sp,sp,16
    80005188:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000518a:	4521                	li	a0,8
    8000518c:	630000ef          	jal	800057bc <uartputc_sync>
    80005190:	02000513          	li	a0,32
    80005194:	628000ef          	jal	800057bc <uartputc_sync>
    80005198:	4521                	li	a0,8
    8000519a:	622000ef          	jal	800057bc <uartputc_sync>
    8000519e:	b7d5                	j	80005182 <consputc+0x14>

00000000800051a0 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800051a0:	1101                	addi	sp,sp,-32
    800051a2:	ec06                	sd	ra,24(sp)
    800051a4:	e822                	sd	s0,16(sp)
    800051a6:	e426                	sd	s1,8(sp)
    800051a8:	1000                	addi	s0,sp,32
    800051aa:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800051ac:	0001c517          	auipc	a0,0x1c
    800051b0:	a5450513          	addi	a0,a0,-1452 # 80020c00 <cons>
    800051b4:	089000ef          	jal	80005a3c <acquire>

  switch(c){
    800051b8:	47d5                	li	a5,21
    800051ba:	08f48d63          	beq	s1,a5,80005254 <consoleintr+0xb4>
    800051be:	0297c563          	blt	a5,s1,800051e8 <consoleintr+0x48>
    800051c2:	47a1                	li	a5,8
    800051c4:	0ef48263          	beq	s1,a5,800052a8 <consoleintr+0x108>
    800051c8:	47c1                	li	a5,16
    800051ca:	10f49363          	bne	s1,a5,800052d0 <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    800051ce:	fd0fc0ef          	jal	8000199e <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800051d2:	0001c517          	auipc	a0,0x1c
    800051d6:	a2e50513          	addi	a0,a0,-1490 # 80020c00 <cons>
    800051da:	0f7000ef          	jal	80005ad0 <release>
}
    800051de:	60e2                	ld	ra,24(sp)
    800051e0:	6442                	ld	s0,16(sp)
    800051e2:	64a2                	ld	s1,8(sp)
    800051e4:	6105                	addi	sp,sp,32
    800051e6:	8082                	ret
  switch(c){
    800051e8:	07f00793          	li	a5,127
    800051ec:	0af48e63          	beq	s1,a5,800052a8 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800051f0:	0001c717          	auipc	a4,0x1c
    800051f4:	a1070713          	addi	a4,a4,-1520 # 80020c00 <cons>
    800051f8:	0a072783          	lw	a5,160(a4)
    800051fc:	09872703          	lw	a4,152(a4)
    80005200:	9f99                	subw	a5,a5,a4
    80005202:	07f00713          	li	a4,127
    80005206:	fcf766e3          	bltu	a4,a5,800051d2 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    8000520a:	47b5                	li	a5,13
    8000520c:	0cf48563          	beq	s1,a5,800052d6 <consoleintr+0x136>
      consputc(c);
    80005210:	8526                	mv	a0,s1
    80005212:	f5dff0ef          	jal	8000516e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005216:	0001c717          	auipc	a4,0x1c
    8000521a:	9ea70713          	addi	a4,a4,-1558 # 80020c00 <cons>
    8000521e:	0a072683          	lw	a3,160(a4)
    80005222:	0016879b          	addiw	a5,a3,1
    80005226:	863e                	mv	a2,a5
    80005228:	0af72023          	sw	a5,160(a4)
    8000522c:	07f6f693          	andi	a3,a3,127
    80005230:	9736                	add	a4,a4,a3
    80005232:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80005236:	ff648713          	addi	a4,s1,-10
    8000523a:	c371                	beqz	a4,800052fe <consoleintr+0x15e>
    8000523c:	14f1                	addi	s1,s1,-4
    8000523e:	c0e1                	beqz	s1,800052fe <consoleintr+0x15e>
    80005240:	0001c717          	auipc	a4,0x1c
    80005244:	a5872703          	lw	a4,-1448(a4) # 80020c98 <cons+0x98>
    80005248:	9f99                	subw	a5,a5,a4
    8000524a:	08000713          	li	a4,128
    8000524e:	f8e792e3          	bne	a5,a4,800051d2 <consoleintr+0x32>
    80005252:	a075                	j	800052fe <consoleintr+0x15e>
    80005254:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80005256:	0001c717          	auipc	a4,0x1c
    8000525a:	9aa70713          	addi	a4,a4,-1622 # 80020c00 <cons>
    8000525e:	0a072783          	lw	a5,160(a4)
    80005262:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005266:	0001c497          	auipc	s1,0x1c
    8000526a:	99a48493          	addi	s1,s1,-1638 # 80020c00 <cons>
    while(cons.e != cons.w &&
    8000526e:	4929                	li	s2,10
    80005270:	02f70863          	beq	a4,a5,800052a0 <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005274:	37fd                	addiw	a5,a5,-1
    80005276:	07f7f713          	andi	a4,a5,127
    8000527a:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000527c:	01874703          	lbu	a4,24(a4)
    80005280:	03270263          	beq	a4,s2,800052a4 <consoleintr+0x104>
      cons.e--;
    80005284:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005288:	10000513          	li	a0,256
    8000528c:	ee3ff0ef          	jal	8000516e <consputc>
    while(cons.e != cons.w &&
    80005290:	0a04a783          	lw	a5,160(s1)
    80005294:	09c4a703          	lw	a4,156(s1)
    80005298:	fcf71ee3          	bne	a4,a5,80005274 <consoleintr+0xd4>
    8000529c:	6902                	ld	s2,0(sp)
    8000529e:	bf15                	j	800051d2 <consoleintr+0x32>
    800052a0:	6902                	ld	s2,0(sp)
    800052a2:	bf05                	j	800051d2 <consoleintr+0x32>
    800052a4:	6902                	ld	s2,0(sp)
    800052a6:	b735                	j	800051d2 <consoleintr+0x32>
    if(cons.e != cons.w){
    800052a8:	0001c717          	auipc	a4,0x1c
    800052ac:	95870713          	addi	a4,a4,-1704 # 80020c00 <cons>
    800052b0:	0a072783          	lw	a5,160(a4)
    800052b4:	09c72703          	lw	a4,156(a4)
    800052b8:	f0f70de3          	beq	a4,a5,800051d2 <consoleintr+0x32>
      cons.e--;
    800052bc:	37fd                	addiw	a5,a5,-1
    800052be:	0001c717          	auipc	a4,0x1c
    800052c2:	9ef72123          	sw	a5,-1566(a4) # 80020ca0 <cons+0xa0>
      consputc(BACKSPACE);
    800052c6:	10000513          	li	a0,256
    800052ca:	ea5ff0ef          	jal	8000516e <consputc>
    800052ce:	b711                	j	800051d2 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800052d0:	f00481e3          	beqz	s1,800051d2 <consoleintr+0x32>
    800052d4:	bf31                	j	800051f0 <consoleintr+0x50>
      consputc(c);
    800052d6:	4529                	li	a0,10
    800052d8:	e97ff0ef          	jal	8000516e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800052dc:	0001c797          	auipc	a5,0x1c
    800052e0:	92478793          	addi	a5,a5,-1756 # 80020c00 <cons>
    800052e4:	0a07a703          	lw	a4,160(a5)
    800052e8:	0017069b          	addiw	a3,a4,1
    800052ec:	8636                	mv	a2,a3
    800052ee:	0ad7a023          	sw	a3,160(a5)
    800052f2:	07f77713          	andi	a4,a4,127
    800052f6:	97ba                	add	a5,a5,a4
    800052f8:	4729                	li	a4,10
    800052fa:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800052fe:	0001c797          	auipc	a5,0x1c
    80005302:	98c7af23          	sw	a2,-1634(a5) # 80020c9c <cons+0x9c>
        wakeup(&cons.r);
    80005306:	0001c517          	auipc	a0,0x1c
    8000530a:	99250513          	addi	a0,a0,-1646 # 80020c98 <cons+0x98>
    8000530e:	aeefc0ef          	jal	800015fc <wakeup>
    80005312:	b5c1                	j	800051d2 <consoleintr+0x32>

0000000080005314 <consoleinit>:

void
consoleinit(void)
{
    80005314:	1141                	addi	sp,sp,-16
    80005316:	e406                	sd	ra,8(sp)
    80005318:	e022                	sd	s0,0(sp)
    8000531a:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000531c:	00002597          	auipc	a1,0x2
    80005320:	4ac58593          	addi	a1,a1,1196 # 800077c8 <etext+0x7c8>
    80005324:	0001c517          	auipc	a0,0x1c
    80005328:	8dc50513          	addi	a0,a0,-1828 # 80020c00 <cons>
    8000532c:	686000ef          	jal	800059b2 <initlock>

  uartinit();
    80005330:	436000ef          	jal	80005766 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80005334:	00012797          	auipc	a5,0x12
    80005338:	73478793          	addi	a5,a5,1844 # 80017a68 <devsw>
    8000533c:	00000717          	auipc	a4,0x0
    80005340:	d2e70713          	addi	a4,a4,-722 # 8000506a <consoleread>
    80005344:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80005346:	00000717          	auipc	a4,0x0
    8000534a:	cb070713          	addi	a4,a4,-848 # 80004ff6 <consolewrite>
    8000534e:	ef98                	sd	a4,24(a5)
}
    80005350:	60a2                	ld	ra,8(sp)
    80005352:	6402                	ld	s0,0(sp)
    80005354:	0141                	addi	sp,sp,16
    80005356:	8082                	ret

0000000080005358 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80005358:	7179                	addi	sp,sp,-48
    8000535a:	f406                	sd	ra,40(sp)
    8000535c:	f022                	sd	s0,32(sp)
    8000535e:	e84a                	sd	s2,16(sp)
    80005360:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80005362:	c219                	beqz	a2,80005368 <printint+0x10>
    80005364:	08054163          	bltz	a0,800053e6 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80005368:	4301                	li	t1,0

  i = 0;
    8000536a:	fd040913          	addi	s2,s0,-48
    x = xx;
    8000536e:	86ca                	mv	a3,s2
  i = 0;
    80005370:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005372:	00002817          	auipc	a6,0x2
    80005376:	5ae80813          	addi	a6,a6,1454 # 80007920 <digits>
    8000537a:	88ba                	mv	a7,a4
    8000537c:	0017061b          	addiw	a2,a4,1
    80005380:	8732                	mv	a4,a2
    80005382:	02b577b3          	remu	a5,a0,a1
    80005386:	97c2                	add	a5,a5,a6
    80005388:	0007c783          	lbu	a5,0(a5)
    8000538c:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005390:	87aa                	mv	a5,a0
    80005392:	02b55533          	divu	a0,a0,a1
    80005396:	0685                	addi	a3,a3,1
    80005398:	feb7f1e3          	bgeu	a5,a1,8000537a <printint+0x22>

  if(sign)
    8000539c:	00030c63          	beqz	t1,800053b4 <printint+0x5c>
    buf[i++] = '-';
    800053a0:	fe060793          	addi	a5,a2,-32
    800053a4:	00878633          	add	a2,a5,s0
    800053a8:	02d00793          	li	a5,45
    800053ac:	fef60823          	sb	a5,-16(a2)
    800053b0:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    800053b4:	02e05463          	blez	a4,800053dc <printint+0x84>
    800053b8:	ec26                	sd	s1,24(sp)
    800053ba:	377d                	addiw	a4,a4,-1
    800053bc:	00e904b3          	add	s1,s2,a4
    800053c0:	197d                	addi	s2,s2,-1
    800053c2:	993a                	add	s2,s2,a4
    800053c4:	1702                	slli	a4,a4,0x20
    800053c6:	9301                	srli	a4,a4,0x20
    800053c8:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800053cc:	0004c503          	lbu	a0,0(s1)
    800053d0:	d9fff0ef          	jal	8000516e <consputc>
  while(--i >= 0)
    800053d4:	14fd                	addi	s1,s1,-1
    800053d6:	ff249be3          	bne	s1,s2,800053cc <printint+0x74>
    800053da:	64e2                	ld	s1,24(sp)
}
    800053dc:	70a2                	ld	ra,40(sp)
    800053de:	7402                	ld	s0,32(sp)
    800053e0:	6942                	ld	s2,16(sp)
    800053e2:	6145                	addi	sp,sp,48
    800053e4:	8082                	ret
    x = -xx;
    800053e6:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800053ea:	4305                	li	t1,1
    x = -xx;
    800053ec:	bfbd                	j	8000536a <printint+0x12>

00000000800053ee <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800053ee:	7131                	addi	sp,sp,-192
    800053f0:	fc86                	sd	ra,120(sp)
    800053f2:	f8a2                	sd	s0,112(sp)
    800053f4:	f0ca                	sd	s2,96(sp)
    800053f6:	ec6e                	sd	s11,24(sp)
    800053f8:	0100                	addi	s0,sp,128
    800053fa:	892a                	mv	s2,a0
    800053fc:	e40c                	sd	a1,8(s0)
    800053fe:	e810                	sd	a2,16(s0)
    80005400:	ec14                	sd	a3,24(s0)
    80005402:	f018                	sd	a4,32(s0)
    80005404:	f41c                	sd	a5,40(s0)
    80005406:	03043823          	sd	a6,48(s0)
    8000540a:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    8000540e:	0001cd97          	auipc	s11,0x1c
    80005412:	8b2dad83          	lw	s11,-1870(s11) # 80020cc0 <pr+0x18>
  if(locking)
    80005416:	020d9d63          	bnez	s11,80005450 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    8000541a:	00840793          	addi	a5,s0,8
    8000541e:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005422:	00054503          	lbu	a0,0(a0)
    80005426:	20050f63          	beqz	a0,80005644 <printf+0x256>
    8000542a:	f4a6                	sd	s1,104(sp)
    8000542c:	ecce                	sd	s3,88(sp)
    8000542e:	e8d2                	sd	s4,80(sp)
    80005430:	e4d6                	sd	s5,72(sp)
    80005432:	e0da                	sd	s6,64(sp)
    80005434:	fc5e                	sd	s7,56(sp)
    80005436:	f862                	sd	s8,48(sp)
    80005438:	f06a                	sd	s10,32(sp)
    8000543a:	4a81                	li	s5,0
    if(cx != '%'){
    8000543c:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80005440:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80005444:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    80005448:	4b29                	li	s6,10
    if(c0 == 'd'){
    8000544a:	06400b93          	li	s7,100
    8000544e:	a80d                	j	80005480 <printf+0x92>
    acquire(&pr.lock);
    80005450:	0001c517          	auipc	a0,0x1c
    80005454:	85850513          	addi	a0,a0,-1960 # 80020ca8 <pr>
    80005458:	5e4000ef          	jal	80005a3c <acquire>
  va_start(ap, fmt);
    8000545c:	00840793          	addi	a5,s0,8
    80005460:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005464:	00094503          	lbu	a0,0(s2)
    80005468:	f169                	bnez	a0,8000542a <printf+0x3c>
    8000546a:	aae5                	j	80005662 <printf+0x274>
      consputc(cx);
    8000546c:	d03ff0ef          	jal	8000516e <consputc>
      continue;
    80005470:	84d6                	mv	s1,s5
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005472:	2485                	addiw	s1,s1,1
    80005474:	8aa6                	mv	s5,s1
    80005476:	94ca                	add	s1,s1,s2
    80005478:	0004c503          	lbu	a0,0(s1)
    8000547c:	1a050a63          	beqz	a0,80005630 <printf+0x242>
    if(cx != '%'){
    80005480:	ff3516e3          	bne	a0,s3,8000546c <printf+0x7e>
    i++;
    80005484:	001a879b          	addiw	a5,s5,1
    80005488:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000548a:	00f90733          	add	a4,s2,a5
    8000548e:	00074a03          	lbu	s4,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005492:	1e0a0863          	beqz	s4,80005682 <printf+0x294>
    80005496:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000549a:	1c068b63          	beqz	a3,80005670 <printf+0x282>
    if(c0 == 'd'){
    8000549e:	037a0863          	beq	s4,s7,800054ce <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    800054a2:	f94a0713          	addi	a4,s4,-108
    800054a6:	00173713          	seqz	a4,a4
    800054aa:	f9c68613          	addi	a2,a3,-100
    800054ae:	ee05                	bnez	a2,800054e6 <printf+0xf8>
    800054b0:	cb1d                	beqz	a4,800054e6 <printf+0xf8>
      printint(va_arg(ap, uint64), 10, 1);
    800054b2:	f8843783          	ld	a5,-120(s0)
    800054b6:	00878713          	addi	a4,a5,8
    800054ba:	f8e43423          	sd	a4,-120(s0)
    800054be:	4605                	li	a2,1
    800054c0:	85da                	mv	a1,s6
    800054c2:	6388                	ld	a0,0(a5)
    800054c4:	e95ff0ef          	jal	80005358 <printint>
      i += 1;
    800054c8:	002a849b          	addiw	s1,s5,2
    800054cc:	b75d                	j	80005472 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    800054ce:	f8843783          	ld	a5,-120(s0)
    800054d2:	00878713          	addi	a4,a5,8
    800054d6:	f8e43423          	sd	a4,-120(s0)
    800054da:	4605                	li	a2,1
    800054dc:	85da                	mv	a1,s6
    800054de:	4388                	lw	a0,0(a5)
    800054e0:	e79ff0ef          	jal	80005358 <printint>
    800054e4:	b779                	j	80005472 <printf+0x84>
    if(c1) c2 = fmt[i+2] & 0xff;
    800054e6:	97ca                	add	a5,a5,s2
    800054e8:	8636                	mv	a2,a3
    800054ea:	0027c683          	lbu	a3,2(a5)
    800054ee:	a245                	j	8000568e <printf+0x2a0>
      printint(va_arg(ap, uint64), 10, 1);
    800054f0:	f8843783          	ld	a5,-120(s0)
    800054f4:	00878713          	addi	a4,a5,8
    800054f8:	f8e43423          	sd	a4,-120(s0)
    800054fc:	4605                	li	a2,1
    800054fe:	45a9                	li	a1,10
    80005500:	6388                	ld	a0,0(a5)
    80005502:	e57ff0ef          	jal	80005358 <printint>
      i += 2;
    80005506:	003a849b          	addiw	s1,s5,3
    8000550a:	b7a5                	j	80005472 <printf+0x84>
      printint(va_arg(ap, int), 10, 0);
    8000550c:	f8843783          	ld	a5,-120(s0)
    80005510:	00878713          	addi	a4,a5,8
    80005514:	f8e43423          	sd	a4,-120(s0)
    80005518:	4601                	li	a2,0
    8000551a:	85da                	mv	a1,s6
    8000551c:	4388                	lw	a0,0(a5)
    8000551e:	e3bff0ef          	jal	80005358 <printint>
    80005522:	bf81                	j	80005472 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    80005524:	f8843783          	ld	a5,-120(s0)
    80005528:	00878713          	addi	a4,a5,8
    8000552c:	f8e43423          	sd	a4,-120(s0)
    80005530:	4601                	li	a2,0
    80005532:	85da                	mv	a1,s6
    80005534:	6388                	ld	a0,0(a5)
    80005536:	e23ff0ef          	jal	80005358 <printint>
      i += 1;
    8000553a:	002a849b          	addiw	s1,s5,2
    8000553e:	bf15                	j	80005472 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    80005540:	f8843783          	ld	a5,-120(s0)
    80005544:	00878713          	addi	a4,a5,8
    80005548:	f8e43423          	sd	a4,-120(s0)
    8000554c:	4601                	li	a2,0
    8000554e:	45a9                	li	a1,10
    80005550:	6388                	ld	a0,0(a5)
    80005552:	e07ff0ef          	jal	80005358 <printint>
      i += 2;
    80005556:	003a849b          	addiw	s1,s5,3
    8000555a:	bf21                	j	80005472 <printf+0x84>
      printint(va_arg(ap, int), 16, 0);
    8000555c:	f8843783          	ld	a5,-120(s0)
    80005560:	00878713          	addi	a4,a5,8
    80005564:	f8e43423          	sd	a4,-120(s0)
    80005568:	4601                	li	a2,0
    8000556a:	45c1                	li	a1,16
    8000556c:	4388                	lw	a0,0(a5)
    8000556e:	debff0ef          	jal	80005358 <printint>
    80005572:	b701                	j	80005472 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80005574:	f8843783          	ld	a5,-120(s0)
    80005578:	00878713          	addi	a4,a5,8
    8000557c:	f8e43423          	sd	a4,-120(s0)
    80005580:	45c1                	li	a1,16
    80005582:	6388                	ld	a0,0(a5)
    80005584:	dd5ff0ef          	jal	80005358 <printint>
      i += 1;
    80005588:	002a849b          	addiw	s1,s5,2
    8000558c:	b5dd                	j	80005472 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    8000558e:	f8843783          	ld	a5,-120(s0)
    80005592:	00878713          	addi	a4,a5,8
    80005596:	f8e43423          	sd	a4,-120(s0)
    8000559a:	4601                	li	a2,0
    8000559c:	45c1                	li	a1,16
    8000559e:	6388                	ld	a0,0(a5)
    800055a0:	db9ff0ef          	jal	80005358 <printint>
      i += 2;
    800055a4:	003a849b          	addiw	s1,s5,3
    800055a8:	b5e9                	j	80005472 <printf+0x84>
    800055aa:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    800055ac:	f8843783          	ld	a5,-120(s0)
    800055b0:	00878713          	addi	a4,a5,8
    800055b4:	f8e43423          	sd	a4,-120(s0)
    800055b8:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800055bc:	03000513          	li	a0,48
    800055c0:	bafff0ef          	jal	8000516e <consputc>
  consputc('x');
    800055c4:	07800513          	li	a0,120
    800055c8:	ba7ff0ef          	jal	8000516e <consputc>
    800055cc:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800055ce:	00002c97          	auipc	s9,0x2
    800055d2:	352c8c93          	addi	s9,s9,850 # 80007920 <digits>
    800055d6:	03cad793          	srli	a5,s5,0x3c
    800055da:	97e6                	add	a5,a5,s9
    800055dc:	0007c503          	lbu	a0,0(a5)
    800055e0:	b8fff0ef          	jal	8000516e <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800055e4:	0a92                	slli	s5,s5,0x4
    800055e6:	3a7d                	addiw	s4,s4,-1
    800055e8:	fe0a17e3          	bnez	s4,800055d6 <printf+0x1e8>
    800055ec:	7ca2                	ld	s9,40(sp)
    800055ee:	b551                	j	80005472 <printf+0x84>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    800055f0:	f8843783          	ld	a5,-120(s0)
    800055f4:	00878713          	addi	a4,a5,8
    800055f8:	f8e43423          	sd	a4,-120(s0)
    800055fc:	0007ba03          	ld	s4,0(a5)
    80005600:	000a0d63          	beqz	s4,8000561a <printf+0x22c>
        s = "(null)";
      for(; *s; s++)
    80005604:	000a4503          	lbu	a0,0(s4)
    80005608:	e60505e3          	beqz	a0,80005472 <printf+0x84>
        consputc(*s);
    8000560c:	b63ff0ef          	jal	8000516e <consputc>
      for(; *s; s++)
    80005610:	0a05                	addi	s4,s4,1
    80005612:	000a4503          	lbu	a0,0(s4)
    80005616:	f97d                	bnez	a0,8000560c <printf+0x21e>
    80005618:	bda9                	j	80005472 <printf+0x84>
        s = "(null)";
    8000561a:	00002a17          	auipc	s4,0x2
    8000561e:	1b6a0a13          	addi	s4,s4,438 # 800077d0 <etext+0x7d0>
      for(; *s; s++)
    80005622:	02800513          	li	a0,40
    80005626:	b7dd                	j	8000560c <printf+0x21e>
    } else if(c0 == '%'){
      consputc('%');
    80005628:	8552                	mv	a0,s4
    8000562a:	b45ff0ef          	jal	8000516e <consputc>
    8000562e:	b591                	j	80005472 <printf+0x84>
    }
#endif
  }
  va_end(ap);

  if(locking)
    80005630:	020d9163          	bnez	s11,80005652 <printf+0x264>
    80005634:	74a6                	ld	s1,104(sp)
    80005636:	69e6                	ld	s3,88(sp)
    80005638:	6a46                	ld	s4,80(sp)
    8000563a:	6aa6                	ld	s5,72(sp)
    8000563c:	6b06                	ld	s6,64(sp)
    8000563e:	7be2                	ld	s7,56(sp)
    80005640:	7c42                	ld	s8,48(sp)
    80005642:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    80005644:	4501                	li	a0,0
    80005646:	70e6                	ld	ra,120(sp)
    80005648:	7446                	ld	s0,112(sp)
    8000564a:	7906                	ld	s2,96(sp)
    8000564c:	6de2                	ld	s11,24(sp)
    8000564e:	6129                	addi	sp,sp,192
    80005650:	8082                	ret
    80005652:	74a6                	ld	s1,104(sp)
    80005654:	69e6                	ld	s3,88(sp)
    80005656:	6a46                	ld	s4,80(sp)
    80005658:	6aa6                	ld	s5,72(sp)
    8000565a:	6b06                	ld	s6,64(sp)
    8000565c:	7be2                	ld	s7,56(sp)
    8000565e:	7c42                	ld	s8,48(sp)
    80005660:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80005662:	0001b517          	auipc	a0,0x1b
    80005666:	64650513          	addi	a0,a0,1606 # 80020ca8 <pr>
    8000566a:	466000ef          	jal	80005ad0 <release>
    8000566e:	bfd9                	j	80005644 <printf+0x256>
    if(c0 == 'd'){
    80005670:	e57a0fe3          	beq	s4,s7,800054ce <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005674:	f94a0713          	addi	a4,s4,-108
    80005678:	00173713          	seqz	a4,a4
    8000567c:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000567e:	4781                	li	a5,0
    80005680:	a00d                	j	800056a2 <printf+0x2b4>
    } else if(c0 == 'l' && c1 == 'd'){
    80005682:	f94a0713          	addi	a4,s4,-108
    80005686:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    8000568a:	8652                	mv	a2,s4
    8000568c:	86d2                	mv	a3,s4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000568e:	f9460793          	addi	a5,a2,-108
    80005692:	0017b793          	seqz	a5,a5
    80005696:	8ff9                	and	a5,a5,a4
    80005698:	f9c68593          	addi	a1,a3,-100
    8000569c:	e199                	bnez	a1,800056a2 <printf+0x2b4>
    8000569e:	e40799e3          	bnez	a5,800054f0 <printf+0x102>
    } else if(c0 == 'u'){
    800056a2:	e78a05e3          	beq	s4,s8,8000550c <printf+0x11e>
    } else if(c0 == 'l' && c1 == 'u'){
    800056a6:	f8b60593          	addi	a1,a2,-117
    800056aa:	e199                	bnez	a1,800056b0 <printf+0x2c2>
    800056ac:	e6071ce3          	bnez	a4,80005524 <printf+0x136>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800056b0:	f8b68593          	addi	a1,a3,-117
    800056b4:	e199                	bnez	a1,800056ba <printf+0x2cc>
    800056b6:	e80795e3          	bnez	a5,80005540 <printf+0x152>
    } else if(c0 == 'x'){
    800056ba:	ebaa01e3          	beq	s4,s10,8000555c <printf+0x16e>
    } else if(c0 == 'l' && c1 == 'x'){
    800056be:	f8860613          	addi	a2,a2,-120
    800056c2:	e219                	bnez	a2,800056c8 <printf+0x2da>
    800056c4:	ea0718e3          	bnez	a4,80005574 <printf+0x186>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800056c8:	f8868693          	addi	a3,a3,-120
    800056cc:	e299                	bnez	a3,800056d2 <printf+0x2e4>
    800056ce:	ec0790e3          	bnez	a5,8000558e <printf+0x1a0>
    } else if(c0 == 'p'){
    800056d2:	07000793          	li	a5,112
    800056d6:	ecfa0ae3          	beq	s4,a5,800055aa <printf+0x1bc>
    } else if(c0 == 's'){
    800056da:	07300793          	li	a5,115
    800056de:	f0fa09e3          	beq	s4,a5,800055f0 <printf+0x202>
    } else if(c0 == '%'){
    800056e2:	02500793          	li	a5,37
    800056e6:	f4fa01e3          	beq	s4,a5,80005628 <printf+0x23a>
    } else if(c0 == 0){
    800056ea:	f40a03e3          	beqz	s4,80005630 <printf+0x242>
      consputc('%');
    800056ee:	02500513          	li	a0,37
    800056f2:	a7dff0ef          	jal	8000516e <consputc>
      consputc(c0);
    800056f6:	8552                	mv	a0,s4
    800056f8:	a77ff0ef          	jal	8000516e <consputc>
    800056fc:	bb9d                	j	80005472 <printf+0x84>

00000000800056fe <panic>:

void
panic(char *s)
{
    800056fe:	1101                	addi	sp,sp,-32
    80005700:	ec06                	sd	ra,24(sp)
    80005702:	e822                	sd	s0,16(sp)
    80005704:	e426                	sd	s1,8(sp)
    80005706:	1000                	addi	s0,sp,32
    80005708:	84aa                	mv	s1,a0
  pr.locking = 0;
    8000570a:	0001b797          	auipc	a5,0x1b
    8000570e:	5a07ab23          	sw	zero,1462(a5) # 80020cc0 <pr+0x18>
  printf("panic: ");
    80005712:	00002517          	auipc	a0,0x2
    80005716:	0c650513          	addi	a0,a0,198 # 800077d8 <etext+0x7d8>
    8000571a:	cd5ff0ef          	jal	800053ee <printf>
  printf("%s\n", s);
    8000571e:	85a6                	mv	a1,s1
    80005720:	00002517          	auipc	a0,0x2
    80005724:	0c050513          	addi	a0,a0,192 # 800077e0 <etext+0x7e0>
    80005728:	cc7ff0ef          	jal	800053ee <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000572c:	4785                	li	a5,1
    8000572e:	00002717          	auipc	a4,0x2
    80005732:	28f72323          	sw	a5,646(a4) # 800079b4 <panicked>
  for(;;)
    80005736:	a001                	j	80005736 <panic+0x38>

0000000080005738 <printfinit>:
    ;
}

void
printfinit(void)
{
    80005738:	1141                	addi	sp,sp,-16
    8000573a:	e406                	sd	ra,8(sp)
    8000573c:	e022                	sd	s0,0(sp)
    8000573e:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80005740:	00002597          	auipc	a1,0x2
    80005744:	0a858593          	addi	a1,a1,168 # 800077e8 <etext+0x7e8>
    80005748:	0001b517          	auipc	a0,0x1b
    8000574c:	56050513          	addi	a0,a0,1376 # 80020ca8 <pr>
    80005750:	262000ef          	jal	800059b2 <initlock>
  pr.locking = 1;
    80005754:	4785                	li	a5,1
    80005756:	0001b717          	auipc	a4,0x1b
    8000575a:	56f72523          	sw	a5,1386(a4) # 80020cc0 <pr+0x18>
}
    8000575e:	60a2                	ld	ra,8(sp)
    80005760:	6402                	ld	s0,0(sp)
    80005762:	0141                	addi	sp,sp,16
    80005764:	8082                	ret

0000000080005766 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80005766:	1141                	addi	sp,sp,-16
    80005768:	e406                	sd	ra,8(sp)
    8000576a:	e022                	sd	s0,0(sp)
    8000576c:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000576e:	100007b7          	lui	a5,0x10000
    80005772:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80005776:	10000737          	lui	a4,0x10000
    8000577a:	f8000693          	li	a3,-128
    8000577e:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005782:	468d                	li	a3,3
    80005784:	10000637          	lui	a2,0x10000
    80005788:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000578c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80005790:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80005794:	8732                	mv	a4,a2
    80005796:	461d                	li	a2,7
    80005798:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000579c:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    800057a0:	00002597          	auipc	a1,0x2
    800057a4:	05058593          	addi	a1,a1,80 # 800077f0 <etext+0x7f0>
    800057a8:	0001b517          	auipc	a0,0x1b
    800057ac:	52050513          	addi	a0,a0,1312 # 80020cc8 <uart_tx_lock>
    800057b0:	202000ef          	jal	800059b2 <initlock>
}
    800057b4:	60a2                	ld	ra,8(sp)
    800057b6:	6402                	ld	s0,0(sp)
    800057b8:	0141                	addi	sp,sp,16
    800057ba:	8082                	ret

00000000800057bc <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800057bc:	1101                	addi	sp,sp,-32
    800057be:	ec06                	sd	ra,24(sp)
    800057c0:	e822                	sd	s0,16(sp)
    800057c2:	e426                	sd	s1,8(sp)
    800057c4:	1000                	addi	s0,sp,32
    800057c6:	84aa                	mv	s1,a0
  push_off();
    800057c8:	230000ef          	jal	800059f8 <push_off>

  if(panicked){
    800057cc:	00002797          	auipc	a5,0x2
    800057d0:	1e87a783          	lw	a5,488(a5) # 800079b4 <panicked>
    800057d4:	e795                	bnez	a5,80005800 <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800057d6:	10000737          	lui	a4,0x10000
    800057da:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    800057dc:	00074783          	lbu	a5,0(a4)
    800057e0:	0207f793          	andi	a5,a5,32
    800057e4:	dfe5                	beqz	a5,800057dc <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    800057e6:	0ff4f513          	zext.b	a0,s1
    800057ea:	100007b7          	lui	a5,0x10000
    800057ee:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800057f2:	28e000ef          	jal	80005a80 <pop_off>
}
    800057f6:	60e2                	ld	ra,24(sp)
    800057f8:	6442                	ld	s0,16(sp)
    800057fa:	64a2                	ld	s1,8(sp)
    800057fc:	6105                	addi	sp,sp,32
    800057fe:	8082                	ret
    for(;;)
    80005800:	a001                	j	80005800 <uartputc_sync+0x44>

0000000080005802 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80005802:	00002797          	auipc	a5,0x2
    80005806:	1b67b783          	ld	a5,438(a5) # 800079b8 <uart_tx_r>
    8000580a:	00002717          	auipc	a4,0x2
    8000580e:	1b673703          	ld	a4,438(a4) # 800079c0 <uart_tx_w>
    80005812:	08f70163          	beq	a4,a5,80005894 <uartstart+0x92>
{
    80005816:	7139                	addi	sp,sp,-64
    80005818:	fc06                	sd	ra,56(sp)
    8000581a:	f822                	sd	s0,48(sp)
    8000581c:	f426                	sd	s1,40(sp)
    8000581e:	f04a                	sd	s2,32(sp)
    80005820:	ec4e                	sd	s3,24(sp)
    80005822:	e852                	sd	s4,16(sp)
    80005824:	e456                	sd	s5,8(sp)
    80005826:	e05a                	sd	s6,0(sp)
    80005828:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000582a:	10000937          	lui	s2,0x10000
    8000582e:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005830:	0001ba97          	auipc	s5,0x1b
    80005834:	498a8a93          	addi	s5,s5,1176 # 80020cc8 <uart_tx_lock>
    uart_tx_r += 1;
    80005838:	00002497          	auipc	s1,0x2
    8000583c:	18048493          	addi	s1,s1,384 # 800079b8 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    80005840:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80005844:	00002997          	auipc	s3,0x2
    80005848:	17c98993          	addi	s3,s3,380 # 800079c0 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000584c:	00094703          	lbu	a4,0(s2)
    80005850:	02077713          	andi	a4,a4,32
    80005854:	c715                	beqz	a4,80005880 <uartstart+0x7e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005856:	01f7f713          	andi	a4,a5,31
    8000585a:	9756                	add	a4,a4,s5
    8000585c:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    80005860:	0785                	addi	a5,a5,1
    80005862:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80005864:	8526                	mv	a0,s1
    80005866:	d97fb0ef          	jal	800015fc <wakeup>
    WriteReg(THR, c);
    8000586a:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    8000586e:	609c                	ld	a5,0(s1)
    80005870:	0009b703          	ld	a4,0(s3)
    80005874:	fcf71ce3          	bne	a4,a5,8000584c <uartstart+0x4a>
      ReadReg(ISR);
    80005878:	100007b7          	lui	a5,0x10000
    8000587c:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005880:	70e2                	ld	ra,56(sp)
    80005882:	7442                	ld	s0,48(sp)
    80005884:	74a2                	ld	s1,40(sp)
    80005886:	7902                	ld	s2,32(sp)
    80005888:	69e2                	ld	s3,24(sp)
    8000588a:	6a42                	ld	s4,16(sp)
    8000588c:	6aa2                	ld	s5,8(sp)
    8000588e:	6b02                	ld	s6,0(sp)
    80005890:	6121                	addi	sp,sp,64
    80005892:	8082                	ret
      ReadReg(ISR);
    80005894:	100007b7          	lui	a5,0x10000
    80005898:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    8000589c:	8082                	ret

000000008000589e <uartputc>:
{
    8000589e:	7179                	addi	sp,sp,-48
    800058a0:	f406                	sd	ra,40(sp)
    800058a2:	f022                	sd	s0,32(sp)
    800058a4:	ec26                	sd	s1,24(sp)
    800058a6:	e84a                	sd	s2,16(sp)
    800058a8:	e44e                	sd	s3,8(sp)
    800058aa:	e052                	sd	s4,0(sp)
    800058ac:	1800                	addi	s0,sp,48
    800058ae:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    800058b0:	0001b517          	auipc	a0,0x1b
    800058b4:	41850513          	addi	a0,a0,1048 # 80020cc8 <uart_tx_lock>
    800058b8:	184000ef          	jal	80005a3c <acquire>
  if(panicked){
    800058bc:	00002797          	auipc	a5,0x2
    800058c0:	0f87a783          	lw	a5,248(a5) # 800079b4 <panicked>
    800058c4:	e3d1                	bnez	a5,80005948 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800058c6:	00002717          	auipc	a4,0x2
    800058ca:	0fa73703          	ld	a4,250(a4) # 800079c0 <uart_tx_w>
    800058ce:	00002797          	auipc	a5,0x2
    800058d2:	0ea7b783          	ld	a5,234(a5) # 800079b8 <uart_tx_r>
    800058d6:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800058da:	0001b997          	auipc	s3,0x1b
    800058de:	3ee98993          	addi	s3,s3,1006 # 80020cc8 <uart_tx_lock>
    800058e2:	00002497          	auipc	s1,0x2
    800058e6:	0d648493          	addi	s1,s1,214 # 800079b8 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800058ea:	00002917          	auipc	s2,0x2
    800058ee:	0d690913          	addi	s2,s2,214 # 800079c0 <uart_tx_w>
    800058f2:	00e79d63          	bne	a5,a4,8000590c <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800058f6:	85ce                	mv	a1,s3
    800058f8:	8526                	mv	a0,s1
    800058fa:	cb7fb0ef          	jal	800015b0 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800058fe:	00093703          	ld	a4,0(s2)
    80005902:	609c                	ld	a5,0(s1)
    80005904:	02078793          	addi	a5,a5,32
    80005908:	fee787e3          	beq	a5,a4,800058f6 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    8000590c:	01f77693          	andi	a3,a4,31
    80005910:	0001b797          	auipc	a5,0x1b
    80005914:	3b878793          	addi	a5,a5,952 # 80020cc8 <uart_tx_lock>
    80005918:	97b6                	add	a5,a5,a3
    8000591a:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    8000591e:	0705                	addi	a4,a4,1
    80005920:	00002797          	auipc	a5,0x2
    80005924:	0ae7b023          	sd	a4,160(a5) # 800079c0 <uart_tx_w>
  uartstart();
    80005928:	edbff0ef          	jal	80005802 <uartstart>
  release(&uart_tx_lock);
    8000592c:	0001b517          	auipc	a0,0x1b
    80005930:	39c50513          	addi	a0,a0,924 # 80020cc8 <uart_tx_lock>
    80005934:	19c000ef          	jal	80005ad0 <release>
}
    80005938:	70a2                	ld	ra,40(sp)
    8000593a:	7402                	ld	s0,32(sp)
    8000593c:	64e2                	ld	s1,24(sp)
    8000593e:	6942                	ld	s2,16(sp)
    80005940:	69a2                	ld	s3,8(sp)
    80005942:	6a02                	ld	s4,0(sp)
    80005944:	6145                	addi	sp,sp,48
    80005946:	8082                	ret
    for(;;)
    80005948:	a001                	j	80005948 <uartputc+0xaa>

000000008000594a <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    8000594a:	1141                	addi	sp,sp,-16
    8000594c:	e406                	sd	ra,8(sp)
    8000594e:	e022                	sd	s0,0(sp)
    80005950:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80005952:	100007b7          	lui	a5,0x10000
    80005956:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    8000595a:	8b85                	andi	a5,a5,1
    8000595c:	cb89                	beqz	a5,8000596e <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    8000595e:	100007b7          	lui	a5,0x10000
    80005962:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80005966:	60a2                	ld	ra,8(sp)
    80005968:	6402                	ld	s0,0(sp)
    8000596a:	0141                	addi	sp,sp,16
    8000596c:	8082                	ret
    return -1;
    8000596e:	557d                	li	a0,-1
    80005970:	bfdd                	j	80005966 <uartgetc+0x1c>

0000000080005972 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80005972:	1101                	addi	sp,sp,-32
    80005974:	ec06                	sd	ra,24(sp)
    80005976:	e822                	sd	s0,16(sp)
    80005978:	e426                	sd	s1,8(sp)
    8000597a:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    8000597c:	54fd                	li	s1,-1
    int c = uartgetc();
    8000597e:	fcdff0ef          	jal	8000594a <uartgetc>
    if(c == -1)
    80005982:	00950563          	beq	a0,s1,8000598c <uartintr+0x1a>
      break;
    consoleintr(c);
    80005986:	81bff0ef          	jal	800051a0 <consoleintr>
  while(1){
    8000598a:	bfd5                	j	8000597e <uartintr+0xc>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    8000598c:	0001b517          	auipc	a0,0x1b
    80005990:	33c50513          	addi	a0,a0,828 # 80020cc8 <uart_tx_lock>
    80005994:	0a8000ef          	jal	80005a3c <acquire>
  uartstart();
    80005998:	e6bff0ef          	jal	80005802 <uartstart>
  release(&uart_tx_lock);
    8000599c:	0001b517          	auipc	a0,0x1b
    800059a0:	32c50513          	addi	a0,a0,812 # 80020cc8 <uart_tx_lock>
    800059a4:	12c000ef          	jal	80005ad0 <release>
}
    800059a8:	60e2                	ld	ra,24(sp)
    800059aa:	6442                	ld	s0,16(sp)
    800059ac:	64a2                	ld	s1,8(sp)
    800059ae:	6105                	addi	sp,sp,32
    800059b0:	8082                	ret

00000000800059b2 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    800059b2:	1141                	addi	sp,sp,-16
    800059b4:	e406                	sd	ra,8(sp)
    800059b6:	e022                	sd	s0,0(sp)
    800059b8:	0800                	addi	s0,sp,16
  lk->name = name;
    800059ba:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    800059bc:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    800059c0:	00053823          	sd	zero,16(a0)
}
    800059c4:	60a2                	ld	ra,8(sp)
    800059c6:	6402                	ld	s0,0(sp)
    800059c8:	0141                	addi	sp,sp,16
    800059ca:	8082                	ret

00000000800059cc <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    800059cc:	411c                	lw	a5,0(a0)
    800059ce:	e399                	bnez	a5,800059d4 <holding+0x8>
    800059d0:	4501                	li	a0,0
  return r;
}
    800059d2:	8082                	ret
{
    800059d4:	1101                	addi	sp,sp,-32
    800059d6:	ec06                	sd	ra,24(sp)
    800059d8:	e822                	sd	s0,16(sp)
    800059da:	e426                	sd	s1,8(sp)
    800059dc:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    800059de:	691c                	ld	a5,16(a0)
    800059e0:	84be                	mv	s1,a5
    800059e2:	ddcfb0ef          	jal	80000fbe <mycpu>
    800059e6:	40a48533          	sub	a0,s1,a0
    800059ea:	00153513          	seqz	a0,a0
}
    800059ee:	60e2                	ld	ra,24(sp)
    800059f0:	6442                	ld	s0,16(sp)
    800059f2:	64a2                	ld	s1,8(sp)
    800059f4:	6105                	addi	sp,sp,32
    800059f6:	8082                	ret

00000000800059f8 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    800059f8:	1101                	addi	sp,sp,-32
    800059fa:	ec06                	sd	ra,24(sp)
    800059fc:	e822                	sd	s0,16(sp)
    800059fe:	e426                	sd	s1,8(sp)
    80005a00:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005a02:	100027f3          	csrr	a5,sstatus
    80005a06:	84be                	mv	s1,a5
    80005a08:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80005a0c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80005a0e:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80005a12:	dacfb0ef          	jal	80000fbe <mycpu>
    80005a16:	5d3c                	lw	a5,120(a0)
    80005a18:	cb99                	beqz	a5,80005a2e <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80005a1a:	da4fb0ef          	jal	80000fbe <mycpu>
    80005a1e:	5d3c                	lw	a5,120(a0)
    80005a20:	2785                	addiw	a5,a5,1
    80005a22:	dd3c                	sw	a5,120(a0)
}
    80005a24:	60e2                	ld	ra,24(sp)
    80005a26:	6442                	ld	s0,16(sp)
    80005a28:	64a2                	ld	s1,8(sp)
    80005a2a:	6105                	addi	sp,sp,32
    80005a2c:	8082                	ret
    mycpu()->intena = old;
    80005a2e:	d90fb0ef          	jal	80000fbe <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80005a32:	0014d793          	srli	a5,s1,0x1
    80005a36:	8b85                	andi	a5,a5,1
    80005a38:	dd7c                	sw	a5,124(a0)
    80005a3a:	b7c5                	j	80005a1a <push_off+0x22>

0000000080005a3c <acquire>:
{
    80005a3c:	1101                	addi	sp,sp,-32
    80005a3e:	ec06                	sd	ra,24(sp)
    80005a40:	e822                	sd	s0,16(sp)
    80005a42:	e426                	sd	s1,8(sp)
    80005a44:	1000                	addi	s0,sp,32
    80005a46:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80005a48:	fb1ff0ef          	jal	800059f8 <push_off>
  if(holding(lk))
    80005a4c:	8526                	mv	a0,s1
    80005a4e:	f7fff0ef          	jal	800059cc <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005a52:	4705                	li	a4,1
  if(holding(lk))
    80005a54:	e105                	bnez	a0,80005a74 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005a56:	87ba                	mv	a5,a4
    80005a58:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80005a5c:	2781                	sext.w	a5,a5
    80005a5e:	ffe5                	bnez	a5,80005a56 <acquire+0x1a>
  __sync_synchronize();
    80005a60:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80005a64:	d5afb0ef          	jal	80000fbe <mycpu>
    80005a68:	e888                	sd	a0,16(s1)
}
    80005a6a:	60e2                	ld	ra,24(sp)
    80005a6c:	6442                	ld	s0,16(sp)
    80005a6e:	64a2                	ld	s1,8(sp)
    80005a70:	6105                	addi	sp,sp,32
    80005a72:	8082                	ret
    panic("acquire");
    80005a74:	00002517          	auipc	a0,0x2
    80005a78:	d8450513          	addi	a0,a0,-636 # 800077f8 <etext+0x7f8>
    80005a7c:	c83ff0ef          	jal	800056fe <panic>

0000000080005a80 <pop_off>:

void
pop_off(void)
{
    80005a80:	1141                	addi	sp,sp,-16
    80005a82:	e406                	sd	ra,8(sp)
    80005a84:	e022                	sd	s0,0(sp)
    80005a86:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005a88:	d36fb0ef          	jal	80000fbe <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005a8c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80005a90:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005a92:	e39d                	bnez	a5,80005ab8 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005a94:	5d3c                	lw	a5,120(a0)
    80005a96:	02f05763          	blez	a5,80005ac4 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80005a9a:	37fd                	addiw	a5,a5,-1
    80005a9c:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80005a9e:	eb89                	bnez	a5,80005ab0 <pop_off+0x30>
    80005aa0:	5d7c                	lw	a5,124(a0)
    80005aa2:	c799                	beqz	a5,80005ab0 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005aa4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80005aa8:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80005aac:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80005ab0:	60a2                	ld	ra,8(sp)
    80005ab2:	6402                	ld	s0,0(sp)
    80005ab4:	0141                	addi	sp,sp,16
    80005ab6:	8082                	ret
    panic("pop_off - interruptible");
    80005ab8:	00002517          	auipc	a0,0x2
    80005abc:	d4850513          	addi	a0,a0,-696 # 80007800 <etext+0x800>
    80005ac0:	c3fff0ef          	jal	800056fe <panic>
    panic("pop_off");
    80005ac4:	00002517          	auipc	a0,0x2
    80005ac8:	d5450513          	addi	a0,a0,-684 # 80007818 <etext+0x818>
    80005acc:	c33ff0ef          	jal	800056fe <panic>

0000000080005ad0 <release>:
{
    80005ad0:	1101                	addi	sp,sp,-32
    80005ad2:	ec06                	sd	ra,24(sp)
    80005ad4:	e822                	sd	s0,16(sp)
    80005ad6:	e426                	sd	s1,8(sp)
    80005ad8:	1000                	addi	s0,sp,32
    80005ada:	84aa                	mv	s1,a0
  if(!holding(lk))
    80005adc:	ef1ff0ef          	jal	800059cc <holding>
    80005ae0:	c105                	beqz	a0,80005b00 <release+0x30>
  lk->cpu = 0;
    80005ae2:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80005ae6:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80005aea:	0310000f          	fence	rw,w
    80005aee:	0004a023          	sw	zero,0(s1)
  pop_off();
    80005af2:	f8fff0ef          	jal	80005a80 <pop_off>
}
    80005af6:	60e2                	ld	ra,24(sp)
    80005af8:	6442                	ld	s0,16(sp)
    80005afa:	64a2                	ld	s1,8(sp)
    80005afc:	6105                	addi	sp,sp,32
    80005afe:	8082                	ret
    panic("release");
    80005b00:	00002517          	auipc	a0,0x2
    80005b04:	d2050513          	addi	a0,a0,-736 # 80007820 <etext+0x820>
    80005b08:	bf7ff0ef          	jal	800056fe <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
