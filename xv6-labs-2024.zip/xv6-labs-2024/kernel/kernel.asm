
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00019117          	auipc	sp,0x19
    80000004:	ec010113          	addi	sp,sp,-320 # 80018ec0 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	541040ef          	jal	80004d56 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	00021797          	auipc	a5,0x21
    8000002c:	f9878793          	addi	a5,a5,-104 # 80020fc0 <end>
    80000030:	00f53733          	sltu	a4,a0,a5
    80000034:	47c5                	li	a5,17
    80000036:	07ee                	slli	a5,a5,0x1b
    80000038:	17fd                	addi	a5,a5,-1
    8000003a:	00a7b7b3          	sltu	a5,a5,a0
    8000003e:	8fd9                	or	a5,a5,a4
    80000040:	eb95                	bnez	a5,80000074 <kfree+0x58>
    80000042:	84aa                	mv	s1,a0
    80000044:	03451793          	slli	a5,a0,0x34
    80000048:	e795                	bnez	a5,80000074 <kfree+0x58>
  memset(pa, 1, PGSIZE);
#endif
  
  r = (struct run*)pa;

  acquire(&kmem.lock);
    8000004a:	00008917          	auipc	s2,0x8
    8000004e:	a4690913          	addi	s2,s2,-1466 # 80007a90 <kmem>
    80000052:	854a                	mv	a0,s2
    80000054:	7b8050ef          	jal	8000580c <acquire>
  r->next = kmem.freelist;
    80000058:	01893783          	ld	a5,24(s2)
    8000005c:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    8000005e:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000062:	854a                	mv	a0,s2
    80000064:	03d050ef          	jal	800058a0 <release>
}
    80000068:	60e2                	ld	ra,24(sp)
    8000006a:	6442                	ld	s0,16(sp)
    8000006c:	64a2                	ld	s1,8(sp)
    8000006e:	6902                	ld	s2,0(sp)
    80000070:	6105                	addi	sp,sp,32
    80000072:	8082                	ret
    panic("kfree");
    80000074:	00007517          	auipc	a0,0x7
    80000078:	f8c50513          	addi	a0,a0,-116 # 80007000 <etext>
    8000007c:	452050ef          	jal	800054ce <panic>

0000000080000080 <freerange>:
{
    80000080:	7179                	addi	sp,sp,-48
    80000082:	f406                	sd	ra,40(sp)
    80000084:	f022                	sd	s0,32(sp)
    80000086:	ec26                	sd	s1,24(sp)
    80000088:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    8000008a:	6785                	lui	a5,0x1
    8000008c:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000090:	00e504b3          	add	s1,a0,a4
    80000094:	777d                	lui	a4,0xfffff
    80000096:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    80000098:	94be                	add	s1,s1,a5
    8000009a:	0295e263          	bltu	a1,s1,800000be <freerange+0x3e>
    8000009e:	e84a                	sd	s2,16(sp)
    800000a0:	e44e                	sd	s3,8(sp)
    800000a2:	e052                	sd	s4,0(sp)
    800000a4:	892e                	mv	s2,a1
    kfree(p);
    800000a6:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    800000a8:	89be                	mv	s3,a5
    kfree(p);
    800000aa:	01448533          	add	a0,s1,s4
    800000ae:	f6fff0ef          	jal	8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    800000b2:	94ce                	add	s1,s1,s3
    800000b4:	fe997be3          	bgeu	s2,s1,800000aa <freerange+0x2a>
    800000b8:	6942                	ld	s2,16(sp)
    800000ba:	69a2                	ld	s3,8(sp)
    800000bc:	6a02                	ld	s4,0(sp)
}
    800000be:	70a2                	ld	ra,40(sp)
    800000c0:	7402                	ld	s0,32(sp)
    800000c2:	64e2                	ld	s1,24(sp)
    800000c4:	6145                	addi	sp,sp,48
    800000c6:	8082                	ret

00000000800000c8 <kinit>:
{
    800000c8:	1141                	addi	sp,sp,-16
    800000ca:	e406                	sd	ra,8(sp)
    800000cc:	e022                	sd	s0,0(sp)
    800000ce:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d0:	00007597          	auipc	a1,0x7
    800000d4:	f4058593          	addi	a1,a1,-192 # 80007010 <etext+0x10>
    800000d8:	00008517          	auipc	a0,0x8
    800000dc:	9b850513          	addi	a0,a0,-1608 # 80007a90 <kmem>
    800000e0:	6a2050ef          	jal	80005782 <initlock>
  freerange(end, (void*)PHYSTOP);
    800000e4:	45c5                	li	a1,17
    800000e6:	05ee                	slli	a1,a1,0x1b
    800000e8:	00021517          	auipc	a0,0x21
    800000ec:	ed850513          	addi	a0,a0,-296 # 80020fc0 <end>
    800000f0:	f91ff0ef          	jal	80000080 <freerange>
}
    800000f4:	60a2                	ld	ra,8(sp)
    800000f6:	6402                	ld	s0,0(sp)
    800000f8:	0141                	addi	sp,sp,16
    800000fa:	8082                	ret

00000000800000fc <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    800000fc:	1101                	addi	sp,sp,-32
    800000fe:	ec06                	sd	ra,24(sp)
    80000100:	e822                	sd	s0,16(sp)
    80000102:	e426                	sd	s1,8(sp)
    80000104:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000106:	00008517          	auipc	a0,0x8
    8000010a:	98a50513          	addi	a0,a0,-1654 # 80007a90 <kmem>
    8000010e:	6fe050ef          	jal	8000580c <acquire>
  r = kmem.freelist;
    80000112:	00008497          	auipc	s1,0x8
    80000116:	9964b483          	ld	s1,-1642(s1) # 80007aa8 <kmem+0x18>
  if(r) {
    8000011a:	c491                	beqz	s1,80000126 <kalloc+0x2a>
    kmem.freelist = r->next;
    8000011c:	609c                	ld	a5,0(s1)
    8000011e:	00008717          	auipc	a4,0x8
    80000122:	98f73523          	sd	a5,-1654(a4) # 80007aa8 <kmem+0x18>
  }
  release(&kmem.lock);
    80000126:	00008517          	auipc	a0,0x8
    8000012a:	96a50513          	addi	a0,a0,-1686 # 80007a90 <kmem>
    8000012e:	772050ef          	jal	800058a0 <release>
#ifndef LAB_SYSCALL
  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
#endif
  return (void*)r;
}
    80000132:	8526                	mv	a0,s1
    80000134:	60e2                	ld	ra,24(sp)
    80000136:	6442                	ld	s0,16(sp)
    80000138:	64a2                	ld	s1,8(sp)
    8000013a:	6105                	addi	sp,sp,32
    8000013c:	8082                	ret

000000008000013e <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000013e:	1141                	addi	sp,sp,-16
    80000140:	e406                	sd	ra,8(sp)
    80000142:	e022                	sd	s0,0(sp)
    80000144:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000146:	ca19                	beqz	a2,8000015c <memset+0x1e>
    80000148:	87aa                	mv	a5,a0
    8000014a:	1602                	slli	a2,a2,0x20
    8000014c:	9201                	srli	a2,a2,0x20
    8000014e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000152:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000156:	0785                	addi	a5,a5,1
    80000158:	fee79de3          	bne	a5,a4,80000152 <memset+0x14>
  }
  return dst;
}
    8000015c:	60a2                	ld	ra,8(sp)
    8000015e:	6402                	ld	s0,0(sp)
    80000160:	0141                	addi	sp,sp,16
    80000162:	8082                	ret

0000000080000164 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000164:	1141                	addi	sp,sp,-16
    80000166:	e406                	sd	ra,8(sp)
    80000168:	e022                	sd	s0,0(sp)
    8000016a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    8000016c:	c61d                	beqz	a2,8000019a <memcmp+0x36>
    8000016e:	1602                	slli	a2,a2,0x20
    80000170:	9201                	srli	a2,a2,0x20
    80000172:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000176:	00054783          	lbu	a5,0(a0)
    8000017a:	0005c703          	lbu	a4,0(a1)
    8000017e:	00e79863          	bne	a5,a4,8000018e <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000182:	0505                	addi	a0,a0,1
    80000184:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000186:	fed518e3          	bne	a0,a3,80000176 <memcmp+0x12>
  }

  return 0;
    8000018a:	4501                	li	a0,0
    8000018c:	a019                	j	80000192 <memcmp+0x2e>
      return *s1 - *s2;
    8000018e:	40e7853b          	subw	a0,a5,a4
}
    80000192:	60a2                	ld	ra,8(sp)
    80000194:	6402                	ld	s0,0(sp)
    80000196:	0141                	addi	sp,sp,16
    80000198:	8082                	ret
  return 0;
    8000019a:	4501                	li	a0,0
    8000019c:	bfdd                	j	80000192 <memcmp+0x2e>

000000008000019e <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    8000019e:	1141                	addi	sp,sp,-16
    800001a0:	e406                	sd	ra,8(sp)
    800001a2:	e022                	sd	s0,0(sp)
    800001a4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001a6:	c205                	beqz	a2,800001c6 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001a8:	02a5e363          	bltu	a1,a0,800001ce <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001ac:	1602                	slli	a2,a2,0x20
    800001ae:	9201                	srli	a2,a2,0x20
    800001b0:	00c587b3          	add	a5,a1,a2
{
    800001b4:	872a                	mv	a4,a0
      *d++ = *s++;
    800001b6:	0585                	addi	a1,a1,1
    800001b8:	0705                	addi	a4,a4,1
    800001ba:	fff5c683          	lbu	a3,-1(a1)
    800001be:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001c2:	feb79ae3          	bne	a5,a1,800001b6 <memmove+0x18>

  return dst;
}
    800001c6:	60a2                	ld	ra,8(sp)
    800001c8:	6402                	ld	s0,0(sp)
    800001ca:	0141                	addi	sp,sp,16
    800001cc:	8082                	ret
  if(s < d && s + n > d){
    800001ce:	02061693          	slli	a3,a2,0x20
    800001d2:	9281                	srli	a3,a3,0x20
    800001d4:	00d58733          	add	a4,a1,a3
    800001d8:	fce57ae3          	bgeu	a0,a4,800001ac <memmove+0xe>
    d += n;
    800001dc:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001de:	fff6079b          	addiw	a5,a2,-1
    800001e2:	1782                	slli	a5,a5,0x20
    800001e4:	9381                	srli	a5,a5,0x20
    800001e6:	fff7c793          	not	a5,a5
    800001ea:	97ba                	add	a5,a5,a4
      *--d = *--s;
    800001ec:	177d                	addi	a4,a4,-1
    800001ee:	16fd                	addi	a3,a3,-1
    800001f0:	00074603          	lbu	a2,0(a4)
    800001f4:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    800001f8:	fee79ae3          	bne	a5,a4,800001ec <memmove+0x4e>
    800001fc:	b7e9                	j	800001c6 <memmove+0x28>

00000000800001fe <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    800001fe:	1141                	addi	sp,sp,-16
    80000200:	e406                	sd	ra,8(sp)
    80000202:	e022                	sd	s0,0(sp)
    80000204:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000206:	f99ff0ef          	jal	8000019e <memmove>
}
    8000020a:	60a2                	ld	ra,8(sp)
    8000020c:	6402                	ld	s0,0(sp)
    8000020e:	0141                	addi	sp,sp,16
    80000210:	8082                	ret

0000000080000212 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000212:	1141                	addi	sp,sp,-16
    80000214:	e406                	sd	ra,8(sp)
    80000216:	e022                	sd	s0,0(sp)
    80000218:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000021a:	ce11                	beqz	a2,80000236 <strncmp+0x24>
    8000021c:	00054783          	lbu	a5,0(a0)
    80000220:	cf89                	beqz	a5,8000023a <strncmp+0x28>
    80000222:	0005c703          	lbu	a4,0(a1)
    80000226:	00f71a63          	bne	a4,a5,8000023a <strncmp+0x28>
    n--, p++, q++;
    8000022a:	367d                	addiw	a2,a2,-1
    8000022c:	0505                	addi	a0,a0,1
    8000022e:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000230:	f675                	bnez	a2,8000021c <strncmp+0xa>
  if(n == 0)
    return 0;
    80000232:	4501                	li	a0,0
    80000234:	a801                	j	80000244 <strncmp+0x32>
    80000236:	4501                	li	a0,0
    80000238:	a031                	j	80000244 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    8000023a:	00054503          	lbu	a0,0(a0)
    8000023e:	0005c783          	lbu	a5,0(a1)
    80000242:	9d1d                	subw	a0,a0,a5
}
    80000244:	60a2                	ld	ra,8(sp)
    80000246:	6402                	ld	s0,0(sp)
    80000248:	0141                	addi	sp,sp,16
    8000024a:	8082                	ret

000000008000024c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    8000024c:	1141                	addi	sp,sp,-16
    8000024e:	e406                	sd	ra,8(sp)
    80000250:	e022                	sd	s0,0(sp)
    80000252:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000254:	87aa                	mv	a5,a0
    80000256:	a011                	j	8000025a <strncpy+0xe>
    80000258:	8636                	mv	a2,a3
    8000025a:	02c05863          	blez	a2,8000028a <strncpy+0x3e>
    8000025e:	fff6069b          	addiw	a3,a2,-1
    80000262:	8836                	mv	a6,a3
    80000264:	0785                	addi	a5,a5,1
    80000266:	0005c703          	lbu	a4,0(a1)
    8000026a:	fee78fa3          	sb	a4,-1(a5)
    8000026e:	0585                	addi	a1,a1,1
    80000270:	f765                	bnez	a4,80000258 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000272:	873e                	mv	a4,a5
    80000274:	01005b63          	blez	a6,8000028a <strncpy+0x3e>
    80000278:	9fb1                	addw	a5,a5,a2
    8000027a:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    8000027c:	0705                	addi	a4,a4,1
    8000027e:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000282:	40e786bb          	subw	a3,a5,a4
    80000286:	fed04be3          	bgtz	a3,8000027c <strncpy+0x30>
  return os;
}
    8000028a:	60a2                	ld	ra,8(sp)
    8000028c:	6402                	ld	s0,0(sp)
    8000028e:	0141                	addi	sp,sp,16
    80000290:	8082                	ret

0000000080000292 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000292:	1141                	addi	sp,sp,-16
    80000294:	e406                	sd	ra,8(sp)
    80000296:	e022                	sd	s0,0(sp)
    80000298:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    8000029a:	02c05363          	blez	a2,800002c0 <safestrcpy+0x2e>
    8000029e:	fff6069b          	addiw	a3,a2,-1
    800002a2:	1682                	slli	a3,a3,0x20
    800002a4:	9281                	srli	a3,a3,0x20
    800002a6:	96ae                	add	a3,a3,a1
    800002a8:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002aa:	00d58963          	beq	a1,a3,800002bc <safestrcpy+0x2a>
    800002ae:	0585                	addi	a1,a1,1
    800002b0:	0785                	addi	a5,a5,1
    800002b2:	fff5c703          	lbu	a4,-1(a1)
    800002b6:	fee78fa3          	sb	a4,-1(a5)
    800002ba:	fb65                	bnez	a4,800002aa <safestrcpy+0x18>
    ;
  *s = 0;
    800002bc:	00078023          	sb	zero,0(a5)
  return os;
}
    800002c0:	60a2                	ld	ra,8(sp)
    800002c2:	6402                	ld	s0,0(sp)
    800002c4:	0141                	addi	sp,sp,16
    800002c6:	8082                	ret

00000000800002c8 <strlen>:

int
strlen(const char *s)
{
    800002c8:	1141                	addi	sp,sp,-16
    800002ca:	e406                	sd	ra,8(sp)
    800002cc:	e022                	sd	s0,0(sp)
    800002ce:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002d0:	00054783          	lbu	a5,0(a0)
    800002d4:	cf91                	beqz	a5,800002f0 <strlen+0x28>
    800002d6:	00150793          	addi	a5,a0,1
    800002da:	86be                	mv	a3,a5
    800002dc:	0785                	addi	a5,a5,1
    800002de:	fff7c703          	lbu	a4,-1(a5)
    800002e2:	ff65                	bnez	a4,800002da <strlen+0x12>
    800002e4:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    800002e8:	60a2                	ld	ra,8(sp)
    800002ea:	6402                	ld	s0,0(sp)
    800002ec:	0141                	addi	sp,sp,16
    800002ee:	8082                	ret
  for(n = 0; s[n]; n++)
    800002f0:	4501                	li	a0,0
    800002f2:	bfdd                	j	800002e8 <strlen+0x20>

00000000800002f4 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    800002f4:	1141                	addi	sp,sp,-16
    800002f6:	e406                	sd	ra,8(sp)
    800002f8:	e022                	sd	s0,0(sp)
    800002fa:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800002fc:	23b000ef          	jal	80000d36 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000300:	00007717          	auipc	a4,0x7
    80000304:	76070713          	addi	a4,a4,1888 # 80007a60 <started>
  if(cpuid() == 0){
    80000308:	c51d                	beqz	a0,80000336 <main+0x42>
    while(started == 0)
    8000030a:	431c                	lw	a5,0(a4)
    8000030c:	2781                	sext.w	a5,a5
    8000030e:	dff5                	beqz	a5,8000030a <main+0x16>
      ;
    __sync_synchronize();
    80000310:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000314:	223000ef          	jal	80000d36 <cpuid>
    80000318:	85aa                	mv	a1,a0
    8000031a:	00007517          	auipc	a0,0x7
    8000031e:	d1e50513          	addi	a0,a0,-738 # 80007038 <etext+0x38>
    80000322:	69d040ef          	jal	800051be <printf>
    kvminithart();    // turn on paging
    80000326:	080000ef          	jal	800003a6 <kvminithart>
    trapinithart();   // install kernel trap vector
    8000032a:	53a010ef          	jal	80001864 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    8000032e:	46a040ef          	jal	80004798 <plicinithart>
  }

  scheduler();        
    80000332:	677000ef          	jal	800011a8 <scheduler>
    consoleinit();
    80000336:	5af040ef          	jal	800050e4 <consoleinit>
    printfinit();
    8000033a:	1ce050ef          	jal	80005508 <printfinit>
    printf("\n");
    8000033e:	00007517          	auipc	a0,0x7
    80000342:	cda50513          	addi	a0,a0,-806 # 80007018 <etext+0x18>
    80000346:	679040ef          	jal	800051be <printf>
    printf("xv6 kernel is booting\n");
    8000034a:	00007517          	auipc	a0,0x7
    8000034e:	cd650513          	addi	a0,a0,-810 # 80007020 <etext+0x20>
    80000352:	66d040ef          	jal	800051be <printf>
    printf("\n");
    80000356:	00007517          	auipc	a0,0x7
    8000035a:	cc250513          	addi	a0,a0,-830 # 80007018 <etext+0x18>
    8000035e:	661040ef          	jal	800051be <printf>
    kinit();         // physical page allocator
    80000362:	d67ff0ef          	jal	800000c8 <kinit>
    kvminit();       // create kernel page table
    80000366:	2cc000ef          	jal	80000632 <kvminit>
    kvminithart();   // turn on paging
    8000036a:	03c000ef          	jal	800003a6 <kvminithart>
    procinit();      // process table
    8000036e:	113000ef          	jal	80000c80 <procinit>
    trapinit();      // trap vectors
    80000372:	4ce010ef          	jal	80001840 <trapinit>
    trapinithart();  // install kernel trap vector
    80000376:	4ee010ef          	jal	80001864 <trapinithart>
    plicinit();      // set up interrupt controller
    8000037a:	404040ef          	jal	8000477e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    8000037e:	41a040ef          	jal	80004798 <plicinithart>
    binit();         // buffer cache
    80000382:	379010ef          	jal	80001efa <binit>
    iinit();         // inode table
    80000386:	134020ef          	jal	800024ba <iinit>
    fileinit();      // file table
    8000038a:	71b020ef          	jal	800032a4 <fileinit>
    virtio_disk_init(); // emulated hard disk
    8000038e:	4fa040ef          	jal	80004888 <virtio_disk_init>
    userinit();      // first user process
    80000392:	443000ef          	jal	80000fd4 <userinit>
    __sync_synchronize();
    80000396:	0330000f          	fence	rw,rw
    started = 1;
    8000039a:	4785                	li	a5,1
    8000039c:	00007717          	auipc	a4,0x7
    800003a0:	6cf72223          	sw	a5,1732(a4) # 80007a60 <started>
    800003a4:	b779                	j	80000332 <main+0x3e>

00000000800003a6 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    800003a6:	1141                	addi	sp,sp,-16
    800003a8:	e406                	sd	ra,8(sp)
    800003aa:	e022                	sd	s0,0(sp)
    800003ac:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800003ae:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    800003b2:	00007797          	auipc	a5,0x7
    800003b6:	6b67b783          	ld	a5,1718(a5) # 80007a68 <kernel_pagetable>
    800003ba:	83b1                	srli	a5,a5,0xc
    800003bc:	577d                	li	a4,-1
    800003be:	177e                	slli	a4,a4,0x3f
    800003c0:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800003c2:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800003c6:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    800003ca:	60a2                	ld	ra,8(sp)
    800003cc:	6402                	ld	s0,0(sp)
    800003ce:	0141                	addi	sp,sp,16
    800003d0:	8082                	ret

00000000800003d2 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800003d2:	7139                	addi	sp,sp,-64
    800003d4:	fc06                	sd	ra,56(sp)
    800003d6:	f822                	sd	s0,48(sp)
    800003d8:	f426                	sd	s1,40(sp)
    800003da:	f04a                	sd	s2,32(sp)
    800003dc:	ec4e                	sd	s3,24(sp)
    800003de:	e852                	sd	s4,16(sp)
    800003e0:	e456                	sd	s5,8(sp)
    800003e2:	e05a                	sd	s6,0(sp)
    800003e4:	0080                	addi	s0,sp,64
    800003e6:	84aa                	mv	s1,a0
    800003e8:	89ae                	mv	s3,a1
    800003ea:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    800003ec:	57fd                	li	a5,-1
    800003ee:	83e9                	srli	a5,a5,0x1a
    800003f0:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    800003f2:	4ab1                	li	s5,12
  if(va >= MAXVA)
    800003f4:	04b7e263          	bltu	a5,a1,80000438 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    800003f8:	0149d933          	srl	s2,s3,s4
    800003fc:	1ff97913          	andi	s2,s2,511
    80000400:	090e                	slli	s2,s2,0x3
    80000402:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000404:	00093483          	ld	s1,0(s2)
    80000408:	0014f793          	andi	a5,s1,1
    8000040c:	cf85                	beqz	a5,80000444 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    8000040e:	80a9                	srli	s1,s1,0xa
    80000410:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80000412:	3a5d                	addiw	s4,s4,-9
    80000414:	ff5a12e3          	bne	s4,s5,800003f8 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000418:	00c9d513          	srli	a0,s3,0xc
    8000041c:	1ff57513          	andi	a0,a0,511
    80000420:	050e                	slli	a0,a0,0x3
    80000422:	9526                	add	a0,a0,s1
}
    80000424:	70e2                	ld	ra,56(sp)
    80000426:	7442                	ld	s0,48(sp)
    80000428:	74a2                	ld	s1,40(sp)
    8000042a:	7902                	ld	s2,32(sp)
    8000042c:	69e2                	ld	s3,24(sp)
    8000042e:	6a42                	ld	s4,16(sp)
    80000430:	6aa2                	ld	s5,8(sp)
    80000432:	6b02                	ld	s6,0(sp)
    80000434:	6121                	addi	sp,sp,64
    80000436:	8082                	ret
    panic("walk");
    80000438:	00007517          	auipc	a0,0x7
    8000043c:	c1850513          	addi	a0,a0,-1000 # 80007050 <etext+0x50>
    80000440:	08e050ef          	jal	800054ce <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000444:	020b0263          	beqz	s6,80000468 <walk+0x96>
    80000448:	cb5ff0ef          	jal	800000fc <kalloc>
    8000044c:	84aa                	mv	s1,a0
    8000044e:	d979                	beqz	a0,80000424 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80000450:	6605                	lui	a2,0x1
    80000452:	4581                	li	a1,0
    80000454:	cebff0ef          	jal	8000013e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000458:	00c4d793          	srli	a5,s1,0xc
    8000045c:	07aa                	slli	a5,a5,0xa
    8000045e:	0017e793          	ori	a5,a5,1
    80000462:	00f93023          	sd	a5,0(s2)
    80000466:	b775                	j	80000412 <walk+0x40>
        return 0;
    80000468:	4501                	li	a0,0
    8000046a:	bf6d                	j	80000424 <walk+0x52>

000000008000046c <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000046c:	57fd                	li	a5,-1
    8000046e:	83e9                	srli	a5,a5,0x1a
    80000470:	00b7f463          	bgeu	a5,a1,80000478 <walkaddr+0xc>
    return 0;
    80000474:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000476:	8082                	ret
{
    80000478:	1141                	addi	sp,sp,-16
    8000047a:	e406                	sd	ra,8(sp)
    8000047c:	e022                	sd	s0,0(sp)
    8000047e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000480:	4601                	li	a2,0
    80000482:	f51ff0ef          	jal	800003d2 <walk>
  if(pte == 0)
    80000486:	c901                	beqz	a0,80000496 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    80000488:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000048a:	0117f693          	andi	a3,a5,17
    8000048e:	4745                	li	a4,17
    return 0;
    80000490:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000492:	00e68663          	beq	a3,a4,8000049e <walkaddr+0x32>
}
    80000496:	60a2                	ld	ra,8(sp)
    80000498:	6402                	ld	s0,0(sp)
    8000049a:	0141                	addi	sp,sp,16
    8000049c:	8082                	ret
  pa = PTE2PA(*pte);
    8000049e:	83a9                	srli	a5,a5,0xa
    800004a0:	00c79513          	slli	a0,a5,0xc
  return pa;
    800004a4:	bfcd                	j	80000496 <walkaddr+0x2a>

00000000800004a6 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800004a6:	715d                	addi	sp,sp,-80
    800004a8:	e486                	sd	ra,72(sp)
    800004aa:	e0a2                	sd	s0,64(sp)
    800004ac:	fc26                	sd	s1,56(sp)
    800004ae:	f84a                	sd	s2,48(sp)
    800004b0:	f44e                	sd	s3,40(sp)
    800004b2:	f052                	sd	s4,32(sp)
    800004b4:	ec56                	sd	s5,24(sp)
    800004b6:	e85a                	sd	s6,16(sp)
    800004b8:	e45e                	sd	s7,8(sp)
    800004ba:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800004bc:	03459793          	slli	a5,a1,0x34
    800004c0:	eba1                	bnez	a5,80000510 <mappages+0x6a>
    800004c2:	8a2a                	mv	s4,a0
    800004c4:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800004c6:	03461793          	slli	a5,a2,0x34
    800004ca:	eba9                	bnez	a5,8000051c <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    800004cc:	ce31                	beqz	a2,80000528 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800004ce:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    800004d2:	80060613          	addi	a2,a2,-2048
    800004d6:	00b60933          	add	s2,a2,a1
  a = va;
    800004da:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800004dc:	4b05                	li	s6,1
    800004de:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800004e2:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    800004e4:	865a                	mv	a2,s6
    800004e6:	85a6                	mv	a1,s1
    800004e8:	8552                	mv	a0,s4
    800004ea:	ee9ff0ef          	jal	800003d2 <walk>
    800004ee:	c929                	beqz	a0,80000540 <mappages+0x9a>
    if(*pte & PTE_V)
    800004f0:	611c                	ld	a5,0(a0)
    800004f2:	8b85                	andi	a5,a5,1
    800004f4:	e3a1                	bnez	a5,80000534 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800004f6:	013487b3          	add	a5,s1,s3
    800004fa:	83b1                	srli	a5,a5,0xc
    800004fc:	07aa                	slli	a5,a5,0xa
    800004fe:	0157e7b3          	or	a5,a5,s5
    80000502:	0017e793          	ori	a5,a5,1
    80000506:	e11c                	sd	a5,0(a0)
    if(a == last)
    80000508:	05248863          	beq	s1,s2,80000558 <mappages+0xb2>
    a += PGSIZE;
    8000050c:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    8000050e:	bfd9                	j	800004e4 <mappages+0x3e>
    panic("mappages: va not aligned");
    80000510:	00007517          	auipc	a0,0x7
    80000514:	b4850513          	addi	a0,a0,-1208 # 80007058 <etext+0x58>
    80000518:	7b7040ef          	jal	800054ce <panic>
    panic("mappages: size not aligned");
    8000051c:	00007517          	auipc	a0,0x7
    80000520:	b5c50513          	addi	a0,a0,-1188 # 80007078 <etext+0x78>
    80000524:	7ab040ef          	jal	800054ce <panic>
    panic("mappages: size");
    80000528:	00007517          	auipc	a0,0x7
    8000052c:	b7050513          	addi	a0,a0,-1168 # 80007098 <etext+0x98>
    80000530:	79f040ef          	jal	800054ce <panic>
      panic("mappages: remap");
    80000534:	00007517          	auipc	a0,0x7
    80000538:	b7450513          	addi	a0,a0,-1164 # 800070a8 <etext+0xa8>
    8000053c:	793040ef          	jal	800054ce <panic>
      return -1;
    80000540:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80000542:	60a6                	ld	ra,72(sp)
    80000544:	6406                	ld	s0,64(sp)
    80000546:	74e2                	ld	s1,56(sp)
    80000548:	7942                	ld	s2,48(sp)
    8000054a:	79a2                	ld	s3,40(sp)
    8000054c:	7a02                	ld	s4,32(sp)
    8000054e:	6ae2                	ld	s5,24(sp)
    80000550:	6b42                	ld	s6,16(sp)
    80000552:	6ba2                	ld	s7,8(sp)
    80000554:	6161                	addi	sp,sp,80
    80000556:	8082                	ret
  return 0;
    80000558:	4501                	li	a0,0
    8000055a:	b7e5                	j	80000542 <mappages+0x9c>

000000008000055c <kvmmap>:
{
    8000055c:	1141                	addi	sp,sp,-16
    8000055e:	e406                	sd	ra,8(sp)
    80000560:	e022                	sd	s0,0(sp)
    80000562:	0800                	addi	s0,sp,16
    80000564:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000566:	86b2                	mv	a3,a2
    80000568:	863e                	mv	a2,a5
    8000056a:	f3dff0ef          	jal	800004a6 <mappages>
    8000056e:	e509                	bnez	a0,80000578 <kvmmap+0x1c>
}
    80000570:	60a2                	ld	ra,8(sp)
    80000572:	6402                	ld	s0,0(sp)
    80000574:	0141                	addi	sp,sp,16
    80000576:	8082                	ret
    panic("kvmmap");
    80000578:	00007517          	auipc	a0,0x7
    8000057c:	b4050513          	addi	a0,a0,-1216 # 800070b8 <etext+0xb8>
    80000580:	74f040ef          	jal	800054ce <panic>

0000000080000584 <kvmmake>:
{
    80000584:	1101                	addi	sp,sp,-32
    80000586:	ec06                	sd	ra,24(sp)
    80000588:	e822                	sd	s0,16(sp)
    8000058a:	e426                	sd	s1,8(sp)
    8000058c:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000058e:	b6fff0ef          	jal	800000fc <kalloc>
    80000592:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80000594:	6605                	lui	a2,0x1
    80000596:	4581                	li	a1,0
    80000598:	ba7ff0ef          	jal	8000013e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000059c:	4719                	li	a4,6
    8000059e:	6685                	lui	a3,0x1
    800005a0:	10000637          	lui	a2,0x10000
    800005a4:	85b2                	mv	a1,a2
    800005a6:	8526                	mv	a0,s1
    800005a8:	fb5ff0ef          	jal	8000055c <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800005ac:	4719                	li	a4,6
    800005ae:	6685                	lui	a3,0x1
    800005b0:	10001637          	lui	a2,0x10001
    800005b4:	85b2                	mv	a1,a2
    800005b6:	8526                	mv	a0,s1
    800005b8:	fa5ff0ef          	jal	8000055c <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800005bc:	4719                	li	a4,6
    800005be:	040006b7          	lui	a3,0x4000
    800005c2:	0c000637          	lui	a2,0xc000
    800005c6:	85b2                	mv	a1,a2
    800005c8:	8526                	mv	a0,s1
    800005ca:	f93ff0ef          	jal	8000055c <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800005ce:	4729                	li	a4,10
    800005d0:	80007697          	auipc	a3,0x80007
    800005d4:	a3068693          	addi	a3,a3,-1488 # 7000 <_entry-0x7fff9000>
    800005d8:	4605                	li	a2,1
    800005da:	067e                	slli	a2,a2,0x1f
    800005dc:	85b2                	mv	a1,a2
    800005de:	8526                	mv	a0,s1
    800005e0:	f7dff0ef          	jal	8000055c <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800005e4:	4719                	li	a4,6
    800005e6:	00007697          	auipc	a3,0x7
    800005ea:	a1a68693          	addi	a3,a3,-1510 # 80007000 <etext>
    800005ee:	47c5                	li	a5,17
    800005f0:	07ee                	slli	a5,a5,0x1b
    800005f2:	40d786b3          	sub	a3,a5,a3
    800005f6:	00007617          	auipc	a2,0x7
    800005fa:	a0a60613          	addi	a2,a2,-1526 # 80007000 <etext>
    800005fe:	85b2                	mv	a1,a2
    80000600:	8526                	mv	a0,s1
    80000602:	f5bff0ef          	jal	8000055c <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80000606:	4729                	li	a4,10
    80000608:	6685                	lui	a3,0x1
    8000060a:	00006617          	auipc	a2,0x6
    8000060e:	9f660613          	addi	a2,a2,-1546 # 80006000 <_trampoline>
    80000612:	040005b7          	lui	a1,0x4000
    80000616:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000618:	05b2                	slli	a1,a1,0xc
    8000061a:	8526                	mv	a0,s1
    8000061c:	f41ff0ef          	jal	8000055c <kvmmap>
  proc_mapstacks(kpgtbl);
    80000620:	8526                	mv	a0,s1
    80000622:	5ba000ef          	jal	80000bdc <proc_mapstacks>
}
    80000626:	8526                	mv	a0,s1
    80000628:	60e2                	ld	ra,24(sp)
    8000062a:	6442                	ld	s0,16(sp)
    8000062c:	64a2                	ld	s1,8(sp)
    8000062e:	6105                	addi	sp,sp,32
    80000630:	8082                	ret

0000000080000632 <kvminit>:
{
    80000632:	1141                	addi	sp,sp,-16
    80000634:	e406                	sd	ra,8(sp)
    80000636:	e022                	sd	s0,0(sp)
    80000638:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000063a:	f4bff0ef          	jal	80000584 <kvmmake>
    8000063e:	00007797          	auipc	a5,0x7
    80000642:	42a7b523          	sd	a0,1066(a5) # 80007a68 <kernel_pagetable>
}
    80000646:	60a2                	ld	ra,8(sp)
    80000648:	6402                	ld	s0,0(sp)
    8000064a:	0141                	addi	sp,sp,16
    8000064c:	8082                	ret

000000008000064e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000064e:	715d                	addi	sp,sp,-80
    80000650:	e486                	sd	ra,72(sp)
    80000652:	e0a2                	sd	s0,64(sp)
    80000654:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;
  int sz;

  if((va % PGSIZE) != 0)
    80000656:	03459793          	slli	a5,a1,0x34
    8000065a:	e39d                	bnez	a5,80000680 <uvmunmap+0x32>
    8000065c:	f84a                	sd	s2,48(sp)
    8000065e:	f44e                	sd	s3,40(sp)
    80000660:	f052                	sd	s4,32(sp)
    80000662:	ec56                	sd	s5,24(sp)
    80000664:	e85a                	sd	s6,16(sp)
    80000666:	e45e                	sd	s7,8(sp)
    80000668:	8a2a                	mv	s4,a0
    8000066a:	892e                	mv	s2,a1
    8000066c:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += sz){
    8000066e:	0632                	slli	a2,a2,0xc
    80000670:	00b609b3          	add	s3,a2,a1
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0) {
      printf("va=%ld pte=%ld\n", a, *pte);
      panic("uvmunmap: not mapped");
    }
    if(PTE_FLAGS(*pte) == PTE_V)
    80000674:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += sz){
    80000676:	6b05                	lui	s6,0x1
    80000678:	0935f763          	bgeu	a1,s3,80000706 <uvmunmap+0xb8>
    8000067c:	fc26                	sd	s1,56(sp)
    8000067e:	a8a1                	j	800006d6 <uvmunmap+0x88>
    80000680:	fc26                	sd	s1,56(sp)
    80000682:	f84a                	sd	s2,48(sp)
    80000684:	f44e                	sd	s3,40(sp)
    80000686:	f052                	sd	s4,32(sp)
    80000688:	ec56                	sd	s5,24(sp)
    8000068a:	e85a                	sd	s6,16(sp)
    8000068c:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    8000068e:	00007517          	auipc	a0,0x7
    80000692:	a3250513          	addi	a0,a0,-1486 # 800070c0 <etext+0xc0>
    80000696:	639040ef          	jal	800054ce <panic>
      panic("uvmunmap: walk");
    8000069a:	00007517          	auipc	a0,0x7
    8000069e:	a3e50513          	addi	a0,a0,-1474 # 800070d8 <etext+0xd8>
    800006a2:	62d040ef          	jal	800054ce <panic>
      printf("va=%ld pte=%ld\n", a, *pte);
    800006a6:	85ca                	mv	a1,s2
    800006a8:	00007517          	auipc	a0,0x7
    800006ac:	a4050513          	addi	a0,a0,-1472 # 800070e8 <etext+0xe8>
    800006b0:	30f040ef          	jal	800051be <printf>
      panic("uvmunmap: not mapped");
    800006b4:	00007517          	auipc	a0,0x7
    800006b8:	a4450513          	addi	a0,a0,-1468 # 800070f8 <etext+0xf8>
    800006bc:	613040ef          	jal	800054ce <panic>
      panic("uvmunmap: not a leaf");
    800006c0:	00007517          	auipc	a0,0x7
    800006c4:	a5050513          	addi	a0,a0,-1456 # 80007110 <etext+0x110>
    800006c8:	607040ef          	jal	800054ce <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    800006cc:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += sz){
    800006d0:	995a                	add	s2,s2,s6
    800006d2:	03397963          	bgeu	s2,s3,80000704 <uvmunmap+0xb6>
    if((pte = walk(pagetable, a, 0)) == 0)
    800006d6:	4601                	li	a2,0
    800006d8:	85ca                	mv	a1,s2
    800006da:	8552                	mv	a0,s4
    800006dc:	cf7ff0ef          	jal	800003d2 <walk>
    800006e0:	84aa                	mv	s1,a0
    800006e2:	dd45                	beqz	a0,8000069a <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0) {
    800006e4:	6110                	ld	a2,0(a0)
    800006e6:	00167793          	andi	a5,a2,1
    800006ea:	dfd5                	beqz	a5,800006a6 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    800006ec:	3ff67793          	andi	a5,a2,1023
    800006f0:	fd7788e3          	beq	a5,s7,800006c0 <uvmunmap+0x72>
    if(do_free){
    800006f4:	fc0a8ce3          	beqz	s5,800006cc <uvmunmap+0x7e>
      uint64 pa = PTE2PA(*pte);
    800006f8:	8229                	srli	a2,a2,0xa
      kfree((void*)pa);
    800006fa:	00c61513          	slli	a0,a2,0xc
    800006fe:	91fff0ef          	jal	8000001c <kfree>
    80000702:	b7e9                	j	800006cc <uvmunmap+0x7e>
    80000704:	74e2                	ld	s1,56(sp)
    80000706:	7942                	ld	s2,48(sp)
    80000708:	79a2                	ld	s3,40(sp)
    8000070a:	7a02                	ld	s4,32(sp)
    8000070c:	6ae2                	ld	s5,24(sp)
    8000070e:	6b42                	ld	s6,16(sp)
    80000710:	6ba2                	ld	s7,8(sp)
  }
}
    80000712:	60a6                	ld	ra,72(sp)
    80000714:	6406                	ld	s0,64(sp)
    80000716:	6161                	addi	sp,sp,80
    80000718:	8082                	ret

000000008000071a <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000071a:	1101                	addi	sp,sp,-32
    8000071c:	ec06                	sd	ra,24(sp)
    8000071e:	e822                	sd	s0,16(sp)
    80000720:	e426                	sd	s1,8(sp)
    80000722:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80000724:	9d9ff0ef          	jal	800000fc <kalloc>
    80000728:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000072a:	c509                	beqz	a0,80000734 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000072c:	6605                	lui	a2,0x1
    8000072e:	4581                	li	a1,0
    80000730:	a0fff0ef          	jal	8000013e <memset>
  return pagetable;
}
    80000734:	8526                	mv	a0,s1
    80000736:	60e2                	ld	ra,24(sp)
    80000738:	6442                	ld	s0,16(sp)
    8000073a:	64a2                	ld	s1,8(sp)
    8000073c:	6105                	addi	sp,sp,32
    8000073e:	8082                	ret

0000000080000740 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80000740:	7179                	addi	sp,sp,-48
    80000742:	f406                	sd	ra,40(sp)
    80000744:	f022                	sd	s0,32(sp)
    80000746:	ec26                	sd	s1,24(sp)
    80000748:	e84a                	sd	s2,16(sp)
    8000074a:	e44e                	sd	s3,8(sp)
    8000074c:	e052                	sd	s4,0(sp)
    8000074e:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80000750:	6785                	lui	a5,0x1
    80000752:	04f67063          	bgeu	a2,a5,80000792 <uvmfirst+0x52>
    80000756:	89aa                	mv	s3,a0
    80000758:	8a2e                	mv	s4,a1
    8000075a:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    8000075c:	9a1ff0ef          	jal	800000fc <kalloc>
    80000760:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000762:	6605                	lui	a2,0x1
    80000764:	4581                	li	a1,0
    80000766:	9d9ff0ef          	jal	8000013e <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    8000076a:	4779                	li	a4,30
    8000076c:	86ca                	mv	a3,s2
    8000076e:	6605                	lui	a2,0x1
    80000770:	4581                	li	a1,0
    80000772:	854e                	mv	a0,s3
    80000774:	d33ff0ef          	jal	800004a6 <mappages>
  memmove(mem, src, sz);
    80000778:	8626                	mv	a2,s1
    8000077a:	85d2                	mv	a1,s4
    8000077c:	854a                	mv	a0,s2
    8000077e:	a21ff0ef          	jal	8000019e <memmove>
}
    80000782:	70a2                	ld	ra,40(sp)
    80000784:	7402                	ld	s0,32(sp)
    80000786:	64e2                	ld	s1,24(sp)
    80000788:	6942                	ld	s2,16(sp)
    8000078a:	69a2                	ld	s3,8(sp)
    8000078c:	6a02                	ld	s4,0(sp)
    8000078e:	6145                	addi	sp,sp,48
    80000790:	8082                	ret
    panic("uvmfirst: more than a page");
    80000792:	00007517          	auipc	a0,0x7
    80000796:	99650513          	addi	a0,a0,-1642 # 80007128 <etext+0x128>
    8000079a:	535040ef          	jal	800054ce <panic>

000000008000079e <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    8000079e:	1101                	addi	sp,sp,-32
    800007a0:	ec06                	sd	ra,24(sp)
    800007a2:	e822                	sd	s0,16(sp)
    800007a4:	e426                	sd	s1,8(sp)
    800007a6:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800007a8:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800007aa:	00b67d63          	bgeu	a2,a1,800007c4 <uvmdealloc+0x26>
    800007ae:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800007b0:	6785                	lui	a5,0x1
    800007b2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800007b4:	00f60733          	add	a4,a2,a5
    800007b8:	76fd                	lui	a3,0xfffff
    800007ba:	8f75                	and	a4,a4,a3
    800007bc:	97ae                	add	a5,a5,a1
    800007be:	8ff5                	and	a5,a5,a3
    800007c0:	00f76863          	bltu	a4,a5,800007d0 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800007c4:	8526                	mv	a0,s1
    800007c6:	60e2                	ld	ra,24(sp)
    800007c8:	6442                	ld	s0,16(sp)
    800007ca:	64a2                	ld	s1,8(sp)
    800007cc:	6105                	addi	sp,sp,32
    800007ce:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800007d0:	8f99                	sub	a5,a5,a4
    800007d2:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800007d4:	4685                	li	a3,1
    800007d6:	0007861b          	sext.w	a2,a5
    800007da:	85ba                	mv	a1,a4
    800007dc:	e73ff0ef          	jal	8000064e <uvmunmap>
    800007e0:	b7d5                	j	800007c4 <uvmdealloc+0x26>

00000000800007e2 <uvmalloc>:
  if(newsz < oldsz)
    800007e2:	08b66d63          	bltu	a2,a1,8000087c <uvmalloc+0x9a>
{
    800007e6:	715d                	addi	sp,sp,-80
    800007e8:	e486                	sd	ra,72(sp)
    800007ea:	e0a2                	sd	s0,64(sp)
    800007ec:	f84a                	sd	s2,48(sp)
    800007ee:	f052                	sd	s4,32(sp)
    800007f0:	ec56                	sd	s5,24(sp)
    800007f2:	e45e                	sd	s7,8(sp)
    800007f4:	0880                	addi	s0,sp,80
    800007f6:	8aaa                	mv	s5,a0
    800007f8:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800007fa:	6785                	lui	a5,0x1
    800007fc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800007fe:	95be                	add	a1,a1,a5
    80000800:	77fd                	lui	a5,0xfffff
    80000802:	00f5f933          	and	s2,a1,a5
    80000806:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += sz){
    80000808:	06c97c63          	bgeu	s2,a2,80000880 <uvmalloc+0x9e>
    8000080c:	fc26                	sd	s1,56(sp)
    8000080e:	f44e                	sd	s3,40(sp)
    80000810:	e85a                	sd	s6,16(sp)
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000812:	0126eb13          	ori	s6,a3,18
    80000816:	6985                	lui	s3,0x1
    mem = kalloc();
    80000818:	8e5ff0ef          	jal	800000fc <kalloc>
    8000081c:	84aa                	mv	s1,a0
    if(mem == 0){
    8000081e:	c10d                	beqz	a0,80000840 <uvmalloc+0x5e>
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000820:	875a                	mv	a4,s6
    80000822:	86aa                	mv	a3,a0
    80000824:	864e                	mv	a2,s3
    80000826:	85ca                	mv	a1,s2
    80000828:	8556                	mv	a0,s5
    8000082a:	c7dff0ef          	jal	800004a6 <mappages>
    8000082e:	e915                	bnez	a0,80000862 <uvmalloc+0x80>
  for(a = oldsz; a < newsz; a += sz){
    80000830:	994e                	add	s2,s2,s3
    80000832:	ff4963e3          	bltu	s2,s4,80000818 <uvmalloc+0x36>
  return newsz;
    80000836:	8552                	mv	a0,s4
    80000838:	74e2                	ld	s1,56(sp)
    8000083a:	79a2                	ld	s3,40(sp)
    8000083c:	6b42                	ld	s6,16(sp)
    8000083e:	a811                	j	80000852 <uvmalloc+0x70>
      uvmdealloc(pagetable, a, oldsz);
    80000840:	865e                	mv	a2,s7
    80000842:	85ca                	mv	a1,s2
    80000844:	8556                	mv	a0,s5
    80000846:	f59ff0ef          	jal	8000079e <uvmdealloc>
      return 0;
    8000084a:	4501                	li	a0,0
    8000084c:	74e2                	ld	s1,56(sp)
    8000084e:	79a2                	ld	s3,40(sp)
    80000850:	6b42                	ld	s6,16(sp)
}
    80000852:	60a6                	ld	ra,72(sp)
    80000854:	6406                	ld	s0,64(sp)
    80000856:	7942                	ld	s2,48(sp)
    80000858:	7a02                	ld	s4,32(sp)
    8000085a:	6ae2                	ld	s5,24(sp)
    8000085c:	6ba2                	ld	s7,8(sp)
    8000085e:	6161                	addi	sp,sp,80
    80000860:	8082                	ret
      kfree(mem);
    80000862:	8526                	mv	a0,s1
    80000864:	fb8ff0ef          	jal	8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80000868:	865e                	mv	a2,s7
    8000086a:	85ca                	mv	a1,s2
    8000086c:	8556                	mv	a0,s5
    8000086e:	f31ff0ef          	jal	8000079e <uvmdealloc>
      return 0;
    80000872:	4501                	li	a0,0
    80000874:	74e2                	ld	s1,56(sp)
    80000876:	79a2                	ld	s3,40(sp)
    80000878:	6b42                	ld	s6,16(sp)
    8000087a:	bfe1                	j	80000852 <uvmalloc+0x70>
    return oldsz;
    8000087c:	852e                	mv	a0,a1
}
    8000087e:	8082                	ret
  return newsz;
    80000880:	8532                	mv	a0,a2
    80000882:	bfc1                	j	80000852 <uvmalloc+0x70>

0000000080000884 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80000884:	7179                	addi	sp,sp,-48
    80000886:	f406                	sd	ra,40(sp)
    80000888:	f022                	sd	s0,32(sp)
    8000088a:	ec26                	sd	s1,24(sp)
    8000088c:	e84a                	sd	s2,16(sp)
    8000088e:	e44e                	sd	s3,8(sp)
    80000890:	1800                	addi	s0,sp,48
    80000892:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    80000894:	84aa                	mv	s1,a0
    80000896:	6905                	lui	s2,0x1
    80000898:	992a                	add	s2,s2,a0
    8000089a:	a811                	j	800008ae <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    8000089c:	00007517          	auipc	a0,0x7
    800008a0:	8ac50513          	addi	a0,a0,-1876 # 80007148 <etext+0x148>
    800008a4:	42b040ef          	jal	800054ce <panic>
  for(int i = 0; i < 512; i++){
    800008a8:	04a1                	addi	s1,s1,8
    800008aa:	03248163          	beq	s1,s2,800008cc <freewalk+0x48>
    pte_t pte = pagetable[i];
    800008ae:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800008b0:	0017f713          	andi	a4,a5,1
    800008b4:	db75                	beqz	a4,800008a8 <freewalk+0x24>
    800008b6:	00e7f713          	andi	a4,a5,14
    800008ba:	f36d                	bnez	a4,8000089c <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800008bc:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800008be:	00c79513          	slli	a0,a5,0xc
    800008c2:	fc3ff0ef          	jal	80000884 <freewalk>
      pagetable[i] = 0;
    800008c6:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800008ca:	bff9                	j	800008a8 <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800008cc:	854e                	mv	a0,s3
    800008ce:	f4eff0ef          	jal	8000001c <kfree>
}
    800008d2:	70a2                	ld	ra,40(sp)
    800008d4:	7402                	ld	s0,32(sp)
    800008d6:	64e2                	ld	s1,24(sp)
    800008d8:	6942                	ld	s2,16(sp)
    800008da:	69a2                	ld	s3,8(sp)
    800008dc:	6145                	addi	sp,sp,48
    800008de:	8082                	ret

00000000800008e0 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800008e0:	1101                	addi	sp,sp,-32
    800008e2:	ec06                	sd	ra,24(sp)
    800008e4:	e822                	sd	s0,16(sp)
    800008e6:	e426                	sd	s1,8(sp)
    800008e8:	1000                	addi	s0,sp,32
    800008ea:	84aa                	mv	s1,a0
  if(sz > 0)
    800008ec:	e989                	bnez	a1,800008fe <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800008ee:	8526                	mv	a0,s1
    800008f0:	f95ff0ef          	jal	80000884 <freewalk>
}
    800008f4:	60e2                	ld	ra,24(sp)
    800008f6:	6442                	ld	s0,16(sp)
    800008f8:	64a2                	ld	s1,8(sp)
    800008fa:	6105                	addi	sp,sp,32
    800008fc:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800008fe:	6785                	lui	a5,0x1
    80000900:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000902:	95be                	add	a1,a1,a5
    80000904:	4685                	li	a3,1
    80000906:	00c5d613          	srli	a2,a1,0xc
    8000090a:	4581                	li	a1,0
    8000090c:	d43ff0ef          	jal	8000064e <uvmunmap>
    80000910:	bff9                	j	800008ee <uvmfree+0xe>

0000000080000912 <uvmcopy>:
  uint64 pa, i;
  uint flags;
  char *mem;
  int szinc;

  for(i = 0; i < sz; i += szinc){
    80000912:	c64d                	beqz	a2,800009bc <uvmcopy+0xaa>
{
    80000914:	715d                	addi	sp,sp,-80
    80000916:	e486                	sd	ra,72(sp)
    80000918:	e0a2                	sd	s0,64(sp)
    8000091a:	fc26                	sd	s1,56(sp)
    8000091c:	f84a                	sd	s2,48(sp)
    8000091e:	f44e                	sd	s3,40(sp)
    80000920:	f052                	sd	s4,32(sp)
    80000922:	ec56                	sd	s5,24(sp)
    80000924:	e85a                	sd	s6,16(sp)
    80000926:	e45e                	sd	s7,8(sp)
    80000928:	0880                	addi	s0,sp,80
    8000092a:	8b2a                	mv	s6,a0
    8000092c:	8aae                	mv	s5,a1
    8000092e:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += szinc){
    80000930:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80000932:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    80000934:	4601                	li	a2,0
    80000936:	85ca                	mv	a1,s2
    80000938:	855a                	mv	a0,s6
    8000093a:	a99ff0ef          	jal	800003d2 <walk>
    8000093e:	cd0d                	beqz	a0,80000978 <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    80000940:	00053b83          	ld	s7,0(a0)
    80000944:	001bf793          	andi	a5,s7,1
    80000948:	cf95                	beqz	a5,80000984 <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    8000094a:	fb2ff0ef          	jal	800000fc <kalloc>
    8000094e:	84aa                	mv	s1,a0
    80000950:	c139                	beqz	a0,80000996 <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    80000952:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80000956:	864e                	mv	a2,s3
    80000958:	05b2                	slli	a1,a1,0xc
    8000095a:	845ff0ef          	jal	8000019e <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    8000095e:	3ffbf713          	andi	a4,s7,1023
    80000962:	86a6                	mv	a3,s1
    80000964:	864e                	mv	a2,s3
    80000966:	85ca                	mv	a1,s2
    80000968:	8556                	mv	a0,s5
    8000096a:	b3dff0ef          	jal	800004a6 <mappages>
    8000096e:	e10d                	bnez	a0,80000990 <uvmcopy+0x7e>
  for(i = 0; i < sz; i += szinc){
    80000970:	994e                	add	s2,s2,s3
    80000972:	fd4961e3          	bltu	s2,s4,80000934 <uvmcopy+0x22>
    80000976:	a805                	j	800009a6 <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    80000978:	00006517          	auipc	a0,0x6
    8000097c:	7e050513          	addi	a0,a0,2016 # 80007158 <etext+0x158>
    80000980:	34f040ef          	jal	800054ce <panic>
      panic("uvmcopy: page not present");
    80000984:	00006517          	auipc	a0,0x6
    80000988:	7f450513          	addi	a0,a0,2036 # 80007178 <etext+0x178>
    8000098c:	343040ef          	jal	800054ce <panic>
      kfree(mem);
    80000990:	8526                	mv	a0,s1
    80000992:	e8aff0ef          	jal	8000001c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80000996:	4685                	li	a3,1
    80000998:	00c95613          	srli	a2,s2,0xc
    8000099c:	4581                	li	a1,0
    8000099e:	8556                	mv	a0,s5
    800009a0:	cafff0ef          	jal	8000064e <uvmunmap>
  return -1;
    800009a4:	557d                	li	a0,-1
}
    800009a6:	60a6                	ld	ra,72(sp)
    800009a8:	6406                	ld	s0,64(sp)
    800009aa:	74e2                	ld	s1,56(sp)
    800009ac:	7942                	ld	s2,48(sp)
    800009ae:	79a2                	ld	s3,40(sp)
    800009b0:	7a02                	ld	s4,32(sp)
    800009b2:	6ae2                	ld	s5,24(sp)
    800009b4:	6b42                	ld	s6,16(sp)
    800009b6:	6ba2                	ld	s7,8(sp)
    800009b8:	6161                	addi	sp,sp,80
    800009ba:	8082                	ret
  return 0;
    800009bc:	4501                	li	a0,0
}
    800009be:	8082                	ret

00000000800009c0 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800009c0:	1141                	addi	sp,sp,-16
    800009c2:	e406                	sd	ra,8(sp)
    800009c4:	e022                	sd	s0,0(sp)
    800009c6:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800009c8:	4601                	li	a2,0
    800009ca:	a09ff0ef          	jal	800003d2 <walk>
  if(pte == 0)
    800009ce:	c901                	beqz	a0,800009de <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800009d0:	611c                	ld	a5,0(a0)
    800009d2:	9bbd                	andi	a5,a5,-17
    800009d4:	e11c                	sd	a5,0(a0)
}
    800009d6:	60a2                	ld	ra,8(sp)
    800009d8:	6402                	ld	s0,0(sp)
    800009da:	0141                	addi	sp,sp,16
    800009dc:	8082                	ret
    panic("uvmclear");
    800009de:	00006517          	auipc	a0,0x6
    800009e2:	7ba50513          	addi	a0,a0,1978 # 80007198 <etext+0x198>
    800009e6:	2e9040ef          	jal	800054ce <panic>

00000000800009ea <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    800009ea:	c2d1                	beqz	a3,80000a6e <copyout+0x84>
{
    800009ec:	711d                	addi	sp,sp,-96
    800009ee:	ec86                	sd	ra,88(sp)
    800009f0:	e8a2                	sd	s0,80(sp)
    800009f2:	e4a6                	sd	s1,72(sp)
    800009f4:	e0ca                	sd	s2,64(sp)
    800009f6:	fc4e                	sd	s3,56(sp)
    800009f8:	f852                	sd	s4,48(sp)
    800009fa:	f456                	sd	s5,40(sp)
    800009fc:	f05a                	sd	s6,32(sp)
    800009fe:	ec5e                	sd	s7,24(sp)
    80000a00:	e862                	sd	s8,16(sp)
    80000a02:	e466                	sd	s9,8(sp)
    80000a04:	1080                	addi	s0,sp,96
    80000a06:	8b2a                	mv	s6,a0
    80000a08:	89ae                	mv	s3,a1
    80000a0a:	8ab2                	mv	s5,a2
    80000a0c:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80000a0e:	7cfd                	lui	s9,0xfffff
    if (va0 >= MAXVA)
    80000a10:	5c7d                	li	s8,-1
    80000a12:	01ac5c13          	srli	s8,s8,0x1a
      return -1;
    
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    80000a16:	6b85                	lui	s7,0x1
    80000a18:	a005                	j	80000a38 <copyout+0x4e>
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000a1a:	412989b3          	sub	s3,s3,s2
    80000a1e:	0004861b          	sext.w	a2,s1
    80000a22:	85d6                	mv	a1,s5
    80000a24:	954e                	add	a0,a0,s3
    80000a26:	f78ff0ef          	jal	8000019e <memmove>

    len -= n;
    80000a2a:	409a0a33          	sub	s4,s4,s1
    src += n;
    80000a2e:	9aa6                	add	s5,s5,s1
    dstva = va0 + PGSIZE;
    80000a30:	017909b3          	add	s3,s2,s7
  while(len > 0){
    80000a34:	020a0b63          	beqz	s4,80000a6a <copyout+0x80>
    va0 = PGROUNDDOWN(dstva);
    80000a38:	0199f933          	and	s2,s3,s9
    if (va0 >= MAXVA)
    80000a3c:	032c6b63          	bltu	s8,s2,80000a72 <copyout+0x88>
    if((pte = walk(pagetable, va0, 0)) == 0) {
    80000a40:	4601                	li	a2,0
    80000a42:	85ca                	mv	a1,s2
    80000a44:	855a                	mv	a0,s6
    80000a46:	98dff0ef          	jal	800003d2 <walk>
    80000a4a:	c131                	beqz	a0,80000a8e <copyout+0xa4>
    if((*pte & PTE_W) == 0)
    80000a4c:	611c                	ld	a5,0(a0)
    80000a4e:	8b91                	andi	a5,a5,4
    80000a50:	c3a9                	beqz	a5,80000a92 <copyout+0xa8>
    pa0 = walkaddr(pagetable, va0);
    80000a52:	85ca                	mv	a1,s2
    80000a54:	855a                	mv	a0,s6
    80000a56:	a17ff0ef          	jal	8000046c <walkaddr>
    if(pa0 == 0)
    80000a5a:	cd15                	beqz	a0,80000a96 <copyout+0xac>
    n = PGSIZE - (dstva - va0);
    80000a5c:	413904b3          	sub	s1,s2,s3
    80000a60:	94de                	add	s1,s1,s7
    if(n > len)
    80000a62:	fa9a7ce3          	bgeu	s4,s1,80000a1a <copyout+0x30>
    80000a66:	84d2                	mv	s1,s4
    80000a68:	bf4d                	j	80000a1a <copyout+0x30>
  }
  return 0;
    80000a6a:	4501                	li	a0,0
    80000a6c:	a021                	j	80000a74 <copyout+0x8a>
    80000a6e:	4501                	li	a0,0
}
    80000a70:	8082                	ret
      return -1;
    80000a72:	557d                	li	a0,-1
}
    80000a74:	60e6                	ld	ra,88(sp)
    80000a76:	6446                	ld	s0,80(sp)
    80000a78:	64a6                	ld	s1,72(sp)
    80000a7a:	6906                	ld	s2,64(sp)
    80000a7c:	79e2                	ld	s3,56(sp)
    80000a7e:	7a42                	ld	s4,48(sp)
    80000a80:	7aa2                	ld	s5,40(sp)
    80000a82:	7b02                	ld	s6,32(sp)
    80000a84:	6be2                	ld	s7,24(sp)
    80000a86:	6c42                	ld	s8,16(sp)
    80000a88:	6ca2                	ld	s9,8(sp)
    80000a8a:	6125                	addi	sp,sp,96
    80000a8c:	8082                	ret
      return -1;
    80000a8e:	557d                	li	a0,-1
    80000a90:	b7d5                	j	80000a74 <copyout+0x8a>
      return -1;
    80000a92:	557d                	li	a0,-1
    80000a94:	b7c5                	j	80000a74 <copyout+0x8a>
      return -1;
    80000a96:	557d                	li	a0,-1
    80000a98:	bff1                	j	80000a74 <copyout+0x8a>

0000000080000a9a <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;
  
  while(len > 0){
    80000a9a:	c6a5                	beqz	a3,80000b02 <copyin+0x68>
{
    80000a9c:	715d                	addi	sp,sp,-80
    80000a9e:	e486                	sd	ra,72(sp)
    80000aa0:	e0a2                	sd	s0,64(sp)
    80000aa2:	fc26                	sd	s1,56(sp)
    80000aa4:	f84a                	sd	s2,48(sp)
    80000aa6:	f44e                	sd	s3,40(sp)
    80000aa8:	f052                	sd	s4,32(sp)
    80000aaa:	ec56                	sd	s5,24(sp)
    80000aac:	e85a                	sd	s6,16(sp)
    80000aae:	e45e                	sd	s7,8(sp)
    80000ab0:	e062                	sd	s8,0(sp)
    80000ab2:	0880                	addi	s0,sp,80
    80000ab4:	8b2a                	mv	s6,a0
    80000ab6:	8a2e                	mv	s4,a1
    80000ab8:	8c32                	mv	s8,a2
    80000aba:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000abc:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000abe:	6a85                	lui	s5,0x1
    80000ac0:	a00d                	j	80000ae2 <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000ac2:	018505b3          	add	a1,a0,s8
    80000ac6:	0004861b          	sext.w	a2,s1
    80000aca:	412585b3          	sub	a1,a1,s2
    80000ace:	8552                	mv	a0,s4
    80000ad0:	eceff0ef          	jal	8000019e <memmove>

    len -= n;
    80000ad4:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000ad8:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000ada:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000ade:	02098063          	beqz	s3,80000afe <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000ae2:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000ae6:	85ca                	mv	a1,s2
    80000ae8:	855a                	mv	a0,s6
    80000aea:	983ff0ef          	jal	8000046c <walkaddr>
    if(pa0 == 0)
    80000aee:	cd01                	beqz	a0,80000b06 <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000af0:	418904b3          	sub	s1,s2,s8
    80000af4:	94d6                	add	s1,s1,s5
    if(n > len)
    80000af6:	fc99f6e3          	bgeu	s3,s1,80000ac2 <copyin+0x28>
    80000afa:	84ce                	mv	s1,s3
    80000afc:	b7d9                	j	80000ac2 <copyin+0x28>
  }
  return 0;
    80000afe:	4501                	li	a0,0
    80000b00:	a021                	j	80000b08 <copyin+0x6e>
    80000b02:	4501                	li	a0,0
}
    80000b04:	8082                	ret
      return -1;
    80000b06:	557d                	li	a0,-1
}
    80000b08:	60a6                	ld	ra,72(sp)
    80000b0a:	6406                	ld	s0,64(sp)
    80000b0c:	74e2                	ld	s1,56(sp)
    80000b0e:	7942                	ld	s2,48(sp)
    80000b10:	79a2                	ld	s3,40(sp)
    80000b12:	7a02                	ld	s4,32(sp)
    80000b14:	6ae2                	ld	s5,24(sp)
    80000b16:	6b42                	ld	s6,16(sp)
    80000b18:	6ba2                	ld	s7,8(sp)
    80000b1a:	6c02                	ld	s8,0(sp)
    80000b1c:	6161                	addi	sp,sp,80
    80000b1e:	8082                	ret

0000000080000b20 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000b20:	cac5                	beqz	a3,80000bd0 <copyinstr+0xb0>
{
    80000b22:	715d                	addi	sp,sp,-80
    80000b24:	e486                	sd	ra,72(sp)
    80000b26:	e0a2                	sd	s0,64(sp)
    80000b28:	fc26                	sd	s1,56(sp)
    80000b2a:	f84a                	sd	s2,48(sp)
    80000b2c:	f44e                	sd	s3,40(sp)
    80000b2e:	f052                	sd	s4,32(sp)
    80000b30:	ec56                	sd	s5,24(sp)
    80000b32:	e85a                	sd	s6,16(sp)
    80000b34:	e45e                	sd	s7,8(sp)
    80000b36:	0880                	addi	s0,sp,80
    80000b38:	8aaa                	mv	s5,a0
    80000b3a:	84ae                	mv	s1,a1
    80000b3c:	8bb2                	mv	s7,a2
    80000b3e:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000b40:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000b42:	6a05                	lui	s4,0x1
    80000b44:	a82d                	j	80000b7e <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000b46:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80000b4a:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000b4c:	0017c793          	xori	a5,a5,1
    80000b50:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000b54:	60a6                	ld	ra,72(sp)
    80000b56:	6406                	ld	s0,64(sp)
    80000b58:	74e2                	ld	s1,56(sp)
    80000b5a:	7942                	ld	s2,48(sp)
    80000b5c:	79a2                	ld	s3,40(sp)
    80000b5e:	7a02                	ld	s4,32(sp)
    80000b60:	6ae2                	ld	s5,24(sp)
    80000b62:	6b42                	ld	s6,16(sp)
    80000b64:	6ba2                	ld	s7,8(sp)
    80000b66:	6161                	addi	sp,sp,80
    80000b68:	8082                	ret
    80000b6a:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80000b6e:	9726                	add	a4,a4,s1
      --max;
    80000b70:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80000b74:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80000b78:	04e58463          	beq	a1,a4,80000bc0 <copyinstr+0xa0>
{
    80000b7c:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80000b7e:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80000b82:	85ca                	mv	a1,s2
    80000b84:	8556                	mv	a0,s5
    80000b86:	8e7ff0ef          	jal	8000046c <walkaddr>
    if(pa0 == 0)
    80000b8a:	cd0d                	beqz	a0,80000bc4 <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80000b8c:	417906b3          	sub	a3,s2,s7
    80000b90:	96d2                	add	a3,a3,s4
    if(n > max)
    80000b92:	00d9f363          	bgeu	s3,a3,80000b98 <copyinstr+0x78>
    80000b96:	86ce                	mv	a3,s3
    while(n > 0){
    80000b98:	ca85                	beqz	a3,80000bc8 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80000b9a:	01750633          	add	a2,a0,s7
    80000b9e:	41260633          	sub	a2,a2,s2
    80000ba2:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80000ba4:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80000ba6:	96a6                	add	a3,a3,s1
    80000ba8:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000baa:	00f60733          	add	a4,a2,a5
    80000bae:	00074703          	lbu	a4,0(a4)
    80000bb2:	db51                	beqz	a4,80000b46 <copyinstr+0x26>
        *dst = *p;
    80000bb4:	00e78023          	sb	a4,0(a5)
      dst++;
    80000bb8:	0785                	addi	a5,a5,1
    while(n > 0){
    80000bba:	fed797e3          	bne	a5,a3,80000ba8 <copyinstr+0x88>
    80000bbe:	b775                	j	80000b6a <copyinstr+0x4a>
    80000bc0:	4781                	li	a5,0
    80000bc2:	b769                	j	80000b4c <copyinstr+0x2c>
      return -1;
    80000bc4:	557d                	li	a0,-1
    80000bc6:	b779                	j	80000b54 <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80000bc8:	6b85                	lui	s7,0x1
    80000bca:	9bca                	add	s7,s7,s2
    80000bcc:	87a6                	mv	a5,s1
    80000bce:	b77d                	j	80000b7c <copyinstr+0x5c>
  int got_null = 0;
    80000bd0:	4781                	li	a5,0
  if(got_null){
    80000bd2:	0017c793          	xori	a5,a5,1
    80000bd6:	40f0053b          	negw	a0,a5
}
    80000bda:	8082                	ret

0000000080000bdc <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000bdc:	715d                	addi	sp,sp,-80
    80000bde:	e486                	sd	ra,72(sp)
    80000be0:	e0a2                	sd	s0,64(sp)
    80000be2:	fc26                	sd	s1,56(sp)
    80000be4:	f84a                	sd	s2,48(sp)
    80000be6:	f44e                	sd	s3,40(sp)
    80000be8:	f052                	sd	s4,32(sp)
    80000bea:	ec56                	sd	s5,24(sp)
    80000bec:	e85a                	sd	s6,16(sp)
    80000bee:	e45e                	sd	s7,8(sp)
    80000bf0:	e062                	sd	s8,0(sp)
    80000bf2:	0880                	addi	s0,sp,80
    80000bf4:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000bf6:	00007497          	auipc	s1,0x7
    80000bfa:	2ea48493          	addi	s1,s1,746 # 80007ee0 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000bfe:	8c26                	mv	s8,s1
    80000c00:	ff4df937          	lui	s2,0xff4df
    80000c04:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bd9fd>
    80000c08:	0936                	slli	s2,s2,0xd
    80000c0a:	6f590913          	addi	s2,s2,1781
    80000c0e:	0936                	slli	s2,s2,0xd
    80000c10:	bd390913          	addi	s2,s2,-1069
    80000c14:	0932                	slli	s2,s2,0xc
    80000c16:	7a790913          	addi	s2,s2,1959
    80000c1a:	040009b7          	lui	s3,0x4000
    80000c1e:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000c20:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c22:	4b99                	li	s7,6
    80000c24:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c26:	0000da97          	auipc	s5,0xd
    80000c2a:	ebaa8a93          	addi	s5,s5,-326 # 8000dae0 <tickslock>
    char *pa = kalloc();
    80000c2e:	cceff0ef          	jal	800000fc <kalloc>
    80000c32:	862a                	mv	a2,a0
    if(pa == 0)
    80000c34:	c121                	beqz	a0,80000c74 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    80000c36:	418485b3          	sub	a1,s1,s8
    80000c3a:	8591                	srai	a1,a1,0x4
    80000c3c:	032585b3          	mul	a1,a1,s2
    80000c40:	05b6                	slli	a1,a1,0xd
    80000c42:	6789                	lui	a5,0x2
    80000c44:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c46:	875e                	mv	a4,s7
    80000c48:	86da                	mv	a3,s6
    80000c4a:	40b985b3          	sub	a1,s3,a1
    80000c4e:	8552                	mv	a0,s4
    80000c50:	90dff0ef          	jal	8000055c <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c54:	17048493          	addi	s1,s1,368
    80000c58:	fd549be3          	bne	s1,s5,80000c2e <proc_mapstacks+0x52>
  }
}
    80000c5c:	60a6                	ld	ra,72(sp)
    80000c5e:	6406                	ld	s0,64(sp)
    80000c60:	74e2                	ld	s1,56(sp)
    80000c62:	7942                	ld	s2,48(sp)
    80000c64:	79a2                	ld	s3,40(sp)
    80000c66:	7a02                	ld	s4,32(sp)
    80000c68:	6ae2                	ld	s5,24(sp)
    80000c6a:	6b42                	ld	s6,16(sp)
    80000c6c:	6ba2                	ld	s7,8(sp)
    80000c6e:	6c02                	ld	s8,0(sp)
    80000c70:	6161                	addi	sp,sp,80
    80000c72:	8082                	ret
      panic("kalloc");
    80000c74:	00006517          	auipc	a0,0x6
    80000c78:	53450513          	addi	a0,a0,1332 # 800071a8 <etext+0x1a8>
    80000c7c:	053040ef          	jal	800054ce <panic>

0000000080000c80 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000c80:	7139                	addi	sp,sp,-64
    80000c82:	fc06                	sd	ra,56(sp)
    80000c84:	f822                	sd	s0,48(sp)
    80000c86:	f426                	sd	s1,40(sp)
    80000c88:	f04a                	sd	s2,32(sp)
    80000c8a:	ec4e                	sd	s3,24(sp)
    80000c8c:	e852                	sd	s4,16(sp)
    80000c8e:	e456                	sd	s5,8(sp)
    80000c90:	e05a                	sd	s6,0(sp)
    80000c92:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000c94:	00006597          	auipc	a1,0x6
    80000c98:	51c58593          	addi	a1,a1,1308 # 800071b0 <etext+0x1b0>
    80000c9c:	00007517          	auipc	a0,0x7
    80000ca0:	e1450513          	addi	a0,a0,-492 # 80007ab0 <pid_lock>
    80000ca4:	2df040ef          	jal	80005782 <initlock>
  initlock(&wait_lock, "wait_lock");
    80000ca8:	00006597          	auipc	a1,0x6
    80000cac:	51058593          	addi	a1,a1,1296 # 800071b8 <etext+0x1b8>
    80000cb0:	00007517          	auipc	a0,0x7
    80000cb4:	e1850513          	addi	a0,a0,-488 # 80007ac8 <wait_lock>
    80000cb8:	2cb040ef          	jal	80005782 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cbc:	00007497          	auipc	s1,0x7
    80000cc0:	22448493          	addi	s1,s1,548 # 80007ee0 <proc>
      initlock(&p->lock, "proc");
    80000cc4:	00006b17          	auipc	s6,0x6
    80000cc8:	504b0b13          	addi	s6,s6,1284 # 800071c8 <etext+0x1c8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000ccc:	8aa6                	mv	s5,s1
    80000cce:	ff4df937          	lui	s2,0xff4df
    80000cd2:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4bd9fd>
    80000cd6:	0936                	slli	s2,s2,0xd
    80000cd8:	6f590913          	addi	s2,s2,1781
    80000cdc:	0936                	slli	s2,s2,0xd
    80000cde:	bd390913          	addi	s2,s2,-1069
    80000ce2:	0932                	slli	s2,s2,0xc
    80000ce4:	7a790913          	addi	s2,s2,1959
    80000ce8:	040009b7          	lui	s3,0x4000
    80000cec:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000cee:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cf0:	0000da17          	auipc	s4,0xd
    80000cf4:	df0a0a13          	addi	s4,s4,-528 # 8000dae0 <tickslock>
      initlock(&p->lock, "proc");
    80000cf8:	85da                	mv	a1,s6
    80000cfa:	8526                	mv	a0,s1
    80000cfc:	287040ef          	jal	80005782 <initlock>
      p->state = UNUSED;
    80000d00:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000d04:	415487b3          	sub	a5,s1,s5
    80000d08:	8791                	srai	a5,a5,0x4
    80000d0a:	032787b3          	mul	a5,a5,s2
    80000d0e:	07b6                	slli	a5,a5,0xd
    80000d10:	6709                	lui	a4,0x2
    80000d12:	9fb9                	addw	a5,a5,a4
    80000d14:	40f987b3          	sub	a5,s3,a5
    80000d18:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d1a:	17048493          	addi	s1,s1,368
    80000d1e:	fd449de3          	bne	s1,s4,80000cf8 <procinit+0x78>
  }
}
    80000d22:	70e2                	ld	ra,56(sp)
    80000d24:	7442                	ld	s0,48(sp)
    80000d26:	74a2                	ld	s1,40(sp)
    80000d28:	7902                	ld	s2,32(sp)
    80000d2a:	69e2                	ld	s3,24(sp)
    80000d2c:	6a42                	ld	s4,16(sp)
    80000d2e:	6aa2                	ld	s5,8(sp)
    80000d30:	6b02                	ld	s6,0(sp)
    80000d32:	6121                	addi	sp,sp,64
    80000d34:	8082                	ret

0000000080000d36 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000d36:	1141                	addi	sp,sp,-16
    80000d38:	e406                	sd	ra,8(sp)
    80000d3a:	e022                	sd	s0,0(sp)
    80000d3c:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000d3e:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000d40:	2501                	sext.w	a0,a0
    80000d42:	60a2                	ld	ra,8(sp)
    80000d44:	6402                	ld	s0,0(sp)
    80000d46:	0141                	addi	sp,sp,16
    80000d48:	8082                	ret

0000000080000d4a <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000d4a:	1141                	addi	sp,sp,-16
    80000d4c:	e406                	sd	ra,8(sp)
    80000d4e:	e022                	sd	s0,0(sp)
    80000d50:	0800                	addi	s0,sp,16
    80000d52:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000d54:	2781                	sext.w	a5,a5
    80000d56:	079e                	slli	a5,a5,0x7
  return c;
}
    80000d58:	00007517          	auipc	a0,0x7
    80000d5c:	d8850513          	addi	a0,a0,-632 # 80007ae0 <cpus>
    80000d60:	953e                	add	a0,a0,a5
    80000d62:	60a2                	ld	ra,8(sp)
    80000d64:	6402                	ld	s0,0(sp)
    80000d66:	0141                	addi	sp,sp,16
    80000d68:	8082                	ret

0000000080000d6a <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000d6a:	1101                	addi	sp,sp,-32
    80000d6c:	ec06                	sd	ra,24(sp)
    80000d6e:	e822                	sd	s0,16(sp)
    80000d70:	e426                	sd	s1,8(sp)
    80000d72:	1000                	addi	s0,sp,32
  push_off();
    80000d74:	255040ef          	jal	800057c8 <push_off>
    80000d78:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000d7a:	2781                	sext.w	a5,a5
    80000d7c:	079e                	slli	a5,a5,0x7
    80000d7e:	00007717          	auipc	a4,0x7
    80000d82:	d3270713          	addi	a4,a4,-718 # 80007ab0 <pid_lock>
    80000d86:	97ba                	add	a5,a5,a4
    80000d88:	7b9c                	ld	a5,48(a5)
    80000d8a:	84be                	mv	s1,a5
  pop_off();
    80000d8c:	2c5040ef          	jal	80005850 <pop_off>
  return p;
}
    80000d90:	8526                	mv	a0,s1
    80000d92:	60e2                	ld	ra,24(sp)
    80000d94:	6442                	ld	s0,16(sp)
    80000d96:	64a2                	ld	s1,8(sp)
    80000d98:	6105                	addi	sp,sp,32
    80000d9a:	8082                	ret

0000000080000d9c <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000d9c:	1141                	addi	sp,sp,-16
    80000d9e:	e406                	sd	ra,8(sp)
    80000da0:	e022                	sd	s0,0(sp)
    80000da2:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000da4:	fc7ff0ef          	jal	80000d6a <myproc>
    80000da8:	2f9040ef          	jal	800058a0 <release>

  if (first) {
    80000dac:	00007797          	auipc	a5,0x7
    80000db0:	c647a783          	lw	a5,-924(a5) # 80007a10 <first.1>
    80000db4:	e799                	bnez	a5,80000dc2 <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000db6:	2cb000ef          	jal	80001880 <usertrapret>
}
    80000dba:	60a2                	ld	ra,8(sp)
    80000dbc:	6402                	ld	s0,0(sp)
    80000dbe:	0141                	addi	sp,sp,16
    80000dc0:	8082                	ret
    fsinit(ROOTDEV);
    80000dc2:	4505                	li	a0,1
    80000dc4:	68c010ef          	jal	80002450 <fsinit>
    first = 0;
    80000dc8:	00007797          	auipc	a5,0x7
    80000dcc:	c407a423          	sw	zero,-952(a5) # 80007a10 <first.1>
    __sync_synchronize();
    80000dd0:	0330000f          	fence	rw,rw
    80000dd4:	b7cd                	j	80000db6 <forkret+0x1a>

0000000080000dd6 <allocpid>:
{
    80000dd6:	1101                	addi	sp,sp,-32
    80000dd8:	ec06                	sd	ra,24(sp)
    80000dda:	e822                	sd	s0,16(sp)
    80000ddc:	e426                	sd	s1,8(sp)
    80000dde:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000de0:	00007517          	auipc	a0,0x7
    80000de4:	cd050513          	addi	a0,a0,-816 # 80007ab0 <pid_lock>
    80000de8:	225040ef          	jal	8000580c <acquire>
  pid = nextpid;
    80000dec:	00007797          	auipc	a5,0x7
    80000df0:	c2878793          	addi	a5,a5,-984 # 80007a14 <nextpid>
    80000df4:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000df6:	0014871b          	addiw	a4,s1,1
    80000dfa:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000dfc:	00007517          	auipc	a0,0x7
    80000e00:	cb450513          	addi	a0,a0,-844 # 80007ab0 <pid_lock>
    80000e04:	29d040ef          	jal	800058a0 <release>
}
    80000e08:	8526                	mv	a0,s1
    80000e0a:	60e2                	ld	ra,24(sp)
    80000e0c:	6442                	ld	s0,16(sp)
    80000e0e:	64a2                	ld	s1,8(sp)
    80000e10:	6105                	addi	sp,sp,32
    80000e12:	8082                	ret

0000000080000e14 <proc_pagetable>:
{
    80000e14:	1101                	addi	sp,sp,-32
    80000e16:	ec06                	sd	ra,24(sp)
    80000e18:	e822                	sd	s0,16(sp)
    80000e1a:	e426                	sd	s1,8(sp)
    80000e1c:	e04a                	sd	s2,0(sp)
    80000e1e:	1000                	addi	s0,sp,32
    80000e20:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000e22:	8f9ff0ef          	jal	8000071a <uvmcreate>
    80000e26:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000e28:	cd05                	beqz	a0,80000e60 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000e2a:	4729                	li	a4,10
    80000e2c:	00005697          	auipc	a3,0x5
    80000e30:	1d468693          	addi	a3,a3,468 # 80006000 <_trampoline>
    80000e34:	6605                	lui	a2,0x1
    80000e36:	040005b7          	lui	a1,0x4000
    80000e3a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e3c:	05b2                	slli	a1,a1,0xc
    80000e3e:	e68ff0ef          	jal	800004a6 <mappages>
    80000e42:	02054663          	bltz	a0,80000e6e <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000e46:	4719                	li	a4,6
    80000e48:	05893683          	ld	a3,88(s2)
    80000e4c:	6605                	lui	a2,0x1
    80000e4e:	020005b7          	lui	a1,0x2000
    80000e52:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000e54:	05b6                	slli	a1,a1,0xd
    80000e56:	8526                	mv	a0,s1
    80000e58:	e4eff0ef          	jal	800004a6 <mappages>
    80000e5c:	00054f63          	bltz	a0,80000e7a <proc_pagetable+0x66>
}
    80000e60:	8526                	mv	a0,s1
    80000e62:	60e2                	ld	ra,24(sp)
    80000e64:	6442                	ld	s0,16(sp)
    80000e66:	64a2                	ld	s1,8(sp)
    80000e68:	6902                	ld	s2,0(sp)
    80000e6a:	6105                	addi	sp,sp,32
    80000e6c:	8082                	ret
    uvmfree(pagetable, 0);
    80000e6e:	4581                	li	a1,0
    80000e70:	8526                	mv	a0,s1
    80000e72:	a6fff0ef          	jal	800008e0 <uvmfree>
    return 0;
    80000e76:	4481                	li	s1,0
    80000e78:	b7e5                	j	80000e60 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000e7a:	4681                	li	a3,0
    80000e7c:	4605                	li	a2,1
    80000e7e:	040005b7          	lui	a1,0x4000
    80000e82:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e84:	05b2                	slli	a1,a1,0xc
    80000e86:	8526                	mv	a0,s1
    80000e88:	fc6ff0ef          	jal	8000064e <uvmunmap>
    uvmfree(pagetable, 0);
    80000e8c:	4581                	li	a1,0
    80000e8e:	8526                	mv	a0,s1
    80000e90:	a51ff0ef          	jal	800008e0 <uvmfree>
    return 0;
    80000e94:	4481                	li	s1,0
    80000e96:	b7e9                	j	80000e60 <proc_pagetable+0x4c>

0000000080000e98 <proc_freepagetable>:
{
    80000e98:	1101                	addi	sp,sp,-32
    80000e9a:	ec06                	sd	ra,24(sp)
    80000e9c:	e822                	sd	s0,16(sp)
    80000e9e:	e426                	sd	s1,8(sp)
    80000ea0:	e04a                	sd	s2,0(sp)
    80000ea2:	1000                	addi	s0,sp,32
    80000ea4:	84aa                	mv	s1,a0
    80000ea6:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000ea8:	4681                	li	a3,0
    80000eaa:	4605                	li	a2,1
    80000eac:	040005b7          	lui	a1,0x4000
    80000eb0:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000eb2:	05b2                	slli	a1,a1,0xc
    80000eb4:	f9aff0ef          	jal	8000064e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000eb8:	4681                	li	a3,0
    80000eba:	4605                	li	a2,1
    80000ebc:	020005b7          	lui	a1,0x2000
    80000ec0:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000ec2:	05b6                	slli	a1,a1,0xd
    80000ec4:	8526                	mv	a0,s1
    80000ec6:	f88ff0ef          	jal	8000064e <uvmunmap>
  uvmfree(pagetable, sz);
    80000eca:	85ca                	mv	a1,s2
    80000ecc:	8526                	mv	a0,s1
    80000ece:	a13ff0ef          	jal	800008e0 <uvmfree>
}
    80000ed2:	60e2                	ld	ra,24(sp)
    80000ed4:	6442                	ld	s0,16(sp)
    80000ed6:	64a2                	ld	s1,8(sp)
    80000ed8:	6902                	ld	s2,0(sp)
    80000eda:	6105                	addi	sp,sp,32
    80000edc:	8082                	ret

0000000080000ede <freeproc>:
{
    80000ede:	1101                	addi	sp,sp,-32
    80000ee0:	ec06                	sd	ra,24(sp)
    80000ee2:	e822                	sd	s0,16(sp)
    80000ee4:	e426                	sd	s1,8(sp)
    80000ee6:	1000                	addi	s0,sp,32
    80000ee8:	84aa                	mv	s1,a0
  if(p->trapframe)
    80000eea:	6d28                	ld	a0,88(a0)
    80000eec:	c119                	beqz	a0,80000ef2 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80000eee:	92eff0ef          	jal	8000001c <kfree>
  p->trapframe = 0;
    80000ef2:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80000ef6:	68a8                	ld	a0,80(s1)
    80000ef8:	c501                	beqz	a0,80000f00 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80000efa:	64ac                	ld	a1,72(s1)
    80000efc:	f9dff0ef          	jal	80000e98 <proc_freepagetable>
  p->pagetable = 0;
    80000f00:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80000f04:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80000f08:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80000f0c:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80000f10:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80000f14:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80000f18:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80000f1c:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80000f20:	0004ac23          	sw	zero,24(s1)
}
    80000f24:	60e2                	ld	ra,24(sp)
    80000f26:	6442                	ld	s0,16(sp)
    80000f28:	64a2                	ld	s1,8(sp)
    80000f2a:	6105                	addi	sp,sp,32
    80000f2c:	8082                	ret

0000000080000f2e <allocproc>:
{
    80000f2e:	1101                	addi	sp,sp,-32
    80000f30:	ec06                	sd	ra,24(sp)
    80000f32:	e822                	sd	s0,16(sp)
    80000f34:	e426                	sd	s1,8(sp)
    80000f36:	e04a                	sd	s2,0(sp)
    80000f38:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f3a:	00007497          	auipc	s1,0x7
    80000f3e:	fa648493          	addi	s1,s1,-90 # 80007ee0 <proc>
    80000f42:	0000d917          	auipc	s2,0xd
    80000f46:	b9e90913          	addi	s2,s2,-1122 # 8000dae0 <tickslock>
    acquire(&p->lock);
    80000f4a:	8526                	mv	a0,s1
    80000f4c:	0c1040ef          	jal	8000580c <acquire>
    if(p->state == UNUSED) {
    80000f50:	4c9c                	lw	a5,24(s1)
    80000f52:	cb91                	beqz	a5,80000f66 <allocproc+0x38>
      release(&p->lock);
    80000f54:	8526                	mv	a0,s1
    80000f56:	14b040ef          	jal	800058a0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f5a:	17048493          	addi	s1,s1,368
    80000f5e:	ff2496e3          	bne	s1,s2,80000f4a <allocproc+0x1c>
  return 0;
    80000f62:	4481                	li	s1,0
    80000f64:	a089                	j	80000fa6 <allocproc+0x78>
  p->pid = allocpid();
    80000f66:	e71ff0ef          	jal	80000dd6 <allocpid>
    80000f6a:	d888                	sw	a0,48(s1)
  p->state = USED;
    80000f6c:	4785                	li	a5,1
    80000f6e:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80000f70:	98cff0ef          	jal	800000fc <kalloc>
    80000f74:	892a                	mv	s2,a0
    80000f76:	eca8                	sd	a0,88(s1)
    80000f78:	cd15                	beqz	a0,80000fb4 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80000f7a:	8526                	mv	a0,s1
    80000f7c:	e99ff0ef          	jal	80000e14 <proc_pagetable>
    80000f80:	892a                	mv	s2,a0
    80000f82:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80000f84:	c121                	beqz	a0,80000fc4 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80000f86:	07000613          	li	a2,112
    80000f8a:	4581                	li	a1,0
    80000f8c:	06048513          	addi	a0,s1,96
    80000f90:	9aeff0ef          	jal	8000013e <memset>
  p->context.ra = (uint64)forkret;
    80000f94:	00000797          	auipc	a5,0x0
    80000f98:	e0878793          	addi	a5,a5,-504 # 80000d9c <forkret>
    80000f9c:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80000f9e:	60bc                	ld	a5,64(s1)
    80000fa0:	6705                	lui	a4,0x1
    80000fa2:	97ba                	add	a5,a5,a4
    80000fa4:	f4bc                	sd	a5,104(s1)
}
    80000fa6:	8526                	mv	a0,s1
    80000fa8:	60e2                	ld	ra,24(sp)
    80000faa:	6442                	ld	s0,16(sp)
    80000fac:	64a2                	ld	s1,8(sp)
    80000fae:	6902                	ld	s2,0(sp)
    80000fb0:	6105                	addi	sp,sp,32
    80000fb2:	8082                	ret
    freeproc(p);
    80000fb4:	8526                	mv	a0,s1
    80000fb6:	f29ff0ef          	jal	80000ede <freeproc>
    release(&p->lock);
    80000fba:	8526                	mv	a0,s1
    80000fbc:	0e5040ef          	jal	800058a0 <release>
    return 0;
    80000fc0:	84ca                	mv	s1,s2
    80000fc2:	b7d5                	j	80000fa6 <allocproc+0x78>
    freeproc(p);
    80000fc4:	8526                	mv	a0,s1
    80000fc6:	f19ff0ef          	jal	80000ede <freeproc>
    release(&p->lock);
    80000fca:	8526                	mv	a0,s1
    80000fcc:	0d5040ef          	jal	800058a0 <release>
    return 0;
    80000fd0:	84ca                	mv	s1,s2
    80000fd2:	bfd1                	j	80000fa6 <allocproc+0x78>

0000000080000fd4 <userinit>:
{
    80000fd4:	1101                	addi	sp,sp,-32
    80000fd6:	ec06                	sd	ra,24(sp)
    80000fd8:	e822                	sd	s0,16(sp)
    80000fda:	e426                	sd	s1,8(sp)
    80000fdc:	1000                	addi	s0,sp,32
  p = allocproc();
    80000fde:	f51ff0ef          	jal	80000f2e <allocproc>
    80000fe2:	84aa                	mv	s1,a0
  initproc = p;
    80000fe4:	00007797          	auipc	a5,0x7
    80000fe8:	a8a7b623          	sd	a0,-1396(a5) # 80007a70 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80000fec:	03400613          	li	a2,52
    80000ff0:	00007597          	auipc	a1,0x7
    80000ff4:	a3058593          	addi	a1,a1,-1488 # 80007a20 <initcode>
    80000ff8:	6928                	ld	a0,80(a0)
    80000ffa:	f46ff0ef          	jal	80000740 <uvmfirst>
  p->sz = PGSIZE;
    80000ffe:	6785                	lui	a5,0x1
    80001000:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001002:	6cb8                	ld	a4,88(s1)
    80001004:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001008:	6cb8                	ld	a4,88(s1)
    8000100a:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    8000100c:	4641                	li	a2,16
    8000100e:	00006597          	auipc	a1,0x6
    80001012:	1c258593          	addi	a1,a1,450 # 800071d0 <etext+0x1d0>
    80001016:	15848513          	addi	a0,s1,344
    8000101a:	a78ff0ef          	jal	80000292 <safestrcpy>
  p->cwd = namei("/");
    8000101e:	00006517          	auipc	a0,0x6
    80001022:	1c250513          	addi	a0,a0,450 # 800071e0 <etext+0x1e0>
    80001026:	553010ef          	jal	80002d78 <namei>
    8000102a:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    8000102e:	478d                	li	a5,3
    80001030:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001032:	8526                	mv	a0,s1
    80001034:	06d040ef          	jal	800058a0 <release>
}
    80001038:	60e2                	ld	ra,24(sp)
    8000103a:	6442                	ld	s0,16(sp)
    8000103c:	64a2                	ld	s1,8(sp)
    8000103e:	6105                	addi	sp,sp,32
    80001040:	8082                	ret

0000000080001042 <growproc>:
{
    80001042:	1101                	addi	sp,sp,-32
    80001044:	ec06                	sd	ra,24(sp)
    80001046:	e822                	sd	s0,16(sp)
    80001048:	e426                	sd	s1,8(sp)
    8000104a:	e04a                	sd	s2,0(sp)
    8000104c:	1000                	addi	s0,sp,32
    8000104e:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001050:	d1bff0ef          	jal	80000d6a <myproc>
    80001054:	84aa                	mv	s1,a0
  sz = p->sz;
    80001056:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001058:	01204c63          	bgtz	s2,80001070 <growproc+0x2e>
  } else if(n < 0){
    8000105c:	02094463          	bltz	s2,80001084 <growproc+0x42>
  p->sz = sz;
    80001060:	e4ac                	sd	a1,72(s1)
  return 0;
    80001062:	4501                	li	a0,0
}
    80001064:	60e2                	ld	ra,24(sp)
    80001066:	6442                	ld	s0,16(sp)
    80001068:	64a2                	ld	s1,8(sp)
    8000106a:	6902                	ld	s2,0(sp)
    8000106c:	6105                	addi	sp,sp,32
    8000106e:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001070:	4691                	li	a3,4
    80001072:	00b90633          	add	a2,s2,a1
    80001076:	6928                	ld	a0,80(a0)
    80001078:	f6aff0ef          	jal	800007e2 <uvmalloc>
    8000107c:	85aa                	mv	a1,a0
    8000107e:	f16d                	bnez	a0,80001060 <growproc+0x1e>
      return -1;
    80001080:	557d                	li	a0,-1
    80001082:	b7cd                	j	80001064 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001084:	00b90633          	add	a2,s2,a1
    80001088:	6928                	ld	a0,80(a0)
    8000108a:	f14ff0ef          	jal	8000079e <uvmdealloc>
    8000108e:	85aa                	mv	a1,a0
    80001090:	bfc1                	j	80001060 <growproc+0x1e>

0000000080001092 <fork>:
{
    80001092:	7139                	addi	sp,sp,-64
    80001094:	fc06                	sd	ra,56(sp)
    80001096:	f822                	sd	s0,48(sp)
    80001098:	f426                	sd	s1,40(sp)
    8000109a:	e456                	sd	s5,8(sp)
    8000109c:	0080                	addi	s0,sp,64
    struct proc *p = myproc();
    8000109e:	ccdff0ef          	jal	80000d6a <myproc>
    800010a2:	8aaa                	mv	s5,a0
    if((np = allocproc()) == 0){
    800010a4:	e8bff0ef          	jal	80000f2e <allocproc>
    800010a8:	0e050e63          	beqz	a0,800011a4 <fork+0x112>
    800010ac:	ec4e                	sd	s3,24(sp)
    800010ae:	89aa                	mv	s3,a0
    if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    800010b0:	048ab603          	ld	a2,72(s5)
    800010b4:	692c                	ld	a1,80(a0)
    800010b6:	050ab503          	ld	a0,80(s5)
    800010ba:	859ff0ef          	jal	80000912 <uvmcopy>
    800010be:	04054863          	bltz	a0,8000110e <fork+0x7c>
    800010c2:	f04a                	sd	s2,32(sp)
    800010c4:	e852                	sd	s4,16(sp)
    np->sz = p->sz;
    800010c6:	048ab783          	ld	a5,72(s5)
    800010ca:	04f9b423          	sd	a5,72(s3)
    *(np->trapframe) = *(p->trapframe);
    800010ce:	058ab683          	ld	a3,88(s5)
    800010d2:	87b6                	mv	a5,a3
    800010d4:	0589b703          	ld	a4,88(s3)
    800010d8:	12068693          	addi	a3,a3,288
    800010dc:	6388                	ld	a0,0(a5)
    800010de:	678c                	ld	a1,8(a5)
    800010e0:	6b90                	ld	a2,16(a5)
    800010e2:	e308                	sd	a0,0(a4)
    800010e4:	e70c                	sd	a1,8(a4)
    800010e6:	eb10                	sd	a2,16(a4)
    800010e8:	6f90                	ld	a2,24(a5)
    800010ea:	ef10                	sd	a2,24(a4)
    800010ec:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    800010f0:	02070713          	addi	a4,a4,32
    800010f4:	fed794e3          	bne	a5,a3,800010dc <fork+0x4a>
    np->trapframe->a0 = 0;
    800010f8:	0589b783          	ld	a5,88(s3)
    800010fc:	0607b823          	sd	zero,112(a5)
    for(i = 0; i < NOFILE; i++)
    80001100:	0d0a8493          	addi	s1,s5,208
    80001104:	0d098913          	addi	s2,s3,208
    80001108:	150a8a13          	addi	s4,s5,336
    8000110c:	a831                	j	80001128 <fork+0x96>
        freeproc(np);
    8000110e:	854e                	mv	a0,s3
    80001110:	dcfff0ef          	jal	80000ede <freeproc>
        release(&np->lock);
    80001114:	854e                	mv	a0,s3
    80001116:	78a040ef          	jal	800058a0 <release>
        return -1;
    8000111a:	54fd                	li	s1,-1
    8000111c:	69e2                	ld	s3,24(sp)
    8000111e:	a8a5                	j	80001196 <fork+0x104>
    for(i = 0; i < NOFILE; i++)
    80001120:	04a1                	addi	s1,s1,8
    80001122:	0921                	addi	s2,s2,8
    80001124:	01448963          	beq	s1,s4,80001136 <fork+0xa4>
        if(p->ofile[i])
    80001128:	6088                	ld	a0,0(s1)
    8000112a:	d97d                	beqz	a0,80001120 <fork+0x8e>
            np->ofile[i] = filedup(p->ofile[i]);
    8000112c:	1fa020ef          	jal	80003326 <filedup>
    80001130:	00a93023          	sd	a0,0(s2)
    80001134:	b7f5                	j	80001120 <fork+0x8e>
    np->cwd = idup(p->cwd);
    80001136:	150ab503          	ld	a0,336(s5)
    8000113a:	512010ef          	jal	8000264c <idup>
    8000113e:	14a9b823          	sd	a0,336(s3)
    safestrcpy(np->name, p->name, sizeof(p->name));
    80001142:	4641                	li	a2,16
    80001144:	158a8593          	addi	a1,s5,344
    80001148:	15898513          	addi	a0,s3,344
    8000114c:	946ff0ef          	jal	80000292 <safestrcpy>
    np->trace_mask = p->trace_mask;
    80001150:	168aa783          	lw	a5,360(s5)
    80001154:	16f9a423          	sw	a5,360(s3)
    pid = np->pid;
    80001158:	0309a483          	lw	s1,48(s3)
    release(&np->lock);
    8000115c:	854e                	mv	a0,s3
    8000115e:	742040ef          	jal	800058a0 <release>
    acquire(&wait_lock);
    80001162:	00007517          	auipc	a0,0x7
    80001166:	96650513          	addi	a0,a0,-1690 # 80007ac8 <wait_lock>
    8000116a:	6a2040ef          	jal	8000580c <acquire>
    np->parent = p;
    8000116e:	0359bc23          	sd	s5,56(s3)
    release(&wait_lock);
    80001172:	00007517          	auipc	a0,0x7
    80001176:	95650513          	addi	a0,a0,-1706 # 80007ac8 <wait_lock>
    8000117a:	726040ef          	jal	800058a0 <release>
    acquire(&np->lock);
    8000117e:	854e                	mv	a0,s3
    80001180:	68c040ef          	jal	8000580c <acquire>
    np->state = RUNNABLE;
    80001184:	478d                	li	a5,3
    80001186:	00f9ac23          	sw	a5,24(s3)
    release(&np->lock);
    8000118a:	854e                	mv	a0,s3
    8000118c:	714040ef          	jal	800058a0 <release>
    return pid;
    80001190:	7902                	ld	s2,32(sp)
    80001192:	69e2                	ld	s3,24(sp)
    80001194:	6a42                	ld	s4,16(sp)
}
    80001196:	8526                	mv	a0,s1
    80001198:	70e2                	ld	ra,56(sp)
    8000119a:	7442                	ld	s0,48(sp)
    8000119c:	74a2                	ld	s1,40(sp)
    8000119e:	6aa2                	ld	s5,8(sp)
    800011a0:	6121                	addi	sp,sp,64
    800011a2:	8082                	ret
        return -1;
    800011a4:	54fd                	li	s1,-1
    800011a6:	bfc5                	j	80001196 <fork+0x104>

00000000800011a8 <scheduler>:
{
    800011a8:	715d                	addi	sp,sp,-80
    800011aa:	e486                	sd	ra,72(sp)
    800011ac:	e0a2                	sd	s0,64(sp)
    800011ae:	fc26                	sd	s1,56(sp)
    800011b0:	f84a                	sd	s2,48(sp)
    800011b2:	f44e                	sd	s3,40(sp)
    800011b4:	f052                	sd	s4,32(sp)
    800011b6:	ec56                	sd	s5,24(sp)
    800011b8:	e85a                	sd	s6,16(sp)
    800011ba:	e45e                	sd	s7,8(sp)
    800011bc:	e062                	sd	s8,0(sp)
    800011be:	0880                	addi	s0,sp,80
    800011c0:	8792                	mv	a5,tp
  int id = r_tp();
    800011c2:	2781                	sext.w	a5,a5
  c->proc = 0;
    800011c4:	00779b13          	slli	s6,a5,0x7
    800011c8:	00007717          	auipc	a4,0x7
    800011cc:	8e870713          	addi	a4,a4,-1816 # 80007ab0 <pid_lock>
    800011d0:	975a                	add	a4,a4,s6
    800011d2:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    800011d6:	00007717          	auipc	a4,0x7
    800011da:	91270713          	addi	a4,a4,-1774 # 80007ae8 <cpus+0x8>
    800011de:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    800011e0:	4c11                	li	s8,4
        c->proc = p;
    800011e2:	079e                	slli	a5,a5,0x7
    800011e4:	00007a17          	auipc	s4,0x7
    800011e8:	8cca0a13          	addi	s4,s4,-1844 # 80007ab0 <pid_lock>
    800011ec:	9a3e                	add	s4,s4,a5
        found = 1;
    800011ee:	4b85                	li	s7,1
    800011f0:	a0a9                	j	8000123a <scheduler+0x92>
      release(&p->lock);
    800011f2:	8526                	mv	a0,s1
    800011f4:	6ac040ef          	jal	800058a0 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    800011f8:	17048493          	addi	s1,s1,368
    800011fc:	03248563          	beq	s1,s2,80001226 <scheduler+0x7e>
      acquire(&p->lock);
    80001200:	8526                	mv	a0,s1
    80001202:	60a040ef          	jal	8000580c <acquire>
      if(p->state == RUNNABLE) {
    80001206:	4c9c                	lw	a5,24(s1)
    80001208:	ff3795e3          	bne	a5,s3,800011f2 <scheduler+0x4a>
        p->state = RUNNING;
    8000120c:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001210:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001214:	06048593          	addi	a1,s1,96
    80001218:	855a                	mv	a0,s6
    8000121a:	5bc000ef          	jal	800017d6 <swtch>
        c->proc = 0;
    8000121e:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001222:	8ade                	mv	s5,s7
    80001224:	b7f9                	j	800011f2 <scheduler+0x4a>
    if(found == 0) {
    80001226:	000a9a63          	bnez	s5,8000123a <scheduler+0x92>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000122a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000122e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001232:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    80001236:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000123a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000123e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001242:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001246:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001248:	00007497          	auipc	s1,0x7
    8000124c:	c9848493          	addi	s1,s1,-872 # 80007ee0 <proc>
      if(p->state == RUNNABLE) {
    80001250:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    80001252:	0000d917          	auipc	s2,0xd
    80001256:	88e90913          	addi	s2,s2,-1906 # 8000dae0 <tickslock>
    8000125a:	b75d                	j	80001200 <scheduler+0x58>

000000008000125c <sched>:
{
    8000125c:	7179                	addi	sp,sp,-48
    8000125e:	f406                	sd	ra,40(sp)
    80001260:	f022                	sd	s0,32(sp)
    80001262:	ec26                	sd	s1,24(sp)
    80001264:	e84a                	sd	s2,16(sp)
    80001266:	e44e                	sd	s3,8(sp)
    80001268:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    8000126a:	b01ff0ef          	jal	80000d6a <myproc>
    8000126e:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001270:	52c040ef          	jal	8000579c <holding>
    80001274:	c935                	beqz	a0,800012e8 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001276:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001278:	2781                	sext.w	a5,a5
    8000127a:	079e                	slli	a5,a5,0x7
    8000127c:	00007717          	auipc	a4,0x7
    80001280:	83470713          	addi	a4,a4,-1996 # 80007ab0 <pid_lock>
    80001284:	97ba                	add	a5,a5,a4
    80001286:	0a87a703          	lw	a4,168(a5)
    8000128a:	4785                	li	a5,1
    8000128c:	06f71463          	bne	a4,a5,800012f4 <sched+0x98>
  if(p->state == RUNNING)
    80001290:	4c98                	lw	a4,24(s1)
    80001292:	4791                	li	a5,4
    80001294:	06f70663          	beq	a4,a5,80001300 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001298:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000129c:	8b89                	andi	a5,a5,2
  if(intr_get())
    8000129e:	e7bd                	bnez	a5,8000130c <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    800012a0:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    800012a2:	00007917          	auipc	s2,0x7
    800012a6:	80e90913          	addi	s2,s2,-2034 # 80007ab0 <pid_lock>
    800012aa:	2781                	sext.w	a5,a5
    800012ac:	079e                	slli	a5,a5,0x7
    800012ae:	97ca                	add	a5,a5,s2
    800012b0:	0ac7a983          	lw	s3,172(a5)
    800012b4:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800012b6:	2781                	sext.w	a5,a5
    800012b8:	079e                	slli	a5,a5,0x7
    800012ba:	07a1                	addi	a5,a5,8
    800012bc:	00007597          	auipc	a1,0x7
    800012c0:	82458593          	addi	a1,a1,-2012 # 80007ae0 <cpus>
    800012c4:	95be                	add	a1,a1,a5
    800012c6:	06048513          	addi	a0,s1,96
    800012ca:	50c000ef          	jal	800017d6 <swtch>
    800012ce:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    800012d0:	2781                	sext.w	a5,a5
    800012d2:	079e                	slli	a5,a5,0x7
    800012d4:	993e                	add	s2,s2,a5
    800012d6:	0b392623          	sw	s3,172(s2)
}
    800012da:	70a2                	ld	ra,40(sp)
    800012dc:	7402                	ld	s0,32(sp)
    800012de:	64e2                	ld	s1,24(sp)
    800012e0:	6942                	ld	s2,16(sp)
    800012e2:	69a2                	ld	s3,8(sp)
    800012e4:	6145                	addi	sp,sp,48
    800012e6:	8082                	ret
    panic("sched p->lock");
    800012e8:	00006517          	auipc	a0,0x6
    800012ec:	f0050513          	addi	a0,a0,-256 # 800071e8 <etext+0x1e8>
    800012f0:	1de040ef          	jal	800054ce <panic>
    panic("sched locks");
    800012f4:	00006517          	auipc	a0,0x6
    800012f8:	f0450513          	addi	a0,a0,-252 # 800071f8 <etext+0x1f8>
    800012fc:	1d2040ef          	jal	800054ce <panic>
    panic("sched running");
    80001300:	00006517          	auipc	a0,0x6
    80001304:	f0850513          	addi	a0,a0,-248 # 80007208 <etext+0x208>
    80001308:	1c6040ef          	jal	800054ce <panic>
    panic("sched interruptible");
    8000130c:	00006517          	auipc	a0,0x6
    80001310:	f0c50513          	addi	a0,a0,-244 # 80007218 <etext+0x218>
    80001314:	1ba040ef          	jal	800054ce <panic>

0000000080001318 <yield>:
{
    80001318:	1101                	addi	sp,sp,-32
    8000131a:	ec06                	sd	ra,24(sp)
    8000131c:	e822                	sd	s0,16(sp)
    8000131e:	e426                	sd	s1,8(sp)
    80001320:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001322:	a49ff0ef          	jal	80000d6a <myproc>
    80001326:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001328:	4e4040ef          	jal	8000580c <acquire>
  p->state = RUNNABLE;
    8000132c:	478d                	li	a5,3
    8000132e:	cc9c                	sw	a5,24(s1)
  sched();
    80001330:	f2dff0ef          	jal	8000125c <sched>
  release(&p->lock);
    80001334:	8526                	mv	a0,s1
    80001336:	56a040ef          	jal	800058a0 <release>
}
    8000133a:	60e2                	ld	ra,24(sp)
    8000133c:	6442                	ld	s0,16(sp)
    8000133e:	64a2                	ld	s1,8(sp)
    80001340:	6105                	addi	sp,sp,32
    80001342:	8082                	ret

0000000080001344 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001344:	7179                	addi	sp,sp,-48
    80001346:	f406                	sd	ra,40(sp)
    80001348:	f022                	sd	s0,32(sp)
    8000134a:	ec26                	sd	s1,24(sp)
    8000134c:	e84a                	sd	s2,16(sp)
    8000134e:	e44e                	sd	s3,8(sp)
    80001350:	1800                	addi	s0,sp,48
    80001352:	89aa                	mv	s3,a0
    80001354:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001356:	a15ff0ef          	jal	80000d6a <myproc>
    8000135a:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    8000135c:	4b0040ef          	jal	8000580c <acquire>
  release(lk);
    80001360:	854a                	mv	a0,s2
    80001362:	53e040ef          	jal	800058a0 <release>

  // Go to sleep.
  p->chan = chan;
    80001366:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    8000136a:	4789                	li	a5,2
    8000136c:	cc9c                	sw	a5,24(s1)

  sched();
    8000136e:	eefff0ef          	jal	8000125c <sched>

  // Tidy up.
  p->chan = 0;
    80001372:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001376:	8526                	mv	a0,s1
    80001378:	528040ef          	jal	800058a0 <release>
  acquire(lk);
    8000137c:	854a                	mv	a0,s2
    8000137e:	48e040ef          	jal	8000580c <acquire>
}
    80001382:	70a2                	ld	ra,40(sp)
    80001384:	7402                	ld	s0,32(sp)
    80001386:	64e2                	ld	s1,24(sp)
    80001388:	6942                	ld	s2,16(sp)
    8000138a:	69a2                	ld	s3,8(sp)
    8000138c:	6145                	addi	sp,sp,48
    8000138e:	8082                	ret

0000000080001390 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    80001390:	7139                	addi	sp,sp,-64
    80001392:	fc06                	sd	ra,56(sp)
    80001394:	f822                	sd	s0,48(sp)
    80001396:	f426                	sd	s1,40(sp)
    80001398:	f04a                	sd	s2,32(sp)
    8000139a:	ec4e                	sd	s3,24(sp)
    8000139c:	e852                	sd	s4,16(sp)
    8000139e:	e456                	sd	s5,8(sp)
    800013a0:	0080                	addi	s0,sp,64
    800013a2:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800013a4:	00007497          	auipc	s1,0x7
    800013a8:	b3c48493          	addi	s1,s1,-1220 # 80007ee0 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800013ac:	4989                	li	s3,2
        p->state = RUNNABLE;
    800013ae:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800013b0:	0000c917          	auipc	s2,0xc
    800013b4:	73090913          	addi	s2,s2,1840 # 8000dae0 <tickslock>
    800013b8:	a801                	j	800013c8 <wakeup+0x38>
      }
      release(&p->lock);
    800013ba:	8526                	mv	a0,s1
    800013bc:	4e4040ef          	jal	800058a0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800013c0:	17048493          	addi	s1,s1,368
    800013c4:	03248263          	beq	s1,s2,800013e8 <wakeup+0x58>
    if(p != myproc()){
    800013c8:	9a3ff0ef          	jal	80000d6a <myproc>
    800013cc:	fe950ae3          	beq	a0,s1,800013c0 <wakeup+0x30>
      acquire(&p->lock);
    800013d0:	8526                	mv	a0,s1
    800013d2:	43a040ef          	jal	8000580c <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800013d6:	4c9c                	lw	a5,24(s1)
    800013d8:	ff3791e3          	bne	a5,s3,800013ba <wakeup+0x2a>
    800013dc:	709c                	ld	a5,32(s1)
    800013de:	fd479ee3          	bne	a5,s4,800013ba <wakeup+0x2a>
        p->state = RUNNABLE;
    800013e2:	0154ac23          	sw	s5,24(s1)
    800013e6:	bfd1                	j	800013ba <wakeup+0x2a>
    }
  }
}
    800013e8:	70e2                	ld	ra,56(sp)
    800013ea:	7442                	ld	s0,48(sp)
    800013ec:	74a2                	ld	s1,40(sp)
    800013ee:	7902                	ld	s2,32(sp)
    800013f0:	69e2                	ld	s3,24(sp)
    800013f2:	6a42                	ld	s4,16(sp)
    800013f4:	6aa2                	ld	s5,8(sp)
    800013f6:	6121                	addi	sp,sp,64
    800013f8:	8082                	ret

00000000800013fa <reparent>:
{
    800013fa:	7179                	addi	sp,sp,-48
    800013fc:	f406                	sd	ra,40(sp)
    800013fe:	f022                	sd	s0,32(sp)
    80001400:	ec26                	sd	s1,24(sp)
    80001402:	e84a                	sd	s2,16(sp)
    80001404:	e44e                	sd	s3,8(sp)
    80001406:	e052                	sd	s4,0(sp)
    80001408:	1800                	addi	s0,sp,48
    8000140a:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000140c:	00007497          	auipc	s1,0x7
    80001410:	ad448493          	addi	s1,s1,-1324 # 80007ee0 <proc>
      pp->parent = initproc;
    80001414:	00006a17          	auipc	s4,0x6
    80001418:	65ca0a13          	addi	s4,s4,1628 # 80007a70 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000141c:	0000c997          	auipc	s3,0xc
    80001420:	6c498993          	addi	s3,s3,1732 # 8000dae0 <tickslock>
    80001424:	a029                	j	8000142e <reparent+0x34>
    80001426:	17048493          	addi	s1,s1,368
    8000142a:	01348b63          	beq	s1,s3,80001440 <reparent+0x46>
    if(pp->parent == p){
    8000142e:	7c9c                	ld	a5,56(s1)
    80001430:	ff279be3          	bne	a5,s2,80001426 <reparent+0x2c>
      pp->parent = initproc;
    80001434:	000a3503          	ld	a0,0(s4)
    80001438:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000143a:	f57ff0ef          	jal	80001390 <wakeup>
    8000143e:	b7e5                	j	80001426 <reparent+0x2c>
}
    80001440:	70a2                	ld	ra,40(sp)
    80001442:	7402                	ld	s0,32(sp)
    80001444:	64e2                	ld	s1,24(sp)
    80001446:	6942                	ld	s2,16(sp)
    80001448:	69a2                	ld	s3,8(sp)
    8000144a:	6a02                	ld	s4,0(sp)
    8000144c:	6145                	addi	sp,sp,48
    8000144e:	8082                	ret

0000000080001450 <exit>:
{
    80001450:	7179                	addi	sp,sp,-48
    80001452:	f406                	sd	ra,40(sp)
    80001454:	f022                	sd	s0,32(sp)
    80001456:	ec26                	sd	s1,24(sp)
    80001458:	e84a                	sd	s2,16(sp)
    8000145a:	e44e                	sd	s3,8(sp)
    8000145c:	e052                	sd	s4,0(sp)
    8000145e:	1800                	addi	s0,sp,48
    80001460:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001462:	909ff0ef          	jal	80000d6a <myproc>
    80001466:	89aa                	mv	s3,a0
  if(p == initproc)
    80001468:	00006797          	auipc	a5,0x6
    8000146c:	6087b783          	ld	a5,1544(a5) # 80007a70 <initproc>
    80001470:	0d050493          	addi	s1,a0,208
    80001474:	15050913          	addi	s2,a0,336
    80001478:	00a79b63          	bne	a5,a0,8000148e <exit+0x3e>
    panic("init exiting");
    8000147c:	00006517          	auipc	a0,0x6
    80001480:	db450513          	addi	a0,a0,-588 # 80007230 <etext+0x230>
    80001484:	04a040ef          	jal	800054ce <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80001488:	04a1                	addi	s1,s1,8
    8000148a:	01248963          	beq	s1,s2,8000149c <exit+0x4c>
    if(p->ofile[fd]){
    8000148e:	6088                	ld	a0,0(s1)
    80001490:	dd65                	beqz	a0,80001488 <exit+0x38>
      fileclose(f);
    80001492:	6db010ef          	jal	8000336c <fileclose>
      p->ofile[fd] = 0;
    80001496:	0004b023          	sd	zero,0(s1)
    8000149a:	b7fd                	j	80001488 <exit+0x38>
  begin_op();
    8000149c:	29f010ef          	jal	80002f3a <begin_op>
  iput(p->cwd);
    800014a0:	1509b503          	ld	a0,336(s3)
    800014a4:	360010ef          	jal	80002804 <iput>
  end_op();
    800014a8:	303010ef          	jal	80002faa <end_op>
  p->cwd = 0;
    800014ac:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800014b0:	00006517          	auipc	a0,0x6
    800014b4:	61850513          	addi	a0,a0,1560 # 80007ac8 <wait_lock>
    800014b8:	354040ef          	jal	8000580c <acquire>
  reparent(p);
    800014bc:	854e                	mv	a0,s3
    800014be:	f3dff0ef          	jal	800013fa <reparent>
  wakeup(p->parent);
    800014c2:	0389b503          	ld	a0,56(s3)
    800014c6:	ecbff0ef          	jal	80001390 <wakeup>
  acquire(&p->lock);
    800014ca:	854e                	mv	a0,s3
    800014cc:	340040ef          	jal	8000580c <acquire>
  p->xstate = status;
    800014d0:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800014d4:	4795                	li	a5,5
    800014d6:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800014da:	00006517          	auipc	a0,0x6
    800014de:	5ee50513          	addi	a0,a0,1518 # 80007ac8 <wait_lock>
    800014e2:	3be040ef          	jal	800058a0 <release>
  sched();
    800014e6:	d77ff0ef          	jal	8000125c <sched>
  panic("zombie exit");
    800014ea:	00006517          	auipc	a0,0x6
    800014ee:	d5650513          	addi	a0,a0,-682 # 80007240 <etext+0x240>
    800014f2:	7dd030ef          	jal	800054ce <panic>

00000000800014f6 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    800014f6:	7179                	addi	sp,sp,-48
    800014f8:	f406                	sd	ra,40(sp)
    800014fa:	f022                	sd	s0,32(sp)
    800014fc:	ec26                	sd	s1,24(sp)
    800014fe:	e84a                	sd	s2,16(sp)
    80001500:	e44e                	sd	s3,8(sp)
    80001502:	1800                	addi	s0,sp,48
    80001504:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80001506:	00007497          	auipc	s1,0x7
    8000150a:	9da48493          	addi	s1,s1,-1574 # 80007ee0 <proc>
    8000150e:	0000c997          	auipc	s3,0xc
    80001512:	5d298993          	addi	s3,s3,1490 # 8000dae0 <tickslock>
    acquire(&p->lock);
    80001516:	8526                	mv	a0,s1
    80001518:	2f4040ef          	jal	8000580c <acquire>
    if(p->pid == pid){
    8000151c:	589c                	lw	a5,48(s1)
    8000151e:	01278b63          	beq	a5,s2,80001534 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80001522:	8526                	mv	a0,s1
    80001524:	37c040ef          	jal	800058a0 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80001528:	17048493          	addi	s1,s1,368
    8000152c:	ff3495e3          	bne	s1,s3,80001516 <kill+0x20>
  }
  return -1;
    80001530:	557d                	li	a0,-1
    80001532:	a819                	j	80001548 <kill+0x52>
      p->killed = 1;
    80001534:	4785                	li	a5,1
    80001536:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80001538:	4c98                	lw	a4,24(s1)
    8000153a:	4789                	li	a5,2
    8000153c:	00f70d63          	beq	a4,a5,80001556 <kill+0x60>
      release(&p->lock);
    80001540:	8526                	mv	a0,s1
    80001542:	35e040ef          	jal	800058a0 <release>
      return 0;
    80001546:	4501                	li	a0,0
}
    80001548:	70a2                	ld	ra,40(sp)
    8000154a:	7402                	ld	s0,32(sp)
    8000154c:	64e2                	ld	s1,24(sp)
    8000154e:	6942                	ld	s2,16(sp)
    80001550:	69a2                	ld	s3,8(sp)
    80001552:	6145                	addi	sp,sp,48
    80001554:	8082                	ret
        p->state = RUNNABLE;
    80001556:	478d                	li	a5,3
    80001558:	cc9c                	sw	a5,24(s1)
    8000155a:	b7dd                	j	80001540 <kill+0x4a>

000000008000155c <setkilled>:

void
setkilled(struct proc *p)
{
    8000155c:	1101                	addi	sp,sp,-32
    8000155e:	ec06                	sd	ra,24(sp)
    80001560:	e822                	sd	s0,16(sp)
    80001562:	e426                	sd	s1,8(sp)
    80001564:	1000                	addi	s0,sp,32
    80001566:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001568:	2a4040ef          	jal	8000580c <acquire>
  p->killed = 1;
    8000156c:	4785                	li	a5,1
    8000156e:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80001570:	8526                	mv	a0,s1
    80001572:	32e040ef          	jal	800058a0 <release>
}
    80001576:	60e2                	ld	ra,24(sp)
    80001578:	6442                	ld	s0,16(sp)
    8000157a:	64a2                	ld	s1,8(sp)
    8000157c:	6105                	addi	sp,sp,32
    8000157e:	8082                	ret

0000000080001580 <killed>:

int
killed(struct proc *p)
{
    80001580:	1101                	addi	sp,sp,-32
    80001582:	ec06                	sd	ra,24(sp)
    80001584:	e822                	sd	s0,16(sp)
    80001586:	e426                	sd	s1,8(sp)
    80001588:	e04a                	sd	s2,0(sp)
    8000158a:	1000                	addi	s0,sp,32
    8000158c:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000158e:	27e040ef          	jal	8000580c <acquire>
  k = p->killed;
    80001592:	549c                	lw	a5,40(s1)
    80001594:	893e                	mv	s2,a5
  release(&p->lock);
    80001596:	8526                	mv	a0,s1
    80001598:	308040ef          	jal	800058a0 <release>
  return k;
}
    8000159c:	854a                	mv	a0,s2
    8000159e:	60e2                	ld	ra,24(sp)
    800015a0:	6442                	ld	s0,16(sp)
    800015a2:	64a2                	ld	s1,8(sp)
    800015a4:	6902                	ld	s2,0(sp)
    800015a6:	6105                	addi	sp,sp,32
    800015a8:	8082                	ret

00000000800015aa <wait>:
{
    800015aa:	715d                	addi	sp,sp,-80
    800015ac:	e486                	sd	ra,72(sp)
    800015ae:	e0a2                	sd	s0,64(sp)
    800015b0:	fc26                	sd	s1,56(sp)
    800015b2:	f84a                	sd	s2,48(sp)
    800015b4:	f44e                	sd	s3,40(sp)
    800015b6:	f052                	sd	s4,32(sp)
    800015b8:	ec56                	sd	s5,24(sp)
    800015ba:	e85a                	sd	s6,16(sp)
    800015bc:	e45e                	sd	s7,8(sp)
    800015be:	0880                	addi	s0,sp,80
    800015c0:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800015c2:	fa8ff0ef          	jal	80000d6a <myproc>
    800015c6:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800015c8:	00006517          	auipc	a0,0x6
    800015cc:	50050513          	addi	a0,a0,1280 # 80007ac8 <wait_lock>
    800015d0:	23c040ef          	jal	8000580c <acquire>
        if(pp->state == ZOMBIE){
    800015d4:	4a15                	li	s4,5
        havekids = 1;
    800015d6:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800015d8:	0000c997          	auipc	s3,0xc
    800015dc:	50898993          	addi	s3,s3,1288 # 8000dae0 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800015e0:	00006b17          	auipc	s6,0x6
    800015e4:	4e8b0b13          	addi	s6,s6,1256 # 80007ac8 <wait_lock>
    800015e8:	a869                	j	80001682 <wait+0xd8>
          pid = pp->pid;
    800015ea:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800015ee:	000b8c63          	beqz	s7,80001606 <wait+0x5c>
    800015f2:	4691                	li	a3,4
    800015f4:	02c48613          	addi	a2,s1,44
    800015f8:	85de                	mv	a1,s7
    800015fa:	05093503          	ld	a0,80(s2)
    800015fe:	becff0ef          	jal	800009ea <copyout>
    80001602:	02054a63          	bltz	a0,80001636 <wait+0x8c>
          freeproc(pp);
    80001606:	8526                	mv	a0,s1
    80001608:	8d7ff0ef          	jal	80000ede <freeproc>
          release(&pp->lock);
    8000160c:	8526                	mv	a0,s1
    8000160e:	292040ef          	jal	800058a0 <release>
          release(&wait_lock);
    80001612:	00006517          	auipc	a0,0x6
    80001616:	4b650513          	addi	a0,a0,1206 # 80007ac8 <wait_lock>
    8000161a:	286040ef          	jal	800058a0 <release>
}
    8000161e:	854e                	mv	a0,s3
    80001620:	60a6                	ld	ra,72(sp)
    80001622:	6406                	ld	s0,64(sp)
    80001624:	74e2                	ld	s1,56(sp)
    80001626:	7942                	ld	s2,48(sp)
    80001628:	79a2                	ld	s3,40(sp)
    8000162a:	7a02                	ld	s4,32(sp)
    8000162c:	6ae2                	ld	s5,24(sp)
    8000162e:	6b42                	ld	s6,16(sp)
    80001630:	6ba2                	ld	s7,8(sp)
    80001632:	6161                	addi	sp,sp,80
    80001634:	8082                	ret
            release(&pp->lock);
    80001636:	8526                	mv	a0,s1
    80001638:	268040ef          	jal	800058a0 <release>
            release(&wait_lock);
    8000163c:	00006517          	auipc	a0,0x6
    80001640:	48c50513          	addi	a0,a0,1164 # 80007ac8 <wait_lock>
    80001644:	25c040ef          	jal	800058a0 <release>
            return -1;
    80001648:	59fd                	li	s3,-1
    8000164a:	bfd1                	j	8000161e <wait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000164c:	17048493          	addi	s1,s1,368
    80001650:	03348063          	beq	s1,s3,80001670 <wait+0xc6>
      if(pp->parent == p){
    80001654:	7c9c                	ld	a5,56(s1)
    80001656:	ff279be3          	bne	a5,s2,8000164c <wait+0xa2>
        acquire(&pp->lock);
    8000165a:	8526                	mv	a0,s1
    8000165c:	1b0040ef          	jal	8000580c <acquire>
        if(pp->state == ZOMBIE){
    80001660:	4c9c                	lw	a5,24(s1)
    80001662:	f94784e3          	beq	a5,s4,800015ea <wait+0x40>
        release(&pp->lock);
    80001666:	8526                	mv	a0,s1
    80001668:	238040ef          	jal	800058a0 <release>
        havekids = 1;
    8000166c:	8756                	mv	a4,s5
    8000166e:	bff9                	j	8000164c <wait+0xa2>
    if(!havekids || killed(p)){
    80001670:	cf19                	beqz	a4,8000168e <wait+0xe4>
    80001672:	854a                	mv	a0,s2
    80001674:	f0dff0ef          	jal	80001580 <killed>
    80001678:	e919                	bnez	a0,8000168e <wait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000167a:	85da                	mv	a1,s6
    8000167c:	854a                	mv	a0,s2
    8000167e:	cc7ff0ef          	jal	80001344 <sleep>
    havekids = 0;
    80001682:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001684:	00007497          	auipc	s1,0x7
    80001688:	85c48493          	addi	s1,s1,-1956 # 80007ee0 <proc>
    8000168c:	b7e1                	j	80001654 <wait+0xaa>
      release(&wait_lock);
    8000168e:	00006517          	auipc	a0,0x6
    80001692:	43a50513          	addi	a0,a0,1082 # 80007ac8 <wait_lock>
    80001696:	20a040ef          	jal	800058a0 <release>
      return -1;
    8000169a:	59fd                	li	s3,-1
    8000169c:	b749                	j	8000161e <wait+0x74>

000000008000169e <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000169e:	7179                	addi	sp,sp,-48
    800016a0:	f406                	sd	ra,40(sp)
    800016a2:	f022                	sd	s0,32(sp)
    800016a4:	ec26                	sd	s1,24(sp)
    800016a6:	e84a                	sd	s2,16(sp)
    800016a8:	e44e                	sd	s3,8(sp)
    800016aa:	e052                	sd	s4,0(sp)
    800016ac:	1800                	addi	s0,sp,48
    800016ae:	84aa                	mv	s1,a0
    800016b0:	8a2e                	mv	s4,a1
    800016b2:	89b2                	mv	s3,a2
    800016b4:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800016b6:	eb4ff0ef          	jal	80000d6a <myproc>
  if(user_dst){
    800016ba:	cc99                	beqz	s1,800016d8 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800016bc:	86ca                	mv	a3,s2
    800016be:	864e                	mv	a2,s3
    800016c0:	85d2                	mv	a1,s4
    800016c2:	6928                	ld	a0,80(a0)
    800016c4:	b26ff0ef          	jal	800009ea <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800016c8:	70a2                	ld	ra,40(sp)
    800016ca:	7402                	ld	s0,32(sp)
    800016cc:	64e2                	ld	s1,24(sp)
    800016ce:	6942                	ld	s2,16(sp)
    800016d0:	69a2                	ld	s3,8(sp)
    800016d2:	6a02                	ld	s4,0(sp)
    800016d4:	6145                	addi	sp,sp,48
    800016d6:	8082                	ret
    memmove((char *)dst, src, len);
    800016d8:	0009061b          	sext.w	a2,s2
    800016dc:	85ce                	mv	a1,s3
    800016de:	8552                	mv	a0,s4
    800016e0:	abffe0ef          	jal	8000019e <memmove>
    return 0;
    800016e4:	8526                	mv	a0,s1
    800016e6:	b7cd                	j	800016c8 <either_copyout+0x2a>

00000000800016e8 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800016e8:	7179                	addi	sp,sp,-48
    800016ea:	f406                	sd	ra,40(sp)
    800016ec:	f022                	sd	s0,32(sp)
    800016ee:	ec26                	sd	s1,24(sp)
    800016f0:	e84a                	sd	s2,16(sp)
    800016f2:	e44e                	sd	s3,8(sp)
    800016f4:	e052                	sd	s4,0(sp)
    800016f6:	1800                	addi	s0,sp,48
    800016f8:	8a2a                	mv	s4,a0
    800016fa:	84ae                	mv	s1,a1
    800016fc:	89b2                	mv	s3,a2
    800016fe:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80001700:	e6aff0ef          	jal	80000d6a <myproc>
  if(user_src){
    80001704:	cc99                	beqz	s1,80001722 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80001706:	86ca                	mv	a3,s2
    80001708:	864e                	mv	a2,s3
    8000170a:	85d2                	mv	a1,s4
    8000170c:	6928                	ld	a0,80(a0)
    8000170e:	b8cff0ef          	jal	80000a9a <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80001712:	70a2                	ld	ra,40(sp)
    80001714:	7402                	ld	s0,32(sp)
    80001716:	64e2                	ld	s1,24(sp)
    80001718:	6942                	ld	s2,16(sp)
    8000171a:	69a2                	ld	s3,8(sp)
    8000171c:	6a02                	ld	s4,0(sp)
    8000171e:	6145                	addi	sp,sp,48
    80001720:	8082                	ret
    memmove(dst, (char*)src, len);
    80001722:	0009061b          	sext.w	a2,s2
    80001726:	85ce                	mv	a1,s3
    80001728:	8552                	mv	a0,s4
    8000172a:	a75fe0ef          	jal	8000019e <memmove>
    return 0;
    8000172e:	8526                	mv	a0,s1
    80001730:	b7cd                	j	80001712 <either_copyin+0x2a>

0000000080001732 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80001732:	715d                	addi	sp,sp,-80
    80001734:	e486                	sd	ra,72(sp)
    80001736:	e0a2                	sd	s0,64(sp)
    80001738:	fc26                	sd	s1,56(sp)
    8000173a:	f84a                	sd	s2,48(sp)
    8000173c:	f44e                	sd	s3,40(sp)
    8000173e:	f052                	sd	s4,32(sp)
    80001740:	ec56                	sd	s5,24(sp)
    80001742:	e85a                	sd	s6,16(sp)
    80001744:	e45e                	sd	s7,8(sp)
    80001746:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80001748:	00006517          	auipc	a0,0x6
    8000174c:	8d050513          	addi	a0,a0,-1840 # 80007018 <etext+0x18>
    80001750:	26f030ef          	jal	800051be <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001754:	00007497          	auipc	s1,0x7
    80001758:	8e448493          	addi	s1,s1,-1820 # 80008038 <proc+0x158>
    8000175c:	0000c917          	auipc	s2,0xc
    80001760:	4dc90913          	addi	s2,s2,1244 # 8000dc38 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001764:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80001766:	00006997          	auipc	s3,0x6
    8000176a:	aea98993          	addi	s3,s3,-1302 # 80007250 <etext+0x250>
    printf("%d %s %s", p->pid, state, p->name);
    8000176e:	00006a97          	auipc	s5,0x6
    80001772:	aeaa8a93          	addi	s5,s5,-1302 # 80007258 <etext+0x258>
    printf("\n");
    80001776:	00006a17          	auipc	s4,0x6
    8000177a:	8a2a0a13          	addi	s4,s4,-1886 # 80007018 <etext+0x18>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000177e:	00006b97          	auipc	s7,0x6
    80001782:	0bab8b93          	addi	s7,s7,186 # 80007838 <states.0>
    80001786:	a829                	j	800017a0 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80001788:	ed86a583          	lw	a1,-296(a3)
    8000178c:	8556                	mv	a0,s5
    8000178e:	231030ef          	jal	800051be <printf>
    printf("\n");
    80001792:	8552                	mv	a0,s4
    80001794:	22b030ef          	jal	800051be <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001798:	17048493          	addi	s1,s1,368
    8000179c:	03248263          	beq	s1,s2,800017c0 <procdump+0x8e>
    if(p->state == UNUSED)
    800017a0:	86a6                	mv	a3,s1
    800017a2:	ec04a783          	lw	a5,-320(s1)
    800017a6:	dbed                	beqz	a5,80001798 <procdump+0x66>
      state = "???";
    800017a8:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800017aa:	fcfb6fe3          	bltu	s6,a5,80001788 <procdump+0x56>
    800017ae:	02079713          	slli	a4,a5,0x20
    800017b2:	01d75793          	srli	a5,a4,0x1d
    800017b6:	97de                	add	a5,a5,s7
    800017b8:	6390                	ld	a2,0(a5)
    800017ba:	f679                	bnez	a2,80001788 <procdump+0x56>
      state = "???";
    800017bc:	864e                	mv	a2,s3
    800017be:	b7e9                	j	80001788 <procdump+0x56>
  }
}
    800017c0:	60a6                	ld	ra,72(sp)
    800017c2:	6406                	ld	s0,64(sp)
    800017c4:	74e2                	ld	s1,56(sp)
    800017c6:	7942                	ld	s2,48(sp)
    800017c8:	79a2                	ld	s3,40(sp)
    800017ca:	7a02                	ld	s4,32(sp)
    800017cc:	6ae2                	ld	s5,24(sp)
    800017ce:	6b42                	ld	s6,16(sp)
    800017d0:	6ba2                	ld	s7,8(sp)
    800017d2:	6161                	addi	sp,sp,80
    800017d4:	8082                	ret

00000000800017d6 <swtch>:
    800017d6:	00153023          	sd	ra,0(a0)
    800017da:	00253423          	sd	sp,8(a0)
    800017de:	e900                	sd	s0,16(a0)
    800017e0:	ed04                	sd	s1,24(a0)
    800017e2:	03253023          	sd	s2,32(a0)
    800017e6:	03353423          	sd	s3,40(a0)
    800017ea:	03453823          	sd	s4,48(a0)
    800017ee:	03553c23          	sd	s5,56(a0)
    800017f2:	05653023          	sd	s6,64(a0)
    800017f6:	05753423          	sd	s7,72(a0)
    800017fa:	05853823          	sd	s8,80(a0)
    800017fe:	05953c23          	sd	s9,88(a0)
    80001802:	07a53023          	sd	s10,96(a0)
    80001806:	07b53423          	sd	s11,104(a0)
    8000180a:	0005b083          	ld	ra,0(a1)
    8000180e:	0085b103          	ld	sp,8(a1)
    80001812:	6980                	ld	s0,16(a1)
    80001814:	6d84                	ld	s1,24(a1)
    80001816:	0205b903          	ld	s2,32(a1)
    8000181a:	0285b983          	ld	s3,40(a1)
    8000181e:	0305ba03          	ld	s4,48(a1)
    80001822:	0385ba83          	ld	s5,56(a1)
    80001826:	0405bb03          	ld	s6,64(a1)
    8000182a:	0485bb83          	ld	s7,72(a1)
    8000182e:	0505bc03          	ld	s8,80(a1)
    80001832:	0585bc83          	ld	s9,88(a1)
    80001836:	0605bd03          	ld	s10,96(a1)
    8000183a:	0685bd83          	ld	s11,104(a1)
    8000183e:	8082                	ret

0000000080001840 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001840:	1141                	addi	sp,sp,-16
    80001842:	e406                	sd	ra,8(sp)
    80001844:	e022                	sd	s0,0(sp)
    80001846:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001848:	00006597          	auipc	a1,0x6
    8000184c:	a5058593          	addi	a1,a1,-1456 # 80007298 <etext+0x298>
    80001850:	0000c517          	auipc	a0,0xc
    80001854:	29050513          	addi	a0,a0,656 # 8000dae0 <tickslock>
    80001858:	72b030ef          	jal	80005782 <initlock>
}
    8000185c:	60a2                	ld	ra,8(sp)
    8000185e:	6402                	ld	s0,0(sp)
    80001860:	0141                	addi	sp,sp,16
    80001862:	8082                	ret

0000000080001864 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80001864:	1141                	addi	sp,sp,-16
    80001866:	e406                	sd	ra,8(sp)
    80001868:	e022                	sd	s0,0(sp)
    8000186a:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000186c:	00003797          	auipc	a5,0x3
    80001870:	eb478793          	addi	a5,a5,-332 # 80004720 <kernelvec>
    80001874:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80001878:	60a2                	ld	ra,8(sp)
    8000187a:	6402                	ld	s0,0(sp)
    8000187c:	0141                	addi	sp,sp,16
    8000187e:	8082                	ret

0000000080001880 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80001880:	1141                	addi	sp,sp,-16
    80001882:	e406                	sd	ra,8(sp)
    80001884:	e022                	sd	s0,0(sp)
    80001886:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80001888:	ce2ff0ef          	jal	80000d6a <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000188c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001890:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001892:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80001896:	00004697          	auipc	a3,0x4
    8000189a:	76a68693          	addi	a3,a3,1898 # 80006000 <_trampoline>
    8000189e:	00004717          	auipc	a4,0x4
    800018a2:	76270713          	addi	a4,a4,1890 # 80006000 <_trampoline>
    800018a6:	8f15                	sub	a4,a4,a3
    800018a8:	040007b7          	lui	a5,0x4000
    800018ac:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    800018ae:	07b2                	slli	a5,a5,0xc
    800018b0:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    800018b2:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800018b6:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800018b8:	18002673          	csrr	a2,satp
    800018bc:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800018be:	6d30                	ld	a2,88(a0)
    800018c0:	6138                	ld	a4,64(a0)
    800018c2:	6585                	lui	a1,0x1
    800018c4:	972e                	add	a4,a4,a1
    800018c6:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800018c8:	6d38                	ld	a4,88(a0)
    800018ca:	00000617          	auipc	a2,0x0
    800018ce:	11460613          	addi	a2,a2,276 # 800019de <usertrap>
    800018d2:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800018d4:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800018d6:	8612                	mv	a2,tp
    800018d8:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800018da:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800018de:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800018e2:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800018e6:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800018ea:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800018ec:	6f18                	ld	a4,24(a4)
    800018ee:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    800018f2:	6928                	ld	a0,80(a0)
    800018f4:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800018f6:	00004717          	auipc	a4,0x4
    800018fa:	7a670713          	addi	a4,a4,1958 # 8000609c <userret>
    800018fe:	8f15                	sub	a4,a4,a3
    80001900:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001902:	577d                	li	a4,-1
    80001904:	177e                	slli	a4,a4,0x3f
    80001906:	8d59                	or	a0,a0,a4
    80001908:	9782                	jalr	a5
}
    8000190a:	60a2                	ld	ra,8(sp)
    8000190c:	6402                	ld	s0,0(sp)
    8000190e:	0141                	addi	sp,sp,16
    80001910:	8082                	ret

0000000080001912 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001912:	1141                	addi	sp,sp,-16
    80001914:	e406                	sd	ra,8(sp)
    80001916:	e022                	sd	s0,0(sp)
    80001918:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    8000191a:	c1cff0ef          	jal	80000d36 <cpuid>
    8000191e:	cd11                	beqz	a0,8000193a <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001920:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001924:	000f4737          	lui	a4,0xf4
    80001928:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000192c:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    8000192e:	14d79073          	csrw	stimecmp,a5
}
    80001932:	60a2                	ld	ra,8(sp)
    80001934:	6402                	ld	s0,0(sp)
    80001936:	0141                	addi	sp,sp,16
    80001938:	8082                	ret
    acquire(&tickslock);
    8000193a:	0000c517          	auipc	a0,0xc
    8000193e:	1a650513          	addi	a0,a0,422 # 8000dae0 <tickslock>
    80001942:	6cb030ef          	jal	8000580c <acquire>
    ticks++;
    80001946:	00006717          	auipc	a4,0x6
    8000194a:	13270713          	addi	a4,a4,306 # 80007a78 <ticks>
    8000194e:	431c                	lw	a5,0(a4)
    80001950:	2785                	addiw	a5,a5,1
    80001952:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80001954:	853a                	mv	a0,a4
    80001956:	a3bff0ef          	jal	80001390 <wakeup>
    release(&tickslock);
    8000195a:	0000c517          	auipc	a0,0xc
    8000195e:	18650513          	addi	a0,a0,390 # 8000dae0 <tickslock>
    80001962:	73f030ef          	jal	800058a0 <release>
    80001966:	bf6d                	j	80001920 <clockintr+0xe>

0000000080001968 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001968:	1101                	addi	sp,sp,-32
    8000196a:	ec06                	sd	ra,24(sp)
    8000196c:	e822                	sd	s0,16(sp)
    8000196e:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001970:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001974:	57fd                	li	a5,-1
    80001976:	17fe                	slli	a5,a5,0x3f
    80001978:	07a5                	addi	a5,a5,9
    8000197a:	00f70c63          	beq	a4,a5,80001992 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    8000197e:	57fd                	li	a5,-1
    80001980:	17fe                	slli	a5,a5,0x3f
    80001982:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001984:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001986:	04f70863          	beq	a4,a5,800019d6 <devintr+0x6e>
  }
}
    8000198a:	60e2                	ld	ra,24(sp)
    8000198c:	6442                	ld	s0,16(sp)
    8000198e:	6105                	addi	sp,sp,32
    80001990:	8082                	ret
    80001992:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80001994:	639020ef          	jal	800047cc <plic_claim>
    80001998:	872a                	mv	a4,a0
    8000199a:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    8000199c:	47a9                	li	a5,10
    8000199e:	00f50963          	beq	a0,a5,800019b0 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    800019a2:	4785                	li	a5,1
    800019a4:	00f50963          	beq	a0,a5,800019b6 <devintr+0x4e>
    return 1;
    800019a8:	4505                	li	a0,1
    } else if(irq){
    800019aa:	eb09                	bnez	a4,800019bc <devintr+0x54>
    800019ac:	64a2                	ld	s1,8(sp)
    800019ae:	bff1                	j	8000198a <devintr+0x22>
      uartintr();
    800019b0:	593030ef          	jal	80005742 <uartintr>
    if(irq)
    800019b4:	a819                	j	800019ca <devintr+0x62>
      virtio_disk_intr();
    800019b6:	2ac030ef          	jal	80004c62 <virtio_disk_intr>
    if(irq)
    800019ba:	a801                	j	800019ca <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    800019bc:	85ba                	mv	a1,a4
    800019be:	00006517          	auipc	a0,0x6
    800019c2:	8e250513          	addi	a0,a0,-1822 # 800072a0 <etext+0x2a0>
    800019c6:	7f8030ef          	jal	800051be <printf>
      plic_complete(irq);
    800019ca:	8526                	mv	a0,s1
    800019cc:	621020ef          	jal	800047ec <plic_complete>
    return 1;
    800019d0:	4505                	li	a0,1
    800019d2:	64a2                	ld	s1,8(sp)
    800019d4:	bf5d                	j	8000198a <devintr+0x22>
    clockintr();
    800019d6:	f3dff0ef          	jal	80001912 <clockintr>
    return 2;
    800019da:	4509                	li	a0,2
    800019dc:	b77d                	j	8000198a <devintr+0x22>

00000000800019de <usertrap>:
{
    800019de:	1101                	addi	sp,sp,-32
    800019e0:	ec06                	sd	ra,24(sp)
    800019e2:	e822                	sd	s0,16(sp)
    800019e4:	e426                	sd	s1,8(sp)
    800019e6:	e04a                	sd	s2,0(sp)
    800019e8:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800019ea:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800019ee:	1007f793          	andi	a5,a5,256
    800019f2:	ef85                	bnez	a5,80001a2a <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800019f4:	00003797          	auipc	a5,0x3
    800019f8:	d2c78793          	addi	a5,a5,-724 # 80004720 <kernelvec>
    800019fc:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001a00:	b6aff0ef          	jal	80000d6a <myproc>
    80001a04:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001a06:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001a08:	14102773          	csrr	a4,sepc
    80001a0c:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001a0e:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001a12:	47a1                	li	a5,8
    80001a14:	02f70163          	beq	a4,a5,80001a36 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001a18:	f51ff0ef          	jal	80001968 <devintr>
    80001a1c:	892a                	mv	s2,a0
    80001a1e:	c135                	beqz	a0,80001a82 <usertrap+0xa4>
  if(killed(p))
    80001a20:	8526                	mv	a0,s1
    80001a22:	b5fff0ef          	jal	80001580 <killed>
    80001a26:	cd1d                	beqz	a0,80001a64 <usertrap+0x86>
    80001a28:	a81d                	j	80001a5e <usertrap+0x80>
    panic("usertrap: not from user mode");
    80001a2a:	00006517          	auipc	a0,0x6
    80001a2e:	89650513          	addi	a0,a0,-1898 # 800072c0 <etext+0x2c0>
    80001a32:	29d030ef          	jal	800054ce <panic>
    if(killed(p))
    80001a36:	b4bff0ef          	jal	80001580 <killed>
    80001a3a:	e121                	bnez	a0,80001a7a <usertrap+0x9c>
    p->trapframe->epc += 4;
    80001a3c:	6cb8                	ld	a4,88(s1)
    80001a3e:	6f1c                	ld	a5,24(a4)
    80001a40:	0791                	addi	a5,a5,4
    80001a42:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a44:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001a48:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001a4c:	10079073          	csrw	sstatus,a5
    syscall();
    80001a50:	242000ef          	jal	80001c92 <syscall>
  if(killed(p))
    80001a54:	8526                	mv	a0,s1
    80001a56:	b2bff0ef          	jal	80001580 <killed>
    80001a5a:	c901                	beqz	a0,80001a6a <usertrap+0x8c>
    80001a5c:	4901                	li	s2,0
    exit(-1);
    80001a5e:	557d                	li	a0,-1
    80001a60:	9f1ff0ef          	jal	80001450 <exit>
  if(which_dev == 2)
    80001a64:	4789                	li	a5,2
    80001a66:	04f90563          	beq	s2,a5,80001ab0 <usertrap+0xd2>
  usertrapret();
    80001a6a:	e17ff0ef          	jal	80001880 <usertrapret>
}
    80001a6e:	60e2                	ld	ra,24(sp)
    80001a70:	6442                	ld	s0,16(sp)
    80001a72:	64a2                	ld	s1,8(sp)
    80001a74:	6902                	ld	s2,0(sp)
    80001a76:	6105                	addi	sp,sp,32
    80001a78:	8082                	ret
      exit(-1);
    80001a7a:	557d                	li	a0,-1
    80001a7c:	9d5ff0ef          	jal	80001450 <exit>
    80001a80:	bf75                	j	80001a3c <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001a82:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001a86:	5890                	lw	a2,48(s1)
    80001a88:	00006517          	auipc	a0,0x6
    80001a8c:	85850513          	addi	a0,a0,-1960 # 800072e0 <etext+0x2e0>
    80001a90:	72e030ef          	jal	800051be <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001a94:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001a98:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001a9c:	00006517          	auipc	a0,0x6
    80001aa0:	87450513          	addi	a0,a0,-1932 # 80007310 <etext+0x310>
    80001aa4:	71a030ef          	jal	800051be <printf>
    setkilled(p);
    80001aa8:	8526                	mv	a0,s1
    80001aaa:	ab3ff0ef          	jal	8000155c <setkilled>
    80001aae:	b75d                	j	80001a54 <usertrap+0x76>
    yield();
    80001ab0:	869ff0ef          	jal	80001318 <yield>
    80001ab4:	bf5d                	j	80001a6a <usertrap+0x8c>

0000000080001ab6 <kerneltrap>:
{
    80001ab6:	7179                	addi	sp,sp,-48
    80001ab8:	f406                	sd	ra,40(sp)
    80001aba:	f022                	sd	s0,32(sp)
    80001abc:	ec26                	sd	s1,24(sp)
    80001abe:	e84a                	sd	s2,16(sp)
    80001ac0:	e44e                	sd	s3,8(sp)
    80001ac2:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001ac4:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001ac8:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001acc:	142027f3          	csrr	a5,scause
    80001ad0:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80001ad2:	1004f793          	andi	a5,s1,256
    80001ad6:	c795                	beqz	a5,80001b02 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001ad8:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001adc:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001ade:	eb85                	bnez	a5,80001b0e <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80001ae0:	e89ff0ef          	jal	80001968 <devintr>
    80001ae4:	c91d                	beqz	a0,80001b1a <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80001ae6:	4789                	li	a5,2
    80001ae8:	04f50a63          	beq	a0,a5,80001b3c <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001aec:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001af0:	10049073          	csrw	sstatus,s1
}
    80001af4:	70a2                	ld	ra,40(sp)
    80001af6:	7402                	ld	s0,32(sp)
    80001af8:	64e2                	ld	s1,24(sp)
    80001afa:	6942                	ld	s2,16(sp)
    80001afc:	69a2                	ld	s3,8(sp)
    80001afe:	6145                	addi	sp,sp,48
    80001b00:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001b02:	00006517          	auipc	a0,0x6
    80001b06:	83650513          	addi	a0,a0,-1994 # 80007338 <etext+0x338>
    80001b0a:	1c5030ef          	jal	800054ce <panic>
    panic("kerneltrap: interrupts enabled");
    80001b0e:	00006517          	auipc	a0,0x6
    80001b12:	85250513          	addi	a0,a0,-1966 # 80007360 <etext+0x360>
    80001b16:	1b9030ef          	jal	800054ce <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b1a:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001b1e:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001b22:	85ce                	mv	a1,s3
    80001b24:	00006517          	auipc	a0,0x6
    80001b28:	85c50513          	addi	a0,a0,-1956 # 80007380 <etext+0x380>
    80001b2c:	692030ef          	jal	800051be <printf>
    panic("kerneltrap");
    80001b30:	00006517          	auipc	a0,0x6
    80001b34:	87850513          	addi	a0,a0,-1928 # 800073a8 <etext+0x3a8>
    80001b38:	197030ef          	jal	800054ce <panic>
  if(which_dev == 2 && myproc() != 0)
    80001b3c:	a2eff0ef          	jal	80000d6a <myproc>
    80001b40:	d555                	beqz	a0,80001aec <kerneltrap+0x36>
    yield();
    80001b42:	fd6ff0ef          	jal	80001318 <yield>
    80001b46:	b75d                	j	80001aec <kerneltrap+0x36>

0000000080001b48 <argraw>:
    return strlen(buf);
}

static uint64
argraw(int n)
{
    80001b48:	1101                	addi	sp,sp,-32
    80001b4a:	ec06                	sd	ra,24(sp)
    80001b4c:	e822                	sd	s0,16(sp)
    80001b4e:	e426                	sd	s1,8(sp)
    80001b50:	1000                	addi	s0,sp,32
    80001b52:	84aa                	mv	s1,a0
    struct proc *p = myproc();
    80001b54:	a16ff0ef          	jal	80000d6a <myproc>
    switch (n) {
    80001b58:	4795                	li	a5,5
    80001b5a:	0497e163          	bltu	a5,s1,80001b9c <argraw+0x54>
    80001b5e:	048a                	slli	s1,s1,0x2
    80001b60:	00006717          	auipc	a4,0x6
    80001b64:	d0870713          	addi	a4,a4,-760 # 80007868 <states.0+0x30>
    80001b68:	94ba                	add	s1,s1,a4
    80001b6a:	409c                	lw	a5,0(s1)
    80001b6c:	97ba                	add	a5,a5,a4
    80001b6e:	8782                	jr	a5
        case 0:
            return p->trapframe->a0;
    80001b70:	6d3c                	ld	a5,88(a0)
    80001b72:	7ba8                	ld	a0,112(a5)
        case 5:
            return p->trapframe->a5;
    }
    panic("argraw");
    return -1;
}
    80001b74:	60e2                	ld	ra,24(sp)
    80001b76:	6442                	ld	s0,16(sp)
    80001b78:	64a2                	ld	s1,8(sp)
    80001b7a:	6105                	addi	sp,sp,32
    80001b7c:	8082                	ret
            return p->trapframe->a1;
    80001b7e:	6d3c                	ld	a5,88(a0)
    80001b80:	7fa8                	ld	a0,120(a5)
    80001b82:	bfcd                	j	80001b74 <argraw+0x2c>
            return p->trapframe->a2;
    80001b84:	6d3c                	ld	a5,88(a0)
    80001b86:	63c8                	ld	a0,128(a5)
    80001b88:	b7f5                	j	80001b74 <argraw+0x2c>
            return p->trapframe->a3;
    80001b8a:	6d3c                	ld	a5,88(a0)
    80001b8c:	67c8                	ld	a0,136(a5)
    80001b8e:	b7dd                	j	80001b74 <argraw+0x2c>
            return p->trapframe->a4;
    80001b90:	6d3c                	ld	a5,88(a0)
    80001b92:	6bc8                	ld	a0,144(a5)
    80001b94:	b7c5                	j	80001b74 <argraw+0x2c>
            return p->trapframe->a5;
    80001b96:	6d3c                	ld	a5,88(a0)
    80001b98:	6fc8                	ld	a0,152(a5)
    80001b9a:	bfe9                	j	80001b74 <argraw+0x2c>
    panic("argraw");
    80001b9c:	00006517          	auipc	a0,0x6
    80001ba0:	81c50513          	addi	a0,a0,-2020 # 800073b8 <etext+0x3b8>
    80001ba4:	12b030ef          	jal	800054ce <panic>

0000000080001ba8 <fetchaddr>:
{
    80001ba8:	1101                	addi	sp,sp,-32
    80001baa:	ec06                	sd	ra,24(sp)
    80001bac:	e822                	sd	s0,16(sp)
    80001bae:	e426                	sd	s1,8(sp)
    80001bb0:	e04a                	sd	s2,0(sp)
    80001bb2:	1000                	addi	s0,sp,32
    80001bb4:	84aa                	mv	s1,a0
    80001bb6:	892e                	mv	s2,a1
    struct proc *p = myproc();
    80001bb8:	9b2ff0ef          	jal	80000d6a <myproc>
    if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001bbc:	653c                	ld	a5,72(a0)
    80001bbe:	02f4f663          	bgeu	s1,a5,80001bea <fetchaddr+0x42>
    80001bc2:	00848713          	addi	a4,s1,8
    80001bc6:	02e7e463          	bltu	a5,a4,80001bee <fetchaddr+0x46>
    if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001bca:	46a1                	li	a3,8
    80001bcc:	8626                	mv	a2,s1
    80001bce:	85ca                	mv	a1,s2
    80001bd0:	6928                	ld	a0,80(a0)
    80001bd2:	ec9fe0ef          	jal	80000a9a <copyin>
    80001bd6:	00a03533          	snez	a0,a0
    80001bda:	40a0053b          	negw	a0,a0
}
    80001bde:	60e2                	ld	ra,24(sp)
    80001be0:	6442                	ld	s0,16(sp)
    80001be2:	64a2                	ld	s1,8(sp)
    80001be4:	6902                	ld	s2,0(sp)
    80001be6:	6105                	addi	sp,sp,32
    80001be8:	8082                	ret
        return -1;
    80001bea:	557d                	li	a0,-1
    80001bec:	bfcd                	j	80001bde <fetchaddr+0x36>
    80001bee:	557d                	li	a0,-1
    80001bf0:	b7fd                	j	80001bde <fetchaddr+0x36>

0000000080001bf2 <fetchstr>:
{
    80001bf2:	7179                	addi	sp,sp,-48
    80001bf4:	f406                	sd	ra,40(sp)
    80001bf6:	f022                	sd	s0,32(sp)
    80001bf8:	ec26                	sd	s1,24(sp)
    80001bfa:	e84a                	sd	s2,16(sp)
    80001bfc:	e44e                	sd	s3,8(sp)
    80001bfe:	1800                	addi	s0,sp,48
    80001c00:	89aa                	mv	s3,a0
    80001c02:	84ae                	mv	s1,a1
    80001c04:	8932                	mv	s2,a2
    struct proc *p = myproc();
    80001c06:	964ff0ef          	jal	80000d6a <myproc>
    if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001c0a:	86ca                	mv	a3,s2
    80001c0c:	864e                	mv	a2,s3
    80001c0e:	85a6                	mv	a1,s1
    80001c10:	6928                	ld	a0,80(a0)
    80001c12:	f0ffe0ef          	jal	80000b20 <copyinstr>
    80001c16:	00054c63          	bltz	a0,80001c2e <fetchstr+0x3c>
    return strlen(buf);
    80001c1a:	8526                	mv	a0,s1
    80001c1c:	eacfe0ef          	jal	800002c8 <strlen>
}
    80001c20:	70a2                	ld	ra,40(sp)
    80001c22:	7402                	ld	s0,32(sp)
    80001c24:	64e2                	ld	s1,24(sp)
    80001c26:	6942                	ld	s2,16(sp)
    80001c28:	69a2                	ld	s3,8(sp)
    80001c2a:	6145                	addi	sp,sp,48
    80001c2c:	8082                	ret
        return -1;
    80001c2e:	557d                	li	a0,-1
    80001c30:	bfc5                	j	80001c20 <fetchstr+0x2e>

0000000080001c32 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001c32:	1101                	addi	sp,sp,-32
    80001c34:	ec06                	sd	ra,24(sp)
    80001c36:	e822                	sd	s0,16(sp)
    80001c38:	e426                	sd	s1,8(sp)
    80001c3a:	1000                	addi	s0,sp,32
    80001c3c:	84ae                	mv	s1,a1
    *ip = argraw(n);
    80001c3e:	f0bff0ef          	jal	80001b48 <argraw>
    80001c42:	c088                	sw	a0,0(s1)
}
    80001c44:	60e2                	ld	ra,24(sp)
    80001c46:	6442                	ld	s0,16(sp)
    80001c48:	64a2                	ld	s1,8(sp)
    80001c4a:	6105                	addi	sp,sp,32
    80001c4c:	8082                	ret

0000000080001c4e <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001c4e:	1101                	addi	sp,sp,-32
    80001c50:	ec06                	sd	ra,24(sp)
    80001c52:	e822                	sd	s0,16(sp)
    80001c54:	e426                	sd	s1,8(sp)
    80001c56:	1000                	addi	s0,sp,32
    80001c58:	84ae                	mv	s1,a1
    *ip = argraw(n);
    80001c5a:	eefff0ef          	jal	80001b48 <argraw>
    80001c5e:	e088                	sd	a0,0(s1)
}
    80001c60:	60e2                	ld	ra,24(sp)
    80001c62:	6442                	ld	s0,16(sp)
    80001c64:	64a2                	ld	s1,8(sp)
    80001c66:	6105                	addi	sp,sp,32
    80001c68:	8082                	ret

0000000080001c6a <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001c6a:	1101                	addi	sp,sp,-32
    80001c6c:	ec06                	sd	ra,24(sp)
    80001c6e:	e822                	sd	s0,16(sp)
    80001c70:	e426                	sd	s1,8(sp)
    80001c72:	e04a                	sd	s2,0(sp)
    80001c74:	1000                	addi	s0,sp,32
    80001c76:	892e                	mv	s2,a1
    80001c78:	84b2                	mv	s1,a2
    *ip = argraw(n);
    80001c7a:	ecfff0ef          	jal	80001b48 <argraw>
    uint64 addr;
    argaddr(n, &addr);
    return fetchstr(addr, buf, max);
    80001c7e:	8626                	mv	a2,s1
    80001c80:	85ca                	mv	a1,s2
    80001c82:	f71ff0ef          	jal	80001bf2 <fetchstr>
}
    80001c86:	60e2                	ld	ra,24(sp)
    80001c88:	6442                	ld	s0,16(sp)
    80001c8a:	64a2                	ld	s1,8(sp)
    80001c8c:	6902                	ld	s2,0(sp)
    80001c8e:	6105                	addi	sp,sp,32
    80001c90:	8082                	ret

0000000080001c92 <syscall>:
        [SYS_trace]   sys_trace,
};

void
syscall(void)
{
    80001c92:	7179                	addi	sp,sp,-48
    80001c94:	f406                	sd	ra,40(sp)
    80001c96:	f022                	sd	s0,32(sp)
    80001c98:	ec26                	sd	s1,24(sp)
    80001c9a:	e84a                	sd	s2,16(sp)
    80001c9c:	e44e                	sd	s3,8(sp)
    80001c9e:	1800                	addi	s0,sp,48
    int num;
    struct proc *p = myproc();
    80001ca0:	8caff0ef          	jal	80000d6a <myproc>
    80001ca4:	84aa                	mv	s1,a0

    num = p->trapframe->a7;
    80001ca6:	05853903          	ld	s2,88(a0)
    80001caa:	0a893783          	ld	a5,168(s2)
    80001cae:	0007899b          	sext.w	s3,a5
    if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001cb2:	37fd                	addiw	a5,a5,-1
    80001cb4:	4755                	li	a4,21
    80001cb6:	04f76563          	bltu	a4,a5,80001d00 <syscall+0x6e>
    80001cba:	00399713          	slli	a4,s3,0x3
    80001cbe:	00006797          	auipc	a5,0x6
    80001cc2:	bc278793          	addi	a5,a5,-1086 # 80007880 <syscalls>
    80001cc6:	97ba                	add	a5,a5,a4
    80001cc8:	639c                	ld	a5,0(a5)
    80001cca:	cb9d                	beqz	a5,80001d00 <syscall+0x6e>
        // Use num to lookup the system call function for num, call it,
        // and store its return value in p->trapframe->a0
        p->trapframe->a0 = syscalls[num]();
    80001ccc:	9782                	jalr	a5
    80001cce:	06a93823          	sd	a0,112(s2)

        // Print trace output if this syscall is being traced
        if((p->trace_mask & (1 << num)) != 0) {
    80001cd2:	1684a783          	lw	a5,360(s1)
    80001cd6:	4137d7bb          	sraw	a5,a5,s3
    80001cda:	8b85                	andi	a5,a5,1
    80001cdc:	cf9d                	beqz	a5,80001d1a <syscall+0x88>
            printf("%d: syscall %s -> %ld\n", p->pid, syscall_names[num], p->trapframe->a0);
    80001cde:	6cb8                	ld	a4,88(s1)
    80001ce0:	098e                	slli	s3,s3,0x3
    80001ce2:	00006797          	auipc	a5,0x6
    80001ce6:	b9e78793          	addi	a5,a5,-1122 # 80007880 <syscalls>
    80001cea:	97ce                	add	a5,a5,s3
    80001cec:	7b34                	ld	a3,112(a4)
    80001cee:	7fd0                	ld	a2,184(a5)
    80001cf0:	588c                	lw	a1,48(s1)
    80001cf2:	00005517          	auipc	a0,0x5
    80001cf6:	6ce50513          	addi	a0,a0,1742 # 800073c0 <etext+0x3c0>
    80001cfa:	4c4030ef          	jal	800051be <printf>
    80001cfe:	a831                	j	80001d1a <syscall+0x88>
        }
    } else {
        printf("%d %s: unknown sys call %d\n",
    80001d00:	86ce                	mv	a3,s3
    80001d02:	15848613          	addi	a2,s1,344
    80001d06:	588c                	lw	a1,48(s1)
    80001d08:	00005517          	auipc	a0,0x5
    80001d0c:	6d050513          	addi	a0,a0,1744 # 800073d8 <etext+0x3d8>
    80001d10:	4ae030ef          	jal	800051be <printf>
               p->pid, p->name, num);
        p->trapframe->a0 = -1;
    80001d14:	6cbc                	ld	a5,88(s1)
    80001d16:	577d                	li	a4,-1
    80001d18:	fbb8                	sd	a4,112(a5)
    }
    80001d1a:	70a2                	ld	ra,40(sp)
    80001d1c:	7402                	ld	s0,32(sp)
    80001d1e:	64e2                	ld	s1,24(sp)
    80001d20:	6942                	ld	s2,16(sp)
    80001d22:	69a2                	ld	s3,8(sp)
    80001d24:	6145                	addi	sp,sp,48
    80001d26:	8082                	ret

0000000080001d28 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001d28:	1101                	addi	sp,sp,-32
    80001d2a:	ec06                	sd	ra,24(sp)
    80001d2c:	e822                	sd	s0,16(sp)
    80001d2e:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001d30:	fec40593          	addi	a1,s0,-20
    80001d34:	4501                	li	a0,0
    80001d36:	efdff0ef          	jal	80001c32 <argint>
  exit(n);
    80001d3a:	fec42503          	lw	a0,-20(s0)
    80001d3e:	f12ff0ef          	jal	80001450 <exit>
  return 0;  // not reached
}
    80001d42:	4501                	li	a0,0
    80001d44:	60e2                	ld	ra,24(sp)
    80001d46:	6442                	ld	s0,16(sp)
    80001d48:	6105                	addi	sp,sp,32
    80001d4a:	8082                	ret

0000000080001d4c <sys_getpid>:

uint64
sys_getpid(void)
{
    80001d4c:	1141                	addi	sp,sp,-16
    80001d4e:	e406                	sd	ra,8(sp)
    80001d50:	e022                	sd	s0,0(sp)
    80001d52:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001d54:	816ff0ef          	jal	80000d6a <myproc>
}
    80001d58:	5908                	lw	a0,48(a0)
    80001d5a:	60a2                	ld	ra,8(sp)
    80001d5c:	6402                	ld	s0,0(sp)
    80001d5e:	0141                	addi	sp,sp,16
    80001d60:	8082                	ret

0000000080001d62 <sys_fork>:

uint64
sys_fork(void)
{
    80001d62:	1141                	addi	sp,sp,-16
    80001d64:	e406                	sd	ra,8(sp)
    80001d66:	e022                	sd	s0,0(sp)
    80001d68:	0800                	addi	s0,sp,16
  return fork();
    80001d6a:	b28ff0ef          	jal	80001092 <fork>
}
    80001d6e:	60a2                	ld	ra,8(sp)
    80001d70:	6402                	ld	s0,0(sp)
    80001d72:	0141                	addi	sp,sp,16
    80001d74:	8082                	ret

0000000080001d76 <sys_wait>:

uint64
sys_wait(void)
{
    80001d76:	1101                	addi	sp,sp,-32
    80001d78:	ec06                	sd	ra,24(sp)
    80001d7a:	e822                	sd	s0,16(sp)
    80001d7c:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001d7e:	fe840593          	addi	a1,s0,-24
    80001d82:	4501                	li	a0,0
    80001d84:	ecbff0ef          	jal	80001c4e <argaddr>
  return wait(p);
    80001d88:	fe843503          	ld	a0,-24(s0)
    80001d8c:	81fff0ef          	jal	800015aa <wait>
}
    80001d90:	60e2                	ld	ra,24(sp)
    80001d92:	6442                	ld	s0,16(sp)
    80001d94:	6105                	addi	sp,sp,32
    80001d96:	8082                	ret

0000000080001d98 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001d98:	7179                	addi	sp,sp,-48
    80001d9a:	f406                	sd	ra,40(sp)
    80001d9c:	f022                	sd	s0,32(sp)
    80001d9e:	ec26                	sd	s1,24(sp)
    80001da0:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001da2:	fdc40593          	addi	a1,s0,-36
    80001da6:	4501                	li	a0,0
    80001da8:	e8bff0ef          	jal	80001c32 <argint>
  addr = myproc()->sz;
    80001dac:	fbffe0ef          	jal	80000d6a <myproc>
    80001db0:	653c                	ld	a5,72(a0)
    80001db2:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80001db4:	fdc42503          	lw	a0,-36(s0)
    80001db8:	a8aff0ef          	jal	80001042 <growproc>
    80001dbc:	00054863          	bltz	a0,80001dcc <sys_sbrk+0x34>
    return -1;
  return addr;
}
    80001dc0:	8526                	mv	a0,s1
    80001dc2:	70a2                	ld	ra,40(sp)
    80001dc4:	7402                	ld	s0,32(sp)
    80001dc6:	64e2                	ld	s1,24(sp)
    80001dc8:	6145                	addi	sp,sp,48
    80001dca:	8082                	ret
    return -1;
    80001dcc:	57fd                	li	a5,-1
    80001dce:	84be                	mv	s1,a5
    80001dd0:	bfc5                	j	80001dc0 <sys_sbrk+0x28>

0000000080001dd2 <sys_sleep>:

uint64
sys_sleep(void)
{
    80001dd2:	7139                	addi	sp,sp,-64
    80001dd4:	fc06                	sd	ra,56(sp)
    80001dd6:	f822                	sd	s0,48(sp)
    80001dd8:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80001dda:	fcc40593          	addi	a1,s0,-52
    80001dde:	4501                	li	a0,0
    80001de0:	e53ff0ef          	jal	80001c32 <argint>
  if(n < 0)
    80001de4:	fcc42783          	lw	a5,-52(s0)
    80001de8:	0607c863          	bltz	a5,80001e58 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80001dec:	0000c517          	auipc	a0,0xc
    80001df0:	cf450513          	addi	a0,a0,-780 # 8000dae0 <tickslock>
    80001df4:	219030ef          	jal	8000580c <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80001df8:	fcc42783          	lw	a5,-52(s0)
    80001dfc:	c3b9                	beqz	a5,80001e42 <sys_sleep+0x70>
    80001dfe:	f426                	sd	s1,40(sp)
    80001e00:	f04a                	sd	s2,32(sp)
    80001e02:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80001e04:	00006997          	auipc	s3,0x6
    80001e08:	c749a983          	lw	s3,-908(s3) # 80007a78 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80001e0c:	0000c917          	auipc	s2,0xc
    80001e10:	cd490913          	addi	s2,s2,-812 # 8000dae0 <tickslock>
    80001e14:	00006497          	auipc	s1,0x6
    80001e18:	c6448493          	addi	s1,s1,-924 # 80007a78 <ticks>
    if(killed(myproc())){
    80001e1c:	f4ffe0ef          	jal	80000d6a <myproc>
    80001e20:	f60ff0ef          	jal	80001580 <killed>
    80001e24:	ed0d                	bnez	a0,80001e5e <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80001e26:	85ca                	mv	a1,s2
    80001e28:	8526                	mv	a0,s1
    80001e2a:	d1aff0ef          	jal	80001344 <sleep>
  while(ticks - ticks0 < n){
    80001e2e:	409c                	lw	a5,0(s1)
    80001e30:	413787bb          	subw	a5,a5,s3
    80001e34:	fcc42703          	lw	a4,-52(s0)
    80001e38:	fee7e2e3          	bltu	a5,a4,80001e1c <sys_sleep+0x4a>
    80001e3c:	74a2                	ld	s1,40(sp)
    80001e3e:	7902                	ld	s2,32(sp)
    80001e40:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80001e42:	0000c517          	auipc	a0,0xc
    80001e46:	c9e50513          	addi	a0,a0,-866 # 8000dae0 <tickslock>
    80001e4a:	257030ef          	jal	800058a0 <release>
  return 0;
    80001e4e:	4501                	li	a0,0
}
    80001e50:	70e2                	ld	ra,56(sp)
    80001e52:	7442                	ld	s0,48(sp)
    80001e54:	6121                	addi	sp,sp,64
    80001e56:	8082                	ret
    n = 0;
    80001e58:	fc042623          	sw	zero,-52(s0)
    80001e5c:	bf41                	j	80001dec <sys_sleep+0x1a>
      release(&tickslock);
    80001e5e:	0000c517          	auipc	a0,0xc
    80001e62:	c8250513          	addi	a0,a0,-894 # 8000dae0 <tickslock>
    80001e66:	23b030ef          	jal	800058a0 <release>
      return -1;
    80001e6a:	557d                	li	a0,-1
    80001e6c:	74a2                	ld	s1,40(sp)
    80001e6e:	7902                	ld	s2,32(sp)
    80001e70:	69e2                	ld	s3,24(sp)
    80001e72:	bff9                	j	80001e50 <sys_sleep+0x7e>

0000000080001e74 <sys_kill>:

uint64
sys_kill(void)
{
    80001e74:	1101                	addi	sp,sp,-32
    80001e76:	ec06                	sd	ra,24(sp)
    80001e78:	e822                	sd	s0,16(sp)
    80001e7a:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80001e7c:	fec40593          	addi	a1,s0,-20
    80001e80:	4501                	li	a0,0
    80001e82:	db1ff0ef          	jal	80001c32 <argint>
  return kill(pid);
    80001e86:	fec42503          	lw	a0,-20(s0)
    80001e8a:	e6cff0ef          	jal	800014f6 <kill>
}
    80001e8e:	60e2                	ld	ra,24(sp)
    80001e90:	6442                	ld	s0,16(sp)
    80001e92:	6105                	addi	sp,sp,32
    80001e94:	8082                	ret

0000000080001e96 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80001e96:	1101                	addi	sp,sp,-32
    80001e98:	ec06                	sd	ra,24(sp)
    80001e9a:	e822                	sd	s0,16(sp)
    80001e9c:	e426                	sd	s1,8(sp)
    80001e9e:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80001ea0:	0000c517          	auipc	a0,0xc
    80001ea4:	c4050513          	addi	a0,a0,-960 # 8000dae0 <tickslock>
    80001ea8:	165030ef          	jal	8000580c <acquire>
  xticks = ticks;
    80001eac:	00006797          	auipc	a5,0x6
    80001eb0:	bcc7a783          	lw	a5,-1076(a5) # 80007a78 <ticks>
    80001eb4:	84be                	mv	s1,a5
  release(&tickslock);
    80001eb6:	0000c517          	auipc	a0,0xc
    80001eba:	c2a50513          	addi	a0,a0,-982 # 8000dae0 <tickslock>
    80001ebe:	1e3030ef          	jal	800058a0 <release>
  return xticks;
}
    80001ec2:	02049513          	slli	a0,s1,0x20
    80001ec6:	9101                	srli	a0,a0,0x20
    80001ec8:	60e2                	ld	ra,24(sp)
    80001eca:	6442                	ld	s0,16(sp)
    80001ecc:	64a2                	ld	s1,8(sp)
    80001ece:	6105                	addi	sp,sp,32
    80001ed0:	8082                	ret

0000000080001ed2 <sys_trace>:
uint64
sys_trace(void)
{
    80001ed2:	1101                	addi	sp,sp,-32
    80001ed4:	ec06                	sd	ra,24(sp)
    80001ed6:	e822                	sd	s0,16(sp)
    80001ed8:	1000                	addi	s0,sp,32
    int mask;

    argint(0, &mask);  // 直接调用，不需要检查返回值
    80001eda:	fec40593          	addi	a1,s0,-20
    80001ede:	4501                	li	a0,0
    80001ee0:	d53ff0ef          	jal	80001c32 <argint>

    myproc()->trace_mask = mask;
    80001ee4:	e87fe0ef          	jal	80000d6a <myproc>
    80001ee8:	fec42783          	lw	a5,-20(s0)
    80001eec:	16f52423          	sw	a5,360(a0)
    return 0;
    80001ef0:	4501                	li	a0,0
    80001ef2:	60e2                	ld	ra,24(sp)
    80001ef4:	6442                	ld	s0,16(sp)
    80001ef6:	6105                	addi	sp,sp,32
    80001ef8:	8082                	ret

0000000080001efa <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80001efa:	7179                	addi	sp,sp,-48
    80001efc:	f406                	sd	ra,40(sp)
    80001efe:	f022                	sd	s0,32(sp)
    80001f00:	ec26                	sd	s1,24(sp)
    80001f02:	e84a                	sd	s2,16(sp)
    80001f04:	e44e                	sd	s3,8(sp)
    80001f06:	e052                	sd	s4,0(sp)
    80001f08:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80001f0a:	00005597          	auipc	a1,0x5
    80001f0e:	59658593          	addi	a1,a1,1430 # 800074a0 <etext+0x4a0>
    80001f12:	0000c517          	auipc	a0,0xc
    80001f16:	be650513          	addi	a0,a0,-1050 # 8000daf8 <bcache>
    80001f1a:	069030ef          	jal	80005782 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80001f1e:	00014797          	auipc	a5,0x14
    80001f22:	bda78793          	addi	a5,a5,-1062 # 80015af8 <bcache+0x8000>
    80001f26:	00014717          	auipc	a4,0x14
    80001f2a:	e3a70713          	addi	a4,a4,-454 # 80015d60 <bcache+0x8268>
    80001f2e:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80001f32:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80001f36:	0000c497          	auipc	s1,0xc
    80001f3a:	bda48493          	addi	s1,s1,-1062 # 8000db10 <bcache+0x18>
    b->next = bcache.head.next;
    80001f3e:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80001f40:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80001f42:	00005a17          	auipc	s4,0x5
    80001f46:	566a0a13          	addi	s4,s4,1382 # 800074a8 <etext+0x4a8>
    b->next = bcache.head.next;
    80001f4a:	2b893783          	ld	a5,696(s2)
    80001f4e:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80001f50:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80001f54:	85d2                	mv	a1,s4
    80001f56:	01048513          	addi	a0,s1,16
    80001f5a:	24c010ef          	jal	800031a6 <initsleeplock>
    bcache.head.next->prev = b;
    80001f5e:	2b893783          	ld	a5,696(s2)
    80001f62:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80001f64:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80001f68:	45848493          	addi	s1,s1,1112
    80001f6c:	fd349fe3          	bne	s1,s3,80001f4a <binit+0x50>
  }
}
    80001f70:	70a2                	ld	ra,40(sp)
    80001f72:	7402                	ld	s0,32(sp)
    80001f74:	64e2                	ld	s1,24(sp)
    80001f76:	6942                	ld	s2,16(sp)
    80001f78:	69a2                	ld	s3,8(sp)
    80001f7a:	6a02                	ld	s4,0(sp)
    80001f7c:	6145                	addi	sp,sp,48
    80001f7e:	8082                	ret

0000000080001f80 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80001f80:	7179                	addi	sp,sp,-48
    80001f82:	f406                	sd	ra,40(sp)
    80001f84:	f022                	sd	s0,32(sp)
    80001f86:	ec26                	sd	s1,24(sp)
    80001f88:	e84a                	sd	s2,16(sp)
    80001f8a:	e44e                	sd	s3,8(sp)
    80001f8c:	1800                	addi	s0,sp,48
    80001f8e:	892a                	mv	s2,a0
    80001f90:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80001f92:	0000c517          	auipc	a0,0xc
    80001f96:	b6650513          	addi	a0,a0,-1178 # 8000daf8 <bcache>
    80001f9a:	073030ef          	jal	8000580c <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80001f9e:	00014497          	auipc	s1,0x14
    80001fa2:	e124b483          	ld	s1,-494(s1) # 80015db0 <bcache+0x82b8>
    80001fa6:	00014797          	auipc	a5,0x14
    80001faa:	dba78793          	addi	a5,a5,-582 # 80015d60 <bcache+0x8268>
    80001fae:	02f48b63          	beq	s1,a5,80001fe4 <bread+0x64>
    80001fb2:	873e                	mv	a4,a5
    80001fb4:	a021                	j	80001fbc <bread+0x3c>
    80001fb6:	68a4                	ld	s1,80(s1)
    80001fb8:	02e48663          	beq	s1,a4,80001fe4 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80001fbc:	449c                	lw	a5,8(s1)
    80001fbe:	ff279ce3          	bne	a5,s2,80001fb6 <bread+0x36>
    80001fc2:	44dc                	lw	a5,12(s1)
    80001fc4:	ff3799e3          	bne	a5,s3,80001fb6 <bread+0x36>
      b->refcnt++;
    80001fc8:	40bc                	lw	a5,64(s1)
    80001fca:	2785                	addiw	a5,a5,1
    80001fcc:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80001fce:	0000c517          	auipc	a0,0xc
    80001fd2:	b2a50513          	addi	a0,a0,-1238 # 8000daf8 <bcache>
    80001fd6:	0cb030ef          	jal	800058a0 <release>
      acquiresleep(&b->lock);
    80001fda:	01048513          	addi	a0,s1,16
    80001fde:	1fe010ef          	jal	800031dc <acquiresleep>
      return b;
    80001fe2:	a889                	j	80002034 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80001fe4:	00014497          	auipc	s1,0x14
    80001fe8:	dc44b483          	ld	s1,-572(s1) # 80015da8 <bcache+0x82b0>
    80001fec:	00014797          	auipc	a5,0x14
    80001ff0:	d7478793          	addi	a5,a5,-652 # 80015d60 <bcache+0x8268>
    80001ff4:	00f48863          	beq	s1,a5,80002004 <bread+0x84>
    80001ff8:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80001ffa:	40bc                	lw	a5,64(s1)
    80001ffc:	cb91                	beqz	a5,80002010 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80001ffe:	64a4                	ld	s1,72(s1)
    80002000:	fee49de3          	bne	s1,a4,80001ffa <bread+0x7a>
  panic("bget: no buffers");
    80002004:	00005517          	auipc	a0,0x5
    80002008:	4ac50513          	addi	a0,a0,1196 # 800074b0 <etext+0x4b0>
    8000200c:	4c2030ef          	jal	800054ce <panic>
      b->dev = dev;
    80002010:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002014:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002018:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    8000201c:	4785                	li	a5,1
    8000201e:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002020:	0000c517          	auipc	a0,0xc
    80002024:	ad850513          	addi	a0,a0,-1320 # 8000daf8 <bcache>
    80002028:	079030ef          	jal	800058a0 <release>
      acquiresleep(&b->lock);
    8000202c:	01048513          	addi	a0,s1,16
    80002030:	1ac010ef          	jal	800031dc <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002034:	409c                	lw	a5,0(s1)
    80002036:	cb89                	beqz	a5,80002048 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002038:	8526                	mv	a0,s1
    8000203a:	70a2                	ld	ra,40(sp)
    8000203c:	7402                	ld	s0,32(sp)
    8000203e:	64e2                	ld	s1,24(sp)
    80002040:	6942                	ld	s2,16(sp)
    80002042:	69a2                	ld	s3,8(sp)
    80002044:	6145                	addi	sp,sp,48
    80002046:	8082                	ret
    virtio_disk_rw(b, 0);
    80002048:	4581                	li	a1,0
    8000204a:	8526                	mv	a0,s1
    8000204c:	205020ef          	jal	80004a50 <virtio_disk_rw>
    b->valid = 1;
    80002050:	4785                	li	a5,1
    80002052:	c09c                	sw	a5,0(s1)
  return b;
    80002054:	b7d5                	j	80002038 <bread+0xb8>

0000000080002056 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002056:	1101                	addi	sp,sp,-32
    80002058:	ec06                	sd	ra,24(sp)
    8000205a:	e822                	sd	s0,16(sp)
    8000205c:	e426                	sd	s1,8(sp)
    8000205e:	1000                	addi	s0,sp,32
    80002060:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002062:	0541                	addi	a0,a0,16
    80002064:	1f6010ef          	jal	8000325a <holdingsleep>
    80002068:	c911                	beqz	a0,8000207c <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    8000206a:	4585                	li	a1,1
    8000206c:	8526                	mv	a0,s1
    8000206e:	1e3020ef          	jal	80004a50 <virtio_disk_rw>
}
    80002072:	60e2                	ld	ra,24(sp)
    80002074:	6442                	ld	s0,16(sp)
    80002076:	64a2                	ld	s1,8(sp)
    80002078:	6105                	addi	sp,sp,32
    8000207a:	8082                	ret
    panic("bwrite");
    8000207c:	00005517          	auipc	a0,0x5
    80002080:	44c50513          	addi	a0,a0,1100 # 800074c8 <etext+0x4c8>
    80002084:	44a030ef          	jal	800054ce <panic>

0000000080002088 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002088:	1101                	addi	sp,sp,-32
    8000208a:	ec06                	sd	ra,24(sp)
    8000208c:	e822                	sd	s0,16(sp)
    8000208e:	e426                	sd	s1,8(sp)
    80002090:	e04a                	sd	s2,0(sp)
    80002092:	1000                	addi	s0,sp,32
    80002094:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002096:	01050913          	addi	s2,a0,16
    8000209a:	854a                	mv	a0,s2
    8000209c:	1be010ef          	jal	8000325a <holdingsleep>
    800020a0:	c125                	beqz	a0,80002100 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    800020a2:	854a                	mv	a0,s2
    800020a4:	17e010ef          	jal	80003222 <releasesleep>

  acquire(&bcache.lock);
    800020a8:	0000c517          	auipc	a0,0xc
    800020ac:	a5050513          	addi	a0,a0,-1456 # 8000daf8 <bcache>
    800020b0:	75c030ef          	jal	8000580c <acquire>
  b->refcnt--;
    800020b4:	40bc                	lw	a5,64(s1)
    800020b6:	37fd                	addiw	a5,a5,-1
    800020b8:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800020ba:	e79d                	bnez	a5,800020e8 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800020bc:	68b8                	ld	a4,80(s1)
    800020be:	64bc                	ld	a5,72(s1)
    800020c0:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    800020c2:	68b8                	ld	a4,80(s1)
    800020c4:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800020c6:	00014797          	auipc	a5,0x14
    800020ca:	a3278793          	addi	a5,a5,-1486 # 80015af8 <bcache+0x8000>
    800020ce:	2b87b703          	ld	a4,696(a5)
    800020d2:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800020d4:	00014717          	auipc	a4,0x14
    800020d8:	c8c70713          	addi	a4,a4,-884 # 80015d60 <bcache+0x8268>
    800020dc:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800020de:	2b87b703          	ld	a4,696(a5)
    800020e2:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800020e4:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800020e8:	0000c517          	auipc	a0,0xc
    800020ec:	a1050513          	addi	a0,a0,-1520 # 8000daf8 <bcache>
    800020f0:	7b0030ef          	jal	800058a0 <release>
}
    800020f4:	60e2                	ld	ra,24(sp)
    800020f6:	6442                	ld	s0,16(sp)
    800020f8:	64a2                	ld	s1,8(sp)
    800020fa:	6902                	ld	s2,0(sp)
    800020fc:	6105                	addi	sp,sp,32
    800020fe:	8082                	ret
    panic("brelse");
    80002100:	00005517          	auipc	a0,0x5
    80002104:	3d050513          	addi	a0,a0,976 # 800074d0 <etext+0x4d0>
    80002108:	3c6030ef          	jal	800054ce <panic>

000000008000210c <bpin>:

void
bpin(struct buf *b) {
    8000210c:	1101                	addi	sp,sp,-32
    8000210e:	ec06                	sd	ra,24(sp)
    80002110:	e822                	sd	s0,16(sp)
    80002112:	e426                	sd	s1,8(sp)
    80002114:	1000                	addi	s0,sp,32
    80002116:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002118:	0000c517          	auipc	a0,0xc
    8000211c:	9e050513          	addi	a0,a0,-1568 # 8000daf8 <bcache>
    80002120:	6ec030ef          	jal	8000580c <acquire>
  b->refcnt++;
    80002124:	40bc                	lw	a5,64(s1)
    80002126:	2785                	addiw	a5,a5,1
    80002128:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000212a:	0000c517          	auipc	a0,0xc
    8000212e:	9ce50513          	addi	a0,a0,-1586 # 8000daf8 <bcache>
    80002132:	76e030ef          	jal	800058a0 <release>
}
    80002136:	60e2                	ld	ra,24(sp)
    80002138:	6442                	ld	s0,16(sp)
    8000213a:	64a2                	ld	s1,8(sp)
    8000213c:	6105                	addi	sp,sp,32
    8000213e:	8082                	ret

0000000080002140 <bunpin>:

void
bunpin(struct buf *b) {
    80002140:	1101                	addi	sp,sp,-32
    80002142:	ec06                	sd	ra,24(sp)
    80002144:	e822                	sd	s0,16(sp)
    80002146:	e426                	sd	s1,8(sp)
    80002148:	1000                	addi	s0,sp,32
    8000214a:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000214c:	0000c517          	auipc	a0,0xc
    80002150:	9ac50513          	addi	a0,a0,-1620 # 8000daf8 <bcache>
    80002154:	6b8030ef          	jal	8000580c <acquire>
  b->refcnt--;
    80002158:	40bc                	lw	a5,64(s1)
    8000215a:	37fd                	addiw	a5,a5,-1
    8000215c:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000215e:	0000c517          	auipc	a0,0xc
    80002162:	99a50513          	addi	a0,a0,-1638 # 8000daf8 <bcache>
    80002166:	73a030ef          	jal	800058a0 <release>
}
    8000216a:	60e2                	ld	ra,24(sp)
    8000216c:	6442                	ld	s0,16(sp)
    8000216e:	64a2                	ld	s1,8(sp)
    80002170:	6105                	addi	sp,sp,32
    80002172:	8082                	ret

0000000080002174 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002174:	1101                	addi	sp,sp,-32
    80002176:	ec06                	sd	ra,24(sp)
    80002178:	e822                	sd	s0,16(sp)
    8000217a:	e426                	sd	s1,8(sp)
    8000217c:	e04a                	sd	s2,0(sp)
    8000217e:	1000                	addi	s0,sp,32
    80002180:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002182:	00d5d79b          	srliw	a5,a1,0xd
    80002186:	00014597          	auipc	a1,0x14
    8000218a:	04e5a583          	lw	a1,78(a1) # 800161d4 <sb+0x1c>
    8000218e:	9dbd                	addw	a1,a1,a5
    80002190:	df1ff0ef          	jal	80001f80 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002194:	0074f713          	andi	a4,s1,7
    80002198:	4785                	li	a5,1
    8000219a:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    8000219e:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    800021a0:	90d9                	srli	s1,s1,0x36
    800021a2:	00950733          	add	a4,a0,s1
    800021a6:	05874703          	lbu	a4,88(a4)
    800021aa:	00e7f6b3          	and	a3,a5,a4
    800021ae:	c29d                	beqz	a3,800021d4 <bfree+0x60>
    800021b0:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800021b2:	94aa                	add	s1,s1,a0
    800021b4:	fff7c793          	not	a5,a5
    800021b8:	8f7d                	and	a4,a4,a5
    800021ba:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    800021be:	717000ef          	jal	800030d4 <log_write>
  brelse(bp);
    800021c2:	854a                	mv	a0,s2
    800021c4:	ec5ff0ef          	jal	80002088 <brelse>
}
    800021c8:	60e2                	ld	ra,24(sp)
    800021ca:	6442                	ld	s0,16(sp)
    800021cc:	64a2                	ld	s1,8(sp)
    800021ce:	6902                	ld	s2,0(sp)
    800021d0:	6105                	addi	sp,sp,32
    800021d2:	8082                	ret
    panic("freeing free block");
    800021d4:	00005517          	auipc	a0,0x5
    800021d8:	30450513          	addi	a0,a0,772 # 800074d8 <etext+0x4d8>
    800021dc:	2f2030ef          	jal	800054ce <panic>

00000000800021e0 <balloc>:
{
    800021e0:	715d                	addi	sp,sp,-80
    800021e2:	e486                	sd	ra,72(sp)
    800021e4:	e0a2                	sd	s0,64(sp)
    800021e6:	fc26                	sd	s1,56(sp)
    800021e8:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    800021ea:	00014797          	auipc	a5,0x14
    800021ee:	fd27a783          	lw	a5,-46(a5) # 800161bc <sb+0x4>
    800021f2:	0e078263          	beqz	a5,800022d6 <balloc+0xf6>
    800021f6:	f84a                	sd	s2,48(sp)
    800021f8:	f44e                	sd	s3,40(sp)
    800021fa:	f052                	sd	s4,32(sp)
    800021fc:	ec56                	sd	s5,24(sp)
    800021fe:	e85a                	sd	s6,16(sp)
    80002200:	e45e                	sd	s7,8(sp)
    80002202:	e062                	sd	s8,0(sp)
    80002204:	8baa                	mv	s7,a0
    80002206:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002208:	00014b17          	auipc	s6,0x14
    8000220c:	fb0b0b13          	addi	s6,s6,-80 # 800161b8 <sb>
      m = 1 << (bi % 8);
    80002210:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002212:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002214:	6c09                	lui	s8,0x2
    80002216:	a09d                	j	8000227c <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002218:	97ca                	add	a5,a5,s2
    8000221a:	8e55                	or	a2,a2,a3
    8000221c:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002220:	854a                	mv	a0,s2
    80002222:	6b3000ef          	jal	800030d4 <log_write>
        brelse(bp);
    80002226:	854a                	mv	a0,s2
    80002228:	e61ff0ef          	jal	80002088 <brelse>
  bp = bread(dev, bno);
    8000222c:	85a6                	mv	a1,s1
    8000222e:	855e                	mv	a0,s7
    80002230:	d51ff0ef          	jal	80001f80 <bread>
    80002234:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002236:	40000613          	li	a2,1024
    8000223a:	4581                	li	a1,0
    8000223c:	05850513          	addi	a0,a0,88
    80002240:	efffd0ef          	jal	8000013e <memset>
  log_write(bp);
    80002244:	854a                	mv	a0,s2
    80002246:	68f000ef          	jal	800030d4 <log_write>
  brelse(bp);
    8000224a:	854a                	mv	a0,s2
    8000224c:	e3dff0ef          	jal	80002088 <brelse>
}
    80002250:	7942                	ld	s2,48(sp)
    80002252:	79a2                	ld	s3,40(sp)
    80002254:	7a02                	ld	s4,32(sp)
    80002256:	6ae2                	ld	s5,24(sp)
    80002258:	6b42                	ld	s6,16(sp)
    8000225a:	6ba2                	ld	s7,8(sp)
    8000225c:	6c02                	ld	s8,0(sp)
}
    8000225e:	8526                	mv	a0,s1
    80002260:	60a6                	ld	ra,72(sp)
    80002262:	6406                	ld	s0,64(sp)
    80002264:	74e2                	ld	s1,56(sp)
    80002266:	6161                	addi	sp,sp,80
    80002268:	8082                	ret
    brelse(bp);
    8000226a:	854a                	mv	a0,s2
    8000226c:	e1dff0ef          	jal	80002088 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002270:	015c0abb          	addw	s5,s8,s5
    80002274:	004b2783          	lw	a5,4(s6)
    80002278:	04faf863          	bgeu	s5,a5,800022c8 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    8000227c:	40dad59b          	sraiw	a1,s5,0xd
    80002280:	01cb2783          	lw	a5,28(s6)
    80002284:	9dbd                	addw	a1,a1,a5
    80002286:	855e                	mv	a0,s7
    80002288:	cf9ff0ef          	jal	80001f80 <bread>
    8000228c:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000228e:	004b2503          	lw	a0,4(s6)
    80002292:	84d6                	mv	s1,s5
    80002294:	4701                	li	a4,0
    80002296:	fca4fae3          	bgeu	s1,a0,8000226a <balloc+0x8a>
      m = 1 << (bi % 8);
    8000229a:	00777693          	andi	a3,a4,7
    8000229e:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800022a2:	41f7579b          	sraiw	a5,a4,0x1f
    800022a6:	01d7d79b          	srliw	a5,a5,0x1d
    800022aa:	9fb9                	addw	a5,a5,a4
    800022ac:	4037d79b          	sraiw	a5,a5,0x3
    800022b0:	00f90633          	add	a2,s2,a5
    800022b4:	05864603          	lbu	a2,88(a2)
    800022b8:	00c6f5b3          	and	a1,a3,a2
    800022bc:	ddb1                	beqz	a1,80002218 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800022be:	2705                	addiw	a4,a4,1
    800022c0:	2485                	addiw	s1,s1,1
    800022c2:	fd471ae3          	bne	a4,s4,80002296 <balloc+0xb6>
    800022c6:	b755                	j	8000226a <balloc+0x8a>
    800022c8:	7942                	ld	s2,48(sp)
    800022ca:	79a2                	ld	s3,40(sp)
    800022cc:	7a02                	ld	s4,32(sp)
    800022ce:	6ae2                	ld	s5,24(sp)
    800022d0:	6b42                	ld	s6,16(sp)
    800022d2:	6ba2                	ld	s7,8(sp)
    800022d4:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    800022d6:	00005517          	auipc	a0,0x5
    800022da:	21a50513          	addi	a0,a0,538 # 800074f0 <etext+0x4f0>
    800022de:	6e1020ef          	jal	800051be <printf>
  return 0;
    800022e2:	4481                	li	s1,0
    800022e4:	bfad                	j	8000225e <balloc+0x7e>

00000000800022e6 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800022e6:	7179                	addi	sp,sp,-48
    800022e8:	f406                	sd	ra,40(sp)
    800022ea:	f022                	sd	s0,32(sp)
    800022ec:	ec26                	sd	s1,24(sp)
    800022ee:	e84a                	sd	s2,16(sp)
    800022f0:	e44e                	sd	s3,8(sp)
    800022f2:	1800                	addi	s0,sp,48
    800022f4:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800022f6:	47ad                	li	a5,11
    800022f8:	02b7e363          	bltu	a5,a1,8000231e <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    800022fc:	02059793          	slli	a5,a1,0x20
    80002300:	01e7d593          	srli	a1,a5,0x1e
    80002304:	00b509b3          	add	s3,a0,a1
    80002308:	0509a483          	lw	s1,80(s3)
    8000230c:	e0b5                	bnez	s1,80002370 <bmap+0x8a>
      addr = balloc(ip->dev);
    8000230e:	4108                	lw	a0,0(a0)
    80002310:	ed1ff0ef          	jal	800021e0 <balloc>
    80002314:	84aa                	mv	s1,a0
      if(addr == 0)
    80002316:	cd29                	beqz	a0,80002370 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002318:	04a9a823          	sw	a0,80(s3)
    8000231c:	a891                	j	80002370 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    8000231e:	ff45879b          	addiw	a5,a1,-12
    80002322:	873e                	mv	a4,a5
    80002324:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80002326:	0ff00793          	li	a5,255
    8000232a:	06e7e763          	bltu	a5,a4,80002398 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000232e:	08052483          	lw	s1,128(a0)
    80002332:	e891                	bnez	s1,80002346 <bmap+0x60>
      addr = balloc(ip->dev);
    80002334:	4108                	lw	a0,0(a0)
    80002336:	eabff0ef          	jal	800021e0 <balloc>
    8000233a:	84aa                	mv	s1,a0
      if(addr == 0)
    8000233c:	c915                	beqz	a0,80002370 <bmap+0x8a>
    8000233e:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002340:	08a92023          	sw	a0,128(s2)
    80002344:	a011                	j	80002348 <bmap+0x62>
    80002346:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002348:	85a6                	mv	a1,s1
    8000234a:	00092503          	lw	a0,0(s2)
    8000234e:	c33ff0ef          	jal	80001f80 <bread>
    80002352:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002354:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002358:	02099713          	slli	a4,s3,0x20
    8000235c:	01e75593          	srli	a1,a4,0x1e
    80002360:	97ae                	add	a5,a5,a1
    80002362:	89be                	mv	s3,a5
    80002364:	4384                	lw	s1,0(a5)
    80002366:	cc89                	beqz	s1,80002380 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002368:	8552                	mv	a0,s4
    8000236a:	d1fff0ef          	jal	80002088 <brelse>
    return addr;
    8000236e:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002370:	8526                	mv	a0,s1
    80002372:	70a2                	ld	ra,40(sp)
    80002374:	7402                	ld	s0,32(sp)
    80002376:	64e2                	ld	s1,24(sp)
    80002378:	6942                	ld	s2,16(sp)
    8000237a:	69a2                	ld	s3,8(sp)
    8000237c:	6145                	addi	sp,sp,48
    8000237e:	8082                	ret
      addr = balloc(ip->dev);
    80002380:	00092503          	lw	a0,0(s2)
    80002384:	e5dff0ef          	jal	800021e0 <balloc>
    80002388:	84aa                	mv	s1,a0
      if(addr){
    8000238a:	dd79                	beqz	a0,80002368 <bmap+0x82>
        a[bn] = addr;
    8000238c:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002390:	8552                	mv	a0,s4
    80002392:	543000ef          	jal	800030d4 <log_write>
    80002396:	bfc9                	j	80002368 <bmap+0x82>
    80002398:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    8000239a:	00005517          	auipc	a0,0x5
    8000239e:	16e50513          	addi	a0,a0,366 # 80007508 <etext+0x508>
    800023a2:	12c030ef          	jal	800054ce <panic>

00000000800023a6 <iget>:
{
    800023a6:	7179                	addi	sp,sp,-48
    800023a8:	f406                	sd	ra,40(sp)
    800023aa:	f022                	sd	s0,32(sp)
    800023ac:	ec26                	sd	s1,24(sp)
    800023ae:	e84a                	sd	s2,16(sp)
    800023b0:	e44e                	sd	s3,8(sp)
    800023b2:	e052                	sd	s4,0(sp)
    800023b4:	1800                	addi	s0,sp,48
    800023b6:	892a                	mv	s2,a0
    800023b8:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800023ba:	00014517          	auipc	a0,0x14
    800023be:	e1e50513          	addi	a0,a0,-482 # 800161d8 <itable>
    800023c2:	44a030ef          	jal	8000580c <acquire>
  empty = 0;
    800023c6:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800023c8:	00014497          	auipc	s1,0x14
    800023cc:	e2848493          	addi	s1,s1,-472 # 800161f0 <itable+0x18>
    800023d0:	00016697          	auipc	a3,0x16
    800023d4:	8b068693          	addi	a3,a3,-1872 # 80017c80 <log>
    800023d8:	a809                	j	800023ea <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800023da:	e781                	bnez	a5,800023e2 <iget+0x3c>
    800023dc:	00099363          	bnez	s3,800023e2 <iget+0x3c>
      empty = ip;
    800023e0:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800023e2:	08848493          	addi	s1,s1,136
    800023e6:	02d48563          	beq	s1,a3,80002410 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800023ea:	449c                	lw	a5,8(s1)
    800023ec:	fef057e3          	blez	a5,800023da <iget+0x34>
    800023f0:	4098                	lw	a4,0(s1)
    800023f2:	ff2718e3          	bne	a4,s2,800023e2 <iget+0x3c>
    800023f6:	40d8                	lw	a4,4(s1)
    800023f8:	ff4715e3          	bne	a4,s4,800023e2 <iget+0x3c>
      ip->ref++;
    800023fc:	2785                	addiw	a5,a5,1
    800023fe:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002400:	00014517          	auipc	a0,0x14
    80002404:	dd850513          	addi	a0,a0,-552 # 800161d8 <itable>
    80002408:	498030ef          	jal	800058a0 <release>
      return ip;
    8000240c:	89a6                	mv	s3,s1
    8000240e:	a015                	j	80002432 <iget+0x8c>
  if(empty == 0)
    80002410:	02098a63          	beqz	s3,80002444 <iget+0x9e>
  ip->dev = dev;
    80002414:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    80002418:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    8000241c:	4785                	li	a5,1
    8000241e:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    80002422:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    80002426:	00014517          	auipc	a0,0x14
    8000242a:	db250513          	addi	a0,a0,-590 # 800161d8 <itable>
    8000242e:	472030ef          	jal	800058a0 <release>
}
    80002432:	854e                	mv	a0,s3
    80002434:	70a2                	ld	ra,40(sp)
    80002436:	7402                	ld	s0,32(sp)
    80002438:	64e2                	ld	s1,24(sp)
    8000243a:	6942                	ld	s2,16(sp)
    8000243c:	69a2                	ld	s3,8(sp)
    8000243e:	6a02                	ld	s4,0(sp)
    80002440:	6145                	addi	sp,sp,48
    80002442:	8082                	ret
    panic("iget: no inodes");
    80002444:	00005517          	auipc	a0,0x5
    80002448:	0dc50513          	addi	a0,a0,220 # 80007520 <etext+0x520>
    8000244c:	082030ef          	jal	800054ce <panic>

0000000080002450 <fsinit>:
fsinit(int dev) {
    80002450:	1101                	addi	sp,sp,-32
    80002452:	ec06                	sd	ra,24(sp)
    80002454:	e822                	sd	s0,16(sp)
    80002456:	e426                	sd	s1,8(sp)
    80002458:	e04a                	sd	s2,0(sp)
    8000245a:	1000                	addi	s0,sp,32
    8000245c:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    8000245e:	4585                	li	a1,1
    80002460:	b21ff0ef          	jal	80001f80 <bread>
    80002464:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002466:	02000613          	li	a2,32
    8000246a:	05850593          	addi	a1,a0,88
    8000246e:	00014517          	auipc	a0,0x14
    80002472:	d4a50513          	addi	a0,a0,-694 # 800161b8 <sb>
    80002476:	d29fd0ef          	jal	8000019e <memmove>
  brelse(bp);
    8000247a:	8526                	mv	a0,s1
    8000247c:	c0dff0ef          	jal	80002088 <brelse>
  if(sb.magic != FSMAGIC)
    80002480:	00014717          	auipc	a4,0x14
    80002484:	d3872703          	lw	a4,-712(a4) # 800161b8 <sb>
    80002488:	102037b7          	lui	a5,0x10203
    8000248c:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002490:	00f71f63          	bne	a4,a5,800024ae <fsinit+0x5e>
  initlog(dev, &sb);
    80002494:	00014597          	auipc	a1,0x14
    80002498:	d2458593          	addi	a1,a1,-732 # 800161b8 <sb>
    8000249c:	854a                	mv	a0,s2
    8000249e:	219000ef          	jal	80002eb6 <initlog>
}
    800024a2:	60e2                	ld	ra,24(sp)
    800024a4:	6442                	ld	s0,16(sp)
    800024a6:	64a2                	ld	s1,8(sp)
    800024a8:	6902                	ld	s2,0(sp)
    800024aa:	6105                	addi	sp,sp,32
    800024ac:	8082                	ret
    panic("invalid file system");
    800024ae:	00005517          	auipc	a0,0x5
    800024b2:	08250513          	addi	a0,a0,130 # 80007530 <etext+0x530>
    800024b6:	018030ef          	jal	800054ce <panic>

00000000800024ba <iinit>:
{
    800024ba:	7179                	addi	sp,sp,-48
    800024bc:	f406                	sd	ra,40(sp)
    800024be:	f022                	sd	s0,32(sp)
    800024c0:	ec26                	sd	s1,24(sp)
    800024c2:	e84a                	sd	s2,16(sp)
    800024c4:	e44e                	sd	s3,8(sp)
    800024c6:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800024c8:	00005597          	auipc	a1,0x5
    800024cc:	08058593          	addi	a1,a1,128 # 80007548 <etext+0x548>
    800024d0:	00014517          	auipc	a0,0x14
    800024d4:	d0850513          	addi	a0,a0,-760 # 800161d8 <itable>
    800024d8:	2aa030ef          	jal	80005782 <initlock>
  for(i = 0; i < NINODE; i++) {
    800024dc:	00014497          	auipc	s1,0x14
    800024e0:	d2448493          	addi	s1,s1,-732 # 80016200 <itable+0x28>
    800024e4:	00015997          	auipc	s3,0x15
    800024e8:	7ac98993          	addi	s3,s3,1964 # 80017c90 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800024ec:	00005917          	auipc	s2,0x5
    800024f0:	06490913          	addi	s2,s2,100 # 80007550 <etext+0x550>
    800024f4:	85ca                	mv	a1,s2
    800024f6:	8526                	mv	a0,s1
    800024f8:	4af000ef          	jal	800031a6 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800024fc:	08848493          	addi	s1,s1,136
    80002500:	ff349ae3          	bne	s1,s3,800024f4 <iinit+0x3a>
}
    80002504:	70a2                	ld	ra,40(sp)
    80002506:	7402                	ld	s0,32(sp)
    80002508:	64e2                	ld	s1,24(sp)
    8000250a:	6942                	ld	s2,16(sp)
    8000250c:	69a2                	ld	s3,8(sp)
    8000250e:	6145                	addi	sp,sp,48
    80002510:	8082                	ret

0000000080002512 <ialloc>:
{
    80002512:	7139                	addi	sp,sp,-64
    80002514:	fc06                	sd	ra,56(sp)
    80002516:	f822                	sd	s0,48(sp)
    80002518:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    8000251a:	00014717          	auipc	a4,0x14
    8000251e:	caa72703          	lw	a4,-854(a4) # 800161c4 <sb+0xc>
    80002522:	4785                	li	a5,1
    80002524:	06e7f063          	bgeu	a5,a4,80002584 <ialloc+0x72>
    80002528:	f426                	sd	s1,40(sp)
    8000252a:	f04a                	sd	s2,32(sp)
    8000252c:	ec4e                	sd	s3,24(sp)
    8000252e:	e852                	sd	s4,16(sp)
    80002530:	e456                	sd	s5,8(sp)
    80002532:	e05a                	sd	s6,0(sp)
    80002534:	8aaa                	mv	s5,a0
    80002536:	8b2e                	mv	s6,a1
    80002538:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    8000253a:	00014a17          	auipc	s4,0x14
    8000253e:	c7ea0a13          	addi	s4,s4,-898 # 800161b8 <sb>
    80002542:	00495593          	srli	a1,s2,0x4
    80002546:	018a2783          	lw	a5,24(s4)
    8000254a:	9dbd                	addw	a1,a1,a5
    8000254c:	8556                	mv	a0,s5
    8000254e:	a33ff0ef          	jal	80001f80 <bread>
    80002552:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80002554:	05850993          	addi	s3,a0,88
    80002558:	00f97793          	andi	a5,s2,15
    8000255c:	079a                	slli	a5,a5,0x6
    8000255e:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002560:	00099783          	lh	a5,0(s3)
    80002564:	cb9d                	beqz	a5,8000259a <ialloc+0x88>
    brelse(bp);
    80002566:	b23ff0ef          	jal	80002088 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000256a:	0905                	addi	s2,s2,1
    8000256c:	00ca2703          	lw	a4,12(s4)
    80002570:	0009079b          	sext.w	a5,s2
    80002574:	fce7e7e3          	bltu	a5,a4,80002542 <ialloc+0x30>
    80002578:	74a2                	ld	s1,40(sp)
    8000257a:	7902                	ld	s2,32(sp)
    8000257c:	69e2                	ld	s3,24(sp)
    8000257e:	6a42                	ld	s4,16(sp)
    80002580:	6aa2                	ld	s5,8(sp)
    80002582:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80002584:	00005517          	auipc	a0,0x5
    80002588:	fd450513          	addi	a0,a0,-44 # 80007558 <etext+0x558>
    8000258c:	433020ef          	jal	800051be <printf>
  return 0;
    80002590:	4501                	li	a0,0
}
    80002592:	70e2                	ld	ra,56(sp)
    80002594:	7442                	ld	s0,48(sp)
    80002596:	6121                	addi	sp,sp,64
    80002598:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    8000259a:	04000613          	li	a2,64
    8000259e:	4581                	li	a1,0
    800025a0:	854e                	mv	a0,s3
    800025a2:	b9dfd0ef          	jal	8000013e <memset>
      dip->type = type;
    800025a6:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800025aa:	8526                	mv	a0,s1
    800025ac:	329000ef          	jal	800030d4 <log_write>
      brelse(bp);
    800025b0:	8526                	mv	a0,s1
    800025b2:	ad7ff0ef          	jal	80002088 <brelse>
      return iget(dev, inum);
    800025b6:	0009059b          	sext.w	a1,s2
    800025ba:	8556                	mv	a0,s5
    800025bc:	debff0ef          	jal	800023a6 <iget>
    800025c0:	74a2                	ld	s1,40(sp)
    800025c2:	7902                	ld	s2,32(sp)
    800025c4:	69e2                	ld	s3,24(sp)
    800025c6:	6a42                	ld	s4,16(sp)
    800025c8:	6aa2                	ld	s5,8(sp)
    800025ca:	6b02                	ld	s6,0(sp)
    800025cc:	b7d9                	j	80002592 <ialloc+0x80>

00000000800025ce <iupdate>:
{
    800025ce:	1101                	addi	sp,sp,-32
    800025d0:	ec06                	sd	ra,24(sp)
    800025d2:	e822                	sd	s0,16(sp)
    800025d4:	e426                	sd	s1,8(sp)
    800025d6:	e04a                	sd	s2,0(sp)
    800025d8:	1000                	addi	s0,sp,32
    800025da:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800025dc:	415c                	lw	a5,4(a0)
    800025de:	0047d79b          	srliw	a5,a5,0x4
    800025e2:	00014597          	auipc	a1,0x14
    800025e6:	bee5a583          	lw	a1,-1042(a1) # 800161d0 <sb+0x18>
    800025ea:	9dbd                	addw	a1,a1,a5
    800025ec:	4108                	lw	a0,0(a0)
    800025ee:	993ff0ef          	jal	80001f80 <bread>
    800025f2:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800025f4:	05850793          	addi	a5,a0,88
    800025f8:	40d8                	lw	a4,4(s1)
    800025fa:	8b3d                	andi	a4,a4,15
    800025fc:	071a                	slli	a4,a4,0x6
    800025fe:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80002600:	04449703          	lh	a4,68(s1)
    80002604:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80002608:	04649703          	lh	a4,70(s1)
    8000260c:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80002610:	04849703          	lh	a4,72(s1)
    80002614:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80002618:	04a49703          	lh	a4,74(s1)
    8000261c:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80002620:	44f8                	lw	a4,76(s1)
    80002622:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80002624:	03400613          	li	a2,52
    80002628:	05048593          	addi	a1,s1,80
    8000262c:	00c78513          	addi	a0,a5,12
    80002630:	b6ffd0ef          	jal	8000019e <memmove>
  log_write(bp);
    80002634:	854a                	mv	a0,s2
    80002636:	29f000ef          	jal	800030d4 <log_write>
  brelse(bp);
    8000263a:	854a                	mv	a0,s2
    8000263c:	a4dff0ef          	jal	80002088 <brelse>
}
    80002640:	60e2                	ld	ra,24(sp)
    80002642:	6442                	ld	s0,16(sp)
    80002644:	64a2                	ld	s1,8(sp)
    80002646:	6902                	ld	s2,0(sp)
    80002648:	6105                	addi	sp,sp,32
    8000264a:	8082                	ret

000000008000264c <idup>:
{
    8000264c:	1101                	addi	sp,sp,-32
    8000264e:	ec06                	sd	ra,24(sp)
    80002650:	e822                	sd	s0,16(sp)
    80002652:	e426                	sd	s1,8(sp)
    80002654:	1000                	addi	s0,sp,32
    80002656:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002658:	00014517          	auipc	a0,0x14
    8000265c:	b8050513          	addi	a0,a0,-1152 # 800161d8 <itable>
    80002660:	1ac030ef          	jal	8000580c <acquire>
  ip->ref++;
    80002664:	449c                	lw	a5,8(s1)
    80002666:	2785                	addiw	a5,a5,1
    80002668:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000266a:	00014517          	auipc	a0,0x14
    8000266e:	b6e50513          	addi	a0,a0,-1170 # 800161d8 <itable>
    80002672:	22e030ef          	jal	800058a0 <release>
}
    80002676:	8526                	mv	a0,s1
    80002678:	60e2                	ld	ra,24(sp)
    8000267a:	6442                	ld	s0,16(sp)
    8000267c:	64a2                	ld	s1,8(sp)
    8000267e:	6105                	addi	sp,sp,32
    80002680:	8082                	ret

0000000080002682 <ilock>:
{
    80002682:	1101                	addi	sp,sp,-32
    80002684:	ec06                	sd	ra,24(sp)
    80002686:	e822                	sd	s0,16(sp)
    80002688:	e426                	sd	s1,8(sp)
    8000268a:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000268c:	cd19                	beqz	a0,800026aa <ilock+0x28>
    8000268e:	84aa                	mv	s1,a0
    80002690:	451c                	lw	a5,8(a0)
    80002692:	00f05c63          	blez	a5,800026aa <ilock+0x28>
  acquiresleep(&ip->lock);
    80002696:	0541                	addi	a0,a0,16
    80002698:	345000ef          	jal	800031dc <acquiresleep>
  if(ip->valid == 0){
    8000269c:	40bc                	lw	a5,64(s1)
    8000269e:	cf89                	beqz	a5,800026b8 <ilock+0x36>
}
    800026a0:	60e2                	ld	ra,24(sp)
    800026a2:	6442                	ld	s0,16(sp)
    800026a4:	64a2                	ld	s1,8(sp)
    800026a6:	6105                	addi	sp,sp,32
    800026a8:	8082                	ret
    800026aa:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800026ac:	00005517          	auipc	a0,0x5
    800026b0:	ec450513          	addi	a0,a0,-316 # 80007570 <etext+0x570>
    800026b4:	61b020ef          	jal	800054ce <panic>
    800026b8:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800026ba:	40dc                	lw	a5,4(s1)
    800026bc:	0047d79b          	srliw	a5,a5,0x4
    800026c0:	00014597          	auipc	a1,0x14
    800026c4:	b105a583          	lw	a1,-1264(a1) # 800161d0 <sb+0x18>
    800026c8:	9dbd                	addw	a1,a1,a5
    800026ca:	4088                	lw	a0,0(s1)
    800026cc:	8b5ff0ef          	jal	80001f80 <bread>
    800026d0:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800026d2:	05850593          	addi	a1,a0,88
    800026d6:	40dc                	lw	a5,4(s1)
    800026d8:	8bbd                	andi	a5,a5,15
    800026da:	079a                	slli	a5,a5,0x6
    800026dc:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800026de:	00059783          	lh	a5,0(a1)
    800026e2:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800026e6:	00259783          	lh	a5,2(a1)
    800026ea:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800026ee:	00459783          	lh	a5,4(a1)
    800026f2:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800026f6:	00659783          	lh	a5,6(a1)
    800026fa:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800026fe:	459c                	lw	a5,8(a1)
    80002700:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80002702:	03400613          	li	a2,52
    80002706:	05b1                	addi	a1,a1,12
    80002708:	05048513          	addi	a0,s1,80
    8000270c:	a93fd0ef          	jal	8000019e <memmove>
    brelse(bp);
    80002710:	854a                	mv	a0,s2
    80002712:	977ff0ef          	jal	80002088 <brelse>
    ip->valid = 1;
    80002716:	4785                	li	a5,1
    80002718:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    8000271a:	04449783          	lh	a5,68(s1)
    8000271e:	c399                	beqz	a5,80002724 <ilock+0xa2>
    80002720:	6902                	ld	s2,0(sp)
    80002722:	bfbd                	j	800026a0 <ilock+0x1e>
      panic("ilock: no type");
    80002724:	00005517          	auipc	a0,0x5
    80002728:	e5450513          	addi	a0,a0,-428 # 80007578 <etext+0x578>
    8000272c:	5a3020ef          	jal	800054ce <panic>

0000000080002730 <iunlock>:
{
    80002730:	1101                	addi	sp,sp,-32
    80002732:	ec06                	sd	ra,24(sp)
    80002734:	e822                	sd	s0,16(sp)
    80002736:	e426                	sd	s1,8(sp)
    80002738:	e04a                	sd	s2,0(sp)
    8000273a:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000273c:	c505                	beqz	a0,80002764 <iunlock+0x34>
    8000273e:	84aa                	mv	s1,a0
    80002740:	01050913          	addi	s2,a0,16
    80002744:	854a                	mv	a0,s2
    80002746:	315000ef          	jal	8000325a <holdingsleep>
    8000274a:	cd09                	beqz	a0,80002764 <iunlock+0x34>
    8000274c:	449c                	lw	a5,8(s1)
    8000274e:	00f05b63          	blez	a5,80002764 <iunlock+0x34>
  releasesleep(&ip->lock);
    80002752:	854a                	mv	a0,s2
    80002754:	2cf000ef          	jal	80003222 <releasesleep>
}
    80002758:	60e2                	ld	ra,24(sp)
    8000275a:	6442                	ld	s0,16(sp)
    8000275c:	64a2                	ld	s1,8(sp)
    8000275e:	6902                	ld	s2,0(sp)
    80002760:	6105                	addi	sp,sp,32
    80002762:	8082                	ret
    panic("iunlock");
    80002764:	00005517          	auipc	a0,0x5
    80002768:	e2450513          	addi	a0,a0,-476 # 80007588 <etext+0x588>
    8000276c:	563020ef          	jal	800054ce <panic>

0000000080002770 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80002770:	7179                	addi	sp,sp,-48
    80002772:	f406                	sd	ra,40(sp)
    80002774:	f022                	sd	s0,32(sp)
    80002776:	ec26                	sd	s1,24(sp)
    80002778:	e84a                	sd	s2,16(sp)
    8000277a:	e44e                	sd	s3,8(sp)
    8000277c:	1800                	addi	s0,sp,48
    8000277e:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80002780:	05050493          	addi	s1,a0,80
    80002784:	08050913          	addi	s2,a0,128
    80002788:	a021                	j	80002790 <itrunc+0x20>
    8000278a:	0491                	addi	s1,s1,4
    8000278c:	01248b63          	beq	s1,s2,800027a2 <itrunc+0x32>
    if(ip->addrs[i]){
    80002790:	408c                	lw	a1,0(s1)
    80002792:	dde5                	beqz	a1,8000278a <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80002794:	0009a503          	lw	a0,0(s3)
    80002798:	9ddff0ef          	jal	80002174 <bfree>
      ip->addrs[i] = 0;
    8000279c:	0004a023          	sw	zero,0(s1)
    800027a0:	b7ed                	j	8000278a <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800027a2:	0809a583          	lw	a1,128(s3)
    800027a6:	ed89                	bnez	a1,800027c0 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800027a8:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800027ac:	854e                	mv	a0,s3
    800027ae:	e21ff0ef          	jal	800025ce <iupdate>
}
    800027b2:	70a2                	ld	ra,40(sp)
    800027b4:	7402                	ld	s0,32(sp)
    800027b6:	64e2                	ld	s1,24(sp)
    800027b8:	6942                	ld	s2,16(sp)
    800027ba:	69a2                	ld	s3,8(sp)
    800027bc:	6145                	addi	sp,sp,48
    800027be:	8082                	ret
    800027c0:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800027c2:	0009a503          	lw	a0,0(s3)
    800027c6:	fbaff0ef          	jal	80001f80 <bread>
    800027ca:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800027cc:	05850493          	addi	s1,a0,88
    800027d0:	45850913          	addi	s2,a0,1112
    800027d4:	a021                	j	800027dc <itrunc+0x6c>
    800027d6:	0491                	addi	s1,s1,4
    800027d8:	01248963          	beq	s1,s2,800027ea <itrunc+0x7a>
      if(a[j])
    800027dc:	408c                	lw	a1,0(s1)
    800027de:	dde5                	beqz	a1,800027d6 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800027e0:	0009a503          	lw	a0,0(s3)
    800027e4:	991ff0ef          	jal	80002174 <bfree>
    800027e8:	b7fd                	j	800027d6 <itrunc+0x66>
    brelse(bp);
    800027ea:	8552                	mv	a0,s4
    800027ec:	89dff0ef          	jal	80002088 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800027f0:	0809a583          	lw	a1,128(s3)
    800027f4:	0009a503          	lw	a0,0(s3)
    800027f8:	97dff0ef          	jal	80002174 <bfree>
    ip->addrs[NDIRECT] = 0;
    800027fc:	0809a023          	sw	zero,128(s3)
    80002800:	6a02                	ld	s4,0(sp)
    80002802:	b75d                	j	800027a8 <itrunc+0x38>

0000000080002804 <iput>:
{
    80002804:	1101                	addi	sp,sp,-32
    80002806:	ec06                	sd	ra,24(sp)
    80002808:	e822                	sd	s0,16(sp)
    8000280a:	e426                	sd	s1,8(sp)
    8000280c:	1000                	addi	s0,sp,32
    8000280e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002810:	00014517          	auipc	a0,0x14
    80002814:	9c850513          	addi	a0,a0,-1592 # 800161d8 <itable>
    80002818:	7f5020ef          	jal	8000580c <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000281c:	4498                	lw	a4,8(s1)
    8000281e:	4785                	li	a5,1
    80002820:	02f70063          	beq	a4,a5,80002840 <iput+0x3c>
  ip->ref--;
    80002824:	449c                	lw	a5,8(s1)
    80002826:	37fd                	addiw	a5,a5,-1
    80002828:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000282a:	00014517          	auipc	a0,0x14
    8000282e:	9ae50513          	addi	a0,a0,-1618 # 800161d8 <itable>
    80002832:	06e030ef          	jal	800058a0 <release>
}
    80002836:	60e2                	ld	ra,24(sp)
    80002838:	6442                	ld	s0,16(sp)
    8000283a:	64a2                	ld	s1,8(sp)
    8000283c:	6105                	addi	sp,sp,32
    8000283e:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002840:	40bc                	lw	a5,64(s1)
    80002842:	d3ed                	beqz	a5,80002824 <iput+0x20>
    80002844:	04a49783          	lh	a5,74(s1)
    80002848:	fff1                	bnez	a5,80002824 <iput+0x20>
    8000284a:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    8000284c:	01048793          	addi	a5,s1,16
    80002850:	893e                	mv	s2,a5
    80002852:	853e                	mv	a0,a5
    80002854:	189000ef          	jal	800031dc <acquiresleep>
    release(&itable.lock);
    80002858:	00014517          	auipc	a0,0x14
    8000285c:	98050513          	addi	a0,a0,-1664 # 800161d8 <itable>
    80002860:	040030ef          	jal	800058a0 <release>
    itrunc(ip);
    80002864:	8526                	mv	a0,s1
    80002866:	f0bff0ef          	jal	80002770 <itrunc>
    ip->type = 0;
    8000286a:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    8000286e:	8526                	mv	a0,s1
    80002870:	d5fff0ef          	jal	800025ce <iupdate>
    ip->valid = 0;
    80002874:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002878:	854a                	mv	a0,s2
    8000287a:	1a9000ef          	jal	80003222 <releasesleep>
    acquire(&itable.lock);
    8000287e:	00014517          	auipc	a0,0x14
    80002882:	95a50513          	addi	a0,a0,-1702 # 800161d8 <itable>
    80002886:	787020ef          	jal	8000580c <acquire>
    8000288a:	6902                	ld	s2,0(sp)
    8000288c:	bf61                	j	80002824 <iput+0x20>

000000008000288e <iunlockput>:
{
    8000288e:	1101                	addi	sp,sp,-32
    80002890:	ec06                	sd	ra,24(sp)
    80002892:	e822                	sd	s0,16(sp)
    80002894:	e426                	sd	s1,8(sp)
    80002896:	1000                	addi	s0,sp,32
    80002898:	84aa                	mv	s1,a0
  iunlock(ip);
    8000289a:	e97ff0ef          	jal	80002730 <iunlock>
  iput(ip);
    8000289e:	8526                	mv	a0,s1
    800028a0:	f65ff0ef          	jal	80002804 <iput>
}
    800028a4:	60e2                	ld	ra,24(sp)
    800028a6:	6442                	ld	s0,16(sp)
    800028a8:	64a2                	ld	s1,8(sp)
    800028aa:	6105                	addi	sp,sp,32
    800028ac:	8082                	ret

00000000800028ae <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800028ae:	1141                	addi	sp,sp,-16
    800028b0:	e406                	sd	ra,8(sp)
    800028b2:	e022                	sd	s0,0(sp)
    800028b4:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800028b6:	411c                	lw	a5,0(a0)
    800028b8:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800028ba:	415c                	lw	a5,4(a0)
    800028bc:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800028be:	04451783          	lh	a5,68(a0)
    800028c2:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800028c6:	04a51783          	lh	a5,74(a0)
    800028ca:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800028ce:	04c56783          	lwu	a5,76(a0)
    800028d2:	e99c                	sd	a5,16(a1)
}
    800028d4:	60a2                	ld	ra,8(sp)
    800028d6:	6402                	ld	s0,0(sp)
    800028d8:	0141                	addi	sp,sp,16
    800028da:	8082                	ret

00000000800028dc <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800028dc:	457c                	lw	a5,76(a0)
    800028de:	0ed7e663          	bltu	a5,a3,800029ca <readi+0xee>
{
    800028e2:	7159                	addi	sp,sp,-112
    800028e4:	f486                	sd	ra,104(sp)
    800028e6:	f0a2                	sd	s0,96(sp)
    800028e8:	eca6                	sd	s1,88(sp)
    800028ea:	e0d2                	sd	s4,64(sp)
    800028ec:	fc56                	sd	s5,56(sp)
    800028ee:	f85a                	sd	s6,48(sp)
    800028f0:	f45e                	sd	s7,40(sp)
    800028f2:	1880                	addi	s0,sp,112
    800028f4:	8b2a                	mv	s6,a0
    800028f6:	8bae                	mv	s7,a1
    800028f8:	8a32                	mv	s4,a2
    800028fa:	84b6                	mv	s1,a3
    800028fc:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800028fe:	9f35                	addw	a4,a4,a3
    return 0;
    80002900:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002902:	0ad76b63          	bltu	a4,a3,800029b8 <readi+0xdc>
    80002906:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80002908:	00e7f463          	bgeu	a5,a4,80002910 <readi+0x34>
    n = ip->size - off;
    8000290c:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002910:	080a8b63          	beqz	s5,800029a6 <readi+0xca>
    80002914:	e8ca                	sd	s2,80(sp)
    80002916:	f062                	sd	s8,32(sp)
    80002918:	ec66                	sd	s9,24(sp)
    8000291a:	e86a                	sd	s10,16(sp)
    8000291c:	e46e                	sd	s11,8(sp)
    8000291e:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002920:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002924:	5c7d                	li	s8,-1
    80002926:	a80d                	j	80002958 <readi+0x7c>
    80002928:	020d1d93          	slli	s11,s10,0x20
    8000292c:	020ddd93          	srli	s11,s11,0x20
    80002930:	05890613          	addi	a2,s2,88
    80002934:	86ee                	mv	a3,s11
    80002936:	963e                	add	a2,a2,a5
    80002938:	85d2                	mv	a1,s4
    8000293a:	855e                	mv	a0,s7
    8000293c:	d63fe0ef          	jal	8000169e <either_copyout>
    80002940:	05850363          	beq	a0,s8,80002986 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002944:	854a                	mv	a0,s2
    80002946:	f42ff0ef          	jal	80002088 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000294a:	013d09bb          	addw	s3,s10,s3
    8000294e:	009d04bb          	addw	s1,s10,s1
    80002952:	9a6e                	add	s4,s4,s11
    80002954:	0559f363          	bgeu	s3,s5,8000299a <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002958:	00a4d59b          	srliw	a1,s1,0xa
    8000295c:	855a                	mv	a0,s6
    8000295e:	989ff0ef          	jal	800022e6 <bmap>
    80002962:	85aa                	mv	a1,a0
    if(addr == 0)
    80002964:	c139                	beqz	a0,800029aa <readi+0xce>
    bp = bread(ip->dev, addr);
    80002966:	000b2503          	lw	a0,0(s6)
    8000296a:	e16ff0ef          	jal	80001f80 <bread>
    8000296e:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002970:	3ff4f793          	andi	a5,s1,1023
    80002974:	40fc873b          	subw	a4,s9,a5
    80002978:	413a86bb          	subw	a3,s5,s3
    8000297c:	8d3a                	mv	s10,a4
    8000297e:	fae6f5e3          	bgeu	a3,a4,80002928 <readi+0x4c>
    80002982:	8d36                	mv	s10,a3
    80002984:	b755                	j	80002928 <readi+0x4c>
      brelse(bp);
    80002986:	854a                	mv	a0,s2
    80002988:	f00ff0ef          	jal	80002088 <brelse>
      tot = -1;
    8000298c:	59fd                	li	s3,-1
      break;
    8000298e:	6946                	ld	s2,80(sp)
    80002990:	7c02                	ld	s8,32(sp)
    80002992:	6ce2                	ld	s9,24(sp)
    80002994:	6d42                	ld	s10,16(sp)
    80002996:	6da2                	ld	s11,8(sp)
    80002998:	a831                	j	800029b4 <readi+0xd8>
    8000299a:	6946                	ld	s2,80(sp)
    8000299c:	7c02                	ld	s8,32(sp)
    8000299e:	6ce2                	ld	s9,24(sp)
    800029a0:	6d42                	ld	s10,16(sp)
    800029a2:	6da2                	ld	s11,8(sp)
    800029a4:	a801                	j	800029b4 <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800029a6:	89d6                	mv	s3,s5
    800029a8:	a031                	j	800029b4 <readi+0xd8>
    800029aa:	6946                	ld	s2,80(sp)
    800029ac:	7c02                	ld	s8,32(sp)
    800029ae:	6ce2                	ld	s9,24(sp)
    800029b0:	6d42                	ld	s10,16(sp)
    800029b2:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800029b4:	854e                	mv	a0,s3
    800029b6:	69a6                	ld	s3,72(sp)
}
    800029b8:	70a6                	ld	ra,104(sp)
    800029ba:	7406                	ld	s0,96(sp)
    800029bc:	64e6                	ld	s1,88(sp)
    800029be:	6a06                	ld	s4,64(sp)
    800029c0:	7ae2                	ld	s5,56(sp)
    800029c2:	7b42                	ld	s6,48(sp)
    800029c4:	7ba2                	ld	s7,40(sp)
    800029c6:	6165                	addi	sp,sp,112
    800029c8:	8082                	ret
    return 0;
    800029ca:	4501                	li	a0,0
}
    800029cc:	8082                	ret

00000000800029ce <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800029ce:	457c                	lw	a5,76(a0)
    800029d0:	0ed7eb63          	bltu	a5,a3,80002ac6 <writei+0xf8>
{
    800029d4:	7159                	addi	sp,sp,-112
    800029d6:	f486                	sd	ra,104(sp)
    800029d8:	f0a2                	sd	s0,96(sp)
    800029da:	e8ca                	sd	s2,80(sp)
    800029dc:	e0d2                	sd	s4,64(sp)
    800029de:	fc56                	sd	s5,56(sp)
    800029e0:	f85a                	sd	s6,48(sp)
    800029e2:	f45e                	sd	s7,40(sp)
    800029e4:	1880                	addi	s0,sp,112
    800029e6:	8aaa                	mv	s5,a0
    800029e8:	8bae                	mv	s7,a1
    800029ea:	8a32                	mv	s4,a2
    800029ec:	8936                	mv	s2,a3
    800029ee:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800029f0:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800029f4:	00043737          	lui	a4,0x43
    800029f8:	0cf76963          	bltu	a4,a5,80002aca <writei+0xfc>
    800029fc:	0cd7e763          	bltu	a5,a3,80002aca <writei+0xfc>
    80002a00:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002a02:	0a0b0a63          	beqz	s6,80002ab6 <writei+0xe8>
    80002a06:	eca6                	sd	s1,88(sp)
    80002a08:	f062                	sd	s8,32(sp)
    80002a0a:	ec66                	sd	s9,24(sp)
    80002a0c:	e86a                	sd	s10,16(sp)
    80002a0e:	e46e                	sd	s11,8(sp)
    80002a10:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002a12:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002a16:	5c7d                	li	s8,-1
    80002a18:	a825                	j	80002a50 <writei+0x82>
    80002a1a:	020d1d93          	slli	s11,s10,0x20
    80002a1e:	020ddd93          	srli	s11,s11,0x20
    80002a22:	05848513          	addi	a0,s1,88
    80002a26:	86ee                	mv	a3,s11
    80002a28:	8652                	mv	a2,s4
    80002a2a:	85de                	mv	a1,s7
    80002a2c:	953e                	add	a0,a0,a5
    80002a2e:	cbbfe0ef          	jal	800016e8 <either_copyin>
    80002a32:	05850663          	beq	a0,s8,80002a7e <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002a36:	8526                	mv	a0,s1
    80002a38:	69c000ef          	jal	800030d4 <log_write>
    brelse(bp);
    80002a3c:	8526                	mv	a0,s1
    80002a3e:	e4aff0ef          	jal	80002088 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002a42:	013d09bb          	addw	s3,s10,s3
    80002a46:	012d093b          	addw	s2,s10,s2
    80002a4a:	9a6e                	add	s4,s4,s11
    80002a4c:	0369fc63          	bgeu	s3,s6,80002a84 <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80002a50:	00a9559b          	srliw	a1,s2,0xa
    80002a54:	8556                	mv	a0,s5
    80002a56:	891ff0ef          	jal	800022e6 <bmap>
    80002a5a:	85aa                	mv	a1,a0
    if(addr == 0)
    80002a5c:	c505                	beqz	a0,80002a84 <writei+0xb6>
    bp = bread(ip->dev, addr);
    80002a5e:	000aa503          	lw	a0,0(s5)
    80002a62:	d1eff0ef          	jal	80001f80 <bread>
    80002a66:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002a68:	3ff97793          	andi	a5,s2,1023
    80002a6c:	40fc873b          	subw	a4,s9,a5
    80002a70:	413b06bb          	subw	a3,s6,s3
    80002a74:	8d3a                	mv	s10,a4
    80002a76:	fae6f2e3          	bgeu	a3,a4,80002a1a <writei+0x4c>
    80002a7a:	8d36                	mv	s10,a3
    80002a7c:	bf79                	j	80002a1a <writei+0x4c>
      brelse(bp);
    80002a7e:	8526                	mv	a0,s1
    80002a80:	e08ff0ef          	jal	80002088 <brelse>
  }

  if(off > ip->size)
    80002a84:	04caa783          	lw	a5,76(s5)
    80002a88:	0327f963          	bgeu	a5,s2,80002aba <writei+0xec>
    ip->size = off;
    80002a8c:	052aa623          	sw	s2,76(s5)
    80002a90:	64e6                	ld	s1,88(sp)
    80002a92:	7c02                	ld	s8,32(sp)
    80002a94:	6ce2                	ld	s9,24(sp)
    80002a96:	6d42                	ld	s10,16(sp)
    80002a98:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002a9a:	8556                	mv	a0,s5
    80002a9c:	b33ff0ef          	jal	800025ce <iupdate>

  return tot;
    80002aa0:	854e                	mv	a0,s3
    80002aa2:	69a6                	ld	s3,72(sp)
}
    80002aa4:	70a6                	ld	ra,104(sp)
    80002aa6:	7406                	ld	s0,96(sp)
    80002aa8:	6946                	ld	s2,80(sp)
    80002aaa:	6a06                	ld	s4,64(sp)
    80002aac:	7ae2                	ld	s5,56(sp)
    80002aae:	7b42                	ld	s6,48(sp)
    80002ab0:	7ba2                	ld	s7,40(sp)
    80002ab2:	6165                	addi	sp,sp,112
    80002ab4:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002ab6:	89da                	mv	s3,s6
    80002ab8:	b7cd                	j	80002a9a <writei+0xcc>
    80002aba:	64e6                	ld	s1,88(sp)
    80002abc:	7c02                	ld	s8,32(sp)
    80002abe:	6ce2                	ld	s9,24(sp)
    80002ac0:	6d42                	ld	s10,16(sp)
    80002ac2:	6da2                	ld	s11,8(sp)
    80002ac4:	bfd9                	j	80002a9a <writei+0xcc>
    return -1;
    80002ac6:	557d                	li	a0,-1
}
    80002ac8:	8082                	ret
    return -1;
    80002aca:	557d                	li	a0,-1
    80002acc:	bfe1                	j	80002aa4 <writei+0xd6>

0000000080002ace <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002ace:	1141                	addi	sp,sp,-16
    80002ad0:	e406                	sd	ra,8(sp)
    80002ad2:	e022                	sd	s0,0(sp)
    80002ad4:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002ad6:	4639                	li	a2,14
    80002ad8:	f3afd0ef          	jal	80000212 <strncmp>
}
    80002adc:	60a2                	ld	ra,8(sp)
    80002ade:	6402                	ld	s0,0(sp)
    80002ae0:	0141                	addi	sp,sp,16
    80002ae2:	8082                	ret

0000000080002ae4 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002ae4:	711d                	addi	sp,sp,-96
    80002ae6:	ec86                	sd	ra,88(sp)
    80002ae8:	e8a2                	sd	s0,80(sp)
    80002aea:	e4a6                	sd	s1,72(sp)
    80002aec:	e0ca                	sd	s2,64(sp)
    80002aee:	fc4e                	sd	s3,56(sp)
    80002af0:	f852                	sd	s4,48(sp)
    80002af2:	f456                	sd	s5,40(sp)
    80002af4:	f05a                	sd	s6,32(sp)
    80002af6:	ec5e                	sd	s7,24(sp)
    80002af8:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002afa:	04451703          	lh	a4,68(a0)
    80002afe:	4785                	li	a5,1
    80002b00:	00f71f63          	bne	a4,a5,80002b1e <dirlookup+0x3a>
    80002b04:	892a                	mv	s2,a0
    80002b06:	8aae                	mv	s5,a1
    80002b08:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002b0a:	457c                	lw	a5,76(a0)
    80002b0c:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002b0e:	fa040a13          	addi	s4,s0,-96
    80002b12:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80002b14:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002b18:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002b1a:	e39d                	bnez	a5,80002b40 <dirlookup+0x5c>
    80002b1c:	a8b9                	j	80002b7a <dirlookup+0x96>
    panic("dirlookup not DIR");
    80002b1e:	00005517          	auipc	a0,0x5
    80002b22:	a7250513          	addi	a0,a0,-1422 # 80007590 <etext+0x590>
    80002b26:	1a9020ef          	jal	800054ce <panic>
      panic("dirlookup read");
    80002b2a:	00005517          	auipc	a0,0x5
    80002b2e:	a7e50513          	addi	a0,a0,-1410 # 800075a8 <etext+0x5a8>
    80002b32:	19d020ef          	jal	800054ce <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002b36:	24c1                	addiw	s1,s1,16
    80002b38:	04c92783          	lw	a5,76(s2)
    80002b3c:	02f4fe63          	bgeu	s1,a5,80002b78 <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002b40:	874e                	mv	a4,s3
    80002b42:	86a6                	mv	a3,s1
    80002b44:	8652                	mv	a2,s4
    80002b46:	4581                	li	a1,0
    80002b48:	854a                	mv	a0,s2
    80002b4a:	d93ff0ef          	jal	800028dc <readi>
    80002b4e:	fd351ee3          	bne	a0,s3,80002b2a <dirlookup+0x46>
    if(de.inum == 0)
    80002b52:	fa045783          	lhu	a5,-96(s0)
    80002b56:	d3e5                	beqz	a5,80002b36 <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80002b58:	85da                	mv	a1,s6
    80002b5a:	8556                	mv	a0,s5
    80002b5c:	f73ff0ef          	jal	80002ace <namecmp>
    80002b60:	f979                	bnez	a0,80002b36 <dirlookup+0x52>
      if(poff)
    80002b62:	000b8463          	beqz	s7,80002b6a <dirlookup+0x86>
        *poff = off;
    80002b66:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80002b6a:	fa045583          	lhu	a1,-96(s0)
    80002b6e:	00092503          	lw	a0,0(s2)
    80002b72:	835ff0ef          	jal	800023a6 <iget>
    80002b76:	a011                	j	80002b7a <dirlookup+0x96>
  return 0;
    80002b78:	4501                	li	a0,0
}
    80002b7a:	60e6                	ld	ra,88(sp)
    80002b7c:	6446                	ld	s0,80(sp)
    80002b7e:	64a6                	ld	s1,72(sp)
    80002b80:	6906                	ld	s2,64(sp)
    80002b82:	79e2                	ld	s3,56(sp)
    80002b84:	7a42                	ld	s4,48(sp)
    80002b86:	7aa2                	ld	s5,40(sp)
    80002b88:	7b02                	ld	s6,32(sp)
    80002b8a:	6be2                	ld	s7,24(sp)
    80002b8c:	6125                	addi	sp,sp,96
    80002b8e:	8082                	ret

0000000080002b90 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002b90:	711d                	addi	sp,sp,-96
    80002b92:	ec86                	sd	ra,88(sp)
    80002b94:	e8a2                	sd	s0,80(sp)
    80002b96:	e4a6                	sd	s1,72(sp)
    80002b98:	e0ca                	sd	s2,64(sp)
    80002b9a:	fc4e                	sd	s3,56(sp)
    80002b9c:	f852                	sd	s4,48(sp)
    80002b9e:	f456                	sd	s5,40(sp)
    80002ba0:	f05a                	sd	s6,32(sp)
    80002ba2:	ec5e                	sd	s7,24(sp)
    80002ba4:	e862                	sd	s8,16(sp)
    80002ba6:	e466                	sd	s9,8(sp)
    80002ba8:	e06a                	sd	s10,0(sp)
    80002baa:	1080                	addi	s0,sp,96
    80002bac:	84aa                	mv	s1,a0
    80002bae:	8b2e                	mv	s6,a1
    80002bb0:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002bb2:	00054703          	lbu	a4,0(a0)
    80002bb6:	02f00793          	li	a5,47
    80002bba:	00f70f63          	beq	a4,a5,80002bd8 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002bbe:	9acfe0ef          	jal	80000d6a <myproc>
    80002bc2:	15053503          	ld	a0,336(a0)
    80002bc6:	a87ff0ef          	jal	8000264c <idup>
    80002bca:	8a2a                	mv	s4,a0
  while(*path == '/')
    80002bcc:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80002bd0:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80002bd2:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002bd4:	4b85                	li	s7,1
    80002bd6:	a879                	j	80002c74 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80002bd8:	4585                	li	a1,1
    80002bda:	852e                	mv	a0,a1
    80002bdc:	fcaff0ef          	jal	800023a6 <iget>
    80002be0:	8a2a                	mv	s4,a0
    80002be2:	b7ed                	j	80002bcc <namex+0x3c>
      iunlockput(ip);
    80002be4:	8552                	mv	a0,s4
    80002be6:	ca9ff0ef          	jal	8000288e <iunlockput>
      return 0;
    80002bea:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002bec:	8552                	mv	a0,s4
    80002bee:	60e6                	ld	ra,88(sp)
    80002bf0:	6446                	ld	s0,80(sp)
    80002bf2:	64a6                	ld	s1,72(sp)
    80002bf4:	6906                	ld	s2,64(sp)
    80002bf6:	79e2                	ld	s3,56(sp)
    80002bf8:	7a42                	ld	s4,48(sp)
    80002bfa:	7aa2                	ld	s5,40(sp)
    80002bfc:	7b02                	ld	s6,32(sp)
    80002bfe:	6be2                	ld	s7,24(sp)
    80002c00:	6c42                	ld	s8,16(sp)
    80002c02:	6ca2                	ld	s9,8(sp)
    80002c04:	6d02                	ld	s10,0(sp)
    80002c06:	6125                	addi	sp,sp,96
    80002c08:	8082                	ret
      iunlock(ip);
    80002c0a:	8552                	mv	a0,s4
    80002c0c:	b25ff0ef          	jal	80002730 <iunlock>
      return ip;
    80002c10:	bff1                	j	80002bec <namex+0x5c>
      iunlockput(ip);
    80002c12:	8552                	mv	a0,s4
    80002c14:	c7bff0ef          	jal	8000288e <iunlockput>
      return 0;
    80002c18:	8a4a                	mv	s4,s2
    80002c1a:	bfc9                	j	80002bec <namex+0x5c>
  len = path - s;
    80002c1c:	40990633          	sub	a2,s2,s1
    80002c20:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80002c24:	09ac5463          	bge	s8,s10,80002cac <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80002c28:	8666                	mv	a2,s9
    80002c2a:	85a6                	mv	a1,s1
    80002c2c:	8556                	mv	a0,s5
    80002c2e:	d70fd0ef          	jal	8000019e <memmove>
    80002c32:	84ca                	mv	s1,s2
  while(*path == '/')
    80002c34:	0004c783          	lbu	a5,0(s1)
    80002c38:	01379763          	bne	a5,s3,80002c46 <namex+0xb6>
    path++;
    80002c3c:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002c3e:	0004c783          	lbu	a5,0(s1)
    80002c42:	ff378de3          	beq	a5,s3,80002c3c <namex+0xac>
    ilock(ip);
    80002c46:	8552                	mv	a0,s4
    80002c48:	a3bff0ef          	jal	80002682 <ilock>
    if(ip->type != T_DIR){
    80002c4c:	044a1783          	lh	a5,68(s4)
    80002c50:	f9779ae3          	bne	a5,s7,80002be4 <namex+0x54>
    if(nameiparent && *path == '\0'){
    80002c54:	000b0563          	beqz	s6,80002c5e <namex+0xce>
    80002c58:	0004c783          	lbu	a5,0(s1)
    80002c5c:	d7dd                	beqz	a5,80002c0a <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002c5e:	4601                	li	a2,0
    80002c60:	85d6                	mv	a1,s5
    80002c62:	8552                	mv	a0,s4
    80002c64:	e81ff0ef          	jal	80002ae4 <dirlookup>
    80002c68:	892a                	mv	s2,a0
    80002c6a:	d545                	beqz	a0,80002c12 <namex+0x82>
    iunlockput(ip);
    80002c6c:	8552                	mv	a0,s4
    80002c6e:	c21ff0ef          	jal	8000288e <iunlockput>
    ip = next;
    80002c72:	8a4a                	mv	s4,s2
  while(*path == '/')
    80002c74:	0004c783          	lbu	a5,0(s1)
    80002c78:	01379763          	bne	a5,s3,80002c86 <namex+0xf6>
    path++;
    80002c7c:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002c7e:	0004c783          	lbu	a5,0(s1)
    80002c82:	ff378de3          	beq	a5,s3,80002c7c <namex+0xec>
  if(*path == 0)
    80002c86:	cf8d                	beqz	a5,80002cc0 <namex+0x130>
  while(*path != '/' && *path != 0)
    80002c88:	0004c783          	lbu	a5,0(s1)
    80002c8c:	fd178713          	addi	a4,a5,-47
    80002c90:	cb19                	beqz	a4,80002ca6 <namex+0x116>
    80002c92:	cb91                	beqz	a5,80002ca6 <namex+0x116>
    80002c94:	8926                	mv	s2,s1
    path++;
    80002c96:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80002c98:	00094783          	lbu	a5,0(s2)
    80002c9c:	fd178713          	addi	a4,a5,-47
    80002ca0:	df35                	beqz	a4,80002c1c <namex+0x8c>
    80002ca2:	fbf5                	bnez	a5,80002c96 <namex+0x106>
    80002ca4:	bfa5                	j	80002c1c <namex+0x8c>
    80002ca6:	8926                	mv	s2,s1
  len = path - s;
    80002ca8:	4d01                	li	s10,0
    80002caa:	4601                	li	a2,0
    memmove(name, s, len);
    80002cac:	2601                	sext.w	a2,a2
    80002cae:	85a6                	mv	a1,s1
    80002cb0:	8556                	mv	a0,s5
    80002cb2:	cecfd0ef          	jal	8000019e <memmove>
    name[len] = 0;
    80002cb6:	9d56                	add	s10,s10,s5
    80002cb8:	000d0023          	sb	zero,0(s10)
    80002cbc:	84ca                	mv	s1,s2
    80002cbe:	bf9d                	j	80002c34 <namex+0xa4>
  if(nameiparent){
    80002cc0:	f20b06e3          	beqz	s6,80002bec <namex+0x5c>
    iput(ip);
    80002cc4:	8552                	mv	a0,s4
    80002cc6:	b3fff0ef          	jal	80002804 <iput>
    return 0;
    80002cca:	4a01                	li	s4,0
    80002ccc:	b705                	j	80002bec <namex+0x5c>

0000000080002cce <dirlink>:
{
    80002cce:	715d                	addi	sp,sp,-80
    80002cd0:	e486                	sd	ra,72(sp)
    80002cd2:	e0a2                	sd	s0,64(sp)
    80002cd4:	f84a                	sd	s2,48(sp)
    80002cd6:	ec56                	sd	s5,24(sp)
    80002cd8:	e85a                	sd	s6,16(sp)
    80002cda:	0880                	addi	s0,sp,80
    80002cdc:	892a                	mv	s2,a0
    80002cde:	8aae                	mv	s5,a1
    80002ce0:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002ce2:	4601                	li	a2,0
    80002ce4:	e01ff0ef          	jal	80002ae4 <dirlookup>
    80002ce8:	ed1d                	bnez	a0,80002d26 <dirlink+0x58>
    80002cea:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002cec:	04c92483          	lw	s1,76(s2)
    80002cf0:	c4b9                	beqz	s1,80002d3e <dirlink+0x70>
    80002cf2:	f44e                	sd	s3,40(sp)
    80002cf4:	f052                	sd	s4,32(sp)
    80002cf6:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002cf8:	fb040a13          	addi	s4,s0,-80
    80002cfc:	49c1                	li	s3,16
    80002cfe:	874e                	mv	a4,s3
    80002d00:	86a6                	mv	a3,s1
    80002d02:	8652                	mv	a2,s4
    80002d04:	4581                	li	a1,0
    80002d06:	854a                	mv	a0,s2
    80002d08:	bd5ff0ef          	jal	800028dc <readi>
    80002d0c:	03351163          	bne	a0,s3,80002d2e <dirlink+0x60>
    if(de.inum == 0)
    80002d10:	fb045783          	lhu	a5,-80(s0)
    80002d14:	c39d                	beqz	a5,80002d3a <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d16:	24c1                	addiw	s1,s1,16
    80002d18:	04c92783          	lw	a5,76(s2)
    80002d1c:	fef4e1e3          	bltu	s1,a5,80002cfe <dirlink+0x30>
    80002d20:	79a2                	ld	s3,40(sp)
    80002d22:	7a02                	ld	s4,32(sp)
    80002d24:	a829                	j	80002d3e <dirlink+0x70>
    iput(ip);
    80002d26:	adfff0ef          	jal	80002804 <iput>
    return -1;
    80002d2a:	557d                	li	a0,-1
    80002d2c:	a83d                	j	80002d6a <dirlink+0x9c>
      panic("dirlink read");
    80002d2e:	00005517          	auipc	a0,0x5
    80002d32:	88a50513          	addi	a0,a0,-1910 # 800075b8 <etext+0x5b8>
    80002d36:	798020ef          	jal	800054ce <panic>
    80002d3a:	79a2                	ld	s3,40(sp)
    80002d3c:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80002d3e:	4639                	li	a2,14
    80002d40:	85d6                	mv	a1,s5
    80002d42:	fb240513          	addi	a0,s0,-78
    80002d46:	d06fd0ef          	jal	8000024c <strncpy>
  de.inum = inum;
    80002d4a:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d4e:	4741                	li	a4,16
    80002d50:	86a6                	mv	a3,s1
    80002d52:	fb040613          	addi	a2,s0,-80
    80002d56:	4581                	li	a1,0
    80002d58:	854a                	mv	a0,s2
    80002d5a:	c75ff0ef          	jal	800029ce <writei>
    80002d5e:	1541                	addi	a0,a0,-16
    80002d60:	00a03533          	snez	a0,a0
    80002d64:	40a0053b          	negw	a0,a0
    80002d68:	74e2                	ld	s1,56(sp)
}
    80002d6a:	60a6                	ld	ra,72(sp)
    80002d6c:	6406                	ld	s0,64(sp)
    80002d6e:	7942                	ld	s2,48(sp)
    80002d70:	6ae2                	ld	s5,24(sp)
    80002d72:	6b42                	ld	s6,16(sp)
    80002d74:	6161                	addi	sp,sp,80
    80002d76:	8082                	ret

0000000080002d78 <namei>:

struct inode*
namei(char *path)
{
    80002d78:	1101                	addi	sp,sp,-32
    80002d7a:	ec06                	sd	ra,24(sp)
    80002d7c:	e822                	sd	s0,16(sp)
    80002d7e:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002d80:	fe040613          	addi	a2,s0,-32
    80002d84:	4581                	li	a1,0
    80002d86:	e0bff0ef          	jal	80002b90 <namex>
}
    80002d8a:	60e2                	ld	ra,24(sp)
    80002d8c:	6442                	ld	s0,16(sp)
    80002d8e:	6105                	addi	sp,sp,32
    80002d90:	8082                	ret

0000000080002d92 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002d92:	1141                	addi	sp,sp,-16
    80002d94:	e406                	sd	ra,8(sp)
    80002d96:	e022                	sd	s0,0(sp)
    80002d98:	0800                	addi	s0,sp,16
    80002d9a:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002d9c:	4585                	li	a1,1
    80002d9e:	df3ff0ef          	jal	80002b90 <namex>
}
    80002da2:	60a2                	ld	ra,8(sp)
    80002da4:	6402                	ld	s0,0(sp)
    80002da6:	0141                	addi	sp,sp,16
    80002da8:	8082                	ret

0000000080002daa <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002daa:	1101                	addi	sp,sp,-32
    80002dac:	ec06                	sd	ra,24(sp)
    80002dae:	e822                	sd	s0,16(sp)
    80002db0:	e426                	sd	s1,8(sp)
    80002db2:	e04a                	sd	s2,0(sp)
    80002db4:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002db6:	00015917          	auipc	s2,0x15
    80002dba:	eca90913          	addi	s2,s2,-310 # 80017c80 <log>
    80002dbe:	01892583          	lw	a1,24(s2)
    80002dc2:	02892503          	lw	a0,40(s2)
    80002dc6:	9baff0ef          	jal	80001f80 <bread>
    80002dca:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002dcc:	02c92603          	lw	a2,44(s2)
    80002dd0:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002dd2:	00c05f63          	blez	a2,80002df0 <write_head+0x46>
    80002dd6:	00015717          	auipc	a4,0x15
    80002dda:	eda70713          	addi	a4,a4,-294 # 80017cb0 <log+0x30>
    80002dde:	87aa                	mv	a5,a0
    80002de0:	060a                	slli	a2,a2,0x2
    80002de2:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80002de4:	4314                	lw	a3,0(a4)
    80002de6:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80002de8:	0711                	addi	a4,a4,4
    80002dea:	0791                	addi	a5,a5,4
    80002dec:	fec79ce3          	bne	a5,a2,80002de4 <write_head+0x3a>
  }
  bwrite(buf);
    80002df0:	8526                	mv	a0,s1
    80002df2:	a64ff0ef          	jal	80002056 <bwrite>
  brelse(buf);
    80002df6:	8526                	mv	a0,s1
    80002df8:	a90ff0ef          	jal	80002088 <brelse>
}
    80002dfc:	60e2                	ld	ra,24(sp)
    80002dfe:	6442                	ld	s0,16(sp)
    80002e00:	64a2                	ld	s1,8(sp)
    80002e02:	6902                	ld	s2,0(sp)
    80002e04:	6105                	addi	sp,sp,32
    80002e06:	8082                	ret

0000000080002e08 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80002e08:	00015797          	auipc	a5,0x15
    80002e0c:	ea47a783          	lw	a5,-348(a5) # 80017cac <log+0x2c>
    80002e10:	0af05263          	blez	a5,80002eb4 <install_trans+0xac>
{
    80002e14:	715d                	addi	sp,sp,-80
    80002e16:	e486                	sd	ra,72(sp)
    80002e18:	e0a2                	sd	s0,64(sp)
    80002e1a:	fc26                	sd	s1,56(sp)
    80002e1c:	f84a                	sd	s2,48(sp)
    80002e1e:	f44e                	sd	s3,40(sp)
    80002e20:	f052                	sd	s4,32(sp)
    80002e22:	ec56                	sd	s5,24(sp)
    80002e24:	e85a                	sd	s6,16(sp)
    80002e26:	e45e                	sd	s7,8(sp)
    80002e28:	0880                	addi	s0,sp,80
    80002e2a:	8b2a                	mv	s6,a0
    80002e2c:	00015a97          	auipc	s5,0x15
    80002e30:	e84a8a93          	addi	s5,s5,-380 # 80017cb0 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002e34:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002e36:	00015997          	auipc	s3,0x15
    80002e3a:	e4a98993          	addi	s3,s3,-438 # 80017c80 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80002e3e:	40000b93          	li	s7,1024
    80002e42:	a829                	j	80002e5c <install_trans+0x54>
    brelse(lbuf);
    80002e44:	854a                	mv	a0,s2
    80002e46:	a42ff0ef          	jal	80002088 <brelse>
    brelse(dbuf);
    80002e4a:	8526                	mv	a0,s1
    80002e4c:	a3cff0ef          	jal	80002088 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002e50:	2a05                	addiw	s4,s4,1
    80002e52:	0a91                	addi	s5,s5,4
    80002e54:	02c9a783          	lw	a5,44(s3)
    80002e58:	04fa5363          	bge	s4,a5,80002e9e <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002e5c:	0189a583          	lw	a1,24(s3)
    80002e60:	014585bb          	addw	a1,a1,s4
    80002e64:	2585                	addiw	a1,a1,1
    80002e66:	0289a503          	lw	a0,40(s3)
    80002e6a:	916ff0ef          	jal	80001f80 <bread>
    80002e6e:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80002e70:	000aa583          	lw	a1,0(s5)
    80002e74:	0289a503          	lw	a0,40(s3)
    80002e78:	908ff0ef          	jal	80001f80 <bread>
    80002e7c:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80002e7e:	865e                	mv	a2,s7
    80002e80:	05890593          	addi	a1,s2,88
    80002e84:	05850513          	addi	a0,a0,88
    80002e88:	b16fd0ef          	jal	8000019e <memmove>
    bwrite(dbuf);  // write dst to disk
    80002e8c:	8526                	mv	a0,s1
    80002e8e:	9c8ff0ef          	jal	80002056 <bwrite>
    if(recovering == 0)
    80002e92:	fa0b19e3          	bnez	s6,80002e44 <install_trans+0x3c>
      bunpin(dbuf);
    80002e96:	8526                	mv	a0,s1
    80002e98:	aa8ff0ef          	jal	80002140 <bunpin>
    80002e9c:	b765                	j	80002e44 <install_trans+0x3c>
}
    80002e9e:	60a6                	ld	ra,72(sp)
    80002ea0:	6406                	ld	s0,64(sp)
    80002ea2:	74e2                	ld	s1,56(sp)
    80002ea4:	7942                	ld	s2,48(sp)
    80002ea6:	79a2                	ld	s3,40(sp)
    80002ea8:	7a02                	ld	s4,32(sp)
    80002eaa:	6ae2                	ld	s5,24(sp)
    80002eac:	6b42                	ld	s6,16(sp)
    80002eae:	6ba2                	ld	s7,8(sp)
    80002eb0:	6161                	addi	sp,sp,80
    80002eb2:	8082                	ret
    80002eb4:	8082                	ret

0000000080002eb6 <initlog>:
{
    80002eb6:	7179                	addi	sp,sp,-48
    80002eb8:	f406                	sd	ra,40(sp)
    80002eba:	f022                	sd	s0,32(sp)
    80002ebc:	ec26                	sd	s1,24(sp)
    80002ebe:	e84a                	sd	s2,16(sp)
    80002ec0:	e44e                	sd	s3,8(sp)
    80002ec2:	1800                	addi	s0,sp,48
    80002ec4:	892a                	mv	s2,a0
    80002ec6:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80002ec8:	00015497          	auipc	s1,0x15
    80002ecc:	db848493          	addi	s1,s1,-584 # 80017c80 <log>
    80002ed0:	00004597          	auipc	a1,0x4
    80002ed4:	6f858593          	addi	a1,a1,1784 # 800075c8 <etext+0x5c8>
    80002ed8:	8526                	mv	a0,s1
    80002eda:	0a9020ef          	jal	80005782 <initlock>
  log.start = sb->logstart;
    80002ede:	0149a583          	lw	a1,20(s3)
    80002ee2:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80002ee4:	0109a783          	lw	a5,16(s3)
    80002ee8:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80002eea:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80002eee:	854a                	mv	a0,s2
    80002ef0:	890ff0ef          	jal	80001f80 <bread>
  log.lh.n = lh->n;
    80002ef4:	4d30                	lw	a2,88(a0)
    80002ef6:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80002ef8:	00c05f63          	blez	a2,80002f16 <initlog+0x60>
    80002efc:	87aa                	mv	a5,a0
    80002efe:	00015717          	auipc	a4,0x15
    80002f02:	db270713          	addi	a4,a4,-590 # 80017cb0 <log+0x30>
    80002f06:	060a                	slli	a2,a2,0x2
    80002f08:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80002f0a:	4ff4                	lw	a3,92(a5)
    80002f0c:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80002f0e:	0791                	addi	a5,a5,4
    80002f10:	0711                	addi	a4,a4,4
    80002f12:	fec79ce3          	bne	a5,a2,80002f0a <initlog+0x54>
  brelse(buf);
    80002f16:	972ff0ef          	jal	80002088 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80002f1a:	4505                	li	a0,1
    80002f1c:	eedff0ef          	jal	80002e08 <install_trans>
  log.lh.n = 0;
    80002f20:	00015797          	auipc	a5,0x15
    80002f24:	d807a623          	sw	zero,-628(a5) # 80017cac <log+0x2c>
  write_head(); // clear the log
    80002f28:	e83ff0ef          	jal	80002daa <write_head>
}
    80002f2c:	70a2                	ld	ra,40(sp)
    80002f2e:	7402                	ld	s0,32(sp)
    80002f30:	64e2                	ld	s1,24(sp)
    80002f32:	6942                	ld	s2,16(sp)
    80002f34:	69a2                	ld	s3,8(sp)
    80002f36:	6145                	addi	sp,sp,48
    80002f38:	8082                	ret

0000000080002f3a <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80002f3a:	1101                	addi	sp,sp,-32
    80002f3c:	ec06                	sd	ra,24(sp)
    80002f3e:	e822                	sd	s0,16(sp)
    80002f40:	e426                	sd	s1,8(sp)
    80002f42:	e04a                	sd	s2,0(sp)
    80002f44:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80002f46:	00015517          	auipc	a0,0x15
    80002f4a:	d3a50513          	addi	a0,a0,-710 # 80017c80 <log>
    80002f4e:	0bf020ef          	jal	8000580c <acquire>
  while(1){
    if(log.committing){
    80002f52:	00015497          	auipc	s1,0x15
    80002f56:	d2e48493          	addi	s1,s1,-722 # 80017c80 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80002f5a:	4979                	li	s2,30
    80002f5c:	a029                	j	80002f66 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80002f5e:	85a6                	mv	a1,s1
    80002f60:	8526                	mv	a0,s1
    80002f62:	be2fe0ef          	jal	80001344 <sleep>
    if(log.committing){
    80002f66:	50dc                	lw	a5,36(s1)
    80002f68:	fbfd                	bnez	a5,80002f5e <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80002f6a:	5098                	lw	a4,32(s1)
    80002f6c:	2705                	addiw	a4,a4,1
    80002f6e:	0027179b          	slliw	a5,a4,0x2
    80002f72:	9fb9                	addw	a5,a5,a4
    80002f74:	0017979b          	slliw	a5,a5,0x1
    80002f78:	54d4                	lw	a3,44(s1)
    80002f7a:	9fb5                	addw	a5,a5,a3
    80002f7c:	00f95763          	bge	s2,a5,80002f8a <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80002f80:	85a6                	mv	a1,s1
    80002f82:	8526                	mv	a0,s1
    80002f84:	bc0fe0ef          	jal	80001344 <sleep>
    80002f88:	bff9                	j	80002f66 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80002f8a:	00015797          	auipc	a5,0x15
    80002f8e:	d0e7ab23          	sw	a4,-746(a5) # 80017ca0 <log+0x20>
      release(&log.lock);
    80002f92:	00015517          	auipc	a0,0x15
    80002f96:	cee50513          	addi	a0,a0,-786 # 80017c80 <log>
    80002f9a:	107020ef          	jal	800058a0 <release>
      break;
    }
  }
}
    80002f9e:	60e2                	ld	ra,24(sp)
    80002fa0:	6442                	ld	s0,16(sp)
    80002fa2:	64a2                	ld	s1,8(sp)
    80002fa4:	6902                	ld	s2,0(sp)
    80002fa6:	6105                	addi	sp,sp,32
    80002fa8:	8082                	ret

0000000080002faa <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80002faa:	7139                	addi	sp,sp,-64
    80002fac:	fc06                	sd	ra,56(sp)
    80002fae:	f822                	sd	s0,48(sp)
    80002fb0:	f426                	sd	s1,40(sp)
    80002fb2:	f04a                	sd	s2,32(sp)
    80002fb4:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80002fb6:	00015497          	auipc	s1,0x15
    80002fba:	cca48493          	addi	s1,s1,-822 # 80017c80 <log>
    80002fbe:	8526                	mv	a0,s1
    80002fc0:	04d020ef          	jal	8000580c <acquire>
  log.outstanding -= 1;
    80002fc4:	509c                	lw	a5,32(s1)
    80002fc6:	37fd                	addiw	a5,a5,-1
    80002fc8:	893e                	mv	s2,a5
    80002fca:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80002fcc:	50dc                	lw	a5,36(s1)
    80002fce:	e7b1                	bnez	a5,8000301a <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80002fd0:	04091e63          	bnez	s2,8000302c <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    80002fd4:	00015497          	auipc	s1,0x15
    80002fd8:	cac48493          	addi	s1,s1,-852 # 80017c80 <log>
    80002fdc:	4785                	li	a5,1
    80002fde:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80002fe0:	8526                	mv	a0,s1
    80002fe2:	0bf020ef          	jal	800058a0 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80002fe6:	54dc                	lw	a5,44(s1)
    80002fe8:	06f04463          	bgtz	a5,80003050 <end_op+0xa6>
    acquire(&log.lock);
    80002fec:	00015517          	auipc	a0,0x15
    80002ff0:	c9450513          	addi	a0,a0,-876 # 80017c80 <log>
    80002ff4:	019020ef          	jal	8000580c <acquire>
    log.committing = 0;
    80002ff8:	00015797          	auipc	a5,0x15
    80002ffc:	ca07a623          	sw	zero,-852(a5) # 80017ca4 <log+0x24>
    wakeup(&log);
    80003000:	00015517          	auipc	a0,0x15
    80003004:	c8050513          	addi	a0,a0,-896 # 80017c80 <log>
    80003008:	b88fe0ef          	jal	80001390 <wakeup>
    release(&log.lock);
    8000300c:	00015517          	auipc	a0,0x15
    80003010:	c7450513          	addi	a0,a0,-908 # 80017c80 <log>
    80003014:	08d020ef          	jal	800058a0 <release>
}
    80003018:	a035                	j	80003044 <end_op+0x9a>
    8000301a:	ec4e                	sd	s3,24(sp)
    8000301c:	e852                	sd	s4,16(sp)
    8000301e:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003020:	00004517          	auipc	a0,0x4
    80003024:	5b050513          	addi	a0,a0,1456 # 800075d0 <etext+0x5d0>
    80003028:	4a6020ef          	jal	800054ce <panic>
    wakeup(&log);
    8000302c:	00015517          	auipc	a0,0x15
    80003030:	c5450513          	addi	a0,a0,-940 # 80017c80 <log>
    80003034:	b5cfe0ef          	jal	80001390 <wakeup>
  release(&log.lock);
    80003038:	00015517          	auipc	a0,0x15
    8000303c:	c4850513          	addi	a0,a0,-952 # 80017c80 <log>
    80003040:	061020ef          	jal	800058a0 <release>
}
    80003044:	70e2                	ld	ra,56(sp)
    80003046:	7442                	ld	s0,48(sp)
    80003048:	74a2                	ld	s1,40(sp)
    8000304a:	7902                	ld	s2,32(sp)
    8000304c:	6121                	addi	sp,sp,64
    8000304e:	8082                	ret
    80003050:	ec4e                	sd	s3,24(sp)
    80003052:	e852                	sd	s4,16(sp)
    80003054:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003056:	00015a97          	auipc	s5,0x15
    8000305a:	c5aa8a93          	addi	s5,s5,-934 # 80017cb0 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    8000305e:	00015a17          	auipc	s4,0x15
    80003062:	c22a0a13          	addi	s4,s4,-990 # 80017c80 <log>
    80003066:	018a2583          	lw	a1,24(s4)
    8000306a:	012585bb          	addw	a1,a1,s2
    8000306e:	2585                	addiw	a1,a1,1
    80003070:	028a2503          	lw	a0,40(s4)
    80003074:	f0dfe0ef          	jal	80001f80 <bread>
    80003078:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    8000307a:	000aa583          	lw	a1,0(s5)
    8000307e:	028a2503          	lw	a0,40(s4)
    80003082:	efffe0ef          	jal	80001f80 <bread>
    80003086:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003088:	40000613          	li	a2,1024
    8000308c:	05850593          	addi	a1,a0,88
    80003090:	05848513          	addi	a0,s1,88
    80003094:	90afd0ef          	jal	8000019e <memmove>
    bwrite(to);  // write the log
    80003098:	8526                	mv	a0,s1
    8000309a:	fbdfe0ef          	jal	80002056 <bwrite>
    brelse(from);
    8000309e:	854e                	mv	a0,s3
    800030a0:	fe9fe0ef          	jal	80002088 <brelse>
    brelse(to);
    800030a4:	8526                	mv	a0,s1
    800030a6:	fe3fe0ef          	jal	80002088 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800030aa:	2905                	addiw	s2,s2,1
    800030ac:	0a91                	addi	s5,s5,4
    800030ae:	02ca2783          	lw	a5,44(s4)
    800030b2:	faf94ae3          	blt	s2,a5,80003066 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800030b6:	cf5ff0ef          	jal	80002daa <write_head>
    install_trans(0); // Now install writes to home locations
    800030ba:	4501                	li	a0,0
    800030bc:	d4dff0ef          	jal	80002e08 <install_trans>
    log.lh.n = 0;
    800030c0:	00015797          	auipc	a5,0x15
    800030c4:	be07a623          	sw	zero,-1044(a5) # 80017cac <log+0x2c>
    write_head();    // Erase the transaction from the log
    800030c8:	ce3ff0ef          	jal	80002daa <write_head>
    800030cc:	69e2                	ld	s3,24(sp)
    800030ce:	6a42                	ld	s4,16(sp)
    800030d0:	6aa2                	ld	s5,8(sp)
    800030d2:	bf29                	j	80002fec <end_op+0x42>

00000000800030d4 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800030d4:	1101                	addi	sp,sp,-32
    800030d6:	ec06                	sd	ra,24(sp)
    800030d8:	e822                	sd	s0,16(sp)
    800030da:	e426                	sd	s1,8(sp)
    800030dc:	1000                	addi	s0,sp,32
    800030de:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800030e0:	00015517          	auipc	a0,0x15
    800030e4:	ba050513          	addi	a0,a0,-1120 # 80017c80 <log>
    800030e8:	724020ef          	jal	8000580c <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800030ec:	00015617          	auipc	a2,0x15
    800030f0:	bc062603          	lw	a2,-1088(a2) # 80017cac <log+0x2c>
    800030f4:	47f5                	li	a5,29
    800030f6:	06c7c463          	blt	a5,a2,8000315e <log_write+0x8a>
    800030fa:	00015797          	auipc	a5,0x15
    800030fe:	ba27a783          	lw	a5,-1118(a5) # 80017c9c <log+0x1c>
    80003102:	37fd                	addiw	a5,a5,-1
    80003104:	04f65d63          	bge	a2,a5,8000315e <log_write+0x8a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003108:	00015797          	auipc	a5,0x15
    8000310c:	b987a783          	lw	a5,-1128(a5) # 80017ca0 <log+0x20>
    80003110:	04f05d63          	blez	a5,8000316a <log_write+0x96>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003114:	4781                	li	a5,0
    80003116:	06c05063          	blez	a2,80003176 <log_write+0xa2>
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000311a:	44cc                	lw	a1,12(s1)
    8000311c:	00015717          	auipc	a4,0x15
    80003120:	b9470713          	addi	a4,a4,-1132 # 80017cb0 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003124:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003126:	4314                	lw	a3,0(a4)
    80003128:	04b68763          	beq	a3,a1,80003176 <log_write+0xa2>
  for (i = 0; i < log.lh.n; i++) {
    8000312c:	2785                	addiw	a5,a5,1
    8000312e:	0711                	addi	a4,a4,4
    80003130:	fef61be3          	bne	a2,a5,80003126 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003134:	060a                	slli	a2,a2,0x2
    80003136:	02060613          	addi	a2,a2,32
    8000313a:	00015797          	auipc	a5,0x15
    8000313e:	b4678793          	addi	a5,a5,-1210 # 80017c80 <log>
    80003142:	97b2                	add	a5,a5,a2
    80003144:	44d8                	lw	a4,12(s1)
    80003146:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003148:	8526                	mv	a0,s1
    8000314a:	fc3fe0ef          	jal	8000210c <bpin>
    log.lh.n++;
    8000314e:	00015717          	auipc	a4,0x15
    80003152:	b3270713          	addi	a4,a4,-1230 # 80017c80 <log>
    80003156:	575c                	lw	a5,44(a4)
    80003158:	2785                	addiw	a5,a5,1
    8000315a:	d75c                	sw	a5,44(a4)
    8000315c:	a815                	j	80003190 <log_write+0xbc>
    panic("too big a transaction");
    8000315e:	00004517          	auipc	a0,0x4
    80003162:	48250513          	addi	a0,a0,1154 # 800075e0 <etext+0x5e0>
    80003166:	368020ef          	jal	800054ce <panic>
    panic("log_write outside of trans");
    8000316a:	00004517          	auipc	a0,0x4
    8000316e:	48e50513          	addi	a0,a0,1166 # 800075f8 <etext+0x5f8>
    80003172:	35c020ef          	jal	800054ce <panic>
  log.lh.block[i] = b->blockno;
    80003176:	00279693          	slli	a3,a5,0x2
    8000317a:	02068693          	addi	a3,a3,32
    8000317e:	00015717          	auipc	a4,0x15
    80003182:	b0270713          	addi	a4,a4,-1278 # 80017c80 <log>
    80003186:	9736                	add	a4,a4,a3
    80003188:	44d4                	lw	a3,12(s1)
    8000318a:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000318c:	faf60ee3          	beq	a2,a5,80003148 <log_write+0x74>
  }
  release(&log.lock);
    80003190:	00015517          	auipc	a0,0x15
    80003194:	af050513          	addi	a0,a0,-1296 # 80017c80 <log>
    80003198:	708020ef          	jal	800058a0 <release>
}
    8000319c:	60e2                	ld	ra,24(sp)
    8000319e:	6442                	ld	s0,16(sp)
    800031a0:	64a2                	ld	s1,8(sp)
    800031a2:	6105                	addi	sp,sp,32
    800031a4:	8082                	ret

00000000800031a6 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800031a6:	1101                	addi	sp,sp,-32
    800031a8:	ec06                	sd	ra,24(sp)
    800031aa:	e822                	sd	s0,16(sp)
    800031ac:	e426                	sd	s1,8(sp)
    800031ae:	e04a                	sd	s2,0(sp)
    800031b0:	1000                	addi	s0,sp,32
    800031b2:	84aa                	mv	s1,a0
    800031b4:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800031b6:	00004597          	auipc	a1,0x4
    800031ba:	46258593          	addi	a1,a1,1122 # 80007618 <etext+0x618>
    800031be:	0521                	addi	a0,a0,8
    800031c0:	5c2020ef          	jal	80005782 <initlock>
  lk->name = name;
    800031c4:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800031c8:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800031cc:	0204a423          	sw	zero,40(s1)
}
    800031d0:	60e2                	ld	ra,24(sp)
    800031d2:	6442                	ld	s0,16(sp)
    800031d4:	64a2                	ld	s1,8(sp)
    800031d6:	6902                	ld	s2,0(sp)
    800031d8:	6105                	addi	sp,sp,32
    800031da:	8082                	ret

00000000800031dc <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800031dc:	1101                	addi	sp,sp,-32
    800031de:	ec06                	sd	ra,24(sp)
    800031e0:	e822                	sd	s0,16(sp)
    800031e2:	e426                	sd	s1,8(sp)
    800031e4:	e04a                	sd	s2,0(sp)
    800031e6:	1000                	addi	s0,sp,32
    800031e8:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800031ea:	00850913          	addi	s2,a0,8
    800031ee:	854a                	mv	a0,s2
    800031f0:	61c020ef          	jal	8000580c <acquire>
  while (lk->locked) {
    800031f4:	409c                	lw	a5,0(s1)
    800031f6:	c799                	beqz	a5,80003204 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    800031f8:	85ca                	mv	a1,s2
    800031fa:	8526                	mv	a0,s1
    800031fc:	948fe0ef          	jal	80001344 <sleep>
  while (lk->locked) {
    80003200:	409c                	lw	a5,0(s1)
    80003202:	fbfd                	bnez	a5,800031f8 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003204:	4785                	li	a5,1
    80003206:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003208:	b63fd0ef          	jal	80000d6a <myproc>
    8000320c:	591c                	lw	a5,48(a0)
    8000320e:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003210:	854a                	mv	a0,s2
    80003212:	68e020ef          	jal	800058a0 <release>
}
    80003216:	60e2                	ld	ra,24(sp)
    80003218:	6442                	ld	s0,16(sp)
    8000321a:	64a2                	ld	s1,8(sp)
    8000321c:	6902                	ld	s2,0(sp)
    8000321e:	6105                	addi	sp,sp,32
    80003220:	8082                	ret

0000000080003222 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003222:	1101                	addi	sp,sp,-32
    80003224:	ec06                	sd	ra,24(sp)
    80003226:	e822                	sd	s0,16(sp)
    80003228:	e426                	sd	s1,8(sp)
    8000322a:	e04a                	sd	s2,0(sp)
    8000322c:	1000                	addi	s0,sp,32
    8000322e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003230:	00850913          	addi	s2,a0,8
    80003234:	854a                	mv	a0,s2
    80003236:	5d6020ef          	jal	8000580c <acquire>
  lk->locked = 0;
    8000323a:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000323e:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003242:	8526                	mv	a0,s1
    80003244:	94cfe0ef          	jal	80001390 <wakeup>
  release(&lk->lk);
    80003248:	854a                	mv	a0,s2
    8000324a:	656020ef          	jal	800058a0 <release>
}
    8000324e:	60e2                	ld	ra,24(sp)
    80003250:	6442                	ld	s0,16(sp)
    80003252:	64a2                	ld	s1,8(sp)
    80003254:	6902                	ld	s2,0(sp)
    80003256:	6105                	addi	sp,sp,32
    80003258:	8082                	ret

000000008000325a <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000325a:	7179                	addi	sp,sp,-48
    8000325c:	f406                	sd	ra,40(sp)
    8000325e:	f022                	sd	s0,32(sp)
    80003260:	ec26                	sd	s1,24(sp)
    80003262:	e84a                	sd	s2,16(sp)
    80003264:	1800                	addi	s0,sp,48
    80003266:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003268:	00850913          	addi	s2,a0,8
    8000326c:	854a                	mv	a0,s2
    8000326e:	59e020ef          	jal	8000580c <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003272:	409c                	lw	a5,0(s1)
    80003274:	ef81                	bnez	a5,8000328c <holdingsleep+0x32>
    80003276:	4481                	li	s1,0
  release(&lk->lk);
    80003278:	854a                	mv	a0,s2
    8000327a:	626020ef          	jal	800058a0 <release>
  return r;
}
    8000327e:	8526                	mv	a0,s1
    80003280:	70a2                	ld	ra,40(sp)
    80003282:	7402                	ld	s0,32(sp)
    80003284:	64e2                	ld	s1,24(sp)
    80003286:	6942                	ld	s2,16(sp)
    80003288:	6145                	addi	sp,sp,48
    8000328a:	8082                	ret
    8000328c:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    8000328e:	0284a983          	lw	s3,40(s1)
    80003292:	ad9fd0ef          	jal	80000d6a <myproc>
    80003296:	5904                	lw	s1,48(a0)
    80003298:	413484b3          	sub	s1,s1,s3
    8000329c:	0014b493          	seqz	s1,s1
    800032a0:	69a2                	ld	s3,8(sp)
    800032a2:	bfd9                	j	80003278 <holdingsleep+0x1e>

00000000800032a4 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800032a4:	1141                	addi	sp,sp,-16
    800032a6:	e406                	sd	ra,8(sp)
    800032a8:	e022                	sd	s0,0(sp)
    800032aa:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800032ac:	00004597          	auipc	a1,0x4
    800032b0:	37c58593          	addi	a1,a1,892 # 80007628 <etext+0x628>
    800032b4:	00015517          	auipc	a0,0x15
    800032b8:	b1450513          	addi	a0,a0,-1260 # 80017dc8 <ftable>
    800032bc:	4c6020ef          	jal	80005782 <initlock>
}
    800032c0:	60a2                	ld	ra,8(sp)
    800032c2:	6402                	ld	s0,0(sp)
    800032c4:	0141                	addi	sp,sp,16
    800032c6:	8082                	ret

00000000800032c8 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    800032c8:	1101                	addi	sp,sp,-32
    800032ca:	ec06                	sd	ra,24(sp)
    800032cc:	e822                	sd	s0,16(sp)
    800032ce:	e426                	sd	s1,8(sp)
    800032d0:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800032d2:	00015517          	auipc	a0,0x15
    800032d6:	af650513          	addi	a0,a0,-1290 # 80017dc8 <ftable>
    800032da:	532020ef          	jal	8000580c <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800032de:	00015497          	auipc	s1,0x15
    800032e2:	b0248493          	addi	s1,s1,-1278 # 80017de0 <ftable+0x18>
    800032e6:	00016717          	auipc	a4,0x16
    800032ea:	a9a70713          	addi	a4,a4,-1382 # 80018d80 <disk>
    if(f->ref == 0){
    800032ee:	40dc                	lw	a5,4(s1)
    800032f0:	cf89                	beqz	a5,8000330a <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800032f2:	02848493          	addi	s1,s1,40
    800032f6:	fee49ce3          	bne	s1,a4,800032ee <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800032fa:	00015517          	auipc	a0,0x15
    800032fe:	ace50513          	addi	a0,a0,-1330 # 80017dc8 <ftable>
    80003302:	59e020ef          	jal	800058a0 <release>
  return 0;
    80003306:	4481                	li	s1,0
    80003308:	a809                	j	8000331a <filealloc+0x52>
      f->ref = 1;
    8000330a:	4785                	li	a5,1
    8000330c:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    8000330e:	00015517          	auipc	a0,0x15
    80003312:	aba50513          	addi	a0,a0,-1350 # 80017dc8 <ftable>
    80003316:	58a020ef          	jal	800058a0 <release>
}
    8000331a:	8526                	mv	a0,s1
    8000331c:	60e2                	ld	ra,24(sp)
    8000331e:	6442                	ld	s0,16(sp)
    80003320:	64a2                	ld	s1,8(sp)
    80003322:	6105                	addi	sp,sp,32
    80003324:	8082                	ret

0000000080003326 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003326:	1101                	addi	sp,sp,-32
    80003328:	ec06                	sd	ra,24(sp)
    8000332a:	e822                	sd	s0,16(sp)
    8000332c:	e426                	sd	s1,8(sp)
    8000332e:	1000                	addi	s0,sp,32
    80003330:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003332:	00015517          	auipc	a0,0x15
    80003336:	a9650513          	addi	a0,a0,-1386 # 80017dc8 <ftable>
    8000333a:	4d2020ef          	jal	8000580c <acquire>
  if(f->ref < 1)
    8000333e:	40dc                	lw	a5,4(s1)
    80003340:	02f05063          	blez	a5,80003360 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003344:	2785                	addiw	a5,a5,1
    80003346:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003348:	00015517          	auipc	a0,0x15
    8000334c:	a8050513          	addi	a0,a0,-1408 # 80017dc8 <ftable>
    80003350:	550020ef          	jal	800058a0 <release>
  return f;
}
    80003354:	8526                	mv	a0,s1
    80003356:	60e2                	ld	ra,24(sp)
    80003358:	6442                	ld	s0,16(sp)
    8000335a:	64a2                	ld	s1,8(sp)
    8000335c:	6105                	addi	sp,sp,32
    8000335e:	8082                	ret
    panic("filedup");
    80003360:	00004517          	auipc	a0,0x4
    80003364:	2d050513          	addi	a0,a0,720 # 80007630 <etext+0x630>
    80003368:	166020ef          	jal	800054ce <panic>

000000008000336c <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000336c:	7139                	addi	sp,sp,-64
    8000336e:	fc06                	sd	ra,56(sp)
    80003370:	f822                	sd	s0,48(sp)
    80003372:	f426                	sd	s1,40(sp)
    80003374:	0080                	addi	s0,sp,64
    80003376:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003378:	00015517          	auipc	a0,0x15
    8000337c:	a5050513          	addi	a0,a0,-1456 # 80017dc8 <ftable>
    80003380:	48c020ef          	jal	8000580c <acquire>
  if(f->ref < 1)
    80003384:	40dc                	lw	a5,4(s1)
    80003386:	04f05a63          	blez	a5,800033da <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    8000338a:	37fd                	addiw	a5,a5,-1
    8000338c:	c0dc                	sw	a5,4(s1)
    8000338e:	06f04063          	bgtz	a5,800033ee <fileclose+0x82>
    80003392:	f04a                	sd	s2,32(sp)
    80003394:	ec4e                	sd	s3,24(sp)
    80003396:	e852                	sd	s4,16(sp)
    80003398:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000339a:	0004a903          	lw	s2,0(s1)
    8000339e:	0094c783          	lbu	a5,9(s1)
    800033a2:	89be                	mv	s3,a5
    800033a4:	689c                	ld	a5,16(s1)
    800033a6:	8a3e                	mv	s4,a5
    800033a8:	6c9c                	ld	a5,24(s1)
    800033aa:	8abe                	mv	s5,a5
  f->ref = 0;
    800033ac:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800033b0:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800033b4:	00015517          	auipc	a0,0x15
    800033b8:	a1450513          	addi	a0,a0,-1516 # 80017dc8 <ftable>
    800033bc:	4e4020ef          	jal	800058a0 <release>

  if(ff.type == FD_PIPE){
    800033c0:	4785                	li	a5,1
    800033c2:	04f90163          	beq	s2,a5,80003404 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800033c6:	ffe9079b          	addiw	a5,s2,-2
    800033ca:	4705                	li	a4,1
    800033cc:	04f77563          	bgeu	a4,a5,80003416 <fileclose+0xaa>
    800033d0:	7902                	ld	s2,32(sp)
    800033d2:	69e2                	ld	s3,24(sp)
    800033d4:	6a42                	ld	s4,16(sp)
    800033d6:	6aa2                	ld	s5,8(sp)
    800033d8:	a00d                	j	800033fa <fileclose+0x8e>
    800033da:	f04a                	sd	s2,32(sp)
    800033dc:	ec4e                	sd	s3,24(sp)
    800033de:	e852                	sd	s4,16(sp)
    800033e0:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800033e2:	00004517          	auipc	a0,0x4
    800033e6:	25650513          	addi	a0,a0,598 # 80007638 <etext+0x638>
    800033ea:	0e4020ef          	jal	800054ce <panic>
    release(&ftable.lock);
    800033ee:	00015517          	auipc	a0,0x15
    800033f2:	9da50513          	addi	a0,a0,-1574 # 80017dc8 <ftable>
    800033f6:	4aa020ef          	jal	800058a0 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800033fa:	70e2                	ld	ra,56(sp)
    800033fc:	7442                	ld	s0,48(sp)
    800033fe:	74a2                	ld	s1,40(sp)
    80003400:	6121                	addi	sp,sp,64
    80003402:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80003404:	85ce                	mv	a1,s3
    80003406:	8552                	mv	a0,s4
    80003408:	348000ef          	jal	80003750 <pipeclose>
    8000340c:	7902                	ld	s2,32(sp)
    8000340e:	69e2                	ld	s3,24(sp)
    80003410:	6a42                	ld	s4,16(sp)
    80003412:	6aa2                	ld	s5,8(sp)
    80003414:	b7dd                	j	800033fa <fileclose+0x8e>
    begin_op();
    80003416:	b25ff0ef          	jal	80002f3a <begin_op>
    iput(ff.ip);
    8000341a:	8556                	mv	a0,s5
    8000341c:	be8ff0ef          	jal	80002804 <iput>
    end_op();
    80003420:	b8bff0ef          	jal	80002faa <end_op>
    80003424:	7902                	ld	s2,32(sp)
    80003426:	69e2                	ld	s3,24(sp)
    80003428:	6a42                	ld	s4,16(sp)
    8000342a:	6aa2                	ld	s5,8(sp)
    8000342c:	b7f9                	j	800033fa <fileclose+0x8e>

000000008000342e <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000342e:	715d                	addi	sp,sp,-80
    80003430:	e486                	sd	ra,72(sp)
    80003432:	e0a2                	sd	s0,64(sp)
    80003434:	fc26                	sd	s1,56(sp)
    80003436:	f052                	sd	s4,32(sp)
    80003438:	0880                	addi	s0,sp,80
    8000343a:	84aa                	mv	s1,a0
    8000343c:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    8000343e:	92dfd0ef          	jal	80000d6a <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003442:	409c                	lw	a5,0(s1)
    80003444:	37f9                	addiw	a5,a5,-2
    80003446:	4705                	li	a4,1
    80003448:	04f76263          	bltu	a4,a5,8000348c <filestat+0x5e>
    8000344c:	f84a                	sd	s2,48(sp)
    8000344e:	f44e                	sd	s3,40(sp)
    80003450:	89aa                	mv	s3,a0
    ilock(f->ip);
    80003452:	6c88                	ld	a0,24(s1)
    80003454:	a2eff0ef          	jal	80002682 <ilock>
    stati(f->ip, &st);
    80003458:	fb840913          	addi	s2,s0,-72
    8000345c:	85ca                	mv	a1,s2
    8000345e:	6c88                	ld	a0,24(s1)
    80003460:	c4eff0ef          	jal	800028ae <stati>
    iunlock(f->ip);
    80003464:	6c88                	ld	a0,24(s1)
    80003466:	acaff0ef          	jal	80002730 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    8000346a:	46e1                	li	a3,24
    8000346c:	864a                	mv	a2,s2
    8000346e:	85d2                	mv	a1,s4
    80003470:	0509b503          	ld	a0,80(s3)
    80003474:	d76fd0ef          	jal	800009ea <copyout>
    80003478:	41f5551b          	sraiw	a0,a0,0x1f
    8000347c:	7942                	ld	s2,48(sp)
    8000347e:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80003480:	60a6                	ld	ra,72(sp)
    80003482:	6406                	ld	s0,64(sp)
    80003484:	74e2                	ld	s1,56(sp)
    80003486:	7a02                	ld	s4,32(sp)
    80003488:	6161                	addi	sp,sp,80
    8000348a:	8082                	ret
  return -1;
    8000348c:	557d                	li	a0,-1
    8000348e:	bfcd                	j	80003480 <filestat+0x52>

0000000080003490 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003490:	7179                	addi	sp,sp,-48
    80003492:	f406                	sd	ra,40(sp)
    80003494:	f022                	sd	s0,32(sp)
    80003496:	e84a                	sd	s2,16(sp)
    80003498:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    8000349a:	00854783          	lbu	a5,8(a0)
    8000349e:	cfd1                	beqz	a5,8000353a <fileread+0xaa>
    800034a0:	ec26                	sd	s1,24(sp)
    800034a2:	e44e                	sd	s3,8(sp)
    800034a4:	84aa                	mv	s1,a0
    800034a6:	892e                	mv	s2,a1
    800034a8:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    800034aa:	411c                	lw	a5,0(a0)
    800034ac:	4705                	li	a4,1
    800034ae:	04e78363          	beq	a5,a4,800034f4 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800034b2:	470d                	li	a4,3
    800034b4:	04e78763          	beq	a5,a4,80003502 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800034b8:	4709                	li	a4,2
    800034ba:	06e79a63          	bne	a5,a4,8000352e <fileread+0x9e>
    ilock(f->ip);
    800034be:	6d08                	ld	a0,24(a0)
    800034c0:	9c2ff0ef          	jal	80002682 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800034c4:	874e                	mv	a4,s3
    800034c6:	5094                	lw	a3,32(s1)
    800034c8:	864a                	mv	a2,s2
    800034ca:	4585                	li	a1,1
    800034cc:	6c88                	ld	a0,24(s1)
    800034ce:	c0eff0ef          	jal	800028dc <readi>
    800034d2:	892a                	mv	s2,a0
    800034d4:	00a05563          	blez	a0,800034de <fileread+0x4e>
      f->off += r;
    800034d8:	509c                	lw	a5,32(s1)
    800034da:	9fa9                	addw	a5,a5,a0
    800034dc:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800034de:	6c88                	ld	a0,24(s1)
    800034e0:	a50ff0ef          	jal	80002730 <iunlock>
    800034e4:	64e2                	ld	s1,24(sp)
    800034e6:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800034e8:	854a                	mv	a0,s2
    800034ea:	70a2                	ld	ra,40(sp)
    800034ec:	7402                	ld	s0,32(sp)
    800034ee:	6942                	ld	s2,16(sp)
    800034f0:	6145                	addi	sp,sp,48
    800034f2:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800034f4:	6908                	ld	a0,16(a0)
    800034f6:	3b0000ef          	jal	800038a6 <piperead>
    800034fa:	892a                	mv	s2,a0
    800034fc:	64e2                	ld	s1,24(sp)
    800034fe:	69a2                	ld	s3,8(sp)
    80003500:	b7e5                	j	800034e8 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80003502:	02451783          	lh	a5,36(a0)
    80003506:	03079693          	slli	a3,a5,0x30
    8000350a:	92c1                	srli	a3,a3,0x30
    8000350c:	4725                	li	a4,9
    8000350e:	02d76963          	bltu	a4,a3,80003540 <fileread+0xb0>
    80003512:	0792                	slli	a5,a5,0x4
    80003514:	00015717          	auipc	a4,0x15
    80003518:	81470713          	addi	a4,a4,-2028 # 80017d28 <devsw>
    8000351c:	97ba                	add	a5,a5,a4
    8000351e:	639c                	ld	a5,0(a5)
    80003520:	c78d                	beqz	a5,8000354a <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80003522:	4505                	li	a0,1
    80003524:	9782                	jalr	a5
    80003526:	892a                	mv	s2,a0
    80003528:	64e2                	ld	s1,24(sp)
    8000352a:	69a2                	ld	s3,8(sp)
    8000352c:	bf75                	j	800034e8 <fileread+0x58>
    panic("fileread");
    8000352e:	00004517          	auipc	a0,0x4
    80003532:	11a50513          	addi	a0,a0,282 # 80007648 <etext+0x648>
    80003536:	799010ef          	jal	800054ce <panic>
    return -1;
    8000353a:	57fd                	li	a5,-1
    8000353c:	893e                	mv	s2,a5
    8000353e:	b76d                	j	800034e8 <fileread+0x58>
      return -1;
    80003540:	57fd                	li	a5,-1
    80003542:	893e                	mv	s2,a5
    80003544:	64e2                	ld	s1,24(sp)
    80003546:	69a2                	ld	s3,8(sp)
    80003548:	b745                	j	800034e8 <fileread+0x58>
    8000354a:	57fd                	li	a5,-1
    8000354c:	893e                	mv	s2,a5
    8000354e:	64e2                	ld	s1,24(sp)
    80003550:	69a2                	ld	s3,8(sp)
    80003552:	bf59                	j	800034e8 <fileread+0x58>

0000000080003554 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80003554:	00954783          	lbu	a5,9(a0)
    80003558:	10078f63          	beqz	a5,80003676 <filewrite+0x122>
{
    8000355c:	711d                	addi	sp,sp,-96
    8000355e:	ec86                	sd	ra,88(sp)
    80003560:	e8a2                	sd	s0,80(sp)
    80003562:	e0ca                	sd	s2,64(sp)
    80003564:	f456                	sd	s5,40(sp)
    80003566:	f05a                	sd	s6,32(sp)
    80003568:	1080                	addi	s0,sp,96
    8000356a:	892a                	mv	s2,a0
    8000356c:	8b2e                	mv	s6,a1
    8000356e:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    80003570:	411c                	lw	a5,0(a0)
    80003572:	4705                	li	a4,1
    80003574:	02e78a63          	beq	a5,a4,800035a8 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003578:	470d                	li	a4,3
    8000357a:	02e78b63          	beq	a5,a4,800035b0 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    8000357e:	4709                	li	a4,2
    80003580:	0ce79f63          	bne	a5,a4,8000365e <filewrite+0x10a>
    80003584:	f852                	sd	s4,48(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80003586:	0ac05a63          	blez	a2,8000363a <filewrite+0xe6>
    8000358a:	e4a6                	sd	s1,72(sp)
    8000358c:	fc4e                	sd	s3,56(sp)
    8000358e:	ec5e                	sd	s7,24(sp)
    80003590:	e862                	sd	s8,16(sp)
    80003592:	e466                	sd	s9,8(sp)
    int i = 0;
    80003594:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    80003596:	6b85                	lui	s7,0x1
    80003598:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    8000359c:	6785                	lui	a5,0x1
    8000359e:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800035a2:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800035a4:	4c05                	li	s8,1
    800035a6:	a8ad                	j	80003620 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800035a8:	6908                	ld	a0,16(a0)
    800035aa:	204000ef          	jal	800037ae <pipewrite>
    800035ae:	a04d                	j	80003650 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800035b0:	02451783          	lh	a5,36(a0)
    800035b4:	03079693          	slli	a3,a5,0x30
    800035b8:	92c1                	srli	a3,a3,0x30
    800035ba:	4725                	li	a4,9
    800035bc:	0ad76f63          	bltu	a4,a3,8000367a <filewrite+0x126>
    800035c0:	0792                	slli	a5,a5,0x4
    800035c2:	00014717          	auipc	a4,0x14
    800035c6:	76670713          	addi	a4,a4,1894 # 80017d28 <devsw>
    800035ca:	97ba                	add	a5,a5,a4
    800035cc:	679c                	ld	a5,8(a5)
    800035ce:	cbc5                	beqz	a5,8000367e <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    800035d0:	4505                	li	a0,1
    800035d2:	9782                	jalr	a5
    800035d4:	a8b5                	j	80003650 <filewrite+0xfc>
      if(n1 > max)
    800035d6:	2981                	sext.w	s3,s3
      begin_op();
    800035d8:	963ff0ef          	jal	80002f3a <begin_op>
      ilock(f->ip);
    800035dc:	01893503          	ld	a0,24(s2)
    800035e0:	8a2ff0ef          	jal	80002682 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800035e4:	874e                	mv	a4,s3
    800035e6:	02092683          	lw	a3,32(s2)
    800035ea:	016a0633          	add	a2,s4,s6
    800035ee:	85e2                	mv	a1,s8
    800035f0:	01893503          	ld	a0,24(s2)
    800035f4:	bdaff0ef          	jal	800029ce <writei>
    800035f8:	84aa                	mv	s1,a0
    800035fa:	00a05763          	blez	a0,80003608 <filewrite+0xb4>
        f->off += r;
    800035fe:	02092783          	lw	a5,32(s2)
    80003602:	9fa9                	addw	a5,a5,a0
    80003604:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80003608:	01893503          	ld	a0,24(s2)
    8000360c:	924ff0ef          	jal	80002730 <iunlock>
      end_op();
    80003610:	99bff0ef          	jal	80002faa <end_op>

      if(r != n1){
    80003614:	02999563          	bne	s3,s1,8000363e <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    80003618:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    8000361c:	015a5963          	bge	s4,s5,8000362e <filewrite+0xda>
      int n1 = n - i;
    80003620:	414a87bb          	subw	a5,s5,s4
    80003624:	89be                	mv	s3,a5
      if(n1 > max)
    80003626:	fafbd8e3          	bge	s7,a5,800035d6 <filewrite+0x82>
    8000362a:	89e6                	mv	s3,s9
    8000362c:	b76d                	j	800035d6 <filewrite+0x82>
    8000362e:	64a6                	ld	s1,72(sp)
    80003630:	79e2                	ld	s3,56(sp)
    80003632:	6be2                	ld	s7,24(sp)
    80003634:	6c42                	ld	s8,16(sp)
    80003636:	6ca2                	ld	s9,8(sp)
    80003638:	a801                	j	80003648 <filewrite+0xf4>
    int i = 0;
    8000363a:	4a01                	li	s4,0
    8000363c:	a031                	j	80003648 <filewrite+0xf4>
    8000363e:	64a6                	ld	s1,72(sp)
    80003640:	79e2                	ld	s3,56(sp)
    80003642:	6be2                	ld	s7,24(sp)
    80003644:	6c42                	ld	s8,16(sp)
    80003646:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    80003648:	034a9d63          	bne	s5,s4,80003682 <filewrite+0x12e>
    8000364c:	8556                	mv	a0,s5
    8000364e:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80003650:	60e6                	ld	ra,88(sp)
    80003652:	6446                	ld	s0,80(sp)
    80003654:	6906                	ld	s2,64(sp)
    80003656:	7aa2                	ld	s5,40(sp)
    80003658:	7b02                	ld	s6,32(sp)
    8000365a:	6125                	addi	sp,sp,96
    8000365c:	8082                	ret
    8000365e:	e4a6                	sd	s1,72(sp)
    80003660:	fc4e                	sd	s3,56(sp)
    80003662:	f852                	sd	s4,48(sp)
    80003664:	ec5e                	sd	s7,24(sp)
    80003666:	e862                	sd	s8,16(sp)
    80003668:	e466                	sd	s9,8(sp)
    panic("filewrite");
    8000366a:	00004517          	auipc	a0,0x4
    8000366e:	fee50513          	addi	a0,a0,-18 # 80007658 <etext+0x658>
    80003672:	65d010ef          	jal	800054ce <panic>
    return -1;
    80003676:	557d                	li	a0,-1
}
    80003678:	8082                	ret
      return -1;
    8000367a:	557d                	li	a0,-1
    8000367c:	bfd1                	j	80003650 <filewrite+0xfc>
    8000367e:	557d                	li	a0,-1
    80003680:	bfc1                	j	80003650 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    80003682:	557d                	li	a0,-1
    80003684:	7a42                	ld	s4,48(sp)
    80003686:	b7e9                	j	80003650 <filewrite+0xfc>

0000000080003688 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80003688:	7179                	addi	sp,sp,-48
    8000368a:	f406                	sd	ra,40(sp)
    8000368c:	f022                	sd	s0,32(sp)
    8000368e:	ec26                	sd	s1,24(sp)
    80003690:	e052                	sd	s4,0(sp)
    80003692:	1800                	addi	s0,sp,48
    80003694:	84aa                	mv	s1,a0
    80003696:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80003698:	0005b023          	sd	zero,0(a1)
    8000369c:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800036a0:	c29ff0ef          	jal	800032c8 <filealloc>
    800036a4:	e088                	sd	a0,0(s1)
    800036a6:	c549                	beqz	a0,80003730 <pipealloc+0xa8>
    800036a8:	c21ff0ef          	jal	800032c8 <filealloc>
    800036ac:	00aa3023          	sd	a0,0(s4)
    800036b0:	cd25                	beqz	a0,80003728 <pipealloc+0xa0>
    800036b2:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800036b4:	a49fc0ef          	jal	800000fc <kalloc>
    800036b8:	892a                	mv	s2,a0
    800036ba:	c12d                	beqz	a0,8000371c <pipealloc+0x94>
    800036bc:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800036be:	4985                	li	s3,1
    800036c0:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800036c4:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800036c8:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800036cc:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800036d0:	00004597          	auipc	a1,0x4
    800036d4:	d4058593          	addi	a1,a1,-704 # 80007410 <etext+0x410>
    800036d8:	0aa020ef          	jal	80005782 <initlock>
  (*f0)->type = FD_PIPE;
    800036dc:	609c                	ld	a5,0(s1)
    800036de:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800036e2:	609c                	ld	a5,0(s1)
    800036e4:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800036e8:	609c                	ld	a5,0(s1)
    800036ea:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800036ee:	609c                	ld	a5,0(s1)
    800036f0:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800036f4:	000a3783          	ld	a5,0(s4)
    800036f8:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800036fc:	000a3783          	ld	a5,0(s4)
    80003700:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80003704:	000a3783          	ld	a5,0(s4)
    80003708:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000370c:	000a3783          	ld	a5,0(s4)
    80003710:	0127b823          	sd	s2,16(a5)
  return 0;
    80003714:	4501                	li	a0,0
    80003716:	6942                	ld	s2,16(sp)
    80003718:	69a2                	ld	s3,8(sp)
    8000371a:	a01d                	j	80003740 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000371c:	6088                	ld	a0,0(s1)
    8000371e:	c119                	beqz	a0,80003724 <pipealloc+0x9c>
    80003720:	6942                	ld	s2,16(sp)
    80003722:	a029                	j	8000372c <pipealloc+0xa4>
    80003724:	6942                	ld	s2,16(sp)
    80003726:	a029                	j	80003730 <pipealloc+0xa8>
    80003728:	6088                	ld	a0,0(s1)
    8000372a:	c10d                	beqz	a0,8000374c <pipealloc+0xc4>
    fileclose(*f0);
    8000372c:	c41ff0ef          	jal	8000336c <fileclose>
  if(*f1)
    80003730:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80003734:	557d                	li	a0,-1
  if(*f1)
    80003736:	c789                	beqz	a5,80003740 <pipealloc+0xb8>
    fileclose(*f1);
    80003738:	853e                	mv	a0,a5
    8000373a:	c33ff0ef          	jal	8000336c <fileclose>
  return -1;
    8000373e:	557d                	li	a0,-1
}
    80003740:	70a2                	ld	ra,40(sp)
    80003742:	7402                	ld	s0,32(sp)
    80003744:	64e2                	ld	s1,24(sp)
    80003746:	6a02                	ld	s4,0(sp)
    80003748:	6145                	addi	sp,sp,48
    8000374a:	8082                	ret
  return -1;
    8000374c:	557d                	li	a0,-1
    8000374e:	bfcd                	j	80003740 <pipealloc+0xb8>

0000000080003750 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80003750:	1101                	addi	sp,sp,-32
    80003752:	ec06                	sd	ra,24(sp)
    80003754:	e822                	sd	s0,16(sp)
    80003756:	e426                	sd	s1,8(sp)
    80003758:	e04a                	sd	s2,0(sp)
    8000375a:	1000                	addi	s0,sp,32
    8000375c:	84aa                	mv	s1,a0
    8000375e:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80003760:	0ac020ef          	jal	8000580c <acquire>
  if(writable){
    80003764:	02090763          	beqz	s2,80003792 <pipeclose+0x42>
    pi->writeopen = 0;
    80003768:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    8000376c:	21848513          	addi	a0,s1,536
    80003770:	c21fd0ef          	jal	80001390 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80003774:	2204a783          	lw	a5,544(s1)
    80003778:	e781                	bnez	a5,80003780 <pipeclose+0x30>
    8000377a:	2244a783          	lw	a5,548(s1)
    8000377e:	c38d                	beqz	a5,800037a0 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    80003780:	8526                	mv	a0,s1
    80003782:	11e020ef          	jal	800058a0 <release>
}
    80003786:	60e2                	ld	ra,24(sp)
    80003788:	6442                	ld	s0,16(sp)
    8000378a:	64a2                	ld	s1,8(sp)
    8000378c:	6902                	ld	s2,0(sp)
    8000378e:	6105                	addi	sp,sp,32
    80003790:	8082                	ret
    pi->readopen = 0;
    80003792:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80003796:	21c48513          	addi	a0,s1,540
    8000379a:	bf7fd0ef          	jal	80001390 <wakeup>
    8000379e:	bfd9                	j	80003774 <pipeclose+0x24>
    release(&pi->lock);
    800037a0:	8526                	mv	a0,s1
    800037a2:	0fe020ef          	jal	800058a0 <release>
    kfree((char*)pi);
    800037a6:	8526                	mv	a0,s1
    800037a8:	875fc0ef          	jal	8000001c <kfree>
    800037ac:	bfe9                	j	80003786 <pipeclose+0x36>

00000000800037ae <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800037ae:	7159                	addi	sp,sp,-112
    800037b0:	f486                	sd	ra,104(sp)
    800037b2:	f0a2                	sd	s0,96(sp)
    800037b4:	eca6                	sd	s1,88(sp)
    800037b6:	e8ca                	sd	s2,80(sp)
    800037b8:	e4ce                	sd	s3,72(sp)
    800037ba:	e0d2                	sd	s4,64(sp)
    800037bc:	fc56                	sd	s5,56(sp)
    800037be:	1880                	addi	s0,sp,112
    800037c0:	84aa                	mv	s1,a0
    800037c2:	8aae                	mv	s5,a1
    800037c4:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800037c6:	da4fd0ef          	jal	80000d6a <myproc>
    800037ca:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800037cc:	8526                	mv	a0,s1
    800037ce:	03e020ef          	jal	8000580c <acquire>
  while(i < n){
    800037d2:	0d405263          	blez	s4,80003896 <pipewrite+0xe8>
    800037d6:	f85a                	sd	s6,48(sp)
    800037d8:	f45e                	sd	s7,40(sp)
    800037da:	f062                	sd	s8,32(sp)
    800037dc:	ec66                	sd	s9,24(sp)
    800037de:	e86a                	sd	s10,16(sp)
  int i = 0;
    800037e0:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800037e2:	f9f40c13          	addi	s8,s0,-97
    800037e6:	4b85                	li	s7,1
    800037e8:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800037ea:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    800037ee:	21c48c93          	addi	s9,s1,540
    800037f2:	a82d                	j	8000382c <pipewrite+0x7e>
      release(&pi->lock);
    800037f4:	8526                	mv	a0,s1
    800037f6:	0aa020ef          	jal	800058a0 <release>
      return -1;
    800037fa:	597d                	li	s2,-1
    800037fc:	7b42                	ld	s6,48(sp)
    800037fe:	7ba2                	ld	s7,40(sp)
    80003800:	7c02                	ld	s8,32(sp)
    80003802:	6ce2                	ld	s9,24(sp)
    80003804:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80003806:	854a                	mv	a0,s2
    80003808:	70a6                	ld	ra,104(sp)
    8000380a:	7406                	ld	s0,96(sp)
    8000380c:	64e6                	ld	s1,88(sp)
    8000380e:	6946                	ld	s2,80(sp)
    80003810:	69a6                	ld	s3,72(sp)
    80003812:	6a06                	ld	s4,64(sp)
    80003814:	7ae2                	ld	s5,56(sp)
    80003816:	6165                	addi	sp,sp,112
    80003818:	8082                	ret
      wakeup(&pi->nread);
    8000381a:	856a                	mv	a0,s10
    8000381c:	b75fd0ef          	jal	80001390 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80003820:	85a6                	mv	a1,s1
    80003822:	8566                	mv	a0,s9
    80003824:	b21fd0ef          	jal	80001344 <sleep>
  while(i < n){
    80003828:	05495a63          	bge	s2,s4,8000387c <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    8000382c:	2204a783          	lw	a5,544(s1)
    80003830:	d3f1                	beqz	a5,800037f4 <pipewrite+0x46>
    80003832:	854e                	mv	a0,s3
    80003834:	d4dfd0ef          	jal	80001580 <killed>
    80003838:	fd55                	bnez	a0,800037f4 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    8000383a:	2184a783          	lw	a5,536(s1)
    8000383e:	21c4a703          	lw	a4,540(s1)
    80003842:	2007879b          	addiw	a5,a5,512
    80003846:	fcf70ae3          	beq	a4,a5,8000381a <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000384a:	86de                	mv	a3,s7
    8000384c:	01590633          	add	a2,s2,s5
    80003850:	85e2                	mv	a1,s8
    80003852:	0509b503          	ld	a0,80(s3)
    80003856:	a44fd0ef          	jal	80000a9a <copyin>
    8000385a:	05650063          	beq	a0,s6,8000389a <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000385e:	21c4a783          	lw	a5,540(s1)
    80003862:	0017871b          	addiw	a4,a5,1
    80003866:	20e4ae23          	sw	a4,540(s1)
    8000386a:	1ff7f793          	andi	a5,a5,511
    8000386e:	97a6                	add	a5,a5,s1
    80003870:	f9f44703          	lbu	a4,-97(s0)
    80003874:	00e78c23          	sb	a4,24(a5)
      i++;
    80003878:	2905                	addiw	s2,s2,1
    8000387a:	b77d                	j	80003828 <pipewrite+0x7a>
    8000387c:	7b42                	ld	s6,48(sp)
    8000387e:	7ba2                	ld	s7,40(sp)
    80003880:	7c02                	ld	s8,32(sp)
    80003882:	6ce2                	ld	s9,24(sp)
    80003884:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80003886:	21848513          	addi	a0,s1,536
    8000388a:	b07fd0ef          	jal	80001390 <wakeup>
  release(&pi->lock);
    8000388e:	8526                	mv	a0,s1
    80003890:	010020ef          	jal	800058a0 <release>
  return i;
    80003894:	bf8d                	j	80003806 <pipewrite+0x58>
  int i = 0;
    80003896:	4901                	li	s2,0
    80003898:	b7fd                	j	80003886 <pipewrite+0xd8>
    8000389a:	7b42                	ld	s6,48(sp)
    8000389c:	7ba2                	ld	s7,40(sp)
    8000389e:	7c02                	ld	s8,32(sp)
    800038a0:	6ce2                	ld	s9,24(sp)
    800038a2:	6d42                	ld	s10,16(sp)
    800038a4:	b7cd                	j	80003886 <pipewrite+0xd8>

00000000800038a6 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800038a6:	711d                	addi	sp,sp,-96
    800038a8:	ec86                	sd	ra,88(sp)
    800038aa:	e8a2                	sd	s0,80(sp)
    800038ac:	e4a6                	sd	s1,72(sp)
    800038ae:	e0ca                	sd	s2,64(sp)
    800038b0:	fc4e                	sd	s3,56(sp)
    800038b2:	f852                	sd	s4,48(sp)
    800038b4:	f456                	sd	s5,40(sp)
    800038b6:	1080                	addi	s0,sp,96
    800038b8:	84aa                	mv	s1,a0
    800038ba:	892e                	mv	s2,a1
    800038bc:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800038be:	cacfd0ef          	jal	80000d6a <myproc>
    800038c2:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800038c4:	8526                	mv	a0,s1
    800038c6:	747010ef          	jal	8000580c <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800038ca:	2184a703          	lw	a4,536(s1)
    800038ce:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800038d2:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800038d6:	02f71763          	bne	a4,a5,80003904 <piperead+0x5e>
    800038da:	2244a783          	lw	a5,548(s1)
    800038de:	cf85                	beqz	a5,80003916 <piperead+0x70>
    if(killed(pr)){
    800038e0:	8552                	mv	a0,s4
    800038e2:	c9ffd0ef          	jal	80001580 <killed>
    800038e6:	e11d                	bnez	a0,8000390c <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800038e8:	85a6                	mv	a1,s1
    800038ea:	854e                	mv	a0,s3
    800038ec:	a59fd0ef          	jal	80001344 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800038f0:	2184a703          	lw	a4,536(s1)
    800038f4:	21c4a783          	lw	a5,540(s1)
    800038f8:	fef701e3          	beq	a4,a5,800038da <piperead+0x34>
    800038fc:	f05a                	sd	s6,32(sp)
    800038fe:	ec5e                	sd	s7,24(sp)
    80003900:	e862                	sd	s8,16(sp)
    80003902:	a829                	j	8000391c <piperead+0x76>
    80003904:	f05a                	sd	s6,32(sp)
    80003906:	ec5e                	sd	s7,24(sp)
    80003908:	e862                	sd	s8,16(sp)
    8000390a:	a809                	j	8000391c <piperead+0x76>
      release(&pi->lock);
    8000390c:	8526                	mv	a0,s1
    8000390e:	793010ef          	jal	800058a0 <release>
      return -1;
    80003912:	59fd                	li	s3,-1
    80003914:	a09d                	j	8000397a <piperead+0xd4>
    80003916:	f05a                	sd	s6,32(sp)
    80003918:	ec5e                	sd	s7,24(sp)
    8000391a:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000391c:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    8000391e:	faf40c13          	addi	s8,s0,-81
    80003922:	4b85                	li	s7,1
    80003924:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003926:	05505063          	blez	s5,80003966 <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    8000392a:	2184a783          	lw	a5,536(s1)
    8000392e:	21c4a703          	lw	a4,540(s1)
    80003932:	02f70a63          	beq	a4,a5,80003966 <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003936:	0017871b          	addiw	a4,a5,1
    8000393a:	20e4ac23          	sw	a4,536(s1)
    8000393e:	1ff7f793          	andi	a5,a5,511
    80003942:	97a6                	add	a5,a5,s1
    80003944:	0187c783          	lbu	a5,24(a5)
    80003948:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    8000394c:	86de                	mv	a3,s7
    8000394e:	8662                	mv	a2,s8
    80003950:	85ca                	mv	a1,s2
    80003952:	050a3503          	ld	a0,80(s4)
    80003956:	894fd0ef          	jal	800009ea <copyout>
    8000395a:	01650663          	beq	a0,s6,80003966 <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000395e:	2985                	addiw	s3,s3,1
    80003960:	0905                	addi	s2,s2,1
    80003962:	fd3a94e3          	bne	s5,s3,8000392a <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003966:	21c48513          	addi	a0,s1,540
    8000396a:	a27fd0ef          	jal	80001390 <wakeup>
  release(&pi->lock);
    8000396e:	8526                	mv	a0,s1
    80003970:	731010ef          	jal	800058a0 <release>
    80003974:	7b02                	ld	s6,32(sp)
    80003976:	6be2                	ld	s7,24(sp)
    80003978:	6c42                	ld	s8,16(sp)
  return i;
}
    8000397a:	854e                	mv	a0,s3
    8000397c:	60e6                	ld	ra,88(sp)
    8000397e:	6446                	ld	s0,80(sp)
    80003980:	64a6                	ld	s1,72(sp)
    80003982:	6906                	ld	s2,64(sp)
    80003984:	79e2                	ld	s3,56(sp)
    80003986:	7a42                	ld	s4,48(sp)
    80003988:	7aa2                	ld	s5,40(sp)
    8000398a:	6125                	addi	sp,sp,96
    8000398c:	8082                	ret

000000008000398e <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    8000398e:	1141                	addi	sp,sp,-16
    80003990:	e406                	sd	ra,8(sp)
    80003992:	e022                	sd	s0,0(sp)
    80003994:	0800                	addi	s0,sp,16
    80003996:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003998:	0035151b          	slliw	a0,a0,0x3
    8000399c:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    8000399e:	8b89                	andi	a5,a5,2
    800039a0:	c399                	beqz	a5,800039a6 <flags2perm+0x18>
      perm |= PTE_W;
    800039a2:	00456513          	ori	a0,a0,4
    return perm;
}
    800039a6:	60a2                	ld	ra,8(sp)
    800039a8:	6402                	ld	s0,0(sp)
    800039aa:	0141                	addi	sp,sp,16
    800039ac:	8082                	ret

00000000800039ae <exec>:

int
exec(char *path, char **argv)
{
    800039ae:	de010113          	addi	sp,sp,-544
    800039b2:	20113c23          	sd	ra,536(sp)
    800039b6:	20813823          	sd	s0,528(sp)
    800039ba:	20913423          	sd	s1,520(sp)
    800039be:	21213023          	sd	s2,512(sp)
    800039c2:	1400                	addi	s0,sp,544
    800039c4:	892a                	mv	s2,a0
    800039c6:	dea43823          	sd	a0,-528(s0)
    800039ca:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800039ce:	b9cfd0ef          	jal	80000d6a <myproc>
    800039d2:	84aa                	mv	s1,a0

  begin_op();
    800039d4:	d66ff0ef          	jal	80002f3a <begin_op>

  if((ip = namei(path)) == 0){
    800039d8:	854a                	mv	a0,s2
    800039da:	b9eff0ef          	jal	80002d78 <namei>
    800039de:	cd21                	beqz	a0,80003a36 <exec+0x88>
    800039e0:	fbd2                	sd	s4,496(sp)
    800039e2:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800039e4:	c9ffe0ef          	jal	80002682 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800039e8:	04000713          	li	a4,64
    800039ec:	4681                	li	a3,0
    800039ee:	e5040613          	addi	a2,s0,-432
    800039f2:	4581                	li	a1,0
    800039f4:	8552                	mv	a0,s4
    800039f6:	ee7fe0ef          	jal	800028dc <readi>
    800039fa:	04000793          	li	a5,64
    800039fe:	00f51a63          	bne	a0,a5,80003a12 <exec+0x64>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80003a02:	e5042703          	lw	a4,-432(s0)
    80003a06:	464c47b7          	lui	a5,0x464c4
    80003a0a:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003a0e:	02f70863          	beq	a4,a5,80003a3e <exec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003a12:	8552                	mv	a0,s4
    80003a14:	e7bfe0ef          	jal	8000288e <iunlockput>
    end_op();
    80003a18:	d92ff0ef          	jal	80002faa <end_op>
  }
  return -1;
    80003a1c:	557d                	li	a0,-1
    80003a1e:	7a5e                	ld	s4,496(sp)
}
    80003a20:	21813083          	ld	ra,536(sp)
    80003a24:	21013403          	ld	s0,528(sp)
    80003a28:	20813483          	ld	s1,520(sp)
    80003a2c:	20013903          	ld	s2,512(sp)
    80003a30:	22010113          	addi	sp,sp,544
    80003a34:	8082                	ret
    end_op();
    80003a36:	d74ff0ef          	jal	80002faa <end_op>
    return -1;
    80003a3a:	557d                	li	a0,-1
    80003a3c:	b7d5                	j	80003a20 <exec+0x72>
    80003a3e:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80003a40:	8526                	mv	a0,s1
    80003a42:	bd2fd0ef          	jal	80000e14 <proc_pagetable>
    80003a46:	8b2a                	mv	s6,a0
    80003a48:	26050f63          	beqz	a0,80003cc6 <exec+0x318>
    80003a4c:	ffce                	sd	s3,504(sp)
    80003a4e:	f7d6                	sd	s5,488(sp)
    80003a50:	efde                	sd	s7,472(sp)
    80003a52:	ebe2                	sd	s8,464(sp)
    80003a54:	e7e6                	sd	s9,456(sp)
    80003a56:	e3ea                	sd	s10,448(sp)
    80003a58:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003a5a:	e8845783          	lhu	a5,-376(s0)
    80003a5e:	0e078963          	beqz	a5,80003b50 <exec+0x1a2>
    80003a62:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003a66:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003a68:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003a6a:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80003a6e:	6c85                	lui	s9,0x1
    80003a70:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80003a74:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80003a78:	6a85                	lui	s5,0x1
    80003a7a:	a085                	j	80003ada <exec+0x12c>
      panic("loadseg: address should exist");
    80003a7c:	00004517          	auipc	a0,0x4
    80003a80:	bec50513          	addi	a0,a0,-1044 # 80007668 <etext+0x668>
    80003a84:	24b010ef          	jal	800054ce <panic>
    if(sz - i < PGSIZE)
    80003a88:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003a8a:	874a                	mv	a4,s2
    80003a8c:	009b86bb          	addw	a3,s7,s1
    80003a90:	4581                	li	a1,0
    80003a92:	8552                	mv	a0,s4
    80003a94:	e49fe0ef          	jal	800028dc <readi>
    80003a98:	22a91b63          	bne	s2,a0,80003cce <exec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    80003a9c:	009a84bb          	addw	s1,s5,s1
    80003aa0:	0334f263          	bgeu	s1,s3,80003ac4 <exec+0x116>
    pa = walkaddr(pagetable, va + i);
    80003aa4:	02049593          	slli	a1,s1,0x20
    80003aa8:	9181                	srli	a1,a1,0x20
    80003aaa:	95e2                	add	a1,a1,s8
    80003aac:	855a                	mv	a0,s6
    80003aae:	9bffc0ef          	jal	8000046c <walkaddr>
    80003ab2:	862a                	mv	a2,a0
    if(pa == 0)
    80003ab4:	d561                	beqz	a0,80003a7c <exec+0xce>
    if(sz - i < PGSIZE)
    80003ab6:	409987bb          	subw	a5,s3,s1
    80003aba:	893e                	mv	s2,a5
    80003abc:	fcfcf6e3          	bgeu	s9,a5,80003a88 <exec+0xda>
    80003ac0:	8956                	mv	s2,s5
    80003ac2:	b7d9                	j	80003a88 <exec+0xda>
    sz = sz1;
    80003ac4:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003ac8:	2d05                	addiw	s10,s10,1
    80003aca:	e0843783          	ld	a5,-504(s0)
    80003ace:	0387869b          	addiw	a3,a5,56
    80003ad2:	e8845783          	lhu	a5,-376(s0)
    80003ad6:	06fd5e63          	bge	s10,a5,80003b52 <exec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003ada:	e0d43423          	sd	a3,-504(s0)
    80003ade:	876e                	mv	a4,s11
    80003ae0:	e1840613          	addi	a2,s0,-488
    80003ae4:	4581                	li	a1,0
    80003ae6:	8552                	mv	a0,s4
    80003ae8:	df5fe0ef          	jal	800028dc <readi>
    80003aec:	1db51f63          	bne	a0,s11,80003cca <exec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80003af0:	e1842783          	lw	a5,-488(s0)
    80003af4:	4705                	li	a4,1
    80003af6:	fce799e3          	bne	a5,a4,80003ac8 <exec+0x11a>
    if(ph.memsz < ph.filesz)
    80003afa:	e4043483          	ld	s1,-448(s0)
    80003afe:	e3843783          	ld	a5,-456(s0)
    80003b02:	1ef4e463          	bltu	s1,a5,80003cea <exec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003b06:	e2843783          	ld	a5,-472(s0)
    80003b0a:	94be                	add	s1,s1,a5
    80003b0c:	1ef4e263          	bltu	s1,a5,80003cf0 <exec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80003b10:	de843703          	ld	a4,-536(s0)
    80003b14:	8ff9                	and	a5,a5,a4
    80003b16:	1e079063          	bnez	a5,80003cf6 <exec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003b1a:	e1c42503          	lw	a0,-484(s0)
    80003b1e:	e71ff0ef          	jal	8000398e <flags2perm>
    80003b22:	86aa                	mv	a3,a0
    80003b24:	8626                	mv	a2,s1
    80003b26:	85ca                	mv	a1,s2
    80003b28:	855a                	mv	a0,s6
    80003b2a:	cb9fc0ef          	jal	800007e2 <uvmalloc>
    80003b2e:	dea43c23          	sd	a0,-520(s0)
    80003b32:	1c050563          	beqz	a0,80003cfc <exec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003b36:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003b3a:	00098863          	beqz	s3,80003b4a <exec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003b3e:	e2843c03          	ld	s8,-472(s0)
    80003b42:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003b46:	4481                	li	s1,0
    80003b48:	bfb1                	j	80003aa4 <exec+0xf6>
    sz = sz1;
    80003b4a:	df843903          	ld	s2,-520(s0)
    80003b4e:	bfad                	j	80003ac8 <exec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003b50:	4901                	li	s2,0
  iunlockput(ip);
    80003b52:	8552                	mv	a0,s4
    80003b54:	d3bfe0ef          	jal	8000288e <iunlockput>
  end_op();
    80003b58:	c52ff0ef          	jal	80002faa <end_op>
  p = myproc();
    80003b5c:	a0efd0ef          	jal	80000d6a <myproc>
    80003b60:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80003b62:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003b66:	6985                	lui	s3,0x1
    80003b68:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80003b6a:	99ca                	add	s3,s3,s2
    80003b6c:	77fd                	lui	a5,0xfffff
    80003b6e:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003b72:	4691                	li	a3,4
    80003b74:	6609                	lui	a2,0x2
    80003b76:	964e                	add	a2,a2,s3
    80003b78:	85ce                	mv	a1,s3
    80003b7a:	855a                	mv	a0,s6
    80003b7c:	c67fc0ef          	jal	800007e2 <uvmalloc>
    80003b80:	8a2a                	mv	s4,a0
    80003b82:	e105                	bnez	a0,80003ba2 <exec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80003b84:	85ce                	mv	a1,s3
    80003b86:	855a                	mv	a0,s6
    80003b88:	b10fd0ef          	jal	80000e98 <proc_freepagetable>
  return -1;
    80003b8c:	557d                	li	a0,-1
    80003b8e:	79fe                	ld	s3,504(sp)
    80003b90:	7a5e                	ld	s4,496(sp)
    80003b92:	7abe                	ld	s5,488(sp)
    80003b94:	7b1e                	ld	s6,480(sp)
    80003b96:	6bfe                	ld	s7,472(sp)
    80003b98:	6c5e                	ld	s8,464(sp)
    80003b9a:	6cbe                	ld	s9,456(sp)
    80003b9c:	6d1e                	ld	s10,448(sp)
    80003b9e:	7dfa                	ld	s11,440(sp)
    80003ba0:	b541                	j	80003a20 <exec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003ba2:	75f9                	lui	a1,0xffffe
    80003ba4:	95aa                	add	a1,a1,a0
    80003ba6:	855a                	mv	a0,s6
    80003ba8:	e19fc0ef          	jal	800009c0 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003bac:	800a0b93          	addi	s7,s4,-2048
    80003bb0:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80003bb4:	e0043783          	ld	a5,-512(s0)
    80003bb8:	6388                	ld	a0,0(a5)
  sp = sz;
    80003bba:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80003bbc:	4481                	li	s1,0
    ustack[argc] = sp;
    80003bbe:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80003bc2:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80003bc6:	cd21                	beqz	a0,80003c1e <exec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80003bc8:	f00fc0ef          	jal	800002c8 <strlen>
    80003bcc:	0015079b          	addiw	a5,a0,1
    80003bd0:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003bd4:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80003bd8:	13796563          	bltu	s2,s7,80003d02 <exec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003bdc:	e0043d83          	ld	s11,-512(s0)
    80003be0:	000db983          	ld	s3,0(s11)
    80003be4:	854e                	mv	a0,s3
    80003be6:	ee2fc0ef          	jal	800002c8 <strlen>
    80003bea:	0015069b          	addiw	a3,a0,1
    80003bee:	864e                	mv	a2,s3
    80003bf0:	85ca                	mv	a1,s2
    80003bf2:	855a                	mv	a0,s6
    80003bf4:	df7fc0ef          	jal	800009ea <copyout>
    80003bf8:	10054763          	bltz	a0,80003d06 <exec+0x358>
    ustack[argc] = sp;
    80003bfc:	00349793          	slli	a5,s1,0x3
    80003c00:	97e6                	add	a5,a5,s9
    80003c02:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde040>
  for(argc = 0; argv[argc]; argc++) {
    80003c06:	0485                	addi	s1,s1,1
    80003c08:	008d8793          	addi	a5,s11,8
    80003c0c:	e0f43023          	sd	a5,-512(s0)
    80003c10:	008db503          	ld	a0,8(s11)
    80003c14:	c509                	beqz	a0,80003c1e <exec+0x270>
    if(argc >= MAXARG)
    80003c16:	fb8499e3          	bne	s1,s8,80003bc8 <exec+0x21a>
  sz = sz1;
    80003c1a:	89d2                	mv	s3,s4
    80003c1c:	b7a5                	j	80003b84 <exec+0x1d6>
  ustack[argc] = 0;
    80003c1e:	00349793          	slli	a5,s1,0x3
    80003c22:	f9078793          	addi	a5,a5,-112
    80003c26:	97a2                	add	a5,a5,s0
    80003c28:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80003c2c:	00349693          	slli	a3,s1,0x3
    80003c30:	06a1                	addi	a3,a3,8
    80003c32:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003c36:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80003c3a:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80003c3c:	f57964e3          	bltu	s2,s7,80003b84 <exec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003c40:	e9040613          	addi	a2,s0,-368
    80003c44:	85ca                	mv	a1,s2
    80003c46:	855a                	mv	a0,s6
    80003c48:	da3fc0ef          	jal	800009ea <copyout>
    80003c4c:	f2054ce3          	bltz	a0,80003b84 <exec+0x1d6>
  p->trapframe->a1 = sp;
    80003c50:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80003c54:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003c58:	df043783          	ld	a5,-528(s0)
    80003c5c:	0007c703          	lbu	a4,0(a5)
    80003c60:	cf11                	beqz	a4,80003c7c <exec+0x2ce>
    80003c62:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003c64:	02f00693          	li	a3,47
    80003c68:	a029                	j	80003c72 <exec+0x2c4>
  for(last=s=path; *s; s++)
    80003c6a:	0785                	addi	a5,a5,1
    80003c6c:	fff7c703          	lbu	a4,-1(a5)
    80003c70:	c711                	beqz	a4,80003c7c <exec+0x2ce>
    if(*s == '/')
    80003c72:	fed71ce3          	bne	a4,a3,80003c6a <exec+0x2bc>
      last = s+1;
    80003c76:	def43823          	sd	a5,-528(s0)
    80003c7a:	bfc5                	j	80003c6a <exec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80003c7c:	4641                	li	a2,16
    80003c7e:	df043583          	ld	a1,-528(s0)
    80003c82:	158a8513          	addi	a0,s5,344
    80003c86:	e0cfc0ef          	jal	80000292 <safestrcpy>
  oldpagetable = p->pagetable;
    80003c8a:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80003c8e:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80003c92:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003c96:	058ab783          	ld	a5,88(s5)
    80003c9a:	e6843703          	ld	a4,-408(s0)
    80003c9e:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003ca0:	058ab783          	ld	a5,88(s5)
    80003ca4:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003ca8:	85ea                	mv	a1,s10
    80003caa:	9eefd0ef          	jal	80000e98 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003cae:	0004851b          	sext.w	a0,s1
    80003cb2:	79fe                	ld	s3,504(sp)
    80003cb4:	7a5e                	ld	s4,496(sp)
    80003cb6:	7abe                	ld	s5,488(sp)
    80003cb8:	7b1e                	ld	s6,480(sp)
    80003cba:	6bfe                	ld	s7,472(sp)
    80003cbc:	6c5e                	ld	s8,464(sp)
    80003cbe:	6cbe                	ld	s9,456(sp)
    80003cc0:	6d1e                	ld	s10,448(sp)
    80003cc2:	7dfa                	ld	s11,440(sp)
    80003cc4:	bbb1                	j	80003a20 <exec+0x72>
    80003cc6:	7b1e                	ld	s6,480(sp)
    80003cc8:	b3a9                	j	80003a12 <exec+0x64>
    80003cca:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003cce:	df843583          	ld	a1,-520(s0)
    80003cd2:	855a                	mv	a0,s6
    80003cd4:	9c4fd0ef          	jal	80000e98 <proc_freepagetable>
  if(ip){
    80003cd8:	79fe                	ld	s3,504(sp)
    80003cda:	7abe                	ld	s5,488(sp)
    80003cdc:	7b1e                	ld	s6,480(sp)
    80003cde:	6bfe                	ld	s7,472(sp)
    80003ce0:	6c5e                	ld	s8,464(sp)
    80003ce2:	6cbe                	ld	s9,456(sp)
    80003ce4:	6d1e                	ld	s10,448(sp)
    80003ce6:	7dfa                	ld	s11,440(sp)
    80003ce8:	b32d                	j	80003a12 <exec+0x64>
    80003cea:	df243c23          	sd	s2,-520(s0)
    80003cee:	b7c5                	j	80003cce <exec+0x320>
    80003cf0:	df243c23          	sd	s2,-520(s0)
    80003cf4:	bfe9                	j	80003cce <exec+0x320>
    80003cf6:	df243c23          	sd	s2,-520(s0)
    80003cfa:	bfd1                	j	80003cce <exec+0x320>
    80003cfc:	df243c23          	sd	s2,-520(s0)
    80003d00:	b7f9                	j	80003cce <exec+0x320>
  sz = sz1;
    80003d02:	89d2                	mv	s3,s4
    80003d04:	b541                	j	80003b84 <exec+0x1d6>
    80003d06:	89d2                	mv	s3,s4
    80003d08:	bdb5                	j	80003b84 <exec+0x1d6>

0000000080003d0a <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003d0a:	7179                	addi	sp,sp,-48
    80003d0c:	f406                	sd	ra,40(sp)
    80003d0e:	f022                	sd	s0,32(sp)
    80003d10:	ec26                	sd	s1,24(sp)
    80003d12:	e84a                	sd	s2,16(sp)
    80003d14:	1800                	addi	s0,sp,48
    80003d16:	892e                	mv	s2,a1
    80003d18:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003d1a:	fdc40593          	addi	a1,s0,-36
    80003d1e:	f15fd0ef          	jal	80001c32 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003d22:	fdc42703          	lw	a4,-36(s0)
    80003d26:	47bd                	li	a5,15
    80003d28:	02e7ea63          	bltu	a5,a4,80003d5c <argfd+0x52>
    80003d2c:	83efd0ef          	jal	80000d6a <myproc>
    80003d30:	fdc42703          	lw	a4,-36(s0)
    80003d34:	00371793          	slli	a5,a4,0x3
    80003d38:	0d078793          	addi	a5,a5,208
    80003d3c:	953e                	add	a0,a0,a5
    80003d3e:	611c                	ld	a5,0(a0)
    80003d40:	c385                	beqz	a5,80003d60 <argfd+0x56>
    return -1;
  if(pfd)
    80003d42:	00090463          	beqz	s2,80003d4a <argfd+0x40>
    *pfd = fd;
    80003d46:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003d4a:	4501                	li	a0,0
  if(pf)
    80003d4c:	c091                	beqz	s1,80003d50 <argfd+0x46>
    *pf = f;
    80003d4e:	e09c                	sd	a5,0(s1)
}
    80003d50:	70a2                	ld	ra,40(sp)
    80003d52:	7402                	ld	s0,32(sp)
    80003d54:	64e2                	ld	s1,24(sp)
    80003d56:	6942                	ld	s2,16(sp)
    80003d58:	6145                	addi	sp,sp,48
    80003d5a:	8082                	ret
    return -1;
    80003d5c:	557d                	li	a0,-1
    80003d5e:	bfcd                	j	80003d50 <argfd+0x46>
    80003d60:	557d                	li	a0,-1
    80003d62:	b7fd                	j	80003d50 <argfd+0x46>

0000000080003d64 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003d64:	1101                	addi	sp,sp,-32
    80003d66:	ec06                	sd	ra,24(sp)
    80003d68:	e822                	sd	s0,16(sp)
    80003d6a:	e426                	sd	s1,8(sp)
    80003d6c:	1000                	addi	s0,sp,32
    80003d6e:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003d70:	ffbfc0ef          	jal	80000d6a <myproc>
    80003d74:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003d76:	0d050793          	addi	a5,a0,208
    80003d7a:	4501                	li	a0,0
    80003d7c:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003d7e:	6398                	ld	a4,0(a5)
    80003d80:	cb19                	beqz	a4,80003d96 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003d82:	2505                	addiw	a0,a0,1
    80003d84:	07a1                	addi	a5,a5,8
    80003d86:	fed51ce3          	bne	a0,a3,80003d7e <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003d8a:	557d                	li	a0,-1
}
    80003d8c:	60e2                	ld	ra,24(sp)
    80003d8e:	6442                	ld	s0,16(sp)
    80003d90:	64a2                	ld	s1,8(sp)
    80003d92:	6105                	addi	sp,sp,32
    80003d94:	8082                	ret
      p->ofile[fd] = f;
    80003d96:	00351793          	slli	a5,a0,0x3
    80003d9a:	0d078793          	addi	a5,a5,208
    80003d9e:	963e                	add	a2,a2,a5
    80003da0:	e204                	sd	s1,0(a2)
      return fd;
    80003da2:	b7ed                	j	80003d8c <fdalloc+0x28>

0000000080003da4 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003da4:	715d                	addi	sp,sp,-80
    80003da6:	e486                	sd	ra,72(sp)
    80003da8:	e0a2                	sd	s0,64(sp)
    80003daa:	fc26                	sd	s1,56(sp)
    80003dac:	f84a                	sd	s2,48(sp)
    80003dae:	f44e                	sd	s3,40(sp)
    80003db0:	f052                	sd	s4,32(sp)
    80003db2:	ec56                	sd	s5,24(sp)
    80003db4:	e85a                	sd	s6,16(sp)
    80003db6:	0880                	addi	s0,sp,80
    80003db8:	892e                	mv	s2,a1
    80003dba:	8a2e                	mv	s4,a1
    80003dbc:	8ab2                	mv	s5,a2
    80003dbe:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003dc0:	fb040593          	addi	a1,s0,-80
    80003dc4:	fcffe0ef          	jal	80002d92 <nameiparent>
    80003dc8:	84aa                	mv	s1,a0
    80003dca:	10050763          	beqz	a0,80003ed8 <create+0x134>
    return 0;

  ilock(dp);
    80003dce:	8b5fe0ef          	jal	80002682 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003dd2:	4601                	li	a2,0
    80003dd4:	fb040593          	addi	a1,s0,-80
    80003dd8:	8526                	mv	a0,s1
    80003dda:	d0bfe0ef          	jal	80002ae4 <dirlookup>
    80003dde:	89aa                	mv	s3,a0
    80003de0:	c131                	beqz	a0,80003e24 <create+0x80>
    iunlockput(dp);
    80003de2:	8526                	mv	a0,s1
    80003de4:	aabfe0ef          	jal	8000288e <iunlockput>
    ilock(ip);
    80003de8:	854e                	mv	a0,s3
    80003dea:	899fe0ef          	jal	80002682 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80003dee:	4789                	li	a5,2
    80003df0:	02f91563          	bne	s2,a5,80003e1a <create+0x76>
    80003df4:	0449d783          	lhu	a5,68(s3)
    80003df8:	37f9                	addiw	a5,a5,-2
    80003dfa:	17c2                	slli	a5,a5,0x30
    80003dfc:	93c1                	srli	a5,a5,0x30
    80003dfe:	4705                	li	a4,1
    80003e00:	00f76d63          	bltu	a4,a5,80003e1a <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80003e04:	854e                	mv	a0,s3
    80003e06:	60a6                	ld	ra,72(sp)
    80003e08:	6406                	ld	s0,64(sp)
    80003e0a:	74e2                	ld	s1,56(sp)
    80003e0c:	7942                	ld	s2,48(sp)
    80003e0e:	79a2                	ld	s3,40(sp)
    80003e10:	7a02                	ld	s4,32(sp)
    80003e12:	6ae2                	ld	s5,24(sp)
    80003e14:	6b42                	ld	s6,16(sp)
    80003e16:	6161                	addi	sp,sp,80
    80003e18:	8082                	ret
    iunlockput(ip);
    80003e1a:	854e                	mv	a0,s3
    80003e1c:	a73fe0ef          	jal	8000288e <iunlockput>
    return 0;
    80003e20:	4981                	li	s3,0
    80003e22:	b7cd                	j	80003e04 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80003e24:	85ca                	mv	a1,s2
    80003e26:	4088                	lw	a0,0(s1)
    80003e28:	eeafe0ef          	jal	80002512 <ialloc>
    80003e2c:	892a                	mv	s2,a0
    80003e2e:	cd15                	beqz	a0,80003e6a <create+0xc6>
  ilock(ip);
    80003e30:	853fe0ef          	jal	80002682 <ilock>
  ip->major = major;
    80003e34:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80003e38:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80003e3c:	4785                	li	a5,1
    80003e3e:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80003e42:	854a                	mv	a0,s2
    80003e44:	f8afe0ef          	jal	800025ce <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80003e48:	4705                	li	a4,1
    80003e4a:	02ea0463          	beq	s4,a4,80003e72 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80003e4e:	00492603          	lw	a2,4(s2)
    80003e52:	fb040593          	addi	a1,s0,-80
    80003e56:	8526                	mv	a0,s1
    80003e58:	e77fe0ef          	jal	80002cce <dirlink>
    80003e5c:	06054263          	bltz	a0,80003ec0 <create+0x11c>
  iunlockput(dp);
    80003e60:	8526                	mv	a0,s1
    80003e62:	a2dfe0ef          	jal	8000288e <iunlockput>
  return ip;
    80003e66:	89ca                	mv	s3,s2
    80003e68:	bf71                	j	80003e04 <create+0x60>
    iunlockput(dp);
    80003e6a:	8526                	mv	a0,s1
    80003e6c:	a23fe0ef          	jal	8000288e <iunlockput>
    return 0;
    80003e70:	bf51                	j	80003e04 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80003e72:	00492603          	lw	a2,4(s2)
    80003e76:	00004597          	auipc	a1,0x4
    80003e7a:	81258593          	addi	a1,a1,-2030 # 80007688 <etext+0x688>
    80003e7e:	854a                	mv	a0,s2
    80003e80:	e4ffe0ef          	jal	80002cce <dirlink>
    80003e84:	02054e63          	bltz	a0,80003ec0 <create+0x11c>
    80003e88:	40d0                	lw	a2,4(s1)
    80003e8a:	00004597          	auipc	a1,0x4
    80003e8e:	80658593          	addi	a1,a1,-2042 # 80007690 <etext+0x690>
    80003e92:	854a                	mv	a0,s2
    80003e94:	e3bfe0ef          	jal	80002cce <dirlink>
    80003e98:	02054463          	bltz	a0,80003ec0 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80003e9c:	00492603          	lw	a2,4(s2)
    80003ea0:	fb040593          	addi	a1,s0,-80
    80003ea4:	8526                	mv	a0,s1
    80003ea6:	e29fe0ef          	jal	80002cce <dirlink>
    80003eaa:	00054b63          	bltz	a0,80003ec0 <create+0x11c>
    dp->nlink++;  // for ".."
    80003eae:	04a4d783          	lhu	a5,74(s1)
    80003eb2:	2785                	addiw	a5,a5,1
    80003eb4:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80003eb8:	8526                	mv	a0,s1
    80003eba:	f14fe0ef          	jal	800025ce <iupdate>
    80003ebe:	b74d                	j	80003e60 <create+0xbc>
  ip->nlink = 0;
    80003ec0:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80003ec4:	854a                	mv	a0,s2
    80003ec6:	f08fe0ef          	jal	800025ce <iupdate>
  iunlockput(ip);
    80003eca:	854a                	mv	a0,s2
    80003ecc:	9c3fe0ef          	jal	8000288e <iunlockput>
  iunlockput(dp);
    80003ed0:	8526                	mv	a0,s1
    80003ed2:	9bdfe0ef          	jal	8000288e <iunlockput>
  return 0;
    80003ed6:	b73d                	j	80003e04 <create+0x60>
    return 0;
    80003ed8:	89aa                	mv	s3,a0
    80003eda:	b72d                	j	80003e04 <create+0x60>

0000000080003edc <sys_dup>:
{
    80003edc:	7179                	addi	sp,sp,-48
    80003ede:	f406                	sd	ra,40(sp)
    80003ee0:	f022                	sd	s0,32(sp)
    80003ee2:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80003ee4:	fd840613          	addi	a2,s0,-40
    80003ee8:	4581                	li	a1,0
    80003eea:	4501                	li	a0,0
    80003eec:	e1fff0ef          	jal	80003d0a <argfd>
    return -1;
    80003ef0:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80003ef2:	02054363          	bltz	a0,80003f18 <sys_dup+0x3c>
    80003ef6:	ec26                	sd	s1,24(sp)
    80003ef8:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80003efa:	fd843483          	ld	s1,-40(s0)
    80003efe:	8526                	mv	a0,s1
    80003f00:	e65ff0ef          	jal	80003d64 <fdalloc>
    80003f04:	892a                	mv	s2,a0
    return -1;
    80003f06:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80003f08:	00054d63          	bltz	a0,80003f22 <sys_dup+0x46>
  filedup(f);
    80003f0c:	8526                	mv	a0,s1
    80003f0e:	c18ff0ef          	jal	80003326 <filedup>
  return fd;
    80003f12:	87ca                	mv	a5,s2
    80003f14:	64e2                	ld	s1,24(sp)
    80003f16:	6942                	ld	s2,16(sp)
}
    80003f18:	853e                	mv	a0,a5
    80003f1a:	70a2                	ld	ra,40(sp)
    80003f1c:	7402                	ld	s0,32(sp)
    80003f1e:	6145                	addi	sp,sp,48
    80003f20:	8082                	ret
    80003f22:	64e2                	ld	s1,24(sp)
    80003f24:	6942                	ld	s2,16(sp)
    80003f26:	bfcd                	j	80003f18 <sys_dup+0x3c>

0000000080003f28 <sys_read>:
{
    80003f28:	7179                	addi	sp,sp,-48
    80003f2a:	f406                	sd	ra,40(sp)
    80003f2c:	f022                	sd	s0,32(sp)
    80003f2e:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80003f30:	fd840593          	addi	a1,s0,-40
    80003f34:	4505                	li	a0,1
    80003f36:	d19fd0ef          	jal	80001c4e <argaddr>
  argint(2, &n);
    80003f3a:	fe440593          	addi	a1,s0,-28
    80003f3e:	4509                	li	a0,2
    80003f40:	cf3fd0ef          	jal	80001c32 <argint>
  if(argfd(0, 0, &f) < 0)
    80003f44:	fe840613          	addi	a2,s0,-24
    80003f48:	4581                	li	a1,0
    80003f4a:	4501                	li	a0,0
    80003f4c:	dbfff0ef          	jal	80003d0a <argfd>
    80003f50:	87aa                	mv	a5,a0
    return -1;
    80003f52:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80003f54:	0007ca63          	bltz	a5,80003f68 <sys_read+0x40>
  return fileread(f, p, n);
    80003f58:	fe442603          	lw	a2,-28(s0)
    80003f5c:	fd843583          	ld	a1,-40(s0)
    80003f60:	fe843503          	ld	a0,-24(s0)
    80003f64:	d2cff0ef          	jal	80003490 <fileread>
}
    80003f68:	70a2                	ld	ra,40(sp)
    80003f6a:	7402                	ld	s0,32(sp)
    80003f6c:	6145                	addi	sp,sp,48
    80003f6e:	8082                	ret

0000000080003f70 <sys_write>:
{
    80003f70:	7179                	addi	sp,sp,-48
    80003f72:	f406                	sd	ra,40(sp)
    80003f74:	f022                	sd	s0,32(sp)
    80003f76:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80003f78:	fd840593          	addi	a1,s0,-40
    80003f7c:	4505                	li	a0,1
    80003f7e:	cd1fd0ef          	jal	80001c4e <argaddr>
  argint(2, &n);
    80003f82:	fe440593          	addi	a1,s0,-28
    80003f86:	4509                	li	a0,2
    80003f88:	cabfd0ef          	jal	80001c32 <argint>
  if(argfd(0, 0, &f) < 0)
    80003f8c:	fe840613          	addi	a2,s0,-24
    80003f90:	4581                	li	a1,0
    80003f92:	4501                	li	a0,0
    80003f94:	d77ff0ef          	jal	80003d0a <argfd>
    80003f98:	87aa                	mv	a5,a0
    return -1;
    80003f9a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80003f9c:	0007ca63          	bltz	a5,80003fb0 <sys_write+0x40>
  return filewrite(f, p, n);
    80003fa0:	fe442603          	lw	a2,-28(s0)
    80003fa4:	fd843583          	ld	a1,-40(s0)
    80003fa8:	fe843503          	ld	a0,-24(s0)
    80003fac:	da8ff0ef          	jal	80003554 <filewrite>
}
    80003fb0:	70a2                	ld	ra,40(sp)
    80003fb2:	7402                	ld	s0,32(sp)
    80003fb4:	6145                	addi	sp,sp,48
    80003fb6:	8082                	ret

0000000080003fb8 <sys_close>:
{
    80003fb8:	1101                	addi	sp,sp,-32
    80003fba:	ec06                	sd	ra,24(sp)
    80003fbc:	e822                	sd	s0,16(sp)
    80003fbe:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80003fc0:	fe040613          	addi	a2,s0,-32
    80003fc4:	fec40593          	addi	a1,s0,-20
    80003fc8:	4501                	li	a0,0
    80003fca:	d41ff0ef          	jal	80003d0a <argfd>
    return -1;
    80003fce:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80003fd0:	02054163          	bltz	a0,80003ff2 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80003fd4:	d97fc0ef          	jal	80000d6a <myproc>
    80003fd8:	fec42783          	lw	a5,-20(s0)
    80003fdc:	078e                	slli	a5,a5,0x3
    80003fde:	0d078793          	addi	a5,a5,208
    80003fe2:	953e                	add	a0,a0,a5
    80003fe4:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80003fe8:	fe043503          	ld	a0,-32(s0)
    80003fec:	b80ff0ef          	jal	8000336c <fileclose>
  return 0;
    80003ff0:	4781                	li	a5,0
}
    80003ff2:	853e                	mv	a0,a5
    80003ff4:	60e2                	ld	ra,24(sp)
    80003ff6:	6442                	ld	s0,16(sp)
    80003ff8:	6105                	addi	sp,sp,32
    80003ffa:	8082                	ret

0000000080003ffc <sys_fstat>:
{
    80003ffc:	1101                	addi	sp,sp,-32
    80003ffe:	ec06                	sd	ra,24(sp)
    80004000:	e822                	sd	s0,16(sp)
    80004002:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004004:	fe040593          	addi	a1,s0,-32
    80004008:	4505                	li	a0,1
    8000400a:	c45fd0ef          	jal	80001c4e <argaddr>
  if(argfd(0, 0, &f) < 0)
    8000400e:	fe840613          	addi	a2,s0,-24
    80004012:	4581                	li	a1,0
    80004014:	4501                	li	a0,0
    80004016:	cf5ff0ef          	jal	80003d0a <argfd>
    8000401a:	87aa                	mv	a5,a0
    return -1;
    8000401c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000401e:	0007c863          	bltz	a5,8000402e <sys_fstat+0x32>
  return filestat(f, st);
    80004022:	fe043583          	ld	a1,-32(s0)
    80004026:	fe843503          	ld	a0,-24(s0)
    8000402a:	c04ff0ef          	jal	8000342e <filestat>
}
    8000402e:	60e2                	ld	ra,24(sp)
    80004030:	6442                	ld	s0,16(sp)
    80004032:	6105                	addi	sp,sp,32
    80004034:	8082                	ret

0000000080004036 <sys_link>:
{
    80004036:	7169                	addi	sp,sp,-304
    80004038:	f606                	sd	ra,296(sp)
    8000403a:	f222                	sd	s0,288(sp)
    8000403c:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000403e:	08000613          	li	a2,128
    80004042:	ed040593          	addi	a1,s0,-304
    80004046:	4501                	li	a0,0
    80004048:	c23fd0ef          	jal	80001c6a <argstr>
    return -1;
    8000404c:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000404e:	0c054e63          	bltz	a0,8000412a <sys_link+0xf4>
    80004052:	08000613          	li	a2,128
    80004056:	f5040593          	addi	a1,s0,-176
    8000405a:	4505                	li	a0,1
    8000405c:	c0ffd0ef          	jal	80001c6a <argstr>
    return -1;
    80004060:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004062:	0c054463          	bltz	a0,8000412a <sys_link+0xf4>
    80004066:	ee26                	sd	s1,280(sp)
  begin_op();
    80004068:	ed3fe0ef          	jal	80002f3a <begin_op>
  if((ip = namei(old)) == 0){
    8000406c:	ed040513          	addi	a0,s0,-304
    80004070:	d09fe0ef          	jal	80002d78 <namei>
    80004074:	84aa                	mv	s1,a0
    80004076:	c53d                	beqz	a0,800040e4 <sys_link+0xae>
  ilock(ip);
    80004078:	e0afe0ef          	jal	80002682 <ilock>
  if(ip->type == T_DIR){
    8000407c:	04449703          	lh	a4,68(s1)
    80004080:	4785                	li	a5,1
    80004082:	06f70663          	beq	a4,a5,800040ee <sys_link+0xb8>
    80004086:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004088:	04a4d783          	lhu	a5,74(s1)
    8000408c:	2785                	addiw	a5,a5,1
    8000408e:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004092:	8526                	mv	a0,s1
    80004094:	d3afe0ef          	jal	800025ce <iupdate>
  iunlock(ip);
    80004098:	8526                	mv	a0,s1
    8000409a:	e96fe0ef          	jal	80002730 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    8000409e:	fd040593          	addi	a1,s0,-48
    800040a2:	f5040513          	addi	a0,s0,-176
    800040a6:	cedfe0ef          	jal	80002d92 <nameiparent>
    800040aa:	892a                	mv	s2,a0
    800040ac:	cd21                	beqz	a0,80004104 <sys_link+0xce>
  ilock(dp);
    800040ae:	dd4fe0ef          	jal	80002682 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800040b2:	854a                	mv	a0,s2
    800040b4:	00092703          	lw	a4,0(s2)
    800040b8:	409c                	lw	a5,0(s1)
    800040ba:	04f71263          	bne	a4,a5,800040fe <sys_link+0xc8>
    800040be:	40d0                	lw	a2,4(s1)
    800040c0:	fd040593          	addi	a1,s0,-48
    800040c4:	c0bfe0ef          	jal	80002cce <dirlink>
    800040c8:	02054b63          	bltz	a0,800040fe <sys_link+0xc8>
  iunlockput(dp);
    800040cc:	854a                	mv	a0,s2
    800040ce:	fc0fe0ef          	jal	8000288e <iunlockput>
  iput(ip);
    800040d2:	8526                	mv	a0,s1
    800040d4:	f30fe0ef          	jal	80002804 <iput>
  end_op();
    800040d8:	ed3fe0ef          	jal	80002faa <end_op>
  return 0;
    800040dc:	4781                	li	a5,0
    800040de:	64f2                	ld	s1,280(sp)
    800040e0:	6952                	ld	s2,272(sp)
    800040e2:	a0a1                	j	8000412a <sys_link+0xf4>
    end_op();
    800040e4:	ec7fe0ef          	jal	80002faa <end_op>
    return -1;
    800040e8:	57fd                	li	a5,-1
    800040ea:	64f2                	ld	s1,280(sp)
    800040ec:	a83d                	j	8000412a <sys_link+0xf4>
    iunlockput(ip);
    800040ee:	8526                	mv	a0,s1
    800040f0:	f9efe0ef          	jal	8000288e <iunlockput>
    end_op();
    800040f4:	eb7fe0ef          	jal	80002faa <end_op>
    return -1;
    800040f8:	57fd                	li	a5,-1
    800040fa:	64f2                	ld	s1,280(sp)
    800040fc:	a03d                	j	8000412a <sys_link+0xf4>
    iunlockput(dp);
    800040fe:	854a                	mv	a0,s2
    80004100:	f8efe0ef          	jal	8000288e <iunlockput>
  ilock(ip);
    80004104:	8526                	mv	a0,s1
    80004106:	d7cfe0ef          	jal	80002682 <ilock>
  ip->nlink--;
    8000410a:	04a4d783          	lhu	a5,74(s1)
    8000410e:	37fd                	addiw	a5,a5,-1
    80004110:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004114:	8526                	mv	a0,s1
    80004116:	cb8fe0ef          	jal	800025ce <iupdate>
  iunlockput(ip);
    8000411a:	8526                	mv	a0,s1
    8000411c:	f72fe0ef          	jal	8000288e <iunlockput>
  end_op();
    80004120:	e8bfe0ef          	jal	80002faa <end_op>
  return -1;
    80004124:	57fd                	li	a5,-1
    80004126:	64f2                	ld	s1,280(sp)
    80004128:	6952                	ld	s2,272(sp)
}
    8000412a:	853e                	mv	a0,a5
    8000412c:	70b2                	ld	ra,296(sp)
    8000412e:	7412                	ld	s0,288(sp)
    80004130:	6155                	addi	sp,sp,304
    80004132:	8082                	ret

0000000080004134 <sys_unlink>:
{
    80004134:	7151                	addi	sp,sp,-240
    80004136:	f586                	sd	ra,232(sp)
    80004138:	f1a2                	sd	s0,224(sp)
    8000413a:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000413c:	08000613          	li	a2,128
    80004140:	f3040593          	addi	a1,s0,-208
    80004144:	4501                	li	a0,0
    80004146:	b25fd0ef          	jal	80001c6a <argstr>
    8000414a:	14054d63          	bltz	a0,800042a4 <sys_unlink+0x170>
    8000414e:	eda6                	sd	s1,216(sp)
  begin_op();
    80004150:	debfe0ef          	jal	80002f3a <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004154:	fb040593          	addi	a1,s0,-80
    80004158:	f3040513          	addi	a0,s0,-208
    8000415c:	c37fe0ef          	jal	80002d92 <nameiparent>
    80004160:	84aa                	mv	s1,a0
    80004162:	c955                	beqz	a0,80004216 <sys_unlink+0xe2>
  ilock(dp);
    80004164:	d1efe0ef          	jal	80002682 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004168:	00003597          	auipc	a1,0x3
    8000416c:	52058593          	addi	a1,a1,1312 # 80007688 <etext+0x688>
    80004170:	fb040513          	addi	a0,s0,-80
    80004174:	95bfe0ef          	jal	80002ace <namecmp>
    80004178:	10050b63          	beqz	a0,8000428e <sys_unlink+0x15a>
    8000417c:	00003597          	auipc	a1,0x3
    80004180:	51458593          	addi	a1,a1,1300 # 80007690 <etext+0x690>
    80004184:	fb040513          	addi	a0,s0,-80
    80004188:	947fe0ef          	jal	80002ace <namecmp>
    8000418c:	10050163          	beqz	a0,8000428e <sys_unlink+0x15a>
    80004190:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004192:	f2c40613          	addi	a2,s0,-212
    80004196:	fb040593          	addi	a1,s0,-80
    8000419a:	8526                	mv	a0,s1
    8000419c:	949fe0ef          	jal	80002ae4 <dirlookup>
    800041a0:	892a                	mv	s2,a0
    800041a2:	0e050563          	beqz	a0,8000428c <sys_unlink+0x158>
    800041a6:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800041a8:	cdafe0ef          	jal	80002682 <ilock>
  if(ip->nlink < 1)
    800041ac:	04a91783          	lh	a5,74(s2)
    800041b0:	06f05863          	blez	a5,80004220 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800041b4:	04491703          	lh	a4,68(s2)
    800041b8:	4785                	li	a5,1
    800041ba:	06f70963          	beq	a4,a5,8000422c <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    800041be:	fc040993          	addi	s3,s0,-64
    800041c2:	4641                	li	a2,16
    800041c4:	4581                	li	a1,0
    800041c6:	854e                	mv	a0,s3
    800041c8:	f77fb0ef          	jal	8000013e <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800041cc:	4741                	li	a4,16
    800041ce:	f2c42683          	lw	a3,-212(s0)
    800041d2:	864e                	mv	a2,s3
    800041d4:	4581                	li	a1,0
    800041d6:	8526                	mv	a0,s1
    800041d8:	ff6fe0ef          	jal	800029ce <writei>
    800041dc:	47c1                	li	a5,16
    800041de:	08f51863          	bne	a0,a5,8000426e <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    800041e2:	04491703          	lh	a4,68(s2)
    800041e6:	4785                	li	a5,1
    800041e8:	08f70963          	beq	a4,a5,8000427a <sys_unlink+0x146>
  iunlockput(dp);
    800041ec:	8526                	mv	a0,s1
    800041ee:	ea0fe0ef          	jal	8000288e <iunlockput>
  ip->nlink--;
    800041f2:	04a95783          	lhu	a5,74(s2)
    800041f6:	37fd                	addiw	a5,a5,-1
    800041f8:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800041fc:	854a                	mv	a0,s2
    800041fe:	bd0fe0ef          	jal	800025ce <iupdate>
  iunlockput(ip);
    80004202:	854a                	mv	a0,s2
    80004204:	e8afe0ef          	jal	8000288e <iunlockput>
  end_op();
    80004208:	da3fe0ef          	jal	80002faa <end_op>
  return 0;
    8000420c:	4501                	li	a0,0
    8000420e:	64ee                	ld	s1,216(sp)
    80004210:	694e                	ld	s2,208(sp)
    80004212:	69ae                	ld	s3,200(sp)
    80004214:	a061                	j	8000429c <sys_unlink+0x168>
    end_op();
    80004216:	d95fe0ef          	jal	80002faa <end_op>
    return -1;
    8000421a:	557d                	li	a0,-1
    8000421c:	64ee                	ld	s1,216(sp)
    8000421e:	a8bd                	j	8000429c <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004220:	00003517          	auipc	a0,0x3
    80004224:	47850513          	addi	a0,a0,1144 # 80007698 <etext+0x698>
    80004228:	2a6010ef          	jal	800054ce <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000422c:	04c92703          	lw	a4,76(s2)
    80004230:	02000793          	li	a5,32
    80004234:	f8e7f5e3          	bgeu	a5,a4,800041be <sys_unlink+0x8a>
    80004238:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000423a:	4741                	li	a4,16
    8000423c:	86ce                	mv	a3,s3
    8000423e:	f1840613          	addi	a2,s0,-232
    80004242:	4581                	li	a1,0
    80004244:	854a                	mv	a0,s2
    80004246:	e96fe0ef          	jal	800028dc <readi>
    8000424a:	47c1                	li	a5,16
    8000424c:	00f51b63          	bne	a0,a5,80004262 <sys_unlink+0x12e>
    if(de.inum != 0)
    80004250:	f1845783          	lhu	a5,-232(s0)
    80004254:	ebb1                	bnez	a5,800042a8 <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004256:	29c1                	addiw	s3,s3,16
    80004258:	04c92783          	lw	a5,76(s2)
    8000425c:	fcf9efe3          	bltu	s3,a5,8000423a <sys_unlink+0x106>
    80004260:	bfb9                	j	800041be <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004262:	00003517          	auipc	a0,0x3
    80004266:	44e50513          	addi	a0,a0,1102 # 800076b0 <etext+0x6b0>
    8000426a:	264010ef          	jal	800054ce <panic>
    panic("unlink: writei");
    8000426e:	00003517          	auipc	a0,0x3
    80004272:	45a50513          	addi	a0,a0,1114 # 800076c8 <etext+0x6c8>
    80004276:	258010ef          	jal	800054ce <panic>
    dp->nlink--;
    8000427a:	04a4d783          	lhu	a5,74(s1)
    8000427e:	37fd                	addiw	a5,a5,-1
    80004280:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004284:	8526                	mv	a0,s1
    80004286:	b48fe0ef          	jal	800025ce <iupdate>
    8000428a:	b78d                	j	800041ec <sys_unlink+0xb8>
    8000428c:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    8000428e:	8526                	mv	a0,s1
    80004290:	dfefe0ef          	jal	8000288e <iunlockput>
  end_op();
    80004294:	d17fe0ef          	jal	80002faa <end_op>
  return -1;
    80004298:	557d                	li	a0,-1
    8000429a:	64ee                	ld	s1,216(sp)
}
    8000429c:	70ae                	ld	ra,232(sp)
    8000429e:	740e                	ld	s0,224(sp)
    800042a0:	616d                	addi	sp,sp,240
    800042a2:	8082                	ret
    return -1;
    800042a4:	557d                	li	a0,-1
    800042a6:	bfdd                	j	8000429c <sys_unlink+0x168>
    iunlockput(ip);
    800042a8:	854a                	mv	a0,s2
    800042aa:	de4fe0ef          	jal	8000288e <iunlockput>
    goto bad;
    800042ae:	694e                	ld	s2,208(sp)
    800042b0:	69ae                	ld	s3,200(sp)
    800042b2:	bff1                	j	8000428e <sys_unlink+0x15a>

00000000800042b4 <sys_open>:

uint64
sys_open(void)
{
    800042b4:	7131                	addi	sp,sp,-192
    800042b6:	fd06                	sd	ra,184(sp)
    800042b8:	f922                	sd	s0,176(sp)
    800042ba:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800042bc:	f4c40593          	addi	a1,s0,-180
    800042c0:	4505                	li	a0,1
    800042c2:	971fd0ef          	jal	80001c32 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800042c6:	08000613          	li	a2,128
    800042ca:	f5040593          	addi	a1,s0,-176
    800042ce:	4501                	li	a0,0
    800042d0:	99bfd0ef          	jal	80001c6a <argstr>
    800042d4:	87aa                	mv	a5,a0
    return -1;
    800042d6:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800042d8:	0a07c363          	bltz	a5,8000437e <sys_open+0xca>
    800042dc:	f526                	sd	s1,168(sp)

  begin_op();
    800042de:	c5dfe0ef          	jal	80002f3a <begin_op>

  if(omode & O_CREATE){
    800042e2:	f4c42783          	lw	a5,-180(s0)
    800042e6:	2007f793          	andi	a5,a5,512
    800042ea:	c3dd                	beqz	a5,80004390 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    800042ec:	4681                	li	a3,0
    800042ee:	4601                	li	a2,0
    800042f0:	4589                	li	a1,2
    800042f2:	f5040513          	addi	a0,s0,-176
    800042f6:	aafff0ef          	jal	80003da4 <create>
    800042fa:	84aa                	mv	s1,a0
    if(ip == 0){
    800042fc:	c549                	beqz	a0,80004386 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800042fe:	04449703          	lh	a4,68(s1)
    80004302:	478d                	li	a5,3
    80004304:	00f71763          	bne	a4,a5,80004312 <sys_open+0x5e>
    80004308:	0464d703          	lhu	a4,70(s1)
    8000430c:	47a5                	li	a5,9
    8000430e:	0ae7ee63          	bltu	a5,a4,800043ca <sys_open+0x116>
    80004312:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004314:	fb5fe0ef          	jal	800032c8 <filealloc>
    80004318:	892a                	mv	s2,a0
    8000431a:	c561                	beqz	a0,800043e2 <sys_open+0x12e>
    8000431c:	ed4e                	sd	s3,152(sp)
    8000431e:	a47ff0ef          	jal	80003d64 <fdalloc>
    80004322:	89aa                	mv	s3,a0
    80004324:	0a054b63          	bltz	a0,800043da <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004328:	04449703          	lh	a4,68(s1)
    8000432c:	478d                	li	a5,3
    8000432e:	0cf70363          	beq	a4,a5,800043f4 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004332:	4789                	li	a5,2
    80004334:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004338:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    8000433c:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004340:	f4c42783          	lw	a5,-180(s0)
    80004344:	0017f713          	andi	a4,a5,1
    80004348:	00174713          	xori	a4,a4,1
    8000434c:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004350:	0037f713          	andi	a4,a5,3
    80004354:	00e03733          	snez	a4,a4
    80004358:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000435c:	4007f793          	andi	a5,a5,1024
    80004360:	c791                	beqz	a5,8000436c <sys_open+0xb8>
    80004362:	04449703          	lh	a4,68(s1)
    80004366:	4789                	li	a5,2
    80004368:	08f70d63          	beq	a4,a5,80004402 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    8000436c:	8526                	mv	a0,s1
    8000436e:	bc2fe0ef          	jal	80002730 <iunlock>
  end_op();
    80004372:	c39fe0ef          	jal	80002faa <end_op>

  return fd;
    80004376:	854e                	mv	a0,s3
    80004378:	74aa                	ld	s1,168(sp)
    8000437a:	790a                	ld	s2,160(sp)
    8000437c:	69ea                	ld	s3,152(sp)
}
    8000437e:	70ea                	ld	ra,184(sp)
    80004380:	744a                	ld	s0,176(sp)
    80004382:	6129                	addi	sp,sp,192
    80004384:	8082                	ret
      end_op();
    80004386:	c25fe0ef          	jal	80002faa <end_op>
      return -1;
    8000438a:	557d                	li	a0,-1
    8000438c:	74aa                	ld	s1,168(sp)
    8000438e:	bfc5                	j	8000437e <sys_open+0xca>
    if((ip = namei(path)) == 0){
    80004390:	f5040513          	addi	a0,s0,-176
    80004394:	9e5fe0ef          	jal	80002d78 <namei>
    80004398:	84aa                	mv	s1,a0
    8000439a:	c11d                	beqz	a0,800043c0 <sys_open+0x10c>
    ilock(ip);
    8000439c:	ae6fe0ef          	jal	80002682 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800043a0:	04449703          	lh	a4,68(s1)
    800043a4:	4785                	li	a5,1
    800043a6:	f4f71ce3          	bne	a4,a5,800042fe <sys_open+0x4a>
    800043aa:	f4c42783          	lw	a5,-180(s0)
    800043ae:	d3b5                	beqz	a5,80004312 <sys_open+0x5e>
      iunlockput(ip);
    800043b0:	8526                	mv	a0,s1
    800043b2:	cdcfe0ef          	jal	8000288e <iunlockput>
      end_op();
    800043b6:	bf5fe0ef          	jal	80002faa <end_op>
      return -1;
    800043ba:	557d                	li	a0,-1
    800043bc:	74aa                	ld	s1,168(sp)
    800043be:	b7c1                	j	8000437e <sys_open+0xca>
      end_op();
    800043c0:	bebfe0ef          	jal	80002faa <end_op>
      return -1;
    800043c4:	557d                	li	a0,-1
    800043c6:	74aa                	ld	s1,168(sp)
    800043c8:	bf5d                	j	8000437e <sys_open+0xca>
    iunlockput(ip);
    800043ca:	8526                	mv	a0,s1
    800043cc:	cc2fe0ef          	jal	8000288e <iunlockput>
    end_op();
    800043d0:	bdbfe0ef          	jal	80002faa <end_op>
    return -1;
    800043d4:	557d                	li	a0,-1
    800043d6:	74aa                	ld	s1,168(sp)
    800043d8:	b75d                	j	8000437e <sys_open+0xca>
      fileclose(f);
    800043da:	854a                	mv	a0,s2
    800043dc:	f91fe0ef          	jal	8000336c <fileclose>
    800043e0:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    800043e2:	8526                	mv	a0,s1
    800043e4:	caafe0ef          	jal	8000288e <iunlockput>
    end_op();
    800043e8:	bc3fe0ef          	jal	80002faa <end_op>
    return -1;
    800043ec:	557d                	li	a0,-1
    800043ee:	74aa                	ld	s1,168(sp)
    800043f0:	790a                	ld	s2,160(sp)
    800043f2:	b771                	j	8000437e <sys_open+0xca>
    f->type = FD_DEVICE;
    800043f4:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800043f8:	04649783          	lh	a5,70(s1)
    800043fc:	02f91223          	sh	a5,36(s2)
    80004400:	bf35                	j	8000433c <sys_open+0x88>
    itrunc(ip);
    80004402:	8526                	mv	a0,s1
    80004404:	b6cfe0ef          	jal	80002770 <itrunc>
    80004408:	b795                	j	8000436c <sys_open+0xb8>

000000008000440a <sys_mkdir>:

uint64
sys_mkdir(void)
{
    8000440a:	7175                	addi	sp,sp,-144
    8000440c:	e506                	sd	ra,136(sp)
    8000440e:	e122                	sd	s0,128(sp)
    80004410:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004412:	b29fe0ef          	jal	80002f3a <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80004416:	08000613          	li	a2,128
    8000441a:	f7040593          	addi	a1,s0,-144
    8000441e:	4501                	li	a0,0
    80004420:	84bfd0ef          	jal	80001c6a <argstr>
    80004424:	02054363          	bltz	a0,8000444a <sys_mkdir+0x40>
    80004428:	4681                	li	a3,0
    8000442a:	4601                	li	a2,0
    8000442c:	4585                	li	a1,1
    8000442e:	f7040513          	addi	a0,s0,-144
    80004432:	973ff0ef          	jal	80003da4 <create>
    80004436:	c911                	beqz	a0,8000444a <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004438:	c56fe0ef          	jal	8000288e <iunlockput>
  end_op();
    8000443c:	b6ffe0ef          	jal	80002faa <end_op>
  return 0;
    80004440:	4501                	li	a0,0
}
    80004442:	60aa                	ld	ra,136(sp)
    80004444:	640a                	ld	s0,128(sp)
    80004446:	6149                	addi	sp,sp,144
    80004448:	8082                	ret
    end_op();
    8000444a:	b61fe0ef          	jal	80002faa <end_op>
    return -1;
    8000444e:	557d                	li	a0,-1
    80004450:	bfcd                	j	80004442 <sys_mkdir+0x38>

0000000080004452 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004452:	7135                	addi	sp,sp,-160
    80004454:	ed06                	sd	ra,152(sp)
    80004456:	e922                	sd	s0,144(sp)
    80004458:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000445a:	ae1fe0ef          	jal	80002f3a <begin_op>
  argint(1, &major);
    8000445e:	f6c40593          	addi	a1,s0,-148
    80004462:	4505                	li	a0,1
    80004464:	fcefd0ef          	jal	80001c32 <argint>
  argint(2, &minor);
    80004468:	f6840593          	addi	a1,s0,-152
    8000446c:	4509                	li	a0,2
    8000446e:	fc4fd0ef          	jal	80001c32 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004472:	08000613          	li	a2,128
    80004476:	f7040593          	addi	a1,s0,-144
    8000447a:	4501                	li	a0,0
    8000447c:	feefd0ef          	jal	80001c6a <argstr>
    80004480:	02054563          	bltz	a0,800044aa <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004484:	f6841683          	lh	a3,-152(s0)
    80004488:	f6c41603          	lh	a2,-148(s0)
    8000448c:	458d                	li	a1,3
    8000448e:	f7040513          	addi	a0,s0,-144
    80004492:	913ff0ef          	jal	80003da4 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004496:	c911                	beqz	a0,800044aa <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004498:	bf6fe0ef          	jal	8000288e <iunlockput>
  end_op();
    8000449c:	b0ffe0ef          	jal	80002faa <end_op>
  return 0;
    800044a0:	4501                	li	a0,0
}
    800044a2:	60ea                	ld	ra,152(sp)
    800044a4:	644a                	ld	s0,144(sp)
    800044a6:	610d                	addi	sp,sp,160
    800044a8:	8082                	ret
    end_op();
    800044aa:	b01fe0ef          	jal	80002faa <end_op>
    return -1;
    800044ae:	557d                	li	a0,-1
    800044b0:	bfcd                	j	800044a2 <sys_mknod+0x50>

00000000800044b2 <sys_chdir>:

uint64
sys_chdir(void)
{
    800044b2:	7135                	addi	sp,sp,-160
    800044b4:	ed06                	sd	ra,152(sp)
    800044b6:	e922                	sd	s0,144(sp)
    800044b8:	e14a                	sd	s2,128(sp)
    800044ba:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800044bc:	8affc0ef          	jal	80000d6a <myproc>
    800044c0:	892a                	mv	s2,a0
  
  begin_op();
    800044c2:	a79fe0ef          	jal	80002f3a <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800044c6:	08000613          	li	a2,128
    800044ca:	f6040593          	addi	a1,s0,-160
    800044ce:	4501                	li	a0,0
    800044d0:	f9afd0ef          	jal	80001c6a <argstr>
    800044d4:	04054363          	bltz	a0,8000451a <sys_chdir+0x68>
    800044d8:	e526                	sd	s1,136(sp)
    800044da:	f6040513          	addi	a0,s0,-160
    800044de:	89bfe0ef          	jal	80002d78 <namei>
    800044e2:	84aa                	mv	s1,a0
    800044e4:	c915                	beqz	a0,80004518 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800044e6:	99cfe0ef          	jal	80002682 <ilock>
  if(ip->type != T_DIR){
    800044ea:	04449703          	lh	a4,68(s1)
    800044ee:	4785                	li	a5,1
    800044f0:	02f71963          	bne	a4,a5,80004522 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800044f4:	8526                	mv	a0,s1
    800044f6:	a3afe0ef          	jal	80002730 <iunlock>
  iput(p->cwd);
    800044fa:	15093503          	ld	a0,336(s2)
    800044fe:	b06fe0ef          	jal	80002804 <iput>
  end_op();
    80004502:	aa9fe0ef          	jal	80002faa <end_op>
  p->cwd = ip;
    80004506:	14993823          	sd	s1,336(s2)
  return 0;
    8000450a:	4501                	li	a0,0
    8000450c:	64aa                	ld	s1,136(sp)
}
    8000450e:	60ea                	ld	ra,152(sp)
    80004510:	644a                	ld	s0,144(sp)
    80004512:	690a                	ld	s2,128(sp)
    80004514:	610d                	addi	sp,sp,160
    80004516:	8082                	ret
    80004518:	64aa                	ld	s1,136(sp)
    end_op();
    8000451a:	a91fe0ef          	jal	80002faa <end_op>
    return -1;
    8000451e:	557d                	li	a0,-1
    80004520:	b7fd                	j	8000450e <sys_chdir+0x5c>
    iunlockput(ip);
    80004522:	8526                	mv	a0,s1
    80004524:	b6afe0ef          	jal	8000288e <iunlockput>
    end_op();
    80004528:	a83fe0ef          	jal	80002faa <end_op>
    return -1;
    8000452c:	557d                	li	a0,-1
    8000452e:	64aa                	ld	s1,136(sp)
    80004530:	bff9                	j	8000450e <sys_chdir+0x5c>

0000000080004532 <sys_exec>:

uint64
sys_exec(void)
{
    80004532:	7105                	addi	sp,sp,-480
    80004534:	ef86                	sd	ra,472(sp)
    80004536:	eba2                	sd	s0,464(sp)
    80004538:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000453a:	e2840593          	addi	a1,s0,-472
    8000453e:	4505                	li	a0,1
    80004540:	f0efd0ef          	jal	80001c4e <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80004544:	08000613          	li	a2,128
    80004548:	f3040593          	addi	a1,s0,-208
    8000454c:	4501                	li	a0,0
    8000454e:	f1cfd0ef          	jal	80001c6a <argstr>
    80004552:	87aa                	mv	a5,a0
    return -1;
    80004554:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80004556:	0e07c063          	bltz	a5,80004636 <sys_exec+0x104>
    8000455a:	e7a6                	sd	s1,456(sp)
    8000455c:	e3ca                	sd	s2,448(sp)
    8000455e:	ff4e                	sd	s3,440(sp)
    80004560:	fb52                	sd	s4,432(sp)
    80004562:	f756                	sd	s5,424(sp)
    80004564:	f35a                	sd	s6,416(sp)
    80004566:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    80004568:	e3040a13          	addi	s4,s0,-464
    8000456c:	10000613          	li	a2,256
    80004570:	4581                	li	a1,0
    80004572:	8552                	mv	a0,s4
    80004574:	bcbfb0ef          	jal	8000013e <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80004578:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    8000457a:	89d2                	mv	s3,s4
    8000457c:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000457e:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80004582:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    80004584:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004588:	00391513          	slli	a0,s2,0x3
    8000458c:	85d6                	mv	a1,s5
    8000458e:	e2843783          	ld	a5,-472(s0)
    80004592:	953e                	add	a0,a0,a5
    80004594:	e14fd0ef          	jal	80001ba8 <fetchaddr>
    80004598:	02054663          	bltz	a0,800045c4 <sys_exec+0x92>
    if(uarg == 0){
    8000459c:	e2043783          	ld	a5,-480(s0)
    800045a0:	c7a1                	beqz	a5,800045e8 <sys_exec+0xb6>
    argv[i] = kalloc();
    800045a2:	b5bfb0ef          	jal	800000fc <kalloc>
    800045a6:	85aa                	mv	a1,a0
    800045a8:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800045ac:	cd01                	beqz	a0,800045c4 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800045ae:	865a                	mv	a2,s6
    800045b0:	e2043503          	ld	a0,-480(s0)
    800045b4:	e3efd0ef          	jal	80001bf2 <fetchstr>
    800045b8:	00054663          	bltz	a0,800045c4 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    800045bc:	0905                	addi	s2,s2,1
    800045be:	09a1                	addi	s3,s3,8
    800045c0:	fd7914e3          	bne	s2,s7,80004588 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800045c4:	100a0a13          	addi	s4,s4,256
    800045c8:	6088                	ld	a0,0(s1)
    800045ca:	cd31                	beqz	a0,80004626 <sys_exec+0xf4>
    kfree(argv[i]);
    800045cc:	a51fb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800045d0:	04a1                	addi	s1,s1,8
    800045d2:	ff449be3          	bne	s1,s4,800045c8 <sys_exec+0x96>
  return -1;
    800045d6:	557d                	li	a0,-1
    800045d8:	64be                	ld	s1,456(sp)
    800045da:	691e                	ld	s2,448(sp)
    800045dc:	79fa                	ld	s3,440(sp)
    800045de:	7a5a                	ld	s4,432(sp)
    800045e0:	7aba                	ld	s5,424(sp)
    800045e2:	7b1a                	ld	s6,416(sp)
    800045e4:	6bfa                	ld	s7,408(sp)
    800045e6:	a881                	j	80004636 <sys_exec+0x104>
      argv[i] = 0;
    800045e8:	0009079b          	sext.w	a5,s2
    800045ec:	e3040593          	addi	a1,s0,-464
    800045f0:	078e                	slli	a5,a5,0x3
    800045f2:	97ae                	add	a5,a5,a1
    800045f4:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    800045f8:	f3040513          	addi	a0,s0,-208
    800045fc:	bb2ff0ef          	jal	800039ae <exec>
    80004600:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004602:	100a0a13          	addi	s4,s4,256
    80004606:	6088                	ld	a0,0(s1)
    80004608:	c511                	beqz	a0,80004614 <sys_exec+0xe2>
    kfree(argv[i]);
    8000460a:	a13fb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000460e:	04a1                	addi	s1,s1,8
    80004610:	ff449be3          	bne	s1,s4,80004606 <sys_exec+0xd4>
  return ret;
    80004614:	854a                	mv	a0,s2
    80004616:	64be                	ld	s1,456(sp)
    80004618:	691e                	ld	s2,448(sp)
    8000461a:	79fa                	ld	s3,440(sp)
    8000461c:	7a5a                	ld	s4,432(sp)
    8000461e:	7aba                	ld	s5,424(sp)
    80004620:	7b1a                	ld	s6,416(sp)
    80004622:	6bfa                	ld	s7,408(sp)
    80004624:	a809                	j	80004636 <sys_exec+0x104>
  return -1;
    80004626:	557d                	li	a0,-1
    80004628:	64be                	ld	s1,456(sp)
    8000462a:	691e                	ld	s2,448(sp)
    8000462c:	79fa                	ld	s3,440(sp)
    8000462e:	7a5a                	ld	s4,432(sp)
    80004630:	7aba                	ld	s5,424(sp)
    80004632:	7b1a                	ld	s6,416(sp)
    80004634:	6bfa                	ld	s7,408(sp)
}
    80004636:	60fe                	ld	ra,472(sp)
    80004638:	645e                	ld	s0,464(sp)
    8000463a:	613d                	addi	sp,sp,480
    8000463c:	8082                	ret

000000008000463e <sys_pipe>:

uint64
sys_pipe(void)
{
    8000463e:	7139                	addi	sp,sp,-64
    80004640:	fc06                	sd	ra,56(sp)
    80004642:	f822                	sd	s0,48(sp)
    80004644:	f426                	sd	s1,40(sp)
    80004646:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80004648:	f22fc0ef          	jal	80000d6a <myproc>
    8000464c:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000464e:	fd840593          	addi	a1,s0,-40
    80004652:	4501                	li	a0,0
    80004654:	dfafd0ef          	jal	80001c4e <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80004658:	fc840593          	addi	a1,s0,-56
    8000465c:	fd040513          	addi	a0,s0,-48
    80004660:	828ff0ef          	jal	80003688 <pipealloc>
    return -1;
    80004664:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80004666:	0a054763          	bltz	a0,80004714 <sys_pipe+0xd6>
  fd0 = -1;
    8000466a:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000466e:	fd043503          	ld	a0,-48(s0)
    80004672:	ef2ff0ef          	jal	80003d64 <fdalloc>
    80004676:	fca42223          	sw	a0,-60(s0)
    8000467a:	08054463          	bltz	a0,80004702 <sys_pipe+0xc4>
    8000467e:	fc843503          	ld	a0,-56(s0)
    80004682:	ee2ff0ef          	jal	80003d64 <fdalloc>
    80004686:	fca42023          	sw	a0,-64(s0)
    8000468a:	06054263          	bltz	a0,800046ee <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000468e:	4691                	li	a3,4
    80004690:	fc440613          	addi	a2,s0,-60
    80004694:	fd843583          	ld	a1,-40(s0)
    80004698:	68a8                	ld	a0,80(s1)
    8000469a:	b50fc0ef          	jal	800009ea <copyout>
    8000469e:	00054e63          	bltz	a0,800046ba <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800046a2:	4691                	li	a3,4
    800046a4:	fc040613          	addi	a2,s0,-64
    800046a8:	fd843583          	ld	a1,-40(s0)
    800046ac:	95b6                	add	a1,a1,a3
    800046ae:	68a8                	ld	a0,80(s1)
    800046b0:	b3afc0ef          	jal	800009ea <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800046b4:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800046b6:	04055f63          	bgez	a0,80004714 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    800046ba:	fc442783          	lw	a5,-60(s0)
    800046be:	078e                	slli	a5,a5,0x3
    800046c0:	0d078793          	addi	a5,a5,208
    800046c4:	97a6                	add	a5,a5,s1
    800046c6:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800046ca:	fc042783          	lw	a5,-64(s0)
    800046ce:	078e                	slli	a5,a5,0x3
    800046d0:	0d078793          	addi	a5,a5,208
    800046d4:	97a6                	add	a5,a5,s1
    800046d6:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800046da:	fd043503          	ld	a0,-48(s0)
    800046de:	c8ffe0ef          	jal	8000336c <fileclose>
    fileclose(wf);
    800046e2:	fc843503          	ld	a0,-56(s0)
    800046e6:	c87fe0ef          	jal	8000336c <fileclose>
    return -1;
    800046ea:	57fd                	li	a5,-1
    800046ec:	a025                	j	80004714 <sys_pipe+0xd6>
    if(fd0 >= 0)
    800046ee:	fc442783          	lw	a5,-60(s0)
    800046f2:	0007c863          	bltz	a5,80004702 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    800046f6:	078e                	slli	a5,a5,0x3
    800046f8:	0d078793          	addi	a5,a5,208
    800046fc:	97a6                	add	a5,a5,s1
    800046fe:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80004702:	fd043503          	ld	a0,-48(s0)
    80004706:	c67fe0ef          	jal	8000336c <fileclose>
    fileclose(wf);
    8000470a:	fc843503          	ld	a0,-56(s0)
    8000470e:	c5ffe0ef          	jal	8000336c <fileclose>
    return -1;
    80004712:	57fd                	li	a5,-1
}
    80004714:	853e                	mv	a0,a5
    80004716:	70e2                	ld	ra,56(sp)
    80004718:	7442                	ld	s0,48(sp)
    8000471a:	74a2                	ld	s1,40(sp)
    8000471c:	6121                	addi	sp,sp,64
    8000471e:	8082                	ret

0000000080004720 <kernelvec>:
    80004720:	7111                	addi	sp,sp,-256
    80004722:	e006                	sd	ra,0(sp)
    80004724:	e40a                	sd	sp,8(sp)
    80004726:	e80e                	sd	gp,16(sp)
    80004728:	ec12                	sd	tp,24(sp)
    8000472a:	f016                	sd	t0,32(sp)
    8000472c:	f41a                	sd	t1,40(sp)
    8000472e:	f81e                	sd	t2,48(sp)
    80004730:	e4aa                	sd	a0,72(sp)
    80004732:	e8ae                	sd	a1,80(sp)
    80004734:	ecb2                	sd	a2,88(sp)
    80004736:	f0b6                	sd	a3,96(sp)
    80004738:	f4ba                	sd	a4,104(sp)
    8000473a:	f8be                	sd	a5,112(sp)
    8000473c:	fcc2                	sd	a6,120(sp)
    8000473e:	e146                	sd	a7,128(sp)
    80004740:	edf2                	sd	t3,216(sp)
    80004742:	f1f6                	sd	t4,224(sp)
    80004744:	f5fa                	sd	t5,232(sp)
    80004746:	f9fe                	sd	t6,240(sp)
    80004748:	b6efd0ef          	jal	80001ab6 <kerneltrap>
    8000474c:	6082                	ld	ra,0(sp)
    8000474e:	6122                	ld	sp,8(sp)
    80004750:	61c2                	ld	gp,16(sp)
    80004752:	7282                	ld	t0,32(sp)
    80004754:	7322                	ld	t1,40(sp)
    80004756:	73c2                	ld	t2,48(sp)
    80004758:	6526                	ld	a0,72(sp)
    8000475a:	65c6                	ld	a1,80(sp)
    8000475c:	6666                	ld	a2,88(sp)
    8000475e:	7686                	ld	a3,96(sp)
    80004760:	7726                	ld	a4,104(sp)
    80004762:	77c6                	ld	a5,112(sp)
    80004764:	7866                	ld	a6,120(sp)
    80004766:	688a                	ld	a7,128(sp)
    80004768:	6e6e                	ld	t3,216(sp)
    8000476a:	7e8e                	ld	t4,224(sp)
    8000476c:	7f2e                	ld	t5,232(sp)
    8000476e:	7fce                	ld	t6,240(sp)
    80004770:	6111                	addi	sp,sp,256
    80004772:	10200073          	sret
    80004776:	00000013          	nop
    8000477a:	00000013          	nop

000000008000477e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000477e:	1141                	addi	sp,sp,-16
    80004780:	e406                	sd	ra,8(sp)
    80004782:	e022                	sd	s0,0(sp)
    80004784:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004786:	0c000737          	lui	a4,0xc000
    8000478a:	4785                	li	a5,1
    8000478c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000478e:	c35c                	sw	a5,4(a4)
}
    80004790:	60a2                	ld	ra,8(sp)
    80004792:	6402                	ld	s0,0(sp)
    80004794:	0141                	addi	sp,sp,16
    80004796:	8082                	ret

0000000080004798 <plicinithart>:

void
plicinithart(void)
{
    80004798:	1141                	addi	sp,sp,-16
    8000479a:	e406                	sd	ra,8(sp)
    8000479c:	e022                	sd	s0,0(sp)
    8000479e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800047a0:	d96fc0ef          	jal	80000d36 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800047a4:	0085171b          	slliw	a4,a0,0x8
    800047a8:	0c0027b7          	lui	a5,0xc002
    800047ac:	97ba                	add	a5,a5,a4
    800047ae:	40200713          	li	a4,1026
    800047b2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800047b6:	00d5151b          	slliw	a0,a0,0xd
    800047ba:	0c2017b7          	lui	a5,0xc201
    800047be:	97aa                	add	a5,a5,a0
    800047c0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800047c4:	60a2                	ld	ra,8(sp)
    800047c6:	6402                	ld	s0,0(sp)
    800047c8:	0141                	addi	sp,sp,16
    800047ca:	8082                	ret

00000000800047cc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800047cc:	1141                	addi	sp,sp,-16
    800047ce:	e406                	sd	ra,8(sp)
    800047d0:	e022                	sd	s0,0(sp)
    800047d2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800047d4:	d62fc0ef          	jal	80000d36 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800047d8:	00d5151b          	slliw	a0,a0,0xd
    800047dc:	0c2017b7          	lui	a5,0xc201
    800047e0:	97aa                	add	a5,a5,a0
  return irq;
}
    800047e2:	43c8                	lw	a0,4(a5)
    800047e4:	60a2                	ld	ra,8(sp)
    800047e6:	6402                	ld	s0,0(sp)
    800047e8:	0141                	addi	sp,sp,16
    800047ea:	8082                	ret

00000000800047ec <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800047ec:	1101                	addi	sp,sp,-32
    800047ee:	ec06                	sd	ra,24(sp)
    800047f0:	e822                	sd	s0,16(sp)
    800047f2:	e426                	sd	s1,8(sp)
    800047f4:	1000                	addi	s0,sp,32
    800047f6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800047f8:	d3efc0ef          	jal	80000d36 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800047fc:	00d5179b          	slliw	a5,a0,0xd
    80004800:	0c201737          	lui	a4,0xc201
    80004804:	97ba                	add	a5,a5,a4
    80004806:	c3c4                	sw	s1,4(a5)
}
    80004808:	60e2                	ld	ra,24(sp)
    8000480a:	6442                	ld	s0,16(sp)
    8000480c:	64a2                	ld	s1,8(sp)
    8000480e:	6105                	addi	sp,sp,32
    80004810:	8082                	ret

0000000080004812 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80004812:	1141                	addi	sp,sp,-16
    80004814:	e406                	sd	ra,8(sp)
    80004816:	e022                	sd	s0,0(sp)
    80004818:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000481a:	479d                	li	a5,7
    8000481c:	04a7ca63          	blt	a5,a0,80004870 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80004820:	00014797          	auipc	a5,0x14
    80004824:	56078793          	addi	a5,a5,1376 # 80018d80 <disk>
    80004828:	97aa                	add	a5,a5,a0
    8000482a:	0187c783          	lbu	a5,24(a5)
    8000482e:	e7b9                	bnez	a5,8000487c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80004830:	00451693          	slli	a3,a0,0x4
    80004834:	00014797          	auipc	a5,0x14
    80004838:	54c78793          	addi	a5,a5,1356 # 80018d80 <disk>
    8000483c:	6398                	ld	a4,0(a5)
    8000483e:	9736                	add	a4,a4,a3
    80004840:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80004844:	6398                	ld	a4,0(a5)
    80004846:	9736                	add	a4,a4,a3
    80004848:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000484c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80004850:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004854:	97aa                	add	a5,a5,a0
    80004856:	4705                	li	a4,1
    80004858:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000485c:	00014517          	auipc	a0,0x14
    80004860:	53c50513          	addi	a0,a0,1340 # 80018d98 <disk+0x18>
    80004864:	b2dfc0ef          	jal	80001390 <wakeup>
}
    80004868:	60a2                	ld	ra,8(sp)
    8000486a:	6402                	ld	s0,0(sp)
    8000486c:	0141                	addi	sp,sp,16
    8000486e:	8082                	ret
    panic("free_desc 1");
    80004870:	00003517          	auipc	a0,0x3
    80004874:	e6850513          	addi	a0,a0,-408 # 800076d8 <etext+0x6d8>
    80004878:	457000ef          	jal	800054ce <panic>
    panic("free_desc 2");
    8000487c:	00003517          	auipc	a0,0x3
    80004880:	e6c50513          	addi	a0,a0,-404 # 800076e8 <etext+0x6e8>
    80004884:	44b000ef          	jal	800054ce <panic>

0000000080004888 <virtio_disk_init>:
{
    80004888:	1101                	addi	sp,sp,-32
    8000488a:	ec06                	sd	ra,24(sp)
    8000488c:	e822                	sd	s0,16(sp)
    8000488e:	e426                	sd	s1,8(sp)
    80004890:	e04a                	sd	s2,0(sp)
    80004892:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004894:	00003597          	auipc	a1,0x3
    80004898:	e6458593          	addi	a1,a1,-412 # 800076f8 <etext+0x6f8>
    8000489c:	00014517          	auipc	a0,0x14
    800048a0:	60c50513          	addi	a0,a0,1548 # 80018ea8 <disk+0x128>
    800048a4:	6df000ef          	jal	80005782 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800048a8:	100017b7          	lui	a5,0x10001
    800048ac:	4398                	lw	a4,0(a5)
    800048ae:	2701                	sext.w	a4,a4
    800048b0:	747277b7          	lui	a5,0x74727
    800048b4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800048b8:	14f71863          	bne	a4,a5,80004a08 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800048bc:	100017b7          	lui	a5,0x10001
    800048c0:	43dc                	lw	a5,4(a5)
    800048c2:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800048c4:	4709                	li	a4,2
    800048c6:	14e79163          	bne	a5,a4,80004a08 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800048ca:	100017b7          	lui	a5,0x10001
    800048ce:	479c                	lw	a5,8(a5)
    800048d0:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800048d2:	12e79b63          	bne	a5,a4,80004a08 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800048d6:	100017b7          	lui	a5,0x10001
    800048da:	47d8                	lw	a4,12(a5)
    800048dc:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800048de:	554d47b7          	lui	a5,0x554d4
    800048e2:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800048e6:	12f71163          	bne	a4,a5,80004a08 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    800048ea:	100017b7          	lui	a5,0x10001
    800048ee:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800048f2:	4705                	li	a4,1
    800048f4:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800048f6:	470d                	li	a4,3
    800048f8:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800048fa:	10001737          	lui	a4,0x10001
    800048fe:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80004900:	c7ffe6b7          	lui	a3,0xc7ffe
    80004904:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd79f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80004908:	8f75                	and	a4,a4,a3
    8000490a:	100016b7          	lui	a3,0x10001
    8000490e:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004910:	472d                	li	a4,11
    80004912:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004914:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80004918:	439c                	lw	a5,0(a5)
    8000491a:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    8000491e:	8ba1                	andi	a5,a5,8
    80004920:	0e078a63          	beqz	a5,80004a14 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80004924:	100017b7          	lui	a5,0x10001
    80004928:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    8000492c:	43fc                	lw	a5,68(a5)
    8000492e:	2781                	sext.w	a5,a5
    80004930:	0e079863          	bnez	a5,80004a20 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80004934:	100017b7          	lui	a5,0x10001
    80004938:	5bdc                	lw	a5,52(a5)
    8000493a:	2781                	sext.w	a5,a5
  if(max == 0)
    8000493c:	0e078863          	beqz	a5,80004a2c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80004940:	471d                	li	a4,7
    80004942:	0ef77b63          	bgeu	a4,a5,80004a38 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80004946:	fb6fb0ef          	jal	800000fc <kalloc>
    8000494a:	00014497          	auipc	s1,0x14
    8000494e:	43648493          	addi	s1,s1,1078 # 80018d80 <disk>
    80004952:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004954:	fa8fb0ef          	jal	800000fc <kalloc>
    80004958:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000495a:	fa2fb0ef          	jal	800000fc <kalloc>
    8000495e:	87aa                	mv	a5,a0
    80004960:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004962:	6088                	ld	a0,0(s1)
    80004964:	0e050063          	beqz	a0,80004a44 <virtio_disk_init+0x1bc>
    80004968:	00014717          	auipc	a4,0x14
    8000496c:	42073703          	ld	a4,1056(a4) # 80018d88 <disk+0x8>
    80004970:	cb71                	beqz	a4,80004a44 <virtio_disk_init+0x1bc>
    80004972:	cbe9                	beqz	a5,80004a44 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80004974:	6605                	lui	a2,0x1
    80004976:	4581                	li	a1,0
    80004978:	fc6fb0ef          	jal	8000013e <memset>
  memset(disk.avail, 0, PGSIZE);
    8000497c:	00014497          	auipc	s1,0x14
    80004980:	40448493          	addi	s1,s1,1028 # 80018d80 <disk>
    80004984:	6605                	lui	a2,0x1
    80004986:	4581                	li	a1,0
    80004988:	6488                	ld	a0,8(s1)
    8000498a:	fb4fb0ef          	jal	8000013e <memset>
  memset(disk.used, 0, PGSIZE);
    8000498e:	6605                	lui	a2,0x1
    80004990:	4581                	li	a1,0
    80004992:	6888                	ld	a0,16(s1)
    80004994:	faafb0ef          	jal	8000013e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004998:	100017b7          	lui	a5,0x10001
    8000499c:	4721                	li	a4,8
    8000499e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800049a0:	4098                	lw	a4,0(s1)
    800049a2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800049a6:	40d8                	lw	a4,4(s1)
    800049a8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800049ac:	649c                	ld	a5,8(s1)
    800049ae:	0007869b          	sext.w	a3,a5
    800049b2:	10001737          	lui	a4,0x10001
    800049b6:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800049ba:	9781                	srai	a5,a5,0x20
    800049bc:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800049c0:	689c                	ld	a5,16(s1)
    800049c2:	0007869b          	sext.w	a3,a5
    800049c6:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800049ca:	9781                	srai	a5,a5,0x20
    800049cc:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800049d0:	4785                	li	a5,1
    800049d2:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800049d4:	00f48c23          	sb	a5,24(s1)
    800049d8:	00f48ca3          	sb	a5,25(s1)
    800049dc:	00f48d23          	sb	a5,26(s1)
    800049e0:	00f48da3          	sb	a5,27(s1)
    800049e4:	00f48e23          	sb	a5,28(s1)
    800049e8:	00f48ea3          	sb	a5,29(s1)
    800049ec:	00f48f23          	sb	a5,30(s1)
    800049f0:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    800049f4:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    800049f8:	07272823          	sw	s2,112(a4)
}
    800049fc:	60e2                	ld	ra,24(sp)
    800049fe:	6442                	ld	s0,16(sp)
    80004a00:	64a2                	ld	s1,8(sp)
    80004a02:	6902                	ld	s2,0(sp)
    80004a04:	6105                	addi	sp,sp,32
    80004a06:	8082                	ret
    panic("could not find virtio disk");
    80004a08:	00003517          	auipc	a0,0x3
    80004a0c:	d0050513          	addi	a0,a0,-768 # 80007708 <etext+0x708>
    80004a10:	2bf000ef          	jal	800054ce <panic>
    panic("virtio disk FEATURES_OK unset");
    80004a14:	00003517          	auipc	a0,0x3
    80004a18:	d1450513          	addi	a0,a0,-748 # 80007728 <etext+0x728>
    80004a1c:	2b3000ef          	jal	800054ce <panic>
    panic("virtio disk should not be ready");
    80004a20:	00003517          	auipc	a0,0x3
    80004a24:	d2850513          	addi	a0,a0,-728 # 80007748 <etext+0x748>
    80004a28:	2a7000ef          	jal	800054ce <panic>
    panic("virtio disk has no queue 0");
    80004a2c:	00003517          	auipc	a0,0x3
    80004a30:	d3c50513          	addi	a0,a0,-708 # 80007768 <etext+0x768>
    80004a34:	29b000ef          	jal	800054ce <panic>
    panic("virtio disk max queue too short");
    80004a38:	00003517          	auipc	a0,0x3
    80004a3c:	d5050513          	addi	a0,a0,-688 # 80007788 <etext+0x788>
    80004a40:	28f000ef          	jal	800054ce <panic>
    panic("virtio disk kalloc");
    80004a44:	00003517          	auipc	a0,0x3
    80004a48:	d6450513          	addi	a0,a0,-668 # 800077a8 <etext+0x7a8>
    80004a4c:	283000ef          	jal	800054ce <panic>

0000000080004a50 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004a50:	711d                	addi	sp,sp,-96
    80004a52:	ec86                	sd	ra,88(sp)
    80004a54:	e8a2                	sd	s0,80(sp)
    80004a56:	e4a6                	sd	s1,72(sp)
    80004a58:	e0ca                	sd	s2,64(sp)
    80004a5a:	fc4e                	sd	s3,56(sp)
    80004a5c:	f852                	sd	s4,48(sp)
    80004a5e:	f456                	sd	s5,40(sp)
    80004a60:	f05a                	sd	s6,32(sp)
    80004a62:	ec5e                	sd	s7,24(sp)
    80004a64:	e862                	sd	s8,16(sp)
    80004a66:	1080                	addi	s0,sp,96
    80004a68:	89aa                	mv	s3,a0
    80004a6a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004a6c:	00c52b83          	lw	s7,12(a0)
    80004a70:	001b9b9b          	slliw	s7,s7,0x1
    80004a74:	1b82                	slli	s7,s7,0x20
    80004a76:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80004a7a:	00014517          	auipc	a0,0x14
    80004a7e:	42e50513          	addi	a0,a0,1070 # 80018ea8 <disk+0x128>
    80004a82:	58b000ef          	jal	8000580c <acquire>
  for(int i = 0; i < NUM; i++){
    80004a86:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004a88:	00014a97          	auipc	s5,0x14
    80004a8c:	2f8a8a93          	addi	s5,s5,760 # 80018d80 <disk>
  for(int i = 0; i < 3; i++){
    80004a90:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80004a92:	5c7d                	li	s8,-1
    80004a94:	a095                	j	80004af8 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80004a96:	00fa8733          	add	a4,s5,a5
    80004a9a:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004a9e:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004aa0:	0207c563          	bltz	a5,80004aca <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80004aa4:	2905                	addiw	s2,s2,1
    80004aa6:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80004aa8:	05490c63          	beq	s2,s4,80004b00 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    80004aac:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004aae:	00014717          	auipc	a4,0x14
    80004ab2:	2d270713          	addi	a4,a4,722 # 80018d80 <disk>
    80004ab6:	4781                	li	a5,0
    if(disk.free[i]){
    80004ab8:	01874683          	lbu	a3,24(a4)
    80004abc:	fee9                	bnez	a3,80004a96 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80004abe:	2785                	addiw	a5,a5,1
    80004ac0:	0705                	addi	a4,a4,1
    80004ac2:	fe979be3          	bne	a5,s1,80004ab8 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80004ac6:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80004aca:	01205d63          	blez	s2,80004ae4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004ace:	fa042503          	lw	a0,-96(s0)
    80004ad2:	d41ff0ef          	jal	80004812 <free_desc>
      for(int j = 0; j < i; j++)
    80004ad6:	4785                	li	a5,1
    80004ad8:	0127d663          	bge	a5,s2,80004ae4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004adc:	fa442503          	lw	a0,-92(s0)
    80004ae0:	d33ff0ef          	jal	80004812 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004ae4:	00014597          	auipc	a1,0x14
    80004ae8:	3c458593          	addi	a1,a1,964 # 80018ea8 <disk+0x128>
    80004aec:	00014517          	auipc	a0,0x14
    80004af0:	2ac50513          	addi	a0,a0,684 # 80018d98 <disk+0x18>
    80004af4:	851fc0ef          	jal	80001344 <sleep>
  for(int i = 0; i < 3; i++){
    80004af8:	fa040613          	addi	a2,s0,-96
    80004afc:	4901                	li	s2,0
    80004afe:	b77d                	j	80004aac <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004b00:	fa042503          	lw	a0,-96(s0)
    80004b04:	00451693          	slli	a3,a0,0x4

  if(write)
    80004b08:	00014797          	auipc	a5,0x14
    80004b0c:	27878793          	addi	a5,a5,632 # 80018d80 <disk>
    80004b10:	00451713          	slli	a4,a0,0x4
    80004b14:	0a070713          	addi	a4,a4,160
    80004b18:	973e                	add	a4,a4,a5
    80004b1a:	01603633          	snez	a2,s6
    80004b1e:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004b20:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004b24:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004b28:	6398                	ld	a4,0(a5)
    80004b2a:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004b2c:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80004b30:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004b32:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004b34:	6390                	ld	a2,0(a5)
    80004b36:	00d60833          	add	a6,a2,a3
    80004b3a:	4741                	li	a4,16
    80004b3c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004b40:	4585                	li	a1,1
    80004b42:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80004b46:	fa442703          	lw	a4,-92(s0)
    80004b4a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004b4e:	0712                	slli	a4,a4,0x4
    80004b50:	963a                	add	a2,a2,a4
    80004b52:	05898813          	addi	a6,s3,88
    80004b56:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80004b5a:	0007b883          	ld	a7,0(a5)
    80004b5e:	9746                	add	a4,a4,a7
    80004b60:	40000613          	li	a2,1024
    80004b64:	c710                	sw	a2,8(a4)
  if(write)
    80004b66:	001b3613          	seqz	a2,s6
    80004b6a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004b6e:	8e4d                	or	a2,a2,a1
    80004b70:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004b74:	fa842603          	lw	a2,-88(s0)
    80004b78:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004b7c:	00451813          	slli	a6,a0,0x4
    80004b80:	02080813          	addi	a6,a6,32
    80004b84:	983e                	add	a6,a6,a5
    80004b86:	577d                	li	a4,-1
    80004b88:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004b8c:	0612                	slli	a2,a2,0x4
    80004b8e:	98b2                	add	a7,a7,a2
    80004b90:	03068713          	addi	a4,a3,48
    80004b94:	973e                	add	a4,a4,a5
    80004b96:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80004b9a:	6398                	ld	a4,0(a5)
    80004b9c:	9732                	add	a4,a4,a2
    80004b9e:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004ba0:	4689                	li	a3,2
    80004ba2:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80004ba6:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004baa:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80004bae:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004bb2:	6794                	ld	a3,8(a5)
    80004bb4:	0026d703          	lhu	a4,2(a3)
    80004bb8:	8b1d                	andi	a4,a4,7
    80004bba:	0706                	slli	a4,a4,0x1
    80004bbc:	96ba                	add	a3,a3,a4
    80004bbe:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80004bc2:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004bc6:	6798                	ld	a4,8(a5)
    80004bc8:	00275783          	lhu	a5,2(a4)
    80004bcc:	2785                	addiw	a5,a5,1
    80004bce:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004bd2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004bd6:	100017b7          	lui	a5,0x10001
    80004bda:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004bde:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80004be2:	00014917          	auipc	s2,0x14
    80004be6:	2c690913          	addi	s2,s2,710 # 80018ea8 <disk+0x128>
  while(b->disk == 1) {
    80004bea:	84ae                	mv	s1,a1
    80004bec:	00b79a63          	bne	a5,a1,80004c00 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80004bf0:	85ca                	mv	a1,s2
    80004bf2:	854e                	mv	a0,s3
    80004bf4:	f50fc0ef          	jal	80001344 <sleep>
  while(b->disk == 1) {
    80004bf8:	0049a783          	lw	a5,4(s3)
    80004bfc:	fe978ae3          	beq	a5,s1,80004bf0 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80004c00:	fa042903          	lw	s2,-96(s0)
    80004c04:	00491713          	slli	a4,s2,0x4
    80004c08:	02070713          	addi	a4,a4,32
    80004c0c:	00014797          	auipc	a5,0x14
    80004c10:	17478793          	addi	a5,a5,372 # 80018d80 <disk>
    80004c14:	97ba                	add	a5,a5,a4
    80004c16:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004c1a:	00014997          	auipc	s3,0x14
    80004c1e:	16698993          	addi	s3,s3,358 # 80018d80 <disk>
    80004c22:	00491713          	slli	a4,s2,0x4
    80004c26:	0009b783          	ld	a5,0(s3)
    80004c2a:	97ba                	add	a5,a5,a4
    80004c2c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004c30:	854a                	mv	a0,s2
    80004c32:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004c36:	bddff0ef          	jal	80004812 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004c3a:	8885                	andi	s1,s1,1
    80004c3c:	f0fd                	bnez	s1,80004c22 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004c3e:	00014517          	auipc	a0,0x14
    80004c42:	26a50513          	addi	a0,a0,618 # 80018ea8 <disk+0x128>
    80004c46:	45b000ef          	jal	800058a0 <release>
}
    80004c4a:	60e6                	ld	ra,88(sp)
    80004c4c:	6446                	ld	s0,80(sp)
    80004c4e:	64a6                	ld	s1,72(sp)
    80004c50:	6906                	ld	s2,64(sp)
    80004c52:	79e2                	ld	s3,56(sp)
    80004c54:	7a42                	ld	s4,48(sp)
    80004c56:	7aa2                	ld	s5,40(sp)
    80004c58:	7b02                	ld	s6,32(sp)
    80004c5a:	6be2                	ld	s7,24(sp)
    80004c5c:	6c42                	ld	s8,16(sp)
    80004c5e:	6125                	addi	sp,sp,96
    80004c60:	8082                	ret

0000000080004c62 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004c62:	1101                	addi	sp,sp,-32
    80004c64:	ec06                	sd	ra,24(sp)
    80004c66:	e822                	sd	s0,16(sp)
    80004c68:	e426                	sd	s1,8(sp)
    80004c6a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004c6c:	00014497          	auipc	s1,0x14
    80004c70:	11448493          	addi	s1,s1,276 # 80018d80 <disk>
    80004c74:	00014517          	auipc	a0,0x14
    80004c78:	23450513          	addi	a0,a0,564 # 80018ea8 <disk+0x128>
    80004c7c:	391000ef          	jal	8000580c <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004c80:	100017b7          	lui	a5,0x10001
    80004c84:	53bc                	lw	a5,96(a5)
    80004c86:	8b8d                	andi	a5,a5,3
    80004c88:	10001737          	lui	a4,0x10001
    80004c8c:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004c8e:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004c92:	689c                	ld	a5,16(s1)
    80004c94:	0204d703          	lhu	a4,32(s1)
    80004c98:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80004c9c:	04f70863          	beq	a4,a5,80004cec <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80004ca0:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004ca4:	6898                	ld	a4,16(s1)
    80004ca6:	0204d783          	lhu	a5,32(s1)
    80004caa:	8b9d                	andi	a5,a5,7
    80004cac:	078e                	slli	a5,a5,0x3
    80004cae:	97ba                	add	a5,a5,a4
    80004cb0:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004cb2:	00479713          	slli	a4,a5,0x4
    80004cb6:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80004cba:	9726                	add	a4,a4,s1
    80004cbc:	01074703          	lbu	a4,16(a4)
    80004cc0:	e329                	bnez	a4,80004d02 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004cc2:	0792                	slli	a5,a5,0x4
    80004cc4:	02078793          	addi	a5,a5,32
    80004cc8:	97a6                	add	a5,a5,s1
    80004cca:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004ccc:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004cd0:	ec0fc0ef          	jal	80001390 <wakeup>

    disk.used_idx += 1;
    80004cd4:	0204d783          	lhu	a5,32(s1)
    80004cd8:	2785                	addiw	a5,a5,1
    80004cda:	17c2                	slli	a5,a5,0x30
    80004cdc:	93c1                	srli	a5,a5,0x30
    80004cde:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004ce2:	6898                	ld	a4,16(s1)
    80004ce4:	00275703          	lhu	a4,2(a4)
    80004ce8:	faf71ce3          	bne	a4,a5,80004ca0 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80004cec:	00014517          	auipc	a0,0x14
    80004cf0:	1bc50513          	addi	a0,a0,444 # 80018ea8 <disk+0x128>
    80004cf4:	3ad000ef          	jal	800058a0 <release>
}
    80004cf8:	60e2                	ld	ra,24(sp)
    80004cfa:	6442                	ld	s0,16(sp)
    80004cfc:	64a2                	ld	s1,8(sp)
    80004cfe:	6105                	addi	sp,sp,32
    80004d00:	8082                	ret
      panic("virtio_disk_intr status");
    80004d02:	00003517          	auipc	a0,0x3
    80004d06:	abe50513          	addi	a0,a0,-1346 # 800077c0 <etext+0x7c0>
    80004d0a:	7c4000ef          	jal	800054ce <panic>

0000000080004d0e <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80004d0e:	1141                	addi	sp,sp,-16
    80004d10:	e406                	sd	ra,8(sp)
    80004d12:	e022                	sd	s0,0(sp)
    80004d14:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80004d16:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80004d1a:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80004d1e:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80004d22:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80004d26:	577d                	li	a4,-1
    80004d28:	177e                	slli	a4,a4,0x3f
    80004d2a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80004d2c:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80004d30:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80004d34:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80004d38:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80004d3c:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80004d40:	000f4737          	lui	a4,0xf4
    80004d44:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80004d48:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80004d4a:	14d79073          	csrw	stimecmp,a5
}
    80004d4e:	60a2                	ld	ra,8(sp)
    80004d50:	6402                	ld	s0,0(sp)
    80004d52:	0141                	addi	sp,sp,16
    80004d54:	8082                	ret

0000000080004d56 <start>:
{
    80004d56:	1141                	addi	sp,sp,-16
    80004d58:	e406                	sd	ra,8(sp)
    80004d5a:	e022                	sd	s0,0(sp)
    80004d5c:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80004d5e:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80004d62:	7779                	lui	a4,0xffffe
    80004d64:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd83f>
    80004d68:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80004d6a:	6705                	lui	a4,0x1
    80004d6c:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80004d70:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80004d72:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80004d76:	ffffb797          	auipc	a5,0xffffb
    80004d7a:	57e78793          	addi	a5,a5,1406 # 800002f4 <main>
    80004d7e:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80004d82:	4781                	li	a5,0
    80004d84:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80004d88:	67c1                	lui	a5,0x10
    80004d8a:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80004d8c:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80004d90:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80004d94:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80004d98:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80004d9c:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80004da0:	57fd                	li	a5,-1
    80004da2:	83a9                	srli	a5,a5,0xa
    80004da4:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80004da8:	47bd                	li	a5,15
    80004daa:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80004dae:	f61ff0ef          	jal	80004d0e <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80004db2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80004db6:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80004db8:	823e                	mv	tp,a5
  asm volatile("mret");
    80004dba:	30200073          	mret
}
    80004dbe:	60a2                	ld	ra,8(sp)
    80004dc0:	6402                	ld	s0,0(sp)
    80004dc2:	0141                	addi	sp,sp,16
    80004dc4:	8082                	ret

0000000080004dc6 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80004dc6:	711d                	addi	sp,sp,-96
    80004dc8:	ec86                	sd	ra,88(sp)
    80004dca:	e8a2                	sd	s0,80(sp)
    80004dcc:	e0ca                	sd	s2,64(sp)
    80004dce:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    80004dd0:	04c05763          	blez	a2,80004e1e <consolewrite+0x58>
    80004dd4:	e4a6                	sd	s1,72(sp)
    80004dd6:	fc4e                	sd	s3,56(sp)
    80004dd8:	f852                	sd	s4,48(sp)
    80004dda:	f456                	sd	s5,40(sp)
    80004ddc:	f05a                	sd	s6,32(sp)
    80004dde:	ec5e                	sd	s7,24(sp)
    80004de0:	8a2a                	mv	s4,a0
    80004de2:	84ae                	mv	s1,a1
    80004de4:	89b2                	mv	s3,a2
    80004de6:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80004de8:	faf40b93          	addi	s7,s0,-81
    80004dec:	4b05                	li	s6,1
    80004dee:	5afd                	li	s5,-1
    80004df0:	86da                	mv	a3,s6
    80004df2:	8626                	mv	a2,s1
    80004df4:	85d2                	mv	a1,s4
    80004df6:	855e                	mv	a0,s7
    80004df8:	8f1fc0ef          	jal	800016e8 <either_copyin>
    80004dfc:	03550363          	beq	a0,s5,80004e22 <consolewrite+0x5c>
      break;
    uartputc(c);
    80004e00:	faf44503          	lbu	a0,-81(s0)
    80004e04:	06b000ef          	jal	8000566e <uartputc>
  for(i = 0; i < n; i++){
    80004e08:	2905                	addiw	s2,s2,1
    80004e0a:	0485                	addi	s1,s1,1
    80004e0c:	ff2992e3          	bne	s3,s2,80004df0 <consolewrite+0x2a>
    80004e10:	64a6                	ld	s1,72(sp)
    80004e12:	79e2                	ld	s3,56(sp)
    80004e14:	7a42                	ld	s4,48(sp)
    80004e16:	7aa2                	ld	s5,40(sp)
    80004e18:	7b02                	ld	s6,32(sp)
    80004e1a:	6be2                	ld	s7,24(sp)
    80004e1c:	a809                	j	80004e2e <consolewrite+0x68>
    80004e1e:	4901                	li	s2,0
    80004e20:	a039                	j	80004e2e <consolewrite+0x68>
    80004e22:	64a6                	ld	s1,72(sp)
    80004e24:	79e2                	ld	s3,56(sp)
    80004e26:	7a42                	ld	s4,48(sp)
    80004e28:	7aa2                	ld	s5,40(sp)
    80004e2a:	7b02                	ld	s6,32(sp)
    80004e2c:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    80004e2e:	854a                	mv	a0,s2
    80004e30:	60e6                	ld	ra,88(sp)
    80004e32:	6446                	ld	s0,80(sp)
    80004e34:	6906                	ld	s2,64(sp)
    80004e36:	6125                	addi	sp,sp,96
    80004e38:	8082                	ret

0000000080004e3a <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80004e3a:	711d                	addi	sp,sp,-96
    80004e3c:	ec86                	sd	ra,88(sp)
    80004e3e:	e8a2                	sd	s0,80(sp)
    80004e40:	e4a6                	sd	s1,72(sp)
    80004e42:	e0ca                	sd	s2,64(sp)
    80004e44:	fc4e                	sd	s3,56(sp)
    80004e46:	f852                	sd	s4,48(sp)
    80004e48:	f05a                	sd	s6,32(sp)
    80004e4a:	ec5e                	sd	s7,24(sp)
    80004e4c:	1080                	addi	s0,sp,96
    80004e4e:	8b2a                	mv	s6,a0
    80004e50:	8a2e                	mv	s4,a1
    80004e52:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80004e54:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80004e56:	0001c517          	auipc	a0,0x1c
    80004e5a:	06a50513          	addi	a0,a0,106 # 80020ec0 <cons>
    80004e5e:	1af000ef          	jal	8000580c <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80004e62:	0001c497          	auipc	s1,0x1c
    80004e66:	05e48493          	addi	s1,s1,94 # 80020ec0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80004e6a:	0001c917          	auipc	s2,0x1c
    80004e6e:	0ee90913          	addi	s2,s2,238 # 80020f58 <cons+0x98>
  while(n > 0){
    80004e72:	0b305b63          	blez	s3,80004f28 <consoleread+0xee>
    while(cons.r == cons.w){
    80004e76:	0984a783          	lw	a5,152(s1)
    80004e7a:	09c4a703          	lw	a4,156(s1)
    80004e7e:	0af71063          	bne	a4,a5,80004f1e <consoleread+0xe4>
      if(killed(myproc())){
    80004e82:	ee9fb0ef          	jal	80000d6a <myproc>
    80004e86:	efafc0ef          	jal	80001580 <killed>
    80004e8a:	e12d                	bnez	a0,80004eec <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    80004e8c:	85a6                	mv	a1,s1
    80004e8e:	854a                	mv	a0,s2
    80004e90:	cb4fc0ef          	jal	80001344 <sleep>
    while(cons.r == cons.w){
    80004e94:	0984a783          	lw	a5,152(s1)
    80004e98:	09c4a703          	lw	a4,156(s1)
    80004e9c:	fef703e3          	beq	a4,a5,80004e82 <consoleread+0x48>
    80004ea0:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80004ea2:	0001c717          	auipc	a4,0x1c
    80004ea6:	01e70713          	addi	a4,a4,30 # 80020ec0 <cons>
    80004eaa:	0017869b          	addiw	a3,a5,1
    80004eae:	08d72c23          	sw	a3,152(a4)
    80004eb2:	07f7f693          	andi	a3,a5,127
    80004eb6:	9736                	add	a4,a4,a3
    80004eb8:	01874703          	lbu	a4,24(a4)
    80004ebc:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    80004ec0:	4691                	li	a3,4
    80004ec2:	04da8663          	beq	s5,a3,80004f0e <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80004ec6:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004eca:	4685                	li	a3,1
    80004ecc:	faf40613          	addi	a2,s0,-81
    80004ed0:	85d2                	mv	a1,s4
    80004ed2:	855a                	mv	a0,s6
    80004ed4:	fcafc0ef          	jal	8000169e <either_copyout>
    80004ed8:	57fd                	li	a5,-1
    80004eda:	04f50663          	beq	a0,a5,80004f26 <consoleread+0xec>
      break;

    dst++;
    80004ede:	0a05                	addi	s4,s4,1
    --n;
    80004ee0:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80004ee2:	47a9                	li	a5,10
    80004ee4:	04fa8b63          	beq	s5,a5,80004f3a <consoleread+0x100>
    80004ee8:	7aa2                	ld	s5,40(sp)
    80004eea:	b761                	j	80004e72 <consoleread+0x38>
        release(&cons.lock);
    80004eec:	0001c517          	auipc	a0,0x1c
    80004ef0:	fd450513          	addi	a0,a0,-44 # 80020ec0 <cons>
    80004ef4:	1ad000ef          	jal	800058a0 <release>
        return -1;
    80004ef8:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80004efa:	60e6                	ld	ra,88(sp)
    80004efc:	6446                	ld	s0,80(sp)
    80004efe:	64a6                	ld	s1,72(sp)
    80004f00:	6906                	ld	s2,64(sp)
    80004f02:	79e2                	ld	s3,56(sp)
    80004f04:	7a42                	ld	s4,48(sp)
    80004f06:	7b02                	ld	s6,32(sp)
    80004f08:	6be2                	ld	s7,24(sp)
    80004f0a:	6125                	addi	sp,sp,96
    80004f0c:	8082                	ret
      if(n < target){
    80004f0e:	0179fa63          	bgeu	s3,s7,80004f22 <consoleread+0xe8>
        cons.r--;
    80004f12:	0001c717          	auipc	a4,0x1c
    80004f16:	04f72323          	sw	a5,70(a4) # 80020f58 <cons+0x98>
    80004f1a:	7aa2                	ld	s5,40(sp)
    80004f1c:	a031                	j	80004f28 <consoleread+0xee>
    80004f1e:	f456                	sd	s5,40(sp)
    80004f20:	b749                	j	80004ea2 <consoleread+0x68>
    80004f22:	7aa2                	ld	s5,40(sp)
    80004f24:	a011                	j	80004f28 <consoleread+0xee>
    80004f26:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80004f28:	0001c517          	auipc	a0,0x1c
    80004f2c:	f9850513          	addi	a0,a0,-104 # 80020ec0 <cons>
    80004f30:	171000ef          	jal	800058a0 <release>
  return target - n;
    80004f34:	413b853b          	subw	a0,s7,s3
    80004f38:	b7c9                	j	80004efa <consoleread+0xc0>
    80004f3a:	7aa2                	ld	s5,40(sp)
    80004f3c:	b7f5                	j	80004f28 <consoleread+0xee>

0000000080004f3e <consputc>:
{
    80004f3e:	1141                	addi	sp,sp,-16
    80004f40:	e406                	sd	ra,8(sp)
    80004f42:	e022                	sd	s0,0(sp)
    80004f44:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80004f46:	10000793          	li	a5,256
    80004f4a:	00f50863          	beq	a0,a5,80004f5a <consputc+0x1c>
    uartputc_sync(c);
    80004f4e:	63e000ef          	jal	8000558c <uartputc_sync>
}
    80004f52:	60a2                	ld	ra,8(sp)
    80004f54:	6402                	ld	s0,0(sp)
    80004f56:	0141                	addi	sp,sp,16
    80004f58:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80004f5a:	4521                	li	a0,8
    80004f5c:	630000ef          	jal	8000558c <uartputc_sync>
    80004f60:	02000513          	li	a0,32
    80004f64:	628000ef          	jal	8000558c <uartputc_sync>
    80004f68:	4521                	li	a0,8
    80004f6a:	622000ef          	jal	8000558c <uartputc_sync>
    80004f6e:	b7d5                	j	80004f52 <consputc+0x14>

0000000080004f70 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80004f70:	1101                	addi	sp,sp,-32
    80004f72:	ec06                	sd	ra,24(sp)
    80004f74:	e822                	sd	s0,16(sp)
    80004f76:	e426                	sd	s1,8(sp)
    80004f78:	1000                	addi	s0,sp,32
    80004f7a:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80004f7c:	0001c517          	auipc	a0,0x1c
    80004f80:	f4450513          	addi	a0,a0,-188 # 80020ec0 <cons>
    80004f84:	089000ef          	jal	8000580c <acquire>

  switch(c){
    80004f88:	47d5                	li	a5,21
    80004f8a:	08f48d63          	beq	s1,a5,80005024 <consoleintr+0xb4>
    80004f8e:	0297c563          	blt	a5,s1,80004fb8 <consoleintr+0x48>
    80004f92:	47a1                	li	a5,8
    80004f94:	0ef48263          	beq	s1,a5,80005078 <consoleintr+0x108>
    80004f98:	47c1                	li	a5,16
    80004f9a:	10f49363          	bne	s1,a5,800050a0 <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    80004f9e:	f94fc0ef          	jal	80001732 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    80004fa2:	0001c517          	auipc	a0,0x1c
    80004fa6:	f1e50513          	addi	a0,a0,-226 # 80020ec0 <cons>
    80004faa:	0f7000ef          	jal	800058a0 <release>
}
    80004fae:	60e2                	ld	ra,24(sp)
    80004fb0:	6442                	ld	s0,16(sp)
    80004fb2:	64a2                	ld	s1,8(sp)
    80004fb4:	6105                	addi	sp,sp,32
    80004fb6:	8082                	ret
  switch(c){
    80004fb8:	07f00793          	li	a5,127
    80004fbc:	0af48e63          	beq	s1,a5,80005078 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80004fc0:	0001c717          	auipc	a4,0x1c
    80004fc4:	f0070713          	addi	a4,a4,-256 # 80020ec0 <cons>
    80004fc8:	0a072783          	lw	a5,160(a4)
    80004fcc:	09872703          	lw	a4,152(a4)
    80004fd0:	9f99                	subw	a5,a5,a4
    80004fd2:	07f00713          	li	a4,127
    80004fd6:	fcf766e3          	bltu	a4,a5,80004fa2 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80004fda:	47b5                	li	a5,13
    80004fdc:	0cf48563          	beq	s1,a5,800050a6 <consoleintr+0x136>
      consputc(c);
    80004fe0:	8526                	mv	a0,s1
    80004fe2:	f5dff0ef          	jal	80004f3e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80004fe6:	0001c717          	auipc	a4,0x1c
    80004fea:	eda70713          	addi	a4,a4,-294 # 80020ec0 <cons>
    80004fee:	0a072683          	lw	a3,160(a4)
    80004ff2:	0016879b          	addiw	a5,a3,1
    80004ff6:	863e                	mv	a2,a5
    80004ff8:	0af72023          	sw	a5,160(a4)
    80004ffc:	07f6f693          	andi	a3,a3,127
    80005000:	9736                	add	a4,a4,a3
    80005002:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80005006:	ff648713          	addi	a4,s1,-10
    8000500a:	c371                	beqz	a4,800050ce <consoleintr+0x15e>
    8000500c:	14f1                	addi	s1,s1,-4
    8000500e:	c0e1                	beqz	s1,800050ce <consoleintr+0x15e>
    80005010:	0001c717          	auipc	a4,0x1c
    80005014:	f4872703          	lw	a4,-184(a4) # 80020f58 <cons+0x98>
    80005018:	9f99                	subw	a5,a5,a4
    8000501a:	08000713          	li	a4,128
    8000501e:	f8e792e3          	bne	a5,a4,80004fa2 <consoleintr+0x32>
    80005022:	a075                	j	800050ce <consoleintr+0x15e>
    80005024:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80005026:	0001c717          	auipc	a4,0x1c
    8000502a:	e9a70713          	addi	a4,a4,-358 # 80020ec0 <cons>
    8000502e:	0a072783          	lw	a5,160(a4)
    80005032:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005036:	0001c497          	auipc	s1,0x1c
    8000503a:	e8a48493          	addi	s1,s1,-374 # 80020ec0 <cons>
    while(cons.e != cons.w &&
    8000503e:	4929                	li	s2,10
    80005040:	02f70863          	beq	a4,a5,80005070 <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005044:	37fd                	addiw	a5,a5,-1
    80005046:	07f7f713          	andi	a4,a5,127
    8000504a:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000504c:	01874703          	lbu	a4,24(a4)
    80005050:	03270263          	beq	a4,s2,80005074 <consoleintr+0x104>
      cons.e--;
    80005054:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005058:	10000513          	li	a0,256
    8000505c:	ee3ff0ef          	jal	80004f3e <consputc>
    while(cons.e != cons.w &&
    80005060:	0a04a783          	lw	a5,160(s1)
    80005064:	09c4a703          	lw	a4,156(s1)
    80005068:	fcf71ee3          	bne	a4,a5,80005044 <consoleintr+0xd4>
    8000506c:	6902                	ld	s2,0(sp)
    8000506e:	bf15                	j	80004fa2 <consoleintr+0x32>
    80005070:	6902                	ld	s2,0(sp)
    80005072:	bf05                	j	80004fa2 <consoleintr+0x32>
    80005074:	6902                	ld	s2,0(sp)
    80005076:	b735                	j	80004fa2 <consoleintr+0x32>
    if(cons.e != cons.w){
    80005078:	0001c717          	auipc	a4,0x1c
    8000507c:	e4870713          	addi	a4,a4,-440 # 80020ec0 <cons>
    80005080:	0a072783          	lw	a5,160(a4)
    80005084:	09c72703          	lw	a4,156(a4)
    80005088:	f0f70de3          	beq	a4,a5,80004fa2 <consoleintr+0x32>
      cons.e--;
    8000508c:	37fd                	addiw	a5,a5,-1
    8000508e:	0001c717          	auipc	a4,0x1c
    80005092:	ecf72923          	sw	a5,-302(a4) # 80020f60 <cons+0xa0>
      consputc(BACKSPACE);
    80005096:	10000513          	li	a0,256
    8000509a:	ea5ff0ef          	jal	80004f3e <consputc>
    8000509e:	b711                	j	80004fa2 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800050a0:	f00481e3          	beqz	s1,80004fa2 <consoleintr+0x32>
    800050a4:	bf31                	j	80004fc0 <consoleintr+0x50>
      consputc(c);
    800050a6:	4529                	li	a0,10
    800050a8:	e97ff0ef          	jal	80004f3e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800050ac:	0001c797          	auipc	a5,0x1c
    800050b0:	e1478793          	addi	a5,a5,-492 # 80020ec0 <cons>
    800050b4:	0a07a703          	lw	a4,160(a5)
    800050b8:	0017069b          	addiw	a3,a4,1
    800050bc:	8636                	mv	a2,a3
    800050be:	0ad7a023          	sw	a3,160(a5)
    800050c2:	07f77713          	andi	a4,a4,127
    800050c6:	97ba                	add	a5,a5,a4
    800050c8:	4729                	li	a4,10
    800050ca:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800050ce:	0001c797          	auipc	a5,0x1c
    800050d2:	e8c7a723          	sw	a2,-370(a5) # 80020f5c <cons+0x9c>
        wakeup(&cons.r);
    800050d6:	0001c517          	auipc	a0,0x1c
    800050da:	e8250513          	addi	a0,a0,-382 # 80020f58 <cons+0x98>
    800050de:	ab2fc0ef          	jal	80001390 <wakeup>
    800050e2:	b5c1                	j	80004fa2 <consoleintr+0x32>

00000000800050e4 <consoleinit>:

void
consoleinit(void)
{
    800050e4:	1141                	addi	sp,sp,-16
    800050e6:	e406                	sd	ra,8(sp)
    800050e8:	e022                	sd	s0,0(sp)
    800050ea:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800050ec:	00002597          	auipc	a1,0x2
    800050f0:	6ec58593          	addi	a1,a1,1772 # 800077d8 <etext+0x7d8>
    800050f4:	0001c517          	auipc	a0,0x1c
    800050f8:	dcc50513          	addi	a0,a0,-564 # 80020ec0 <cons>
    800050fc:	686000ef          	jal	80005782 <initlock>

  uartinit();
    80005100:	436000ef          	jal	80005536 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80005104:	00013797          	auipc	a5,0x13
    80005108:	c2478793          	addi	a5,a5,-988 # 80017d28 <devsw>
    8000510c:	00000717          	auipc	a4,0x0
    80005110:	d2e70713          	addi	a4,a4,-722 # 80004e3a <consoleread>
    80005114:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80005116:	00000717          	auipc	a4,0x0
    8000511a:	cb070713          	addi	a4,a4,-848 # 80004dc6 <consolewrite>
    8000511e:	ef98                	sd	a4,24(a5)
}
    80005120:	60a2                	ld	ra,8(sp)
    80005122:	6402                	ld	s0,0(sp)
    80005124:	0141                	addi	sp,sp,16
    80005126:	8082                	ret

0000000080005128 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80005128:	7179                	addi	sp,sp,-48
    8000512a:	f406                	sd	ra,40(sp)
    8000512c:	f022                	sd	s0,32(sp)
    8000512e:	e84a                	sd	s2,16(sp)
    80005130:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80005132:	c219                	beqz	a2,80005138 <printint+0x10>
    80005134:	08054163          	bltz	a0,800051b6 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80005138:	4301                	li	t1,0

  i = 0;
    8000513a:	fd040913          	addi	s2,s0,-48
    x = xx;
    8000513e:	86ca                	mv	a3,s2
  i = 0;
    80005140:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005142:	00003817          	auipc	a6,0x3
    80005146:	8ae80813          	addi	a6,a6,-1874 # 800079f0 <digits>
    8000514a:	88ba                	mv	a7,a4
    8000514c:	0017061b          	addiw	a2,a4,1
    80005150:	8732                	mv	a4,a2
    80005152:	02b577b3          	remu	a5,a0,a1
    80005156:	97c2                	add	a5,a5,a6
    80005158:	0007c783          	lbu	a5,0(a5)
    8000515c:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005160:	87aa                	mv	a5,a0
    80005162:	02b55533          	divu	a0,a0,a1
    80005166:	0685                	addi	a3,a3,1
    80005168:	feb7f1e3          	bgeu	a5,a1,8000514a <printint+0x22>

  if(sign)
    8000516c:	00030c63          	beqz	t1,80005184 <printint+0x5c>
    buf[i++] = '-';
    80005170:	fe060793          	addi	a5,a2,-32
    80005174:	00878633          	add	a2,a5,s0
    80005178:	02d00793          	li	a5,45
    8000517c:	fef60823          	sb	a5,-16(a2)
    80005180:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80005184:	02e05463          	blez	a4,800051ac <printint+0x84>
    80005188:	ec26                	sd	s1,24(sp)
    8000518a:	377d                	addiw	a4,a4,-1
    8000518c:	00e904b3          	add	s1,s2,a4
    80005190:	197d                	addi	s2,s2,-1
    80005192:	993a                	add	s2,s2,a4
    80005194:	1702                	slli	a4,a4,0x20
    80005196:	9301                	srli	a4,a4,0x20
    80005198:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    8000519c:	0004c503          	lbu	a0,0(s1)
    800051a0:	d9fff0ef          	jal	80004f3e <consputc>
  while(--i >= 0)
    800051a4:	14fd                	addi	s1,s1,-1
    800051a6:	ff249be3          	bne	s1,s2,8000519c <printint+0x74>
    800051aa:	64e2                	ld	s1,24(sp)
}
    800051ac:	70a2                	ld	ra,40(sp)
    800051ae:	7402                	ld	s0,32(sp)
    800051b0:	6942                	ld	s2,16(sp)
    800051b2:	6145                	addi	sp,sp,48
    800051b4:	8082                	ret
    x = -xx;
    800051b6:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800051ba:	4305                	li	t1,1
    x = -xx;
    800051bc:	bfbd                	j	8000513a <printint+0x12>

00000000800051be <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800051be:	7131                	addi	sp,sp,-192
    800051c0:	fc86                	sd	ra,120(sp)
    800051c2:	f8a2                	sd	s0,112(sp)
    800051c4:	f0ca                	sd	s2,96(sp)
    800051c6:	ec6e                	sd	s11,24(sp)
    800051c8:	0100                	addi	s0,sp,128
    800051ca:	892a                	mv	s2,a0
    800051cc:	e40c                	sd	a1,8(s0)
    800051ce:	e810                	sd	a2,16(s0)
    800051d0:	ec14                	sd	a3,24(s0)
    800051d2:	f018                	sd	a4,32(s0)
    800051d4:	f41c                	sd	a5,40(s0)
    800051d6:	03043823          	sd	a6,48(s0)
    800051da:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800051de:	0001cd97          	auipc	s11,0x1c
    800051e2:	da2dad83          	lw	s11,-606(s11) # 80020f80 <pr+0x18>
  if(locking)
    800051e6:	020d9d63          	bnez	s11,80005220 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800051ea:	00840793          	addi	a5,s0,8
    800051ee:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800051f2:	00054503          	lbu	a0,0(a0)
    800051f6:	20050f63          	beqz	a0,80005414 <printf+0x256>
    800051fa:	f4a6                	sd	s1,104(sp)
    800051fc:	ecce                	sd	s3,88(sp)
    800051fe:	e8d2                	sd	s4,80(sp)
    80005200:	e4d6                	sd	s5,72(sp)
    80005202:	e0da                	sd	s6,64(sp)
    80005204:	fc5e                	sd	s7,56(sp)
    80005206:	f862                	sd	s8,48(sp)
    80005208:	f06a                	sd	s10,32(sp)
    8000520a:	4a81                	li	s5,0
    if(cx != '%'){
    8000520c:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80005210:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80005214:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    80005218:	4b29                	li	s6,10
    if(c0 == 'd'){
    8000521a:	06400b93          	li	s7,100
    8000521e:	a80d                	j	80005250 <printf+0x92>
    acquire(&pr.lock);
    80005220:	0001c517          	auipc	a0,0x1c
    80005224:	d4850513          	addi	a0,a0,-696 # 80020f68 <pr>
    80005228:	5e4000ef          	jal	8000580c <acquire>
  va_start(ap, fmt);
    8000522c:	00840793          	addi	a5,s0,8
    80005230:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005234:	00094503          	lbu	a0,0(s2)
    80005238:	f169                	bnez	a0,800051fa <printf+0x3c>
    8000523a:	aae5                	j	80005432 <printf+0x274>
      consputc(cx);
    8000523c:	d03ff0ef          	jal	80004f3e <consputc>
      continue;
    80005240:	84d6                	mv	s1,s5
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005242:	2485                	addiw	s1,s1,1
    80005244:	8aa6                	mv	s5,s1
    80005246:	94ca                	add	s1,s1,s2
    80005248:	0004c503          	lbu	a0,0(s1)
    8000524c:	1a050a63          	beqz	a0,80005400 <printf+0x242>
    if(cx != '%'){
    80005250:	ff3516e3          	bne	a0,s3,8000523c <printf+0x7e>
    i++;
    80005254:	001a879b          	addiw	a5,s5,1
    80005258:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000525a:	00f90733          	add	a4,s2,a5
    8000525e:	00074a03          	lbu	s4,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005262:	1e0a0863          	beqz	s4,80005452 <printf+0x294>
    80005266:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000526a:	1c068b63          	beqz	a3,80005440 <printf+0x282>
    if(c0 == 'd'){
    8000526e:	037a0863          	beq	s4,s7,8000529e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005272:	f94a0713          	addi	a4,s4,-108
    80005276:	00173713          	seqz	a4,a4
    8000527a:	f9c68613          	addi	a2,a3,-100
    8000527e:	ee05                	bnez	a2,800052b6 <printf+0xf8>
    80005280:	cb1d                	beqz	a4,800052b6 <printf+0xf8>
      printint(va_arg(ap, uint64), 10, 1);
    80005282:	f8843783          	ld	a5,-120(s0)
    80005286:	00878713          	addi	a4,a5,8
    8000528a:	f8e43423          	sd	a4,-120(s0)
    8000528e:	4605                	li	a2,1
    80005290:	85da                	mv	a1,s6
    80005292:	6388                	ld	a0,0(a5)
    80005294:	e95ff0ef          	jal	80005128 <printint>
      i += 1;
    80005298:	002a849b          	addiw	s1,s5,2
    8000529c:	b75d                	j	80005242 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    8000529e:	f8843783          	ld	a5,-120(s0)
    800052a2:	00878713          	addi	a4,a5,8
    800052a6:	f8e43423          	sd	a4,-120(s0)
    800052aa:	4605                	li	a2,1
    800052ac:	85da                	mv	a1,s6
    800052ae:	4388                	lw	a0,0(a5)
    800052b0:	e79ff0ef          	jal	80005128 <printint>
    800052b4:	b779                	j	80005242 <printf+0x84>
    if(c1) c2 = fmt[i+2] & 0xff;
    800052b6:	97ca                	add	a5,a5,s2
    800052b8:	8636                	mv	a2,a3
    800052ba:	0027c683          	lbu	a3,2(a5)
    800052be:	a245                	j	8000545e <printf+0x2a0>
      printint(va_arg(ap, uint64), 10, 1);
    800052c0:	f8843783          	ld	a5,-120(s0)
    800052c4:	00878713          	addi	a4,a5,8
    800052c8:	f8e43423          	sd	a4,-120(s0)
    800052cc:	4605                	li	a2,1
    800052ce:	45a9                	li	a1,10
    800052d0:	6388                	ld	a0,0(a5)
    800052d2:	e57ff0ef          	jal	80005128 <printint>
      i += 2;
    800052d6:	003a849b          	addiw	s1,s5,3
    800052da:	b7a5                	j	80005242 <printf+0x84>
      printint(va_arg(ap, int), 10, 0);
    800052dc:	f8843783          	ld	a5,-120(s0)
    800052e0:	00878713          	addi	a4,a5,8
    800052e4:	f8e43423          	sd	a4,-120(s0)
    800052e8:	4601                	li	a2,0
    800052ea:	85da                	mv	a1,s6
    800052ec:	4388                	lw	a0,0(a5)
    800052ee:	e3bff0ef          	jal	80005128 <printint>
    800052f2:	bf81                	j	80005242 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800052f4:	f8843783          	ld	a5,-120(s0)
    800052f8:	00878713          	addi	a4,a5,8
    800052fc:	f8e43423          	sd	a4,-120(s0)
    80005300:	4601                	li	a2,0
    80005302:	85da                	mv	a1,s6
    80005304:	6388                	ld	a0,0(a5)
    80005306:	e23ff0ef          	jal	80005128 <printint>
      i += 1;
    8000530a:	002a849b          	addiw	s1,s5,2
    8000530e:	bf15                	j	80005242 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    80005310:	f8843783          	ld	a5,-120(s0)
    80005314:	00878713          	addi	a4,a5,8
    80005318:	f8e43423          	sd	a4,-120(s0)
    8000531c:	4601                	li	a2,0
    8000531e:	45a9                	li	a1,10
    80005320:	6388                	ld	a0,0(a5)
    80005322:	e07ff0ef          	jal	80005128 <printint>
      i += 2;
    80005326:	003a849b          	addiw	s1,s5,3
    8000532a:	bf21                	j	80005242 <printf+0x84>
      printint(va_arg(ap, int), 16, 0);
    8000532c:	f8843783          	ld	a5,-120(s0)
    80005330:	00878713          	addi	a4,a5,8
    80005334:	f8e43423          	sd	a4,-120(s0)
    80005338:	4601                	li	a2,0
    8000533a:	45c1                	li	a1,16
    8000533c:	4388                	lw	a0,0(a5)
    8000533e:	debff0ef          	jal	80005128 <printint>
    80005342:	b701                	j	80005242 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80005344:	f8843783          	ld	a5,-120(s0)
    80005348:	00878713          	addi	a4,a5,8
    8000534c:	f8e43423          	sd	a4,-120(s0)
    80005350:	45c1                	li	a1,16
    80005352:	6388                	ld	a0,0(a5)
    80005354:	dd5ff0ef          	jal	80005128 <printint>
      i += 1;
    80005358:	002a849b          	addiw	s1,s5,2
    8000535c:	b5dd                	j	80005242 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    8000535e:	f8843783          	ld	a5,-120(s0)
    80005362:	00878713          	addi	a4,a5,8
    80005366:	f8e43423          	sd	a4,-120(s0)
    8000536a:	4601                	li	a2,0
    8000536c:	45c1                	li	a1,16
    8000536e:	6388                	ld	a0,0(a5)
    80005370:	db9ff0ef          	jal	80005128 <printint>
      i += 2;
    80005374:	003a849b          	addiw	s1,s5,3
    80005378:	b5e9                	j	80005242 <printf+0x84>
    8000537a:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    8000537c:	f8843783          	ld	a5,-120(s0)
    80005380:	00878713          	addi	a4,a5,8
    80005384:	f8e43423          	sd	a4,-120(s0)
    80005388:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    8000538c:	03000513          	li	a0,48
    80005390:	bafff0ef          	jal	80004f3e <consputc>
  consputc('x');
    80005394:	07800513          	li	a0,120
    80005398:	ba7ff0ef          	jal	80004f3e <consputc>
    8000539c:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000539e:	00002c97          	auipc	s9,0x2
    800053a2:	652c8c93          	addi	s9,s9,1618 # 800079f0 <digits>
    800053a6:	03cad793          	srli	a5,s5,0x3c
    800053aa:	97e6                	add	a5,a5,s9
    800053ac:	0007c503          	lbu	a0,0(a5)
    800053b0:	b8fff0ef          	jal	80004f3e <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800053b4:	0a92                	slli	s5,s5,0x4
    800053b6:	3a7d                	addiw	s4,s4,-1
    800053b8:	fe0a17e3          	bnez	s4,800053a6 <printf+0x1e8>
    800053bc:	7ca2                	ld	s9,40(sp)
    800053be:	b551                	j	80005242 <printf+0x84>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    800053c0:	f8843783          	ld	a5,-120(s0)
    800053c4:	00878713          	addi	a4,a5,8
    800053c8:	f8e43423          	sd	a4,-120(s0)
    800053cc:	0007ba03          	ld	s4,0(a5)
    800053d0:	000a0d63          	beqz	s4,800053ea <printf+0x22c>
        s = "(null)";
      for(; *s; s++)
    800053d4:	000a4503          	lbu	a0,0(s4)
    800053d8:	e60505e3          	beqz	a0,80005242 <printf+0x84>
        consputc(*s);
    800053dc:	b63ff0ef          	jal	80004f3e <consputc>
      for(; *s; s++)
    800053e0:	0a05                	addi	s4,s4,1
    800053e2:	000a4503          	lbu	a0,0(s4)
    800053e6:	f97d                	bnez	a0,800053dc <printf+0x21e>
    800053e8:	bda9                	j	80005242 <printf+0x84>
        s = "(null)";
    800053ea:	00002a17          	auipc	s4,0x2
    800053ee:	3f6a0a13          	addi	s4,s4,1014 # 800077e0 <etext+0x7e0>
      for(; *s; s++)
    800053f2:	02800513          	li	a0,40
    800053f6:	b7dd                	j	800053dc <printf+0x21e>
    } else if(c0 == '%'){
      consputc('%');
    800053f8:	8552                	mv	a0,s4
    800053fa:	b45ff0ef          	jal	80004f3e <consputc>
    800053fe:	b591                	j	80005242 <printf+0x84>
    }
#endif
  }
  va_end(ap);

  if(locking)
    80005400:	020d9163          	bnez	s11,80005422 <printf+0x264>
    80005404:	74a6                	ld	s1,104(sp)
    80005406:	69e6                	ld	s3,88(sp)
    80005408:	6a46                	ld	s4,80(sp)
    8000540a:	6aa6                	ld	s5,72(sp)
    8000540c:	6b06                	ld	s6,64(sp)
    8000540e:	7be2                	ld	s7,56(sp)
    80005410:	7c42                	ld	s8,48(sp)
    80005412:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    80005414:	4501                	li	a0,0
    80005416:	70e6                	ld	ra,120(sp)
    80005418:	7446                	ld	s0,112(sp)
    8000541a:	7906                	ld	s2,96(sp)
    8000541c:	6de2                	ld	s11,24(sp)
    8000541e:	6129                	addi	sp,sp,192
    80005420:	8082                	ret
    80005422:	74a6                	ld	s1,104(sp)
    80005424:	69e6                	ld	s3,88(sp)
    80005426:	6a46                	ld	s4,80(sp)
    80005428:	6aa6                	ld	s5,72(sp)
    8000542a:	6b06                	ld	s6,64(sp)
    8000542c:	7be2                	ld	s7,56(sp)
    8000542e:	7c42                	ld	s8,48(sp)
    80005430:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80005432:	0001c517          	auipc	a0,0x1c
    80005436:	b3650513          	addi	a0,a0,-1226 # 80020f68 <pr>
    8000543a:	466000ef          	jal	800058a0 <release>
    8000543e:	bfd9                	j	80005414 <printf+0x256>
    if(c0 == 'd'){
    80005440:	e57a0fe3          	beq	s4,s7,8000529e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005444:	f94a0713          	addi	a4,s4,-108
    80005448:	00173713          	seqz	a4,a4
    8000544c:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000544e:	4781                	li	a5,0
    80005450:	a00d                	j	80005472 <printf+0x2b4>
    } else if(c0 == 'l' && c1 == 'd'){
    80005452:	f94a0713          	addi	a4,s4,-108
    80005456:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    8000545a:	8652                	mv	a2,s4
    8000545c:	86d2                	mv	a3,s4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000545e:	f9460793          	addi	a5,a2,-108
    80005462:	0017b793          	seqz	a5,a5
    80005466:	8ff9                	and	a5,a5,a4
    80005468:	f9c68593          	addi	a1,a3,-100
    8000546c:	e199                	bnez	a1,80005472 <printf+0x2b4>
    8000546e:	e40799e3          	bnez	a5,800052c0 <printf+0x102>
    } else if(c0 == 'u'){
    80005472:	e78a05e3          	beq	s4,s8,800052dc <printf+0x11e>
    } else if(c0 == 'l' && c1 == 'u'){
    80005476:	f8b60593          	addi	a1,a2,-117
    8000547a:	e199                	bnez	a1,80005480 <printf+0x2c2>
    8000547c:	e6071ce3          	bnez	a4,800052f4 <printf+0x136>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005480:	f8b68593          	addi	a1,a3,-117
    80005484:	e199                	bnez	a1,8000548a <printf+0x2cc>
    80005486:	e80795e3          	bnez	a5,80005310 <printf+0x152>
    } else if(c0 == 'x'){
    8000548a:	ebaa01e3          	beq	s4,s10,8000532c <printf+0x16e>
    } else if(c0 == 'l' && c1 == 'x'){
    8000548e:	f8860613          	addi	a2,a2,-120
    80005492:	e219                	bnez	a2,80005498 <printf+0x2da>
    80005494:	ea0718e3          	bnez	a4,80005344 <printf+0x186>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    80005498:	f8868693          	addi	a3,a3,-120
    8000549c:	e299                	bnez	a3,800054a2 <printf+0x2e4>
    8000549e:	ec0790e3          	bnez	a5,8000535e <printf+0x1a0>
    } else if(c0 == 'p'){
    800054a2:	07000793          	li	a5,112
    800054a6:	ecfa0ae3          	beq	s4,a5,8000537a <printf+0x1bc>
    } else if(c0 == 's'){
    800054aa:	07300793          	li	a5,115
    800054ae:	f0fa09e3          	beq	s4,a5,800053c0 <printf+0x202>
    } else if(c0 == '%'){
    800054b2:	02500793          	li	a5,37
    800054b6:	f4fa01e3          	beq	s4,a5,800053f8 <printf+0x23a>
    } else if(c0 == 0){
    800054ba:	f40a03e3          	beqz	s4,80005400 <printf+0x242>
      consputc('%');
    800054be:	02500513          	li	a0,37
    800054c2:	a7dff0ef          	jal	80004f3e <consputc>
      consputc(c0);
    800054c6:	8552                	mv	a0,s4
    800054c8:	a77ff0ef          	jal	80004f3e <consputc>
    800054cc:	bb9d                	j	80005242 <printf+0x84>

00000000800054ce <panic>:

void
panic(char *s)
{
    800054ce:	1101                	addi	sp,sp,-32
    800054d0:	ec06                	sd	ra,24(sp)
    800054d2:	e822                	sd	s0,16(sp)
    800054d4:	e426                	sd	s1,8(sp)
    800054d6:	1000                	addi	s0,sp,32
    800054d8:	84aa                	mv	s1,a0
  pr.locking = 0;
    800054da:	0001c797          	auipc	a5,0x1c
    800054de:	aa07a323          	sw	zero,-1370(a5) # 80020f80 <pr+0x18>
  printf("panic: ");
    800054e2:	00002517          	auipc	a0,0x2
    800054e6:	30650513          	addi	a0,a0,774 # 800077e8 <etext+0x7e8>
    800054ea:	cd5ff0ef          	jal	800051be <printf>
  printf("%s\n", s);
    800054ee:	85a6                	mv	a1,s1
    800054f0:	00002517          	auipc	a0,0x2
    800054f4:	30050513          	addi	a0,a0,768 # 800077f0 <etext+0x7f0>
    800054f8:	cc7ff0ef          	jal	800051be <printf>
  panicked = 1; // freeze uart output from other CPUs
    800054fc:	4785                	li	a5,1
    800054fe:	00002717          	auipc	a4,0x2
    80005502:	56f72f23          	sw	a5,1406(a4) # 80007a7c <panicked>
  for(;;)
    80005506:	a001                	j	80005506 <panic+0x38>

0000000080005508 <printfinit>:
    ;
}

void
printfinit(void)
{
    80005508:	1141                	addi	sp,sp,-16
    8000550a:	e406                	sd	ra,8(sp)
    8000550c:	e022                	sd	s0,0(sp)
    8000550e:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80005510:	00002597          	auipc	a1,0x2
    80005514:	2e858593          	addi	a1,a1,744 # 800077f8 <etext+0x7f8>
    80005518:	0001c517          	auipc	a0,0x1c
    8000551c:	a5050513          	addi	a0,a0,-1456 # 80020f68 <pr>
    80005520:	262000ef          	jal	80005782 <initlock>
  pr.locking = 1;
    80005524:	4785                	li	a5,1
    80005526:	0001c717          	auipc	a4,0x1c
    8000552a:	a4f72d23          	sw	a5,-1446(a4) # 80020f80 <pr+0x18>
}
    8000552e:	60a2                	ld	ra,8(sp)
    80005530:	6402                	ld	s0,0(sp)
    80005532:	0141                	addi	sp,sp,16
    80005534:	8082                	ret

0000000080005536 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80005536:	1141                	addi	sp,sp,-16
    80005538:	e406                	sd	ra,8(sp)
    8000553a:	e022                	sd	s0,0(sp)
    8000553c:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000553e:	100007b7          	lui	a5,0x10000
    80005542:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80005546:	10000737          	lui	a4,0x10000
    8000554a:	f8000693          	li	a3,-128
    8000554e:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005552:	468d                	li	a3,3
    80005554:	10000637          	lui	a2,0x10000
    80005558:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000555c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80005560:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80005564:	8732                	mv	a4,a2
    80005566:	461d                	li	a2,7
    80005568:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000556c:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80005570:	00002597          	auipc	a1,0x2
    80005574:	29058593          	addi	a1,a1,656 # 80007800 <etext+0x800>
    80005578:	0001c517          	auipc	a0,0x1c
    8000557c:	a1050513          	addi	a0,a0,-1520 # 80020f88 <uart_tx_lock>
    80005580:	202000ef          	jal	80005782 <initlock>
}
    80005584:	60a2                	ld	ra,8(sp)
    80005586:	6402                	ld	s0,0(sp)
    80005588:	0141                	addi	sp,sp,16
    8000558a:	8082                	ret

000000008000558c <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000558c:	1101                	addi	sp,sp,-32
    8000558e:	ec06                	sd	ra,24(sp)
    80005590:	e822                	sd	s0,16(sp)
    80005592:	e426                	sd	s1,8(sp)
    80005594:	1000                	addi	s0,sp,32
    80005596:	84aa                	mv	s1,a0
  push_off();
    80005598:	230000ef          	jal	800057c8 <push_off>

  if(panicked){
    8000559c:	00002797          	auipc	a5,0x2
    800055a0:	4e07a783          	lw	a5,1248(a5) # 80007a7c <panicked>
    800055a4:	e795                	bnez	a5,800055d0 <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800055a6:	10000737          	lui	a4,0x10000
    800055aa:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    800055ac:	00074783          	lbu	a5,0(a4)
    800055b0:	0207f793          	andi	a5,a5,32
    800055b4:	dfe5                	beqz	a5,800055ac <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    800055b6:	0ff4f513          	zext.b	a0,s1
    800055ba:	100007b7          	lui	a5,0x10000
    800055be:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800055c2:	28e000ef          	jal	80005850 <pop_off>
}
    800055c6:	60e2                	ld	ra,24(sp)
    800055c8:	6442                	ld	s0,16(sp)
    800055ca:	64a2                	ld	s1,8(sp)
    800055cc:	6105                	addi	sp,sp,32
    800055ce:	8082                	ret
    for(;;)
    800055d0:	a001                	j	800055d0 <uartputc_sync+0x44>

00000000800055d2 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800055d2:	00002797          	auipc	a5,0x2
    800055d6:	4ae7b783          	ld	a5,1198(a5) # 80007a80 <uart_tx_r>
    800055da:	00002717          	auipc	a4,0x2
    800055de:	4ae73703          	ld	a4,1198(a4) # 80007a88 <uart_tx_w>
    800055e2:	08f70163          	beq	a4,a5,80005664 <uartstart+0x92>
{
    800055e6:	7139                	addi	sp,sp,-64
    800055e8:	fc06                	sd	ra,56(sp)
    800055ea:	f822                	sd	s0,48(sp)
    800055ec:	f426                	sd	s1,40(sp)
    800055ee:	f04a                	sd	s2,32(sp)
    800055f0:	ec4e                	sd	s3,24(sp)
    800055f2:	e852                	sd	s4,16(sp)
    800055f4:	e456                	sd	s5,8(sp)
    800055f6:	e05a                	sd	s6,0(sp)
    800055f8:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800055fa:	10000937          	lui	s2,0x10000
    800055fe:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005600:	0001ca97          	auipc	s5,0x1c
    80005604:	988a8a93          	addi	s5,s5,-1656 # 80020f88 <uart_tx_lock>
    uart_tx_r += 1;
    80005608:	00002497          	auipc	s1,0x2
    8000560c:	47848493          	addi	s1,s1,1144 # 80007a80 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    80005610:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80005614:	00002997          	auipc	s3,0x2
    80005618:	47498993          	addi	s3,s3,1140 # 80007a88 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000561c:	00094703          	lbu	a4,0(s2)
    80005620:	02077713          	andi	a4,a4,32
    80005624:	c715                	beqz	a4,80005650 <uartstart+0x7e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005626:	01f7f713          	andi	a4,a5,31
    8000562a:	9756                	add	a4,a4,s5
    8000562c:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    80005630:	0785                	addi	a5,a5,1
    80005632:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80005634:	8526                	mv	a0,s1
    80005636:	d5bfb0ef          	jal	80001390 <wakeup>
    WriteReg(THR, c);
    8000563a:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    8000563e:	609c                	ld	a5,0(s1)
    80005640:	0009b703          	ld	a4,0(s3)
    80005644:	fcf71ce3          	bne	a4,a5,8000561c <uartstart+0x4a>
      ReadReg(ISR);
    80005648:	100007b7          	lui	a5,0x10000
    8000564c:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005650:	70e2                	ld	ra,56(sp)
    80005652:	7442                	ld	s0,48(sp)
    80005654:	74a2                	ld	s1,40(sp)
    80005656:	7902                	ld	s2,32(sp)
    80005658:	69e2                	ld	s3,24(sp)
    8000565a:	6a42                	ld	s4,16(sp)
    8000565c:	6aa2                	ld	s5,8(sp)
    8000565e:	6b02                	ld	s6,0(sp)
    80005660:	6121                	addi	sp,sp,64
    80005662:	8082                	ret
      ReadReg(ISR);
    80005664:	100007b7          	lui	a5,0x10000
    80005668:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    8000566c:	8082                	ret

000000008000566e <uartputc>:
{
    8000566e:	7179                	addi	sp,sp,-48
    80005670:	f406                	sd	ra,40(sp)
    80005672:	f022                	sd	s0,32(sp)
    80005674:	ec26                	sd	s1,24(sp)
    80005676:	e84a                	sd	s2,16(sp)
    80005678:	e44e                	sd	s3,8(sp)
    8000567a:	e052                	sd	s4,0(sp)
    8000567c:	1800                	addi	s0,sp,48
    8000567e:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    80005680:	0001c517          	auipc	a0,0x1c
    80005684:	90850513          	addi	a0,a0,-1784 # 80020f88 <uart_tx_lock>
    80005688:	184000ef          	jal	8000580c <acquire>
  if(panicked){
    8000568c:	00002797          	auipc	a5,0x2
    80005690:	3f07a783          	lw	a5,1008(a5) # 80007a7c <panicked>
    80005694:	e3d1                	bnez	a5,80005718 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80005696:	00002717          	auipc	a4,0x2
    8000569a:	3f273703          	ld	a4,1010(a4) # 80007a88 <uart_tx_w>
    8000569e:	00002797          	auipc	a5,0x2
    800056a2:	3e27b783          	ld	a5,994(a5) # 80007a80 <uart_tx_r>
    800056a6:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800056aa:	0001c997          	auipc	s3,0x1c
    800056ae:	8de98993          	addi	s3,s3,-1826 # 80020f88 <uart_tx_lock>
    800056b2:	00002497          	auipc	s1,0x2
    800056b6:	3ce48493          	addi	s1,s1,974 # 80007a80 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056ba:	00002917          	auipc	s2,0x2
    800056be:	3ce90913          	addi	s2,s2,974 # 80007a88 <uart_tx_w>
    800056c2:	00e79d63          	bne	a5,a4,800056dc <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800056c6:	85ce                	mv	a1,s3
    800056c8:	8526                	mv	a0,s1
    800056ca:	c7bfb0ef          	jal	80001344 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056ce:	00093703          	ld	a4,0(s2)
    800056d2:	609c                	ld	a5,0(s1)
    800056d4:	02078793          	addi	a5,a5,32
    800056d8:	fee787e3          	beq	a5,a4,800056c6 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800056dc:	01f77693          	andi	a3,a4,31
    800056e0:	0001c797          	auipc	a5,0x1c
    800056e4:	8a878793          	addi	a5,a5,-1880 # 80020f88 <uart_tx_lock>
    800056e8:	97b6                	add	a5,a5,a3
    800056ea:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800056ee:	0705                	addi	a4,a4,1
    800056f0:	00002797          	auipc	a5,0x2
    800056f4:	38e7bc23          	sd	a4,920(a5) # 80007a88 <uart_tx_w>
  uartstart();
    800056f8:	edbff0ef          	jal	800055d2 <uartstart>
  release(&uart_tx_lock);
    800056fc:	0001c517          	auipc	a0,0x1c
    80005700:	88c50513          	addi	a0,a0,-1908 # 80020f88 <uart_tx_lock>
    80005704:	19c000ef          	jal	800058a0 <release>
}
    80005708:	70a2                	ld	ra,40(sp)
    8000570a:	7402                	ld	s0,32(sp)
    8000570c:	64e2                	ld	s1,24(sp)
    8000570e:	6942                	ld	s2,16(sp)
    80005710:	69a2                	ld	s3,8(sp)
    80005712:	6a02                	ld	s4,0(sp)
    80005714:	6145                	addi	sp,sp,48
    80005716:	8082                	ret
    for(;;)
    80005718:	a001                	j	80005718 <uartputc+0xaa>

000000008000571a <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    8000571a:	1141                	addi	sp,sp,-16
    8000571c:	e406                	sd	ra,8(sp)
    8000571e:	e022                	sd	s0,0(sp)
    80005720:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80005722:	100007b7          	lui	a5,0x10000
    80005726:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    8000572a:	8b85                	andi	a5,a5,1
    8000572c:	cb89                	beqz	a5,8000573e <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    8000572e:	100007b7          	lui	a5,0x10000
    80005732:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80005736:	60a2                	ld	ra,8(sp)
    80005738:	6402                	ld	s0,0(sp)
    8000573a:	0141                	addi	sp,sp,16
    8000573c:	8082                	ret
    return -1;
    8000573e:	557d                	li	a0,-1
    80005740:	bfdd                	j	80005736 <uartgetc+0x1c>

0000000080005742 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80005742:	1101                	addi	sp,sp,-32
    80005744:	ec06                	sd	ra,24(sp)
    80005746:	e822                	sd	s0,16(sp)
    80005748:	e426                	sd	s1,8(sp)
    8000574a:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    8000574c:	54fd                	li	s1,-1
    int c = uartgetc();
    8000574e:	fcdff0ef          	jal	8000571a <uartgetc>
    if(c == -1)
    80005752:	00950563          	beq	a0,s1,8000575c <uartintr+0x1a>
      break;
    consoleintr(c);
    80005756:	81bff0ef          	jal	80004f70 <consoleintr>
  while(1){
    8000575a:	bfd5                	j	8000574e <uartintr+0xc>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    8000575c:	0001c517          	auipc	a0,0x1c
    80005760:	82c50513          	addi	a0,a0,-2004 # 80020f88 <uart_tx_lock>
    80005764:	0a8000ef          	jal	8000580c <acquire>
  uartstart();
    80005768:	e6bff0ef          	jal	800055d2 <uartstart>
  release(&uart_tx_lock);
    8000576c:	0001c517          	auipc	a0,0x1c
    80005770:	81c50513          	addi	a0,a0,-2020 # 80020f88 <uart_tx_lock>
    80005774:	12c000ef          	jal	800058a0 <release>
}
    80005778:	60e2                	ld	ra,24(sp)
    8000577a:	6442                	ld	s0,16(sp)
    8000577c:	64a2                	ld	s1,8(sp)
    8000577e:	6105                	addi	sp,sp,32
    80005780:	8082                	ret

0000000080005782 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80005782:	1141                	addi	sp,sp,-16
    80005784:	e406                	sd	ra,8(sp)
    80005786:	e022                	sd	s0,0(sp)
    80005788:	0800                	addi	s0,sp,16
  lk->name = name;
    8000578a:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    8000578c:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80005790:	00053823          	sd	zero,16(a0)
}
    80005794:	60a2                	ld	ra,8(sp)
    80005796:	6402                	ld	s0,0(sp)
    80005798:	0141                	addi	sp,sp,16
    8000579a:	8082                	ret

000000008000579c <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    8000579c:	411c                	lw	a5,0(a0)
    8000579e:	e399                	bnez	a5,800057a4 <holding+0x8>
    800057a0:	4501                	li	a0,0
  return r;
}
    800057a2:	8082                	ret
{
    800057a4:	1101                	addi	sp,sp,-32
    800057a6:	ec06                	sd	ra,24(sp)
    800057a8:	e822                	sd	s0,16(sp)
    800057aa:	e426                	sd	s1,8(sp)
    800057ac:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    800057ae:	691c                	ld	a5,16(a0)
    800057b0:	84be                	mv	s1,a5
    800057b2:	d98fb0ef          	jal	80000d4a <mycpu>
    800057b6:	40a48533          	sub	a0,s1,a0
    800057ba:	00153513          	seqz	a0,a0
}
    800057be:	60e2                	ld	ra,24(sp)
    800057c0:	6442                	ld	s0,16(sp)
    800057c2:	64a2                	ld	s1,8(sp)
    800057c4:	6105                	addi	sp,sp,32
    800057c6:	8082                	ret

00000000800057c8 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    800057c8:	1101                	addi	sp,sp,-32
    800057ca:	ec06                	sd	ra,24(sp)
    800057cc:	e822                	sd	s0,16(sp)
    800057ce:	e426                	sd	s1,8(sp)
    800057d0:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800057d2:	100027f3          	csrr	a5,sstatus
    800057d6:	84be                	mv	s1,a5
    800057d8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800057dc:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800057de:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    800057e2:	d68fb0ef          	jal	80000d4a <mycpu>
    800057e6:	5d3c                	lw	a5,120(a0)
    800057e8:	cb99                	beqz	a5,800057fe <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    800057ea:	d60fb0ef          	jal	80000d4a <mycpu>
    800057ee:	5d3c                	lw	a5,120(a0)
    800057f0:	2785                	addiw	a5,a5,1
    800057f2:	dd3c                	sw	a5,120(a0)
}
    800057f4:	60e2                	ld	ra,24(sp)
    800057f6:	6442                	ld	s0,16(sp)
    800057f8:	64a2                	ld	s1,8(sp)
    800057fa:	6105                	addi	sp,sp,32
    800057fc:	8082                	ret
    mycpu()->intena = old;
    800057fe:	d4cfb0ef          	jal	80000d4a <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80005802:	0014d793          	srli	a5,s1,0x1
    80005806:	8b85                	andi	a5,a5,1
    80005808:	dd7c                	sw	a5,124(a0)
    8000580a:	b7c5                	j	800057ea <push_off+0x22>

000000008000580c <acquire>:
{
    8000580c:	1101                	addi	sp,sp,-32
    8000580e:	ec06                	sd	ra,24(sp)
    80005810:	e822                	sd	s0,16(sp)
    80005812:	e426                	sd	s1,8(sp)
    80005814:	1000                	addi	s0,sp,32
    80005816:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80005818:	fb1ff0ef          	jal	800057c8 <push_off>
  if(holding(lk))
    8000581c:	8526                	mv	a0,s1
    8000581e:	f7fff0ef          	jal	8000579c <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005822:	4705                	li	a4,1
  if(holding(lk))
    80005824:	e105                	bnez	a0,80005844 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005826:	87ba                	mv	a5,a4
    80005828:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    8000582c:	2781                	sext.w	a5,a5
    8000582e:	ffe5                	bnez	a5,80005826 <acquire+0x1a>
  __sync_synchronize();
    80005830:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80005834:	d16fb0ef          	jal	80000d4a <mycpu>
    80005838:	e888                	sd	a0,16(s1)
}
    8000583a:	60e2                	ld	ra,24(sp)
    8000583c:	6442                	ld	s0,16(sp)
    8000583e:	64a2                	ld	s1,8(sp)
    80005840:	6105                	addi	sp,sp,32
    80005842:	8082                	ret
    panic("acquire");
    80005844:	00002517          	auipc	a0,0x2
    80005848:	fc450513          	addi	a0,a0,-60 # 80007808 <etext+0x808>
    8000584c:	c83ff0ef          	jal	800054ce <panic>

0000000080005850 <pop_off>:

void
pop_off(void)
{
    80005850:	1141                	addi	sp,sp,-16
    80005852:	e406                	sd	ra,8(sp)
    80005854:	e022                	sd	s0,0(sp)
    80005856:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005858:	cf2fb0ef          	jal	80000d4a <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000585c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80005860:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005862:	e39d                	bnez	a5,80005888 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005864:	5d3c                	lw	a5,120(a0)
    80005866:	02f05763          	blez	a5,80005894 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    8000586a:	37fd                	addiw	a5,a5,-1
    8000586c:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    8000586e:	eb89                	bnez	a5,80005880 <pop_off+0x30>
    80005870:	5d7c                	lw	a5,124(a0)
    80005872:	c799                	beqz	a5,80005880 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005874:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80005878:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000587c:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80005880:	60a2                	ld	ra,8(sp)
    80005882:	6402                	ld	s0,0(sp)
    80005884:	0141                	addi	sp,sp,16
    80005886:	8082                	ret
    panic("pop_off - interruptible");
    80005888:	00002517          	auipc	a0,0x2
    8000588c:	f8850513          	addi	a0,a0,-120 # 80007810 <etext+0x810>
    80005890:	c3fff0ef          	jal	800054ce <panic>
    panic("pop_off");
    80005894:	00002517          	auipc	a0,0x2
    80005898:	f9450513          	addi	a0,a0,-108 # 80007828 <etext+0x828>
    8000589c:	c33ff0ef          	jal	800054ce <panic>

00000000800058a0 <release>:
{
    800058a0:	1101                	addi	sp,sp,-32
    800058a2:	ec06                	sd	ra,24(sp)
    800058a4:	e822                	sd	s0,16(sp)
    800058a6:	e426                	sd	s1,8(sp)
    800058a8:	1000                	addi	s0,sp,32
    800058aa:	84aa                	mv	s1,a0
  if(!holding(lk))
    800058ac:	ef1ff0ef          	jal	8000579c <holding>
    800058b0:	c105                	beqz	a0,800058d0 <release+0x30>
  lk->cpu = 0;
    800058b2:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    800058b6:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    800058ba:	0310000f          	fence	rw,w
    800058be:	0004a023          	sw	zero,0(s1)
  pop_off();
    800058c2:	f8fff0ef          	jal	80005850 <pop_off>
}
    800058c6:	60e2                	ld	ra,24(sp)
    800058c8:	6442                	ld	s0,16(sp)
    800058ca:	64a2                	ld	s1,8(sp)
    800058cc:	6105                	addi	sp,sp,32
    800058ce:	8082                	ret
    panic("release");
    800058d0:	00002517          	auipc	a0,0x2
    800058d4:	f6050513          	addi	a0,a0,-160 # 80007830 <etext+0x830>
    800058d8:	bf7ff0ef          	jal	800054ce <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
