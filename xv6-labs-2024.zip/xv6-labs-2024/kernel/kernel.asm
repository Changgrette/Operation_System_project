
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00019117          	auipc	sp,0x19
    80000004:	56010113          	addi	sp,sp,1376 # 80019560 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	611040ef          	jal	80004e26 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	00021797          	auipc	a5,0x21
    8000002c:	63878793          	addi	a5,a5,1592 # 80021660 <end>
    80000030:	00f53733          	sltu	a4,a0,a5
    80000034:	47c5                	li	a5,17
    80000036:	07ee                	slli	a5,a5,0x1b
    80000038:	17fd                	addi	a5,a5,-1
    8000003a:	00a7b7b3          	sltu	a5,a5,a0
    8000003e:	8fd9                	or	a5,a5,a4
    80000040:	ef95                	bnez	a5,8000007c <kfree+0x60>
    80000042:	84aa                	mv	s1,a0
    80000044:	03451793          	slli	a5,a0,0x34
    80000048:	eb95                	bnez	a5,8000007c <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    8000004a:	6605                	lui	a2,0x1
    8000004c:	4585                	li	a1,1
    8000004e:	110000ef          	jal	8000015e <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000052:	00008917          	auipc	s2,0x8
    80000056:	8de90913          	addi	s2,s2,-1826 # 80007930 <kmem>
    8000005a:	854a                	mv	a0,s2
    8000005c:	0e1050ef          	jal	8000593c <acquire>
  r->next = kmem.freelist;
    80000060:	01893783          	ld	a5,24(s2)
    80000064:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000066:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    8000006a:	854a                	mv	a0,s2
    8000006c:	165050ef          	jal	800059d0 <release>
}
    80000070:	60e2                	ld	ra,24(sp)
    80000072:	6442                	ld	s0,16(sp)
    80000074:	64a2                	ld	s1,8(sp)
    80000076:	6902                	ld	s2,0(sp)
    80000078:	6105                	addi	sp,sp,32
    8000007a:	8082                	ret
    panic("kfree");
    8000007c:	00007517          	auipc	a0,0x7
    80000080:	f8450513          	addi	a0,a0,-124 # 80007000 <etext>
    80000084:	5a4050ef          	jal	80005628 <panic>

0000000080000088 <freerange>:
{
    80000088:	7179                	addi	sp,sp,-48
    8000008a:	f406                	sd	ra,40(sp)
    8000008c:	f022                	sd	s0,32(sp)
    8000008e:	ec26                	sd	s1,24(sp)
    80000090:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000092:	6785                	lui	a5,0x1
    80000094:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000098:	00e504b3          	add	s1,a0,a4
    8000009c:	777d                	lui	a4,0xfffff
    8000009e:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000a0:	94be                	add	s1,s1,a5
    800000a2:	0295e263          	bltu	a1,s1,800000c6 <freerange+0x3e>
    800000a6:	e84a                	sd	s2,16(sp)
    800000a8:	e44e                	sd	s3,8(sp)
    800000aa:	e052                	sd	s4,0(sp)
    800000ac:	892e                	mv	s2,a1
    kfree(p);
    800000ae:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000b0:	89be                	mv	s3,a5
    kfree(p);
    800000b2:	01448533          	add	a0,s1,s4
    800000b6:	f67ff0ef          	jal	8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000ba:	94ce                	add	s1,s1,s3
    800000bc:	fe997be3          	bgeu	s2,s1,800000b2 <freerange+0x2a>
    800000c0:	6942                	ld	s2,16(sp)
    800000c2:	69a2                	ld	s3,8(sp)
    800000c4:	6a02                	ld	s4,0(sp)
}
    800000c6:	70a2                	ld	ra,40(sp)
    800000c8:	7402                	ld	s0,32(sp)
    800000ca:	64e2                	ld	s1,24(sp)
    800000cc:	6145                	addi	sp,sp,48
    800000ce:	8082                	ret

00000000800000d0 <kinit>:
{
    800000d0:	1141                	addi	sp,sp,-16
    800000d2:	e406                	sd	ra,8(sp)
    800000d4:	e022                	sd	s0,0(sp)
    800000d6:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d8:	00007597          	auipc	a1,0x7
    800000dc:	f3858593          	addi	a1,a1,-200 # 80007010 <etext+0x10>
    800000e0:	00008517          	auipc	a0,0x8
    800000e4:	85050513          	addi	a0,a0,-1968 # 80007930 <kmem>
    800000e8:	7ca050ef          	jal	800058b2 <initlock>
  freerange(end, (void*)PHYSTOP);
    800000ec:	45c5                	li	a1,17
    800000ee:	05ee                	slli	a1,a1,0x1b
    800000f0:	00021517          	auipc	a0,0x21
    800000f4:	57050513          	addi	a0,a0,1392 # 80021660 <end>
    800000f8:	f91ff0ef          	jal	80000088 <freerange>
}
    800000fc:	60a2                	ld	ra,8(sp)
    800000fe:	6402                	ld	s0,0(sp)
    80000100:	0141                	addi	sp,sp,16
    80000102:	8082                	ret

0000000080000104 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000104:	1101                	addi	sp,sp,-32
    80000106:	ec06                	sd	ra,24(sp)
    80000108:	e822                	sd	s0,16(sp)
    8000010a:	e426                	sd	s1,8(sp)
    8000010c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    8000010e:	00008517          	auipc	a0,0x8
    80000112:	82250513          	addi	a0,a0,-2014 # 80007930 <kmem>
    80000116:	027050ef          	jal	8000593c <acquire>
  r = kmem.freelist;
    8000011a:	00008497          	auipc	s1,0x8
    8000011e:	82e4b483          	ld	s1,-2002(s1) # 80007948 <kmem+0x18>
  if(r)
    80000122:	c49d                	beqz	s1,80000150 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000124:	609c                	ld	a5,0(s1)
    80000126:	00008717          	auipc	a4,0x8
    8000012a:	82f73123          	sd	a5,-2014(a4) # 80007948 <kmem+0x18>
  release(&kmem.lock);
    8000012e:	00008517          	auipc	a0,0x8
    80000132:	80250513          	addi	a0,a0,-2046 # 80007930 <kmem>
    80000136:	09b050ef          	jal	800059d0 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    8000013a:	6605                	lui	a2,0x1
    8000013c:	4595                	li	a1,5
    8000013e:	8526                	mv	a0,s1
    80000140:	01e000ef          	jal	8000015e <memset>
  return (void*)r;
}
    80000144:	8526                	mv	a0,s1
    80000146:	60e2                	ld	ra,24(sp)
    80000148:	6442                	ld	s0,16(sp)
    8000014a:	64a2                	ld	s1,8(sp)
    8000014c:	6105                	addi	sp,sp,32
    8000014e:	8082                	ret
  release(&kmem.lock);
    80000150:	00007517          	auipc	a0,0x7
    80000154:	7e050513          	addi	a0,a0,2016 # 80007930 <kmem>
    80000158:	079050ef          	jal	800059d0 <release>
  if(r)
    8000015c:	b7e5                	j	80000144 <kalloc+0x40>

000000008000015e <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000015e:	1141                	addi	sp,sp,-16
    80000160:	e406                	sd	ra,8(sp)
    80000162:	e022                	sd	s0,0(sp)
    80000164:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000166:	ca19                	beqz	a2,8000017c <memset+0x1e>
    80000168:	87aa                	mv	a5,a0
    8000016a:	1602                	slli	a2,a2,0x20
    8000016c:	9201                	srli	a2,a2,0x20
    8000016e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000172:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000176:	0785                	addi	a5,a5,1
    80000178:	fee79de3          	bne	a5,a4,80000172 <memset+0x14>
  }
  return dst;
}
    8000017c:	60a2                	ld	ra,8(sp)
    8000017e:	6402                	ld	s0,0(sp)
    80000180:	0141                	addi	sp,sp,16
    80000182:	8082                	ret

0000000080000184 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000184:	1141                	addi	sp,sp,-16
    80000186:	e406                	sd	ra,8(sp)
    80000188:	e022                	sd	s0,0(sp)
    8000018a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    8000018c:	c61d                	beqz	a2,800001ba <memcmp+0x36>
    8000018e:	1602                	slli	a2,a2,0x20
    80000190:	9201                	srli	a2,a2,0x20
    80000192:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000196:	00054783          	lbu	a5,0(a0)
    8000019a:	0005c703          	lbu	a4,0(a1)
    8000019e:	00e79863          	bne	a5,a4,800001ae <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    800001a2:	0505                	addi	a0,a0,1
    800001a4:	0585                	addi	a1,a1,1
  while(n-- > 0){
    800001a6:	fed518e3          	bne	a0,a3,80000196 <memcmp+0x12>
  }

  return 0;
    800001aa:	4501                	li	a0,0
    800001ac:	a019                	j	800001b2 <memcmp+0x2e>
      return *s1 - *s2;
    800001ae:	40e7853b          	subw	a0,a5,a4
}
    800001b2:	60a2                	ld	ra,8(sp)
    800001b4:	6402                	ld	s0,0(sp)
    800001b6:	0141                	addi	sp,sp,16
    800001b8:	8082                	ret
  return 0;
    800001ba:	4501                	li	a0,0
    800001bc:	bfdd                	j	800001b2 <memcmp+0x2e>

00000000800001be <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001be:	1141                	addi	sp,sp,-16
    800001c0:	e406                	sd	ra,8(sp)
    800001c2:	e022                	sd	s0,0(sp)
    800001c4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001c6:	c205                	beqz	a2,800001e6 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001c8:	02a5e363          	bltu	a1,a0,800001ee <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001cc:	1602                	slli	a2,a2,0x20
    800001ce:	9201                	srli	a2,a2,0x20
    800001d0:	00c587b3          	add	a5,a1,a2
{
    800001d4:	872a                	mv	a4,a0
      *d++ = *s++;
    800001d6:	0585                	addi	a1,a1,1
    800001d8:	0705                	addi	a4,a4,1
    800001da:	fff5c683          	lbu	a3,-1(a1)
    800001de:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001e2:	feb79ae3          	bne	a5,a1,800001d6 <memmove+0x18>

  return dst;
}
    800001e6:	60a2                	ld	ra,8(sp)
    800001e8:	6402                	ld	s0,0(sp)
    800001ea:	0141                	addi	sp,sp,16
    800001ec:	8082                	ret
  if(s < d && s + n > d){
    800001ee:	02061693          	slli	a3,a2,0x20
    800001f2:	9281                	srli	a3,a3,0x20
    800001f4:	00d58733          	add	a4,a1,a3
    800001f8:	fce57ae3          	bgeu	a0,a4,800001cc <memmove+0xe>
    d += n;
    800001fc:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001fe:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000202:	1782                	slli	a5,a5,0x20
    80000204:	9381                	srli	a5,a5,0x20
    80000206:	fff7c793          	not	a5,a5
    8000020a:	97ba                	add	a5,a5,a4
      *--d = *--s;
    8000020c:	177d                	addi	a4,a4,-1
    8000020e:	16fd                	addi	a3,a3,-1
    80000210:	00074603          	lbu	a2,0(a4)
    80000214:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000218:	fee79ae3          	bne	a5,a4,8000020c <memmove+0x4e>
    8000021c:	b7e9                	j	800001e6 <memmove+0x28>

000000008000021e <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    8000021e:	1141                	addi	sp,sp,-16
    80000220:	e406                	sd	ra,8(sp)
    80000222:	e022                	sd	s0,0(sp)
    80000224:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000226:	f99ff0ef          	jal	800001be <memmove>
}
    8000022a:	60a2                	ld	ra,8(sp)
    8000022c:	6402                	ld	s0,0(sp)
    8000022e:	0141                	addi	sp,sp,16
    80000230:	8082                	ret

0000000080000232 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000232:	1141                	addi	sp,sp,-16
    80000234:	e406                	sd	ra,8(sp)
    80000236:	e022                	sd	s0,0(sp)
    80000238:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000023a:	ce11                	beqz	a2,80000256 <strncmp+0x24>
    8000023c:	00054783          	lbu	a5,0(a0)
    80000240:	cf89                	beqz	a5,8000025a <strncmp+0x28>
    80000242:	0005c703          	lbu	a4,0(a1)
    80000246:	00f71a63          	bne	a4,a5,8000025a <strncmp+0x28>
    n--, p++, q++;
    8000024a:	367d                	addiw	a2,a2,-1
    8000024c:	0505                	addi	a0,a0,1
    8000024e:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000250:	f675                	bnez	a2,8000023c <strncmp+0xa>
  if(n == 0)
    return 0;
    80000252:	4501                	li	a0,0
    80000254:	a801                	j	80000264 <strncmp+0x32>
    80000256:	4501                	li	a0,0
    80000258:	a031                	j	80000264 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    8000025a:	00054503          	lbu	a0,0(a0)
    8000025e:	0005c783          	lbu	a5,0(a1)
    80000262:	9d1d                	subw	a0,a0,a5
}
    80000264:	60a2                	ld	ra,8(sp)
    80000266:	6402                	ld	s0,0(sp)
    80000268:	0141                	addi	sp,sp,16
    8000026a:	8082                	ret

000000008000026c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    8000026c:	1141                	addi	sp,sp,-16
    8000026e:	e406                	sd	ra,8(sp)
    80000270:	e022                	sd	s0,0(sp)
    80000272:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000274:	87aa                	mv	a5,a0
    80000276:	a011                	j	8000027a <strncpy+0xe>
    80000278:	8636                	mv	a2,a3
    8000027a:	02c05863          	blez	a2,800002aa <strncpy+0x3e>
    8000027e:	fff6069b          	addiw	a3,a2,-1
    80000282:	8836                	mv	a6,a3
    80000284:	0785                	addi	a5,a5,1
    80000286:	0005c703          	lbu	a4,0(a1)
    8000028a:	fee78fa3          	sb	a4,-1(a5)
    8000028e:	0585                	addi	a1,a1,1
    80000290:	f765                	bnez	a4,80000278 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000292:	873e                	mv	a4,a5
    80000294:	01005b63          	blez	a6,800002aa <strncpy+0x3e>
    80000298:	9fb1                	addw	a5,a5,a2
    8000029a:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    8000029c:	0705                	addi	a4,a4,1
    8000029e:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    800002a2:	40e786bb          	subw	a3,a5,a4
    800002a6:	fed04be3          	bgtz	a3,8000029c <strncpy+0x30>
  return os;
}
    800002aa:	60a2                	ld	ra,8(sp)
    800002ac:	6402                	ld	s0,0(sp)
    800002ae:	0141                	addi	sp,sp,16
    800002b0:	8082                	ret

00000000800002b2 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    800002b2:	1141                	addi	sp,sp,-16
    800002b4:	e406                	sd	ra,8(sp)
    800002b6:	e022                	sd	s0,0(sp)
    800002b8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    800002ba:	02c05363          	blez	a2,800002e0 <safestrcpy+0x2e>
    800002be:	fff6069b          	addiw	a3,a2,-1
    800002c2:	1682                	slli	a3,a3,0x20
    800002c4:	9281                	srli	a3,a3,0x20
    800002c6:	96ae                	add	a3,a3,a1
    800002c8:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002ca:	00d58963          	beq	a1,a3,800002dc <safestrcpy+0x2a>
    800002ce:	0585                	addi	a1,a1,1
    800002d0:	0785                	addi	a5,a5,1
    800002d2:	fff5c703          	lbu	a4,-1(a1)
    800002d6:	fee78fa3          	sb	a4,-1(a5)
    800002da:	fb65                	bnez	a4,800002ca <safestrcpy+0x18>
    ;
  *s = 0;
    800002dc:	00078023          	sb	zero,0(a5)
  return os;
}
    800002e0:	60a2                	ld	ra,8(sp)
    800002e2:	6402                	ld	s0,0(sp)
    800002e4:	0141                	addi	sp,sp,16
    800002e6:	8082                	ret

00000000800002e8 <strlen>:

int
strlen(const char *s)
{
    800002e8:	1141                	addi	sp,sp,-16
    800002ea:	e406                	sd	ra,8(sp)
    800002ec:	e022                	sd	s0,0(sp)
    800002ee:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002f0:	00054783          	lbu	a5,0(a0)
    800002f4:	cf91                	beqz	a5,80000310 <strlen+0x28>
    800002f6:	00150793          	addi	a5,a0,1
    800002fa:	86be                	mv	a3,a5
    800002fc:	0785                	addi	a5,a5,1
    800002fe:	fff7c703          	lbu	a4,-1(a5)
    80000302:	ff65                	bnez	a4,800002fa <strlen+0x12>
    80000304:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000308:	60a2                	ld	ra,8(sp)
    8000030a:	6402                	ld	s0,0(sp)
    8000030c:	0141                	addi	sp,sp,16
    8000030e:	8082                	ret
  for(n = 0; s[n]; n++)
    80000310:	4501                	li	a0,0
    80000312:	bfdd                	j	80000308 <strlen+0x20>

0000000080000314 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000314:	1141                	addi	sp,sp,-16
    80000316:	e406                	sd	ra,8(sp)
    80000318:	e022                	sd	s0,0(sp)
    8000031a:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    8000031c:	233000ef          	jal	80000d4e <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000320:	00007717          	auipc	a4,0x7
    80000324:	5e070713          	addi	a4,a4,1504 # 80007900 <started>
  if(cpuid() == 0){
    80000328:	c51d                	beqz	a0,80000356 <main+0x42>
    while(started == 0)
    8000032a:	431c                	lw	a5,0(a4)
    8000032c:	2781                	sext.w	a5,a5
    8000032e:	dff5                	beqz	a5,8000032a <main+0x16>
      ;
    __sync_synchronize();
    80000330:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000334:	21b000ef          	jal	80000d4e <cpuid>
    80000338:	85aa                	mv	a1,a0
    8000033a:	00007517          	auipc	a0,0x7
    8000033e:	cfe50513          	addi	a0,a0,-770 # 80007038 <etext+0x38>
    80000342:	74d040ef          	jal	8000528e <printf>
    kvminithart();    // turn on paging
    80000346:	080000ef          	jal	800003c6 <kvminithart>
    trapinithart();   // install kernel trap vector
    8000034a:	5ca010ef          	jal	80001914 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    8000034e:	51a040ef          	jal	80004868 <plicinithart>
  }

  scheduler();        
    80000352:	699000ef          	jal	800011ea <scheduler>
    consoleinit();
    80000356:	65f040ef          	jal	800051b4 <consoleinit>
    printfinit();
    8000035a:	244050ef          	jal	8000559e <printfinit>
    printf("\n");
    8000035e:	00007517          	auipc	a0,0x7
    80000362:	cba50513          	addi	a0,a0,-838 # 80007018 <etext+0x18>
    80000366:	729040ef          	jal	8000528e <printf>
    printf("xv6 kernel is booting\n");
    8000036a:	00007517          	auipc	a0,0x7
    8000036e:	cb650513          	addi	a0,a0,-842 # 80007020 <etext+0x20>
    80000372:	71d040ef          	jal	8000528e <printf>
    printf("\n");
    80000376:	00007517          	auipc	a0,0x7
    8000037a:	ca250513          	addi	a0,a0,-862 # 80007018 <etext+0x18>
    8000037e:	711040ef          	jal	8000528e <printf>
    kinit();         // physical page allocator
    80000382:	d4fff0ef          	jal	800000d0 <kinit>
    kvminit();       // create kernel page table
    80000386:	2cc000ef          	jal	80000652 <kvminit>
    kvminithart();   // turn on paging
    8000038a:	03c000ef          	jal	800003c6 <kvminithart>
    procinit();      // process table
    8000038e:	10b000ef          	jal	80000c98 <procinit>
    trapinit();      // trap vectors
    80000392:	55e010ef          	jal	800018f0 <trapinit>
    trapinithart();  // install kernel trap vector
    80000396:	57e010ef          	jal	80001914 <trapinithart>
    plicinit();      // set up interrupt controller
    8000039a:	4b4040ef          	jal	8000484e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    8000039e:	4ca040ef          	jal	80004868 <plicinithart>
    binit();         // buffer cache
    800003a2:	421010ef          	jal	80001fc2 <binit>
    iinit();         // inode table
    800003a6:	1dc020ef          	jal	80002582 <iinit>
    fileinit();      // file table
    800003aa:	7c3020ef          	jal	8000336c <fileinit>
    virtio_disk_init(); // emulated hard disk
    800003ae:	5aa040ef          	jal	80004958 <virtio_disk_init>
    userinit();      // first user process
    800003b2:	46d000ef          	jal	8000101e <userinit>
    __sync_synchronize();
    800003b6:	0330000f          	fence	rw,rw
    started = 1;
    800003ba:	4785                	li	a5,1
    800003bc:	00007717          	auipc	a4,0x7
    800003c0:	54f72223          	sw	a5,1348(a4) # 80007900 <started>
    800003c4:	b779                	j	80000352 <main+0x3e>

00000000800003c6 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    800003c6:	1141                	addi	sp,sp,-16
    800003c8:	e406                	sd	ra,8(sp)
    800003ca:	e022                	sd	s0,0(sp)
    800003cc:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800003ce:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    800003d2:	00007797          	auipc	a5,0x7
    800003d6:	5367b783          	ld	a5,1334(a5) # 80007908 <kernel_pagetable>
    800003da:	83b1                	srli	a5,a5,0xc
    800003dc:	577d                	li	a4,-1
    800003de:	177e                	slli	a4,a4,0x3f
    800003e0:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800003e2:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800003e6:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    800003ea:	60a2                	ld	ra,8(sp)
    800003ec:	6402                	ld	s0,0(sp)
    800003ee:	0141                	addi	sp,sp,16
    800003f0:	8082                	ret

00000000800003f2 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800003f2:	7139                	addi	sp,sp,-64
    800003f4:	fc06                	sd	ra,56(sp)
    800003f6:	f822                	sd	s0,48(sp)
    800003f8:	f426                	sd	s1,40(sp)
    800003fa:	f04a                	sd	s2,32(sp)
    800003fc:	ec4e                	sd	s3,24(sp)
    800003fe:	e852                	sd	s4,16(sp)
    80000400:	e456                	sd	s5,8(sp)
    80000402:	e05a                	sd	s6,0(sp)
    80000404:	0080                	addi	s0,sp,64
    80000406:	84aa                	mv	s1,a0
    80000408:	89ae                	mv	s3,a1
    8000040a:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    8000040c:	57fd                	li	a5,-1
    8000040e:	83e9                	srli	a5,a5,0x1a
    80000410:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000412:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000414:	04b7e263          	bltu	a5,a1,80000458 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000418:	0149d933          	srl	s2,s3,s4
    8000041c:	1ff97913          	andi	s2,s2,511
    80000420:	090e                	slli	s2,s2,0x3
    80000422:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000424:	00093483          	ld	s1,0(s2)
    80000428:	0014f793          	andi	a5,s1,1
    8000042c:	cf85                	beqz	a5,80000464 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    8000042e:	80a9                	srli	s1,s1,0xa
    80000430:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80000432:	3a5d                	addiw	s4,s4,-9
    80000434:	ff5a12e3          	bne	s4,s5,80000418 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000438:	00c9d513          	srli	a0,s3,0xc
    8000043c:	1ff57513          	andi	a0,a0,511
    80000440:	050e                	slli	a0,a0,0x3
    80000442:	9526                	add	a0,a0,s1
}
    80000444:	70e2                	ld	ra,56(sp)
    80000446:	7442                	ld	s0,48(sp)
    80000448:	74a2                	ld	s1,40(sp)
    8000044a:	7902                	ld	s2,32(sp)
    8000044c:	69e2                	ld	s3,24(sp)
    8000044e:	6a42                	ld	s4,16(sp)
    80000450:	6aa2                	ld	s5,8(sp)
    80000452:	6b02                	ld	s6,0(sp)
    80000454:	6121                	addi	sp,sp,64
    80000456:	8082                	ret
    panic("walk");
    80000458:	00007517          	auipc	a0,0x7
    8000045c:	bf850513          	addi	a0,a0,-1032 # 80007050 <etext+0x50>
    80000460:	1c8050ef          	jal	80005628 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000464:	020b0263          	beqz	s6,80000488 <walk+0x96>
    80000468:	c9dff0ef          	jal	80000104 <kalloc>
    8000046c:	84aa                	mv	s1,a0
    8000046e:	d979                	beqz	a0,80000444 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80000470:	6605                	lui	a2,0x1
    80000472:	4581                	li	a1,0
    80000474:	cebff0ef          	jal	8000015e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000478:	00c4d793          	srli	a5,s1,0xc
    8000047c:	07aa                	slli	a5,a5,0xa
    8000047e:	0017e793          	ori	a5,a5,1
    80000482:	00f93023          	sd	a5,0(s2)
    80000486:	b775                	j	80000432 <walk+0x40>
        return 0;
    80000488:	4501                	li	a0,0
    8000048a:	bf6d                	j	80000444 <walk+0x52>

000000008000048c <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000048c:	57fd                	li	a5,-1
    8000048e:	83e9                	srli	a5,a5,0x1a
    80000490:	00b7f463          	bgeu	a5,a1,80000498 <walkaddr+0xc>
    return 0;
    80000494:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000496:	8082                	ret
{
    80000498:	1141                	addi	sp,sp,-16
    8000049a:	e406                	sd	ra,8(sp)
    8000049c:	e022                	sd	s0,0(sp)
    8000049e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    800004a0:	4601                	li	a2,0
    800004a2:	f51ff0ef          	jal	800003f2 <walk>
  if(pte == 0)
    800004a6:	c901                	beqz	a0,800004b6 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    800004a8:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    800004aa:	0117f693          	andi	a3,a5,17
    800004ae:	4745                	li	a4,17
    return 0;
    800004b0:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    800004b2:	00e68663          	beq	a3,a4,800004be <walkaddr+0x32>
}
    800004b6:	60a2                	ld	ra,8(sp)
    800004b8:	6402                	ld	s0,0(sp)
    800004ba:	0141                	addi	sp,sp,16
    800004bc:	8082                	ret
  pa = PTE2PA(*pte);
    800004be:	83a9                	srli	a5,a5,0xa
    800004c0:	00c79513          	slli	a0,a5,0xc
  return pa;
    800004c4:	bfcd                	j	800004b6 <walkaddr+0x2a>

00000000800004c6 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800004c6:	715d                	addi	sp,sp,-80
    800004c8:	e486                	sd	ra,72(sp)
    800004ca:	e0a2                	sd	s0,64(sp)
    800004cc:	fc26                	sd	s1,56(sp)
    800004ce:	f84a                	sd	s2,48(sp)
    800004d0:	f44e                	sd	s3,40(sp)
    800004d2:	f052                	sd	s4,32(sp)
    800004d4:	ec56                	sd	s5,24(sp)
    800004d6:	e85a                	sd	s6,16(sp)
    800004d8:	e45e                	sd	s7,8(sp)
    800004da:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800004dc:	03459793          	slli	a5,a1,0x34
    800004e0:	eba1                	bnez	a5,80000530 <mappages+0x6a>
    800004e2:	8a2a                	mv	s4,a0
    800004e4:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800004e6:	03461793          	slli	a5,a2,0x34
    800004ea:	eba9                	bnez	a5,8000053c <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    800004ec:	ce31                	beqz	a2,80000548 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800004ee:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    800004f2:	80060613          	addi	a2,a2,-2048
    800004f6:	00b60933          	add	s2,a2,a1
  a = va;
    800004fa:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800004fc:	4b05                	li	s6,1
    800004fe:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80000502:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    80000504:	865a                	mv	a2,s6
    80000506:	85a6                	mv	a1,s1
    80000508:	8552                	mv	a0,s4
    8000050a:	ee9ff0ef          	jal	800003f2 <walk>
    8000050e:	c929                	beqz	a0,80000560 <mappages+0x9a>
    if(*pte & PTE_V)
    80000510:	611c                	ld	a5,0(a0)
    80000512:	8b85                	andi	a5,a5,1
    80000514:	e3a1                	bnez	a5,80000554 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000516:	013487b3          	add	a5,s1,s3
    8000051a:	83b1                	srli	a5,a5,0xc
    8000051c:	07aa                	slli	a5,a5,0xa
    8000051e:	0157e7b3          	or	a5,a5,s5
    80000522:	0017e793          	ori	a5,a5,1
    80000526:	e11c                	sd	a5,0(a0)
    if(a == last)
    80000528:	05248863          	beq	s1,s2,80000578 <mappages+0xb2>
    a += PGSIZE;
    8000052c:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    8000052e:	bfd9                	j	80000504 <mappages+0x3e>
    panic("mappages: va not aligned");
    80000530:	00007517          	auipc	a0,0x7
    80000534:	b2850513          	addi	a0,a0,-1240 # 80007058 <etext+0x58>
    80000538:	0f0050ef          	jal	80005628 <panic>
    panic("mappages: size not aligned");
    8000053c:	00007517          	auipc	a0,0x7
    80000540:	b3c50513          	addi	a0,a0,-1220 # 80007078 <etext+0x78>
    80000544:	0e4050ef          	jal	80005628 <panic>
    panic("mappages: size");
    80000548:	00007517          	auipc	a0,0x7
    8000054c:	b5050513          	addi	a0,a0,-1200 # 80007098 <etext+0x98>
    80000550:	0d8050ef          	jal	80005628 <panic>
      panic("mappages: remap");
    80000554:	00007517          	auipc	a0,0x7
    80000558:	b5450513          	addi	a0,a0,-1196 # 800070a8 <etext+0xa8>
    8000055c:	0cc050ef          	jal	80005628 <panic>
      return -1;
    80000560:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80000562:	60a6                	ld	ra,72(sp)
    80000564:	6406                	ld	s0,64(sp)
    80000566:	74e2                	ld	s1,56(sp)
    80000568:	7942                	ld	s2,48(sp)
    8000056a:	79a2                	ld	s3,40(sp)
    8000056c:	7a02                	ld	s4,32(sp)
    8000056e:	6ae2                	ld	s5,24(sp)
    80000570:	6b42                	ld	s6,16(sp)
    80000572:	6ba2                	ld	s7,8(sp)
    80000574:	6161                	addi	sp,sp,80
    80000576:	8082                	ret
  return 0;
    80000578:	4501                	li	a0,0
    8000057a:	b7e5                	j	80000562 <mappages+0x9c>

000000008000057c <kvmmap>:
{
    8000057c:	1141                	addi	sp,sp,-16
    8000057e:	e406                	sd	ra,8(sp)
    80000580:	e022                	sd	s0,0(sp)
    80000582:	0800                	addi	s0,sp,16
    80000584:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000586:	86b2                	mv	a3,a2
    80000588:	863e                	mv	a2,a5
    8000058a:	f3dff0ef          	jal	800004c6 <mappages>
    8000058e:	e509                	bnez	a0,80000598 <kvmmap+0x1c>
}
    80000590:	60a2                	ld	ra,8(sp)
    80000592:	6402                	ld	s0,0(sp)
    80000594:	0141                	addi	sp,sp,16
    80000596:	8082                	ret
    panic("kvmmap");
    80000598:	00007517          	auipc	a0,0x7
    8000059c:	b2050513          	addi	a0,a0,-1248 # 800070b8 <etext+0xb8>
    800005a0:	088050ef          	jal	80005628 <panic>

00000000800005a4 <kvmmake>:
{
    800005a4:	1101                	addi	sp,sp,-32
    800005a6:	ec06                	sd	ra,24(sp)
    800005a8:	e822                	sd	s0,16(sp)
    800005aa:	e426                	sd	s1,8(sp)
    800005ac:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800005ae:	b57ff0ef          	jal	80000104 <kalloc>
    800005b2:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800005b4:	6605                	lui	a2,0x1
    800005b6:	4581                	li	a1,0
    800005b8:	ba7ff0ef          	jal	8000015e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800005bc:	4719                	li	a4,6
    800005be:	6685                	lui	a3,0x1
    800005c0:	10000637          	lui	a2,0x10000
    800005c4:	85b2                	mv	a1,a2
    800005c6:	8526                	mv	a0,s1
    800005c8:	fb5ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800005cc:	4719                	li	a4,6
    800005ce:	6685                	lui	a3,0x1
    800005d0:	10001637          	lui	a2,0x10001
    800005d4:	85b2                	mv	a1,a2
    800005d6:	8526                	mv	a0,s1
    800005d8:	fa5ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800005dc:	4719                	li	a4,6
    800005de:	040006b7          	lui	a3,0x4000
    800005e2:	0c000637          	lui	a2,0xc000
    800005e6:	85b2                	mv	a1,a2
    800005e8:	8526                	mv	a0,s1
    800005ea:	f93ff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800005ee:	4729                	li	a4,10
    800005f0:	80007697          	auipc	a3,0x80007
    800005f4:	a1068693          	addi	a3,a3,-1520 # 7000 <_entry-0x7fff9000>
    800005f8:	4605                	li	a2,1
    800005fa:	067e                	slli	a2,a2,0x1f
    800005fc:	85b2                	mv	a1,a2
    800005fe:	8526                	mv	a0,s1
    80000600:	f7dff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80000604:	4719                	li	a4,6
    80000606:	00007697          	auipc	a3,0x7
    8000060a:	9fa68693          	addi	a3,a3,-1542 # 80007000 <etext>
    8000060e:	47c5                	li	a5,17
    80000610:	07ee                	slli	a5,a5,0x1b
    80000612:	40d786b3          	sub	a3,a5,a3
    80000616:	00007617          	auipc	a2,0x7
    8000061a:	9ea60613          	addi	a2,a2,-1558 # 80007000 <etext>
    8000061e:	85b2                	mv	a1,a2
    80000620:	8526                	mv	a0,s1
    80000622:	f5bff0ef          	jal	8000057c <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80000626:	4729                	li	a4,10
    80000628:	6685                	lui	a3,0x1
    8000062a:	00006617          	auipc	a2,0x6
    8000062e:	9d660613          	addi	a2,a2,-1578 # 80006000 <_trampoline>
    80000632:	040005b7          	lui	a1,0x4000
    80000636:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000638:	05b2                	slli	a1,a1,0xc
    8000063a:	8526                	mv	a0,s1
    8000063c:	f41ff0ef          	jal	8000057c <kvmmap>
  proc_mapstacks(kpgtbl);
    80000640:	8526                	mv	a0,s1
    80000642:	5b2000ef          	jal	80000bf4 <proc_mapstacks>
}
    80000646:	8526                	mv	a0,s1
    80000648:	60e2                	ld	ra,24(sp)
    8000064a:	6442                	ld	s0,16(sp)
    8000064c:	64a2                	ld	s1,8(sp)
    8000064e:	6105                	addi	sp,sp,32
    80000650:	8082                	ret

0000000080000652 <kvminit>:
{
    80000652:	1141                	addi	sp,sp,-16
    80000654:	e406                	sd	ra,8(sp)
    80000656:	e022                	sd	s0,0(sp)
    80000658:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000065a:	f4bff0ef          	jal	800005a4 <kvmmake>
    8000065e:	00007797          	auipc	a5,0x7
    80000662:	2aa7b523          	sd	a0,682(a5) # 80007908 <kernel_pagetable>
}
    80000666:	60a2                	ld	ra,8(sp)
    80000668:	6402                	ld	s0,0(sp)
    8000066a:	0141                	addi	sp,sp,16
    8000066c:	8082                	ret

000000008000066e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000066e:	715d                	addi	sp,sp,-80
    80000670:	e486                	sd	ra,72(sp)
    80000672:	e0a2                	sd	s0,64(sp)
    80000674:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80000676:	03459793          	slli	a5,a1,0x34
    8000067a:	e39d                	bnez	a5,800006a0 <uvmunmap+0x32>
    8000067c:	f84a                	sd	s2,48(sp)
    8000067e:	f44e                	sd	s3,40(sp)
    80000680:	f052                	sd	s4,32(sp)
    80000682:	ec56                	sd	s5,24(sp)
    80000684:	e85a                	sd	s6,16(sp)
    80000686:	e45e                	sd	s7,8(sp)
    80000688:	8a2a                	mv	s4,a0
    8000068a:	892e                	mv	s2,a1
    8000068c:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000068e:	0632                	slli	a2,a2,0xc
    80000690:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    80000694:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80000696:	6b05                	lui	s6,0x1
    80000698:	0735ff63          	bgeu	a1,s3,80000716 <uvmunmap+0xa8>
    8000069c:	fc26                	sd	s1,56(sp)
    8000069e:	a0a9                	j	800006e8 <uvmunmap+0x7a>
    800006a0:	fc26                	sd	s1,56(sp)
    800006a2:	f84a                	sd	s2,48(sp)
    800006a4:	f44e                	sd	s3,40(sp)
    800006a6:	f052                	sd	s4,32(sp)
    800006a8:	ec56                	sd	s5,24(sp)
    800006aa:	e85a                	sd	s6,16(sp)
    800006ac:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    800006ae:	00007517          	auipc	a0,0x7
    800006b2:	a1250513          	addi	a0,a0,-1518 # 800070c0 <etext+0xc0>
    800006b6:	773040ef          	jal	80005628 <panic>
      panic("uvmunmap: walk");
    800006ba:	00007517          	auipc	a0,0x7
    800006be:	a1e50513          	addi	a0,a0,-1506 # 800070d8 <etext+0xd8>
    800006c2:	767040ef          	jal	80005628 <panic>
      panic("uvmunmap: not mapped");
    800006c6:	00007517          	auipc	a0,0x7
    800006ca:	a2250513          	addi	a0,a0,-1502 # 800070e8 <etext+0xe8>
    800006ce:	75b040ef          	jal	80005628 <panic>
      panic("uvmunmap: not a leaf");
    800006d2:	00007517          	auipc	a0,0x7
    800006d6:	a2e50513          	addi	a0,a0,-1490 # 80007100 <etext+0x100>
    800006da:	74f040ef          	jal	80005628 <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    800006de:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800006e2:	995a                	add	s2,s2,s6
    800006e4:	03397863          	bgeu	s2,s3,80000714 <uvmunmap+0xa6>
    if((pte = walk(pagetable, a, 0)) == 0)
    800006e8:	4601                	li	a2,0
    800006ea:	85ca                	mv	a1,s2
    800006ec:	8552                	mv	a0,s4
    800006ee:	d05ff0ef          	jal	800003f2 <walk>
    800006f2:	84aa                	mv	s1,a0
    800006f4:	d179                	beqz	a0,800006ba <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0)
    800006f6:	6108                	ld	a0,0(a0)
    800006f8:	00157793          	andi	a5,a0,1
    800006fc:	d7e9                	beqz	a5,800006c6 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    800006fe:	3ff57793          	andi	a5,a0,1023
    80000702:	fd7788e3          	beq	a5,s7,800006d2 <uvmunmap+0x64>
    if(do_free){
    80000706:	fc0a8ce3          	beqz	s5,800006de <uvmunmap+0x70>
      uint64 pa = PTE2PA(*pte);
    8000070a:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    8000070c:	0532                	slli	a0,a0,0xc
    8000070e:	90fff0ef          	jal	8000001c <kfree>
    80000712:	b7f1                	j	800006de <uvmunmap+0x70>
    80000714:	74e2                	ld	s1,56(sp)
    80000716:	7942                	ld	s2,48(sp)
    80000718:	79a2                	ld	s3,40(sp)
    8000071a:	7a02                	ld	s4,32(sp)
    8000071c:	6ae2                	ld	s5,24(sp)
    8000071e:	6b42                	ld	s6,16(sp)
    80000720:	6ba2                	ld	s7,8(sp)
  }
}
    80000722:	60a6                	ld	ra,72(sp)
    80000724:	6406                	ld	s0,64(sp)
    80000726:	6161                	addi	sp,sp,80
    80000728:	8082                	ret

000000008000072a <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000072a:	1101                	addi	sp,sp,-32
    8000072c:	ec06                	sd	ra,24(sp)
    8000072e:	e822                	sd	s0,16(sp)
    80000730:	e426                	sd	s1,8(sp)
    80000732:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80000734:	9d1ff0ef          	jal	80000104 <kalloc>
    80000738:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000073a:	c509                	beqz	a0,80000744 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000073c:	6605                	lui	a2,0x1
    8000073e:	4581                	li	a1,0
    80000740:	a1fff0ef          	jal	8000015e <memset>
  return pagetable;
}
    80000744:	8526                	mv	a0,s1
    80000746:	60e2                	ld	ra,24(sp)
    80000748:	6442                	ld	s0,16(sp)
    8000074a:	64a2                	ld	s1,8(sp)
    8000074c:	6105                	addi	sp,sp,32
    8000074e:	8082                	ret

0000000080000750 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80000750:	7179                	addi	sp,sp,-48
    80000752:	f406                	sd	ra,40(sp)
    80000754:	f022                	sd	s0,32(sp)
    80000756:	ec26                	sd	s1,24(sp)
    80000758:	e84a                	sd	s2,16(sp)
    8000075a:	e44e                	sd	s3,8(sp)
    8000075c:	e052                	sd	s4,0(sp)
    8000075e:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80000760:	6785                	lui	a5,0x1
    80000762:	04f67063          	bgeu	a2,a5,800007a2 <uvmfirst+0x52>
    80000766:	89aa                	mv	s3,a0
    80000768:	8a2e                	mv	s4,a1
    8000076a:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    8000076c:	999ff0ef          	jal	80000104 <kalloc>
    80000770:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000772:	6605                	lui	a2,0x1
    80000774:	4581                	li	a1,0
    80000776:	9e9ff0ef          	jal	8000015e <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    8000077a:	4779                	li	a4,30
    8000077c:	86ca                	mv	a3,s2
    8000077e:	6605                	lui	a2,0x1
    80000780:	4581                	li	a1,0
    80000782:	854e                	mv	a0,s3
    80000784:	d43ff0ef          	jal	800004c6 <mappages>
  memmove(mem, src, sz);
    80000788:	8626                	mv	a2,s1
    8000078a:	85d2                	mv	a1,s4
    8000078c:	854a                	mv	a0,s2
    8000078e:	a31ff0ef          	jal	800001be <memmove>
}
    80000792:	70a2                	ld	ra,40(sp)
    80000794:	7402                	ld	s0,32(sp)
    80000796:	64e2                	ld	s1,24(sp)
    80000798:	6942                	ld	s2,16(sp)
    8000079a:	69a2                	ld	s3,8(sp)
    8000079c:	6a02                	ld	s4,0(sp)
    8000079e:	6145                	addi	sp,sp,48
    800007a0:	8082                	ret
    panic("uvmfirst: more than a page");
    800007a2:	00007517          	auipc	a0,0x7
    800007a6:	97650513          	addi	a0,a0,-1674 # 80007118 <etext+0x118>
    800007aa:	67f040ef          	jal	80005628 <panic>

00000000800007ae <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800007ae:	1101                	addi	sp,sp,-32
    800007b0:	ec06                	sd	ra,24(sp)
    800007b2:	e822                	sd	s0,16(sp)
    800007b4:	e426                	sd	s1,8(sp)
    800007b6:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800007b8:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800007ba:	00b67d63          	bgeu	a2,a1,800007d4 <uvmdealloc+0x26>
    800007be:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800007c0:	6785                	lui	a5,0x1
    800007c2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800007c4:	00f60733          	add	a4,a2,a5
    800007c8:	76fd                	lui	a3,0xfffff
    800007ca:	8f75                	and	a4,a4,a3
    800007cc:	97ae                	add	a5,a5,a1
    800007ce:	8ff5                	and	a5,a5,a3
    800007d0:	00f76863          	bltu	a4,a5,800007e0 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800007d4:	8526                	mv	a0,s1
    800007d6:	60e2                	ld	ra,24(sp)
    800007d8:	6442                	ld	s0,16(sp)
    800007da:	64a2                	ld	s1,8(sp)
    800007dc:	6105                	addi	sp,sp,32
    800007de:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800007e0:	8f99                	sub	a5,a5,a4
    800007e2:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800007e4:	4685                	li	a3,1
    800007e6:	0007861b          	sext.w	a2,a5
    800007ea:	85ba                	mv	a1,a4
    800007ec:	e83ff0ef          	jal	8000066e <uvmunmap>
    800007f0:	b7d5                	j	800007d4 <uvmdealloc+0x26>

00000000800007f2 <uvmalloc>:
  if(newsz < oldsz)
    800007f2:	0ab66163          	bltu	a2,a1,80000894 <uvmalloc+0xa2>
{
    800007f6:	715d                	addi	sp,sp,-80
    800007f8:	e486                	sd	ra,72(sp)
    800007fa:	e0a2                	sd	s0,64(sp)
    800007fc:	f84a                	sd	s2,48(sp)
    800007fe:	f052                	sd	s4,32(sp)
    80000800:	ec56                	sd	s5,24(sp)
    80000802:	e45e                	sd	s7,8(sp)
    80000804:	0880                	addi	s0,sp,80
    80000806:	8aaa                	mv	s5,a0
    80000808:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000080a:	6785                	lui	a5,0x1
    8000080c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000080e:	95be                	add	a1,a1,a5
    80000810:	77fd                	lui	a5,0xfffff
    80000812:	00f5f933          	and	s2,a1,a5
    80000816:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000818:	08c97063          	bgeu	s2,a2,80000898 <uvmalloc+0xa6>
    8000081c:	fc26                	sd	s1,56(sp)
    8000081e:	f44e                	sd	s3,40(sp)
    80000820:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    80000822:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000824:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80000828:	8ddff0ef          	jal	80000104 <kalloc>
    8000082c:	84aa                	mv	s1,a0
    if(mem == 0){
    8000082e:	c50d                	beqz	a0,80000858 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    80000830:	864e                	mv	a2,s3
    80000832:	4581                	li	a1,0
    80000834:	92bff0ef          	jal	8000015e <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000838:	875a                	mv	a4,s6
    8000083a:	86a6                	mv	a3,s1
    8000083c:	864e                	mv	a2,s3
    8000083e:	85ca                	mv	a1,s2
    80000840:	8556                	mv	a0,s5
    80000842:	c85ff0ef          	jal	800004c6 <mappages>
    80000846:	e915                	bnez	a0,8000087a <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000848:	994e                	add	s2,s2,s3
    8000084a:	fd496fe3          	bltu	s2,s4,80000828 <uvmalloc+0x36>
  return newsz;
    8000084e:	8552                	mv	a0,s4
    80000850:	74e2                	ld	s1,56(sp)
    80000852:	79a2                	ld	s3,40(sp)
    80000854:	6b42                	ld	s6,16(sp)
    80000856:	a811                	j	8000086a <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80000858:	865e                	mv	a2,s7
    8000085a:	85ca                	mv	a1,s2
    8000085c:	8556                	mv	a0,s5
    8000085e:	f51ff0ef          	jal	800007ae <uvmdealloc>
      return 0;
    80000862:	4501                	li	a0,0
    80000864:	74e2                	ld	s1,56(sp)
    80000866:	79a2                	ld	s3,40(sp)
    80000868:	6b42                	ld	s6,16(sp)
}
    8000086a:	60a6                	ld	ra,72(sp)
    8000086c:	6406                	ld	s0,64(sp)
    8000086e:	7942                	ld	s2,48(sp)
    80000870:	7a02                	ld	s4,32(sp)
    80000872:	6ae2                	ld	s5,24(sp)
    80000874:	6ba2                	ld	s7,8(sp)
    80000876:	6161                	addi	sp,sp,80
    80000878:	8082                	ret
      kfree(mem);
    8000087a:	8526                	mv	a0,s1
    8000087c:	fa0ff0ef          	jal	8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80000880:	865e                	mv	a2,s7
    80000882:	85ca                	mv	a1,s2
    80000884:	8556                	mv	a0,s5
    80000886:	f29ff0ef          	jal	800007ae <uvmdealloc>
      return 0;
    8000088a:	4501                	li	a0,0
    8000088c:	74e2                	ld	s1,56(sp)
    8000088e:	79a2                	ld	s3,40(sp)
    80000890:	6b42                	ld	s6,16(sp)
    80000892:	bfe1                	j	8000086a <uvmalloc+0x78>
    return oldsz;
    80000894:	852e                	mv	a0,a1
}
    80000896:	8082                	ret
  return newsz;
    80000898:	8532                	mv	a0,a2
    8000089a:	bfc1                	j	8000086a <uvmalloc+0x78>

000000008000089c <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000089c:	7179                	addi	sp,sp,-48
    8000089e:	f406                	sd	ra,40(sp)
    800008a0:	f022                	sd	s0,32(sp)
    800008a2:	ec26                	sd	s1,24(sp)
    800008a4:	e84a                	sd	s2,16(sp)
    800008a6:	e44e                	sd	s3,8(sp)
    800008a8:	1800                	addi	s0,sp,48
    800008aa:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800008ac:	84aa                	mv	s1,a0
    800008ae:	6905                	lui	s2,0x1
    800008b0:	992a                	add	s2,s2,a0
    800008b2:	a811                	j	800008c6 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    800008b4:	00007517          	auipc	a0,0x7
    800008b8:	88450513          	addi	a0,a0,-1916 # 80007138 <etext+0x138>
    800008bc:	56d040ef          	jal	80005628 <panic>
  for(int i = 0; i < 512; i++){
    800008c0:	04a1                	addi	s1,s1,8
    800008c2:	03248163          	beq	s1,s2,800008e4 <freewalk+0x48>
    pte_t pte = pagetable[i];
    800008c6:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800008c8:	0017f713          	andi	a4,a5,1
    800008cc:	db75                	beqz	a4,800008c0 <freewalk+0x24>
    800008ce:	00e7f713          	andi	a4,a5,14
    800008d2:	f36d                	bnez	a4,800008b4 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800008d4:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800008d6:	00c79513          	slli	a0,a5,0xc
    800008da:	fc3ff0ef          	jal	8000089c <freewalk>
      pagetable[i] = 0;
    800008de:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800008e2:	bff9                	j	800008c0 <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800008e4:	854e                	mv	a0,s3
    800008e6:	f36ff0ef          	jal	8000001c <kfree>
}
    800008ea:	70a2                	ld	ra,40(sp)
    800008ec:	7402                	ld	s0,32(sp)
    800008ee:	64e2                	ld	s1,24(sp)
    800008f0:	6942                	ld	s2,16(sp)
    800008f2:	69a2                	ld	s3,8(sp)
    800008f4:	6145                	addi	sp,sp,48
    800008f6:	8082                	ret

00000000800008f8 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800008f8:	1101                	addi	sp,sp,-32
    800008fa:	ec06                	sd	ra,24(sp)
    800008fc:	e822                	sd	s0,16(sp)
    800008fe:	e426                	sd	s1,8(sp)
    80000900:	1000                	addi	s0,sp,32
    80000902:	84aa                	mv	s1,a0
  if(sz > 0)
    80000904:	e989                	bnez	a1,80000916 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80000906:	8526                	mv	a0,s1
    80000908:	f95ff0ef          	jal	8000089c <freewalk>
}
    8000090c:	60e2                	ld	ra,24(sp)
    8000090e:	6442                	ld	s0,16(sp)
    80000910:	64a2                	ld	s1,8(sp)
    80000912:	6105                	addi	sp,sp,32
    80000914:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80000916:	6785                	lui	a5,0x1
    80000918:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000091a:	95be                	add	a1,a1,a5
    8000091c:	4685                	li	a3,1
    8000091e:	00c5d613          	srli	a2,a1,0xc
    80000922:	4581                	li	a1,0
    80000924:	d4bff0ef          	jal	8000066e <uvmunmap>
    80000928:	bff9                	j	80000906 <uvmfree+0xe>

000000008000092a <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    8000092a:	c64d                	beqz	a2,800009d4 <uvmcopy+0xaa>
{
    8000092c:	715d                	addi	sp,sp,-80
    8000092e:	e486                	sd	ra,72(sp)
    80000930:	e0a2                	sd	s0,64(sp)
    80000932:	fc26                	sd	s1,56(sp)
    80000934:	f84a                	sd	s2,48(sp)
    80000936:	f44e                	sd	s3,40(sp)
    80000938:	f052                	sd	s4,32(sp)
    8000093a:	ec56                	sd	s5,24(sp)
    8000093c:	e85a                	sd	s6,16(sp)
    8000093e:	e45e                	sd	s7,8(sp)
    80000940:	0880                	addi	s0,sp,80
    80000942:	8b2a                	mv	s6,a0
    80000944:	8aae                	mv	s5,a1
    80000946:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80000948:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    8000094a:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    8000094c:	4601                	li	a2,0
    8000094e:	85ca                	mv	a1,s2
    80000950:	855a                	mv	a0,s6
    80000952:	aa1ff0ef          	jal	800003f2 <walk>
    80000956:	cd0d                	beqz	a0,80000990 <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    80000958:	00053b83          	ld	s7,0(a0)
    8000095c:	001bf793          	andi	a5,s7,1
    80000960:	cf95                	beqz	a5,8000099c <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    80000962:	fa2ff0ef          	jal	80000104 <kalloc>
    80000966:	84aa                	mv	s1,a0
    80000968:	c139                	beqz	a0,800009ae <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    8000096a:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    8000096e:	864e                	mv	a2,s3
    80000970:	05b2                	slli	a1,a1,0xc
    80000972:	84dff0ef          	jal	800001be <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80000976:	3ffbf713          	andi	a4,s7,1023
    8000097a:	86a6                	mv	a3,s1
    8000097c:	864e                	mv	a2,s3
    8000097e:	85ca                	mv	a1,s2
    80000980:	8556                	mv	a0,s5
    80000982:	b45ff0ef          	jal	800004c6 <mappages>
    80000986:	e10d                	bnez	a0,800009a8 <uvmcopy+0x7e>
  for(i = 0; i < sz; i += PGSIZE){
    80000988:	994e                	add	s2,s2,s3
    8000098a:	fd4961e3          	bltu	s2,s4,8000094c <uvmcopy+0x22>
    8000098e:	a805                	j	800009be <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    80000990:	00006517          	auipc	a0,0x6
    80000994:	7b850513          	addi	a0,a0,1976 # 80007148 <etext+0x148>
    80000998:	491040ef          	jal	80005628 <panic>
      panic("uvmcopy: page not present");
    8000099c:	00006517          	auipc	a0,0x6
    800009a0:	7cc50513          	addi	a0,a0,1996 # 80007168 <etext+0x168>
    800009a4:	485040ef          	jal	80005628 <panic>
      kfree(mem);
    800009a8:	8526                	mv	a0,s1
    800009aa:	e72ff0ef          	jal	8000001c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800009ae:	4685                	li	a3,1
    800009b0:	00c95613          	srli	a2,s2,0xc
    800009b4:	4581                	li	a1,0
    800009b6:	8556                	mv	a0,s5
    800009b8:	cb7ff0ef          	jal	8000066e <uvmunmap>
  return -1;
    800009bc:	557d                	li	a0,-1
}
    800009be:	60a6                	ld	ra,72(sp)
    800009c0:	6406                	ld	s0,64(sp)
    800009c2:	74e2                	ld	s1,56(sp)
    800009c4:	7942                	ld	s2,48(sp)
    800009c6:	79a2                	ld	s3,40(sp)
    800009c8:	7a02                	ld	s4,32(sp)
    800009ca:	6ae2                	ld	s5,24(sp)
    800009cc:	6b42                	ld	s6,16(sp)
    800009ce:	6ba2                	ld	s7,8(sp)
    800009d0:	6161                	addi	sp,sp,80
    800009d2:	8082                	ret
  return 0;
    800009d4:	4501                	li	a0,0
}
    800009d6:	8082                	ret

00000000800009d8 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800009d8:	1141                	addi	sp,sp,-16
    800009da:	e406                	sd	ra,8(sp)
    800009dc:	e022                	sd	s0,0(sp)
    800009de:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800009e0:	4601                	li	a2,0
    800009e2:	a11ff0ef          	jal	800003f2 <walk>
  if(pte == 0)
    800009e6:	c901                	beqz	a0,800009f6 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800009e8:	611c                	ld	a5,0(a0)
    800009ea:	9bbd                	andi	a5,a5,-17
    800009ec:	e11c                	sd	a5,0(a0)
}
    800009ee:	60a2                	ld	ra,8(sp)
    800009f0:	6402                	ld	s0,0(sp)
    800009f2:	0141                	addi	sp,sp,16
    800009f4:	8082                	ret
    panic("uvmclear");
    800009f6:	00006517          	auipc	a0,0x6
    800009fa:	79250513          	addi	a0,a0,1938 # 80007188 <etext+0x188>
    800009fe:	42b040ef          	jal	80005628 <panic>

0000000080000a02 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    80000a02:	c2d9                	beqz	a3,80000a88 <copyout+0x86>
{
    80000a04:	711d                	addi	sp,sp,-96
    80000a06:	ec86                	sd	ra,88(sp)
    80000a08:	e8a2                	sd	s0,80(sp)
    80000a0a:	e4a6                	sd	s1,72(sp)
    80000a0c:	e0ca                	sd	s2,64(sp)
    80000a0e:	fc4e                	sd	s3,56(sp)
    80000a10:	f852                	sd	s4,48(sp)
    80000a12:	f456                	sd	s5,40(sp)
    80000a14:	f05a                	sd	s6,32(sp)
    80000a16:	ec5e                	sd	s7,24(sp)
    80000a18:	e862                	sd	s8,16(sp)
    80000a1a:	e466                	sd	s9,8(sp)
    80000a1c:	e06a                	sd	s10,0(sp)
    80000a1e:	1080                	addi	s0,sp,96
    80000a20:	8c2a                	mv	s8,a0
    80000a22:	892e                	mv	s2,a1
    80000a24:	8ab2                	mv	s5,a2
    80000a26:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80000a28:	7cfd                	lui	s9,0xfffff
    if(va0 >= MAXVA)
    80000a2a:	5bfd                	li	s7,-1
    80000a2c:	01abdb93          	srli	s7,s7,0x1a
      return -1;
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000a30:	4d55                	li	s10,21
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    n = PGSIZE - (dstva - va0);
    80000a32:	6b05                	lui	s6,0x1
    80000a34:	a015                	j	80000a58 <copyout+0x56>
    pa0 = PTE2PA(*pte);
    80000a36:	83a9                	srli	a5,a5,0xa
    80000a38:	07b2                	slli	a5,a5,0xc
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000a3a:	41390533          	sub	a0,s2,s3
    80000a3e:	0004861b          	sext.w	a2,s1
    80000a42:	85d6                	mv	a1,s5
    80000a44:	953e                	add	a0,a0,a5
    80000a46:	f78ff0ef          	jal	800001be <memmove>

    len -= n;
    80000a4a:	409a0a33          	sub	s4,s4,s1
    src += n;
    80000a4e:	9aa6                	add	s5,s5,s1
    dstva = va0 + PGSIZE;
    80000a50:	01698933          	add	s2,s3,s6
  while(len > 0){
    80000a54:	020a0863          	beqz	s4,80000a84 <copyout+0x82>
    va0 = PGROUNDDOWN(dstva);
    80000a58:	019979b3          	and	s3,s2,s9
    if(va0 >= MAXVA)
    80000a5c:	033be863          	bltu	s7,s3,80000a8c <copyout+0x8a>
    pte = walk(pagetable, va0, 0);
    80000a60:	4601                	li	a2,0
    80000a62:	85ce                	mv	a1,s3
    80000a64:	8562                	mv	a0,s8
    80000a66:	98dff0ef          	jal	800003f2 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000a6a:	c11d                	beqz	a0,80000a90 <copyout+0x8e>
    80000a6c:	611c                	ld	a5,0(a0)
    80000a6e:	0157f713          	andi	a4,a5,21
    80000a72:	03a71163          	bne	a4,s10,80000a94 <copyout+0x92>
    n = PGSIZE - (dstva - va0);
    80000a76:	412984b3          	sub	s1,s3,s2
    80000a7a:	94da                	add	s1,s1,s6
    if(n > len)
    80000a7c:	fa9a7de3          	bgeu	s4,s1,80000a36 <copyout+0x34>
    80000a80:	84d2                	mv	s1,s4
    80000a82:	bf55                	j	80000a36 <copyout+0x34>
  }
  return 0;
    80000a84:	4501                	li	a0,0
    80000a86:	a801                	j	80000a96 <copyout+0x94>
    80000a88:	4501                	li	a0,0
}
    80000a8a:	8082                	ret
      return -1;
    80000a8c:	557d                	li	a0,-1
    80000a8e:	a021                	j	80000a96 <copyout+0x94>
      return -1;
    80000a90:	557d                	li	a0,-1
    80000a92:	a011                	j	80000a96 <copyout+0x94>
    80000a94:	557d                	li	a0,-1
}
    80000a96:	60e6                	ld	ra,88(sp)
    80000a98:	6446                	ld	s0,80(sp)
    80000a9a:	64a6                	ld	s1,72(sp)
    80000a9c:	6906                	ld	s2,64(sp)
    80000a9e:	79e2                	ld	s3,56(sp)
    80000aa0:	7a42                	ld	s4,48(sp)
    80000aa2:	7aa2                	ld	s5,40(sp)
    80000aa4:	7b02                	ld	s6,32(sp)
    80000aa6:	6be2                	ld	s7,24(sp)
    80000aa8:	6c42                	ld	s8,16(sp)
    80000aaa:	6ca2                	ld	s9,8(sp)
    80000aac:	6d02                	ld	s10,0(sp)
    80000aae:	6125                	addi	sp,sp,96
    80000ab0:	8082                	ret

0000000080000ab2 <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80000ab2:	c6a5                	beqz	a3,80000b1a <copyin+0x68>
{
    80000ab4:	715d                	addi	sp,sp,-80
    80000ab6:	e486                	sd	ra,72(sp)
    80000ab8:	e0a2                	sd	s0,64(sp)
    80000aba:	fc26                	sd	s1,56(sp)
    80000abc:	f84a                	sd	s2,48(sp)
    80000abe:	f44e                	sd	s3,40(sp)
    80000ac0:	f052                	sd	s4,32(sp)
    80000ac2:	ec56                	sd	s5,24(sp)
    80000ac4:	e85a                	sd	s6,16(sp)
    80000ac6:	e45e                	sd	s7,8(sp)
    80000ac8:	e062                	sd	s8,0(sp)
    80000aca:	0880                	addi	s0,sp,80
    80000acc:	8b2a                	mv	s6,a0
    80000ace:	8a2e                	mv	s4,a1
    80000ad0:	8c32                	mv	s8,a2
    80000ad2:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000ad4:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000ad6:	6a85                	lui	s5,0x1
    80000ad8:	a00d                	j	80000afa <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000ada:	018505b3          	add	a1,a0,s8
    80000ade:	0004861b          	sext.w	a2,s1
    80000ae2:	412585b3          	sub	a1,a1,s2
    80000ae6:	8552                	mv	a0,s4
    80000ae8:	ed6ff0ef          	jal	800001be <memmove>

    len -= n;
    80000aec:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000af0:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000af2:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000af6:	02098063          	beqz	s3,80000b16 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000afa:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000afe:	85ca                	mv	a1,s2
    80000b00:	855a                	mv	a0,s6
    80000b02:	98bff0ef          	jal	8000048c <walkaddr>
    if(pa0 == 0)
    80000b06:	cd01                	beqz	a0,80000b1e <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000b08:	418904b3          	sub	s1,s2,s8
    80000b0c:	94d6                	add	s1,s1,s5
    if(n > len)
    80000b0e:	fc99f6e3          	bgeu	s3,s1,80000ada <copyin+0x28>
    80000b12:	84ce                	mv	s1,s3
    80000b14:	b7d9                	j	80000ada <copyin+0x28>
  }
  return 0;
    80000b16:	4501                	li	a0,0
    80000b18:	a021                	j	80000b20 <copyin+0x6e>
    80000b1a:	4501                	li	a0,0
}
    80000b1c:	8082                	ret
      return -1;
    80000b1e:	557d                	li	a0,-1
}
    80000b20:	60a6                	ld	ra,72(sp)
    80000b22:	6406                	ld	s0,64(sp)
    80000b24:	74e2                	ld	s1,56(sp)
    80000b26:	7942                	ld	s2,48(sp)
    80000b28:	79a2                	ld	s3,40(sp)
    80000b2a:	7a02                	ld	s4,32(sp)
    80000b2c:	6ae2                	ld	s5,24(sp)
    80000b2e:	6b42                	ld	s6,16(sp)
    80000b30:	6ba2                	ld	s7,8(sp)
    80000b32:	6c02                	ld	s8,0(sp)
    80000b34:	6161                	addi	sp,sp,80
    80000b36:	8082                	ret

0000000080000b38 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000b38:	cac5                	beqz	a3,80000be8 <copyinstr+0xb0>
{
    80000b3a:	715d                	addi	sp,sp,-80
    80000b3c:	e486                	sd	ra,72(sp)
    80000b3e:	e0a2                	sd	s0,64(sp)
    80000b40:	fc26                	sd	s1,56(sp)
    80000b42:	f84a                	sd	s2,48(sp)
    80000b44:	f44e                	sd	s3,40(sp)
    80000b46:	f052                	sd	s4,32(sp)
    80000b48:	ec56                	sd	s5,24(sp)
    80000b4a:	e85a                	sd	s6,16(sp)
    80000b4c:	e45e                	sd	s7,8(sp)
    80000b4e:	0880                	addi	s0,sp,80
    80000b50:	8aaa                	mv	s5,a0
    80000b52:	84ae                	mv	s1,a1
    80000b54:	8bb2                	mv	s7,a2
    80000b56:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000b58:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000b5a:	6a05                	lui	s4,0x1
    80000b5c:	a82d                	j	80000b96 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000b5e:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80000b62:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000b64:	0017c793          	xori	a5,a5,1
    80000b68:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000b6c:	60a6                	ld	ra,72(sp)
    80000b6e:	6406                	ld	s0,64(sp)
    80000b70:	74e2                	ld	s1,56(sp)
    80000b72:	7942                	ld	s2,48(sp)
    80000b74:	79a2                	ld	s3,40(sp)
    80000b76:	7a02                	ld	s4,32(sp)
    80000b78:	6ae2                	ld	s5,24(sp)
    80000b7a:	6b42                	ld	s6,16(sp)
    80000b7c:	6ba2                	ld	s7,8(sp)
    80000b7e:	6161                	addi	sp,sp,80
    80000b80:	8082                	ret
    80000b82:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80000b86:	9726                	add	a4,a4,s1
      --max;
    80000b88:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80000b8c:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80000b90:	04e58463          	beq	a1,a4,80000bd8 <copyinstr+0xa0>
{
    80000b94:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80000b96:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80000b9a:	85ca                	mv	a1,s2
    80000b9c:	8556                	mv	a0,s5
    80000b9e:	8efff0ef          	jal	8000048c <walkaddr>
    if(pa0 == 0)
    80000ba2:	cd0d                	beqz	a0,80000bdc <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80000ba4:	417906b3          	sub	a3,s2,s7
    80000ba8:	96d2                	add	a3,a3,s4
    if(n > max)
    80000baa:	00d9f363          	bgeu	s3,a3,80000bb0 <copyinstr+0x78>
    80000bae:	86ce                	mv	a3,s3
    while(n > 0){
    80000bb0:	ca85                	beqz	a3,80000be0 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80000bb2:	01750633          	add	a2,a0,s7
    80000bb6:	41260633          	sub	a2,a2,s2
    80000bba:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80000bbc:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80000bbe:	96a6                	add	a3,a3,s1
    80000bc0:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000bc2:	00f60733          	add	a4,a2,a5
    80000bc6:	00074703          	lbu	a4,0(a4)
    80000bca:	db51                	beqz	a4,80000b5e <copyinstr+0x26>
        *dst = *p;
    80000bcc:	00e78023          	sb	a4,0(a5)
      dst++;
    80000bd0:	0785                	addi	a5,a5,1
    while(n > 0){
    80000bd2:	fed797e3          	bne	a5,a3,80000bc0 <copyinstr+0x88>
    80000bd6:	b775                	j	80000b82 <copyinstr+0x4a>
    80000bd8:	4781                	li	a5,0
    80000bda:	b769                	j	80000b64 <copyinstr+0x2c>
      return -1;
    80000bdc:	557d                	li	a0,-1
    80000bde:	b779                	j	80000b6c <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80000be0:	6b85                	lui	s7,0x1
    80000be2:	9bca                	add	s7,s7,s2
    80000be4:	87a6                	mv	a5,s1
    80000be6:	b77d                	j	80000b94 <copyinstr+0x5c>
  int got_null = 0;
    80000be8:	4781                	li	a5,0
  if(got_null){
    80000bea:	0017c793          	xori	a5,a5,1
    80000bee:	40f0053b          	negw	a0,a5
}
    80000bf2:	8082                	ret

0000000080000bf4 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000bf4:	715d                	addi	sp,sp,-80
    80000bf6:	e486                	sd	ra,72(sp)
    80000bf8:	e0a2                	sd	s0,64(sp)
    80000bfa:	fc26                	sd	s1,56(sp)
    80000bfc:	f84a                	sd	s2,48(sp)
    80000bfe:	f44e                	sd	s3,40(sp)
    80000c00:	f052                	sd	s4,32(sp)
    80000c02:	ec56                	sd	s5,24(sp)
    80000c04:	e85a                	sd	s6,16(sp)
    80000c06:	e45e                	sd	s7,8(sp)
    80000c08:	e062                	sd	s8,0(sp)
    80000c0a:	0880                	addi	s0,sp,80
    80000c0c:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c0e:	00007497          	auipc	s1,0x7
    80000c12:	17248493          	addi	s1,s1,370 # 80007d80 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000c16:	8c26                	mv	s8,s1
    80000c18:	ff8f6937          	lui	s2,0xff8f6
    80000c1c:	c2990913          	addi	s2,s2,-983 # ffffffffff8f5c29 <end+0xffffffff7f8d45c9>
    80000c20:	093e                	slli	s2,s2,0xf
    80000c22:	ae190913          	addi	s2,s2,-1311
    80000c26:	0932                	slli	s2,s2,0xc
    80000c28:	47b90913          	addi	s2,s2,1147
    80000c2c:	0936                	slli	s2,s2,0xd
    80000c2e:	c2990913          	addi	s2,s2,-983
    80000c32:	040009b7          	lui	s3,0x4000
    80000c36:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000c38:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c3a:	4b99                	li	s7,6
    80000c3c:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c3e:	0000da97          	auipc	s5,0xd
    80000c42:	542a8a93          	addi	s5,s5,1346 # 8000e180 <tickslock>
    char *pa = kalloc();
    80000c46:	cbeff0ef          	jal	80000104 <kalloc>
    80000c4a:	862a                	mv	a2,a0
    if(pa == 0)
    80000c4c:	c121                	beqz	a0,80000c8c <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    80000c4e:	418485b3          	sub	a1,s1,s8
    80000c52:	8591                	srai	a1,a1,0x4
    80000c54:	032585b3          	mul	a1,a1,s2
    80000c58:	05b6                	slli	a1,a1,0xd
    80000c5a:	6789                	lui	a5,0x2
    80000c5c:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000c5e:	875e                	mv	a4,s7
    80000c60:	86da                	mv	a3,s6
    80000c62:	40b985b3          	sub	a1,s3,a1
    80000c66:	8552                	mv	a0,s4
    80000c68:	915ff0ef          	jal	8000057c <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000c6c:	19048493          	addi	s1,s1,400
    80000c70:	fd549be3          	bne	s1,s5,80000c46 <proc_mapstacks+0x52>
  }
}
    80000c74:	60a6                	ld	ra,72(sp)
    80000c76:	6406                	ld	s0,64(sp)
    80000c78:	74e2                	ld	s1,56(sp)
    80000c7a:	7942                	ld	s2,48(sp)
    80000c7c:	79a2                	ld	s3,40(sp)
    80000c7e:	7a02                	ld	s4,32(sp)
    80000c80:	6ae2                	ld	s5,24(sp)
    80000c82:	6b42                	ld	s6,16(sp)
    80000c84:	6ba2                	ld	s7,8(sp)
    80000c86:	6c02                	ld	s8,0(sp)
    80000c88:	6161                	addi	sp,sp,80
    80000c8a:	8082                	ret
      panic("kalloc");
    80000c8c:	00006517          	auipc	a0,0x6
    80000c90:	50c50513          	addi	a0,a0,1292 # 80007198 <etext+0x198>
    80000c94:	195040ef          	jal	80005628 <panic>

0000000080000c98 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000c98:	7139                	addi	sp,sp,-64
    80000c9a:	fc06                	sd	ra,56(sp)
    80000c9c:	f822                	sd	s0,48(sp)
    80000c9e:	f426                	sd	s1,40(sp)
    80000ca0:	f04a                	sd	s2,32(sp)
    80000ca2:	ec4e                	sd	s3,24(sp)
    80000ca4:	e852                	sd	s4,16(sp)
    80000ca6:	e456                	sd	s5,8(sp)
    80000ca8:	e05a                	sd	s6,0(sp)
    80000caa:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000cac:	00006597          	auipc	a1,0x6
    80000cb0:	4f458593          	addi	a1,a1,1268 # 800071a0 <etext+0x1a0>
    80000cb4:	00007517          	auipc	a0,0x7
    80000cb8:	c9c50513          	addi	a0,a0,-868 # 80007950 <pid_lock>
    80000cbc:	3f7040ef          	jal	800058b2 <initlock>
  initlock(&wait_lock, "wait_lock");
    80000cc0:	00006597          	auipc	a1,0x6
    80000cc4:	4e858593          	addi	a1,a1,1256 # 800071a8 <etext+0x1a8>
    80000cc8:	00007517          	auipc	a0,0x7
    80000ccc:	ca050513          	addi	a0,a0,-864 # 80007968 <wait_lock>
    80000cd0:	3e3040ef          	jal	800058b2 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cd4:	00007497          	auipc	s1,0x7
    80000cd8:	0ac48493          	addi	s1,s1,172 # 80007d80 <proc>
      initlock(&p->lock, "proc");
    80000cdc:	00006b17          	auipc	s6,0x6
    80000ce0:	4dcb0b13          	addi	s6,s6,1244 # 800071b8 <etext+0x1b8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000ce4:	8aa6                	mv	s5,s1
    80000ce6:	ff8f6937          	lui	s2,0xff8f6
    80000cea:	c2990913          	addi	s2,s2,-983 # ffffffffff8f5c29 <end+0xffffffff7f8d45c9>
    80000cee:	093e                	slli	s2,s2,0xf
    80000cf0:	ae190913          	addi	s2,s2,-1311
    80000cf4:	0932                	slli	s2,s2,0xc
    80000cf6:	47b90913          	addi	s2,s2,1147
    80000cfa:	0936                	slli	s2,s2,0xd
    80000cfc:	c2990913          	addi	s2,s2,-983
    80000d00:	040009b7          	lui	s3,0x4000
    80000d04:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000d06:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d08:	0000da17          	auipc	s4,0xd
    80000d0c:	478a0a13          	addi	s4,s4,1144 # 8000e180 <tickslock>
      initlock(&p->lock, "proc");
    80000d10:	85da                	mv	a1,s6
    80000d12:	8526                	mv	a0,s1
    80000d14:	39f040ef          	jal	800058b2 <initlock>
      p->state = UNUSED;
    80000d18:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000d1c:	415487b3          	sub	a5,s1,s5
    80000d20:	8791                	srai	a5,a5,0x4
    80000d22:	032787b3          	mul	a5,a5,s2
    80000d26:	07b6                	slli	a5,a5,0xd
    80000d28:	6709                	lui	a4,0x2
    80000d2a:	9fb9                	addw	a5,a5,a4
    80000d2c:	40f987b3          	sub	a5,s3,a5
    80000d30:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d32:	19048493          	addi	s1,s1,400
    80000d36:	fd449de3          	bne	s1,s4,80000d10 <procinit+0x78>
  }
}
    80000d3a:	70e2                	ld	ra,56(sp)
    80000d3c:	7442                	ld	s0,48(sp)
    80000d3e:	74a2                	ld	s1,40(sp)
    80000d40:	7902                	ld	s2,32(sp)
    80000d42:	69e2                	ld	s3,24(sp)
    80000d44:	6a42                	ld	s4,16(sp)
    80000d46:	6aa2                	ld	s5,8(sp)
    80000d48:	6b02                	ld	s6,0(sp)
    80000d4a:	6121                	addi	sp,sp,64
    80000d4c:	8082                	ret

0000000080000d4e <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000d4e:	1141                	addi	sp,sp,-16
    80000d50:	e406                	sd	ra,8(sp)
    80000d52:	e022                	sd	s0,0(sp)
    80000d54:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000d56:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000d58:	2501                	sext.w	a0,a0
    80000d5a:	60a2                	ld	ra,8(sp)
    80000d5c:	6402                	ld	s0,0(sp)
    80000d5e:	0141                	addi	sp,sp,16
    80000d60:	8082                	ret

0000000080000d62 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000d62:	1141                	addi	sp,sp,-16
    80000d64:	e406                	sd	ra,8(sp)
    80000d66:	e022                	sd	s0,0(sp)
    80000d68:	0800                	addi	s0,sp,16
    80000d6a:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000d6c:	2781                	sext.w	a5,a5
    80000d6e:	079e                	slli	a5,a5,0x7
  return c;
}
    80000d70:	00007517          	auipc	a0,0x7
    80000d74:	c1050513          	addi	a0,a0,-1008 # 80007980 <cpus>
    80000d78:	953e                	add	a0,a0,a5
    80000d7a:	60a2                	ld	ra,8(sp)
    80000d7c:	6402                	ld	s0,0(sp)
    80000d7e:	0141                	addi	sp,sp,16
    80000d80:	8082                	ret

0000000080000d82 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000d82:	1101                	addi	sp,sp,-32
    80000d84:	ec06                	sd	ra,24(sp)
    80000d86:	e822                	sd	s0,16(sp)
    80000d88:	e426                	sd	s1,8(sp)
    80000d8a:	1000                	addi	s0,sp,32
  push_off();
    80000d8c:	36d040ef          	jal	800058f8 <push_off>
    80000d90:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000d92:	2781                	sext.w	a5,a5
    80000d94:	079e                	slli	a5,a5,0x7
    80000d96:	00007717          	auipc	a4,0x7
    80000d9a:	bba70713          	addi	a4,a4,-1094 # 80007950 <pid_lock>
    80000d9e:	97ba                	add	a5,a5,a4
    80000da0:	7b9c                	ld	a5,48(a5)
    80000da2:	84be                	mv	s1,a5
  pop_off();
    80000da4:	3dd040ef          	jal	80005980 <pop_off>
  return p;
}
    80000da8:	8526                	mv	a0,s1
    80000daa:	60e2                	ld	ra,24(sp)
    80000dac:	6442                	ld	s0,16(sp)
    80000dae:	64a2                	ld	s1,8(sp)
    80000db0:	6105                	addi	sp,sp,32
    80000db2:	8082                	ret

0000000080000db4 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000db4:	1141                	addi	sp,sp,-16
    80000db6:	e406                	sd	ra,8(sp)
    80000db8:	e022                	sd	s0,0(sp)
    80000dba:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000dbc:	fc7ff0ef          	jal	80000d82 <myproc>
    80000dc0:	411040ef          	jal	800059d0 <release>

  if (first) {
    80000dc4:	00007797          	auipc	a5,0x7
    80000dc8:	aec7a783          	lw	a5,-1300(a5) # 800078b0 <first.1>
    80000dcc:	e799                	bnez	a5,80000dda <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000dce:	363000ef          	jal	80001930 <usertrapret>
}
    80000dd2:	60a2                	ld	ra,8(sp)
    80000dd4:	6402                	ld	s0,0(sp)
    80000dd6:	0141                	addi	sp,sp,16
    80000dd8:	8082                	ret
    fsinit(ROOTDEV);
    80000dda:	4505                	li	a0,1
    80000ddc:	73c010ef          	jal	80002518 <fsinit>
    first = 0;
    80000de0:	00007797          	auipc	a5,0x7
    80000de4:	ac07a823          	sw	zero,-1328(a5) # 800078b0 <first.1>
    __sync_synchronize();
    80000de8:	0330000f          	fence	rw,rw
    80000dec:	b7cd                	j	80000dce <forkret+0x1a>

0000000080000dee <allocpid>:
{
    80000dee:	1101                	addi	sp,sp,-32
    80000df0:	ec06                	sd	ra,24(sp)
    80000df2:	e822                	sd	s0,16(sp)
    80000df4:	e426                	sd	s1,8(sp)
    80000df6:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000df8:	00007517          	auipc	a0,0x7
    80000dfc:	b5850513          	addi	a0,a0,-1192 # 80007950 <pid_lock>
    80000e00:	33d040ef          	jal	8000593c <acquire>
  pid = nextpid;
    80000e04:	00007797          	auipc	a5,0x7
    80000e08:	ab078793          	addi	a5,a5,-1360 # 800078b4 <nextpid>
    80000e0c:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000e0e:	0014871b          	addiw	a4,s1,1
    80000e12:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000e14:	00007517          	auipc	a0,0x7
    80000e18:	b3c50513          	addi	a0,a0,-1220 # 80007950 <pid_lock>
    80000e1c:	3b5040ef          	jal	800059d0 <release>
}
    80000e20:	8526                	mv	a0,s1
    80000e22:	60e2                	ld	ra,24(sp)
    80000e24:	6442                	ld	s0,16(sp)
    80000e26:	64a2                	ld	s1,8(sp)
    80000e28:	6105                	addi	sp,sp,32
    80000e2a:	8082                	ret

0000000080000e2c <proc_pagetable>:
{
    80000e2c:	1101                	addi	sp,sp,-32
    80000e2e:	ec06                	sd	ra,24(sp)
    80000e30:	e822                	sd	s0,16(sp)
    80000e32:	e426                	sd	s1,8(sp)
    80000e34:	e04a                	sd	s2,0(sp)
    80000e36:	1000                	addi	s0,sp,32
    80000e38:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000e3a:	8f1ff0ef          	jal	8000072a <uvmcreate>
    80000e3e:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000e40:	cd05                	beqz	a0,80000e78 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000e42:	4729                	li	a4,10
    80000e44:	00005697          	auipc	a3,0x5
    80000e48:	1bc68693          	addi	a3,a3,444 # 80006000 <_trampoline>
    80000e4c:	6605                	lui	a2,0x1
    80000e4e:	040005b7          	lui	a1,0x4000
    80000e52:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e54:	05b2                	slli	a1,a1,0xc
    80000e56:	e70ff0ef          	jal	800004c6 <mappages>
    80000e5a:	02054663          	bltz	a0,80000e86 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000e5e:	4719                	li	a4,6
    80000e60:	05893683          	ld	a3,88(s2)
    80000e64:	6605                	lui	a2,0x1
    80000e66:	020005b7          	lui	a1,0x2000
    80000e6a:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000e6c:	05b6                	slli	a1,a1,0xd
    80000e6e:	8526                	mv	a0,s1
    80000e70:	e56ff0ef          	jal	800004c6 <mappages>
    80000e74:	00054f63          	bltz	a0,80000e92 <proc_pagetable+0x66>
}
    80000e78:	8526                	mv	a0,s1
    80000e7a:	60e2                	ld	ra,24(sp)
    80000e7c:	6442                	ld	s0,16(sp)
    80000e7e:	64a2                	ld	s1,8(sp)
    80000e80:	6902                	ld	s2,0(sp)
    80000e82:	6105                	addi	sp,sp,32
    80000e84:	8082                	ret
    uvmfree(pagetable, 0);
    80000e86:	4581                	li	a1,0
    80000e88:	8526                	mv	a0,s1
    80000e8a:	a6fff0ef          	jal	800008f8 <uvmfree>
    return 0;
    80000e8e:	4481                	li	s1,0
    80000e90:	b7e5                	j	80000e78 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000e92:	4681                	li	a3,0
    80000e94:	4605                	li	a2,1
    80000e96:	040005b7          	lui	a1,0x4000
    80000e9a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000e9c:	05b2                	slli	a1,a1,0xc
    80000e9e:	8526                	mv	a0,s1
    80000ea0:	fceff0ef          	jal	8000066e <uvmunmap>
    uvmfree(pagetable, 0);
    80000ea4:	4581                	li	a1,0
    80000ea6:	8526                	mv	a0,s1
    80000ea8:	a51ff0ef          	jal	800008f8 <uvmfree>
    return 0;
    80000eac:	4481                	li	s1,0
    80000eae:	b7e9                	j	80000e78 <proc_pagetable+0x4c>

0000000080000eb0 <proc_freepagetable>:
{
    80000eb0:	1101                	addi	sp,sp,-32
    80000eb2:	ec06                	sd	ra,24(sp)
    80000eb4:	e822                	sd	s0,16(sp)
    80000eb6:	e426                	sd	s1,8(sp)
    80000eb8:	e04a                	sd	s2,0(sp)
    80000eba:	1000                	addi	s0,sp,32
    80000ebc:	84aa                	mv	s1,a0
    80000ebe:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000ec0:	4681                	li	a3,0
    80000ec2:	4605                	li	a2,1
    80000ec4:	040005b7          	lui	a1,0x4000
    80000ec8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000eca:	05b2                	slli	a1,a1,0xc
    80000ecc:	fa2ff0ef          	jal	8000066e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000ed0:	4681                	li	a3,0
    80000ed2:	4605                	li	a2,1
    80000ed4:	020005b7          	lui	a1,0x2000
    80000ed8:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80000eda:	05b6                	slli	a1,a1,0xd
    80000edc:	8526                	mv	a0,s1
    80000ede:	f90ff0ef          	jal	8000066e <uvmunmap>
  uvmfree(pagetable, sz);
    80000ee2:	85ca                	mv	a1,s2
    80000ee4:	8526                	mv	a0,s1
    80000ee6:	a13ff0ef          	jal	800008f8 <uvmfree>
}
    80000eea:	60e2                	ld	ra,24(sp)
    80000eec:	6442                	ld	s0,16(sp)
    80000eee:	64a2                	ld	s1,8(sp)
    80000ef0:	6902                	ld	s2,0(sp)
    80000ef2:	6105                	addi	sp,sp,32
    80000ef4:	8082                	ret

0000000080000ef6 <freeproc>:
{
    80000ef6:	1101                	addi	sp,sp,-32
    80000ef8:	ec06                	sd	ra,24(sp)
    80000efa:	e822                	sd	s0,16(sp)
    80000efc:	e426                	sd	s1,8(sp)
    80000efe:	1000                	addi	s0,sp,32
    80000f00:	84aa                	mv	s1,a0
  if(p->trapframe)
    80000f02:	6d28                	ld	a0,88(a0)
    80000f04:	c119                	beqz	a0,80000f0a <freeproc+0x14>
    kfree((void*)p->trapframe);
    80000f06:	916ff0ef          	jal	8000001c <kfree>
  p->trapframe = 0;
    80000f0a:	0404bc23          	sd	zero,88(s1)
  if(p->sigreturntrapframe)
    80000f0e:	1784b503          	ld	a0,376(s1)
    80000f12:	c119                	beqz	a0,80000f18 <freeproc+0x22>
    kfree((void*)p->sigreturntrapframe);
    80000f14:	908ff0ef          	jal	8000001c <kfree>
  p->sigreturntrapframe = 0;
    80000f18:	1604bc23          	sd	zero,376(s1)
  if(p->pagetable)
    80000f1c:	68a8                	ld	a0,80(s1)
    80000f1e:	c501                	beqz	a0,80000f26 <freeproc+0x30>
    proc_freepagetable(p->pagetable, p->sz);
    80000f20:	64ac                	ld	a1,72(s1)
    80000f22:	f8fff0ef          	jal	80000eb0 <proc_freepagetable>
  p->pagetable = 0;
    80000f26:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80000f2a:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80000f2e:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80000f32:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80000f36:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80000f3a:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80000f3e:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80000f42:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80000f46:	0004ac23          	sw	zero,24(s1)
}
    80000f4a:	60e2                	ld	ra,24(sp)
    80000f4c:	6442                	ld	s0,16(sp)
    80000f4e:	64a2                	ld	s1,8(sp)
    80000f50:	6105                	addi	sp,sp,32
    80000f52:	8082                	ret

0000000080000f54 <allocproc>:
{
    80000f54:	1101                	addi	sp,sp,-32
    80000f56:	ec06                	sd	ra,24(sp)
    80000f58:	e822                	sd	s0,16(sp)
    80000f5a:	e426                	sd	s1,8(sp)
    80000f5c:	e04a                	sd	s2,0(sp)
    80000f5e:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f60:	00007497          	auipc	s1,0x7
    80000f64:	e2048493          	addi	s1,s1,-480 # 80007d80 <proc>
    80000f68:	0000d917          	auipc	s2,0xd
    80000f6c:	21890913          	addi	s2,s2,536 # 8000e180 <tickslock>
    acquire(&p->lock);
    80000f70:	8526                	mv	a0,s1
    80000f72:	1cb040ef          	jal	8000593c <acquire>
    if(p->state == UNUSED) {
    80000f76:	4c9c                	lw	a5,24(s1)
    80000f78:	cb91                	beqz	a5,80000f8c <allocproc+0x38>
      release(&p->lock);
    80000f7a:	8526                	mv	a0,s1
    80000f7c:	255040ef          	jal	800059d0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f80:	19048493          	addi	s1,s1,400
    80000f84:	ff2496e3          	bne	s1,s2,80000f70 <allocproc+0x1c>
  return 0;
    80000f88:	4481                	li	s1,0
    80000f8a:	a899                	j	80000fe0 <allocproc+0x8c>
  p->pid = allocpid();
    80000f8c:	e63ff0ef          	jal	80000dee <allocpid>
    80000f90:	d888                	sw	a0,48(s1)
  p->state = USED;
    80000f92:	4785                	li	a5,1
    80000f94:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80000f96:	96eff0ef          	jal	80000104 <kalloc>
    80000f9a:	892a                	mv	s2,a0
    80000f9c:	eca8                	sd	a0,88(s1)
    80000f9e:	c921                	beqz	a0,80000fee <allocproc+0x9a>
  if((p->sigreturntrapframe = (struct trapframe *)kalloc()) == 0){
    80000fa0:	964ff0ef          	jal	80000104 <kalloc>
    80000fa4:	892a                	mv	s2,a0
    80000fa6:	16a4bc23          	sd	a0,376(s1)
    80000faa:	c931                	beqz	a0,80000ffe <allocproc+0xaa>
  p->pagetable = proc_pagetable(p);
    80000fac:	8526                	mv	a0,s1
    80000fae:	e7fff0ef          	jal	80000e2c <proc_pagetable>
    80000fb2:	892a                	mv	s2,a0
    80000fb4:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80000fb6:	cd21                	beqz	a0,8000100e <allocproc+0xba>
  memset(&p->context, 0, sizeof(p->context));
    80000fb8:	07000613          	li	a2,112
    80000fbc:	4581                	li	a1,0
    80000fbe:	06048513          	addi	a0,s1,96
    80000fc2:	99cff0ef          	jal	8000015e <memset>
  p->context.ra = (uint64)forkret;
    80000fc6:	00000797          	auipc	a5,0x0
    80000fca:	dee78793          	addi	a5,a5,-530 # 80000db4 <forkret>
    80000fce:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80000fd0:	60bc                	ld	a5,64(s1)
    80000fd2:	6705                	lui	a4,0x1
    80000fd4:	97ba                	add	a5,a5,a4
    80000fd6:	f4bc                	sd	a5,104(s1)
  p->alarmticks = 0;
    80000fd8:	1604b423          	sd	zero,360(s1)
  p->alarmhandler = 0;
    80000fdc:	1604b823          	sd	zero,368(s1)
}
    80000fe0:	8526                	mv	a0,s1
    80000fe2:	60e2                	ld	ra,24(sp)
    80000fe4:	6442                	ld	s0,16(sp)
    80000fe6:	64a2                	ld	s1,8(sp)
    80000fe8:	6902                	ld	s2,0(sp)
    80000fea:	6105                	addi	sp,sp,32
    80000fec:	8082                	ret
    freeproc(p);
    80000fee:	8526                	mv	a0,s1
    80000ff0:	f07ff0ef          	jal	80000ef6 <freeproc>
    release(&p->lock);
    80000ff4:	8526                	mv	a0,s1
    80000ff6:	1db040ef          	jal	800059d0 <release>
    return 0;
    80000ffa:	84ca                	mv	s1,s2
    80000ffc:	b7d5                	j	80000fe0 <allocproc+0x8c>
    freeproc(p);
    80000ffe:	8526                	mv	a0,s1
    80001000:	ef7ff0ef          	jal	80000ef6 <freeproc>
    release(&p->lock);
    80001004:	8526                	mv	a0,s1
    80001006:	1cb040ef          	jal	800059d0 <release>
    return 0;
    8000100a:	84ca                	mv	s1,s2
    8000100c:	bfd1                	j	80000fe0 <allocproc+0x8c>
    freeproc(p);
    8000100e:	8526                	mv	a0,s1
    80001010:	ee7ff0ef          	jal	80000ef6 <freeproc>
    release(&p->lock);
    80001014:	8526                	mv	a0,s1
    80001016:	1bb040ef          	jal	800059d0 <release>
    return 0;
    8000101a:	84ca                	mv	s1,s2
    8000101c:	b7d1                	j	80000fe0 <allocproc+0x8c>

000000008000101e <userinit>:
{
    8000101e:	1101                	addi	sp,sp,-32
    80001020:	ec06                	sd	ra,24(sp)
    80001022:	e822                	sd	s0,16(sp)
    80001024:	e426                	sd	s1,8(sp)
    80001026:	1000                	addi	s0,sp,32
  p = allocproc();
    80001028:	f2dff0ef          	jal	80000f54 <allocproc>
    8000102c:	84aa                	mv	s1,a0
  initproc = p;
    8000102e:	00007797          	auipc	a5,0x7
    80001032:	8ea7b123          	sd	a0,-1822(a5) # 80007910 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001036:	03400613          	li	a2,52
    8000103a:	00007597          	auipc	a1,0x7
    8000103e:	88658593          	addi	a1,a1,-1914 # 800078c0 <initcode>
    80001042:	6928                	ld	a0,80(a0)
    80001044:	f0cff0ef          	jal	80000750 <uvmfirst>
  p->sz = PGSIZE;
    80001048:	6785                	lui	a5,0x1
    8000104a:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    8000104c:	6cb8                	ld	a4,88(s1)
    8000104e:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001052:	6cb8                	ld	a4,88(s1)
    80001054:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001056:	4641                	li	a2,16
    80001058:	00006597          	auipc	a1,0x6
    8000105c:	16858593          	addi	a1,a1,360 # 800071c0 <etext+0x1c0>
    80001060:	15848513          	addi	a0,s1,344
    80001064:	a4eff0ef          	jal	800002b2 <safestrcpy>
  p->cwd = namei("/");
    80001068:	00006517          	auipc	a0,0x6
    8000106c:	16850513          	addi	a0,a0,360 # 800071d0 <etext+0x1d0>
    80001070:	5d1010ef          	jal	80002e40 <namei>
    80001074:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001078:	478d                	li	a5,3
    8000107a:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    8000107c:	8526                	mv	a0,s1
    8000107e:	153040ef          	jal	800059d0 <release>
}
    80001082:	60e2                	ld	ra,24(sp)
    80001084:	6442                	ld	s0,16(sp)
    80001086:	64a2                	ld	s1,8(sp)
    80001088:	6105                	addi	sp,sp,32
    8000108a:	8082                	ret

000000008000108c <growproc>:
{
    8000108c:	1101                	addi	sp,sp,-32
    8000108e:	ec06                	sd	ra,24(sp)
    80001090:	e822                	sd	s0,16(sp)
    80001092:	e426                	sd	s1,8(sp)
    80001094:	e04a                	sd	s2,0(sp)
    80001096:	1000                	addi	s0,sp,32
    80001098:	892a                	mv	s2,a0
  struct proc *p = myproc();
    8000109a:	ce9ff0ef          	jal	80000d82 <myproc>
    8000109e:	84aa                	mv	s1,a0
  sz = p->sz;
    800010a0:	652c                	ld	a1,72(a0)
  if(n > 0){
    800010a2:	01204c63          	bgtz	s2,800010ba <growproc+0x2e>
  } else if(n < 0){
    800010a6:	02094463          	bltz	s2,800010ce <growproc+0x42>
  p->sz = sz;
    800010aa:	e4ac                	sd	a1,72(s1)
  return 0;
    800010ac:	4501                	li	a0,0
}
    800010ae:	60e2                	ld	ra,24(sp)
    800010b0:	6442                	ld	s0,16(sp)
    800010b2:	64a2                	ld	s1,8(sp)
    800010b4:	6902                	ld	s2,0(sp)
    800010b6:	6105                	addi	sp,sp,32
    800010b8:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    800010ba:	4691                	li	a3,4
    800010bc:	00b90633          	add	a2,s2,a1
    800010c0:	6928                	ld	a0,80(a0)
    800010c2:	f30ff0ef          	jal	800007f2 <uvmalloc>
    800010c6:	85aa                	mv	a1,a0
    800010c8:	f16d                	bnez	a0,800010aa <growproc+0x1e>
      return -1;
    800010ca:	557d                	li	a0,-1
    800010cc:	b7cd                	j	800010ae <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    800010ce:	00b90633          	add	a2,s2,a1
    800010d2:	6928                	ld	a0,80(a0)
    800010d4:	edaff0ef          	jal	800007ae <uvmdealloc>
    800010d8:	85aa                	mv	a1,a0
    800010da:	bfc1                	j	800010aa <growproc+0x1e>

00000000800010dc <fork>:
{
    800010dc:	7139                	addi	sp,sp,-64
    800010de:	fc06                	sd	ra,56(sp)
    800010e0:	f822                	sd	s0,48(sp)
    800010e2:	f426                	sd	s1,40(sp)
    800010e4:	e456                	sd	s5,8(sp)
    800010e6:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    800010e8:	c9bff0ef          	jal	80000d82 <myproc>
    800010ec:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    800010ee:	e67ff0ef          	jal	80000f54 <allocproc>
    800010f2:	0e050a63          	beqz	a0,800011e6 <fork+0x10a>
    800010f6:	e852                	sd	s4,16(sp)
    800010f8:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    800010fa:	048ab603          	ld	a2,72(s5)
    800010fe:	692c                	ld	a1,80(a0)
    80001100:	050ab503          	ld	a0,80(s5)
    80001104:	827ff0ef          	jal	8000092a <uvmcopy>
    80001108:	04054863          	bltz	a0,80001158 <fork+0x7c>
    8000110c:	f04a                	sd	s2,32(sp)
    8000110e:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001110:	048ab783          	ld	a5,72(s5)
    80001114:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001118:	058ab683          	ld	a3,88(s5)
    8000111c:	87b6                	mv	a5,a3
    8000111e:	058a3703          	ld	a4,88(s4)
    80001122:	12068693          	addi	a3,a3,288
    80001126:	6388                	ld	a0,0(a5)
    80001128:	678c                	ld	a1,8(a5)
    8000112a:	6b90                	ld	a2,16(a5)
    8000112c:	e308                	sd	a0,0(a4)
    8000112e:	e70c                	sd	a1,8(a4)
    80001130:	eb10                	sd	a2,16(a4)
    80001132:	6f90                	ld	a2,24(a5)
    80001134:	ef10                	sd	a2,24(a4)
    80001136:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    8000113a:	02070713          	addi	a4,a4,32
    8000113e:	fed794e3          	bne	a5,a3,80001126 <fork+0x4a>
  np->trapframe->a0 = 0;
    80001142:	058a3783          	ld	a5,88(s4)
    80001146:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    8000114a:	0d0a8493          	addi	s1,s5,208
    8000114e:	0d0a0913          	addi	s2,s4,208
    80001152:	150a8993          	addi	s3,s5,336
    80001156:	a831                	j	80001172 <fork+0x96>
    freeproc(np);
    80001158:	8552                	mv	a0,s4
    8000115a:	d9dff0ef          	jal	80000ef6 <freeproc>
    release(&np->lock);
    8000115e:	8552                	mv	a0,s4
    80001160:	071040ef          	jal	800059d0 <release>
    return -1;
    80001164:	54fd                	li	s1,-1
    80001166:	6a42                	ld	s4,16(sp)
    80001168:	a885                	j	800011d8 <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    8000116a:	04a1                	addi	s1,s1,8
    8000116c:	0921                	addi	s2,s2,8
    8000116e:	01348963          	beq	s1,s3,80001180 <fork+0xa4>
    if(p->ofile[i])
    80001172:	6088                	ld	a0,0(s1)
    80001174:	d97d                	beqz	a0,8000116a <fork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001176:	278020ef          	jal	800033ee <filedup>
    8000117a:	00a93023          	sd	a0,0(s2)
    8000117e:	b7f5                	j	8000116a <fork+0x8e>
  np->cwd = idup(p->cwd);
    80001180:	150ab503          	ld	a0,336(s5)
    80001184:	590010ef          	jal	80002714 <idup>
    80001188:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    8000118c:	4641                	li	a2,16
    8000118e:	158a8593          	addi	a1,s5,344
    80001192:	158a0513          	addi	a0,s4,344
    80001196:	91cff0ef          	jal	800002b2 <safestrcpy>
  pid = np->pid;
    8000119a:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    8000119e:	8552                	mv	a0,s4
    800011a0:	031040ef          	jal	800059d0 <release>
  acquire(&wait_lock);
    800011a4:	00006517          	auipc	a0,0x6
    800011a8:	7c450513          	addi	a0,a0,1988 # 80007968 <wait_lock>
    800011ac:	790040ef          	jal	8000593c <acquire>
  np->parent = p;
    800011b0:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    800011b4:	00006517          	auipc	a0,0x6
    800011b8:	7b450513          	addi	a0,a0,1972 # 80007968 <wait_lock>
    800011bc:	015040ef          	jal	800059d0 <release>
  acquire(&np->lock);
    800011c0:	8552                	mv	a0,s4
    800011c2:	77a040ef          	jal	8000593c <acquire>
  np->state = RUNNABLE;
    800011c6:	478d                	li	a5,3
    800011c8:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    800011cc:	8552                	mv	a0,s4
    800011ce:	003040ef          	jal	800059d0 <release>
  return pid;
    800011d2:	7902                	ld	s2,32(sp)
    800011d4:	69e2                	ld	s3,24(sp)
    800011d6:	6a42                	ld	s4,16(sp)
}
    800011d8:	8526                	mv	a0,s1
    800011da:	70e2                	ld	ra,56(sp)
    800011dc:	7442                	ld	s0,48(sp)
    800011de:	74a2                	ld	s1,40(sp)
    800011e0:	6aa2                	ld	s5,8(sp)
    800011e2:	6121                	addi	sp,sp,64
    800011e4:	8082                	ret
    return -1;
    800011e6:	54fd                	li	s1,-1
    800011e8:	bfc5                	j	800011d8 <fork+0xfc>

00000000800011ea <scheduler>:
{
    800011ea:	715d                	addi	sp,sp,-80
    800011ec:	e486                	sd	ra,72(sp)
    800011ee:	e0a2                	sd	s0,64(sp)
    800011f0:	fc26                	sd	s1,56(sp)
    800011f2:	f84a                	sd	s2,48(sp)
    800011f4:	f44e                	sd	s3,40(sp)
    800011f6:	f052                	sd	s4,32(sp)
    800011f8:	ec56                	sd	s5,24(sp)
    800011fa:	e85a                	sd	s6,16(sp)
    800011fc:	e45e                	sd	s7,8(sp)
    800011fe:	e062                	sd	s8,0(sp)
    80001200:	0880                	addi	s0,sp,80
    80001202:	8792                	mv	a5,tp
  int id = r_tp();
    80001204:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001206:	00779b13          	slli	s6,a5,0x7
    8000120a:	00006717          	auipc	a4,0x6
    8000120e:	74670713          	addi	a4,a4,1862 # 80007950 <pid_lock>
    80001212:	975a                	add	a4,a4,s6
    80001214:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001218:	00006717          	auipc	a4,0x6
    8000121c:	77070713          	addi	a4,a4,1904 # 80007988 <cpus+0x8>
    80001220:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001222:	4c11                	li	s8,4
        c->proc = p;
    80001224:	079e                	slli	a5,a5,0x7
    80001226:	00006a17          	auipc	s4,0x6
    8000122a:	72aa0a13          	addi	s4,s4,1834 # 80007950 <pid_lock>
    8000122e:	9a3e                	add	s4,s4,a5
        found = 1;
    80001230:	4b85                	li	s7,1
    80001232:	a0a9                	j	8000127c <scheduler+0x92>
      release(&p->lock);
    80001234:	8526                	mv	a0,s1
    80001236:	79a040ef          	jal	800059d0 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    8000123a:	19048493          	addi	s1,s1,400
    8000123e:	03248563          	beq	s1,s2,80001268 <scheduler+0x7e>
      acquire(&p->lock);
    80001242:	8526                	mv	a0,s1
    80001244:	6f8040ef          	jal	8000593c <acquire>
      if(p->state == RUNNABLE) {
    80001248:	4c9c                	lw	a5,24(s1)
    8000124a:	ff3795e3          	bne	a5,s3,80001234 <scheduler+0x4a>
        p->state = RUNNING;
    8000124e:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001252:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001256:	06048593          	addi	a1,s1,96
    8000125a:	855a                	mv	a0,s6
    8000125c:	62a000ef          	jal	80001886 <swtch>
        c->proc = 0;
    80001260:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001264:	8ade                	mv	s5,s7
    80001266:	b7f9                	j	80001234 <scheduler+0x4a>
    if(found == 0) {
    80001268:	000a9a63          	bnez	s5,8000127c <scheduler+0x92>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000126c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001270:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001274:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    80001278:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000127c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001280:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001284:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001288:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    8000128a:	00007497          	auipc	s1,0x7
    8000128e:	af648493          	addi	s1,s1,-1290 # 80007d80 <proc>
      if(p->state == RUNNABLE) {
    80001292:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    80001294:	0000d917          	auipc	s2,0xd
    80001298:	eec90913          	addi	s2,s2,-276 # 8000e180 <tickslock>
    8000129c:	b75d                	j	80001242 <scheduler+0x58>

000000008000129e <sched>:
{
    8000129e:	7179                	addi	sp,sp,-48
    800012a0:	f406                	sd	ra,40(sp)
    800012a2:	f022                	sd	s0,32(sp)
    800012a4:	ec26                	sd	s1,24(sp)
    800012a6:	e84a                	sd	s2,16(sp)
    800012a8:	e44e                	sd	s3,8(sp)
    800012aa:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    800012ac:	ad7ff0ef          	jal	80000d82 <myproc>
    800012b0:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    800012b2:	61a040ef          	jal	800058cc <holding>
    800012b6:	c935                	beqz	a0,8000132a <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    800012b8:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    800012ba:	2781                	sext.w	a5,a5
    800012bc:	079e                	slli	a5,a5,0x7
    800012be:	00006717          	auipc	a4,0x6
    800012c2:	69270713          	addi	a4,a4,1682 # 80007950 <pid_lock>
    800012c6:	97ba                	add	a5,a5,a4
    800012c8:	0a87a703          	lw	a4,168(a5)
    800012cc:	4785                	li	a5,1
    800012ce:	06f71463          	bne	a4,a5,80001336 <sched+0x98>
  if(p->state == RUNNING)
    800012d2:	4c98                	lw	a4,24(s1)
    800012d4:	4791                	li	a5,4
    800012d6:	06f70663          	beq	a4,a5,80001342 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800012da:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800012de:	8b89                	andi	a5,a5,2
  if(intr_get())
    800012e0:	e7bd                	bnez	a5,8000134e <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    800012e2:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    800012e4:	00006917          	auipc	s2,0x6
    800012e8:	66c90913          	addi	s2,s2,1644 # 80007950 <pid_lock>
    800012ec:	2781                	sext.w	a5,a5
    800012ee:	079e                	slli	a5,a5,0x7
    800012f0:	97ca                	add	a5,a5,s2
    800012f2:	0ac7a983          	lw	s3,172(a5)
    800012f6:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800012f8:	2781                	sext.w	a5,a5
    800012fa:	079e                	slli	a5,a5,0x7
    800012fc:	07a1                	addi	a5,a5,8
    800012fe:	00006597          	auipc	a1,0x6
    80001302:	68258593          	addi	a1,a1,1666 # 80007980 <cpus>
    80001306:	95be                	add	a1,a1,a5
    80001308:	06048513          	addi	a0,s1,96
    8000130c:	57a000ef          	jal	80001886 <swtch>
    80001310:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001312:	2781                	sext.w	a5,a5
    80001314:	079e                	slli	a5,a5,0x7
    80001316:	993e                	add	s2,s2,a5
    80001318:	0b392623          	sw	s3,172(s2)
}
    8000131c:	70a2                	ld	ra,40(sp)
    8000131e:	7402                	ld	s0,32(sp)
    80001320:	64e2                	ld	s1,24(sp)
    80001322:	6942                	ld	s2,16(sp)
    80001324:	69a2                	ld	s3,8(sp)
    80001326:	6145                	addi	sp,sp,48
    80001328:	8082                	ret
    panic("sched p->lock");
    8000132a:	00006517          	auipc	a0,0x6
    8000132e:	eae50513          	addi	a0,a0,-338 # 800071d8 <etext+0x1d8>
    80001332:	2f6040ef          	jal	80005628 <panic>
    panic("sched locks");
    80001336:	00006517          	auipc	a0,0x6
    8000133a:	eb250513          	addi	a0,a0,-334 # 800071e8 <etext+0x1e8>
    8000133e:	2ea040ef          	jal	80005628 <panic>
    panic("sched running");
    80001342:	00006517          	auipc	a0,0x6
    80001346:	eb650513          	addi	a0,a0,-330 # 800071f8 <etext+0x1f8>
    8000134a:	2de040ef          	jal	80005628 <panic>
    panic("sched interruptible");
    8000134e:	00006517          	auipc	a0,0x6
    80001352:	eba50513          	addi	a0,a0,-326 # 80007208 <etext+0x208>
    80001356:	2d2040ef          	jal	80005628 <panic>

000000008000135a <yield>:
{
    8000135a:	1101                	addi	sp,sp,-32
    8000135c:	ec06                	sd	ra,24(sp)
    8000135e:	e822                	sd	s0,16(sp)
    80001360:	e426                	sd	s1,8(sp)
    80001362:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001364:	a1fff0ef          	jal	80000d82 <myproc>
    80001368:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000136a:	5d2040ef          	jal	8000593c <acquire>
  p->state = RUNNABLE;
    8000136e:	478d                	li	a5,3
    80001370:	cc9c                	sw	a5,24(s1)
  sched();
    80001372:	f2dff0ef          	jal	8000129e <sched>
  release(&p->lock);
    80001376:	8526                	mv	a0,s1
    80001378:	658040ef          	jal	800059d0 <release>
}
    8000137c:	60e2                	ld	ra,24(sp)
    8000137e:	6442                	ld	s0,16(sp)
    80001380:	64a2                	ld	s1,8(sp)
    80001382:	6105                	addi	sp,sp,32
    80001384:	8082                	ret

0000000080001386 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001386:	7179                	addi	sp,sp,-48
    80001388:	f406                	sd	ra,40(sp)
    8000138a:	f022                	sd	s0,32(sp)
    8000138c:	ec26                	sd	s1,24(sp)
    8000138e:	e84a                	sd	s2,16(sp)
    80001390:	e44e                	sd	s3,8(sp)
    80001392:	1800                	addi	s0,sp,48
    80001394:	89aa                	mv	s3,a0
    80001396:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001398:	9ebff0ef          	jal	80000d82 <myproc>
    8000139c:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    8000139e:	59e040ef          	jal	8000593c <acquire>
  release(lk);
    800013a2:	854a                	mv	a0,s2
    800013a4:	62c040ef          	jal	800059d0 <release>

  // Go to sleep.
  p->chan = chan;
    800013a8:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    800013ac:	4789                	li	a5,2
    800013ae:	cc9c                	sw	a5,24(s1)

  sched();
    800013b0:	eefff0ef          	jal	8000129e <sched>

  // Tidy up.
  p->chan = 0;
    800013b4:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    800013b8:	8526                	mv	a0,s1
    800013ba:	616040ef          	jal	800059d0 <release>
  acquire(lk);
    800013be:	854a                	mv	a0,s2
    800013c0:	57c040ef          	jal	8000593c <acquire>
}
    800013c4:	70a2                	ld	ra,40(sp)
    800013c6:	7402                	ld	s0,32(sp)
    800013c8:	64e2                	ld	s1,24(sp)
    800013ca:	6942                	ld	s2,16(sp)
    800013cc:	69a2                	ld	s3,8(sp)
    800013ce:	6145                	addi	sp,sp,48
    800013d0:	8082                	ret

00000000800013d2 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800013d2:	7139                	addi	sp,sp,-64
    800013d4:	fc06                	sd	ra,56(sp)
    800013d6:	f822                	sd	s0,48(sp)
    800013d8:	f426                	sd	s1,40(sp)
    800013da:	f04a                	sd	s2,32(sp)
    800013dc:	ec4e                	sd	s3,24(sp)
    800013de:	e852                	sd	s4,16(sp)
    800013e0:	e456                	sd	s5,8(sp)
    800013e2:	0080                	addi	s0,sp,64
    800013e4:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800013e6:	00007497          	auipc	s1,0x7
    800013ea:	99a48493          	addi	s1,s1,-1638 # 80007d80 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800013ee:	4989                	li	s3,2
        p->state = RUNNABLE;
    800013f0:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800013f2:	0000d917          	auipc	s2,0xd
    800013f6:	d8e90913          	addi	s2,s2,-626 # 8000e180 <tickslock>
    800013fa:	a801                	j	8000140a <wakeup+0x38>
      }
      release(&p->lock);
    800013fc:	8526                	mv	a0,s1
    800013fe:	5d2040ef          	jal	800059d0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001402:	19048493          	addi	s1,s1,400
    80001406:	03248263          	beq	s1,s2,8000142a <wakeup+0x58>
    if(p != myproc()){
    8000140a:	979ff0ef          	jal	80000d82 <myproc>
    8000140e:	fe950ae3          	beq	a0,s1,80001402 <wakeup+0x30>
      acquire(&p->lock);
    80001412:	8526                	mv	a0,s1
    80001414:	528040ef          	jal	8000593c <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001418:	4c9c                	lw	a5,24(s1)
    8000141a:	ff3791e3          	bne	a5,s3,800013fc <wakeup+0x2a>
    8000141e:	709c                	ld	a5,32(s1)
    80001420:	fd479ee3          	bne	a5,s4,800013fc <wakeup+0x2a>
        p->state = RUNNABLE;
    80001424:	0154ac23          	sw	s5,24(s1)
    80001428:	bfd1                	j	800013fc <wakeup+0x2a>
    }
  }
}
    8000142a:	70e2                	ld	ra,56(sp)
    8000142c:	7442                	ld	s0,48(sp)
    8000142e:	74a2                	ld	s1,40(sp)
    80001430:	7902                	ld	s2,32(sp)
    80001432:	69e2                	ld	s3,24(sp)
    80001434:	6a42                	ld	s4,16(sp)
    80001436:	6aa2                	ld	s5,8(sp)
    80001438:	6121                	addi	sp,sp,64
    8000143a:	8082                	ret

000000008000143c <reparent>:
{
    8000143c:	7179                	addi	sp,sp,-48
    8000143e:	f406                	sd	ra,40(sp)
    80001440:	f022                	sd	s0,32(sp)
    80001442:	ec26                	sd	s1,24(sp)
    80001444:	e84a                	sd	s2,16(sp)
    80001446:	e44e                	sd	s3,8(sp)
    80001448:	e052                	sd	s4,0(sp)
    8000144a:	1800                	addi	s0,sp,48
    8000144c:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000144e:	00007497          	auipc	s1,0x7
    80001452:	93248493          	addi	s1,s1,-1742 # 80007d80 <proc>
      pp->parent = initproc;
    80001456:	00006a17          	auipc	s4,0x6
    8000145a:	4baa0a13          	addi	s4,s4,1210 # 80007910 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000145e:	0000d997          	auipc	s3,0xd
    80001462:	d2298993          	addi	s3,s3,-734 # 8000e180 <tickslock>
    80001466:	a029                	j	80001470 <reparent+0x34>
    80001468:	19048493          	addi	s1,s1,400
    8000146c:	01348b63          	beq	s1,s3,80001482 <reparent+0x46>
    if(pp->parent == p){
    80001470:	7c9c                	ld	a5,56(s1)
    80001472:	ff279be3          	bne	a5,s2,80001468 <reparent+0x2c>
      pp->parent = initproc;
    80001476:	000a3503          	ld	a0,0(s4)
    8000147a:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000147c:	f57ff0ef          	jal	800013d2 <wakeup>
    80001480:	b7e5                	j	80001468 <reparent+0x2c>
}
    80001482:	70a2                	ld	ra,40(sp)
    80001484:	7402                	ld	s0,32(sp)
    80001486:	64e2                	ld	s1,24(sp)
    80001488:	6942                	ld	s2,16(sp)
    8000148a:	69a2                	ld	s3,8(sp)
    8000148c:	6a02                	ld	s4,0(sp)
    8000148e:	6145                	addi	sp,sp,48
    80001490:	8082                	ret

0000000080001492 <exit>:
{
    80001492:	7179                	addi	sp,sp,-48
    80001494:	f406                	sd	ra,40(sp)
    80001496:	f022                	sd	s0,32(sp)
    80001498:	ec26                	sd	s1,24(sp)
    8000149a:	e84a                	sd	s2,16(sp)
    8000149c:	e44e                	sd	s3,8(sp)
    8000149e:	e052                	sd	s4,0(sp)
    800014a0:	1800                	addi	s0,sp,48
    800014a2:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800014a4:	8dfff0ef          	jal	80000d82 <myproc>
    800014a8:	89aa                	mv	s3,a0
  if(p == initproc)
    800014aa:	00006797          	auipc	a5,0x6
    800014ae:	4667b783          	ld	a5,1126(a5) # 80007910 <initproc>
    800014b2:	0d050493          	addi	s1,a0,208
    800014b6:	15050913          	addi	s2,a0,336
    800014ba:	00a79b63          	bne	a5,a0,800014d0 <exit+0x3e>
    panic("init exiting");
    800014be:	00006517          	auipc	a0,0x6
    800014c2:	d6250513          	addi	a0,a0,-670 # 80007220 <etext+0x220>
    800014c6:	162040ef          	jal	80005628 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    800014ca:	04a1                	addi	s1,s1,8
    800014cc:	01248963          	beq	s1,s2,800014de <exit+0x4c>
    if(p->ofile[fd]){
    800014d0:	6088                	ld	a0,0(s1)
    800014d2:	dd65                	beqz	a0,800014ca <exit+0x38>
      fileclose(f);
    800014d4:	761010ef          	jal	80003434 <fileclose>
      p->ofile[fd] = 0;
    800014d8:	0004b023          	sd	zero,0(s1)
    800014dc:	b7fd                	j	800014ca <exit+0x38>
  begin_op();
    800014de:	325010ef          	jal	80003002 <begin_op>
  iput(p->cwd);
    800014e2:	1509b503          	ld	a0,336(s3)
    800014e6:	3e6010ef          	jal	800028cc <iput>
  end_op();
    800014ea:	389010ef          	jal	80003072 <end_op>
  p->cwd = 0;
    800014ee:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800014f2:	00006517          	auipc	a0,0x6
    800014f6:	47650513          	addi	a0,a0,1142 # 80007968 <wait_lock>
    800014fa:	442040ef          	jal	8000593c <acquire>
  reparent(p);
    800014fe:	854e                	mv	a0,s3
    80001500:	f3dff0ef          	jal	8000143c <reparent>
  wakeup(p->parent);
    80001504:	0389b503          	ld	a0,56(s3)
    80001508:	ecbff0ef          	jal	800013d2 <wakeup>
  acquire(&p->lock);
    8000150c:	854e                	mv	a0,s3
    8000150e:	42e040ef          	jal	8000593c <acquire>
  p->xstate = status;
    80001512:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80001516:	4795                	li	a5,5
    80001518:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    8000151c:	00006517          	auipc	a0,0x6
    80001520:	44c50513          	addi	a0,a0,1100 # 80007968 <wait_lock>
    80001524:	4ac040ef          	jal	800059d0 <release>
  sched();
    80001528:	d77ff0ef          	jal	8000129e <sched>
  panic("zombie exit");
    8000152c:	00006517          	auipc	a0,0x6
    80001530:	d0450513          	addi	a0,a0,-764 # 80007230 <etext+0x230>
    80001534:	0f4040ef          	jal	80005628 <panic>

0000000080001538 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80001538:	7179                	addi	sp,sp,-48
    8000153a:	f406                	sd	ra,40(sp)
    8000153c:	f022                	sd	s0,32(sp)
    8000153e:	ec26                	sd	s1,24(sp)
    80001540:	e84a                	sd	s2,16(sp)
    80001542:	e44e                	sd	s3,8(sp)
    80001544:	1800                	addi	s0,sp,48
    80001546:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80001548:	00007497          	auipc	s1,0x7
    8000154c:	83848493          	addi	s1,s1,-1992 # 80007d80 <proc>
    80001550:	0000d997          	auipc	s3,0xd
    80001554:	c3098993          	addi	s3,s3,-976 # 8000e180 <tickslock>
    acquire(&p->lock);
    80001558:	8526                	mv	a0,s1
    8000155a:	3e2040ef          	jal	8000593c <acquire>
    if(p->pid == pid){
    8000155e:	589c                	lw	a5,48(s1)
    80001560:	01278b63          	beq	a5,s2,80001576 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80001564:	8526                	mv	a0,s1
    80001566:	46a040ef          	jal	800059d0 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    8000156a:	19048493          	addi	s1,s1,400
    8000156e:	ff3495e3          	bne	s1,s3,80001558 <kill+0x20>
  }
  return -1;
    80001572:	557d                	li	a0,-1
    80001574:	a819                	j	8000158a <kill+0x52>
      p->killed = 1;
    80001576:	4785                	li	a5,1
    80001578:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    8000157a:	4c98                	lw	a4,24(s1)
    8000157c:	4789                	li	a5,2
    8000157e:	00f70d63          	beq	a4,a5,80001598 <kill+0x60>
      release(&p->lock);
    80001582:	8526                	mv	a0,s1
    80001584:	44c040ef          	jal	800059d0 <release>
      return 0;
    80001588:	4501                	li	a0,0
}
    8000158a:	70a2                	ld	ra,40(sp)
    8000158c:	7402                	ld	s0,32(sp)
    8000158e:	64e2                	ld	s1,24(sp)
    80001590:	6942                	ld	s2,16(sp)
    80001592:	69a2                	ld	s3,8(sp)
    80001594:	6145                	addi	sp,sp,48
    80001596:	8082                	ret
        p->state = RUNNABLE;
    80001598:	478d                	li	a5,3
    8000159a:	cc9c                	sw	a5,24(s1)
    8000159c:	b7dd                	j	80001582 <kill+0x4a>

000000008000159e <setkilled>:

void
setkilled(struct proc *p)
{
    8000159e:	1101                	addi	sp,sp,-32
    800015a0:	ec06                	sd	ra,24(sp)
    800015a2:	e822                	sd	s0,16(sp)
    800015a4:	e426                	sd	s1,8(sp)
    800015a6:	1000                	addi	s0,sp,32
    800015a8:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800015aa:	392040ef          	jal	8000593c <acquire>
  p->killed = 1;
    800015ae:	4785                	li	a5,1
    800015b0:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800015b2:	8526                	mv	a0,s1
    800015b4:	41c040ef          	jal	800059d0 <release>
}
    800015b8:	60e2                	ld	ra,24(sp)
    800015ba:	6442                	ld	s0,16(sp)
    800015bc:	64a2                	ld	s1,8(sp)
    800015be:	6105                	addi	sp,sp,32
    800015c0:	8082                	ret

00000000800015c2 <killed>:

int
killed(struct proc *p)
{
    800015c2:	1101                	addi	sp,sp,-32
    800015c4:	ec06                	sd	ra,24(sp)
    800015c6:	e822                	sd	s0,16(sp)
    800015c8:	e426                	sd	s1,8(sp)
    800015ca:	e04a                	sd	s2,0(sp)
    800015cc:	1000                	addi	s0,sp,32
    800015ce:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800015d0:	36c040ef          	jal	8000593c <acquire>
  k = p->killed;
    800015d4:	549c                	lw	a5,40(s1)
    800015d6:	893e                	mv	s2,a5
  release(&p->lock);
    800015d8:	8526                	mv	a0,s1
    800015da:	3f6040ef          	jal	800059d0 <release>
  return k;
}
    800015de:	854a                	mv	a0,s2
    800015e0:	60e2                	ld	ra,24(sp)
    800015e2:	6442                	ld	s0,16(sp)
    800015e4:	64a2                	ld	s1,8(sp)
    800015e6:	6902                	ld	s2,0(sp)
    800015e8:	6105                	addi	sp,sp,32
    800015ea:	8082                	ret

00000000800015ec <wait>:
{
    800015ec:	715d                	addi	sp,sp,-80
    800015ee:	e486                	sd	ra,72(sp)
    800015f0:	e0a2                	sd	s0,64(sp)
    800015f2:	fc26                	sd	s1,56(sp)
    800015f4:	f84a                	sd	s2,48(sp)
    800015f6:	f44e                	sd	s3,40(sp)
    800015f8:	f052                	sd	s4,32(sp)
    800015fa:	ec56                	sd	s5,24(sp)
    800015fc:	e85a                	sd	s6,16(sp)
    800015fe:	e45e                	sd	s7,8(sp)
    80001600:	0880                	addi	s0,sp,80
    80001602:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    80001604:	f7eff0ef          	jal	80000d82 <myproc>
    80001608:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000160a:	00006517          	auipc	a0,0x6
    8000160e:	35e50513          	addi	a0,a0,862 # 80007968 <wait_lock>
    80001612:	32a040ef          	jal	8000593c <acquire>
        if(pp->state == ZOMBIE){
    80001616:	4a15                	li	s4,5
        havekids = 1;
    80001618:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000161a:	0000d997          	auipc	s3,0xd
    8000161e:	b6698993          	addi	s3,s3,-1178 # 8000e180 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80001622:	00006b17          	auipc	s6,0x6
    80001626:	346b0b13          	addi	s6,s6,838 # 80007968 <wait_lock>
    8000162a:	a869                	j	800016c4 <wait+0xd8>
          pid = pp->pid;
    8000162c:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80001630:	000b8c63          	beqz	s7,80001648 <wait+0x5c>
    80001634:	4691                	li	a3,4
    80001636:	02c48613          	addi	a2,s1,44
    8000163a:	85de                	mv	a1,s7
    8000163c:	05093503          	ld	a0,80(s2)
    80001640:	bc2ff0ef          	jal	80000a02 <copyout>
    80001644:	02054a63          	bltz	a0,80001678 <wait+0x8c>
          freeproc(pp);
    80001648:	8526                	mv	a0,s1
    8000164a:	8adff0ef          	jal	80000ef6 <freeproc>
          release(&pp->lock);
    8000164e:	8526                	mv	a0,s1
    80001650:	380040ef          	jal	800059d0 <release>
          release(&wait_lock);
    80001654:	00006517          	auipc	a0,0x6
    80001658:	31450513          	addi	a0,a0,788 # 80007968 <wait_lock>
    8000165c:	374040ef          	jal	800059d0 <release>
}
    80001660:	854e                	mv	a0,s3
    80001662:	60a6                	ld	ra,72(sp)
    80001664:	6406                	ld	s0,64(sp)
    80001666:	74e2                	ld	s1,56(sp)
    80001668:	7942                	ld	s2,48(sp)
    8000166a:	79a2                	ld	s3,40(sp)
    8000166c:	7a02                	ld	s4,32(sp)
    8000166e:	6ae2                	ld	s5,24(sp)
    80001670:	6b42                	ld	s6,16(sp)
    80001672:	6ba2                	ld	s7,8(sp)
    80001674:	6161                	addi	sp,sp,80
    80001676:	8082                	ret
            release(&pp->lock);
    80001678:	8526                	mv	a0,s1
    8000167a:	356040ef          	jal	800059d0 <release>
            release(&wait_lock);
    8000167e:	00006517          	auipc	a0,0x6
    80001682:	2ea50513          	addi	a0,a0,746 # 80007968 <wait_lock>
    80001686:	34a040ef          	jal	800059d0 <release>
            return -1;
    8000168a:	59fd                	li	s3,-1
    8000168c:	bfd1                	j	80001660 <wait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000168e:	19048493          	addi	s1,s1,400
    80001692:	03348063          	beq	s1,s3,800016b2 <wait+0xc6>
      if(pp->parent == p){
    80001696:	7c9c                	ld	a5,56(s1)
    80001698:	ff279be3          	bne	a5,s2,8000168e <wait+0xa2>
        acquire(&pp->lock);
    8000169c:	8526                	mv	a0,s1
    8000169e:	29e040ef          	jal	8000593c <acquire>
        if(pp->state == ZOMBIE){
    800016a2:	4c9c                	lw	a5,24(s1)
    800016a4:	f94784e3          	beq	a5,s4,8000162c <wait+0x40>
        release(&pp->lock);
    800016a8:	8526                	mv	a0,s1
    800016aa:	326040ef          	jal	800059d0 <release>
        havekids = 1;
    800016ae:	8756                	mv	a4,s5
    800016b0:	bff9                	j	8000168e <wait+0xa2>
    if(!havekids || killed(p)){
    800016b2:	cf19                	beqz	a4,800016d0 <wait+0xe4>
    800016b4:	854a                	mv	a0,s2
    800016b6:	f0dff0ef          	jal	800015c2 <killed>
    800016ba:	e919                	bnez	a0,800016d0 <wait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800016bc:	85da                	mv	a1,s6
    800016be:	854a                	mv	a0,s2
    800016c0:	cc7ff0ef          	jal	80001386 <sleep>
    havekids = 0;
    800016c4:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800016c6:	00006497          	auipc	s1,0x6
    800016ca:	6ba48493          	addi	s1,s1,1722 # 80007d80 <proc>
    800016ce:	b7e1                	j	80001696 <wait+0xaa>
      release(&wait_lock);
    800016d0:	00006517          	auipc	a0,0x6
    800016d4:	29850513          	addi	a0,a0,664 # 80007968 <wait_lock>
    800016d8:	2f8040ef          	jal	800059d0 <release>
      return -1;
    800016dc:	59fd                	li	s3,-1
    800016de:	b749                	j	80001660 <wait+0x74>

00000000800016e0 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800016e0:	7179                	addi	sp,sp,-48
    800016e2:	f406                	sd	ra,40(sp)
    800016e4:	f022                	sd	s0,32(sp)
    800016e6:	ec26                	sd	s1,24(sp)
    800016e8:	e84a                	sd	s2,16(sp)
    800016ea:	e44e                	sd	s3,8(sp)
    800016ec:	e052                	sd	s4,0(sp)
    800016ee:	1800                	addi	s0,sp,48
    800016f0:	84aa                	mv	s1,a0
    800016f2:	8a2e                	mv	s4,a1
    800016f4:	89b2                	mv	s3,a2
    800016f6:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800016f8:	e8aff0ef          	jal	80000d82 <myproc>
  if(user_dst){
    800016fc:	cc99                	beqz	s1,8000171a <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800016fe:	86ca                	mv	a3,s2
    80001700:	864e                	mv	a2,s3
    80001702:	85d2                	mv	a1,s4
    80001704:	6928                	ld	a0,80(a0)
    80001706:	afcff0ef          	jal	80000a02 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    8000170a:	70a2                	ld	ra,40(sp)
    8000170c:	7402                	ld	s0,32(sp)
    8000170e:	64e2                	ld	s1,24(sp)
    80001710:	6942                	ld	s2,16(sp)
    80001712:	69a2                	ld	s3,8(sp)
    80001714:	6a02                	ld	s4,0(sp)
    80001716:	6145                	addi	sp,sp,48
    80001718:	8082                	ret
    memmove((char *)dst, src, len);
    8000171a:	0009061b          	sext.w	a2,s2
    8000171e:	85ce                	mv	a1,s3
    80001720:	8552                	mv	a0,s4
    80001722:	a9dfe0ef          	jal	800001be <memmove>
    return 0;
    80001726:	8526                	mv	a0,s1
    80001728:	b7cd                	j	8000170a <either_copyout+0x2a>

000000008000172a <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000172a:	7179                	addi	sp,sp,-48
    8000172c:	f406                	sd	ra,40(sp)
    8000172e:	f022                	sd	s0,32(sp)
    80001730:	ec26                	sd	s1,24(sp)
    80001732:	e84a                	sd	s2,16(sp)
    80001734:	e44e                	sd	s3,8(sp)
    80001736:	e052                	sd	s4,0(sp)
    80001738:	1800                	addi	s0,sp,48
    8000173a:	8a2a                	mv	s4,a0
    8000173c:	84ae                	mv	s1,a1
    8000173e:	89b2                	mv	s3,a2
    80001740:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80001742:	e40ff0ef          	jal	80000d82 <myproc>
  if(user_src){
    80001746:	cc99                	beqz	s1,80001764 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80001748:	86ca                	mv	a3,s2
    8000174a:	864e                	mv	a2,s3
    8000174c:	85d2                	mv	a1,s4
    8000174e:	6928                	ld	a0,80(a0)
    80001750:	b62ff0ef          	jal	80000ab2 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80001754:	70a2                	ld	ra,40(sp)
    80001756:	7402                	ld	s0,32(sp)
    80001758:	64e2                	ld	s1,24(sp)
    8000175a:	6942                	ld	s2,16(sp)
    8000175c:	69a2                	ld	s3,8(sp)
    8000175e:	6a02                	ld	s4,0(sp)
    80001760:	6145                	addi	sp,sp,48
    80001762:	8082                	ret
    memmove(dst, (char*)src, len);
    80001764:	0009061b          	sext.w	a2,s2
    80001768:	85ce                	mv	a1,s3
    8000176a:	8552                	mv	a0,s4
    8000176c:	a53fe0ef          	jal	800001be <memmove>
    return 0;
    80001770:	8526                	mv	a0,s1
    80001772:	b7cd                	j	80001754 <either_copyin+0x2a>

0000000080001774 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80001774:	715d                	addi	sp,sp,-80
    80001776:	e486                	sd	ra,72(sp)
    80001778:	e0a2                	sd	s0,64(sp)
    8000177a:	fc26                	sd	s1,56(sp)
    8000177c:	f84a                	sd	s2,48(sp)
    8000177e:	f44e                	sd	s3,40(sp)
    80001780:	f052                	sd	s4,32(sp)
    80001782:	ec56                	sd	s5,24(sp)
    80001784:	e85a                	sd	s6,16(sp)
    80001786:	e45e                	sd	s7,8(sp)
    80001788:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    8000178a:	00006517          	auipc	a0,0x6
    8000178e:	88e50513          	addi	a0,a0,-1906 # 80007018 <etext+0x18>
    80001792:	2fd030ef          	jal	8000528e <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001796:	00006497          	auipc	s1,0x6
    8000179a:	74248493          	addi	s1,s1,1858 # 80007ed8 <proc+0x158>
    8000179e:	0000d917          	auipc	s2,0xd
    800017a2:	b3a90913          	addi	s2,s2,-1222 # 8000e2d8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800017a6:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800017a8:	00006997          	auipc	s3,0x6
    800017ac:	a9898993          	addi	s3,s3,-1384 # 80007240 <etext+0x240>
    printf("%d %s %s", p->pid, state, p->name);
    800017b0:	00006a97          	auipc	s5,0x6
    800017b4:	a98a8a93          	addi	s5,s5,-1384 # 80007248 <etext+0x248>
    printf("\n");
    800017b8:	00006a17          	auipc	s4,0x6
    800017bc:	860a0a13          	addi	s4,s4,-1952 # 80007018 <etext+0x18>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800017c0:	00006b97          	auipc	s7,0x6
    800017c4:	fc8b8b93          	addi	s7,s7,-56 # 80007788 <states.0>
    800017c8:	a829                	j	800017e2 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800017ca:	ed86a583          	lw	a1,-296(a3)
    800017ce:	8556                	mv	a0,s5
    800017d0:	2bf030ef          	jal	8000528e <printf>
    printf("\n");
    800017d4:	8552                	mv	a0,s4
    800017d6:	2b9030ef          	jal	8000528e <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800017da:	19048493          	addi	s1,s1,400
    800017de:	03248263          	beq	s1,s2,80001802 <procdump+0x8e>
    if(p->state == UNUSED)
    800017e2:	86a6                	mv	a3,s1
    800017e4:	ec04a783          	lw	a5,-320(s1)
    800017e8:	dbed                	beqz	a5,800017da <procdump+0x66>
      state = "???";
    800017ea:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800017ec:	fcfb6fe3          	bltu	s6,a5,800017ca <procdump+0x56>
    800017f0:	02079713          	slli	a4,a5,0x20
    800017f4:	01d75793          	srli	a5,a4,0x1d
    800017f8:	97de                	add	a5,a5,s7
    800017fa:	6390                	ld	a2,0(a5)
    800017fc:	f679                	bnez	a2,800017ca <procdump+0x56>
      state = "???";
    800017fe:	864e                	mv	a2,s3
    80001800:	b7e9                	j	800017ca <procdump+0x56>
  }
}
    80001802:	60a6                	ld	ra,72(sp)
    80001804:	6406                	ld	s0,64(sp)
    80001806:	74e2                	ld	s1,56(sp)
    80001808:	7942                	ld	s2,48(sp)
    8000180a:	79a2                	ld	s3,40(sp)
    8000180c:	7a02                	ld	s4,32(sp)
    8000180e:	6ae2                	ld	s5,24(sp)
    80001810:	6b42                	ld	s6,16(sp)
    80001812:	6ba2                	ld	s7,8(sp)
    80001814:	6161                	addi	sp,sp,80
    80001816:	8082                	ret

0000000080001818 <sigalarm>:

int
sigalarm(uint64 ticks, void (*handler)())
{
    80001818:	1101                	addi	sp,sp,-32
    8000181a:	ec06                	sd	ra,24(sp)
    8000181c:	e822                	sd	s0,16(sp)
    8000181e:	e426                	sd	s1,8(sp)
    80001820:	e04a                	sd	s2,0(sp)
    80001822:	1000                	addi	s0,sp,32
    80001824:	892a                	mv	s2,a0
    80001826:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    80001828:	d5aff0ef          	jal	80000d82 <myproc>
  p->alarmticks = ticks;
    8000182c:	17253423          	sd	s2,360(a0)
  p->alarmhandler = handler;
    80001830:	16953823          	sd	s1,368(a0)
  p->realarmticks = ticks;
    80001834:	19253023          	sd	s2,384(a0)
  p->realarmhandler = handler;
    80001838:	18953423          	sd	s1,392(a0)
  return 0;
}
    8000183c:	4501                	li	a0,0
    8000183e:	60e2                	ld	ra,24(sp)
    80001840:	6442                	ld	s0,16(sp)
    80001842:	64a2                	ld	s1,8(sp)
    80001844:	6902                	ld	s2,0(sp)
    80001846:	6105                	addi	sp,sp,32
    80001848:	8082                	ret

000000008000184a <sigreturn>:

int
sigreturn(void)
{
    8000184a:	1101                	addi	sp,sp,-32
    8000184c:	ec06                	sd	ra,24(sp)
    8000184e:	e822                	sd	s0,16(sp)
    80001850:	e426                	sd	s1,8(sp)
    80001852:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001854:	d2eff0ef          	jal	80000d82 <myproc>
    80001858:	84aa                	mv	s1,a0
  memmove(p->trapframe, p->sigreturntrapframe, sizeof(struct trapframe));
    8000185a:	12000613          	li	a2,288
    8000185e:	17853583          	ld	a1,376(a0)
    80001862:	6d28                	ld	a0,88(a0)
    80001864:	95bfe0ef          	jal	800001be <memmove>
  p->alarmticks = p->realarmticks;
    80001868:	1804b783          	ld	a5,384(s1)
    8000186c:	16f4b423          	sd	a5,360(s1)
  p->alarmhandler = p->realarmhandler;
    80001870:	1884b783          	ld	a5,392(s1)
    80001874:	16f4b823          	sd	a5,368(s1)
  return p->trapframe->a0;
    80001878:	6cbc                	ld	a5,88(s1)
    8000187a:	5ba8                	lw	a0,112(a5)
    8000187c:	60e2                	ld	ra,24(sp)
    8000187e:	6442                	ld	s0,16(sp)
    80001880:	64a2                	ld	s1,8(sp)
    80001882:	6105                	addi	sp,sp,32
    80001884:	8082                	ret

0000000080001886 <swtch>:
    80001886:	00153023          	sd	ra,0(a0)
    8000188a:	00253423          	sd	sp,8(a0)
    8000188e:	e900                	sd	s0,16(a0)
    80001890:	ed04                	sd	s1,24(a0)
    80001892:	03253023          	sd	s2,32(a0)
    80001896:	03353423          	sd	s3,40(a0)
    8000189a:	03453823          	sd	s4,48(a0)
    8000189e:	03553c23          	sd	s5,56(a0)
    800018a2:	05653023          	sd	s6,64(a0)
    800018a6:	05753423          	sd	s7,72(a0)
    800018aa:	05853823          	sd	s8,80(a0)
    800018ae:	05953c23          	sd	s9,88(a0)
    800018b2:	07a53023          	sd	s10,96(a0)
    800018b6:	07b53423          	sd	s11,104(a0)
    800018ba:	0005b083          	ld	ra,0(a1)
    800018be:	0085b103          	ld	sp,8(a1)
    800018c2:	6980                	ld	s0,16(a1)
    800018c4:	6d84                	ld	s1,24(a1)
    800018c6:	0205b903          	ld	s2,32(a1)
    800018ca:	0285b983          	ld	s3,40(a1)
    800018ce:	0305ba03          	ld	s4,48(a1)
    800018d2:	0385ba83          	ld	s5,56(a1)
    800018d6:	0405bb03          	ld	s6,64(a1)
    800018da:	0485bb83          	ld	s7,72(a1)
    800018de:	0505bc03          	ld	s8,80(a1)
    800018e2:	0585bc83          	ld	s9,88(a1)
    800018e6:	0605bd03          	ld	s10,96(a1)
    800018ea:	0685bd83          	ld	s11,104(a1)
    800018ee:	8082                	ret

00000000800018f0 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800018f0:	1141                	addi	sp,sp,-16
    800018f2:	e406                	sd	ra,8(sp)
    800018f4:	e022                	sd	s0,0(sp)
    800018f6:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800018f8:	00006597          	auipc	a1,0x6
    800018fc:	99058593          	addi	a1,a1,-1648 # 80007288 <etext+0x288>
    80001900:	0000d517          	auipc	a0,0xd
    80001904:	88050513          	addi	a0,a0,-1920 # 8000e180 <tickslock>
    80001908:	7ab030ef          	jal	800058b2 <initlock>
}
    8000190c:	60a2                	ld	ra,8(sp)
    8000190e:	6402                	ld	s0,0(sp)
    80001910:	0141                	addi	sp,sp,16
    80001912:	8082                	ret

0000000080001914 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80001914:	1141                	addi	sp,sp,-16
    80001916:	e406                	sd	ra,8(sp)
    80001918:	e022                	sd	s0,0(sp)
    8000191a:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000191c:	00003797          	auipc	a5,0x3
    80001920:	ed478793          	addi	a5,a5,-300 # 800047f0 <kernelvec>
    80001924:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80001928:	60a2                	ld	ra,8(sp)
    8000192a:	6402                	ld	s0,0(sp)
    8000192c:	0141                	addi	sp,sp,16
    8000192e:	8082                	ret

0000000080001930 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80001930:	1141                	addi	sp,sp,-16
    80001932:	e406                	sd	ra,8(sp)
    80001934:	e022                	sd	s0,0(sp)
    80001936:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80001938:	c4aff0ef          	jal	80000d82 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000193c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001940:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001942:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80001946:	00004697          	auipc	a3,0x4
    8000194a:	6ba68693          	addi	a3,a3,1722 # 80006000 <_trampoline>
    8000194e:	00004717          	auipc	a4,0x4
    80001952:	6b270713          	addi	a4,a4,1714 # 80006000 <_trampoline>
    80001956:	8f15                	sub	a4,a4,a3
    80001958:	040007b7          	lui	a5,0x4000
    8000195c:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    8000195e:	07b2                	slli	a5,a5,0xc
    80001960:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001962:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80001966:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80001968:	18002673          	csrr	a2,satp
    8000196c:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000196e:	6d30                	ld	a2,88(a0)
    80001970:	6138                	ld	a4,64(a0)
    80001972:	6585                	lui	a1,0x1
    80001974:	972e                	add	a4,a4,a1
    80001976:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80001978:	6d38                	ld	a4,88(a0)
    8000197a:	00000617          	auipc	a2,0x0
    8000197e:	11460613          	addi	a2,a2,276 # 80001a8e <usertrap>
    80001982:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80001984:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80001986:	8612                	mv	a2,tp
    80001988:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000198a:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000198e:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80001992:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001996:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000199a:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000199c:	6f18                	ld	a4,24(a4)
    8000199e:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    800019a2:	6928                	ld	a0,80(a0)
    800019a4:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800019a6:	00004717          	auipc	a4,0x4
    800019aa:	6f670713          	addi	a4,a4,1782 # 8000609c <userret>
    800019ae:	8f15                	sub	a4,a4,a3
    800019b0:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019b2:	577d                	li	a4,-1
    800019b4:	177e                	slli	a4,a4,0x3f
    800019b6:	8d59                	or	a0,a0,a4
    800019b8:	9782                	jalr	a5
}
    800019ba:	60a2                	ld	ra,8(sp)
    800019bc:	6402                	ld	s0,0(sp)
    800019be:	0141                	addi	sp,sp,16
    800019c0:	8082                	ret

00000000800019c2 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800019c2:	1141                	addi	sp,sp,-16
    800019c4:	e406                	sd	ra,8(sp)
    800019c6:	e022                	sd	s0,0(sp)
    800019c8:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800019ca:	b84ff0ef          	jal	80000d4e <cpuid>
    800019ce:	cd11                	beqz	a0,800019ea <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800019d0:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800019d4:	000f4737          	lui	a4,0xf4
    800019d8:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800019dc:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800019de:	14d79073          	csrw	stimecmp,a5
}
    800019e2:	60a2                	ld	ra,8(sp)
    800019e4:	6402                	ld	s0,0(sp)
    800019e6:	0141                	addi	sp,sp,16
    800019e8:	8082                	ret
    acquire(&tickslock);
    800019ea:	0000c517          	auipc	a0,0xc
    800019ee:	79650513          	addi	a0,a0,1942 # 8000e180 <tickslock>
    800019f2:	74b030ef          	jal	8000593c <acquire>
    ticks++;
    800019f6:	00006717          	auipc	a4,0x6
    800019fa:	f2270713          	addi	a4,a4,-222 # 80007918 <ticks>
    800019fe:	431c                	lw	a5,0(a4)
    80001a00:	2785                	addiw	a5,a5,1
    80001a02:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80001a04:	853a                	mv	a0,a4
    80001a06:	9cdff0ef          	jal	800013d2 <wakeup>
    release(&tickslock);
    80001a0a:	0000c517          	auipc	a0,0xc
    80001a0e:	77650513          	addi	a0,a0,1910 # 8000e180 <tickslock>
    80001a12:	7bf030ef          	jal	800059d0 <release>
    80001a16:	bf6d                	j	800019d0 <clockintr+0xe>

0000000080001a18 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001a18:	1101                	addi	sp,sp,-32
    80001a1a:	ec06                	sd	ra,24(sp)
    80001a1c:	e822                	sd	s0,16(sp)
    80001a1e:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001a20:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001a24:	57fd                	li	a5,-1
    80001a26:	17fe                	slli	a5,a5,0x3f
    80001a28:	07a5                	addi	a5,a5,9
    80001a2a:	00f70c63          	beq	a4,a5,80001a42 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80001a2e:	57fd                	li	a5,-1
    80001a30:	17fe                	slli	a5,a5,0x3f
    80001a32:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001a34:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001a36:	04f70863          	beq	a4,a5,80001a86 <devintr+0x6e>
  }
}
    80001a3a:	60e2                	ld	ra,24(sp)
    80001a3c:	6442                	ld	s0,16(sp)
    80001a3e:	6105                	addi	sp,sp,32
    80001a40:	8082                	ret
    80001a42:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80001a44:	659020ef          	jal	8000489c <plic_claim>
    80001a48:	872a                	mv	a4,a0
    80001a4a:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001a4c:	47a9                	li	a5,10
    80001a4e:	00f50963          	beq	a0,a5,80001a60 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    80001a52:	4785                	li	a5,1
    80001a54:	00f50963          	beq	a0,a5,80001a66 <devintr+0x4e>
    return 1;
    80001a58:	4505                	li	a0,1
    } else if(irq){
    80001a5a:	eb09                	bnez	a4,80001a6c <devintr+0x54>
    80001a5c:	64a2                	ld	s1,8(sp)
    80001a5e:	bff1                	j	80001a3a <devintr+0x22>
      uartintr();
    80001a60:	613030ef          	jal	80005872 <uartintr>
    if(irq)
    80001a64:	a819                	j	80001a7a <devintr+0x62>
      virtio_disk_intr();
    80001a66:	2cc030ef          	jal	80004d32 <virtio_disk_intr>
    if(irq)
    80001a6a:	a801                	j	80001a7a <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    80001a6c:	85ba                	mv	a1,a4
    80001a6e:	00006517          	auipc	a0,0x6
    80001a72:	82250513          	addi	a0,a0,-2014 # 80007290 <etext+0x290>
    80001a76:	019030ef          	jal	8000528e <printf>
      plic_complete(irq);
    80001a7a:	8526                	mv	a0,s1
    80001a7c:	641020ef          	jal	800048bc <plic_complete>
    return 1;
    80001a80:	4505                	li	a0,1
    80001a82:	64a2                	ld	s1,8(sp)
    80001a84:	bf5d                	j	80001a3a <devintr+0x22>
    clockintr();
    80001a86:	f3dff0ef          	jal	800019c2 <clockintr>
    return 2;
    80001a8a:	4509                	li	a0,2
    80001a8c:	b77d                	j	80001a3a <devintr+0x22>

0000000080001a8e <usertrap>:
{
    80001a8e:	1101                	addi	sp,sp,-32
    80001a90:	ec06                	sd	ra,24(sp)
    80001a92:	e822                	sd	s0,16(sp)
    80001a94:	e426                	sd	s1,8(sp)
    80001a96:	e04a                	sd	s2,0(sp)
    80001a98:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a9a:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80001a9e:	1007f793          	andi	a5,a5,256
    80001aa2:	ef85                	bnez	a5,80001ada <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001aa4:	00003797          	auipc	a5,0x3
    80001aa8:	d4c78793          	addi	a5,a5,-692 # 800047f0 <kernelvec>
    80001aac:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001ab0:	ad2ff0ef          	jal	80000d82 <myproc>
    80001ab4:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001ab6:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001ab8:	14102773          	csrr	a4,sepc
    80001abc:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001abe:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001ac2:	47a1                	li	a5,8
    80001ac4:	02f70163          	beq	a4,a5,80001ae6 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001ac8:	f51ff0ef          	jal	80001a18 <devintr>
    80001acc:	892a                	mv	s2,a0
    80001ace:	c939                	beqz	a0,80001b24 <usertrap+0x96>
  if(killed(p))
    80001ad0:	8526                	mv	a0,s1
    80001ad2:	af1ff0ef          	jal	800015c2 <killed>
    80001ad6:	c151                	beqz	a0,80001b5a <usertrap+0xcc>
    80001ad8:	a8b5                	j	80001b54 <usertrap+0xc6>
    panic("usertrap: not from user mode");
    80001ada:	00005517          	auipc	a0,0x5
    80001ade:	7d650513          	addi	a0,a0,2006 # 800072b0 <etext+0x2b0>
    80001ae2:	347030ef          	jal	80005628 <panic>
    if(killed(p))
    80001ae6:	addff0ef          	jal	800015c2 <killed>
    80001aea:	e90d                	bnez	a0,80001b1c <usertrap+0x8e>
    p->trapframe->epc += 4;
    80001aec:	6cb8                	ld	a4,88(s1)
    80001aee:	6f1c                	ld	a5,24(a4)
    80001af0:	0791                	addi	a5,a5,4
    80001af2:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001af4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001af8:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001afc:	10079073          	csrw	sstatus,a5
    syscall();
    80001b00:	26c000ef          	jal	80001d6c <syscall>
  if(killed(p))
    80001b04:	8526                	mv	a0,s1
    80001b06:	abdff0ef          	jal	800015c2 <killed>
    80001b0a:	e521                	bnez	a0,80001b52 <usertrap+0xc4>
  usertrapret();
    80001b0c:	e25ff0ef          	jal	80001930 <usertrapret>
}
    80001b10:	60e2                	ld	ra,24(sp)
    80001b12:	6442                	ld	s0,16(sp)
    80001b14:	64a2                	ld	s1,8(sp)
    80001b16:	6902                	ld	s2,0(sp)
    80001b18:	6105                	addi	sp,sp,32
    80001b1a:	8082                	ret
      exit(-1);
    80001b1c:	557d                	li	a0,-1
    80001b1e:	975ff0ef          	jal	80001492 <exit>
    80001b22:	b7e9                	j	80001aec <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001b24:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001b28:	5890                	lw	a2,48(s1)
    80001b2a:	00005517          	auipc	a0,0x5
    80001b2e:	7a650513          	addi	a0,a0,1958 # 800072d0 <etext+0x2d0>
    80001b32:	75c030ef          	jal	8000528e <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b36:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001b3a:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001b3e:	00005517          	auipc	a0,0x5
    80001b42:	7c250513          	addi	a0,a0,1986 # 80007300 <etext+0x300>
    80001b46:	748030ef          	jal	8000528e <printf>
    setkilled(p);
    80001b4a:	8526                	mv	a0,s1
    80001b4c:	a53ff0ef          	jal	8000159e <setkilled>
    80001b50:	bf55                	j	80001b04 <usertrap+0x76>
  if(killed(p))
    80001b52:	4901                	li	s2,0
    exit(-1);
    80001b54:	557d                	li	a0,-1
    80001b56:	93dff0ef          	jal	80001492 <exit>
  if(which_dev == 2){
    80001b5a:	4789                	li	a5,2
    80001b5c:	faf918e3          	bne	s2,a5,80001b0c <usertrap+0x7e>
    if(p->alarmticks > 0){
    80001b60:	1684b783          	ld	a5,360(s1)
    80001b64:	c789                	beqz	a5,80001b6e <usertrap+0xe0>
      p->alarmticks--;
    80001b66:	17fd                	addi	a5,a5,-1
    80001b68:	16f4b423          	sd	a5,360(s1)
      if(p->alarmticks == 0){
    80001b6c:	c781                	beqz	a5,80001b74 <usertrap+0xe6>
    yield();
    80001b6e:	fecff0ef          	jal	8000135a <yield>
    80001b72:	bf69                	j	80001b0c <usertrap+0x7e>
        memmove(p->sigreturntrapframe, p->trapframe, sizeof(struct trapframe));
    80001b74:	12000613          	li	a2,288
    80001b78:	6cac                	ld	a1,88(s1)
    80001b7a:	1784b503          	ld	a0,376(s1)
    80001b7e:	e40fe0ef          	jal	800001be <memmove>
        p->trapframe->epc = (uint64)p->alarmhandler;
    80001b82:	6cbc                	ld	a5,88(s1)
    80001b84:	1704b703          	ld	a4,368(s1)
    80001b88:	ef98                	sd	a4,24(a5)
        p->alarmhandler = 0;
    80001b8a:	1604b823          	sd	zero,368(s1)
    80001b8e:	b7c5                	j	80001b6e <usertrap+0xe0>

0000000080001b90 <kerneltrap>:
{
    80001b90:	7179                	addi	sp,sp,-48
    80001b92:	f406                	sd	ra,40(sp)
    80001b94:	f022                	sd	s0,32(sp)
    80001b96:	ec26                	sd	s1,24(sp)
    80001b98:	e84a                	sd	s2,16(sp)
    80001b9a:	e44e                	sd	s3,8(sp)
    80001b9c:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b9e:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001ba2:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001ba6:	142027f3          	csrr	a5,scause
    80001baa:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80001bac:	1004f793          	andi	a5,s1,256
    80001bb0:	c795                	beqz	a5,80001bdc <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001bb2:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001bb6:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001bb8:	eb85                	bnez	a5,80001be8 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80001bba:	e5fff0ef          	jal	80001a18 <devintr>
    80001bbe:	c91d                	beqz	a0,80001bf4 <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80001bc0:	4789                	li	a5,2
    80001bc2:	04f50a63          	beq	a0,a5,80001c16 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001bc6:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001bca:	10049073          	csrw	sstatus,s1
}
    80001bce:	70a2                	ld	ra,40(sp)
    80001bd0:	7402                	ld	s0,32(sp)
    80001bd2:	64e2                	ld	s1,24(sp)
    80001bd4:	6942                	ld	s2,16(sp)
    80001bd6:	69a2                	ld	s3,8(sp)
    80001bd8:	6145                	addi	sp,sp,48
    80001bda:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001bdc:	00005517          	auipc	a0,0x5
    80001be0:	74c50513          	addi	a0,a0,1868 # 80007328 <etext+0x328>
    80001be4:	245030ef          	jal	80005628 <panic>
    panic("kerneltrap: interrupts enabled");
    80001be8:	00005517          	auipc	a0,0x5
    80001bec:	76850513          	addi	a0,a0,1896 # 80007350 <etext+0x350>
    80001bf0:	239030ef          	jal	80005628 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001bf4:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001bf8:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001bfc:	85ce                	mv	a1,s3
    80001bfe:	00005517          	auipc	a0,0x5
    80001c02:	77250513          	addi	a0,a0,1906 # 80007370 <etext+0x370>
    80001c06:	688030ef          	jal	8000528e <printf>
    panic("kerneltrap");
    80001c0a:	00005517          	auipc	a0,0x5
    80001c0e:	78e50513          	addi	a0,a0,1934 # 80007398 <etext+0x398>
    80001c12:	217030ef          	jal	80005628 <panic>
  if(which_dev == 2 && myproc() != 0)
    80001c16:	96cff0ef          	jal	80000d82 <myproc>
    80001c1a:	d555                	beqz	a0,80001bc6 <kerneltrap+0x36>
    yield();
    80001c1c:	f3eff0ef          	jal	8000135a <yield>
    80001c20:	b75d                	j	80001bc6 <kerneltrap+0x36>

0000000080001c22 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001c22:	1101                	addi	sp,sp,-32
    80001c24:	ec06                	sd	ra,24(sp)
    80001c26:	e822                	sd	s0,16(sp)
    80001c28:	e426                	sd	s1,8(sp)
    80001c2a:	1000                	addi	s0,sp,32
    80001c2c:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c2e:	954ff0ef          	jal	80000d82 <myproc>
  switch (n) {
    80001c32:	4795                	li	a5,5
    80001c34:	0497e163          	bltu	a5,s1,80001c76 <argraw+0x54>
    80001c38:	048a                	slli	s1,s1,0x2
    80001c3a:	00006717          	auipc	a4,0x6
    80001c3e:	b7e70713          	addi	a4,a4,-1154 # 800077b8 <states.0+0x30>
    80001c42:	94ba                	add	s1,s1,a4
    80001c44:	409c                	lw	a5,0(s1)
    80001c46:	97ba                	add	a5,a5,a4
    80001c48:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001c4a:	6d3c                	ld	a5,88(a0)
    80001c4c:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001c4e:	60e2                	ld	ra,24(sp)
    80001c50:	6442                	ld	s0,16(sp)
    80001c52:	64a2                	ld	s1,8(sp)
    80001c54:	6105                	addi	sp,sp,32
    80001c56:	8082                	ret
    return p->trapframe->a1;
    80001c58:	6d3c                	ld	a5,88(a0)
    80001c5a:	7fa8                	ld	a0,120(a5)
    80001c5c:	bfcd                	j	80001c4e <argraw+0x2c>
    return p->trapframe->a2;
    80001c5e:	6d3c                	ld	a5,88(a0)
    80001c60:	63c8                	ld	a0,128(a5)
    80001c62:	b7f5                	j	80001c4e <argraw+0x2c>
    return p->trapframe->a3;
    80001c64:	6d3c                	ld	a5,88(a0)
    80001c66:	67c8                	ld	a0,136(a5)
    80001c68:	b7dd                	j	80001c4e <argraw+0x2c>
    return p->trapframe->a4;
    80001c6a:	6d3c                	ld	a5,88(a0)
    80001c6c:	6bc8                	ld	a0,144(a5)
    80001c6e:	b7c5                	j	80001c4e <argraw+0x2c>
    return p->trapframe->a5;
    80001c70:	6d3c                	ld	a5,88(a0)
    80001c72:	6fc8                	ld	a0,152(a5)
    80001c74:	bfe9                	j	80001c4e <argraw+0x2c>
  panic("argraw");
    80001c76:	00005517          	auipc	a0,0x5
    80001c7a:	73250513          	addi	a0,a0,1842 # 800073a8 <etext+0x3a8>
    80001c7e:	1ab030ef          	jal	80005628 <panic>

0000000080001c82 <fetchaddr>:
{
    80001c82:	1101                	addi	sp,sp,-32
    80001c84:	ec06                	sd	ra,24(sp)
    80001c86:	e822                	sd	s0,16(sp)
    80001c88:	e426                	sd	s1,8(sp)
    80001c8a:	e04a                	sd	s2,0(sp)
    80001c8c:	1000                	addi	s0,sp,32
    80001c8e:	84aa                	mv	s1,a0
    80001c90:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001c92:	8f0ff0ef          	jal	80000d82 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001c96:	653c                	ld	a5,72(a0)
    80001c98:	02f4f663          	bgeu	s1,a5,80001cc4 <fetchaddr+0x42>
    80001c9c:	00848713          	addi	a4,s1,8
    80001ca0:	02e7e463          	bltu	a5,a4,80001cc8 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001ca4:	46a1                	li	a3,8
    80001ca6:	8626                	mv	a2,s1
    80001ca8:	85ca                	mv	a1,s2
    80001caa:	6928                	ld	a0,80(a0)
    80001cac:	e07fe0ef          	jal	80000ab2 <copyin>
    80001cb0:	00a03533          	snez	a0,a0
    80001cb4:	40a0053b          	negw	a0,a0
}
    80001cb8:	60e2                	ld	ra,24(sp)
    80001cba:	6442                	ld	s0,16(sp)
    80001cbc:	64a2                	ld	s1,8(sp)
    80001cbe:	6902                	ld	s2,0(sp)
    80001cc0:	6105                	addi	sp,sp,32
    80001cc2:	8082                	ret
    return -1;
    80001cc4:	557d                	li	a0,-1
    80001cc6:	bfcd                	j	80001cb8 <fetchaddr+0x36>
    80001cc8:	557d                	li	a0,-1
    80001cca:	b7fd                	j	80001cb8 <fetchaddr+0x36>

0000000080001ccc <fetchstr>:
{
    80001ccc:	7179                	addi	sp,sp,-48
    80001cce:	f406                	sd	ra,40(sp)
    80001cd0:	f022                	sd	s0,32(sp)
    80001cd2:	ec26                	sd	s1,24(sp)
    80001cd4:	e84a                	sd	s2,16(sp)
    80001cd6:	e44e                	sd	s3,8(sp)
    80001cd8:	1800                	addi	s0,sp,48
    80001cda:	89aa                	mv	s3,a0
    80001cdc:	84ae                	mv	s1,a1
    80001cde:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80001ce0:	8a2ff0ef          	jal	80000d82 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001ce4:	86ca                	mv	a3,s2
    80001ce6:	864e                	mv	a2,s3
    80001ce8:	85a6                	mv	a1,s1
    80001cea:	6928                	ld	a0,80(a0)
    80001cec:	e4dfe0ef          	jal	80000b38 <copyinstr>
    80001cf0:	00054c63          	bltz	a0,80001d08 <fetchstr+0x3c>
  return strlen(buf);
    80001cf4:	8526                	mv	a0,s1
    80001cf6:	df2fe0ef          	jal	800002e8 <strlen>
}
    80001cfa:	70a2                	ld	ra,40(sp)
    80001cfc:	7402                	ld	s0,32(sp)
    80001cfe:	64e2                	ld	s1,24(sp)
    80001d00:	6942                	ld	s2,16(sp)
    80001d02:	69a2                	ld	s3,8(sp)
    80001d04:	6145                	addi	sp,sp,48
    80001d06:	8082                	ret
    return -1;
    80001d08:	557d                	li	a0,-1
    80001d0a:	bfc5                	j	80001cfa <fetchstr+0x2e>

0000000080001d0c <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001d0c:	1101                	addi	sp,sp,-32
    80001d0e:	ec06                	sd	ra,24(sp)
    80001d10:	e822                	sd	s0,16(sp)
    80001d12:	e426                	sd	s1,8(sp)
    80001d14:	1000                	addi	s0,sp,32
    80001d16:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001d18:	f0bff0ef          	jal	80001c22 <argraw>
    80001d1c:	c088                	sw	a0,0(s1)
}
    80001d1e:	60e2                	ld	ra,24(sp)
    80001d20:	6442                	ld	s0,16(sp)
    80001d22:	64a2                	ld	s1,8(sp)
    80001d24:	6105                	addi	sp,sp,32
    80001d26:	8082                	ret

0000000080001d28 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001d28:	1101                	addi	sp,sp,-32
    80001d2a:	ec06                	sd	ra,24(sp)
    80001d2c:	e822                	sd	s0,16(sp)
    80001d2e:	e426                	sd	s1,8(sp)
    80001d30:	1000                	addi	s0,sp,32
    80001d32:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001d34:	eefff0ef          	jal	80001c22 <argraw>
    80001d38:	e088                	sd	a0,0(s1)
}
    80001d3a:	60e2                	ld	ra,24(sp)
    80001d3c:	6442                	ld	s0,16(sp)
    80001d3e:	64a2                	ld	s1,8(sp)
    80001d40:	6105                	addi	sp,sp,32
    80001d42:	8082                	ret

0000000080001d44 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001d44:	1101                	addi	sp,sp,-32
    80001d46:	ec06                	sd	ra,24(sp)
    80001d48:	e822                	sd	s0,16(sp)
    80001d4a:	e426                	sd	s1,8(sp)
    80001d4c:	e04a                	sd	s2,0(sp)
    80001d4e:	1000                	addi	s0,sp,32
    80001d50:	892e                	mv	s2,a1
    80001d52:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80001d54:	ecfff0ef          	jal	80001c22 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80001d58:	8626                	mv	a2,s1
    80001d5a:	85ca                	mv	a1,s2
    80001d5c:	f71ff0ef          	jal	80001ccc <fetchstr>
}
    80001d60:	60e2                	ld	ra,24(sp)
    80001d62:	6442                	ld	s0,16(sp)
    80001d64:	64a2                	ld	s1,8(sp)
    80001d66:	6902                	ld	s2,0(sp)
    80001d68:	6105                	addi	sp,sp,32
    80001d6a:	8082                	ret

0000000080001d6c <syscall>:
[SYS_sigreturn] sys_sigreturn,
};

void
syscall(void)
{
    80001d6c:	1101                	addi	sp,sp,-32
    80001d6e:	ec06                	sd	ra,24(sp)
    80001d70:	e822                	sd	s0,16(sp)
    80001d72:	e426                	sd	s1,8(sp)
    80001d74:	e04a                	sd	s2,0(sp)
    80001d76:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001d78:	80aff0ef          	jal	80000d82 <myproc>
    80001d7c:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001d7e:	05853903          	ld	s2,88(a0)
    80001d82:	0a893783          	ld	a5,168(s2)
    80001d86:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001d8a:	37fd                	addiw	a5,a5,-1
    80001d8c:	4759                	li	a4,22
    80001d8e:	00f76f63          	bltu	a4,a5,80001dac <syscall+0x40>
    80001d92:	00369713          	slli	a4,a3,0x3
    80001d96:	00006797          	auipc	a5,0x6
    80001d9a:	a3a78793          	addi	a5,a5,-1478 # 800077d0 <syscalls>
    80001d9e:	97ba                	add	a5,a5,a4
    80001da0:	639c                	ld	a5,0(a5)
    80001da2:	c789                	beqz	a5,80001dac <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001da4:	9782                	jalr	a5
    80001da6:	06a93823          	sd	a0,112(s2)
    80001daa:	a829                	j	80001dc4 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001dac:	15848613          	addi	a2,s1,344
    80001db0:	588c                	lw	a1,48(s1)
    80001db2:	00005517          	auipc	a0,0x5
    80001db6:	5fe50513          	addi	a0,a0,1534 # 800073b0 <etext+0x3b0>
    80001dba:	4d4030ef          	jal	8000528e <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001dbe:	6cbc                	ld	a5,88(s1)
    80001dc0:	577d                	li	a4,-1
    80001dc2:	fbb8                	sd	a4,112(a5)
  }
}
    80001dc4:	60e2                	ld	ra,24(sp)
    80001dc6:	6442                	ld	s0,16(sp)
    80001dc8:	64a2                	ld	s1,8(sp)
    80001dca:	6902                	ld	s2,0(sp)
    80001dcc:	6105                	addi	sp,sp,32
    80001dce:	8082                	ret

0000000080001dd0 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001dd0:	1101                	addi	sp,sp,-32
    80001dd2:	ec06                	sd	ra,24(sp)
    80001dd4:	e822                	sd	s0,16(sp)
    80001dd6:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001dd8:	fec40593          	addi	a1,s0,-20
    80001ddc:	4501                	li	a0,0
    80001dde:	f2fff0ef          	jal	80001d0c <argint>
  exit(n);
    80001de2:	fec42503          	lw	a0,-20(s0)
    80001de6:	eacff0ef          	jal	80001492 <exit>
  return 0;  // not reached
}
    80001dea:	4501                	li	a0,0
    80001dec:	60e2                	ld	ra,24(sp)
    80001dee:	6442                	ld	s0,16(sp)
    80001df0:	6105                	addi	sp,sp,32
    80001df2:	8082                	ret

0000000080001df4 <sys_getpid>:

uint64
sys_getpid(void)
{
    80001df4:	1141                	addi	sp,sp,-16
    80001df6:	e406                	sd	ra,8(sp)
    80001df8:	e022                	sd	s0,0(sp)
    80001dfa:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001dfc:	f87fe0ef          	jal	80000d82 <myproc>
}
    80001e00:	5908                	lw	a0,48(a0)
    80001e02:	60a2                	ld	ra,8(sp)
    80001e04:	6402                	ld	s0,0(sp)
    80001e06:	0141                	addi	sp,sp,16
    80001e08:	8082                	ret

0000000080001e0a <sys_fork>:

uint64
sys_fork(void)
{
    80001e0a:	1141                	addi	sp,sp,-16
    80001e0c:	e406                	sd	ra,8(sp)
    80001e0e:	e022                	sd	s0,0(sp)
    80001e10:	0800                	addi	s0,sp,16
  return fork();
    80001e12:	acaff0ef          	jal	800010dc <fork>
}
    80001e16:	60a2                	ld	ra,8(sp)
    80001e18:	6402                	ld	s0,0(sp)
    80001e1a:	0141                	addi	sp,sp,16
    80001e1c:	8082                	ret

0000000080001e1e <sys_wait>:

uint64
sys_wait(void)
{
    80001e1e:	1101                	addi	sp,sp,-32
    80001e20:	ec06                	sd	ra,24(sp)
    80001e22:	e822                	sd	s0,16(sp)
    80001e24:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001e26:	fe840593          	addi	a1,s0,-24
    80001e2a:	4501                	li	a0,0
    80001e2c:	efdff0ef          	jal	80001d28 <argaddr>
  return wait(p);
    80001e30:	fe843503          	ld	a0,-24(s0)
    80001e34:	fb8ff0ef          	jal	800015ec <wait>
}
    80001e38:	60e2                	ld	ra,24(sp)
    80001e3a:	6442                	ld	s0,16(sp)
    80001e3c:	6105                	addi	sp,sp,32
    80001e3e:	8082                	ret

0000000080001e40 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001e40:	7179                	addi	sp,sp,-48
    80001e42:	f406                	sd	ra,40(sp)
    80001e44:	f022                	sd	s0,32(sp)
    80001e46:	ec26                	sd	s1,24(sp)
    80001e48:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001e4a:	fdc40593          	addi	a1,s0,-36
    80001e4e:	4501                	li	a0,0
    80001e50:	ebdff0ef          	jal	80001d0c <argint>
  addr = myproc()->sz;
    80001e54:	f2ffe0ef          	jal	80000d82 <myproc>
    80001e58:	653c                	ld	a5,72(a0)
    80001e5a:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80001e5c:	fdc42503          	lw	a0,-36(s0)
    80001e60:	a2cff0ef          	jal	8000108c <growproc>
    80001e64:	00054863          	bltz	a0,80001e74 <sys_sbrk+0x34>
    return -1;
  return addr;
}
    80001e68:	8526                	mv	a0,s1
    80001e6a:	70a2                	ld	ra,40(sp)
    80001e6c:	7402                	ld	s0,32(sp)
    80001e6e:	64e2                	ld	s1,24(sp)
    80001e70:	6145                	addi	sp,sp,48
    80001e72:	8082                	ret
    return -1;
    80001e74:	57fd                	li	a5,-1
    80001e76:	84be                	mv	s1,a5
    80001e78:	bfc5                	j	80001e68 <sys_sbrk+0x28>

0000000080001e7a <sys_sleep>:

uint64
sys_sleep(void)
{
    80001e7a:	7139                	addi	sp,sp,-64
    80001e7c:	fc06                	sd	ra,56(sp)
    80001e7e:	f822                	sd	s0,48(sp)
    80001e80:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80001e82:	fcc40593          	addi	a1,s0,-52
    80001e86:	4501                	li	a0,0
    80001e88:	e85ff0ef          	jal	80001d0c <argint>
  if(n < 0)
    80001e8c:	fcc42783          	lw	a5,-52(s0)
    80001e90:	0607ca63          	bltz	a5,80001f04 <sys_sleep+0x8a>
    n = 0;
  acquire(&tickslock);
    80001e94:	0000c517          	auipc	a0,0xc
    80001e98:	2ec50513          	addi	a0,a0,748 # 8000e180 <tickslock>
    80001e9c:	2a1030ef          	jal	8000593c <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80001ea0:	fcc42783          	lw	a5,-52(s0)
    80001ea4:	c3b9                	beqz	a5,80001eea <sys_sleep+0x70>
    80001ea6:	f426                	sd	s1,40(sp)
    80001ea8:	f04a                	sd	s2,32(sp)
    80001eaa:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80001eac:	00006997          	auipc	s3,0x6
    80001eb0:	a6c9a983          	lw	s3,-1428(s3) # 80007918 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80001eb4:	0000c917          	auipc	s2,0xc
    80001eb8:	2cc90913          	addi	s2,s2,716 # 8000e180 <tickslock>
    80001ebc:	00006497          	auipc	s1,0x6
    80001ec0:	a5c48493          	addi	s1,s1,-1444 # 80007918 <ticks>
    if(killed(myproc())){
    80001ec4:	ebffe0ef          	jal	80000d82 <myproc>
    80001ec8:	efaff0ef          	jal	800015c2 <killed>
    80001ecc:	ed1d                	bnez	a0,80001f0a <sys_sleep+0x90>
    sleep(&ticks, &tickslock);
    80001ece:	85ca                	mv	a1,s2
    80001ed0:	8526                	mv	a0,s1
    80001ed2:	cb4ff0ef          	jal	80001386 <sleep>
  while(ticks - ticks0 < n){
    80001ed6:	409c                	lw	a5,0(s1)
    80001ed8:	413787bb          	subw	a5,a5,s3
    80001edc:	fcc42703          	lw	a4,-52(s0)
    80001ee0:	fee7e2e3          	bltu	a5,a4,80001ec4 <sys_sleep+0x4a>
    80001ee4:	74a2                	ld	s1,40(sp)
    80001ee6:	7902                	ld	s2,32(sp)
    80001ee8:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80001eea:	0000c517          	auipc	a0,0xc
    80001eee:	29650513          	addi	a0,a0,662 # 8000e180 <tickslock>
    80001ef2:	2df030ef          	jal	800059d0 <release>
  backtrace();
    80001ef6:	6d6030ef          	jal	800055cc <backtrace>
  return 0;
    80001efa:	4501                	li	a0,0
}
    80001efc:	70e2                	ld	ra,56(sp)
    80001efe:	7442                	ld	s0,48(sp)
    80001f00:	6121                	addi	sp,sp,64
    80001f02:	8082                	ret
    n = 0;
    80001f04:	fc042623          	sw	zero,-52(s0)
    80001f08:	b771                	j	80001e94 <sys_sleep+0x1a>
      release(&tickslock);
    80001f0a:	0000c517          	auipc	a0,0xc
    80001f0e:	27650513          	addi	a0,a0,630 # 8000e180 <tickslock>
    80001f12:	2bf030ef          	jal	800059d0 <release>
      return -1;
    80001f16:	557d                	li	a0,-1
    80001f18:	74a2                	ld	s1,40(sp)
    80001f1a:	7902                	ld	s2,32(sp)
    80001f1c:	69e2                	ld	s3,24(sp)
    80001f1e:	bff9                	j	80001efc <sys_sleep+0x82>

0000000080001f20 <sys_kill>:

uint64
sys_kill(void)
{
    80001f20:	1101                	addi	sp,sp,-32
    80001f22:	ec06                	sd	ra,24(sp)
    80001f24:	e822                	sd	s0,16(sp)
    80001f26:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80001f28:	fec40593          	addi	a1,s0,-20
    80001f2c:	4501                	li	a0,0
    80001f2e:	ddfff0ef          	jal	80001d0c <argint>
  return kill(pid);
    80001f32:	fec42503          	lw	a0,-20(s0)
    80001f36:	e02ff0ef          	jal	80001538 <kill>
}
    80001f3a:	60e2                	ld	ra,24(sp)
    80001f3c:	6442                	ld	s0,16(sp)
    80001f3e:	6105                	addi	sp,sp,32
    80001f40:	8082                	ret

0000000080001f42 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80001f42:	1101                	addi	sp,sp,-32
    80001f44:	ec06                	sd	ra,24(sp)
    80001f46:	e822                	sd	s0,16(sp)
    80001f48:	e426                	sd	s1,8(sp)
    80001f4a:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80001f4c:	0000c517          	auipc	a0,0xc
    80001f50:	23450513          	addi	a0,a0,564 # 8000e180 <tickslock>
    80001f54:	1e9030ef          	jal	8000593c <acquire>
  xticks = ticks;
    80001f58:	00006797          	auipc	a5,0x6
    80001f5c:	9c07a783          	lw	a5,-1600(a5) # 80007918 <ticks>
    80001f60:	84be                	mv	s1,a5
  release(&tickslock);
    80001f62:	0000c517          	auipc	a0,0xc
    80001f66:	21e50513          	addi	a0,a0,542 # 8000e180 <tickslock>
    80001f6a:	267030ef          	jal	800059d0 <release>
  return xticks;
}
    80001f6e:	02049513          	slli	a0,s1,0x20
    80001f72:	9101                	srli	a0,a0,0x20
    80001f74:	60e2                	ld	ra,24(sp)
    80001f76:	6442                	ld	s0,16(sp)
    80001f78:	64a2                	ld	s1,8(sp)
    80001f7a:	6105                	addi	sp,sp,32
    80001f7c:	8082                	ret

0000000080001f7e <sys_sigalarm>:

uint64
sys_sigalarm(void)
{
    80001f7e:	1101                	addi	sp,sp,-32
    80001f80:	ec06                	sd	ra,24(sp)
    80001f82:	e822                	sd	s0,16(sp)
    80001f84:	1000                	addi	s0,sp,32
  int ticks;
  void (*handler)();
  argint(0, &ticks);
    80001f86:	fec40593          	addi	a1,s0,-20
    80001f8a:	4501                	li	a0,0
    80001f8c:	d81ff0ef          	jal	80001d0c <argint>
  argaddr(1, (uint64 *)&handler);
    80001f90:	fe040593          	addi	a1,s0,-32
    80001f94:	4505                	li	a0,1
    80001f96:	d93ff0ef          	jal	80001d28 <argaddr>
  return sigalarm(ticks, handler);
    80001f9a:	fe043583          	ld	a1,-32(s0)
    80001f9e:	fec42503          	lw	a0,-20(s0)
    80001fa2:	877ff0ef          	jal	80001818 <sigalarm>
}
    80001fa6:	60e2                	ld	ra,24(sp)
    80001fa8:	6442                	ld	s0,16(sp)
    80001faa:	6105                	addi	sp,sp,32
    80001fac:	8082                	ret

0000000080001fae <sys_sigreturn>:

uint64
sys_sigreturn(void)
{
    80001fae:	1141                	addi	sp,sp,-16
    80001fb0:	e406                	sd	ra,8(sp)
    80001fb2:	e022                	sd	s0,0(sp)
    80001fb4:	0800                	addi	s0,sp,16
  return sigreturn();
    80001fb6:	895ff0ef          	jal	8000184a <sigreturn>
    80001fba:	60a2                	ld	ra,8(sp)
    80001fbc:	6402                	ld	s0,0(sp)
    80001fbe:	0141                	addi	sp,sp,16
    80001fc0:	8082                	ret

0000000080001fc2 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80001fc2:	7179                	addi	sp,sp,-48
    80001fc4:	f406                	sd	ra,40(sp)
    80001fc6:	f022                	sd	s0,32(sp)
    80001fc8:	ec26                	sd	s1,24(sp)
    80001fca:	e84a                	sd	s2,16(sp)
    80001fcc:	e44e                	sd	s3,8(sp)
    80001fce:	e052                	sd	s4,0(sp)
    80001fd0:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80001fd2:	00005597          	auipc	a1,0x5
    80001fd6:	3fe58593          	addi	a1,a1,1022 # 800073d0 <etext+0x3d0>
    80001fda:	0000c517          	auipc	a0,0xc
    80001fde:	1be50513          	addi	a0,a0,446 # 8000e198 <bcache>
    80001fe2:	0d1030ef          	jal	800058b2 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80001fe6:	00014797          	auipc	a5,0x14
    80001fea:	1b278793          	addi	a5,a5,434 # 80016198 <bcache+0x8000>
    80001fee:	00014717          	auipc	a4,0x14
    80001ff2:	41270713          	addi	a4,a4,1042 # 80016400 <bcache+0x8268>
    80001ff6:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80001ffa:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80001ffe:	0000c497          	auipc	s1,0xc
    80002002:	1b248493          	addi	s1,s1,434 # 8000e1b0 <bcache+0x18>
    b->next = bcache.head.next;
    80002006:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002008:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    8000200a:	00005a17          	auipc	s4,0x5
    8000200e:	3cea0a13          	addi	s4,s4,974 # 800073d8 <etext+0x3d8>
    b->next = bcache.head.next;
    80002012:	2b893783          	ld	a5,696(s2)
    80002016:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002018:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    8000201c:	85d2                	mv	a1,s4
    8000201e:	01048513          	addi	a0,s1,16
    80002022:	24c010ef          	jal	8000326e <initsleeplock>
    bcache.head.next->prev = b;
    80002026:	2b893783          	ld	a5,696(s2)
    8000202a:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    8000202c:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002030:	45848493          	addi	s1,s1,1112
    80002034:	fd349fe3          	bne	s1,s3,80002012 <binit+0x50>
  }
}
    80002038:	70a2                	ld	ra,40(sp)
    8000203a:	7402                	ld	s0,32(sp)
    8000203c:	64e2                	ld	s1,24(sp)
    8000203e:	6942                	ld	s2,16(sp)
    80002040:	69a2                	ld	s3,8(sp)
    80002042:	6a02                	ld	s4,0(sp)
    80002044:	6145                	addi	sp,sp,48
    80002046:	8082                	ret

0000000080002048 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002048:	7179                	addi	sp,sp,-48
    8000204a:	f406                	sd	ra,40(sp)
    8000204c:	f022                	sd	s0,32(sp)
    8000204e:	ec26                	sd	s1,24(sp)
    80002050:	e84a                	sd	s2,16(sp)
    80002052:	e44e                	sd	s3,8(sp)
    80002054:	1800                	addi	s0,sp,48
    80002056:	892a                	mv	s2,a0
    80002058:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    8000205a:	0000c517          	auipc	a0,0xc
    8000205e:	13e50513          	addi	a0,a0,318 # 8000e198 <bcache>
    80002062:	0db030ef          	jal	8000593c <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002066:	00014497          	auipc	s1,0x14
    8000206a:	3ea4b483          	ld	s1,1002(s1) # 80016450 <bcache+0x82b8>
    8000206e:	00014797          	auipc	a5,0x14
    80002072:	39278793          	addi	a5,a5,914 # 80016400 <bcache+0x8268>
    80002076:	02f48b63          	beq	s1,a5,800020ac <bread+0x64>
    8000207a:	873e                	mv	a4,a5
    8000207c:	a021                	j	80002084 <bread+0x3c>
    8000207e:	68a4                	ld	s1,80(s1)
    80002080:	02e48663          	beq	s1,a4,800020ac <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002084:	449c                	lw	a5,8(s1)
    80002086:	ff279ce3          	bne	a5,s2,8000207e <bread+0x36>
    8000208a:	44dc                	lw	a5,12(s1)
    8000208c:	ff3799e3          	bne	a5,s3,8000207e <bread+0x36>
      b->refcnt++;
    80002090:	40bc                	lw	a5,64(s1)
    80002092:	2785                	addiw	a5,a5,1
    80002094:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002096:	0000c517          	auipc	a0,0xc
    8000209a:	10250513          	addi	a0,a0,258 # 8000e198 <bcache>
    8000209e:	133030ef          	jal	800059d0 <release>
      acquiresleep(&b->lock);
    800020a2:	01048513          	addi	a0,s1,16
    800020a6:	1fe010ef          	jal	800032a4 <acquiresleep>
      return b;
    800020aa:	a889                	j	800020fc <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800020ac:	00014497          	auipc	s1,0x14
    800020b0:	39c4b483          	ld	s1,924(s1) # 80016448 <bcache+0x82b0>
    800020b4:	00014797          	auipc	a5,0x14
    800020b8:	34c78793          	addi	a5,a5,844 # 80016400 <bcache+0x8268>
    800020bc:	00f48863          	beq	s1,a5,800020cc <bread+0x84>
    800020c0:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    800020c2:	40bc                	lw	a5,64(s1)
    800020c4:	cb91                	beqz	a5,800020d8 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800020c6:	64a4                	ld	s1,72(s1)
    800020c8:	fee49de3          	bne	s1,a4,800020c2 <bread+0x7a>
  panic("bget: no buffers");
    800020cc:	00005517          	auipc	a0,0x5
    800020d0:	31450513          	addi	a0,a0,788 # 800073e0 <etext+0x3e0>
    800020d4:	554030ef          	jal	80005628 <panic>
      b->dev = dev;
    800020d8:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    800020dc:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    800020e0:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    800020e4:	4785                	li	a5,1
    800020e6:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800020e8:	0000c517          	auipc	a0,0xc
    800020ec:	0b050513          	addi	a0,a0,176 # 8000e198 <bcache>
    800020f0:	0e1030ef          	jal	800059d0 <release>
      acquiresleep(&b->lock);
    800020f4:	01048513          	addi	a0,s1,16
    800020f8:	1ac010ef          	jal	800032a4 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    800020fc:	409c                	lw	a5,0(s1)
    800020fe:	cb89                	beqz	a5,80002110 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002100:	8526                	mv	a0,s1
    80002102:	70a2                	ld	ra,40(sp)
    80002104:	7402                	ld	s0,32(sp)
    80002106:	64e2                	ld	s1,24(sp)
    80002108:	6942                	ld	s2,16(sp)
    8000210a:	69a2                	ld	s3,8(sp)
    8000210c:	6145                	addi	sp,sp,48
    8000210e:	8082                	ret
    virtio_disk_rw(b, 0);
    80002110:	4581                	li	a1,0
    80002112:	8526                	mv	a0,s1
    80002114:	20d020ef          	jal	80004b20 <virtio_disk_rw>
    b->valid = 1;
    80002118:	4785                	li	a5,1
    8000211a:	c09c                	sw	a5,0(s1)
  return b;
    8000211c:	b7d5                	j	80002100 <bread+0xb8>

000000008000211e <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000211e:	1101                	addi	sp,sp,-32
    80002120:	ec06                	sd	ra,24(sp)
    80002122:	e822                	sd	s0,16(sp)
    80002124:	e426                	sd	s1,8(sp)
    80002126:	1000                	addi	s0,sp,32
    80002128:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000212a:	0541                	addi	a0,a0,16
    8000212c:	1f6010ef          	jal	80003322 <holdingsleep>
    80002130:	c911                	beqz	a0,80002144 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002132:	4585                	li	a1,1
    80002134:	8526                	mv	a0,s1
    80002136:	1eb020ef          	jal	80004b20 <virtio_disk_rw>
}
    8000213a:	60e2                	ld	ra,24(sp)
    8000213c:	6442                	ld	s0,16(sp)
    8000213e:	64a2                	ld	s1,8(sp)
    80002140:	6105                	addi	sp,sp,32
    80002142:	8082                	ret
    panic("bwrite");
    80002144:	00005517          	auipc	a0,0x5
    80002148:	2b450513          	addi	a0,a0,692 # 800073f8 <etext+0x3f8>
    8000214c:	4dc030ef          	jal	80005628 <panic>

0000000080002150 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002150:	1101                	addi	sp,sp,-32
    80002152:	ec06                	sd	ra,24(sp)
    80002154:	e822                	sd	s0,16(sp)
    80002156:	e426                	sd	s1,8(sp)
    80002158:	e04a                	sd	s2,0(sp)
    8000215a:	1000                	addi	s0,sp,32
    8000215c:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000215e:	01050913          	addi	s2,a0,16
    80002162:	854a                	mv	a0,s2
    80002164:	1be010ef          	jal	80003322 <holdingsleep>
    80002168:	c125                	beqz	a0,800021c8 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    8000216a:	854a                	mv	a0,s2
    8000216c:	17e010ef          	jal	800032ea <releasesleep>

  acquire(&bcache.lock);
    80002170:	0000c517          	auipc	a0,0xc
    80002174:	02850513          	addi	a0,a0,40 # 8000e198 <bcache>
    80002178:	7c4030ef          	jal	8000593c <acquire>
  b->refcnt--;
    8000217c:	40bc                	lw	a5,64(s1)
    8000217e:	37fd                	addiw	a5,a5,-1
    80002180:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002182:	e79d                	bnez	a5,800021b0 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002184:	68b8                	ld	a4,80(s1)
    80002186:	64bc                	ld	a5,72(s1)
    80002188:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    8000218a:	68b8                	ld	a4,80(s1)
    8000218c:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    8000218e:	00014797          	auipc	a5,0x14
    80002192:	00a78793          	addi	a5,a5,10 # 80016198 <bcache+0x8000>
    80002196:	2b87b703          	ld	a4,696(a5)
    8000219a:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    8000219c:	00014717          	auipc	a4,0x14
    800021a0:	26470713          	addi	a4,a4,612 # 80016400 <bcache+0x8268>
    800021a4:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800021a6:	2b87b703          	ld	a4,696(a5)
    800021aa:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800021ac:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800021b0:	0000c517          	auipc	a0,0xc
    800021b4:	fe850513          	addi	a0,a0,-24 # 8000e198 <bcache>
    800021b8:	019030ef          	jal	800059d0 <release>
}
    800021bc:	60e2                	ld	ra,24(sp)
    800021be:	6442                	ld	s0,16(sp)
    800021c0:	64a2                	ld	s1,8(sp)
    800021c2:	6902                	ld	s2,0(sp)
    800021c4:	6105                	addi	sp,sp,32
    800021c6:	8082                	ret
    panic("brelse");
    800021c8:	00005517          	auipc	a0,0x5
    800021cc:	23850513          	addi	a0,a0,568 # 80007400 <etext+0x400>
    800021d0:	458030ef          	jal	80005628 <panic>

00000000800021d4 <bpin>:

void
bpin(struct buf *b) {
    800021d4:	1101                	addi	sp,sp,-32
    800021d6:	ec06                	sd	ra,24(sp)
    800021d8:	e822                	sd	s0,16(sp)
    800021da:	e426                	sd	s1,8(sp)
    800021dc:	1000                	addi	s0,sp,32
    800021de:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800021e0:	0000c517          	auipc	a0,0xc
    800021e4:	fb850513          	addi	a0,a0,-72 # 8000e198 <bcache>
    800021e8:	754030ef          	jal	8000593c <acquire>
  b->refcnt++;
    800021ec:	40bc                	lw	a5,64(s1)
    800021ee:	2785                	addiw	a5,a5,1
    800021f0:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800021f2:	0000c517          	auipc	a0,0xc
    800021f6:	fa650513          	addi	a0,a0,-90 # 8000e198 <bcache>
    800021fa:	7d6030ef          	jal	800059d0 <release>
}
    800021fe:	60e2                	ld	ra,24(sp)
    80002200:	6442                	ld	s0,16(sp)
    80002202:	64a2                	ld	s1,8(sp)
    80002204:	6105                	addi	sp,sp,32
    80002206:	8082                	ret

0000000080002208 <bunpin>:

void
bunpin(struct buf *b) {
    80002208:	1101                	addi	sp,sp,-32
    8000220a:	ec06                	sd	ra,24(sp)
    8000220c:	e822                	sd	s0,16(sp)
    8000220e:	e426                	sd	s1,8(sp)
    80002210:	1000                	addi	s0,sp,32
    80002212:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002214:	0000c517          	auipc	a0,0xc
    80002218:	f8450513          	addi	a0,a0,-124 # 8000e198 <bcache>
    8000221c:	720030ef          	jal	8000593c <acquire>
  b->refcnt--;
    80002220:	40bc                	lw	a5,64(s1)
    80002222:	37fd                	addiw	a5,a5,-1
    80002224:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002226:	0000c517          	auipc	a0,0xc
    8000222a:	f7250513          	addi	a0,a0,-142 # 8000e198 <bcache>
    8000222e:	7a2030ef          	jal	800059d0 <release>
}
    80002232:	60e2                	ld	ra,24(sp)
    80002234:	6442                	ld	s0,16(sp)
    80002236:	64a2                	ld	s1,8(sp)
    80002238:	6105                	addi	sp,sp,32
    8000223a:	8082                	ret

000000008000223c <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    8000223c:	1101                	addi	sp,sp,-32
    8000223e:	ec06                	sd	ra,24(sp)
    80002240:	e822                	sd	s0,16(sp)
    80002242:	e426                	sd	s1,8(sp)
    80002244:	e04a                	sd	s2,0(sp)
    80002246:	1000                	addi	s0,sp,32
    80002248:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000224a:	00d5d79b          	srliw	a5,a1,0xd
    8000224e:	00014597          	auipc	a1,0x14
    80002252:	6265a583          	lw	a1,1574(a1) # 80016874 <sb+0x1c>
    80002256:	9dbd                	addw	a1,a1,a5
    80002258:	df1ff0ef          	jal	80002048 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    8000225c:	0074f713          	andi	a4,s1,7
    80002260:	4785                	li	a5,1
    80002262:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002266:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002268:	90d9                	srli	s1,s1,0x36
    8000226a:	00950733          	add	a4,a0,s1
    8000226e:	05874703          	lbu	a4,88(a4)
    80002272:	00e7f6b3          	and	a3,a5,a4
    80002276:	c29d                	beqz	a3,8000229c <bfree+0x60>
    80002278:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    8000227a:	94aa                	add	s1,s1,a0
    8000227c:	fff7c793          	not	a5,a5
    80002280:	8f7d                	and	a4,a4,a5
    80002282:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002286:	717000ef          	jal	8000319c <log_write>
  brelse(bp);
    8000228a:	854a                	mv	a0,s2
    8000228c:	ec5ff0ef          	jal	80002150 <brelse>
}
    80002290:	60e2                	ld	ra,24(sp)
    80002292:	6442                	ld	s0,16(sp)
    80002294:	64a2                	ld	s1,8(sp)
    80002296:	6902                	ld	s2,0(sp)
    80002298:	6105                	addi	sp,sp,32
    8000229a:	8082                	ret
    panic("freeing free block");
    8000229c:	00005517          	auipc	a0,0x5
    800022a0:	16c50513          	addi	a0,a0,364 # 80007408 <etext+0x408>
    800022a4:	384030ef          	jal	80005628 <panic>

00000000800022a8 <balloc>:
{
    800022a8:	715d                	addi	sp,sp,-80
    800022aa:	e486                	sd	ra,72(sp)
    800022ac:	e0a2                	sd	s0,64(sp)
    800022ae:	fc26                	sd	s1,56(sp)
    800022b0:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    800022b2:	00014797          	auipc	a5,0x14
    800022b6:	5aa7a783          	lw	a5,1450(a5) # 8001685c <sb+0x4>
    800022ba:	0e078263          	beqz	a5,8000239e <balloc+0xf6>
    800022be:	f84a                	sd	s2,48(sp)
    800022c0:	f44e                	sd	s3,40(sp)
    800022c2:	f052                	sd	s4,32(sp)
    800022c4:	ec56                	sd	s5,24(sp)
    800022c6:	e85a                	sd	s6,16(sp)
    800022c8:	e45e                	sd	s7,8(sp)
    800022ca:	e062                	sd	s8,0(sp)
    800022cc:	8baa                	mv	s7,a0
    800022ce:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800022d0:	00014b17          	auipc	s6,0x14
    800022d4:	588b0b13          	addi	s6,s6,1416 # 80016858 <sb>
      m = 1 << (bi % 8);
    800022d8:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800022da:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    800022dc:	6c09                	lui	s8,0x2
    800022de:	a09d                	j	80002344 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    800022e0:	97ca                	add	a5,a5,s2
    800022e2:	8e55                	or	a2,a2,a3
    800022e4:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    800022e8:	854a                	mv	a0,s2
    800022ea:	6b3000ef          	jal	8000319c <log_write>
        brelse(bp);
    800022ee:	854a                	mv	a0,s2
    800022f0:	e61ff0ef          	jal	80002150 <brelse>
  bp = bread(dev, bno);
    800022f4:	85a6                	mv	a1,s1
    800022f6:	855e                	mv	a0,s7
    800022f8:	d51ff0ef          	jal	80002048 <bread>
    800022fc:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800022fe:	40000613          	li	a2,1024
    80002302:	4581                	li	a1,0
    80002304:	05850513          	addi	a0,a0,88
    80002308:	e57fd0ef          	jal	8000015e <memset>
  log_write(bp);
    8000230c:	854a                	mv	a0,s2
    8000230e:	68f000ef          	jal	8000319c <log_write>
  brelse(bp);
    80002312:	854a                	mv	a0,s2
    80002314:	e3dff0ef          	jal	80002150 <brelse>
}
    80002318:	7942                	ld	s2,48(sp)
    8000231a:	79a2                	ld	s3,40(sp)
    8000231c:	7a02                	ld	s4,32(sp)
    8000231e:	6ae2                	ld	s5,24(sp)
    80002320:	6b42                	ld	s6,16(sp)
    80002322:	6ba2                	ld	s7,8(sp)
    80002324:	6c02                	ld	s8,0(sp)
}
    80002326:	8526                	mv	a0,s1
    80002328:	60a6                	ld	ra,72(sp)
    8000232a:	6406                	ld	s0,64(sp)
    8000232c:	74e2                	ld	s1,56(sp)
    8000232e:	6161                	addi	sp,sp,80
    80002330:	8082                	ret
    brelse(bp);
    80002332:	854a                	mv	a0,s2
    80002334:	e1dff0ef          	jal	80002150 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002338:	015c0abb          	addw	s5,s8,s5
    8000233c:	004b2783          	lw	a5,4(s6)
    80002340:	04faf863          	bgeu	s5,a5,80002390 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002344:	40dad59b          	sraiw	a1,s5,0xd
    80002348:	01cb2783          	lw	a5,28(s6)
    8000234c:	9dbd                	addw	a1,a1,a5
    8000234e:	855e                	mv	a0,s7
    80002350:	cf9ff0ef          	jal	80002048 <bread>
    80002354:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002356:	004b2503          	lw	a0,4(s6)
    8000235a:	84d6                	mv	s1,s5
    8000235c:	4701                	li	a4,0
    8000235e:	fca4fae3          	bgeu	s1,a0,80002332 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002362:	00777693          	andi	a3,a4,7
    80002366:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    8000236a:	41f7579b          	sraiw	a5,a4,0x1f
    8000236e:	01d7d79b          	srliw	a5,a5,0x1d
    80002372:	9fb9                	addw	a5,a5,a4
    80002374:	4037d79b          	sraiw	a5,a5,0x3
    80002378:	00f90633          	add	a2,s2,a5
    8000237c:	05864603          	lbu	a2,88(a2)
    80002380:	00c6f5b3          	and	a1,a3,a2
    80002384:	ddb1                	beqz	a1,800022e0 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002386:	2705                	addiw	a4,a4,1
    80002388:	2485                	addiw	s1,s1,1
    8000238a:	fd471ae3          	bne	a4,s4,8000235e <balloc+0xb6>
    8000238e:	b755                	j	80002332 <balloc+0x8a>
    80002390:	7942                	ld	s2,48(sp)
    80002392:	79a2                	ld	s3,40(sp)
    80002394:	7a02                	ld	s4,32(sp)
    80002396:	6ae2                	ld	s5,24(sp)
    80002398:	6b42                	ld	s6,16(sp)
    8000239a:	6ba2                	ld	s7,8(sp)
    8000239c:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    8000239e:	00005517          	auipc	a0,0x5
    800023a2:	08250513          	addi	a0,a0,130 # 80007420 <etext+0x420>
    800023a6:	6e9020ef          	jal	8000528e <printf>
  return 0;
    800023aa:	4481                	li	s1,0
    800023ac:	bfad                	j	80002326 <balloc+0x7e>

00000000800023ae <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800023ae:	7179                	addi	sp,sp,-48
    800023b0:	f406                	sd	ra,40(sp)
    800023b2:	f022                	sd	s0,32(sp)
    800023b4:	ec26                	sd	s1,24(sp)
    800023b6:	e84a                	sd	s2,16(sp)
    800023b8:	e44e                	sd	s3,8(sp)
    800023ba:	1800                	addi	s0,sp,48
    800023bc:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800023be:	47ad                	li	a5,11
    800023c0:	02b7e363          	bltu	a5,a1,800023e6 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    800023c4:	02059793          	slli	a5,a1,0x20
    800023c8:	01e7d593          	srli	a1,a5,0x1e
    800023cc:	00b509b3          	add	s3,a0,a1
    800023d0:	0509a483          	lw	s1,80(s3)
    800023d4:	e0b5                	bnez	s1,80002438 <bmap+0x8a>
      addr = balloc(ip->dev);
    800023d6:	4108                	lw	a0,0(a0)
    800023d8:	ed1ff0ef          	jal	800022a8 <balloc>
    800023dc:	84aa                	mv	s1,a0
      if(addr == 0)
    800023de:	cd29                	beqz	a0,80002438 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    800023e0:	04a9a823          	sw	a0,80(s3)
    800023e4:	a891                	j	80002438 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800023e6:	ff45879b          	addiw	a5,a1,-12
    800023ea:	873e                	mv	a4,a5
    800023ec:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    800023ee:	0ff00793          	li	a5,255
    800023f2:	06e7e763          	bltu	a5,a4,80002460 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800023f6:	08052483          	lw	s1,128(a0)
    800023fa:	e891                	bnez	s1,8000240e <bmap+0x60>
      addr = balloc(ip->dev);
    800023fc:	4108                	lw	a0,0(a0)
    800023fe:	eabff0ef          	jal	800022a8 <balloc>
    80002402:	84aa                	mv	s1,a0
      if(addr == 0)
    80002404:	c915                	beqz	a0,80002438 <bmap+0x8a>
    80002406:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002408:	08a92023          	sw	a0,128(s2)
    8000240c:	a011                	j	80002410 <bmap+0x62>
    8000240e:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002410:	85a6                	mv	a1,s1
    80002412:	00092503          	lw	a0,0(s2)
    80002416:	c33ff0ef          	jal	80002048 <bread>
    8000241a:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    8000241c:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002420:	02099713          	slli	a4,s3,0x20
    80002424:	01e75593          	srli	a1,a4,0x1e
    80002428:	97ae                	add	a5,a5,a1
    8000242a:	89be                	mv	s3,a5
    8000242c:	4384                	lw	s1,0(a5)
    8000242e:	cc89                	beqz	s1,80002448 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002430:	8552                	mv	a0,s4
    80002432:	d1fff0ef          	jal	80002150 <brelse>
    return addr;
    80002436:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002438:	8526                	mv	a0,s1
    8000243a:	70a2                	ld	ra,40(sp)
    8000243c:	7402                	ld	s0,32(sp)
    8000243e:	64e2                	ld	s1,24(sp)
    80002440:	6942                	ld	s2,16(sp)
    80002442:	69a2                	ld	s3,8(sp)
    80002444:	6145                	addi	sp,sp,48
    80002446:	8082                	ret
      addr = balloc(ip->dev);
    80002448:	00092503          	lw	a0,0(s2)
    8000244c:	e5dff0ef          	jal	800022a8 <balloc>
    80002450:	84aa                	mv	s1,a0
      if(addr){
    80002452:	dd79                	beqz	a0,80002430 <bmap+0x82>
        a[bn] = addr;
    80002454:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002458:	8552                	mv	a0,s4
    8000245a:	543000ef          	jal	8000319c <log_write>
    8000245e:	bfc9                	j	80002430 <bmap+0x82>
    80002460:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80002462:	00005517          	auipc	a0,0x5
    80002466:	fd650513          	addi	a0,a0,-42 # 80007438 <etext+0x438>
    8000246a:	1be030ef          	jal	80005628 <panic>

000000008000246e <iget>:
{
    8000246e:	7179                	addi	sp,sp,-48
    80002470:	f406                	sd	ra,40(sp)
    80002472:	f022                	sd	s0,32(sp)
    80002474:	ec26                	sd	s1,24(sp)
    80002476:	e84a                	sd	s2,16(sp)
    80002478:	e44e                	sd	s3,8(sp)
    8000247a:	e052                	sd	s4,0(sp)
    8000247c:	1800                	addi	s0,sp,48
    8000247e:	892a                	mv	s2,a0
    80002480:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80002482:	00014517          	auipc	a0,0x14
    80002486:	3f650513          	addi	a0,a0,1014 # 80016878 <itable>
    8000248a:	4b2030ef          	jal	8000593c <acquire>
  empty = 0;
    8000248e:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002490:	00014497          	auipc	s1,0x14
    80002494:	40048493          	addi	s1,s1,1024 # 80016890 <itable+0x18>
    80002498:	00016697          	auipc	a3,0x16
    8000249c:	e8868693          	addi	a3,a3,-376 # 80018320 <log>
    800024a0:	a809                	j	800024b2 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800024a2:	e781                	bnez	a5,800024aa <iget+0x3c>
    800024a4:	00099363          	bnez	s3,800024aa <iget+0x3c>
      empty = ip;
    800024a8:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800024aa:	08848493          	addi	s1,s1,136
    800024ae:	02d48563          	beq	s1,a3,800024d8 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800024b2:	449c                	lw	a5,8(s1)
    800024b4:	fef057e3          	blez	a5,800024a2 <iget+0x34>
    800024b8:	4098                	lw	a4,0(s1)
    800024ba:	ff2718e3          	bne	a4,s2,800024aa <iget+0x3c>
    800024be:	40d8                	lw	a4,4(s1)
    800024c0:	ff4715e3          	bne	a4,s4,800024aa <iget+0x3c>
      ip->ref++;
    800024c4:	2785                	addiw	a5,a5,1
    800024c6:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800024c8:	00014517          	auipc	a0,0x14
    800024cc:	3b050513          	addi	a0,a0,944 # 80016878 <itable>
    800024d0:	500030ef          	jal	800059d0 <release>
      return ip;
    800024d4:	89a6                	mv	s3,s1
    800024d6:	a015                	j	800024fa <iget+0x8c>
  if(empty == 0)
    800024d8:	02098a63          	beqz	s3,8000250c <iget+0x9e>
  ip->dev = dev;
    800024dc:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    800024e0:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    800024e4:	4785                	li	a5,1
    800024e6:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    800024ea:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    800024ee:	00014517          	auipc	a0,0x14
    800024f2:	38a50513          	addi	a0,a0,906 # 80016878 <itable>
    800024f6:	4da030ef          	jal	800059d0 <release>
}
    800024fa:	854e                	mv	a0,s3
    800024fc:	70a2                	ld	ra,40(sp)
    800024fe:	7402                	ld	s0,32(sp)
    80002500:	64e2                	ld	s1,24(sp)
    80002502:	6942                	ld	s2,16(sp)
    80002504:	69a2                	ld	s3,8(sp)
    80002506:	6a02                	ld	s4,0(sp)
    80002508:	6145                	addi	sp,sp,48
    8000250a:	8082                	ret
    panic("iget: no inodes");
    8000250c:	00005517          	auipc	a0,0x5
    80002510:	f4450513          	addi	a0,a0,-188 # 80007450 <etext+0x450>
    80002514:	114030ef          	jal	80005628 <panic>

0000000080002518 <fsinit>:
fsinit(int dev) {
    80002518:	1101                	addi	sp,sp,-32
    8000251a:	ec06                	sd	ra,24(sp)
    8000251c:	e822                	sd	s0,16(sp)
    8000251e:	e426                	sd	s1,8(sp)
    80002520:	e04a                	sd	s2,0(sp)
    80002522:	1000                	addi	s0,sp,32
    80002524:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002526:	4585                	li	a1,1
    80002528:	b21ff0ef          	jal	80002048 <bread>
    8000252c:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000252e:	02000613          	li	a2,32
    80002532:	05850593          	addi	a1,a0,88
    80002536:	00014517          	auipc	a0,0x14
    8000253a:	32250513          	addi	a0,a0,802 # 80016858 <sb>
    8000253e:	c81fd0ef          	jal	800001be <memmove>
  brelse(bp);
    80002542:	8526                	mv	a0,s1
    80002544:	c0dff0ef          	jal	80002150 <brelse>
  if(sb.magic != FSMAGIC)
    80002548:	00014717          	auipc	a4,0x14
    8000254c:	31072703          	lw	a4,784(a4) # 80016858 <sb>
    80002550:	102037b7          	lui	a5,0x10203
    80002554:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002558:	00f71f63          	bne	a4,a5,80002576 <fsinit+0x5e>
  initlog(dev, &sb);
    8000255c:	00014597          	auipc	a1,0x14
    80002560:	2fc58593          	addi	a1,a1,764 # 80016858 <sb>
    80002564:	854a                	mv	a0,s2
    80002566:	219000ef          	jal	80002f7e <initlog>
}
    8000256a:	60e2                	ld	ra,24(sp)
    8000256c:	6442                	ld	s0,16(sp)
    8000256e:	64a2                	ld	s1,8(sp)
    80002570:	6902                	ld	s2,0(sp)
    80002572:	6105                	addi	sp,sp,32
    80002574:	8082                	ret
    panic("invalid file system");
    80002576:	00005517          	auipc	a0,0x5
    8000257a:	eea50513          	addi	a0,a0,-278 # 80007460 <etext+0x460>
    8000257e:	0aa030ef          	jal	80005628 <panic>

0000000080002582 <iinit>:
{
    80002582:	7179                	addi	sp,sp,-48
    80002584:	f406                	sd	ra,40(sp)
    80002586:	f022                	sd	s0,32(sp)
    80002588:	ec26                	sd	s1,24(sp)
    8000258a:	e84a                	sd	s2,16(sp)
    8000258c:	e44e                	sd	s3,8(sp)
    8000258e:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80002590:	00005597          	auipc	a1,0x5
    80002594:	ee858593          	addi	a1,a1,-280 # 80007478 <etext+0x478>
    80002598:	00014517          	auipc	a0,0x14
    8000259c:	2e050513          	addi	a0,a0,736 # 80016878 <itable>
    800025a0:	312030ef          	jal	800058b2 <initlock>
  for(i = 0; i < NINODE; i++) {
    800025a4:	00014497          	auipc	s1,0x14
    800025a8:	2fc48493          	addi	s1,s1,764 # 800168a0 <itable+0x28>
    800025ac:	00016997          	auipc	s3,0x16
    800025b0:	d8498993          	addi	s3,s3,-636 # 80018330 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800025b4:	00005917          	auipc	s2,0x5
    800025b8:	ecc90913          	addi	s2,s2,-308 # 80007480 <etext+0x480>
    800025bc:	85ca                	mv	a1,s2
    800025be:	8526                	mv	a0,s1
    800025c0:	4af000ef          	jal	8000326e <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800025c4:	08848493          	addi	s1,s1,136
    800025c8:	ff349ae3          	bne	s1,s3,800025bc <iinit+0x3a>
}
    800025cc:	70a2                	ld	ra,40(sp)
    800025ce:	7402                	ld	s0,32(sp)
    800025d0:	64e2                	ld	s1,24(sp)
    800025d2:	6942                	ld	s2,16(sp)
    800025d4:	69a2                	ld	s3,8(sp)
    800025d6:	6145                	addi	sp,sp,48
    800025d8:	8082                	ret

00000000800025da <ialloc>:
{
    800025da:	7139                	addi	sp,sp,-64
    800025dc:	fc06                	sd	ra,56(sp)
    800025de:	f822                	sd	s0,48(sp)
    800025e0:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    800025e2:	00014717          	auipc	a4,0x14
    800025e6:	28272703          	lw	a4,642(a4) # 80016864 <sb+0xc>
    800025ea:	4785                	li	a5,1
    800025ec:	06e7f063          	bgeu	a5,a4,8000264c <ialloc+0x72>
    800025f0:	f426                	sd	s1,40(sp)
    800025f2:	f04a                	sd	s2,32(sp)
    800025f4:	ec4e                	sd	s3,24(sp)
    800025f6:	e852                	sd	s4,16(sp)
    800025f8:	e456                	sd	s5,8(sp)
    800025fa:	e05a                	sd	s6,0(sp)
    800025fc:	8aaa                	mv	s5,a0
    800025fe:	8b2e                	mv	s6,a1
    80002600:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80002602:	00014a17          	auipc	s4,0x14
    80002606:	256a0a13          	addi	s4,s4,598 # 80016858 <sb>
    8000260a:	00495593          	srli	a1,s2,0x4
    8000260e:	018a2783          	lw	a5,24(s4)
    80002612:	9dbd                	addw	a1,a1,a5
    80002614:	8556                	mv	a0,s5
    80002616:	a33ff0ef          	jal	80002048 <bread>
    8000261a:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    8000261c:	05850993          	addi	s3,a0,88
    80002620:	00f97793          	andi	a5,s2,15
    80002624:	079a                	slli	a5,a5,0x6
    80002626:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002628:	00099783          	lh	a5,0(s3)
    8000262c:	cb9d                	beqz	a5,80002662 <ialloc+0x88>
    brelse(bp);
    8000262e:	b23ff0ef          	jal	80002150 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80002632:	0905                	addi	s2,s2,1
    80002634:	00ca2703          	lw	a4,12(s4)
    80002638:	0009079b          	sext.w	a5,s2
    8000263c:	fce7e7e3          	bltu	a5,a4,8000260a <ialloc+0x30>
    80002640:	74a2                	ld	s1,40(sp)
    80002642:	7902                	ld	s2,32(sp)
    80002644:	69e2                	ld	s3,24(sp)
    80002646:	6a42                	ld	s4,16(sp)
    80002648:	6aa2                	ld	s5,8(sp)
    8000264a:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    8000264c:	00005517          	auipc	a0,0x5
    80002650:	e3c50513          	addi	a0,a0,-452 # 80007488 <etext+0x488>
    80002654:	43b020ef          	jal	8000528e <printf>
  return 0;
    80002658:	4501                	li	a0,0
}
    8000265a:	70e2                	ld	ra,56(sp)
    8000265c:	7442                	ld	s0,48(sp)
    8000265e:	6121                	addi	sp,sp,64
    80002660:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80002662:	04000613          	li	a2,64
    80002666:	4581                	li	a1,0
    80002668:	854e                	mv	a0,s3
    8000266a:	af5fd0ef          	jal	8000015e <memset>
      dip->type = type;
    8000266e:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80002672:	8526                	mv	a0,s1
    80002674:	329000ef          	jal	8000319c <log_write>
      brelse(bp);
    80002678:	8526                	mv	a0,s1
    8000267a:	ad7ff0ef          	jal	80002150 <brelse>
      return iget(dev, inum);
    8000267e:	0009059b          	sext.w	a1,s2
    80002682:	8556                	mv	a0,s5
    80002684:	debff0ef          	jal	8000246e <iget>
    80002688:	74a2                	ld	s1,40(sp)
    8000268a:	7902                	ld	s2,32(sp)
    8000268c:	69e2                	ld	s3,24(sp)
    8000268e:	6a42                	ld	s4,16(sp)
    80002690:	6aa2                	ld	s5,8(sp)
    80002692:	6b02                	ld	s6,0(sp)
    80002694:	b7d9                	j	8000265a <ialloc+0x80>

0000000080002696 <iupdate>:
{
    80002696:	1101                	addi	sp,sp,-32
    80002698:	ec06                	sd	ra,24(sp)
    8000269a:	e822                	sd	s0,16(sp)
    8000269c:	e426                	sd	s1,8(sp)
    8000269e:	e04a                	sd	s2,0(sp)
    800026a0:	1000                	addi	s0,sp,32
    800026a2:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800026a4:	415c                	lw	a5,4(a0)
    800026a6:	0047d79b          	srliw	a5,a5,0x4
    800026aa:	00014597          	auipc	a1,0x14
    800026ae:	1c65a583          	lw	a1,454(a1) # 80016870 <sb+0x18>
    800026b2:	9dbd                	addw	a1,a1,a5
    800026b4:	4108                	lw	a0,0(a0)
    800026b6:	993ff0ef          	jal	80002048 <bread>
    800026ba:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800026bc:	05850793          	addi	a5,a0,88
    800026c0:	40d8                	lw	a4,4(s1)
    800026c2:	8b3d                	andi	a4,a4,15
    800026c4:	071a                	slli	a4,a4,0x6
    800026c6:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800026c8:	04449703          	lh	a4,68(s1)
    800026cc:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800026d0:	04649703          	lh	a4,70(s1)
    800026d4:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800026d8:	04849703          	lh	a4,72(s1)
    800026dc:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800026e0:	04a49703          	lh	a4,74(s1)
    800026e4:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800026e8:	44f8                	lw	a4,76(s1)
    800026ea:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800026ec:	03400613          	li	a2,52
    800026f0:	05048593          	addi	a1,s1,80
    800026f4:	00c78513          	addi	a0,a5,12
    800026f8:	ac7fd0ef          	jal	800001be <memmove>
  log_write(bp);
    800026fc:	854a                	mv	a0,s2
    800026fe:	29f000ef          	jal	8000319c <log_write>
  brelse(bp);
    80002702:	854a                	mv	a0,s2
    80002704:	a4dff0ef          	jal	80002150 <brelse>
}
    80002708:	60e2                	ld	ra,24(sp)
    8000270a:	6442                	ld	s0,16(sp)
    8000270c:	64a2                	ld	s1,8(sp)
    8000270e:	6902                	ld	s2,0(sp)
    80002710:	6105                	addi	sp,sp,32
    80002712:	8082                	ret

0000000080002714 <idup>:
{
    80002714:	1101                	addi	sp,sp,-32
    80002716:	ec06                	sd	ra,24(sp)
    80002718:	e822                	sd	s0,16(sp)
    8000271a:	e426                	sd	s1,8(sp)
    8000271c:	1000                	addi	s0,sp,32
    8000271e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002720:	00014517          	auipc	a0,0x14
    80002724:	15850513          	addi	a0,a0,344 # 80016878 <itable>
    80002728:	214030ef          	jal	8000593c <acquire>
  ip->ref++;
    8000272c:	449c                	lw	a5,8(s1)
    8000272e:	2785                	addiw	a5,a5,1
    80002730:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002732:	00014517          	auipc	a0,0x14
    80002736:	14650513          	addi	a0,a0,326 # 80016878 <itable>
    8000273a:	296030ef          	jal	800059d0 <release>
}
    8000273e:	8526                	mv	a0,s1
    80002740:	60e2                	ld	ra,24(sp)
    80002742:	6442                	ld	s0,16(sp)
    80002744:	64a2                	ld	s1,8(sp)
    80002746:	6105                	addi	sp,sp,32
    80002748:	8082                	ret

000000008000274a <ilock>:
{
    8000274a:	1101                	addi	sp,sp,-32
    8000274c:	ec06                	sd	ra,24(sp)
    8000274e:	e822                	sd	s0,16(sp)
    80002750:	e426                	sd	s1,8(sp)
    80002752:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80002754:	cd19                	beqz	a0,80002772 <ilock+0x28>
    80002756:	84aa                	mv	s1,a0
    80002758:	451c                	lw	a5,8(a0)
    8000275a:	00f05c63          	blez	a5,80002772 <ilock+0x28>
  acquiresleep(&ip->lock);
    8000275e:	0541                	addi	a0,a0,16
    80002760:	345000ef          	jal	800032a4 <acquiresleep>
  if(ip->valid == 0){
    80002764:	40bc                	lw	a5,64(s1)
    80002766:	cf89                	beqz	a5,80002780 <ilock+0x36>
}
    80002768:	60e2                	ld	ra,24(sp)
    8000276a:	6442                	ld	s0,16(sp)
    8000276c:	64a2                	ld	s1,8(sp)
    8000276e:	6105                	addi	sp,sp,32
    80002770:	8082                	ret
    80002772:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80002774:	00005517          	auipc	a0,0x5
    80002778:	d2c50513          	addi	a0,a0,-724 # 800074a0 <etext+0x4a0>
    8000277c:	6ad020ef          	jal	80005628 <panic>
    80002780:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002782:	40dc                	lw	a5,4(s1)
    80002784:	0047d79b          	srliw	a5,a5,0x4
    80002788:	00014597          	auipc	a1,0x14
    8000278c:	0e85a583          	lw	a1,232(a1) # 80016870 <sb+0x18>
    80002790:	9dbd                	addw	a1,a1,a5
    80002792:	4088                	lw	a0,0(s1)
    80002794:	8b5ff0ef          	jal	80002048 <bread>
    80002798:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000279a:	05850593          	addi	a1,a0,88
    8000279e:	40dc                	lw	a5,4(s1)
    800027a0:	8bbd                	andi	a5,a5,15
    800027a2:	079a                	slli	a5,a5,0x6
    800027a4:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800027a6:	00059783          	lh	a5,0(a1)
    800027aa:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800027ae:	00259783          	lh	a5,2(a1)
    800027b2:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800027b6:	00459783          	lh	a5,4(a1)
    800027ba:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800027be:	00659783          	lh	a5,6(a1)
    800027c2:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800027c6:	459c                	lw	a5,8(a1)
    800027c8:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800027ca:	03400613          	li	a2,52
    800027ce:	05b1                	addi	a1,a1,12
    800027d0:	05048513          	addi	a0,s1,80
    800027d4:	9ebfd0ef          	jal	800001be <memmove>
    brelse(bp);
    800027d8:	854a                	mv	a0,s2
    800027da:	977ff0ef          	jal	80002150 <brelse>
    ip->valid = 1;
    800027de:	4785                	li	a5,1
    800027e0:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800027e2:	04449783          	lh	a5,68(s1)
    800027e6:	c399                	beqz	a5,800027ec <ilock+0xa2>
    800027e8:	6902                	ld	s2,0(sp)
    800027ea:	bfbd                	j	80002768 <ilock+0x1e>
      panic("ilock: no type");
    800027ec:	00005517          	auipc	a0,0x5
    800027f0:	cbc50513          	addi	a0,a0,-836 # 800074a8 <etext+0x4a8>
    800027f4:	635020ef          	jal	80005628 <panic>

00000000800027f8 <iunlock>:
{
    800027f8:	1101                	addi	sp,sp,-32
    800027fa:	ec06                	sd	ra,24(sp)
    800027fc:	e822                	sd	s0,16(sp)
    800027fe:	e426                	sd	s1,8(sp)
    80002800:	e04a                	sd	s2,0(sp)
    80002802:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80002804:	c505                	beqz	a0,8000282c <iunlock+0x34>
    80002806:	84aa                	mv	s1,a0
    80002808:	01050913          	addi	s2,a0,16
    8000280c:	854a                	mv	a0,s2
    8000280e:	315000ef          	jal	80003322 <holdingsleep>
    80002812:	cd09                	beqz	a0,8000282c <iunlock+0x34>
    80002814:	449c                	lw	a5,8(s1)
    80002816:	00f05b63          	blez	a5,8000282c <iunlock+0x34>
  releasesleep(&ip->lock);
    8000281a:	854a                	mv	a0,s2
    8000281c:	2cf000ef          	jal	800032ea <releasesleep>
}
    80002820:	60e2                	ld	ra,24(sp)
    80002822:	6442                	ld	s0,16(sp)
    80002824:	64a2                	ld	s1,8(sp)
    80002826:	6902                	ld	s2,0(sp)
    80002828:	6105                	addi	sp,sp,32
    8000282a:	8082                	ret
    panic("iunlock");
    8000282c:	00005517          	auipc	a0,0x5
    80002830:	c8c50513          	addi	a0,a0,-884 # 800074b8 <etext+0x4b8>
    80002834:	5f5020ef          	jal	80005628 <panic>

0000000080002838 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80002838:	7179                	addi	sp,sp,-48
    8000283a:	f406                	sd	ra,40(sp)
    8000283c:	f022                	sd	s0,32(sp)
    8000283e:	ec26                	sd	s1,24(sp)
    80002840:	e84a                	sd	s2,16(sp)
    80002842:	e44e                	sd	s3,8(sp)
    80002844:	1800                	addi	s0,sp,48
    80002846:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80002848:	05050493          	addi	s1,a0,80
    8000284c:	08050913          	addi	s2,a0,128
    80002850:	a021                	j	80002858 <itrunc+0x20>
    80002852:	0491                	addi	s1,s1,4
    80002854:	01248b63          	beq	s1,s2,8000286a <itrunc+0x32>
    if(ip->addrs[i]){
    80002858:	408c                	lw	a1,0(s1)
    8000285a:	dde5                	beqz	a1,80002852 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000285c:	0009a503          	lw	a0,0(s3)
    80002860:	9ddff0ef          	jal	8000223c <bfree>
      ip->addrs[i] = 0;
    80002864:	0004a023          	sw	zero,0(s1)
    80002868:	b7ed                	j	80002852 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    8000286a:	0809a583          	lw	a1,128(s3)
    8000286e:	ed89                	bnez	a1,80002888 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80002870:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80002874:	854e                	mv	a0,s3
    80002876:	e21ff0ef          	jal	80002696 <iupdate>
}
    8000287a:	70a2                	ld	ra,40(sp)
    8000287c:	7402                	ld	s0,32(sp)
    8000287e:	64e2                	ld	s1,24(sp)
    80002880:	6942                	ld	s2,16(sp)
    80002882:	69a2                	ld	s3,8(sp)
    80002884:	6145                	addi	sp,sp,48
    80002886:	8082                	ret
    80002888:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000288a:	0009a503          	lw	a0,0(s3)
    8000288e:	fbaff0ef          	jal	80002048 <bread>
    80002892:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80002894:	05850493          	addi	s1,a0,88
    80002898:	45850913          	addi	s2,a0,1112
    8000289c:	a021                	j	800028a4 <itrunc+0x6c>
    8000289e:	0491                	addi	s1,s1,4
    800028a0:	01248963          	beq	s1,s2,800028b2 <itrunc+0x7a>
      if(a[j])
    800028a4:	408c                	lw	a1,0(s1)
    800028a6:	dde5                	beqz	a1,8000289e <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800028a8:	0009a503          	lw	a0,0(s3)
    800028ac:	991ff0ef          	jal	8000223c <bfree>
    800028b0:	b7fd                	j	8000289e <itrunc+0x66>
    brelse(bp);
    800028b2:	8552                	mv	a0,s4
    800028b4:	89dff0ef          	jal	80002150 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800028b8:	0809a583          	lw	a1,128(s3)
    800028bc:	0009a503          	lw	a0,0(s3)
    800028c0:	97dff0ef          	jal	8000223c <bfree>
    ip->addrs[NDIRECT] = 0;
    800028c4:	0809a023          	sw	zero,128(s3)
    800028c8:	6a02                	ld	s4,0(sp)
    800028ca:	b75d                	j	80002870 <itrunc+0x38>

00000000800028cc <iput>:
{
    800028cc:	1101                	addi	sp,sp,-32
    800028ce:	ec06                	sd	ra,24(sp)
    800028d0:	e822                	sd	s0,16(sp)
    800028d2:	e426                	sd	s1,8(sp)
    800028d4:	1000                	addi	s0,sp,32
    800028d6:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800028d8:	00014517          	auipc	a0,0x14
    800028dc:	fa050513          	addi	a0,a0,-96 # 80016878 <itable>
    800028e0:	05c030ef          	jal	8000593c <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800028e4:	4498                	lw	a4,8(s1)
    800028e6:	4785                	li	a5,1
    800028e8:	02f70063          	beq	a4,a5,80002908 <iput+0x3c>
  ip->ref--;
    800028ec:	449c                	lw	a5,8(s1)
    800028ee:	37fd                	addiw	a5,a5,-1
    800028f0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800028f2:	00014517          	auipc	a0,0x14
    800028f6:	f8650513          	addi	a0,a0,-122 # 80016878 <itable>
    800028fa:	0d6030ef          	jal	800059d0 <release>
}
    800028fe:	60e2                	ld	ra,24(sp)
    80002900:	6442                	ld	s0,16(sp)
    80002902:	64a2                	ld	s1,8(sp)
    80002904:	6105                	addi	sp,sp,32
    80002906:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002908:	40bc                	lw	a5,64(s1)
    8000290a:	d3ed                	beqz	a5,800028ec <iput+0x20>
    8000290c:	04a49783          	lh	a5,74(s1)
    80002910:	fff1                	bnez	a5,800028ec <iput+0x20>
    80002912:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80002914:	01048793          	addi	a5,s1,16
    80002918:	893e                	mv	s2,a5
    8000291a:	853e                	mv	a0,a5
    8000291c:	189000ef          	jal	800032a4 <acquiresleep>
    release(&itable.lock);
    80002920:	00014517          	auipc	a0,0x14
    80002924:	f5850513          	addi	a0,a0,-168 # 80016878 <itable>
    80002928:	0a8030ef          	jal	800059d0 <release>
    itrunc(ip);
    8000292c:	8526                	mv	a0,s1
    8000292e:	f0bff0ef          	jal	80002838 <itrunc>
    ip->type = 0;
    80002932:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002936:	8526                	mv	a0,s1
    80002938:	d5fff0ef          	jal	80002696 <iupdate>
    ip->valid = 0;
    8000293c:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002940:	854a                	mv	a0,s2
    80002942:	1a9000ef          	jal	800032ea <releasesleep>
    acquire(&itable.lock);
    80002946:	00014517          	auipc	a0,0x14
    8000294a:	f3250513          	addi	a0,a0,-206 # 80016878 <itable>
    8000294e:	7ef020ef          	jal	8000593c <acquire>
    80002952:	6902                	ld	s2,0(sp)
    80002954:	bf61                	j	800028ec <iput+0x20>

0000000080002956 <iunlockput>:
{
    80002956:	1101                	addi	sp,sp,-32
    80002958:	ec06                	sd	ra,24(sp)
    8000295a:	e822                	sd	s0,16(sp)
    8000295c:	e426                	sd	s1,8(sp)
    8000295e:	1000                	addi	s0,sp,32
    80002960:	84aa                	mv	s1,a0
  iunlock(ip);
    80002962:	e97ff0ef          	jal	800027f8 <iunlock>
  iput(ip);
    80002966:	8526                	mv	a0,s1
    80002968:	f65ff0ef          	jal	800028cc <iput>
}
    8000296c:	60e2                	ld	ra,24(sp)
    8000296e:	6442                	ld	s0,16(sp)
    80002970:	64a2                	ld	s1,8(sp)
    80002972:	6105                	addi	sp,sp,32
    80002974:	8082                	ret

0000000080002976 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002976:	1141                	addi	sp,sp,-16
    80002978:	e406                	sd	ra,8(sp)
    8000297a:	e022                	sd	s0,0(sp)
    8000297c:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    8000297e:	411c                	lw	a5,0(a0)
    80002980:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002982:	415c                	lw	a5,4(a0)
    80002984:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002986:	04451783          	lh	a5,68(a0)
    8000298a:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    8000298e:	04a51783          	lh	a5,74(a0)
    80002992:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002996:	04c56783          	lwu	a5,76(a0)
    8000299a:	e99c                	sd	a5,16(a1)
}
    8000299c:	60a2                	ld	ra,8(sp)
    8000299e:	6402                	ld	s0,0(sp)
    800029a0:	0141                	addi	sp,sp,16
    800029a2:	8082                	ret

00000000800029a4 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800029a4:	457c                	lw	a5,76(a0)
    800029a6:	0ed7e663          	bltu	a5,a3,80002a92 <readi+0xee>
{
    800029aa:	7159                	addi	sp,sp,-112
    800029ac:	f486                	sd	ra,104(sp)
    800029ae:	f0a2                	sd	s0,96(sp)
    800029b0:	eca6                	sd	s1,88(sp)
    800029b2:	e0d2                	sd	s4,64(sp)
    800029b4:	fc56                	sd	s5,56(sp)
    800029b6:	f85a                	sd	s6,48(sp)
    800029b8:	f45e                	sd	s7,40(sp)
    800029ba:	1880                	addi	s0,sp,112
    800029bc:	8b2a                	mv	s6,a0
    800029be:	8bae                	mv	s7,a1
    800029c0:	8a32                	mv	s4,a2
    800029c2:	84b6                	mv	s1,a3
    800029c4:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800029c6:	9f35                	addw	a4,a4,a3
    return 0;
    800029c8:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800029ca:	0ad76b63          	bltu	a4,a3,80002a80 <readi+0xdc>
    800029ce:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    800029d0:	00e7f463          	bgeu	a5,a4,800029d8 <readi+0x34>
    n = ip->size - off;
    800029d4:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800029d8:	080a8b63          	beqz	s5,80002a6e <readi+0xca>
    800029dc:	e8ca                	sd	s2,80(sp)
    800029de:	f062                	sd	s8,32(sp)
    800029e0:	ec66                	sd	s9,24(sp)
    800029e2:	e86a                	sd	s10,16(sp)
    800029e4:	e46e                	sd	s11,8(sp)
    800029e6:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800029e8:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800029ec:	5c7d                	li	s8,-1
    800029ee:	a80d                	j	80002a20 <readi+0x7c>
    800029f0:	020d1d93          	slli	s11,s10,0x20
    800029f4:	020ddd93          	srli	s11,s11,0x20
    800029f8:	05890613          	addi	a2,s2,88
    800029fc:	86ee                	mv	a3,s11
    800029fe:	963e                	add	a2,a2,a5
    80002a00:	85d2                	mv	a1,s4
    80002a02:	855e                	mv	a0,s7
    80002a04:	cddfe0ef          	jal	800016e0 <either_copyout>
    80002a08:	05850363          	beq	a0,s8,80002a4e <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002a0c:	854a                	mv	a0,s2
    80002a0e:	f42ff0ef          	jal	80002150 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002a12:	013d09bb          	addw	s3,s10,s3
    80002a16:	009d04bb          	addw	s1,s10,s1
    80002a1a:	9a6e                	add	s4,s4,s11
    80002a1c:	0559f363          	bgeu	s3,s5,80002a62 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002a20:	00a4d59b          	srliw	a1,s1,0xa
    80002a24:	855a                	mv	a0,s6
    80002a26:	989ff0ef          	jal	800023ae <bmap>
    80002a2a:	85aa                	mv	a1,a0
    if(addr == 0)
    80002a2c:	c139                	beqz	a0,80002a72 <readi+0xce>
    bp = bread(ip->dev, addr);
    80002a2e:	000b2503          	lw	a0,0(s6)
    80002a32:	e16ff0ef          	jal	80002048 <bread>
    80002a36:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002a38:	3ff4f793          	andi	a5,s1,1023
    80002a3c:	40fc873b          	subw	a4,s9,a5
    80002a40:	413a86bb          	subw	a3,s5,s3
    80002a44:	8d3a                	mv	s10,a4
    80002a46:	fae6f5e3          	bgeu	a3,a4,800029f0 <readi+0x4c>
    80002a4a:	8d36                	mv	s10,a3
    80002a4c:	b755                	j	800029f0 <readi+0x4c>
      brelse(bp);
    80002a4e:	854a                	mv	a0,s2
    80002a50:	f00ff0ef          	jal	80002150 <brelse>
      tot = -1;
    80002a54:	59fd                	li	s3,-1
      break;
    80002a56:	6946                	ld	s2,80(sp)
    80002a58:	7c02                	ld	s8,32(sp)
    80002a5a:	6ce2                	ld	s9,24(sp)
    80002a5c:	6d42                	ld	s10,16(sp)
    80002a5e:	6da2                	ld	s11,8(sp)
    80002a60:	a831                	j	80002a7c <readi+0xd8>
    80002a62:	6946                	ld	s2,80(sp)
    80002a64:	7c02                	ld	s8,32(sp)
    80002a66:	6ce2                	ld	s9,24(sp)
    80002a68:	6d42                	ld	s10,16(sp)
    80002a6a:	6da2                	ld	s11,8(sp)
    80002a6c:	a801                	j	80002a7c <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002a6e:	89d6                	mv	s3,s5
    80002a70:	a031                	j	80002a7c <readi+0xd8>
    80002a72:	6946                	ld	s2,80(sp)
    80002a74:	7c02                	ld	s8,32(sp)
    80002a76:	6ce2                	ld	s9,24(sp)
    80002a78:	6d42                	ld	s10,16(sp)
    80002a7a:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80002a7c:	854e                	mv	a0,s3
    80002a7e:	69a6                	ld	s3,72(sp)
}
    80002a80:	70a6                	ld	ra,104(sp)
    80002a82:	7406                	ld	s0,96(sp)
    80002a84:	64e6                	ld	s1,88(sp)
    80002a86:	6a06                	ld	s4,64(sp)
    80002a88:	7ae2                	ld	s5,56(sp)
    80002a8a:	7b42                	ld	s6,48(sp)
    80002a8c:	7ba2                	ld	s7,40(sp)
    80002a8e:	6165                	addi	sp,sp,112
    80002a90:	8082                	ret
    return 0;
    80002a92:	4501                	li	a0,0
}
    80002a94:	8082                	ret

0000000080002a96 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002a96:	457c                	lw	a5,76(a0)
    80002a98:	0ed7eb63          	bltu	a5,a3,80002b8e <writei+0xf8>
{
    80002a9c:	7159                	addi	sp,sp,-112
    80002a9e:	f486                	sd	ra,104(sp)
    80002aa0:	f0a2                	sd	s0,96(sp)
    80002aa2:	e8ca                	sd	s2,80(sp)
    80002aa4:	e0d2                	sd	s4,64(sp)
    80002aa6:	fc56                	sd	s5,56(sp)
    80002aa8:	f85a                	sd	s6,48(sp)
    80002aaa:	f45e                	sd	s7,40(sp)
    80002aac:	1880                	addi	s0,sp,112
    80002aae:	8aaa                	mv	s5,a0
    80002ab0:	8bae                	mv	s7,a1
    80002ab2:	8a32                	mv	s4,a2
    80002ab4:	8936                	mv	s2,a3
    80002ab6:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80002ab8:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80002abc:	00043737          	lui	a4,0x43
    80002ac0:	0cf76963          	bltu	a4,a5,80002b92 <writei+0xfc>
    80002ac4:	0cd7e763          	bltu	a5,a3,80002b92 <writei+0xfc>
    80002ac8:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002aca:	0a0b0a63          	beqz	s6,80002b7e <writei+0xe8>
    80002ace:	eca6                	sd	s1,88(sp)
    80002ad0:	f062                	sd	s8,32(sp)
    80002ad2:	ec66                	sd	s9,24(sp)
    80002ad4:	e86a                	sd	s10,16(sp)
    80002ad6:	e46e                	sd	s11,8(sp)
    80002ad8:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002ada:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002ade:	5c7d                	li	s8,-1
    80002ae0:	a825                	j	80002b18 <writei+0x82>
    80002ae2:	020d1d93          	slli	s11,s10,0x20
    80002ae6:	020ddd93          	srli	s11,s11,0x20
    80002aea:	05848513          	addi	a0,s1,88
    80002aee:	86ee                	mv	a3,s11
    80002af0:	8652                	mv	a2,s4
    80002af2:	85de                	mv	a1,s7
    80002af4:	953e                	add	a0,a0,a5
    80002af6:	c35fe0ef          	jal	8000172a <either_copyin>
    80002afa:	05850663          	beq	a0,s8,80002b46 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002afe:	8526                	mv	a0,s1
    80002b00:	69c000ef          	jal	8000319c <log_write>
    brelse(bp);
    80002b04:	8526                	mv	a0,s1
    80002b06:	e4aff0ef          	jal	80002150 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002b0a:	013d09bb          	addw	s3,s10,s3
    80002b0e:	012d093b          	addw	s2,s10,s2
    80002b12:	9a6e                	add	s4,s4,s11
    80002b14:	0369fc63          	bgeu	s3,s6,80002b4c <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80002b18:	00a9559b          	srliw	a1,s2,0xa
    80002b1c:	8556                	mv	a0,s5
    80002b1e:	891ff0ef          	jal	800023ae <bmap>
    80002b22:	85aa                	mv	a1,a0
    if(addr == 0)
    80002b24:	c505                	beqz	a0,80002b4c <writei+0xb6>
    bp = bread(ip->dev, addr);
    80002b26:	000aa503          	lw	a0,0(s5)
    80002b2a:	d1eff0ef          	jal	80002048 <bread>
    80002b2e:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b30:	3ff97793          	andi	a5,s2,1023
    80002b34:	40fc873b          	subw	a4,s9,a5
    80002b38:	413b06bb          	subw	a3,s6,s3
    80002b3c:	8d3a                	mv	s10,a4
    80002b3e:	fae6f2e3          	bgeu	a3,a4,80002ae2 <writei+0x4c>
    80002b42:	8d36                	mv	s10,a3
    80002b44:	bf79                	j	80002ae2 <writei+0x4c>
      brelse(bp);
    80002b46:	8526                	mv	a0,s1
    80002b48:	e08ff0ef          	jal	80002150 <brelse>
  }

  if(off > ip->size)
    80002b4c:	04caa783          	lw	a5,76(s5)
    80002b50:	0327f963          	bgeu	a5,s2,80002b82 <writei+0xec>
    ip->size = off;
    80002b54:	052aa623          	sw	s2,76(s5)
    80002b58:	64e6                	ld	s1,88(sp)
    80002b5a:	7c02                	ld	s8,32(sp)
    80002b5c:	6ce2                	ld	s9,24(sp)
    80002b5e:	6d42                	ld	s10,16(sp)
    80002b60:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002b62:	8556                	mv	a0,s5
    80002b64:	b33ff0ef          	jal	80002696 <iupdate>

  return tot;
    80002b68:	854e                	mv	a0,s3
    80002b6a:	69a6                	ld	s3,72(sp)
}
    80002b6c:	70a6                	ld	ra,104(sp)
    80002b6e:	7406                	ld	s0,96(sp)
    80002b70:	6946                	ld	s2,80(sp)
    80002b72:	6a06                	ld	s4,64(sp)
    80002b74:	7ae2                	ld	s5,56(sp)
    80002b76:	7b42                	ld	s6,48(sp)
    80002b78:	7ba2                	ld	s7,40(sp)
    80002b7a:	6165                	addi	sp,sp,112
    80002b7c:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002b7e:	89da                	mv	s3,s6
    80002b80:	b7cd                	j	80002b62 <writei+0xcc>
    80002b82:	64e6                	ld	s1,88(sp)
    80002b84:	7c02                	ld	s8,32(sp)
    80002b86:	6ce2                	ld	s9,24(sp)
    80002b88:	6d42                	ld	s10,16(sp)
    80002b8a:	6da2                	ld	s11,8(sp)
    80002b8c:	bfd9                	j	80002b62 <writei+0xcc>
    return -1;
    80002b8e:	557d                	li	a0,-1
}
    80002b90:	8082                	ret
    return -1;
    80002b92:	557d                	li	a0,-1
    80002b94:	bfe1                	j	80002b6c <writei+0xd6>

0000000080002b96 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002b96:	1141                	addi	sp,sp,-16
    80002b98:	e406                	sd	ra,8(sp)
    80002b9a:	e022                	sd	s0,0(sp)
    80002b9c:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002b9e:	4639                	li	a2,14
    80002ba0:	e92fd0ef          	jal	80000232 <strncmp>
}
    80002ba4:	60a2                	ld	ra,8(sp)
    80002ba6:	6402                	ld	s0,0(sp)
    80002ba8:	0141                	addi	sp,sp,16
    80002baa:	8082                	ret

0000000080002bac <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002bac:	711d                	addi	sp,sp,-96
    80002bae:	ec86                	sd	ra,88(sp)
    80002bb0:	e8a2                	sd	s0,80(sp)
    80002bb2:	e4a6                	sd	s1,72(sp)
    80002bb4:	e0ca                	sd	s2,64(sp)
    80002bb6:	fc4e                	sd	s3,56(sp)
    80002bb8:	f852                	sd	s4,48(sp)
    80002bba:	f456                	sd	s5,40(sp)
    80002bbc:	f05a                	sd	s6,32(sp)
    80002bbe:	ec5e                	sd	s7,24(sp)
    80002bc0:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002bc2:	04451703          	lh	a4,68(a0)
    80002bc6:	4785                	li	a5,1
    80002bc8:	00f71f63          	bne	a4,a5,80002be6 <dirlookup+0x3a>
    80002bcc:	892a                	mv	s2,a0
    80002bce:	8aae                	mv	s5,a1
    80002bd0:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002bd2:	457c                	lw	a5,76(a0)
    80002bd4:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002bd6:	fa040a13          	addi	s4,s0,-96
    80002bda:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80002bdc:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002be0:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002be2:	e39d                	bnez	a5,80002c08 <dirlookup+0x5c>
    80002be4:	a8b9                	j	80002c42 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80002be6:	00005517          	auipc	a0,0x5
    80002bea:	8da50513          	addi	a0,a0,-1830 # 800074c0 <etext+0x4c0>
    80002bee:	23b020ef          	jal	80005628 <panic>
      panic("dirlookup read");
    80002bf2:	00005517          	auipc	a0,0x5
    80002bf6:	8e650513          	addi	a0,a0,-1818 # 800074d8 <etext+0x4d8>
    80002bfa:	22f020ef          	jal	80005628 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002bfe:	24c1                	addiw	s1,s1,16
    80002c00:	04c92783          	lw	a5,76(s2)
    80002c04:	02f4fe63          	bgeu	s1,a5,80002c40 <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002c08:	874e                	mv	a4,s3
    80002c0a:	86a6                	mv	a3,s1
    80002c0c:	8652                	mv	a2,s4
    80002c0e:	4581                	li	a1,0
    80002c10:	854a                	mv	a0,s2
    80002c12:	d93ff0ef          	jal	800029a4 <readi>
    80002c16:	fd351ee3          	bne	a0,s3,80002bf2 <dirlookup+0x46>
    if(de.inum == 0)
    80002c1a:	fa045783          	lhu	a5,-96(s0)
    80002c1e:	d3e5                	beqz	a5,80002bfe <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80002c20:	85da                	mv	a1,s6
    80002c22:	8556                	mv	a0,s5
    80002c24:	f73ff0ef          	jal	80002b96 <namecmp>
    80002c28:	f979                	bnez	a0,80002bfe <dirlookup+0x52>
      if(poff)
    80002c2a:	000b8463          	beqz	s7,80002c32 <dirlookup+0x86>
        *poff = off;
    80002c2e:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80002c32:	fa045583          	lhu	a1,-96(s0)
    80002c36:	00092503          	lw	a0,0(s2)
    80002c3a:	835ff0ef          	jal	8000246e <iget>
    80002c3e:	a011                	j	80002c42 <dirlookup+0x96>
  return 0;
    80002c40:	4501                	li	a0,0
}
    80002c42:	60e6                	ld	ra,88(sp)
    80002c44:	6446                	ld	s0,80(sp)
    80002c46:	64a6                	ld	s1,72(sp)
    80002c48:	6906                	ld	s2,64(sp)
    80002c4a:	79e2                	ld	s3,56(sp)
    80002c4c:	7a42                	ld	s4,48(sp)
    80002c4e:	7aa2                	ld	s5,40(sp)
    80002c50:	7b02                	ld	s6,32(sp)
    80002c52:	6be2                	ld	s7,24(sp)
    80002c54:	6125                	addi	sp,sp,96
    80002c56:	8082                	ret

0000000080002c58 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002c58:	711d                	addi	sp,sp,-96
    80002c5a:	ec86                	sd	ra,88(sp)
    80002c5c:	e8a2                	sd	s0,80(sp)
    80002c5e:	e4a6                	sd	s1,72(sp)
    80002c60:	e0ca                	sd	s2,64(sp)
    80002c62:	fc4e                	sd	s3,56(sp)
    80002c64:	f852                	sd	s4,48(sp)
    80002c66:	f456                	sd	s5,40(sp)
    80002c68:	f05a                	sd	s6,32(sp)
    80002c6a:	ec5e                	sd	s7,24(sp)
    80002c6c:	e862                	sd	s8,16(sp)
    80002c6e:	e466                	sd	s9,8(sp)
    80002c70:	e06a                	sd	s10,0(sp)
    80002c72:	1080                	addi	s0,sp,96
    80002c74:	84aa                	mv	s1,a0
    80002c76:	8b2e                	mv	s6,a1
    80002c78:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002c7a:	00054703          	lbu	a4,0(a0)
    80002c7e:	02f00793          	li	a5,47
    80002c82:	00f70f63          	beq	a4,a5,80002ca0 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002c86:	8fcfe0ef          	jal	80000d82 <myproc>
    80002c8a:	15053503          	ld	a0,336(a0)
    80002c8e:	a87ff0ef          	jal	80002714 <idup>
    80002c92:	8a2a                	mv	s4,a0
  while(*path == '/')
    80002c94:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80002c98:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80002c9a:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002c9c:	4b85                	li	s7,1
    80002c9e:	a879                	j	80002d3c <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80002ca0:	4585                	li	a1,1
    80002ca2:	852e                	mv	a0,a1
    80002ca4:	fcaff0ef          	jal	8000246e <iget>
    80002ca8:	8a2a                	mv	s4,a0
    80002caa:	b7ed                	j	80002c94 <namex+0x3c>
      iunlockput(ip);
    80002cac:	8552                	mv	a0,s4
    80002cae:	ca9ff0ef          	jal	80002956 <iunlockput>
      return 0;
    80002cb2:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002cb4:	8552                	mv	a0,s4
    80002cb6:	60e6                	ld	ra,88(sp)
    80002cb8:	6446                	ld	s0,80(sp)
    80002cba:	64a6                	ld	s1,72(sp)
    80002cbc:	6906                	ld	s2,64(sp)
    80002cbe:	79e2                	ld	s3,56(sp)
    80002cc0:	7a42                	ld	s4,48(sp)
    80002cc2:	7aa2                	ld	s5,40(sp)
    80002cc4:	7b02                	ld	s6,32(sp)
    80002cc6:	6be2                	ld	s7,24(sp)
    80002cc8:	6c42                	ld	s8,16(sp)
    80002cca:	6ca2                	ld	s9,8(sp)
    80002ccc:	6d02                	ld	s10,0(sp)
    80002cce:	6125                	addi	sp,sp,96
    80002cd0:	8082                	ret
      iunlock(ip);
    80002cd2:	8552                	mv	a0,s4
    80002cd4:	b25ff0ef          	jal	800027f8 <iunlock>
      return ip;
    80002cd8:	bff1                	j	80002cb4 <namex+0x5c>
      iunlockput(ip);
    80002cda:	8552                	mv	a0,s4
    80002cdc:	c7bff0ef          	jal	80002956 <iunlockput>
      return 0;
    80002ce0:	8a4a                	mv	s4,s2
    80002ce2:	bfc9                	j	80002cb4 <namex+0x5c>
  len = path - s;
    80002ce4:	40990633          	sub	a2,s2,s1
    80002ce8:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80002cec:	09ac5463          	bge	s8,s10,80002d74 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80002cf0:	8666                	mv	a2,s9
    80002cf2:	85a6                	mv	a1,s1
    80002cf4:	8556                	mv	a0,s5
    80002cf6:	cc8fd0ef          	jal	800001be <memmove>
    80002cfa:	84ca                	mv	s1,s2
  while(*path == '/')
    80002cfc:	0004c783          	lbu	a5,0(s1)
    80002d00:	01379763          	bne	a5,s3,80002d0e <namex+0xb6>
    path++;
    80002d04:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002d06:	0004c783          	lbu	a5,0(s1)
    80002d0a:	ff378de3          	beq	a5,s3,80002d04 <namex+0xac>
    ilock(ip);
    80002d0e:	8552                	mv	a0,s4
    80002d10:	a3bff0ef          	jal	8000274a <ilock>
    if(ip->type != T_DIR){
    80002d14:	044a1783          	lh	a5,68(s4)
    80002d18:	f9779ae3          	bne	a5,s7,80002cac <namex+0x54>
    if(nameiparent && *path == '\0'){
    80002d1c:	000b0563          	beqz	s6,80002d26 <namex+0xce>
    80002d20:	0004c783          	lbu	a5,0(s1)
    80002d24:	d7dd                	beqz	a5,80002cd2 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002d26:	4601                	li	a2,0
    80002d28:	85d6                	mv	a1,s5
    80002d2a:	8552                	mv	a0,s4
    80002d2c:	e81ff0ef          	jal	80002bac <dirlookup>
    80002d30:	892a                	mv	s2,a0
    80002d32:	d545                	beqz	a0,80002cda <namex+0x82>
    iunlockput(ip);
    80002d34:	8552                	mv	a0,s4
    80002d36:	c21ff0ef          	jal	80002956 <iunlockput>
    ip = next;
    80002d3a:	8a4a                	mv	s4,s2
  while(*path == '/')
    80002d3c:	0004c783          	lbu	a5,0(s1)
    80002d40:	01379763          	bne	a5,s3,80002d4e <namex+0xf6>
    path++;
    80002d44:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002d46:	0004c783          	lbu	a5,0(s1)
    80002d4a:	ff378de3          	beq	a5,s3,80002d44 <namex+0xec>
  if(*path == 0)
    80002d4e:	cf8d                	beqz	a5,80002d88 <namex+0x130>
  while(*path != '/' && *path != 0)
    80002d50:	0004c783          	lbu	a5,0(s1)
    80002d54:	fd178713          	addi	a4,a5,-47
    80002d58:	cb19                	beqz	a4,80002d6e <namex+0x116>
    80002d5a:	cb91                	beqz	a5,80002d6e <namex+0x116>
    80002d5c:	8926                	mv	s2,s1
    path++;
    80002d5e:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80002d60:	00094783          	lbu	a5,0(s2)
    80002d64:	fd178713          	addi	a4,a5,-47
    80002d68:	df35                	beqz	a4,80002ce4 <namex+0x8c>
    80002d6a:	fbf5                	bnez	a5,80002d5e <namex+0x106>
    80002d6c:	bfa5                	j	80002ce4 <namex+0x8c>
    80002d6e:	8926                	mv	s2,s1
  len = path - s;
    80002d70:	4d01                	li	s10,0
    80002d72:	4601                	li	a2,0
    memmove(name, s, len);
    80002d74:	2601                	sext.w	a2,a2
    80002d76:	85a6                	mv	a1,s1
    80002d78:	8556                	mv	a0,s5
    80002d7a:	c44fd0ef          	jal	800001be <memmove>
    name[len] = 0;
    80002d7e:	9d56                	add	s10,s10,s5
    80002d80:	000d0023          	sb	zero,0(s10)
    80002d84:	84ca                	mv	s1,s2
    80002d86:	bf9d                	j	80002cfc <namex+0xa4>
  if(nameiparent){
    80002d88:	f20b06e3          	beqz	s6,80002cb4 <namex+0x5c>
    iput(ip);
    80002d8c:	8552                	mv	a0,s4
    80002d8e:	b3fff0ef          	jal	800028cc <iput>
    return 0;
    80002d92:	4a01                	li	s4,0
    80002d94:	b705                	j	80002cb4 <namex+0x5c>

0000000080002d96 <dirlink>:
{
    80002d96:	715d                	addi	sp,sp,-80
    80002d98:	e486                	sd	ra,72(sp)
    80002d9a:	e0a2                	sd	s0,64(sp)
    80002d9c:	f84a                	sd	s2,48(sp)
    80002d9e:	ec56                	sd	s5,24(sp)
    80002da0:	e85a                	sd	s6,16(sp)
    80002da2:	0880                	addi	s0,sp,80
    80002da4:	892a                	mv	s2,a0
    80002da6:	8aae                	mv	s5,a1
    80002da8:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002daa:	4601                	li	a2,0
    80002dac:	e01ff0ef          	jal	80002bac <dirlookup>
    80002db0:	ed1d                	bnez	a0,80002dee <dirlink+0x58>
    80002db2:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002db4:	04c92483          	lw	s1,76(s2)
    80002db8:	c4b9                	beqz	s1,80002e06 <dirlink+0x70>
    80002dba:	f44e                	sd	s3,40(sp)
    80002dbc:	f052                	sd	s4,32(sp)
    80002dbe:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002dc0:	fb040a13          	addi	s4,s0,-80
    80002dc4:	49c1                	li	s3,16
    80002dc6:	874e                	mv	a4,s3
    80002dc8:	86a6                	mv	a3,s1
    80002dca:	8652                	mv	a2,s4
    80002dcc:	4581                	li	a1,0
    80002dce:	854a                	mv	a0,s2
    80002dd0:	bd5ff0ef          	jal	800029a4 <readi>
    80002dd4:	03351163          	bne	a0,s3,80002df6 <dirlink+0x60>
    if(de.inum == 0)
    80002dd8:	fb045783          	lhu	a5,-80(s0)
    80002ddc:	c39d                	beqz	a5,80002e02 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002dde:	24c1                	addiw	s1,s1,16
    80002de0:	04c92783          	lw	a5,76(s2)
    80002de4:	fef4e1e3          	bltu	s1,a5,80002dc6 <dirlink+0x30>
    80002de8:	79a2                	ld	s3,40(sp)
    80002dea:	7a02                	ld	s4,32(sp)
    80002dec:	a829                	j	80002e06 <dirlink+0x70>
    iput(ip);
    80002dee:	adfff0ef          	jal	800028cc <iput>
    return -1;
    80002df2:	557d                	li	a0,-1
    80002df4:	a83d                	j	80002e32 <dirlink+0x9c>
      panic("dirlink read");
    80002df6:	00004517          	auipc	a0,0x4
    80002dfa:	6f250513          	addi	a0,a0,1778 # 800074e8 <etext+0x4e8>
    80002dfe:	02b020ef          	jal	80005628 <panic>
    80002e02:	79a2                	ld	s3,40(sp)
    80002e04:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80002e06:	4639                	li	a2,14
    80002e08:	85d6                	mv	a1,s5
    80002e0a:	fb240513          	addi	a0,s0,-78
    80002e0e:	c5efd0ef          	jal	8000026c <strncpy>
  de.inum = inum;
    80002e12:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002e16:	4741                	li	a4,16
    80002e18:	86a6                	mv	a3,s1
    80002e1a:	fb040613          	addi	a2,s0,-80
    80002e1e:	4581                	li	a1,0
    80002e20:	854a                	mv	a0,s2
    80002e22:	c75ff0ef          	jal	80002a96 <writei>
    80002e26:	1541                	addi	a0,a0,-16
    80002e28:	00a03533          	snez	a0,a0
    80002e2c:	40a0053b          	negw	a0,a0
    80002e30:	74e2                	ld	s1,56(sp)
}
    80002e32:	60a6                	ld	ra,72(sp)
    80002e34:	6406                	ld	s0,64(sp)
    80002e36:	7942                	ld	s2,48(sp)
    80002e38:	6ae2                	ld	s5,24(sp)
    80002e3a:	6b42                	ld	s6,16(sp)
    80002e3c:	6161                	addi	sp,sp,80
    80002e3e:	8082                	ret

0000000080002e40 <namei>:

struct inode*
namei(char *path)
{
    80002e40:	1101                	addi	sp,sp,-32
    80002e42:	ec06                	sd	ra,24(sp)
    80002e44:	e822                	sd	s0,16(sp)
    80002e46:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002e48:	fe040613          	addi	a2,s0,-32
    80002e4c:	4581                	li	a1,0
    80002e4e:	e0bff0ef          	jal	80002c58 <namex>
}
    80002e52:	60e2                	ld	ra,24(sp)
    80002e54:	6442                	ld	s0,16(sp)
    80002e56:	6105                	addi	sp,sp,32
    80002e58:	8082                	ret

0000000080002e5a <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002e5a:	1141                	addi	sp,sp,-16
    80002e5c:	e406                	sd	ra,8(sp)
    80002e5e:	e022                	sd	s0,0(sp)
    80002e60:	0800                	addi	s0,sp,16
    80002e62:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002e64:	4585                	li	a1,1
    80002e66:	df3ff0ef          	jal	80002c58 <namex>
}
    80002e6a:	60a2                	ld	ra,8(sp)
    80002e6c:	6402                	ld	s0,0(sp)
    80002e6e:	0141                	addi	sp,sp,16
    80002e70:	8082                	ret

0000000080002e72 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002e72:	1101                	addi	sp,sp,-32
    80002e74:	ec06                	sd	ra,24(sp)
    80002e76:	e822                	sd	s0,16(sp)
    80002e78:	e426                	sd	s1,8(sp)
    80002e7a:	e04a                	sd	s2,0(sp)
    80002e7c:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002e7e:	00015917          	auipc	s2,0x15
    80002e82:	4a290913          	addi	s2,s2,1186 # 80018320 <log>
    80002e86:	01892583          	lw	a1,24(s2)
    80002e8a:	02892503          	lw	a0,40(s2)
    80002e8e:	9baff0ef          	jal	80002048 <bread>
    80002e92:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002e94:	02c92603          	lw	a2,44(s2)
    80002e98:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002e9a:	00c05f63          	blez	a2,80002eb8 <write_head+0x46>
    80002e9e:	00015717          	auipc	a4,0x15
    80002ea2:	4b270713          	addi	a4,a4,1202 # 80018350 <log+0x30>
    80002ea6:	87aa                	mv	a5,a0
    80002ea8:	060a                	slli	a2,a2,0x2
    80002eaa:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80002eac:	4314                	lw	a3,0(a4)
    80002eae:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80002eb0:	0711                	addi	a4,a4,4
    80002eb2:	0791                	addi	a5,a5,4
    80002eb4:	fec79ce3          	bne	a5,a2,80002eac <write_head+0x3a>
  }
  bwrite(buf);
    80002eb8:	8526                	mv	a0,s1
    80002eba:	a64ff0ef          	jal	8000211e <bwrite>
  brelse(buf);
    80002ebe:	8526                	mv	a0,s1
    80002ec0:	a90ff0ef          	jal	80002150 <brelse>
}
    80002ec4:	60e2                	ld	ra,24(sp)
    80002ec6:	6442                	ld	s0,16(sp)
    80002ec8:	64a2                	ld	s1,8(sp)
    80002eca:	6902                	ld	s2,0(sp)
    80002ecc:	6105                	addi	sp,sp,32
    80002ece:	8082                	ret

0000000080002ed0 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80002ed0:	00015797          	auipc	a5,0x15
    80002ed4:	47c7a783          	lw	a5,1148(a5) # 8001834c <log+0x2c>
    80002ed8:	0af05263          	blez	a5,80002f7c <install_trans+0xac>
{
    80002edc:	715d                	addi	sp,sp,-80
    80002ede:	e486                	sd	ra,72(sp)
    80002ee0:	e0a2                	sd	s0,64(sp)
    80002ee2:	fc26                	sd	s1,56(sp)
    80002ee4:	f84a                	sd	s2,48(sp)
    80002ee6:	f44e                	sd	s3,40(sp)
    80002ee8:	f052                	sd	s4,32(sp)
    80002eea:	ec56                	sd	s5,24(sp)
    80002eec:	e85a                	sd	s6,16(sp)
    80002eee:	e45e                	sd	s7,8(sp)
    80002ef0:	0880                	addi	s0,sp,80
    80002ef2:	8b2a                	mv	s6,a0
    80002ef4:	00015a97          	auipc	s5,0x15
    80002ef8:	45ca8a93          	addi	s5,s5,1116 # 80018350 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002efc:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002efe:	00015997          	auipc	s3,0x15
    80002f02:	42298993          	addi	s3,s3,1058 # 80018320 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80002f06:	40000b93          	li	s7,1024
    80002f0a:	a829                	j	80002f24 <install_trans+0x54>
    brelse(lbuf);
    80002f0c:	854a                	mv	a0,s2
    80002f0e:	a42ff0ef          	jal	80002150 <brelse>
    brelse(dbuf);
    80002f12:	8526                	mv	a0,s1
    80002f14:	a3cff0ef          	jal	80002150 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80002f18:	2a05                	addiw	s4,s4,1
    80002f1a:	0a91                	addi	s5,s5,4
    80002f1c:	02c9a783          	lw	a5,44(s3)
    80002f20:	04fa5363          	bge	s4,a5,80002f66 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80002f24:	0189a583          	lw	a1,24(s3)
    80002f28:	014585bb          	addw	a1,a1,s4
    80002f2c:	2585                	addiw	a1,a1,1
    80002f2e:	0289a503          	lw	a0,40(s3)
    80002f32:	916ff0ef          	jal	80002048 <bread>
    80002f36:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80002f38:	000aa583          	lw	a1,0(s5)
    80002f3c:	0289a503          	lw	a0,40(s3)
    80002f40:	908ff0ef          	jal	80002048 <bread>
    80002f44:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80002f46:	865e                	mv	a2,s7
    80002f48:	05890593          	addi	a1,s2,88
    80002f4c:	05850513          	addi	a0,a0,88
    80002f50:	a6efd0ef          	jal	800001be <memmove>
    bwrite(dbuf);  // write dst to disk
    80002f54:	8526                	mv	a0,s1
    80002f56:	9c8ff0ef          	jal	8000211e <bwrite>
    if(recovering == 0)
    80002f5a:	fa0b19e3          	bnez	s6,80002f0c <install_trans+0x3c>
      bunpin(dbuf);
    80002f5e:	8526                	mv	a0,s1
    80002f60:	aa8ff0ef          	jal	80002208 <bunpin>
    80002f64:	b765                	j	80002f0c <install_trans+0x3c>
}
    80002f66:	60a6                	ld	ra,72(sp)
    80002f68:	6406                	ld	s0,64(sp)
    80002f6a:	74e2                	ld	s1,56(sp)
    80002f6c:	7942                	ld	s2,48(sp)
    80002f6e:	79a2                	ld	s3,40(sp)
    80002f70:	7a02                	ld	s4,32(sp)
    80002f72:	6ae2                	ld	s5,24(sp)
    80002f74:	6b42                	ld	s6,16(sp)
    80002f76:	6ba2                	ld	s7,8(sp)
    80002f78:	6161                	addi	sp,sp,80
    80002f7a:	8082                	ret
    80002f7c:	8082                	ret

0000000080002f7e <initlog>:
{
    80002f7e:	7179                	addi	sp,sp,-48
    80002f80:	f406                	sd	ra,40(sp)
    80002f82:	f022                	sd	s0,32(sp)
    80002f84:	ec26                	sd	s1,24(sp)
    80002f86:	e84a                	sd	s2,16(sp)
    80002f88:	e44e                	sd	s3,8(sp)
    80002f8a:	1800                	addi	s0,sp,48
    80002f8c:	892a                	mv	s2,a0
    80002f8e:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80002f90:	00015497          	auipc	s1,0x15
    80002f94:	39048493          	addi	s1,s1,912 # 80018320 <log>
    80002f98:	00004597          	auipc	a1,0x4
    80002f9c:	56058593          	addi	a1,a1,1376 # 800074f8 <etext+0x4f8>
    80002fa0:	8526                	mv	a0,s1
    80002fa2:	111020ef          	jal	800058b2 <initlock>
  log.start = sb->logstart;
    80002fa6:	0149a583          	lw	a1,20(s3)
    80002faa:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80002fac:	0109a783          	lw	a5,16(s3)
    80002fb0:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80002fb2:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80002fb6:	854a                	mv	a0,s2
    80002fb8:	890ff0ef          	jal	80002048 <bread>
  log.lh.n = lh->n;
    80002fbc:	4d30                	lw	a2,88(a0)
    80002fbe:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80002fc0:	00c05f63          	blez	a2,80002fde <initlog+0x60>
    80002fc4:	87aa                	mv	a5,a0
    80002fc6:	00015717          	auipc	a4,0x15
    80002fca:	38a70713          	addi	a4,a4,906 # 80018350 <log+0x30>
    80002fce:	060a                	slli	a2,a2,0x2
    80002fd0:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80002fd2:	4ff4                	lw	a3,92(a5)
    80002fd4:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80002fd6:	0791                	addi	a5,a5,4
    80002fd8:	0711                	addi	a4,a4,4
    80002fda:	fec79ce3          	bne	a5,a2,80002fd2 <initlog+0x54>
  brelse(buf);
    80002fde:	972ff0ef          	jal	80002150 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80002fe2:	4505                	li	a0,1
    80002fe4:	eedff0ef          	jal	80002ed0 <install_trans>
  log.lh.n = 0;
    80002fe8:	00015797          	auipc	a5,0x15
    80002fec:	3607a223          	sw	zero,868(a5) # 8001834c <log+0x2c>
  write_head(); // clear the log
    80002ff0:	e83ff0ef          	jal	80002e72 <write_head>
}
    80002ff4:	70a2                	ld	ra,40(sp)
    80002ff6:	7402                	ld	s0,32(sp)
    80002ff8:	64e2                	ld	s1,24(sp)
    80002ffa:	6942                	ld	s2,16(sp)
    80002ffc:	69a2                	ld	s3,8(sp)
    80002ffe:	6145                	addi	sp,sp,48
    80003000:	8082                	ret

0000000080003002 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003002:	1101                	addi	sp,sp,-32
    80003004:	ec06                	sd	ra,24(sp)
    80003006:	e822                	sd	s0,16(sp)
    80003008:	e426                	sd	s1,8(sp)
    8000300a:	e04a                	sd	s2,0(sp)
    8000300c:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000300e:	00015517          	auipc	a0,0x15
    80003012:	31250513          	addi	a0,a0,786 # 80018320 <log>
    80003016:	127020ef          	jal	8000593c <acquire>
  while(1){
    if(log.committing){
    8000301a:	00015497          	auipc	s1,0x15
    8000301e:	30648493          	addi	s1,s1,774 # 80018320 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003022:	4979                	li	s2,30
    80003024:	a029                	j	8000302e <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003026:	85a6                	mv	a1,s1
    80003028:	8526                	mv	a0,s1
    8000302a:	b5cfe0ef          	jal	80001386 <sleep>
    if(log.committing){
    8000302e:	50dc                	lw	a5,36(s1)
    80003030:	fbfd                	bnez	a5,80003026 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003032:	5098                	lw	a4,32(s1)
    80003034:	2705                	addiw	a4,a4,1
    80003036:	0027179b          	slliw	a5,a4,0x2
    8000303a:	9fb9                	addw	a5,a5,a4
    8000303c:	0017979b          	slliw	a5,a5,0x1
    80003040:	54d4                	lw	a3,44(s1)
    80003042:	9fb5                	addw	a5,a5,a3
    80003044:	00f95763          	bge	s2,a5,80003052 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003048:	85a6                	mv	a1,s1
    8000304a:	8526                	mv	a0,s1
    8000304c:	b3afe0ef          	jal	80001386 <sleep>
    80003050:	bff9                	j	8000302e <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003052:	00015797          	auipc	a5,0x15
    80003056:	2ee7a723          	sw	a4,750(a5) # 80018340 <log+0x20>
      release(&log.lock);
    8000305a:	00015517          	auipc	a0,0x15
    8000305e:	2c650513          	addi	a0,a0,710 # 80018320 <log>
    80003062:	16f020ef          	jal	800059d0 <release>
      break;
    }
  }
}
    80003066:	60e2                	ld	ra,24(sp)
    80003068:	6442                	ld	s0,16(sp)
    8000306a:	64a2                	ld	s1,8(sp)
    8000306c:	6902                	ld	s2,0(sp)
    8000306e:	6105                	addi	sp,sp,32
    80003070:	8082                	ret

0000000080003072 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003072:	7139                	addi	sp,sp,-64
    80003074:	fc06                	sd	ra,56(sp)
    80003076:	f822                	sd	s0,48(sp)
    80003078:	f426                	sd	s1,40(sp)
    8000307a:	f04a                	sd	s2,32(sp)
    8000307c:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    8000307e:	00015497          	auipc	s1,0x15
    80003082:	2a248493          	addi	s1,s1,674 # 80018320 <log>
    80003086:	8526                	mv	a0,s1
    80003088:	0b5020ef          	jal	8000593c <acquire>
  log.outstanding -= 1;
    8000308c:	509c                	lw	a5,32(s1)
    8000308e:	37fd                	addiw	a5,a5,-1
    80003090:	893e                	mv	s2,a5
    80003092:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80003094:	50dc                	lw	a5,36(s1)
    80003096:	e7b1                	bnez	a5,800030e2 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80003098:	04091e63          	bnez	s2,800030f4 <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    8000309c:	00015497          	auipc	s1,0x15
    800030a0:	28448493          	addi	s1,s1,644 # 80018320 <log>
    800030a4:	4785                	li	a5,1
    800030a6:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800030a8:	8526                	mv	a0,s1
    800030aa:	127020ef          	jal	800059d0 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800030ae:	54dc                	lw	a5,44(s1)
    800030b0:	06f04463          	bgtz	a5,80003118 <end_op+0xa6>
    acquire(&log.lock);
    800030b4:	00015517          	auipc	a0,0x15
    800030b8:	26c50513          	addi	a0,a0,620 # 80018320 <log>
    800030bc:	081020ef          	jal	8000593c <acquire>
    log.committing = 0;
    800030c0:	00015797          	auipc	a5,0x15
    800030c4:	2807a223          	sw	zero,644(a5) # 80018344 <log+0x24>
    wakeup(&log);
    800030c8:	00015517          	auipc	a0,0x15
    800030cc:	25850513          	addi	a0,a0,600 # 80018320 <log>
    800030d0:	b02fe0ef          	jal	800013d2 <wakeup>
    release(&log.lock);
    800030d4:	00015517          	auipc	a0,0x15
    800030d8:	24c50513          	addi	a0,a0,588 # 80018320 <log>
    800030dc:	0f5020ef          	jal	800059d0 <release>
}
    800030e0:	a035                	j	8000310c <end_op+0x9a>
    800030e2:	ec4e                	sd	s3,24(sp)
    800030e4:	e852                	sd	s4,16(sp)
    800030e6:	e456                	sd	s5,8(sp)
    panic("log.committing");
    800030e8:	00004517          	auipc	a0,0x4
    800030ec:	41850513          	addi	a0,a0,1048 # 80007500 <etext+0x500>
    800030f0:	538020ef          	jal	80005628 <panic>
    wakeup(&log);
    800030f4:	00015517          	auipc	a0,0x15
    800030f8:	22c50513          	addi	a0,a0,556 # 80018320 <log>
    800030fc:	ad6fe0ef          	jal	800013d2 <wakeup>
  release(&log.lock);
    80003100:	00015517          	auipc	a0,0x15
    80003104:	22050513          	addi	a0,a0,544 # 80018320 <log>
    80003108:	0c9020ef          	jal	800059d0 <release>
}
    8000310c:	70e2                	ld	ra,56(sp)
    8000310e:	7442                	ld	s0,48(sp)
    80003110:	74a2                	ld	s1,40(sp)
    80003112:	7902                	ld	s2,32(sp)
    80003114:	6121                	addi	sp,sp,64
    80003116:	8082                	ret
    80003118:	ec4e                	sd	s3,24(sp)
    8000311a:	e852                	sd	s4,16(sp)
    8000311c:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    8000311e:	00015a97          	auipc	s5,0x15
    80003122:	232a8a93          	addi	s5,s5,562 # 80018350 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003126:	00015a17          	auipc	s4,0x15
    8000312a:	1faa0a13          	addi	s4,s4,506 # 80018320 <log>
    8000312e:	018a2583          	lw	a1,24(s4)
    80003132:	012585bb          	addw	a1,a1,s2
    80003136:	2585                	addiw	a1,a1,1
    80003138:	028a2503          	lw	a0,40(s4)
    8000313c:	f0dfe0ef          	jal	80002048 <bread>
    80003140:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003142:	000aa583          	lw	a1,0(s5)
    80003146:	028a2503          	lw	a0,40(s4)
    8000314a:	efffe0ef          	jal	80002048 <bread>
    8000314e:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003150:	40000613          	li	a2,1024
    80003154:	05850593          	addi	a1,a0,88
    80003158:	05848513          	addi	a0,s1,88
    8000315c:	862fd0ef          	jal	800001be <memmove>
    bwrite(to);  // write the log
    80003160:	8526                	mv	a0,s1
    80003162:	fbdfe0ef          	jal	8000211e <bwrite>
    brelse(from);
    80003166:	854e                	mv	a0,s3
    80003168:	fe9fe0ef          	jal	80002150 <brelse>
    brelse(to);
    8000316c:	8526                	mv	a0,s1
    8000316e:	fe3fe0ef          	jal	80002150 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003172:	2905                	addiw	s2,s2,1
    80003174:	0a91                	addi	s5,s5,4
    80003176:	02ca2783          	lw	a5,44(s4)
    8000317a:	faf94ae3          	blt	s2,a5,8000312e <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    8000317e:	cf5ff0ef          	jal	80002e72 <write_head>
    install_trans(0); // Now install writes to home locations
    80003182:	4501                	li	a0,0
    80003184:	d4dff0ef          	jal	80002ed0 <install_trans>
    log.lh.n = 0;
    80003188:	00015797          	auipc	a5,0x15
    8000318c:	1c07a223          	sw	zero,452(a5) # 8001834c <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003190:	ce3ff0ef          	jal	80002e72 <write_head>
    80003194:	69e2                	ld	s3,24(sp)
    80003196:	6a42                	ld	s4,16(sp)
    80003198:	6aa2                	ld	s5,8(sp)
    8000319a:	bf29                	j	800030b4 <end_op+0x42>

000000008000319c <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000319c:	1101                	addi	sp,sp,-32
    8000319e:	ec06                	sd	ra,24(sp)
    800031a0:	e822                	sd	s0,16(sp)
    800031a2:	e426                	sd	s1,8(sp)
    800031a4:	1000                	addi	s0,sp,32
    800031a6:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800031a8:	00015517          	auipc	a0,0x15
    800031ac:	17850513          	addi	a0,a0,376 # 80018320 <log>
    800031b0:	78c020ef          	jal	8000593c <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800031b4:	00015617          	auipc	a2,0x15
    800031b8:	19862603          	lw	a2,408(a2) # 8001834c <log+0x2c>
    800031bc:	47f5                	li	a5,29
    800031be:	06c7c463          	blt	a5,a2,80003226 <log_write+0x8a>
    800031c2:	00015797          	auipc	a5,0x15
    800031c6:	17a7a783          	lw	a5,378(a5) # 8001833c <log+0x1c>
    800031ca:	37fd                	addiw	a5,a5,-1
    800031cc:	04f65d63          	bge	a2,a5,80003226 <log_write+0x8a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800031d0:	00015797          	auipc	a5,0x15
    800031d4:	1707a783          	lw	a5,368(a5) # 80018340 <log+0x20>
    800031d8:	04f05d63          	blez	a5,80003232 <log_write+0x96>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800031dc:	4781                	li	a5,0
    800031de:	06c05063          	blez	a2,8000323e <log_write+0xa2>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800031e2:	44cc                	lw	a1,12(s1)
    800031e4:	00015717          	auipc	a4,0x15
    800031e8:	16c70713          	addi	a4,a4,364 # 80018350 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800031ec:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800031ee:	4314                	lw	a3,0(a4)
    800031f0:	04b68763          	beq	a3,a1,8000323e <log_write+0xa2>
  for (i = 0; i < log.lh.n; i++) {
    800031f4:	2785                	addiw	a5,a5,1
    800031f6:	0711                	addi	a4,a4,4
    800031f8:	fef61be3          	bne	a2,a5,800031ee <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    800031fc:	060a                	slli	a2,a2,0x2
    800031fe:	02060613          	addi	a2,a2,32
    80003202:	00015797          	auipc	a5,0x15
    80003206:	11e78793          	addi	a5,a5,286 # 80018320 <log>
    8000320a:	97b2                	add	a5,a5,a2
    8000320c:	44d8                	lw	a4,12(s1)
    8000320e:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003210:	8526                	mv	a0,s1
    80003212:	fc3fe0ef          	jal	800021d4 <bpin>
    log.lh.n++;
    80003216:	00015717          	auipc	a4,0x15
    8000321a:	10a70713          	addi	a4,a4,266 # 80018320 <log>
    8000321e:	575c                	lw	a5,44(a4)
    80003220:	2785                	addiw	a5,a5,1
    80003222:	d75c                	sw	a5,44(a4)
    80003224:	a815                	j	80003258 <log_write+0xbc>
    panic("too big a transaction");
    80003226:	00004517          	auipc	a0,0x4
    8000322a:	2ea50513          	addi	a0,a0,746 # 80007510 <etext+0x510>
    8000322e:	3fa020ef          	jal	80005628 <panic>
    panic("log_write outside of trans");
    80003232:	00004517          	auipc	a0,0x4
    80003236:	2f650513          	addi	a0,a0,758 # 80007528 <etext+0x528>
    8000323a:	3ee020ef          	jal	80005628 <panic>
  log.lh.block[i] = b->blockno;
    8000323e:	00279693          	slli	a3,a5,0x2
    80003242:	02068693          	addi	a3,a3,32
    80003246:	00015717          	auipc	a4,0x15
    8000324a:	0da70713          	addi	a4,a4,218 # 80018320 <log>
    8000324e:	9736                	add	a4,a4,a3
    80003250:	44d4                	lw	a3,12(s1)
    80003252:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003254:	faf60ee3          	beq	a2,a5,80003210 <log_write+0x74>
  }
  release(&log.lock);
    80003258:	00015517          	auipc	a0,0x15
    8000325c:	0c850513          	addi	a0,a0,200 # 80018320 <log>
    80003260:	770020ef          	jal	800059d0 <release>
}
    80003264:	60e2                	ld	ra,24(sp)
    80003266:	6442                	ld	s0,16(sp)
    80003268:	64a2                	ld	s1,8(sp)
    8000326a:	6105                	addi	sp,sp,32
    8000326c:	8082                	ret

000000008000326e <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    8000326e:	1101                	addi	sp,sp,-32
    80003270:	ec06                	sd	ra,24(sp)
    80003272:	e822                	sd	s0,16(sp)
    80003274:	e426                	sd	s1,8(sp)
    80003276:	e04a                	sd	s2,0(sp)
    80003278:	1000                	addi	s0,sp,32
    8000327a:	84aa                	mv	s1,a0
    8000327c:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    8000327e:	00004597          	auipc	a1,0x4
    80003282:	2ca58593          	addi	a1,a1,714 # 80007548 <etext+0x548>
    80003286:	0521                	addi	a0,a0,8
    80003288:	62a020ef          	jal	800058b2 <initlock>
  lk->name = name;
    8000328c:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003290:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003294:	0204a423          	sw	zero,40(s1)
}
    80003298:	60e2                	ld	ra,24(sp)
    8000329a:	6442                	ld	s0,16(sp)
    8000329c:	64a2                	ld	s1,8(sp)
    8000329e:	6902                	ld	s2,0(sp)
    800032a0:	6105                	addi	sp,sp,32
    800032a2:	8082                	ret

00000000800032a4 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800032a4:	1101                	addi	sp,sp,-32
    800032a6:	ec06                	sd	ra,24(sp)
    800032a8:	e822                	sd	s0,16(sp)
    800032aa:	e426                	sd	s1,8(sp)
    800032ac:	e04a                	sd	s2,0(sp)
    800032ae:	1000                	addi	s0,sp,32
    800032b0:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800032b2:	00850913          	addi	s2,a0,8
    800032b6:	854a                	mv	a0,s2
    800032b8:	684020ef          	jal	8000593c <acquire>
  while (lk->locked) {
    800032bc:	409c                	lw	a5,0(s1)
    800032be:	c799                	beqz	a5,800032cc <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    800032c0:	85ca                	mv	a1,s2
    800032c2:	8526                	mv	a0,s1
    800032c4:	8c2fe0ef          	jal	80001386 <sleep>
  while (lk->locked) {
    800032c8:	409c                	lw	a5,0(s1)
    800032ca:	fbfd                	bnez	a5,800032c0 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800032cc:	4785                	li	a5,1
    800032ce:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800032d0:	ab3fd0ef          	jal	80000d82 <myproc>
    800032d4:	591c                	lw	a5,48(a0)
    800032d6:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800032d8:	854a                	mv	a0,s2
    800032da:	6f6020ef          	jal	800059d0 <release>
}
    800032de:	60e2                	ld	ra,24(sp)
    800032e0:	6442                	ld	s0,16(sp)
    800032e2:	64a2                	ld	s1,8(sp)
    800032e4:	6902                	ld	s2,0(sp)
    800032e6:	6105                	addi	sp,sp,32
    800032e8:	8082                	ret

00000000800032ea <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800032ea:	1101                	addi	sp,sp,-32
    800032ec:	ec06                	sd	ra,24(sp)
    800032ee:	e822                	sd	s0,16(sp)
    800032f0:	e426                	sd	s1,8(sp)
    800032f2:	e04a                	sd	s2,0(sp)
    800032f4:	1000                	addi	s0,sp,32
    800032f6:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800032f8:	00850913          	addi	s2,a0,8
    800032fc:	854a                	mv	a0,s2
    800032fe:	63e020ef          	jal	8000593c <acquire>
  lk->locked = 0;
    80003302:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003306:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000330a:	8526                	mv	a0,s1
    8000330c:	8c6fe0ef          	jal	800013d2 <wakeup>
  release(&lk->lk);
    80003310:	854a                	mv	a0,s2
    80003312:	6be020ef          	jal	800059d0 <release>
}
    80003316:	60e2                	ld	ra,24(sp)
    80003318:	6442                	ld	s0,16(sp)
    8000331a:	64a2                	ld	s1,8(sp)
    8000331c:	6902                	ld	s2,0(sp)
    8000331e:	6105                	addi	sp,sp,32
    80003320:	8082                	ret

0000000080003322 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003322:	7179                	addi	sp,sp,-48
    80003324:	f406                	sd	ra,40(sp)
    80003326:	f022                	sd	s0,32(sp)
    80003328:	ec26                	sd	s1,24(sp)
    8000332a:	e84a                	sd	s2,16(sp)
    8000332c:	1800                	addi	s0,sp,48
    8000332e:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003330:	00850913          	addi	s2,a0,8
    80003334:	854a                	mv	a0,s2
    80003336:	606020ef          	jal	8000593c <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000333a:	409c                	lw	a5,0(s1)
    8000333c:	ef81                	bnez	a5,80003354 <holdingsleep+0x32>
    8000333e:	4481                	li	s1,0
  release(&lk->lk);
    80003340:	854a                	mv	a0,s2
    80003342:	68e020ef          	jal	800059d0 <release>
  return r;
}
    80003346:	8526                	mv	a0,s1
    80003348:	70a2                	ld	ra,40(sp)
    8000334a:	7402                	ld	s0,32(sp)
    8000334c:	64e2                	ld	s1,24(sp)
    8000334e:	6942                	ld	s2,16(sp)
    80003350:	6145                	addi	sp,sp,48
    80003352:	8082                	ret
    80003354:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003356:	0284a983          	lw	s3,40(s1)
    8000335a:	a29fd0ef          	jal	80000d82 <myproc>
    8000335e:	5904                	lw	s1,48(a0)
    80003360:	413484b3          	sub	s1,s1,s3
    80003364:	0014b493          	seqz	s1,s1
    80003368:	69a2                	ld	s3,8(sp)
    8000336a:	bfd9                	j	80003340 <holdingsleep+0x1e>

000000008000336c <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    8000336c:	1141                	addi	sp,sp,-16
    8000336e:	e406                	sd	ra,8(sp)
    80003370:	e022                	sd	s0,0(sp)
    80003372:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003374:	00004597          	auipc	a1,0x4
    80003378:	1e458593          	addi	a1,a1,484 # 80007558 <etext+0x558>
    8000337c:	00015517          	auipc	a0,0x15
    80003380:	0ec50513          	addi	a0,a0,236 # 80018468 <ftable>
    80003384:	52e020ef          	jal	800058b2 <initlock>
}
    80003388:	60a2                	ld	ra,8(sp)
    8000338a:	6402                	ld	s0,0(sp)
    8000338c:	0141                	addi	sp,sp,16
    8000338e:	8082                	ret

0000000080003390 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003390:	1101                	addi	sp,sp,-32
    80003392:	ec06                	sd	ra,24(sp)
    80003394:	e822                	sd	s0,16(sp)
    80003396:	e426                	sd	s1,8(sp)
    80003398:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    8000339a:	00015517          	auipc	a0,0x15
    8000339e:	0ce50513          	addi	a0,a0,206 # 80018468 <ftable>
    800033a2:	59a020ef          	jal	8000593c <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800033a6:	00015497          	auipc	s1,0x15
    800033aa:	0da48493          	addi	s1,s1,218 # 80018480 <ftable+0x18>
    800033ae:	00016717          	auipc	a4,0x16
    800033b2:	07270713          	addi	a4,a4,114 # 80019420 <disk>
    if(f->ref == 0){
    800033b6:	40dc                	lw	a5,4(s1)
    800033b8:	cf89                	beqz	a5,800033d2 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800033ba:	02848493          	addi	s1,s1,40
    800033be:	fee49ce3          	bne	s1,a4,800033b6 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800033c2:	00015517          	auipc	a0,0x15
    800033c6:	0a650513          	addi	a0,a0,166 # 80018468 <ftable>
    800033ca:	606020ef          	jal	800059d0 <release>
  return 0;
    800033ce:	4481                	li	s1,0
    800033d0:	a809                	j	800033e2 <filealloc+0x52>
      f->ref = 1;
    800033d2:	4785                	li	a5,1
    800033d4:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800033d6:	00015517          	auipc	a0,0x15
    800033da:	09250513          	addi	a0,a0,146 # 80018468 <ftable>
    800033de:	5f2020ef          	jal	800059d0 <release>
}
    800033e2:	8526                	mv	a0,s1
    800033e4:	60e2                	ld	ra,24(sp)
    800033e6:	6442                	ld	s0,16(sp)
    800033e8:	64a2                	ld	s1,8(sp)
    800033ea:	6105                	addi	sp,sp,32
    800033ec:	8082                	ret

00000000800033ee <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800033ee:	1101                	addi	sp,sp,-32
    800033f0:	ec06                	sd	ra,24(sp)
    800033f2:	e822                	sd	s0,16(sp)
    800033f4:	e426                	sd	s1,8(sp)
    800033f6:	1000                	addi	s0,sp,32
    800033f8:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800033fa:	00015517          	auipc	a0,0x15
    800033fe:	06e50513          	addi	a0,a0,110 # 80018468 <ftable>
    80003402:	53a020ef          	jal	8000593c <acquire>
  if(f->ref < 1)
    80003406:	40dc                	lw	a5,4(s1)
    80003408:	02f05063          	blez	a5,80003428 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000340c:	2785                	addiw	a5,a5,1
    8000340e:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003410:	00015517          	auipc	a0,0x15
    80003414:	05850513          	addi	a0,a0,88 # 80018468 <ftable>
    80003418:	5b8020ef          	jal	800059d0 <release>
  return f;
}
    8000341c:	8526                	mv	a0,s1
    8000341e:	60e2                	ld	ra,24(sp)
    80003420:	6442                	ld	s0,16(sp)
    80003422:	64a2                	ld	s1,8(sp)
    80003424:	6105                	addi	sp,sp,32
    80003426:	8082                	ret
    panic("filedup");
    80003428:	00004517          	auipc	a0,0x4
    8000342c:	13850513          	addi	a0,a0,312 # 80007560 <etext+0x560>
    80003430:	1f8020ef          	jal	80005628 <panic>

0000000080003434 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003434:	7139                	addi	sp,sp,-64
    80003436:	fc06                	sd	ra,56(sp)
    80003438:	f822                	sd	s0,48(sp)
    8000343a:	f426                	sd	s1,40(sp)
    8000343c:	0080                	addi	s0,sp,64
    8000343e:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003440:	00015517          	auipc	a0,0x15
    80003444:	02850513          	addi	a0,a0,40 # 80018468 <ftable>
    80003448:	4f4020ef          	jal	8000593c <acquire>
  if(f->ref < 1)
    8000344c:	40dc                	lw	a5,4(s1)
    8000344e:	04f05a63          	blez	a5,800034a2 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    80003452:	37fd                	addiw	a5,a5,-1
    80003454:	c0dc                	sw	a5,4(s1)
    80003456:	06f04063          	bgtz	a5,800034b6 <fileclose+0x82>
    8000345a:	f04a                	sd	s2,32(sp)
    8000345c:	ec4e                	sd	s3,24(sp)
    8000345e:	e852                	sd	s4,16(sp)
    80003460:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003462:	0004a903          	lw	s2,0(s1)
    80003466:	0094c783          	lbu	a5,9(s1)
    8000346a:	89be                	mv	s3,a5
    8000346c:	689c                	ld	a5,16(s1)
    8000346e:	8a3e                	mv	s4,a5
    80003470:	6c9c                	ld	a5,24(s1)
    80003472:	8abe                	mv	s5,a5
  f->ref = 0;
    80003474:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003478:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000347c:	00015517          	auipc	a0,0x15
    80003480:	fec50513          	addi	a0,a0,-20 # 80018468 <ftable>
    80003484:	54c020ef          	jal	800059d0 <release>

  if(ff.type == FD_PIPE){
    80003488:	4785                	li	a5,1
    8000348a:	04f90163          	beq	s2,a5,800034cc <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000348e:	ffe9079b          	addiw	a5,s2,-2
    80003492:	4705                	li	a4,1
    80003494:	04f77563          	bgeu	a4,a5,800034de <fileclose+0xaa>
    80003498:	7902                	ld	s2,32(sp)
    8000349a:	69e2                	ld	s3,24(sp)
    8000349c:	6a42                	ld	s4,16(sp)
    8000349e:	6aa2                	ld	s5,8(sp)
    800034a0:	a00d                	j	800034c2 <fileclose+0x8e>
    800034a2:	f04a                	sd	s2,32(sp)
    800034a4:	ec4e                	sd	s3,24(sp)
    800034a6:	e852                	sd	s4,16(sp)
    800034a8:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800034aa:	00004517          	auipc	a0,0x4
    800034ae:	0be50513          	addi	a0,a0,190 # 80007568 <etext+0x568>
    800034b2:	176020ef          	jal	80005628 <panic>
    release(&ftable.lock);
    800034b6:	00015517          	auipc	a0,0x15
    800034ba:	fb250513          	addi	a0,a0,-78 # 80018468 <ftable>
    800034be:	512020ef          	jal	800059d0 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800034c2:	70e2                	ld	ra,56(sp)
    800034c4:	7442                	ld	s0,48(sp)
    800034c6:	74a2                	ld	s1,40(sp)
    800034c8:	6121                	addi	sp,sp,64
    800034ca:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800034cc:	85ce                	mv	a1,s3
    800034ce:	8552                	mv	a0,s4
    800034d0:	348000ef          	jal	80003818 <pipeclose>
    800034d4:	7902                	ld	s2,32(sp)
    800034d6:	69e2                	ld	s3,24(sp)
    800034d8:	6a42                	ld	s4,16(sp)
    800034da:	6aa2                	ld	s5,8(sp)
    800034dc:	b7dd                	j	800034c2 <fileclose+0x8e>
    begin_op();
    800034de:	b25ff0ef          	jal	80003002 <begin_op>
    iput(ff.ip);
    800034e2:	8556                	mv	a0,s5
    800034e4:	be8ff0ef          	jal	800028cc <iput>
    end_op();
    800034e8:	b8bff0ef          	jal	80003072 <end_op>
    800034ec:	7902                	ld	s2,32(sp)
    800034ee:	69e2                	ld	s3,24(sp)
    800034f0:	6a42                	ld	s4,16(sp)
    800034f2:	6aa2                	ld	s5,8(sp)
    800034f4:	b7f9                	j	800034c2 <fileclose+0x8e>

00000000800034f6 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800034f6:	715d                	addi	sp,sp,-80
    800034f8:	e486                	sd	ra,72(sp)
    800034fa:	e0a2                	sd	s0,64(sp)
    800034fc:	fc26                	sd	s1,56(sp)
    800034fe:	f052                	sd	s4,32(sp)
    80003500:	0880                	addi	s0,sp,80
    80003502:	84aa                	mv	s1,a0
    80003504:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80003506:	87dfd0ef          	jal	80000d82 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    8000350a:	409c                	lw	a5,0(s1)
    8000350c:	37f9                	addiw	a5,a5,-2
    8000350e:	4705                	li	a4,1
    80003510:	04f76263          	bltu	a4,a5,80003554 <filestat+0x5e>
    80003514:	f84a                	sd	s2,48(sp)
    80003516:	f44e                	sd	s3,40(sp)
    80003518:	89aa                	mv	s3,a0
    ilock(f->ip);
    8000351a:	6c88                	ld	a0,24(s1)
    8000351c:	a2eff0ef          	jal	8000274a <ilock>
    stati(f->ip, &st);
    80003520:	fb840913          	addi	s2,s0,-72
    80003524:	85ca                	mv	a1,s2
    80003526:	6c88                	ld	a0,24(s1)
    80003528:	c4eff0ef          	jal	80002976 <stati>
    iunlock(f->ip);
    8000352c:	6c88                	ld	a0,24(s1)
    8000352e:	acaff0ef          	jal	800027f8 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003532:	46e1                	li	a3,24
    80003534:	864a                	mv	a2,s2
    80003536:	85d2                	mv	a1,s4
    80003538:	0509b503          	ld	a0,80(s3)
    8000353c:	cc6fd0ef          	jal	80000a02 <copyout>
    80003540:	41f5551b          	sraiw	a0,a0,0x1f
    80003544:	7942                	ld	s2,48(sp)
    80003546:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80003548:	60a6                	ld	ra,72(sp)
    8000354a:	6406                	ld	s0,64(sp)
    8000354c:	74e2                	ld	s1,56(sp)
    8000354e:	7a02                	ld	s4,32(sp)
    80003550:	6161                	addi	sp,sp,80
    80003552:	8082                	ret
  return -1;
    80003554:	557d                	li	a0,-1
    80003556:	bfcd                	j	80003548 <filestat+0x52>

0000000080003558 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003558:	7179                	addi	sp,sp,-48
    8000355a:	f406                	sd	ra,40(sp)
    8000355c:	f022                	sd	s0,32(sp)
    8000355e:	e84a                	sd	s2,16(sp)
    80003560:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003562:	00854783          	lbu	a5,8(a0)
    80003566:	cfd1                	beqz	a5,80003602 <fileread+0xaa>
    80003568:	ec26                	sd	s1,24(sp)
    8000356a:	e44e                	sd	s3,8(sp)
    8000356c:	84aa                	mv	s1,a0
    8000356e:	892e                	mv	s2,a1
    80003570:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    80003572:	411c                	lw	a5,0(a0)
    80003574:	4705                	li	a4,1
    80003576:	04e78363          	beq	a5,a4,800035bc <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000357a:	470d                	li	a4,3
    8000357c:	04e78763          	beq	a5,a4,800035ca <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80003580:	4709                	li	a4,2
    80003582:	06e79a63          	bne	a5,a4,800035f6 <fileread+0x9e>
    ilock(f->ip);
    80003586:	6d08                	ld	a0,24(a0)
    80003588:	9c2ff0ef          	jal	8000274a <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000358c:	874e                	mv	a4,s3
    8000358e:	5094                	lw	a3,32(s1)
    80003590:	864a                	mv	a2,s2
    80003592:	4585                	li	a1,1
    80003594:	6c88                	ld	a0,24(s1)
    80003596:	c0eff0ef          	jal	800029a4 <readi>
    8000359a:	892a                	mv	s2,a0
    8000359c:	00a05563          	blez	a0,800035a6 <fileread+0x4e>
      f->off += r;
    800035a0:	509c                	lw	a5,32(s1)
    800035a2:	9fa9                	addw	a5,a5,a0
    800035a4:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800035a6:	6c88                	ld	a0,24(s1)
    800035a8:	a50ff0ef          	jal	800027f8 <iunlock>
    800035ac:	64e2                	ld	s1,24(sp)
    800035ae:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800035b0:	854a                	mv	a0,s2
    800035b2:	70a2                	ld	ra,40(sp)
    800035b4:	7402                	ld	s0,32(sp)
    800035b6:	6942                	ld	s2,16(sp)
    800035b8:	6145                	addi	sp,sp,48
    800035ba:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800035bc:	6908                	ld	a0,16(a0)
    800035be:	3b0000ef          	jal	8000396e <piperead>
    800035c2:	892a                	mv	s2,a0
    800035c4:	64e2                	ld	s1,24(sp)
    800035c6:	69a2                	ld	s3,8(sp)
    800035c8:	b7e5                	j	800035b0 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800035ca:	02451783          	lh	a5,36(a0)
    800035ce:	03079693          	slli	a3,a5,0x30
    800035d2:	92c1                	srli	a3,a3,0x30
    800035d4:	4725                	li	a4,9
    800035d6:	02d76963          	bltu	a4,a3,80003608 <fileread+0xb0>
    800035da:	0792                	slli	a5,a5,0x4
    800035dc:	00015717          	auipc	a4,0x15
    800035e0:	dec70713          	addi	a4,a4,-532 # 800183c8 <devsw>
    800035e4:	97ba                	add	a5,a5,a4
    800035e6:	639c                	ld	a5,0(a5)
    800035e8:	c78d                	beqz	a5,80003612 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    800035ea:	4505                	li	a0,1
    800035ec:	9782                	jalr	a5
    800035ee:	892a                	mv	s2,a0
    800035f0:	64e2                	ld	s1,24(sp)
    800035f2:	69a2                	ld	s3,8(sp)
    800035f4:	bf75                	j	800035b0 <fileread+0x58>
    panic("fileread");
    800035f6:	00004517          	auipc	a0,0x4
    800035fa:	f8250513          	addi	a0,a0,-126 # 80007578 <etext+0x578>
    800035fe:	02a020ef          	jal	80005628 <panic>
    return -1;
    80003602:	57fd                	li	a5,-1
    80003604:	893e                	mv	s2,a5
    80003606:	b76d                	j	800035b0 <fileread+0x58>
      return -1;
    80003608:	57fd                	li	a5,-1
    8000360a:	893e                	mv	s2,a5
    8000360c:	64e2                	ld	s1,24(sp)
    8000360e:	69a2                	ld	s3,8(sp)
    80003610:	b745                	j	800035b0 <fileread+0x58>
    80003612:	57fd                	li	a5,-1
    80003614:	893e                	mv	s2,a5
    80003616:	64e2                	ld	s1,24(sp)
    80003618:	69a2                	ld	s3,8(sp)
    8000361a:	bf59                	j	800035b0 <fileread+0x58>

000000008000361c <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    8000361c:	00954783          	lbu	a5,9(a0)
    80003620:	10078f63          	beqz	a5,8000373e <filewrite+0x122>
{
    80003624:	711d                	addi	sp,sp,-96
    80003626:	ec86                	sd	ra,88(sp)
    80003628:	e8a2                	sd	s0,80(sp)
    8000362a:	e0ca                	sd	s2,64(sp)
    8000362c:	f456                	sd	s5,40(sp)
    8000362e:	f05a                	sd	s6,32(sp)
    80003630:	1080                	addi	s0,sp,96
    80003632:	892a                	mv	s2,a0
    80003634:	8b2e                	mv	s6,a1
    80003636:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    80003638:	411c                	lw	a5,0(a0)
    8000363a:	4705                	li	a4,1
    8000363c:	02e78a63          	beq	a5,a4,80003670 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003640:	470d                	li	a4,3
    80003642:	02e78b63          	beq	a5,a4,80003678 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80003646:	4709                	li	a4,2
    80003648:	0ce79f63          	bne	a5,a4,80003726 <filewrite+0x10a>
    8000364c:	f852                	sd	s4,48(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    8000364e:	0ac05a63          	blez	a2,80003702 <filewrite+0xe6>
    80003652:	e4a6                	sd	s1,72(sp)
    80003654:	fc4e                	sd	s3,56(sp)
    80003656:	ec5e                	sd	s7,24(sp)
    80003658:	e862                	sd	s8,16(sp)
    8000365a:	e466                	sd	s9,8(sp)
    int i = 0;
    8000365c:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    8000365e:	6b85                	lui	s7,0x1
    80003660:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80003664:	6785                	lui	a5,0x1
    80003666:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    8000366a:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000366c:	4c05                	li	s8,1
    8000366e:	a8ad                	j	800036e8 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80003670:	6908                	ld	a0,16(a0)
    80003672:	204000ef          	jal	80003876 <pipewrite>
    80003676:	a04d                	j	80003718 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80003678:	02451783          	lh	a5,36(a0)
    8000367c:	03079693          	slli	a3,a5,0x30
    80003680:	92c1                	srli	a3,a3,0x30
    80003682:	4725                	li	a4,9
    80003684:	0ad76f63          	bltu	a4,a3,80003742 <filewrite+0x126>
    80003688:	0792                	slli	a5,a5,0x4
    8000368a:	00015717          	auipc	a4,0x15
    8000368e:	d3e70713          	addi	a4,a4,-706 # 800183c8 <devsw>
    80003692:	97ba                	add	a5,a5,a4
    80003694:	679c                	ld	a5,8(a5)
    80003696:	cbc5                	beqz	a5,80003746 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    80003698:	4505                	li	a0,1
    8000369a:	9782                	jalr	a5
    8000369c:	a8b5                	j	80003718 <filewrite+0xfc>
      if(n1 > max)
    8000369e:	2981                	sext.w	s3,s3
      begin_op();
    800036a0:	963ff0ef          	jal	80003002 <begin_op>
      ilock(f->ip);
    800036a4:	01893503          	ld	a0,24(s2)
    800036a8:	8a2ff0ef          	jal	8000274a <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800036ac:	874e                	mv	a4,s3
    800036ae:	02092683          	lw	a3,32(s2)
    800036b2:	016a0633          	add	a2,s4,s6
    800036b6:	85e2                	mv	a1,s8
    800036b8:	01893503          	ld	a0,24(s2)
    800036bc:	bdaff0ef          	jal	80002a96 <writei>
    800036c0:	84aa                	mv	s1,a0
    800036c2:	00a05763          	blez	a0,800036d0 <filewrite+0xb4>
        f->off += r;
    800036c6:	02092783          	lw	a5,32(s2)
    800036ca:	9fa9                	addw	a5,a5,a0
    800036cc:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800036d0:	01893503          	ld	a0,24(s2)
    800036d4:	924ff0ef          	jal	800027f8 <iunlock>
      end_op();
    800036d8:	99bff0ef          	jal	80003072 <end_op>

      if(r != n1){
    800036dc:	02999563          	bne	s3,s1,80003706 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    800036e0:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    800036e4:	015a5963          	bge	s4,s5,800036f6 <filewrite+0xda>
      int n1 = n - i;
    800036e8:	414a87bb          	subw	a5,s5,s4
    800036ec:	89be                	mv	s3,a5
      if(n1 > max)
    800036ee:	fafbd8e3          	bge	s7,a5,8000369e <filewrite+0x82>
    800036f2:	89e6                	mv	s3,s9
    800036f4:	b76d                	j	8000369e <filewrite+0x82>
    800036f6:	64a6                	ld	s1,72(sp)
    800036f8:	79e2                	ld	s3,56(sp)
    800036fa:	6be2                	ld	s7,24(sp)
    800036fc:	6c42                	ld	s8,16(sp)
    800036fe:	6ca2                	ld	s9,8(sp)
    80003700:	a801                	j	80003710 <filewrite+0xf4>
    int i = 0;
    80003702:	4a01                	li	s4,0
    80003704:	a031                	j	80003710 <filewrite+0xf4>
    80003706:	64a6                	ld	s1,72(sp)
    80003708:	79e2                	ld	s3,56(sp)
    8000370a:	6be2                	ld	s7,24(sp)
    8000370c:	6c42                	ld	s8,16(sp)
    8000370e:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    80003710:	034a9d63          	bne	s5,s4,8000374a <filewrite+0x12e>
    80003714:	8556                	mv	a0,s5
    80003716:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80003718:	60e6                	ld	ra,88(sp)
    8000371a:	6446                	ld	s0,80(sp)
    8000371c:	6906                	ld	s2,64(sp)
    8000371e:	7aa2                	ld	s5,40(sp)
    80003720:	7b02                	ld	s6,32(sp)
    80003722:	6125                	addi	sp,sp,96
    80003724:	8082                	ret
    80003726:	e4a6                	sd	s1,72(sp)
    80003728:	fc4e                	sd	s3,56(sp)
    8000372a:	f852                	sd	s4,48(sp)
    8000372c:	ec5e                	sd	s7,24(sp)
    8000372e:	e862                	sd	s8,16(sp)
    80003730:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80003732:	00004517          	auipc	a0,0x4
    80003736:	e5650513          	addi	a0,a0,-426 # 80007588 <etext+0x588>
    8000373a:	6ef010ef          	jal	80005628 <panic>
    return -1;
    8000373e:	557d                	li	a0,-1
}
    80003740:	8082                	ret
      return -1;
    80003742:	557d                	li	a0,-1
    80003744:	bfd1                	j	80003718 <filewrite+0xfc>
    80003746:	557d                	li	a0,-1
    80003748:	bfc1                	j	80003718 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    8000374a:	557d                	li	a0,-1
    8000374c:	7a42                	ld	s4,48(sp)
    8000374e:	b7e9                	j	80003718 <filewrite+0xfc>

0000000080003750 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80003750:	7179                	addi	sp,sp,-48
    80003752:	f406                	sd	ra,40(sp)
    80003754:	f022                	sd	s0,32(sp)
    80003756:	ec26                	sd	s1,24(sp)
    80003758:	e052                	sd	s4,0(sp)
    8000375a:	1800                	addi	s0,sp,48
    8000375c:	84aa                	mv	s1,a0
    8000375e:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80003760:	0005b023          	sd	zero,0(a1)
    80003764:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80003768:	c29ff0ef          	jal	80003390 <filealloc>
    8000376c:	e088                	sd	a0,0(s1)
    8000376e:	c549                	beqz	a0,800037f8 <pipealloc+0xa8>
    80003770:	c21ff0ef          	jal	80003390 <filealloc>
    80003774:	00aa3023          	sd	a0,0(s4)
    80003778:	cd25                	beqz	a0,800037f0 <pipealloc+0xa0>
    8000377a:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    8000377c:	989fc0ef          	jal	80000104 <kalloc>
    80003780:	892a                	mv	s2,a0
    80003782:	c12d                	beqz	a0,800037e4 <pipealloc+0x94>
    80003784:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80003786:	4985                	li	s3,1
    80003788:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000378c:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80003790:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80003794:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80003798:	00004597          	auipc	a1,0x4
    8000379c:	e0058593          	addi	a1,a1,-512 # 80007598 <etext+0x598>
    800037a0:	112020ef          	jal	800058b2 <initlock>
  (*f0)->type = FD_PIPE;
    800037a4:	609c                	ld	a5,0(s1)
    800037a6:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800037aa:	609c                	ld	a5,0(s1)
    800037ac:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800037b0:	609c                	ld	a5,0(s1)
    800037b2:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800037b6:	609c                	ld	a5,0(s1)
    800037b8:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800037bc:	000a3783          	ld	a5,0(s4)
    800037c0:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800037c4:	000a3783          	ld	a5,0(s4)
    800037c8:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800037cc:	000a3783          	ld	a5,0(s4)
    800037d0:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800037d4:	000a3783          	ld	a5,0(s4)
    800037d8:	0127b823          	sd	s2,16(a5)
  return 0;
    800037dc:	4501                	li	a0,0
    800037de:	6942                	ld	s2,16(sp)
    800037e0:	69a2                	ld	s3,8(sp)
    800037e2:	a01d                	j	80003808 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    800037e4:	6088                	ld	a0,0(s1)
    800037e6:	c119                	beqz	a0,800037ec <pipealloc+0x9c>
    800037e8:	6942                	ld	s2,16(sp)
    800037ea:	a029                	j	800037f4 <pipealloc+0xa4>
    800037ec:	6942                	ld	s2,16(sp)
    800037ee:	a029                	j	800037f8 <pipealloc+0xa8>
    800037f0:	6088                	ld	a0,0(s1)
    800037f2:	c10d                	beqz	a0,80003814 <pipealloc+0xc4>
    fileclose(*f0);
    800037f4:	c41ff0ef          	jal	80003434 <fileclose>
  if(*f1)
    800037f8:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800037fc:	557d                	li	a0,-1
  if(*f1)
    800037fe:	c789                	beqz	a5,80003808 <pipealloc+0xb8>
    fileclose(*f1);
    80003800:	853e                	mv	a0,a5
    80003802:	c33ff0ef          	jal	80003434 <fileclose>
  return -1;
    80003806:	557d                	li	a0,-1
}
    80003808:	70a2                	ld	ra,40(sp)
    8000380a:	7402                	ld	s0,32(sp)
    8000380c:	64e2                	ld	s1,24(sp)
    8000380e:	6a02                	ld	s4,0(sp)
    80003810:	6145                	addi	sp,sp,48
    80003812:	8082                	ret
  return -1;
    80003814:	557d                	li	a0,-1
    80003816:	bfcd                	j	80003808 <pipealloc+0xb8>

0000000080003818 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80003818:	1101                	addi	sp,sp,-32
    8000381a:	ec06                	sd	ra,24(sp)
    8000381c:	e822                	sd	s0,16(sp)
    8000381e:	e426                	sd	s1,8(sp)
    80003820:	e04a                	sd	s2,0(sp)
    80003822:	1000                	addi	s0,sp,32
    80003824:	84aa                	mv	s1,a0
    80003826:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80003828:	114020ef          	jal	8000593c <acquire>
  if(writable){
    8000382c:	02090763          	beqz	s2,8000385a <pipeclose+0x42>
    pi->writeopen = 0;
    80003830:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80003834:	21848513          	addi	a0,s1,536
    80003838:	b9bfd0ef          	jal	800013d2 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    8000383c:	2204a783          	lw	a5,544(s1)
    80003840:	e781                	bnez	a5,80003848 <pipeclose+0x30>
    80003842:	2244a783          	lw	a5,548(s1)
    80003846:	c38d                	beqz	a5,80003868 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    80003848:	8526                	mv	a0,s1
    8000384a:	186020ef          	jal	800059d0 <release>
}
    8000384e:	60e2                	ld	ra,24(sp)
    80003850:	6442                	ld	s0,16(sp)
    80003852:	64a2                	ld	s1,8(sp)
    80003854:	6902                	ld	s2,0(sp)
    80003856:	6105                	addi	sp,sp,32
    80003858:	8082                	ret
    pi->readopen = 0;
    8000385a:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    8000385e:	21c48513          	addi	a0,s1,540
    80003862:	b71fd0ef          	jal	800013d2 <wakeup>
    80003866:	bfd9                	j	8000383c <pipeclose+0x24>
    release(&pi->lock);
    80003868:	8526                	mv	a0,s1
    8000386a:	166020ef          	jal	800059d0 <release>
    kfree((char*)pi);
    8000386e:	8526                	mv	a0,s1
    80003870:	facfc0ef          	jal	8000001c <kfree>
    80003874:	bfe9                	j	8000384e <pipeclose+0x36>

0000000080003876 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80003876:	7159                	addi	sp,sp,-112
    80003878:	f486                	sd	ra,104(sp)
    8000387a:	f0a2                	sd	s0,96(sp)
    8000387c:	eca6                	sd	s1,88(sp)
    8000387e:	e8ca                	sd	s2,80(sp)
    80003880:	e4ce                	sd	s3,72(sp)
    80003882:	e0d2                	sd	s4,64(sp)
    80003884:	fc56                	sd	s5,56(sp)
    80003886:	1880                	addi	s0,sp,112
    80003888:	84aa                	mv	s1,a0
    8000388a:	8aae                	mv	s5,a1
    8000388c:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000388e:	cf4fd0ef          	jal	80000d82 <myproc>
    80003892:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80003894:	8526                	mv	a0,s1
    80003896:	0a6020ef          	jal	8000593c <acquire>
  while(i < n){
    8000389a:	0d405263          	blez	s4,8000395e <pipewrite+0xe8>
    8000389e:	f85a                	sd	s6,48(sp)
    800038a0:	f45e                	sd	s7,40(sp)
    800038a2:	f062                	sd	s8,32(sp)
    800038a4:	ec66                	sd	s9,24(sp)
    800038a6:	e86a                	sd	s10,16(sp)
  int i = 0;
    800038a8:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800038aa:	f9f40c13          	addi	s8,s0,-97
    800038ae:	4b85                	li	s7,1
    800038b0:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800038b2:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    800038b6:	21c48c93          	addi	s9,s1,540
    800038ba:	a82d                	j	800038f4 <pipewrite+0x7e>
      release(&pi->lock);
    800038bc:	8526                	mv	a0,s1
    800038be:	112020ef          	jal	800059d0 <release>
      return -1;
    800038c2:	597d                	li	s2,-1
    800038c4:	7b42                	ld	s6,48(sp)
    800038c6:	7ba2                	ld	s7,40(sp)
    800038c8:	7c02                	ld	s8,32(sp)
    800038ca:	6ce2                	ld	s9,24(sp)
    800038cc:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800038ce:	854a                	mv	a0,s2
    800038d0:	70a6                	ld	ra,104(sp)
    800038d2:	7406                	ld	s0,96(sp)
    800038d4:	64e6                	ld	s1,88(sp)
    800038d6:	6946                	ld	s2,80(sp)
    800038d8:	69a6                	ld	s3,72(sp)
    800038da:	6a06                	ld	s4,64(sp)
    800038dc:	7ae2                	ld	s5,56(sp)
    800038de:	6165                	addi	sp,sp,112
    800038e0:	8082                	ret
      wakeup(&pi->nread);
    800038e2:	856a                	mv	a0,s10
    800038e4:	aeffd0ef          	jal	800013d2 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    800038e8:	85a6                	mv	a1,s1
    800038ea:	8566                	mv	a0,s9
    800038ec:	a9bfd0ef          	jal	80001386 <sleep>
  while(i < n){
    800038f0:	05495a63          	bge	s2,s4,80003944 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    800038f4:	2204a783          	lw	a5,544(s1)
    800038f8:	d3f1                	beqz	a5,800038bc <pipewrite+0x46>
    800038fa:	854e                	mv	a0,s3
    800038fc:	cc7fd0ef          	jal	800015c2 <killed>
    80003900:	fd55                	bnez	a0,800038bc <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80003902:	2184a783          	lw	a5,536(s1)
    80003906:	21c4a703          	lw	a4,540(s1)
    8000390a:	2007879b          	addiw	a5,a5,512
    8000390e:	fcf70ae3          	beq	a4,a5,800038e2 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003912:	86de                	mv	a3,s7
    80003914:	01590633          	add	a2,s2,s5
    80003918:	85e2                	mv	a1,s8
    8000391a:	0509b503          	ld	a0,80(s3)
    8000391e:	994fd0ef          	jal	80000ab2 <copyin>
    80003922:	05650063          	beq	a0,s6,80003962 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80003926:	21c4a783          	lw	a5,540(s1)
    8000392a:	0017871b          	addiw	a4,a5,1
    8000392e:	20e4ae23          	sw	a4,540(s1)
    80003932:	1ff7f793          	andi	a5,a5,511
    80003936:	97a6                	add	a5,a5,s1
    80003938:	f9f44703          	lbu	a4,-97(s0)
    8000393c:	00e78c23          	sb	a4,24(a5)
      i++;
    80003940:	2905                	addiw	s2,s2,1
    80003942:	b77d                	j	800038f0 <pipewrite+0x7a>
    80003944:	7b42                	ld	s6,48(sp)
    80003946:	7ba2                	ld	s7,40(sp)
    80003948:	7c02                	ld	s8,32(sp)
    8000394a:	6ce2                	ld	s9,24(sp)
    8000394c:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    8000394e:	21848513          	addi	a0,s1,536
    80003952:	a81fd0ef          	jal	800013d2 <wakeup>
  release(&pi->lock);
    80003956:	8526                	mv	a0,s1
    80003958:	078020ef          	jal	800059d0 <release>
  return i;
    8000395c:	bf8d                	j	800038ce <pipewrite+0x58>
  int i = 0;
    8000395e:	4901                	li	s2,0
    80003960:	b7fd                	j	8000394e <pipewrite+0xd8>
    80003962:	7b42                	ld	s6,48(sp)
    80003964:	7ba2                	ld	s7,40(sp)
    80003966:	7c02                	ld	s8,32(sp)
    80003968:	6ce2                	ld	s9,24(sp)
    8000396a:	6d42                	ld	s10,16(sp)
    8000396c:	b7cd                	j	8000394e <pipewrite+0xd8>

000000008000396e <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    8000396e:	711d                	addi	sp,sp,-96
    80003970:	ec86                	sd	ra,88(sp)
    80003972:	e8a2                	sd	s0,80(sp)
    80003974:	e4a6                	sd	s1,72(sp)
    80003976:	e0ca                	sd	s2,64(sp)
    80003978:	fc4e                	sd	s3,56(sp)
    8000397a:	f852                	sd	s4,48(sp)
    8000397c:	f456                	sd	s5,40(sp)
    8000397e:	1080                	addi	s0,sp,96
    80003980:	84aa                	mv	s1,a0
    80003982:	892e                	mv	s2,a1
    80003984:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80003986:	bfcfd0ef          	jal	80000d82 <myproc>
    8000398a:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    8000398c:	8526                	mv	a0,s1
    8000398e:	7af010ef          	jal	8000593c <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003992:	2184a703          	lw	a4,536(s1)
    80003996:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000399a:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000399e:	02f71763          	bne	a4,a5,800039cc <piperead+0x5e>
    800039a2:	2244a783          	lw	a5,548(s1)
    800039a6:	cf85                	beqz	a5,800039de <piperead+0x70>
    if(killed(pr)){
    800039a8:	8552                	mv	a0,s4
    800039aa:	c19fd0ef          	jal	800015c2 <killed>
    800039ae:	e11d                	bnez	a0,800039d4 <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800039b0:	85a6                	mv	a1,s1
    800039b2:	854e                	mv	a0,s3
    800039b4:	9d3fd0ef          	jal	80001386 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800039b8:	2184a703          	lw	a4,536(s1)
    800039bc:	21c4a783          	lw	a5,540(s1)
    800039c0:	fef701e3          	beq	a4,a5,800039a2 <piperead+0x34>
    800039c4:	f05a                	sd	s6,32(sp)
    800039c6:	ec5e                	sd	s7,24(sp)
    800039c8:	e862                	sd	s8,16(sp)
    800039ca:	a829                	j	800039e4 <piperead+0x76>
    800039cc:	f05a                	sd	s6,32(sp)
    800039ce:	ec5e                	sd	s7,24(sp)
    800039d0:	e862                	sd	s8,16(sp)
    800039d2:	a809                	j	800039e4 <piperead+0x76>
      release(&pi->lock);
    800039d4:	8526                	mv	a0,s1
    800039d6:	7fb010ef          	jal	800059d0 <release>
      return -1;
    800039da:	59fd                	li	s3,-1
    800039dc:	a09d                	j	80003a42 <piperead+0xd4>
    800039de:	f05a                	sd	s6,32(sp)
    800039e0:	ec5e                	sd	s7,24(sp)
    800039e2:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800039e4:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    800039e6:	faf40c13          	addi	s8,s0,-81
    800039ea:	4b85                	li	s7,1
    800039ec:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800039ee:	05505063          	blez	s5,80003a2e <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    800039f2:	2184a783          	lw	a5,536(s1)
    800039f6:	21c4a703          	lw	a4,540(s1)
    800039fa:	02f70a63          	beq	a4,a5,80003a2e <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    800039fe:	0017871b          	addiw	a4,a5,1
    80003a02:	20e4ac23          	sw	a4,536(s1)
    80003a06:	1ff7f793          	andi	a5,a5,511
    80003a0a:	97a6                	add	a5,a5,s1
    80003a0c:	0187c783          	lbu	a5,24(a5)
    80003a10:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003a14:	86de                	mv	a3,s7
    80003a16:	8662                	mv	a2,s8
    80003a18:	85ca                	mv	a1,s2
    80003a1a:	050a3503          	ld	a0,80(s4)
    80003a1e:	fe5fc0ef          	jal	80000a02 <copyout>
    80003a22:	01650663          	beq	a0,s6,80003a2e <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a26:	2985                	addiw	s3,s3,1
    80003a28:	0905                	addi	s2,s2,1
    80003a2a:	fd3a94e3          	bne	s5,s3,800039f2 <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003a2e:	21c48513          	addi	a0,s1,540
    80003a32:	9a1fd0ef          	jal	800013d2 <wakeup>
  release(&pi->lock);
    80003a36:	8526                	mv	a0,s1
    80003a38:	799010ef          	jal	800059d0 <release>
    80003a3c:	7b02                	ld	s6,32(sp)
    80003a3e:	6be2                	ld	s7,24(sp)
    80003a40:	6c42                	ld	s8,16(sp)
  return i;
}
    80003a42:	854e                	mv	a0,s3
    80003a44:	60e6                	ld	ra,88(sp)
    80003a46:	6446                	ld	s0,80(sp)
    80003a48:	64a6                	ld	s1,72(sp)
    80003a4a:	6906                	ld	s2,64(sp)
    80003a4c:	79e2                	ld	s3,56(sp)
    80003a4e:	7a42                	ld	s4,48(sp)
    80003a50:	7aa2                	ld	s5,40(sp)
    80003a52:	6125                	addi	sp,sp,96
    80003a54:	8082                	ret

0000000080003a56 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003a56:	1141                	addi	sp,sp,-16
    80003a58:	e406                	sd	ra,8(sp)
    80003a5a:	e022                	sd	s0,0(sp)
    80003a5c:	0800                	addi	s0,sp,16
    80003a5e:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003a60:	0035151b          	slliw	a0,a0,0x3
    80003a64:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80003a66:	8b89                	andi	a5,a5,2
    80003a68:	c399                	beqz	a5,80003a6e <flags2perm+0x18>
      perm |= PTE_W;
    80003a6a:	00456513          	ori	a0,a0,4
    return perm;
}
    80003a6e:	60a2                	ld	ra,8(sp)
    80003a70:	6402                	ld	s0,0(sp)
    80003a72:	0141                	addi	sp,sp,16
    80003a74:	8082                	ret

0000000080003a76 <exec>:

int
exec(char *path, char **argv)
{
    80003a76:	de010113          	addi	sp,sp,-544
    80003a7a:	20113c23          	sd	ra,536(sp)
    80003a7e:	20813823          	sd	s0,528(sp)
    80003a82:	20913423          	sd	s1,520(sp)
    80003a86:	21213023          	sd	s2,512(sp)
    80003a8a:	1400                	addi	s0,sp,544
    80003a8c:	892a                	mv	s2,a0
    80003a8e:	dea43823          	sd	a0,-528(s0)
    80003a92:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80003a96:	aecfd0ef          	jal	80000d82 <myproc>
    80003a9a:	84aa                	mv	s1,a0

  begin_op();
    80003a9c:	d66ff0ef          	jal	80003002 <begin_op>

  if((ip = namei(path)) == 0){
    80003aa0:	854a                	mv	a0,s2
    80003aa2:	b9eff0ef          	jal	80002e40 <namei>
    80003aa6:	cd21                	beqz	a0,80003afe <exec+0x88>
    80003aa8:	fbd2                	sd	s4,496(sp)
    80003aaa:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80003aac:	c9ffe0ef          	jal	8000274a <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80003ab0:	04000713          	li	a4,64
    80003ab4:	4681                	li	a3,0
    80003ab6:	e5040613          	addi	a2,s0,-432
    80003aba:	4581                	li	a1,0
    80003abc:	8552                	mv	a0,s4
    80003abe:	ee7fe0ef          	jal	800029a4 <readi>
    80003ac2:	04000793          	li	a5,64
    80003ac6:	00f51a63          	bne	a0,a5,80003ada <exec+0x64>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80003aca:	e5042703          	lw	a4,-432(s0)
    80003ace:	464c47b7          	lui	a5,0x464c4
    80003ad2:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003ad6:	02f70863          	beq	a4,a5,80003b06 <exec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003ada:	8552                	mv	a0,s4
    80003adc:	e7bfe0ef          	jal	80002956 <iunlockput>
    end_op();
    80003ae0:	d92ff0ef          	jal	80003072 <end_op>
  }
  return -1;
    80003ae4:	557d                	li	a0,-1
    80003ae6:	7a5e                	ld	s4,496(sp)
}
    80003ae8:	21813083          	ld	ra,536(sp)
    80003aec:	21013403          	ld	s0,528(sp)
    80003af0:	20813483          	ld	s1,520(sp)
    80003af4:	20013903          	ld	s2,512(sp)
    80003af8:	22010113          	addi	sp,sp,544
    80003afc:	8082                	ret
    end_op();
    80003afe:	d74ff0ef          	jal	80003072 <end_op>
    return -1;
    80003b02:	557d                	li	a0,-1
    80003b04:	b7d5                	j	80003ae8 <exec+0x72>
    80003b06:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80003b08:	8526                	mv	a0,s1
    80003b0a:	b22fd0ef          	jal	80000e2c <proc_pagetable>
    80003b0e:	8b2a                	mv	s6,a0
    80003b10:	26050f63          	beqz	a0,80003d8e <exec+0x318>
    80003b14:	ffce                	sd	s3,504(sp)
    80003b16:	f7d6                	sd	s5,488(sp)
    80003b18:	efde                	sd	s7,472(sp)
    80003b1a:	ebe2                	sd	s8,464(sp)
    80003b1c:	e7e6                	sd	s9,456(sp)
    80003b1e:	e3ea                	sd	s10,448(sp)
    80003b20:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003b22:	e8845783          	lhu	a5,-376(s0)
    80003b26:	0e078963          	beqz	a5,80003c18 <exec+0x1a2>
    80003b2a:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003b2e:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003b30:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003b32:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80003b36:	6c85                	lui	s9,0x1
    80003b38:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80003b3c:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80003b40:	6a85                	lui	s5,0x1
    80003b42:	a085                	j	80003ba2 <exec+0x12c>
      panic("loadseg: address should exist");
    80003b44:	00004517          	auipc	a0,0x4
    80003b48:	a5c50513          	addi	a0,a0,-1444 # 800075a0 <etext+0x5a0>
    80003b4c:	2dd010ef          	jal	80005628 <panic>
    if(sz - i < PGSIZE)
    80003b50:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003b52:	874a                	mv	a4,s2
    80003b54:	009b86bb          	addw	a3,s7,s1
    80003b58:	4581                	li	a1,0
    80003b5a:	8552                	mv	a0,s4
    80003b5c:	e49fe0ef          	jal	800029a4 <readi>
    80003b60:	22a91b63          	bne	s2,a0,80003d96 <exec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    80003b64:	009a84bb          	addw	s1,s5,s1
    80003b68:	0334f263          	bgeu	s1,s3,80003b8c <exec+0x116>
    pa = walkaddr(pagetable, va + i);
    80003b6c:	02049593          	slli	a1,s1,0x20
    80003b70:	9181                	srli	a1,a1,0x20
    80003b72:	95e2                	add	a1,a1,s8
    80003b74:	855a                	mv	a0,s6
    80003b76:	917fc0ef          	jal	8000048c <walkaddr>
    80003b7a:	862a                	mv	a2,a0
    if(pa == 0)
    80003b7c:	d561                	beqz	a0,80003b44 <exec+0xce>
    if(sz - i < PGSIZE)
    80003b7e:	409987bb          	subw	a5,s3,s1
    80003b82:	893e                	mv	s2,a5
    80003b84:	fcfcf6e3          	bgeu	s9,a5,80003b50 <exec+0xda>
    80003b88:	8956                	mv	s2,s5
    80003b8a:	b7d9                	j	80003b50 <exec+0xda>
    sz = sz1;
    80003b8c:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003b90:	2d05                	addiw	s10,s10,1
    80003b92:	e0843783          	ld	a5,-504(s0)
    80003b96:	0387869b          	addiw	a3,a5,56
    80003b9a:	e8845783          	lhu	a5,-376(s0)
    80003b9e:	06fd5e63          	bge	s10,a5,80003c1a <exec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003ba2:	e0d43423          	sd	a3,-504(s0)
    80003ba6:	876e                	mv	a4,s11
    80003ba8:	e1840613          	addi	a2,s0,-488
    80003bac:	4581                	li	a1,0
    80003bae:	8552                	mv	a0,s4
    80003bb0:	df5fe0ef          	jal	800029a4 <readi>
    80003bb4:	1db51f63          	bne	a0,s11,80003d92 <exec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80003bb8:	e1842783          	lw	a5,-488(s0)
    80003bbc:	4705                	li	a4,1
    80003bbe:	fce799e3          	bne	a5,a4,80003b90 <exec+0x11a>
    if(ph.memsz < ph.filesz)
    80003bc2:	e4043483          	ld	s1,-448(s0)
    80003bc6:	e3843783          	ld	a5,-456(s0)
    80003bca:	1ef4e463          	bltu	s1,a5,80003db2 <exec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003bce:	e2843783          	ld	a5,-472(s0)
    80003bd2:	94be                	add	s1,s1,a5
    80003bd4:	1ef4e263          	bltu	s1,a5,80003db8 <exec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80003bd8:	de843703          	ld	a4,-536(s0)
    80003bdc:	8ff9                	and	a5,a5,a4
    80003bde:	1e079063          	bnez	a5,80003dbe <exec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003be2:	e1c42503          	lw	a0,-484(s0)
    80003be6:	e71ff0ef          	jal	80003a56 <flags2perm>
    80003bea:	86aa                	mv	a3,a0
    80003bec:	8626                	mv	a2,s1
    80003bee:	85ca                	mv	a1,s2
    80003bf0:	855a                	mv	a0,s6
    80003bf2:	c01fc0ef          	jal	800007f2 <uvmalloc>
    80003bf6:	dea43c23          	sd	a0,-520(s0)
    80003bfa:	1c050563          	beqz	a0,80003dc4 <exec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003bfe:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003c02:	00098863          	beqz	s3,80003c12 <exec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003c06:	e2843c03          	ld	s8,-472(s0)
    80003c0a:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003c0e:	4481                	li	s1,0
    80003c10:	bfb1                	j	80003b6c <exec+0xf6>
    sz = sz1;
    80003c12:	df843903          	ld	s2,-520(s0)
    80003c16:	bfad                	j	80003b90 <exec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003c18:	4901                	li	s2,0
  iunlockput(ip);
    80003c1a:	8552                	mv	a0,s4
    80003c1c:	d3bfe0ef          	jal	80002956 <iunlockput>
  end_op();
    80003c20:	c52ff0ef          	jal	80003072 <end_op>
  p = myproc();
    80003c24:	95efd0ef          	jal	80000d82 <myproc>
    80003c28:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80003c2a:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003c2e:	6985                	lui	s3,0x1
    80003c30:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80003c32:	99ca                	add	s3,s3,s2
    80003c34:	77fd                	lui	a5,0xfffff
    80003c36:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003c3a:	4691                	li	a3,4
    80003c3c:	6609                	lui	a2,0x2
    80003c3e:	964e                	add	a2,a2,s3
    80003c40:	85ce                	mv	a1,s3
    80003c42:	855a                	mv	a0,s6
    80003c44:	baffc0ef          	jal	800007f2 <uvmalloc>
    80003c48:	8a2a                	mv	s4,a0
    80003c4a:	e105                	bnez	a0,80003c6a <exec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80003c4c:	85ce                	mv	a1,s3
    80003c4e:	855a                	mv	a0,s6
    80003c50:	a60fd0ef          	jal	80000eb0 <proc_freepagetable>
  return -1;
    80003c54:	557d                	li	a0,-1
    80003c56:	79fe                	ld	s3,504(sp)
    80003c58:	7a5e                	ld	s4,496(sp)
    80003c5a:	7abe                	ld	s5,488(sp)
    80003c5c:	7b1e                	ld	s6,480(sp)
    80003c5e:	6bfe                	ld	s7,472(sp)
    80003c60:	6c5e                	ld	s8,464(sp)
    80003c62:	6cbe                	ld	s9,456(sp)
    80003c64:	6d1e                	ld	s10,448(sp)
    80003c66:	7dfa                	ld	s11,440(sp)
    80003c68:	b541                	j	80003ae8 <exec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003c6a:	75f9                	lui	a1,0xffffe
    80003c6c:	95aa                	add	a1,a1,a0
    80003c6e:	855a                	mv	a0,s6
    80003c70:	d69fc0ef          	jal	800009d8 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003c74:	800a0b93          	addi	s7,s4,-2048
    80003c78:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80003c7c:	e0043783          	ld	a5,-512(s0)
    80003c80:	6388                	ld	a0,0(a5)
  sp = sz;
    80003c82:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80003c84:	4481                	li	s1,0
    ustack[argc] = sp;
    80003c86:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80003c8a:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80003c8e:	cd21                	beqz	a0,80003ce6 <exec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80003c90:	e58fc0ef          	jal	800002e8 <strlen>
    80003c94:	0015079b          	addiw	a5,a0,1
    80003c98:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003c9c:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80003ca0:	13796563          	bltu	s2,s7,80003dca <exec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003ca4:	e0043d83          	ld	s11,-512(s0)
    80003ca8:	000db983          	ld	s3,0(s11)
    80003cac:	854e                	mv	a0,s3
    80003cae:	e3afc0ef          	jal	800002e8 <strlen>
    80003cb2:	0015069b          	addiw	a3,a0,1
    80003cb6:	864e                	mv	a2,s3
    80003cb8:	85ca                	mv	a1,s2
    80003cba:	855a                	mv	a0,s6
    80003cbc:	d47fc0ef          	jal	80000a02 <copyout>
    80003cc0:	10054763          	bltz	a0,80003dce <exec+0x358>
    ustack[argc] = sp;
    80003cc4:	00349793          	slli	a5,s1,0x3
    80003cc8:	97e6                	add	a5,a5,s9
    80003cca:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffdd9a0>
  for(argc = 0; argv[argc]; argc++) {
    80003cce:	0485                	addi	s1,s1,1
    80003cd0:	008d8793          	addi	a5,s11,8
    80003cd4:	e0f43023          	sd	a5,-512(s0)
    80003cd8:	008db503          	ld	a0,8(s11)
    80003cdc:	c509                	beqz	a0,80003ce6 <exec+0x270>
    if(argc >= MAXARG)
    80003cde:	fb8499e3          	bne	s1,s8,80003c90 <exec+0x21a>
  sz = sz1;
    80003ce2:	89d2                	mv	s3,s4
    80003ce4:	b7a5                	j	80003c4c <exec+0x1d6>
  ustack[argc] = 0;
    80003ce6:	00349793          	slli	a5,s1,0x3
    80003cea:	f9078793          	addi	a5,a5,-112
    80003cee:	97a2                	add	a5,a5,s0
    80003cf0:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80003cf4:	00349693          	slli	a3,s1,0x3
    80003cf8:	06a1                	addi	a3,a3,8
    80003cfa:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003cfe:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80003d02:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80003d04:	f57964e3          	bltu	s2,s7,80003c4c <exec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003d08:	e9040613          	addi	a2,s0,-368
    80003d0c:	85ca                	mv	a1,s2
    80003d0e:	855a                	mv	a0,s6
    80003d10:	cf3fc0ef          	jal	80000a02 <copyout>
    80003d14:	f2054ce3          	bltz	a0,80003c4c <exec+0x1d6>
  p->trapframe->a1 = sp;
    80003d18:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80003d1c:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003d20:	df043783          	ld	a5,-528(s0)
    80003d24:	0007c703          	lbu	a4,0(a5)
    80003d28:	cf11                	beqz	a4,80003d44 <exec+0x2ce>
    80003d2a:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003d2c:	02f00693          	li	a3,47
    80003d30:	a029                	j	80003d3a <exec+0x2c4>
  for(last=s=path; *s; s++)
    80003d32:	0785                	addi	a5,a5,1
    80003d34:	fff7c703          	lbu	a4,-1(a5)
    80003d38:	c711                	beqz	a4,80003d44 <exec+0x2ce>
    if(*s == '/')
    80003d3a:	fed71ce3          	bne	a4,a3,80003d32 <exec+0x2bc>
      last = s+1;
    80003d3e:	def43823          	sd	a5,-528(s0)
    80003d42:	bfc5                	j	80003d32 <exec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80003d44:	4641                	li	a2,16
    80003d46:	df043583          	ld	a1,-528(s0)
    80003d4a:	158a8513          	addi	a0,s5,344
    80003d4e:	d64fc0ef          	jal	800002b2 <safestrcpy>
  oldpagetable = p->pagetable;
    80003d52:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80003d56:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80003d5a:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003d5e:	058ab783          	ld	a5,88(s5)
    80003d62:	e6843703          	ld	a4,-408(s0)
    80003d66:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003d68:	058ab783          	ld	a5,88(s5)
    80003d6c:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003d70:	85ea                	mv	a1,s10
    80003d72:	93efd0ef          	jal	80000eb0 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003d76:	0004851b          	sext.w	a0,s1
    80003d7a:	79fe                	ld	s3,504(sp)
    80003d7c:	7a5e                	ld	s4,496(sp)
    80003d7e:	7abe                	ld	s5,488(sp)
    80003d80:	7b1e                	ld	s6,480(sp)
    80003d82:	6bfe                	ld	s7,472(sp)
    80003d84:	6c5e                	ld	s8,464(sp)
    80003d86:	6cbe                	ld	s9,456(sp)
    80003d88:	6d1e                	ld	s10,448(sp)
    80003d8a:	7dfa                	ld	s11,440(sp)
    80003d8c:	bbb1                	j	80003ae8 <exec+0x72>
    80003d8e:	7b1e                	ld	s6,480(sp)
    80003d90:	b3a9                	j	80003ada <exec+0x64>
    80003d92:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003d96:	df843583          	ld	a1,-520(s0)
    80003d9a:	855a                	mv	a0,s6
    80003d9c:	914fd0ef          	jal	80000eb0 <proc_freepagetable>
  if(ip){
    80003da0:	79fe                	ld	s3,504(sp)
    80003da2:	7abe                	ld	s5,488(sp)
    80003da4:	7b1e                	ld	s6,480(sp)
    80003da6:	6bfe                	ld	s7,472(sp)
    80003da8:	6c5e                	ld	s8,464(sp)
    80003daa:	6cbe                	ld	s9,456(sp)
    80003dac:	6d1e                	ld	s10,448(sp)
    80003dae:	7dfa                	ld	s11,440(sp)
    80003db0:	b32d                	j	80003ada <exec+0x64>
    80003db2:	df243c23          	sd	s2,-520(s0)
    80003db6:	b7c5                	j	80003d96 <exec+0x320>
    80003db8:	df243c23          	sd	s2,-520(s0)
    80003dbc:	bfe9                	j	80003d96 <exec+0x320>
    80003dbe:	df243c23          	sd	s2,-520(s0)
    80003dc2:	bfd1                	j	80003d96 <exec+0x320>
    80003dc4:	df243c23          	sd	s2,-520(s0)
    80003dc8:	b7f9                	j	80003d96 <exec+0x320>
  sz = sz1;
    80003dca:	89d2                	mv	s3,s4
    80003dcc:	b541                	j	80003c4c <exec+0x1d6>
    80003dce:	89d2                	mv	s3,s4
    80003dd0:	bdb5                	j	80003c4c <exec+0x1d6>

0000000080003dd2 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003dd2:	7179                	addi	sp,sp,-48
    80003dd4:	f406                	sd	ra,40(sp)
    80003dd6:	f022                	sd	s0,32(sp)
    80003dd8:	ec26                	sd	s1,24(sp)
    80003dda:	e84a                	sd	s2,16(sp)
    80003ddc:	1800                	addi	s0,sp,48
    80003dde:	892e                	mv	s2,a1
    80003de0:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003de2:	fdc40593          	addi	a1,s0,-36
    80003de6:	f27fd0ef          	jal	80001d0c <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003dea:	fdc42703          	lw	a4,-36(s0)
    80003dee:	47bd                	li	a5,15
    80003df0:	02e7ea63          	bltu	a5,a4,80003e24 <argfd+0x52>
    80003df4:	f8ffc0ef          	jal	80000d82 <myproc>
    80003df8:	fdc42703          	lw	a4,-36(s0)
    80003dfc:	00371793          	slli	a5,a4,0x3
    80003e00:	0d078793          	addi	a5,a5,208
    80003e04:	953e                	add	a0,a0,a5
    80003e06:	611c                	ld	a5,0(a0)
    80003e08:	c385                	beqz	a5,80003e28 <argfd+0x56>
    return -1;
  if(pfd)
    80003e0a:	00090463          	beqz	s2,80003e12 <argfd+0x40>
    *pfd = fd;
    80003e0e:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003e12:	4501                	li	a0,0
  if(pf)
    80003e14:	c091                	beqz	s1,80003e18 <argfd+0x46>
    *pf = f;
    80003e16:	e09c                	sd	a5,0(s1)
}
    80003e18:	70a2                	ld	ra,40(sp)
    80003e1a:	7402                	ld	s0,32(sp)
    80003e1c:	64e2                	ld	s1,24(sp)
    80003e1e:	6942                	ld	s2,16(sp)
    80003e20:	6145                	addi	sp,sp,48
    80003e22:	8082                	ret
    return -1;
    80003e24:	557d                	li	a0,-1
    80003e26:	bfcd                	j	80003e18 <argfd+0x46>
    80003e28:	557d                	li	a0,-1
    80003e2a:	b7fd                	j	80003e18 <argfd+0x46>

0000000080003e2c <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003e2c:	1101                	addi	sp,sp,-32
    80003e2e:	ec06                	sd	ra,24(sp)
    80003e30:	e822                	sd	s0,16(sp)
    80003e32:	e426                	sd	s1,8(sp)
    80003e34:	1000                	addi	s0,sp,32
    80003e36:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003e38:	f4bfc0ef          	jal	80000d82 <myproc>
    80003e3c:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003e3e:	0d050793          	addi	a5,a0,208
    80003e42:	4501                	li	a0,0
    80003e44:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003e46:	6398                	ld	a4,0(a5)
    80003e48:	cb19                	beqz	a4,80003e5e <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003e4a:	2505                	addiw	a0,a0,1
    80003e4c:	07a1                	addi	a5,a5,8
    80003e4e:	fed51ce3          	bne	a0,a3,80003e46 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003e52:	557d                	li	a0,-1
}
    80003e54:	60e2                	ld	ra,24(sp)
    80003e56:	6442                	ld	s0,16(sp)
    80003e58:	64a2                	ld	s1,8(sp)
    80003e5a:	6105                	addi	sp,sp,32
    80003e5c:	8082                	ret
      p->ofile[fd] = f;
    80003e5e:	00351793          	slli	a5,a0,0x3
    80003e62:	0d078793          	addi	a5,a5,208
    80003e66:	963e                	add	a2,a2,a5
    80003e68:	e204                	sd	s1,0(a2)
      return fd;
    80003e6a:	b7ed                	j	80003e54 <fdalloc+0x28>

0000000080003e6c <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003e6c:	715d                	addi	sp,sp,-80
    80003e6e:	e486                	sd	ra,72(sp)
    80003e70:	e0a2                	sd	s0,64(sp)
    80003e72:	fc26                	sd	s1,56(sp)
    80003e74:	f84a                	sd	s2,48(sp)
    80003e76:	f44e                	sd	s3,40(sp)
    80003e78:	f052                	sd	s4,32(sp)
    80003e7a:	ec56                	sd	s5,24(sp)
    80003e7c:	e85a                	sd	s6,16(sp)
    80003e7e:	0880                	addi	s0,sp,80
    80003e80:	892e                	mv	s2,a1
    80003e82:	8a2e                	mv	s4,a1
    80003e84:	8ab2                	mv	s5,a2
    80003e86:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003e88:	fb040593          	addi	a1,s0,-80
    80003e8c:	fcffe0ef          	jal	80002e5a <nameiparent>
    80003e90:	84aa                	mv	s1,a0
    80003e92:	10050763          	beqz	a0,80003fa0 <create+0x134>
    return 0;

  ilock(dp);
    80003e96:	8b5fe0ef          	jal	8000274a <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003e9a:	4601                	li	a2,0
    80003e9c:	fb040593          	addi	a1,s0,-80
    80003ea0:	8526                	mv	a0,s1
    80003ea2:	d0bfe0ef          	jal	80002bac <dirlookup>
    80003ea6:	89aa                	mv	s3,a0
    80003ea8:	c131                	beqz	a0,80003eec <create+0x80>
    iunlockput(dp);
    80003eaa:	8526                	mv	a0,s1
    80003eac:	aabfe0ef          	jal	80002956 <iunlockput>
    ilock(ip);
    80003eb0:	854e                	mv	a0,s3
    80003eb2:	899fe0ef          	jal	8000274a <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80003eb6:	4789                	li	a5,2
    80003eb8:	02f91563          	bne	s2,a5,80003ee2 <create+0x76>
    80003ebc:	0449d783          	lhu	a5,68(s3)
    80003ec0:	37f9                	addiw	a5,a5,-2
    80003ec2:	17c2                	slli	a5,a5,0x30
    80003ec4:	93c1                	srli	a5,a5,0x30
    80003ec6:	4705                	li	a4,1
    80003ec8:	00f76d63          	bltu	a4,a5,80003ee2 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80003ecc:	854e                	mv	a0,s3
    80003ece:	60a6                	ld	ra,72(sp)
    80003ed0:	6406                	ld	s0,64(sp)
    80003ed2:	74e2                	ld	s1,56(sp)
    80003ed4:	7942                	ld	s2,48(sp)
    80003ed6:	79a2                	ld	s3,40(sp)
    80003ed8:	7a02                	ld	s4,32(sp)
    80003eda:	6ae2                	ld	s5,24(sp)
    80003edc:	6b42                	ld	s6,16(sp)
    80003ede:	6161                	addi	sp,sp,80
    80003ee0:	8082                	ret
    iunlockput(ip);
    80003ee2:	854e                	mv	a0,s3
    80003ee4:	a73fe0ef          	jal	80002956 <iunlockput>
    return 0;
    80003ee8:	4981                	li	s3,0
    80003eea:	b7cd                	j	80003ecc <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80003eec:	85ca                	mv	a1,s2
    80003eee:	4088                	lw	a0,0(s1)
    80003ef0:	eeafe0ef          	jal	800025da <ialloc>
    80003ef4:	892a                	mv	s2,a0
    80003ef6:	cd15                	beqz	a0,80003f32 <create+0xc6>
  ilock(ip);
    80003ef8:	853fe0ef          	jal	8000274a <ilock>
  ip->major = major;
    80003efc:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80003f00:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80003f04:	4785                	li	a5,1
    80003f06:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80003f0a:	854a                	mv	a0,s2
    80003f0c:	f8afe0ef          	jal	80002696 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80003f10:	4705                	li	a4,1
    80003f12:	02ea0463          	beq	s4,a4,80003f3a <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80003f16:	00492603          	lw	a2,4(s2)
    80003f1a:	fb040593          	addi	a1,s0,-80
    80003f1e:	8526                	mv	a0,s1
    80003f20:	e77fe0ef          	jal	80002d96 <dirlink>
    80003f24:	06054263          	bltz	a0,80003f88 <create+0x11c>
  iunlockput(dp);
    80003f28:	8526                	mv	a0,s1
    80003f2a:	a2dfe0ef          	jal	80002956 <iunlockput>
  return ip;
    80003f2e:	89ca                	mv	s3,s2
    80003f30:	bf71                	j	80003ecc <create+0x60>
    iunlockput(dp);
    80003f32:	8526                	mv	a0,s1
    80003f34:	a23fe0ef          	jal	80002956 <iunlockput>
    return 0;
    80003f38:	bf51                	j	80003ecc <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80003f3a:	00492603          	lw	a2,4(s2)
    80003f3e:	00003597          	auipc	a1,0x3
    80003f42:	68258593          	addi	a1,a1,1666 # 800075c0 <etext+0x5c0>
    80003f46:	854a                	mv	a0,s2
    80003f48:	e4ffe0ef          	jal	80002d96 <dirlink>
    80003f4c:	02054e63          	bltz	a0,80003f88 <create+0x11c>
    80003f50:	40d0                	lw	a2,4(s1)
    80003f52:	00003597          	auipc	a1,0x3
    80003f56:	67658593          	addi	a1,a1,1654 # 800075c8 <etext+0x5c8>
    80003f5a:	854a                	mv	a0,s2
    80003f5c:	e3bfe0ef          	jal	80002d96 <dirlink>
    80003f60:	02054463          	bltz	a0,80003f88 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80003f64:	00492603          	lw	a2,4(s2)
    80003f68:	fb040593          	addi	a1,s0,-80
    80003f6c:	8526                	mv	a0,s1
    80003f6e:	e29fe0ef          	jal	80002d96 <dirlink>
    80003f72:	00054b63          	bltz	a0,80003f88 <create+0x11c>
    dp->nlink++;  // for ".."
    80003f76:	04a4d783          	lhu	a5,74(s1)
    80003f7a:	2785                	addiw	a5,a5,1
    80003f7c:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80003f80:	8526                	mv	a0,s1
    80003f82:	f14fe0ef          	jal	80002696 <iupdate>
    80003f86:	b74d                	j	80003f28 <create+0xbc>
  ip->nlink = 0;
    80003f88:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80003f8c:	854a                	mv	a0,s2
    80003f8e:	f08fe0ef          	jal	80002696 <iupdate>
  iunlockput(ip);
    80003f92:	854a                	mv	a0,s2
    80003f94:	9c3fe0ef          	jal	80002956 <iunlockput>
  iunlockput(dp);
    80003f98:	8526                	mv	a0,s1
    80003f9a:	9bdfe0ef          	jal	80002956 <iunlockput>
  return 0;
    80003f9e:	b73d                	j	80003ecc <create+0x60>
    return 0;
    80003fa0:	89aa                	mv	s3,a0
    80003fa2:	b72d                	j	80003ecc <create+0x60>

0000000080003fa4 <sys_dup>:
{
    80003fa4:	7179                	addi	sp,sp,-48
    80003fa6:	f406                	sd	ra,40(sp)
    80003fa8:	f022                	sd	s0,32(sp)
    80003faa:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80003fac:	fd840613          	addi	a2,s0,-40
    80003fb0:	4581                	li	a1,0
    80003fb2:	4501                	li	a0,0
    80003fb4:	e1fff0ef          	jal	80003dd2 <argfd>
    return -1;
    80003fb8:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80003fba:	02054363          	bltz	a0,80003fe0 <sys_dup+0x3c>
    80003fbe:	ec26                	sd	s1,24(sp)
    80003fc0:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80003fc2:	fd843483          	ld	s1,-40(s0)
    80003fc6:	8526                	mv	a0,s1
    80003fc8:	e65ff0ef          	jal	80003e2c <fdalloc>
    80003fcc:	892a                	mv	s2,a0
    return -1;
    80003fce:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80003fd0:	00054d63          	bltz	a0,80003fea <sys_dup+0x46>
  filedup(f);
    80003fd4:	8526                	mv	a0,s1
    80003fd6:	c18ff0ef          	jal	800033ee <filedup>
  return fd;
    80003fda:	87ca                	mv	a5,s2
    80003fdc:	64e2                	ld	s1,24(sp)
    80003fde:	6942                	ld	s2,16(sp)
}
    80003fe0:	853e                	mv	a0,a5
    80003fe2:	70a2                	ld	ra,40(sp)
    80003fe4:	7402                	ld	s0,32(sp)
    80003fe6:	6145                	addi	sp,sp,48
    80003fe8:	8082                	ret
    80003fea:	64e2                	ld	s1,24(sp)
    80003fec:	6942                	ld	s2,16(sp)
    80003fee:	bfcd                	j	80003fe0 <sys_dup+0x3c>

0000000080003ff0 <sys_read>:
{
    80003ff0:	7179                	addi	sp,sp,-48
    80003ff2:	f406                	sd	ra,40(sp)
    80003ff4:	f022                	sd	s0,32(sp)
    80003ff6:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80003ff8:	fd840593          	addi	a1,s0,-40
    80003ffc:	4505                	li	a0,1
    80003ffe:	d2bfd0ef          	jal	80001d28 <argaddr>
  argint(2, &n);
    80004002:	fe440593          	addi	a1,s0,-28
    80004006:	4509                	li	a0,2
    80004008:	d05fd0ef          	jal	80001d0c <argint>
  if(argfd(0, 0, &f) < 0)
    8000400c:	fe840613          	addi	a2,s0,-24
    80004010:	4581                	li	a1,0
    80004012:	4501                	li	a0,0
    80004014:	dbfff0ef          	jal	80003dd2 <argfd>
    80004018:	87aa                	mv	a5,a0
    return -1;
    8000401a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000401c:	0007ca63          	bltz	a5,80004030 <sys_read+0x40>
  return fileread(f, p, n);
    80004020:	fe442603          	lw	a2,-28(s0)
    80004024:	fd843583          	ld	a1,-40(s0)
    80004028:	fe843503          	ld	a0,-24(s0)
    8000402c:	d2cff0ef          	jal	80003558 <fileread>
}
    80004030:	70a2                	ld	ra,40(sp)
    80004032:	7402                	ld	s0,32(sp)
    80004034:	6145                	addi	sp,sp,48
    80004036:	8082                	ret

0000000080004038 <sys_write>:
{
    80004038:	7179                	addi	sp,sp,-48
    8000403a:	f406                	sd	ra,40(sp)
    8000403c:	f022                	sd	s0,32(sp)
    8000403e:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004040:	fd840593          	addi	a1,s0,-40
    80004044:	4505                	li	a0,1
    80004046:	ce3fd0ef          	jal	80001d28 <argaddr>
  argint(2, &n);
    8000404a:	fe440593          	addi	a1,s0,-28
    8000404e:	4509                	li	a0,2
    80004050:	cbdfd0ef          	jal	80001d0c <argint>
  if(argfd(0, 0, &f) < 0)
    80004054:	fe840613          	addi	a2,s0,-24
    80004058:	4581                	li	a1,0
    8000405a:	4501                	li	a0,0
    8000405c:	d77ff0ef          	jal	80003dd2 <argfd>
    80004060:	87aa                	mv	a5,a0
    return -1;
    80004062:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004064:	0007ca63          	bltz	a5,80004078 <sys_write+0x40>
  return filewrite(f, p, n);
    80004068:	fe442603          	lw	a2,-28(s0)
    8000406c:	fd843583          	ld	a1,-40(s0)
    80004070:	fe843503          	ld	a0,-24(s0)
    80004074:	da8ff0ef          	jal	8000361c <filewrite>
}
    80004078:	70a2                	ld	ra,40(sp)
    8000407a:	7402                	ld	s0,32(sp)
    8000407c:	6145                	addi	sp,sp,48
    8000407e:	8082                	ret

0000000080004080 <sys_close>:
{
    80004080:	1101                	addi	sp,sp,-32
    80004082:	ec06                	sd	ra,24(sp)
    80004084:	e822                	sd	s0,16(sp)
    80004086:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004088:	fe040613          	addi	a2,s0,-32
    8000408c:	fec40593          	addi	a1,s0,-20
    80004090:	4501                	li	a0,0
    80004092:	d41ff0ef          	jal	80003dd2 <argfd>
    return -1;
    80004096:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004098:	02054163          	bltz	a0,800040ba <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    8000409c:	ce7fc0ef          	jal	80000d82 <myproc>
    800040a0:	fec42783          	lw	a5,-20(s0)
    800040a4:	078e                	slli	a5,a5,0x3
    800040a6:	0d078793          	addi	a5,a5,208
    800040aa:	953e                	add	a0,a0,a5
    800040ac:	00053023          	sd	zero,0(a0)
  fileclose(f);
    800040b0:	fe043503          	ld	a0,-32(s0)
    800040b4:	b80ff0ef          	jal	80003434 <fileclose>
  return 0;
    800040b8:	4781                	li	a5,0
}
    800040ba:	853e                	mv	a0,a5
    800040bc:	60e2                	ld	ra,24(sp)
    800040be:	6442                	ld	s0,16(sp)
    800040c0:	6105                	addi	sp,sp,32
    800040c2:	8082                	ret

00000000800040c4 <sys_fstat>:
{
    800040c4:	1101                	addi	sp,sp,-32
    800040c6:	ec06                	sd	ra,24(sp)
    800040c8:	e822                	sd	s0,16(sp)
    800040ca:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    800040cc:	fe040593          	addi	a1,s0,-32
    800040d0:	4505                	li	a0,1
    800040d2:	c57fd0ef          	jal	80001d28 <argaddr>
  if(argfd(0, 0, &f) < 0)
    800040d6:	fe840613          	addi	a2,s0,-24
    800040da:	4581                	li	a1,0
    800040dc:	4501                	li	a0,0
    800040de:	cf5ff0ef          	jal	80003dd2 <argfd>
    800040e2:	87aa                	mv	a5,a0
    return -1;
    800040e4:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800040e6:	0007c863          	bltz	a5,800040f6 <sys_fstat+0x32>
  return filestat(f, st);
    800040ea:	fe043583          	ld	a1,-32(s0)
    800040ee:	fe843503          	ld	a0,-24(s0)
    800040f2:	c04ff0ef          	jal	800034f6 <filestat>
}
    800040f6:	60e2                	ld	ra,24(sp)
    800040f8:	6442                	ld	s0,16(sp)
    800040fa:	6105                	addi	sp,sp,32
    800040fc:	8082                	ret

00000000800040fe <sys_link>:
{
    800040fe:	7169                	addi	sp,sp,-304
    80004100:	f606                	sd	ra,296(sp)
    80004102:	f222                	sd	s0,288(sp)
    80004104:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004106:	08000613          	li	a2,128
    8000410a:	ed040593          	addi	a1,s0,-304
    8000410e:	4501                	li	a0,0
    80004110:	c35fd0ef          	jal	80001d44 <argstr>
    return -1;
    80004114:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004116:	0c054e63          	bltz	a0,800041f2 <sys_link+0xf4>
    8000411a:	08000613          	li	a2,128
    8000411e:	f5040593          	addi	a1,s0,-176
    80004122:	4505                	li	a0,1
    80004124:	c21fd0ef          	jal	80001d44 <argstr>
    return -1;
    80004128:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000412a:	0c054463          	bltz	a0,800041f2 <sys_link+0xf4>
    8000412e:	ee26                	sd	s1,280(sp)
  begin_op();
    80004130:	ed3fe0ef          	jal	80003002 <begin_op>
  if((ip = namei(old)) == 0){
    80004134:	ed040513          	addi	a0,s0,-304
    80004138:	d09fe0ef          	jal	80002e40 <namei>
    8000413c:	84aa                	mv	s1,a0
    8000413e:	c53d                	beqz	a0,800041ac <sys_link+0xae>
  ilock(ip);
    80004140:	e0afe0ef          	jal	8000274a <ilock>
  if(ip->type == T_DIR){
    80004144:	04449703          	lh	a4,68(s1)
    80004148:	4785                	li	a5,1
    8000414a:	06f70663          	beq	a4,a5,800041b6 <sys_link+0xb8>
    8000414e:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004150:	04a4d783          	lhu	a5,74(s1)
    80004154:	2785                	addiw	a5,a5,1
    80004156:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000415a:	8526                	mv	a0,s1
    8000415c:	d3afe0ef          	jal	80002696 <iupdate>
  iunlock(ip);
    80004160:	8526                	mv	a0,s1
    80004162:	e96fe0ef          	jal	800027f8 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004166:	fd040593          	addi	a1,s0,-48
    8000416a:	f5040513          	addi	a0,s0,-176
    8000416e:	cedfe0ef          	jal	80002e5a <nameiparent>
    80004172:	892a                	mv	s2,a0
    80004174:	cd21                	beqz	a0,800041cc <sys_link+0xce>
  ilock(dp);
    80004176:	dd4fe0ef          	jal	8000274a <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    8000417a:	854a                	mv	a0,s2
    8000417c:	00092703          	lw	a4,0(s2)
    80004180:	409c                	lw	a5,0(s1)
    80004182:	04f71263          	bne	a4,a5,800041c6 <sys_link+0xc8>
    80004186:	40d0                	lw	a2,4(s1)
    80004188:	fd040593          	addi	a1,s0,-48
    8000418c:	c0bfe0ef          	jal	80002d96 <dirlink>
    80004190:	02054b63          	bltz	a0,800041c6 <sys_link+0xc8>
  iunlockput(dp);
    80004194:	854a                	mv	a0,s2
    80004196:	fc0fe0ef          	jal	80002956 <iunlockput>
  iput(ip);
    8000419a:	8526                	mv	a0,s1
    8000419c:	f30fe0ef          	jal	800028cc <iput>
  end_op();
    800041a0:	ed3fe0ef          	jal	80003072 <end_op>
  return 0;
    800041a4:	4781                	li	a5,0
    800041a6:	64f2                	ld	s1,280(sp)
    800041a8:	6952                	ld	s2,272(sp)
    800041aa:	a0a1                	j	800041f2 <sys_link+0xf4>
    end_op();
    800041ac:	ec7fe0ef          	jal	80003072 <end_op>
    return -1;
    800041b0:	57fd                	li	a5,-1
    800041b2:	64f2                	ld	s1,280(sp)
    800041b4:	a83d                	j	800041f2 <sys_link+0xf4>
    iunlockput(ip);
    800041b6:	8526                	mv	a0,s1
    800041b8:	f9efe0ef          	jal	80002956 <iunlockput>
    end_op();
    800041bc:	eb7fe0ef          	jal	80003072 <end_op>
    return -1;
    800041c0:	57fd                	li	a5,-1
    800041c2:	64f2                	ld	s1,280(sp)
    800041c4:	a03d                	j	800041f2 <sys_link+0xf4>
    iunlockput(dp);
    800041c6:	854a                	mv	a0,s2
    800041c8:	f8efe0ef          	jal	80002956 <iunlockput>
  ilock(ip);
    800041cc:	8526                	mv	a0,s1
    800041ce:	d7cfe0ef          	jal	8000274a <ilock>
  ip->nlink--;
    800041d2:	04a4d783          	lhu	a5,74(s1)
    800041d6:	37fd                	addiw	a5,a5,-1
    800041d8:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800041dc:	8526                	mv	a0,s1
    800041de:	cb8fe0ef          	jal	80002696 <iupdate>
  iunlockput(ip);
    800041e2:	8526                	mv	a0,s1
    800041e4:	f72fe0ef          	jal	80002956 <iunlockput>
  end_op();
    800041e8:	e8bfe0ef          	jal	80003072 <end_op>
  return -1;
    800041ec:	57fd                	li	a5,-1
    800041ee:	64f2                	ld	s1,280(sp)
    800041f0:	6952                	ld	s2,272(sp)
}
    800041f2:	853e                	mv	a0,a5
    800041f4:	70b2                	ld	ra,296(sp)
    800041f6:	7412                	ld	s0,288(sp)
    800041f8:	6155                	addi	sp,sp,304
    800041fa:	8082                	ret

00000000800041fc <sys_unlink>:
{
    800041fc:	7151                	addi	sp,sp,-240
    800041fe:	f586                	sd	ra,232(sp)
    80004200:	f1a2                	sd	s0,224(sp)
    80004202:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004204:	08000613          	li	a2,128
    80004208:	f3040593          	addi	a1,s0,-208
    8000420c:	4501                	li	a0,0
    8000420e:	b37fd0ef          	jal	80001d44 <argstr>
    80004212:	14054d63          	bltz	a0,8000436c <sys_unlink+0x170>
    80004216:	eda6                	sd	s1,216(sp)
  begin_op();
    80004218:	debfe0ef          	jal	80003002 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    8000421c:	fb040593          	addi	a1,s0,-80
    80004220:	f3040513          	addi	a0,s0,-208
    80004224:	c37fe0ef          	jal	80002e5a <nameiparent>
    80004228:	84aa                	mv	s1,a0
    8000422a:	c955                	beqz	a0,800042de <sys_unlink+0xe2>
  ilock(dp);
    8000422c:	d1efe0ef          	jal	8000274a <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004230:	00003597          	auipc	a1,0x3
    80004234:	39058593          	addi	a1,a1,912 # 800075c0 <etext+0x5c0>
    80004238:	fb040513          	addi	a0,s0,-80
    8000423c:	95bfe0ef          	jal	80002b96 <namecmp>
    80004240:	10050b63          	beqz	a0,80004356 <sys_unlink+0x15a>
    80004244:	00003597          	auipc	a1,0x3
    80004248:	38458593          	addi	a1,a1,900 # 800075c8 <etext+0x5c8>
    8000424c:	fb040513          	addi	a0,s0,-80
    80004250:	947fe0ef          	jal	80002b96 <namecmp>
    80004254:	10050163          	beqz	a0,80004356 <sys_unlink+0x15a>
    80004258:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    8000425a:	f2c40613          	addi	a2,s0,-212
    8000425e:	fb040593          	addi	a1,s0,-80
    80004262:	8526                	mv	a0,s1
    80004264:	949fe0ef          	jal	80002bac <dirlookup>
    80004268:	892a                	mv	s2,a0
    8000426a:	0e050563          	beqz	a0,80004354 <sys_unlink+0x158>
    8000426e:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80004270:	cdafe0ef          	jal	8000274a <ilock>
  if(ip->nlink < 1)
    80004274:	04a91783          	lh	a5,74(s2)
    80004278:	06f05863          	blez	a5,800042e8 <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    8000427c:	04491703          	lh	a4,68(s2)
    80004280:	4785                	li	a5,1
    80004282:	06f70963          	beq	a4,a5,800042f4 <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80004286:	fc040993          	addi	s3,s0,-64
    8000428a:	4641                	li	a2,16
    8000428c:	4581                	li	a1,0
    8000428e:	854e                	mv	a0,s3
    80004290:	ecffb0ef          	jal	8000015e <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004294:	4741                	li	a4,16
    80004296:	f2c42683          	lw	a3,-212(s0)
    8000429a:	864e                	mv	a2,s3
    8000429c:	4581                	li	a1,0
    8000429e:	8526                	mv	a0,s1
    800042a0:	ff6fe0ef          	jal	80002a96 <writei>
    800042a4:	47c1                	li	a5,16
    800042a6:	08f51863          	bne	a0,a5,80004336 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    800042aa:	04491703          	lh	a4,68(s2)
    800042ae:	4785                	li	a5,1
    800042b0:	08f70963          	beq	a4,a5,80004342 <sys_unlink+0x146>
  iunlockput(dp);
    800042b4:	8526                	mv	a0,s1
    800042b6:	ea0fe0ef          	jal	80002956 <iunlockput>
  ip->nlink--;
    800042ba:	04a95783          	lhu	a5,74(s2)
    800042be:	37fd                	addiw	a5,a5,-1
    800042c0:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800042c4:	854a                	mv	a0,s2
    800042c6:	bd0fe0ef          	jal	80002696 <iupdate>
  iunlockput(ip);
    800042ca:	854a                	mv	a0,s2
    800042cc:	e8afe0ef          	jal	80002956 <iunlockput>
  end_op();
    800042d0:	da3fe0ef          	jal	80003072 <end_op>
  return 0;
    800042d4:	4501                	li	a0,0
    800042d6:	64ee                	ld	s1,216(sp)
    800042d8:	694e                	ld	s2,208(sp)
    800042da:	69ae                	ld	s3,200(sp)
    800042dc:	a061                	j	80004364 <sys_unlink+0x168>
    end_op();
    800042de:	d95fe0ef          	jal	80003072 <end_op>
    return -1;
    800042e2:	557d                	li	a0,-1
    800042e4:	64ee                	ld	s1,216(sp)
    800042e6:	a8bd                	j	80004364 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    800042e8:	00003517          	auipc	a0,0x3
    800042ec:	2e850513          	addi	a0,a0,744 # 800075d0 <etext+0x5d0>
    800042f0:	338010ef          	jal	80005628 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800042f4:	04c92703          	lw	a4,76(s2)
    800042f8:	02000793          	li	a5,32
    800042fc:	f8e7f5e3          	bgeu	a5,a4,80004286 <sys_unlink+0x8a>
    80004300:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004302:	4741                	li	a4,16
    80004304:	86ce                	mv	a3,s3
    80004306:	f1840613          	addi	a2,s0,-232
    8000430a:	4581                	li	a1,0
    8000430c:	854a                	mv	a0,s2
    8000430e:	e96fe0ef          	jal	800029a4 <readi>
    80004312:	47c1                	li	a5,16
    80004314:	00f51b63          	bne	a0,a5,8000432a <sys_unlink+0x12e>
    if(de.inum != 0)
    80004318:	f1845783          	lhu	a5,-232(s0)
    8000431c:	ebb1                	bnez	a5,80004370 <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000431e:	29c1                	addiw	s3,s3,16
    80004320:	04c92783          	lw	a5,76(s2)
    80004324:	fcf9efe3          	bltu	s3,a5,80004302 <sys_unlink+0x106>
    80004328:	bfb9                	j	80004286 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    8000432a:	00003517          	auipc	a0,0x3
    8000432e:	2be50513          	addi	a0,a0,702 # 800075e8 <etext+0x5e8>
    80004332:	2f6010ef          	jal	80005628 <panic>
    panic("unlink: writei");
    80004336:	00003517          	auipc	a0,0x3
    8000433a:	2ca50513          	addi	a0,a0,714 # 80007600 <etext+0x600>
    8000433e:	2ea010ef          	jal	80005628 <panic>
    dp->nlink--;
    80004342:	04a4d783          	lhu	a5,74(s1)
    80004346:	37fd                	addiw	a5,a5,-1
    80004348:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000434c:	8526                	mv	a0,s1
    8000434e:	b48fe0ef          	jal	80002696 <iupdate>
    80004352:	b78d                	j	800042b4 <sys_unlink+0xb8>
    80004354:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004356:	8526                	mv	a0,s1
    80004358:	dfefe0ef          	jal	80002956 <iunlockput>
  end_op();
    8000435c:	d17fe0ef          	jal	80003072 <end_op>
  return -1;
    80004360:	557d                	li	a0,-1
    80004362:	64ee                	ld	s1,216(sp)
}
    80004364:	70ae                	ld	ra,232(sp)
    80004366:	740e                	ld	s0,224(sp)
    80004368:	616d                	addi	sp,sp,240
    8000436a:	8082                	ret
    return -1;
    8000436c:	557d                	li	a0,-1
    8000436e:	bfdd                	j	80004364 <sys_unlink+0x168>
    iunlockput(ip);
    80004370:	854a                	mv	a0,s2
    80004372:	de4fe0ef          	jal	80002956 <iunlockput>
    goto bad;
    80004376:	694e                	ld	s2,208(sp)
    80004378:	69ae                	ld	s3,200(sp)
    8000437a:	bff1                	j	80004356 <sys_unlink+0x15a>

000000008000437c <sys_open>:

uint64
sys_open(void)
{
    8000437c:	7131                	addi	sp,sp,-192
    8000437e:	fd06                	sd	ra,184(sp)
    80004380:	f922                	sd	s0,176(sp)
    80004382:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004384:	f4c40593          	addi	a1,s0,-180
    80004388:	4505                	li	a0,1
    8000438a:	983fd0ef          	jal	80001d0c <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000438e:	08000613          	li	a2,128
    80004392:	f5040593          	addi	a1,s0,-176
    80004396:	4501                	li	a0,0
    80004398:	9adfd0ef          	jal	80001d44 <argstr>
    8000439c:	87aa                	mv	a5,a0
    return -1;
    8000439e:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800043a0:	0a07c363          	bltz	a5,80004446 <sys_open+0xca>
    800043a4:	f526                	sd	s1,168(sp)

  begin_op();
    800043a6:	c5dfe0ef          	jal	80003002 <begin_op>

  if(omode & O_CREATE){
    800043aa:	f4c42783          	lw	a5,-180(s0)
    800043ae:	2007f793          	andi	a5,a5,512
    800043b2:	c3dd                	beqz	a5,80004458 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    800043b4:	4681                	li	a3,0
    800043b6:	4601                	li	a2,0
    800043b8:	4589                	li	a1,2
    800043ba:	f5040513          	addi	a0,s0,-176
    800043be:	aafff0ef          	jal	80003e6c <create>
    800043c2:	84aa                	mv	s1,a0
    if(ip == 0){
    800043c4:	c549                	beqz	a0,8000444e <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800043c6:	04449703          	lh	a4,68(s1)
    800043ca:	478d                	li	a5,3
    800043cc:	00f71763          	bne	a4,a5,800043da <sys_open+0x5e>
    800043d0:	0464d703          	lhu	a4,70(s1)
    800043d4:	47a5                	li	a5,9
    800043d6:	0ae7ee63          	bltu	a5,a4,80004492 <sys_open+0x116>
    800043da:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    800043dc:	fb5fe0ef          	jal	80003390 <filealloc>
    800043e0:	892a                	mv	s2,a0
    800043e2:	c561                	beqz	a0,800044aa <sys_open+0x12e>
    800043e4:	ed4e                	sd	s3,152(sp)
    800043e6:	a47ff0ef          	jal	80003e2c <fdalloc>
    800043ea:	89aa                	mv	s3,a0
    800043ec:	0a054b63          	bltz	a0,800044a2 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    800043f0:	04449703          	lh	a4,68(s1)
    800043f4:	478d                	li	a5,3
    800043f6:	0cf70363          	beq	a4,a5,800044bc <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    800043fa:	4789                	li	a5,2
    800043fc:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004400:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004404:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004408:	f4c42783          	lw	a5,-180(s0)
    8000440c:	0017f713          	andi	a4,a5,1
    80004410:	00174713          	xori	a4,a4,1
    80004414:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004418:	0037f713          	andi	a4,a5,3
    8000441c:	00e03733          	snez	a4,a4
    80004420:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004424:	4007f793          	andi	a5,a5,1024
    80004428:	c791                	beqz	a5,80004434 <sys_open+0xb8>
    8000442a:	04449703          	lh	a4,68(s1)
    8000442e:	4789                	li	a5,2
    80004430:	08f70d63          	beq	a4,a5,800044ca <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    80004434:	8526                	mv	a0,s1
    80004436:	bc2fe0ef          	jal	800027f8 <iunlock>
  end_op();
    8000443a:	c39fe0ef          	jal	80003072 <end_op>

  return fd;
    8000443e:	854e                	mv	a0,s3
    80004440:	74aa                	ld	s1,168(sp)
    80004442:	790a                	ld	s2,160(sp)
    80004444:	69ea                	ld	s3,152(sp)
}
    80004446:	70ea                	ld	ra,184(sp)
    80004448:	744a                	ld	s0,176(sp)
    8000444a:	6129                	addi	sp,sp,192
    8000444c:	8082                	ret
      end_op();
    8000444e:	c25fe0ef          	jal	80003072 <end_op>
      return -1;
    80004452:	557d                	li	a0,-1
    80004454:	74aa                	ld	s1,168(sp)
    80004456:	bfc5                	j	80004446 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    80004458:	f5040513          	addi	a0,s0,-176
    8000445c:	9e5fe0ef          	jal	80002e40 <namei>
    80004460:	84aa                	mv	s1,a0
    80004462:	c11d                	beqz	a0,80004488 <sys_open+0x10c>
    ilock(ip);
    80004464:	ae6fe0ef          	jal	8000274a <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004468:	04449703          	lh	a4,68(s1)
    8000446c:	4785                	li	a5,1
    8000446e:	f4f71ce3          	bne	a4,a5,800043c6 <sys_open+0x4a>
    80004472:	f4c42783          	lw	a5,-180(s0)
    80004476:	d3b5                	beqz	a5,800043da <sys_open+0x5e>
      iunlockput(ip);
    80004478:	8526                	mv	a0,s1
    8000447a:	cdcfe0ef          	jal	80002956 <iunlockput>
      end_op();
    8000447e:	bf5fe0ef          	jal	80003072 <end_op>
      return -1;
    80004482:	557d                	li	a0,-1
    80004484:	74aa                	ld	s1,168(sp)
    80004486:	b7c1                	j	80004446 <sys_open+0xca>
      end_op();
    80004488:	bebfe0ef          	jal	80003072 <end_op>
      return -1;
    8000448c:	557d                	li	a0,-1
    8000448e:	74aa                	ld	s1,168(sp)
    80004490:	bf5d                	j	80004446 <sys_open+0xca>
    iunlockput(ip);
    80004492:	8526                	mv	a0,s1
    80004494:	cc2fe0ef          	jal	80002956 <iunlockput>
    end_op();
    80004498:	bdbfe0ef          	jal	80003072 <end_op>
    return -1;
    8000449c:	557d                	li	a0,-1
    8000449e:	74aa                	ld	s1,168(sp)
    800044a0:	b75d                	j	80004446 <sys_open+0xca>
      fileclose(f);
    800044a2:	854a                	mv	a0,s2
    800044a4:	f91fe0ef          	jal	80003434 <fileclose>
    800044a8:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    800044aa:	8526                	mv	a0,s1
    800044ac:	caafe0ef          	jal	80002956 <iunlockput>
    end_op();
    800044b0:	bc3fe0ef          	jal	80003072 <end_op>
    return -1;
    800044b4:	557d                	li	a0,-1
    800044b6:	74aa                	ld	s1,168(sp)
    800044b8:	790a                	ld	s2,160(sp)
    800044ba:	b771                	j	80004446 <sys_open+0xca>
    f->type = FD_DEVICE;
    800044bc:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800044c0:	04649783          	lh	a5,70(s1)
    800044c4:	02f91223          	sh	a5,36(s2)
    800044c8:	bf35                	j	80004404 <sys_open+0x88>
    itrunc(ip);
    800044ca:	8526                	mv	a0,s1
    800044cc:	b6cfe0ef          	jal	80002838 <itrunc>
    800044d0:	b795                	j	80004434 <sys_open+0xb8>

00000000800044d2 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800044d2:	7175                	addi	sp,sp,-144
    800044d4:	e506                	sd	ra,136(sp)
    800044d6:	e122                	sd	s0,128(sp)
    800044d8:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800044da:	b29fe0ef          	jal	80003002 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800044de:	08000613          	li	a2,128
    800044e2:	f7040593          	addi	a1,s0,-144
    800044e6:	4501                	li	a0,0
    800044e8:	85dfd0ef          	jal	80001d44 <argstr>
    800044ec:	02054363          	bltz	a0,80004512 <sys_mkdir+0x40>
    800044f0:	4681                	li	a3,0
    800044f2:	4601                	li	a2,0
    800044f4:	4585                	li	a1,1
    800044f6:	f7040513          	addi	a0,s0,-144
    800044fa:	973ff0ef          	jal	80003e6c <create>
    800044fe:	c911                	beqz	a0,80004512 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004500:	c56fe0ef          	jal	80002956 <iunlockput>
  end_op();
    80004504:	b6ffe0ef          	jal	80003072 <end_op>
  return 0;
    80004508:	4501                	li	a0,0
}
    8000450a:	60aa                	ld	ra,136(sp)
    8000450c:	640a                	ld	s0,128(sp)
    8000450e:	6149                	addi	sp,sp,144
    80004510:	8082                	ret
    end_op();
    80004512:	b61fe0ef          	jal	80003072 <end_op>
    return -1;
    80004516:	557d                	li	a0,-1
    80004518:	bfcd                	j	8000450a <sys_mkdir+0x38>

000000008000451a <sys_mknod>:

uint64
sys_mknod(void)
{
    8000451a:	7135                	addi	sp,sp,-160
    8000451c:	ed06                	sd	ra,152(sp)
    8000451e:	e922                	sd	s0,144(sp)
    80004520:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004522:	ae1fe0ef          	jal	80003002 <begin_op>
  argint(1, &major);
    80004526:	f6c40593          	addi	a1,s0,-148
    8000452a:	4505                	li	a0,1
    8000452c:	fe0fd0ef          	jal	80001d0c <argint>
  argint(2, &minor);
    80004530:	f6840593          	addi	a1,s0,-152
    80004534:	4509                	li	a0,2
    80004536:	fd6fd0ef          	jal	80001d0c <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000453a:	08000613          	li	a2,128
    8000453e:	f7040593          	addi	a1,s0,-144
    80004542:	4501                	li	a0,0
    80004544:	801fd0ef          	jal	80001d44 <argstr>
    80004548:	02054563          	bltz	a0,80004572 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    8000454c:	f6841683          	lh	a3,-152(s0)
    80004550:	f6c41603          	lh	a2,-148(s0)
    80004554:	458d                	li	a1,3
    80004556:	f7040513          	addi	a0,s0,-144
    8000455a:	913ff0ef          	jal	80003e6c <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000455e:	c911                	beqz	a0,80004572 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004560:	bf6fe0ef          	jal	80002956 <iunlockput>
  end_op();
    80004564:	b0ffe0ef          	jal	80003072 <end_op>
  return 0;
    80004568:	4501                	li	a0,0
}
    8000456a:	60ea                	ld	ra,152(sp)
    8000456c:	644a                	ld	s0,144(sp)
    8000456e:	610d                	addi	sp,sp,160
    80004570:	8082                	ret
    end_op();
    80004572:	b01fe0ef          	jal	80003072 <end_op>
    return -1;
    80004576:	557d                	li	a0,-1
    80004578:	bfcd                	j	8000456a <sys_mknod+0x50>

000000008000457a <sys_chdir>:

uint64
sys_chdir(void)
{
    8000457a:	7135                	addi	sp,sp,-160
    8000457c:	ed06                	sd	ra,152(sp)
    8000457e:	e922                	sd	s0,144(sp)
    80004580:	e14a                	sd	s2,128(sp)
    80004582:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80004584:	ffefc0ef          	jal	80000d82 <myproc>
    80004588:	892a                	mv	s2,a0
  
  begin_op();
    8000458a:	a79fe0ef          	jal	80003002 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    8000458e:	08000613          	li	a2,128
    80004592:	f6040593          	addi	a1,s0,-160
    80004596:	4501                	li	a0,0
    80004598:	facfd0ef          	jal	80001d44 <argstr>
    8000459c:	04054363          	bltz	a0,800045e2 <sys_chdir+0x68>
    800045a0:	e526                	sd	s1,136(sp)
    800045a2:	f6040513          	addi	a0,s0,-160
    800045a6:	89bfe0ef          	jal	80002e40 <namei>
    800045aa:	84aa                	mv	s1,a0
    800045ac:	c915                	beqz	a0,800045e0 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800045ae:	99cfe0ef          	jal	8000274a <ilock>
  if(ip->type != T_DIR){
    800045b2:	04449703          	lh	a4,68(s1)
    800045b6:	4785                	li	a5,1
    800045b8:	02f71963          	bne	a4,a5,800045ea <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800045bc:	8526                	mv	a0,s1
    800045be:	a3afe0ef          	jal	800027f8 <iunlock>
  iput(p->cwd);
    800045c2:	15093503          	ld	a0,336(s2)
    800045c6:	b06fe0ef          	jal	800028cc <iput>
  end_op();
    800045ca:	aa9fe0ef          	jal	80003072 <end_op>
  p->cwd = ip;
    800045ce:	14993823          	sd	s1,336(s2)
  return 0;
    800045d2:	4501                	li	a0,0
    800045d4:	64aa                	ld	s1,136(sp)
}
    800045d6:	60ea                	ld	ra,152(sp)
    800045d8:	644a                	ld	s0,144(sp)
    800045da:	690a                	ld	s2,128(sp)
    800045dc:	610d                	addi	sp,sp,160
    800045de:	8082                	ret
    800045e0:	64aa                	ld	s1,136(sp)
    end_op();
    800045e2:	a91fe0ef          	jal	80003072 <end_op>
    return -1;
    800045e6:	557d                	li	a0,-1
    800045e8:	b7fd                	j	800045d6 <sys_chdir+0x5c>
    iunlockput(ip);
    800045ea:	8526                	mv	a0,s1
    800045ec:	b6afe0ef          	jal	80002956 <iunlockput>
    end_op();
    800045f0:	a83fe0ef          	jal	80003072 <end_op>
    return -1;
    800045f4:	557d                	li	a0,-1
    800045f6:	64aa                	ld	s1,136(sp)
    800045f8:	bff9                	j	800045d6 <sys_chdir+0x5c>

00000000800045fa <sys_exec>:

uint64
sys_exec(void)
{
    800045fa:	7105                	addi	sp,sp,-480
    800045fc:	ef86                	sd	ra,472(sp)
    800045fe:	eba2                	sd	s0,464(sp)
    80004600:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004602:	e2840593          	addi	a1,s0,-472
    80004606:	4505                	li	a0,1
    80004608:	f20fd0ef          	jal	80001d28 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    8000460c:	08000613          	li	a2,128
    80004610:	f3040593          	addi	a1,s0,-208
    80004614:	4501                	li	a0,0
    80004616:	f2efd0ef          	jal	80001d44 <argstr>
    8000461a:	87aa                	mv	a5,a0
    return -1;
    8000461c:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    8000461e:	0e07c063          	bltz	a5,800046fe <sys_exec+0x104>
    80004622:	e7a6                	sd	s1,456(sp)
    80004624:	e3ca                	sd	s2,448(sp)
    80004626:	ff4e                	sd	s3,440(sp)
    80004628:	fb52                	sd	s4,432(sp)
    8000462a:	f756                	sd	s5,424(sp)
    8000462c:	f35a                	sd	s6,416(sp)
    8000462e:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    80004630:	e3040a13          	addi	s4,s0,-464
    80004634:	10000613          	li	a2,256
    80004638:	4581                	li	a1,0
    8000463a:	8552                	mv	a0,s4
    8000463c:	b23fb0ef          	jal	8000015e <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80004640:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    80004642:	89d2                	mv	s3,s4
    80004644:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004646:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000464a:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    8000464c:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004650:	00391513          	slli	a0,s2,0x3
    80004654:	85d6                	mv	a1,s5
    80004656:	e2843783          	ld	a5,-472(s0)
    8000465a:	953e                	add	a0,a0,a5
    8000465c:	e26fd0ef          	jal	80001c82 <fetchaddr>
    80004660:	02054663          	bltz	a0,8000468c <sys_exec+0x92>
    if(uarg == 0){
    80004664:	e2043783          	ld	a5,-480(s0)
    80004668:	c7a1                	beqz	a5,800046b0 <sys_exec+0xb6>
    argv[i] = kalloc();
    8000466a:	a9bfb0ef          	jal	80000104 <kalloc>
    8000466e:	85aa                	mv	a1,a0
    80004670:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80004674:	cd01                	beqz	a0,8000468c <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80004676:	865a                	mv	a2,s6
    80004678:	e2043503          	ld	a0,-480(s0)
    8000467c:	e50fd0ef          	jal	80001ccc <fetchstr>
    80004680:	00054663          	bltz	a0,8000468c <sys_exec+0x92>
    if(i >= NELEM(argv)){
    80004684:	0905                	addi	s2,s2,1
    80004686:	09a1                	addi	s3,s3,8
    80004688:	fd7914e3          	bne	s2,s7,80004650 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000468c:	100a0a13          	addi	s4,s4,256
    80004690:	6088                	ld	a0,0(s1)
    80004692:	cd31                	beqz	a0,800046ee <sys_exec+0xf4>
    kfree(argv[i]);
    80004694:	989fb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004698:	04a1                	addi	s1,s1,8
    8000469a:	ff449be3          	bne	s1,s4,80004690 <sys_exec+0x96>
  return -1;
    8000469e:	557d                	li	a0,-1
    800046a0:	64be                	ld	s1,456(sp)
    800046a2:	691e                	ld	s2,448(sp)
    800046a4:	79fa                	ld	s3,440(sp)
    800046a6:	7a5a                	ld	s4,432(sp)
    800046a8:	7aba                	ld	s5,424(sp)
    800046aa:	7b1a                	ld	s6,416(sp)
    800046ac:	6bfa                	ld	s7,408(sp)
    800046ae:	a881                	j	800046fe <sys_exec+0x104>
      argv[i] = 0;
    800046b0:	0009079b          	sext.w	a5,s2
    800046b4:	e3040593          	addi	a1,s0,-464
    800046b8:	078e                	slli	a5,a5,0x3
    800046ba:	97ae                	add	a5,a5,a1
    800046bc:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    800046c0:	f3040513          	addi	a0,s0,-208
    800046c4:	bb2ff0ef          	jal	80003a76 <exec>
    800046c8:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046ca:	100a0a13          	addi	s4,s4,256
    800046ce:	6088                	ld	a0,0(s1)
    800046d0:	c511                	beqz	a0,800046dc <sys_exec+0xe2>
    kfree(argv[i]);
    800046d2:	94bfb0ef          	jal	8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046d6:	04a1                	addi	s1,s1,8
    800046d8:	ff449be3          	bne	s1,s4,800046ce <sys_exec+0xd4>
  return ret;
    800046dc:	854a                	mv	a0,s2
    800046de:	64be                	ld	s1,456(sp)
    800046e0:	691e                	ld	s2,448(sp)
    800046e2:	79fa                	ld	s3,440(sp)
    800046e4:	7a5a                	ld	s4,432(sp)
    800046e6:	7aba                	ld	s5,424(sp)
    800046e8:	7b1a                	ld	s6,416(sp)
    800046ea:	6bfa                	ld	s7,408(sp)
    800046ec:	a809                	j	800046fe <sys_exec+0x104>
  return -1;
    800046ee:	557d                	li	a0,-1
    800046f0:	64be                	ld	s1,456(sp)
    800046f2:	691e                	ld	s2,448(sp)
    800046f4:	79fa                	ld	s3,440(sp)
    800046f6:	7a5a                	ld	s4,432(sp)
    800046f8:	7aba                	ld	s5,424(sp)
    800046fa:	7b1a                	ld	s6,416(sp)
    800046fc:	6bfa                	ld	s7,408(sp)
}
    800046fe:	60fe                	ld	ra,472(sp)
    80004700:	645e                	ld	s0,464(sp)
    80004702:	613d                	addi	sp,sp,480
    80004704:	8082                	ret

0000000080004706 <sys_pipe>:

uint64
sys_pipe(void)
{
    80004706:	7139                	addi	sp,sp,-64
    80004708:	fc06                	sd	ra,56(sp)
    8000470a:	f822                	sd	s0,48(sp)
    8000470c:	f426                	sd	s1,40(sp)
    8000470e:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80004710:	e72fc0ef          	jal	80000d82 <myproc>
    80004714:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80004716:	fd840593          	addi	a1,s0,-40
    8000471a:	4501                	li	a0,0
    8000471c:	e0cfd0ef          	jal	80001d28 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80004720:	fc840593          	addi	a1,s0,-56
    80004724:	fd040513          	addi	a0,s0,-48
    80004728:	828ff0ef          	jal	80003750 <pipealloc>
    return -1;
    8000472c:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    8000472e:	0a054763          	bltz	a0,800047dc <sys_pipe+0xd6>
  fd0 = -1;
    80004732:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80004736:	fd043503          	ld	a0,-48(s0)
    8000473a:	ef2ff0ef          	jal	80003e2c <fdalloc>
    8000473e:	fca42223          	sw	a0,-60(s0)
    80004742:	08054463          	bltz	a0,800047ca <sys_pipe+0xc4>
    80004746:	fc843503          	ld	a0,-56(s0)
    8000474a:	ee2ff0ef          	jal	80003e2c <fdalloc>
    8000474e:	fca42023          	sw	a0,-64(s0)
    80004752:	06054263          	bltz	a0,800047b6 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004756:	4691                	li	a3,4
    80004758:	fc440613          	addi	a2,s0,-60
    8000475c:	fd843583          	ld	a1,-40(s0)
    80004760:	68a8                	ld	a0,80(s1)
    80004762:	aa0fc0ef          	jal	80000a02 <copyout>
    80004766:	00054e63          	bltz	a0,80004782 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    8000476a:	4691                	li	a3,4
    8000476c:	fc040613          	addi	a2,s0,-64
    80004770:	fd843583          	ld	a1,-40(s0)
    80004774:	95b6                	add	a1,a1,a3
    80004776:	68a8                	ld	a0,80(s1)
    80004778:	a8afc0ef          	jal	80000a02 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    8000477c:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000477e:	04055f63          	bgez	a0,800047dc <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    80004782:	fc442783          	lw	a5,-60(s0)
    80004786:	078e                	slli	a5,a5,0x3
    80004788:	0d078793          	addi	a5,a5,208
    8000478c:	97a6                	add	a5,a5,s1
    8000478e:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80004792:	fc042783          	lw	a5,-64(s0)
    80004796:	078e                	slli	a5,a5,0x3
    80004798:	0d078793          	addi	a5,a5,208
    8000479c:	97a6                	add	a5,a5,s1
    8000479e:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800047a2:	fd043503          	ld	a0,-48(s0)
    800047a6:	c8ffe0ef          	jal	80003434 <fileclose>
    fileclose(wf);
    800047aa:	fc843503          	ld	a0,-56(s0)
    800047ae:	c87fe0ef          	jal	80003434 <fileclose>
    return -1;
    800047b2:	57fd                	li	a5,-1
    800047b4:	a025                	j	800047dc <sys_pipe+0xd6>
    if(fd0 >= 0)
    800047b6:	fc442783          	lw	a5,-60(s0)
    800047ba:	0007c863          	bltz	a5,800047ca <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    800047be:	078e                	slli	a5,a5,0x3
    800047c0:	0d078793          	addi	a5,a5,208
    800047c4:	97a6                	add	a5,a5,s1
    800047c6:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800047ca:	fd043503          	ld	a0,-48(s0)
    800047ce:	c67fe0ef          	jal	80003434 <fileclose>
    fileclose(wf);
    800047d2:	fc843503          	ld	a0,-56(s0)
    800047d6:	c5ffe0ef          	jal	80003434 <fileclose>
    return -1;
    800047da:	57fd                	li	a5,-1
}
    800047dc:	853e                	mv	a0,a5
    800047de:	70e2                	ld	ra,56(sp)
    800047e0:	7442                	ld	s0,48(sp)
    800047e2:	74a2                	ld	s1,40(sp)
    800047e4:	6121                	addi	sp,sp,64
    800047e6:	8082                	ret
	...

00000000800047f0 <kernelvec>:
    800047f0:	7111                	addi	sp,sp,-256
    800047f2:	e006                	sd	ra,0(sp)
    800047f4:	e40a                	sd	sp,8(sp)
    800047f6:	e80e                	sd	gp,16(sp)
    800047f8:	ec12                	sd	tp,24(sp)
    800047fa:	f016                	sd	t0,32(sp)
    800047fc:	f41a                	sd	t1,40(sp)
    800047fe:	f81e                	sd	t2,48(sp)
    80004800:	e4aa                	sd	a0,72(sp)
    80004802:	e8ae                	sd	a1,80(sp)
    80004804:	ecb2                	sd	a2,88(sp)
    80004806:	f0b6                	sd	a3,96(sp)
    80004808:	f4ba                	sd	a4,104(sp)
    8000480a:	f8be                	sd	a5,112(sp)
    8000480c:	fcc2                	sd	a6,120(sp)
    8000480e:	e146                	sd	a7,128(sp)
    80004810:	edf2                	sd	t3,216(sp)
    80004812:	f1f6                	sd	t4,224(sp)
    80004814:	f5fa                	sd	t5,232(sp)
    80004816:	f9fe                	sd	t6,240(sp)
    80004818:	b78fd0ef          	jal	80001b90 <kerneltrap>
    8000481c:	6082                	ld	ra,0(sp)
    8000481e:	6122                	ld	sp,8(sp)
    80004820:	61c2                	ld	gp,16(sp)
    80004822:	7282                	ld	t0,32(sp)
    80004824:	7322                	ld	t1,40(sp)
    80004826:	73c2                	ld	t2,48(sp)
    80004828:	6526                	ld	a0,72(sp)
    8000482a:	65c6                	ld	a1,80(sp)
    8000482c:	6666                	ld	a2,88(sp)
    8000482e:	7686                	ld	a3,96(sp)
    80004830:	7726                	ld	a4,104(sp)
    80004832:	77c6                	ld	a5,112(sp)
    80004834:	7866                	ld	a6,120(sp)
    80004836:	688a                	ld	a7,128(sp)
    80004838:	6e6e                	ld	t3,216(sp)
    8000483a:	7e8e                	ld	t4,224(sp)
    8000483c:	7f2e                	ld	t5,232(sp)
    8000483e:	7fce                	ld	t6,240(sp)
    80004840:	6111                	addi	sp,sp,256
    80004842:	10200073          	sret
    80004846:	00000013          	nop
    8000484a:	00000013          	nop

000000008000484e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000484e:	1141                	addi	sp,sp,-16
    80004850:	e406                	sd	ra,8(sp)
    80004852:	e022                	sd	s0,0(sp)
    80004854:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004856:	0c000737          	lui	a4,0xc000
    8000485a:	4785                	li	a5,1
    8000485c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000485e:	c35c                	sw	a5,4(a4)
}
    80004860:	60a2                	ld	ra,8(sp)
    80004862:	6402                	ld	s0,0(sp)
    80004864:	0141                	addi	sp,sp,16
    80004866:	8082                	ret

0000000080004868 <plicinithart>:

void
plicinithart(void)
{
    80004868:	1141                	addi	sp,sp,-16
    8000486a:	e406                	sd	ra,8(sp)
    8000486c:	e022                	sd	s0,0(sp)
    8000486e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004870:	cdefc0ef          	jal	80000d4e <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80004874:	0085171b          	slliw	a4,a0,0x8
    80004878:	0c0027b7          	lui	a5,0xc002
    8000487c:	97ba                	add	a5,a5,a4
    8000487e:	40200713          	li	a4,1026
    80004882:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80004886:	00d5151b          	slliw	a0,a0,0xd
    8000488a:	0c2017b7          	lui	a5,0xc201
    8000488e:	97aa                	add	a5,a5,a0
    80004890:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80004894:	60a2                	ld	ra,8(sp)
    80004896:	6402                	ld	s0,0(sp)
    80004898:	0141                	addi	sp,sp,16
    8000489a:	8082                	ret

000000008000489c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000489c:	1141                	addi	sp,sp,-16
    8000489e:	e406                	sd	ra,8(sp)
    800048a0:	e022                	sd	s0,0(sp)
    800048a2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800048a4:	caafc0ef          	jal	80000d4e <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800048a8:	00d5151b          	slliw	a0,a0,0xd
    800048ac:	0c2017b7          	lui	a5,0xc201
    800048b0:	97aa                	add	a5,a5,a0
  return irq;
}
    800048b2:	43c8                	lw	a0,4(a5)
    800048b4:	60a2                	ld	ra,8(sp)
    800048b6:	6402                	ld	s0,0(sp)
    800048b8:	0141                	addi	sp,sp,16
    800048ba:	8082                	ret

00000000800048bc <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800048bc:	1101                	addi	sp,sp,-32
    800048be:	ec06                	sd	ra,24(sp)
    800048c0:	e822                	sd	s0,16(sp)
    800048c2:	e426                	sd	s1,8(sp)
    800048c4:	1000                	addi	s0,sp,32
    800048c6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800048c8:	c86fc0ef          	jal	80000d4e <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800048cc:	00d5179b          	slliw	a5,a0,0xd
    800048d0:	0c201737          	lui	a4,0xc201
    800048d4:	97ba                	add	a5,a5,a4
    800048d6:	c3c4                	sw	s1,4(a5)
}
    800048d8:	60e2                	ld	ra,24(sp)
    800048da:	6442                	ld	s0,16(sp)
    800048dc:	64a2                	ld	s1,8(sp)
    800048de:	6105                	addi	sp,sp,32
    800048e0:	8082                	ret

00000000800048e2 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800048e2:	1141                	addi	sp,sp,-16
    800048e4:	e406                	sd	ra,8(sp)
    800048e6:	e022                	sd	s0,0(sp)
    800048e8:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800048ea:	479d                	li	a5,7
    800048ec:	04a7ca63          	blt	a5,a0,80004940 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800048f0:	00015797          	auipc	a5,0x15
    800048f4:	b3078793          	addi	a5,a5,-1232 # 80019420 <disk>
    800048f8:	97aa                	add	a5,a5,a0
    800048fa:	0187c783          	lbu	a5,24(a5)
    800048fe:	e7b9                	bnez	a5,8000494c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80004900:	00451693          	slli	a3,a0,0x4
    80004904:	00015797          	auipc	a5,0x15
    80004908:	b1c78793          	addi	a5,a5,-1252 # 80019420 <disk>
    8000490c:	6398                	ld	a4,0(a5)
    8000490e:	9736                	add	a4,a4,a3
    80004910:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80004914:	6398                	ld	a4,0(a5)
    80004916:	9736                	add	a4,a4,a3
    80004918:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000491c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80004920:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004924:	97aa                	add	a5,a5,a0
    80004926:	4705                	li	a4,1
    80004928:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000492c:	00015517          	auipc	a0,0x15
    80004930:	b0c50513          	addi	a0,a0,-1268 # 80019438 <disk+0x18>
    80004934:	a9ffc0ef          	jal	800013d2 <wakeup>
}
    80004938:	60a2                	ld	ra,8(sp)
    8000493a:	6402                	ld	s0,0(sp)
    8000493c:	0141                	addi	sp,sp,16
    8000493e:	8082                	ret
    panic("free_desc 1");
    80004940:	00003517          	auipc	a0,0x3
    80004944:	cd050513          	addi	a0,a0,-816 # 80007610 <etext+0x610>
    80004948:	4e1000ef          	jal	80005628 <panic>
    panic("free_desc 2");
    8000494c:	00003517          	auipc	a0,0x3
    80004950:	cd450513          	addi	a0,a0,-812 # 80007620 <etext+0x620>
    80004954:	4d5000ef          	jal	80005628 <panic>

0000000080004958 <virtio_disk_init>:
{
    80004958:	1101                	addi	sp,sp,-32
    8000495a:	ec06                	sd	ra,24(sp)
    8000495c:	e822                	sd	s0,16(sp)
    8000495e:	e426                	sd	s1,8(sp)
    80004960:	e04a                	sd	s2,0(sp)
    80004962:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004964:	00003597          	auipc	a1,0x3
    80004968:	ccc58593          	addi	a1,a1,-820 # 80007630 <etext+0x630>
    8000496c:	00015517          	auipc	a0,0x15
    80004970:	bdc50513          	addi	a0,a0,-1060 # 80019548 <disk+0x128>
    80004974:	73f000ef          	jal	800058b2 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004978:	100017b7          	lui	a5,0x10001
    8000497c:	4398                	lw	a4,0(a5)
    8000497e:	2701                	sext.w	a4,a4
    80004980:	747277b7          	lui	a5,0x74727
    80004984:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80004988:	14f71863          	bne	a4,a5,80004ad8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000498c:	100017b7          	lui	a5,0x10001
    80004990:	43dc                	lw	a5,4(a5)
    80004992:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004994:	4709                	li	a4,2
    80004996:	14e79163          	bne	a5,a4,80004ad8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000499a:	100017b7          	lui	a5,0x10001
    8000499e:	479c                	lw	a5,8(a5)
    800049a0:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800049a2:	12e79b63          	bne	a5,a4,80004ad8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800049a6:	100017b7          	lui	a5,0x10001
    800049aa:	47d8                	lw	a4,12(a5)
    800049ac:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800049ae:	554d47b7          	lui	a5,0x554d4
    800049b2:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800049b6:	12f71163          	bne	a4,a5,80004ad8 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    800049ba:	100017b7          	lui	a5,0x10001
    800049be:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800049c2:	4705                	li	a4,1
    800049c4:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049c6:	470d                	li	a4,3
    800049c8:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800049ca:	10001737          	lui	a4,0x10001
    800049ce:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800049d0:	c7ffe6b7          	lui	a3,0xc7ffe
    800049d4:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd0ff>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800049d8:	8f75                	and	a4,a4,a3
    800049da:	100016b7          	lui	a3,0x10001
    800049de:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049e0:	472d                	li	a4,11
    800049e2:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049e4:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    800049e8:	439c                	lw	a5,0(a5)
    800049ea:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800049ee:	8ba1                	andi	a5,a5,8
    800049f0:	0e078a63          	beqz	a5,80004ae4 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800049f4:	100017b7          	lui	a5,0x10001
    800049f8:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    800049fc:	43fc                	lw	a5,68(a5)
    800049fe:	2781                	sext.w	a5,a5
    80004a00:	0e079863          	bnez	a5,80004af0 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80004a04:	100017b7          	lui	a5,0x10001
    80004a08:	5bdc                	lw	a5,52(a5)
    80004a0a:	2781                	sext.w	a5,a5
  if(max == 0)
    80004a0c:	0e078863          	beqz	a5,80004afc <virtio_disk_init+0x1a4>
  if(max < NUM)
    80004a10:	471d                	li	a4,7
    80004a12:	0ef77b63          	bgeu	a4,a5,80004b08 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80004a16:	eeefb0ef          	jal	80000104 <kalloc>
    80004a1a:	00015497          	auipc	s1,0x15
    80004a1e:	a0648493          	addi	s1,s1,-1530 # 80019420 <disk>
    80004a22:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004a24:	ee0fb0ef          	jal	80000104 <kalloc>
    80004a28:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004a2a:	edafb0ef          	jal	80000104 <kalloc>
    80004a2e:	87aa                	mv	a5,a0
    80004a30:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004a32:	6088                	ld	a0,0(s1)
    80004a34:	0e050063          	beqz	a0,80004b14 <virtio_disk_init+0x1bc>
    80004a38:	00015717          	auipc	a4,0x15
    80004a3c:	9f073703          	ld	a4,-1552(a4) # 80019428 <disk+0x8>
    80004a40:	cb71                	beqz	a4,80004b14 <virtio_disk_init+0x1bc>
    80004a42:	cbe9                	beqz	a5,80004b14 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80004a44:	6605                	lui	a2,0x1
    80004a46:	4581                	li	a1,0
    80004a48:	f16fb0ef          	jal	8000015e <memset>
  memset(disk.avail, 0, PGSIZE);
    80004a4c:	00015497          	auipc	s1,0x15
    80004a50:	9d448493          	addi	s1,s1,-1580 # 80019420 <disk>
    80004a54:	6605                	lui	a2,0x1
    80004a56:	4581                	li	a1,0
    80004a58:	6488                	ld	a0,8(s1)
    80004a5a:	f04fb0ef          	jal	8000015e <memset>
  memset(disk.used, 0, PGSIZE);
    80004a5e:	6605                	lui	a2,0x1
    80004a60:	4581                	li	a1,0
    80004a62:	6888                	ld	a0,16(s1)
    80004a64:	efafb0ef          	jal	8000015e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004a68:	100017b7          	lui	a5,0x10001
    80004a6c:	4721                	li	a4,8
    80004a6e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004a70:	4098                	lw	a4,0(s1)
    80004a72:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004a76:	40d8                	lw	a4,4(s1)
    80004a78:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80004a7c:	649c                	ld	a5,8(s1)
    80004a7e:	0007869b          	sext.w	a3,a5
    80004a82:	10001737          	lui	a4,0x10001
    80004a86:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80004a8a:	9781                	srai	a5,a5,0x20
    80004a8c:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80004a90:	689c                	ld	a5,16(s1)
    80004a92:	0007869b          	sext.w	a3,a5
    80004a96:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80004a9a:	9781                	srai	a5,a5,0x20
    80004a9c:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80004aa0:	4785                	li	a5,1
    80004aa2:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80004aa4:	00f48c23          	sb	a5,24(s1)
    80004aa8:	00f48ca3          	sb	a5,25(s1)
    80004aac:	00f48d23          	sb	a5,26(s1)
    80004ab0:	00f48da3          	sb	a5,27(s1)
    80004ab4:	00f48e23          	sb	a5,28(s1)
    80004ab8:	00f48ea3          	sb	a5,29(s1)
    80004abc:	00f48f23          	sb	a5,30(s1)
    80004ac0:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80004ac4:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80004ac8:	07272823          	sw	s2,112(a4)
}
    80004acc:	60e2                	ld	ra,24(sp)
    80004ace:	6442                	ld	s0,16(sp)
    80004ad0:	64a2                	ld	s1,8(sp)
    80004ad2:	6902                	ld	s2,0(sp)
    80004ad4:	6105                	addi	sp,sp,32
    80004ad6:	8082                	ret
    panic("could not find virtio disk");
    80004ad8:	00003517          	auipc	a0,0x3
    80004adc:	b6850513          	addi	a0,a0,-1176 # 80007640 <etext+0x640>
    80004ae0:	349000ef          	jal	80005628 <panic>
    panic("virtio disk FEATURES_OK unset");
    80004ae4:	00003517          	auipc	a0,0x3
    80004ae8:	b7c50513          	addi	a0,a0,-1156 # 80007660 <etext+0x660>
    80004aec:	33d000ef          	jal	80005628 <panic>
    panic("virtio disk should not be ready");
    80004af0:	00003517          	auipc	a0,0x3
    80004af4:	b9050513          	addi	a0,a0,-1136 # 80007680 <etext+0x680>
    80004af8:	331000ef          	jal	80005628 <panic>
    panic("virtio disk has no queue 0");
    80004afc:	00003517          	auipc	a0,0x3
    80004b00:	ba450513          	addi	a0,a0,-1116 # 800076a0 <etext+0x6a0>
    80004b04:	325000ef          	jal	80005628 <panic>
    panic("virtio disk max queue too short");
    80004b08:	00003517          	auipc	a0,0x3
    80004b0c:	bb850513          	addi	a0,a0,-1096 # 800076c0 <etext+0x6c0>
    80004b10:	319000ef          	jal	80005628 <panic>
    panic("virtio disk kalloc");
    80004b14:	00003517          	auipc	a0,0x3
    80004b18:	bcc50513          	addi	a0,a0,-1076 # 800076e0 <etext+0x6e0>
    80004b1c:	30d000ef          	jal	80005628 <panic>

0000000080004b20 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004b20:	711d                	addi	sp,sp,-96
    80004b22:	ec86                	sd	ra,88(sp)
    80004b24:	e8a2                	sd	s0,80(sp)
    80004b26:	e4a6                	sd	s1,72(sp)
    80004b28:	e0ca                	sd	s2,64(sp)
    80004b2a:	fc4e                	sd	s3,56(sp)
    80004b2c:	f852                	sd	s4,48(sp)
    80004b2e:	f456                	sd	s5,40(sp)
    80004b30:	f05a                	sd	s6,32(sp)
    80004b32:	ec5e                	sd	s7,24(sp)
    80004b34:	e862                	sd	s8,16(sp)
    80004b36:	1080                	addi	s0,sp,96
    80004b38:	89aa                	mv	s3,a0
    80004b3a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004b3c:	00c52b83          	lw	s7,12(a0)
    80004b40:	001b9b9b          	slliw	s7,s7,0x1
    80004b44:	1b82                	slli	s7,s7,0x20
    80004b46:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80004b4a:	00015517          	auipc	a0,0x15
    80004b4e:	9fe50513          	addi	a0,a0,-1538 # 80019548 <disk+0x128>
    80004b52:	5eb000ef          	jal	8000593c <acquire>
  for(int i = 0; i < NUM; i++){
    80004b56:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004b58:	00015a97          	auipc	s5,0x15
    80004b5c:	8c8a8a93          	addi	s5,s5,-1848 # 80019420 <disk>
  for(int i = 0; i < 3; i++){
    80004b60:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80004b62:	5c7d                	li	s8,-1
    80004b64:	a095                	j	80004bc8 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80004b66:	00fa8733          	add	a4,s5,a5
    80004b6a:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004b6e:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004b70:	0207c563          	bltz	a5,80004b9a <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80004b74:	2905                	addiw	s2,s2,1
    80004b76:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80004b78:	05490c63          	beq	s2,s4,80004bd0 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    80004b7c:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004b7e:	00015717          	auipc	a4,0x15
    80004b82:	8a270713          	addi	a4,a4,-1886 # 80019420 <disk>
    80004b86:	4781                	li	a5,0
    if(disk.free[i]){
    80004b88:	01874683          	lbu	a3,24(a4)
    80004b8c:	fee9                	bnez	a3,80004b66 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80004b8e:	2785                	addiw	a5,a5,1
    80004b90:	0705                	addi	a4,a4,1
    80004b92:	fe979be3          	bne	a5,s1,80004b88 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80004b96:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80004b9a:	01205d63          	blez	s2,80004bb4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004b9e:	fa042503          	lw	a0,-96(s0)
    80004ba2:	d41ff0ef          	jal	800048e2 <free_desc>
      for(int j = 0; j < i; j++)
    80004ba6:	4785                	li	a5,1
    80004ba8:	0127d663          	bge	a5,s2,80004bb4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80004bac:	fa442503          	lw	a0,-92(s0)
    80004bb0:	d33ff0ef          	jal	800048e2 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004bb4:	00015597          	auipc	a1,0x15
    80004bb8:	99458593          	addi	a1,a1,-1644 # 80019548 <disk+0x128>
    80004bbc:	00015517          	auipc	a0,0x15
    80004bc0:	87c50513          	addi	a0,a0,-1924 # 80019438 <disk+0x18>
    80004bc4:	fc2fc0ef          	jal	80001386 <sleep>
  for(int i = 0; i < 3; i++){
    80004bc8:	fa040613          	addi	a2,s0,-96
    80004bcc:	4901                	li	s2,0
    80004bce:	b77d                	j	80004b7c <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004bd0:	fa042503          	lw	a0,-96(s0)
    80004bd4:	00451693          	slli	a3,a0,0x4

  if(write)
    80004bd8:	00015797          	auipc	a5,0x15
    80004bdc:	84878793          	addi	a5,a5,-1976 # 80019420 <disk>
    80004be0:	00451713          	slli	a4,a0,0x4
    80004be4:	0a070713          	addi	a4,a4,160
    80004be8:	973e                	add	a4,a4,a5
    80004bea:	01603633          	snez	a2,s6
    80004bee:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004bf0:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004bf4:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004bf8:	6398                	ld	a4,0(a5)
    80004bfa:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004bfc:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80004c00:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004c02:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004c04:	6390                	ld	a2,0(a5)
    80004c06:	00d60833          	add	a6,a2,a3
    80004c0a:	4741                	li	a4,16
    80004c0c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004c10:	4585                	li	a1,1
    80004c12:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80004c16:	fa442703          	lw	a4,-92(s0)
    80004c1a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004c1e:	0712                	slli	a4,a4,0x4
    80004c20:	963a                	add	a2,a2,a4
    80004c22:	05898813          	addi	a6,s3,88
    80004c26:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80004c2a:	0007b883          	ld	a7,0(a5)
    80004c2e:	9746                	add	a4,a4,a7
    80004c30:	40000613          	li	a2,1024
    80004c34:	c710                	sw	a2,8(a4)
  if(write)
    80004c36:	001b3613          	seqz	a2,s6
    80004c3a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004c3e:	8e4d                	or	a2,a2,a1
    80004c40:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004c44:	fa842603          	lw	a2,-88(s0)
    80004c48:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004c4c:	00451813          	slli	a6,a0,0x4
    80004c50:	02080813          	addi	a6,a6,32
    80004c54:	983e                	add	a6,a6,a5
    80004c56:	577d                	li	a4,-1
    80004c58:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004c5c:	0612                	slli	a2,a2,0x4
    80004c5e:	98b2                	add	a7,a7,a2
    80004c60:	03068713          	addi	a4,a3,48
    80004c64:	973e                	add	a4,a4,a5
    80004c66:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80004c6a:	6398                	ld	a4,0(a5)
    80004c6c:	9732                	add	a4,a4,a2
    80004c6e:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004c70:	4689                	li	a3,2
    80004c72:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80004c76:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004c7a:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80004c7e:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004c82:	6794                	ld	a3,8(a5)
    80004c84:	0026d703          	lhu	a4,2(a3)
    80004c88:	8b1d                	andi	a4,a4,7
    80004c8a:	0706                	slli	a4,a4,0x1
    80004c8c:	96ba                	add	a3,a3,a4
    80004c8e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80004c92:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004c96:	6798                	ld	a4,8(a5)
    80004c98:	00275783          	lhu	a5,2(a4)
    80004c9c:	2785                	addiw	a5,a5,1
    80004c9e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004ca2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004ca6:	100017b7          	lui	a5,0x10001
    80004caa:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004cae:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80004cb2:	00015917          	auipc	s2,0x15
    80004cb6:	89690913          	addi	s2,s2,-1898 # 80019548 <disk+0x128>
  while(b->disk == 1) {
    80004cba:	84ae                	mv	s1,a1
    80004cbc:	00b79a63          	bne	a5,a1,80004cd0 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80004cc0:	85ca                	mv	a1,s2
    80004cc2:	854e                	mv	a0,s3
    80004cc4:	ec2fc0ef          	jal	80001386 <sleep>
  while(b->disk == 1) {
    80004cc8:	0049a783          	lw	a5,4(s3)
    80004ccc:	fe978ae3          	beq	a5,s1,80004cc0 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80004cd0:	fa042903          	lw	s2,-96(s0)
    80004cd4:	00491713          	slli	a4,s2,0x4
    80004cd8:	02070713          	addi	a4,a4,32
    80004cdc:	00014797          	auipc	a5,0x14
    80004ce0:	74478793          	addi	a5,a5,1860 # 80019420 <disk>
    80004ce4:	97ba                	add	a5,a5,a4
    80004ce6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004cea:	00014997          	auipc	s3,0x14
    80004cee:	73698993          	addi	s3,s3,1846 # 80019420 <disk>
    80004cf2:	00491713          	slli	a4,s2,0x4
    80004cf6:	0009b783          	ld	a5,0(s3)
    80004cfa:	97ba                	add	a5,a5,a4
    80004cfc:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004d00:	854a                	mv	a0,s2
    80004d02:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004d06:	bddff0ef          	jal	800048e2 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004d0a:	8885                	andi	s1,s1,1
    80004d0c:	f0fd                	bnez	s1,80004cf2 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004d0e:	00015517          	auipc	a0,0x15
    80004d12:	83a50513          	addi	a0,a0,-1990 # 80019548 <disk+0x128>
    80004d16:	4bb000ef          	jal	800059d0 <release>
}
    80004d1a:	60e6                	ld	ra,88(sp)
    80004d1c:	6446                	ld	s0,80(sp)
    80004d1e:	64a6                	ld	s1,72(sp)
    80004d20:	6906                	ld	s2,64(sp)
    80004d22:	79e2                	ld	s3,56(sp)
    80004d24:	7a42                	ld	s4,48(sp)
    80004d26:	7aa2                	ld	s5,40(sp)
    80004d28:	7b02                	ld	s6,32(sp)
    80004d2a:	6be2                	ld	s7,24(sp)
    80004d2c:	6c42                	ld	s8,16(sp)
    80004d2e:	6125                	addi	sp,sp,96
    80004d30:	8082                	ret

0000000080004d32 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004d32:	1101                	addi	sp,sp,-32
    80004d34:	ec06                	sd	ra,24(sp)
    80004d36:	e822                	sd	s0,16(sp)
    80004d38:	e426                	sd	s1,8(sp)
    80004d3a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004d3c:	00014497          	auipc	s1,0x14
    80004d40:	6e448493          	addi	s1,s1,1764 # 80019420 <disk>
    80004d44:	00015517          	auipc	a0,0x15
    80004d48:	80450513          	addi	a0,a0,-2044 # 80019548 <disk+0x128>
    80004d4c:	3f1000ef          	jal	8000593c <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004d50:	100017b7          	lui	a5,0x10001
    80004d54:	53bc                	lw	a5,96(a5)
    80004d56:	8b8d                	andi	a5,a5,3
    80004d58:	10001737          	lui	a4,0x10001
    80004d5c:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004d5e:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004d62:	689c                	ld	a5,16(s1)
    80004d64:	0204d703          	lhu	a4,32(s1)
    80004d68:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80004d6c:	04f70863          	beq	a4,a5,80004dbc <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80004d70:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004d74:	6898                	ld	a4,16(s1)
    80004d76:	0204d783          	lhu	a5,32(s1)
    80004d7a:	8b9d                	andi	a5,a5,7
    80004d7c:	078e                	slli	a5,a5,0x3
    80004d7e:	97ba                	add	a5,a5,a4
    80004d80:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004d82:	00479713          	slli	a4,a5,0x4
    80004d86:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80004d8a:	9726                	add	a4,a4,s1
    80004d8c:	01074703          	lbu	a4,16(a4)
    80004d90:	e329                	bnez	a4,80004dd2 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004d92:	0792                	slli	a5,a5,0x4
    80004d94:	02078793          	addi	a5,a5,32
    80004d98:	97a6                	add	a5,a5,s1
    80004d9a:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004d9c:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004da0:	e32fc0ef          	jal	800013d2 <wakeup>

    disk.used_idx += 1;
    80004da4:	0204d783          	lhu	a5,32(s1)
    80004da8:	2785                	addiw	a5,a5,1
    80004daa:	17c2                	slli	a5,a5,0x30
    80004dac:	93c1                	srli	a5,a5,0x30
    80004dae:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004db2:	6898                	ld	a4,16(s1)
    80004db4:	00275703          	lhu	a4,2(a4)
    80004db8:	faf71ce3          	bne	a4,a5,80004d70 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80004dbc:	00014517          	auipc	a0,0x14
    80004dc0:	78c50513          	addi	a0,a0,1932 # 80019548 <disk+0x128>
    80004dc4:	40d000ef          	jal	800059d0 <release>
}
    80004dc8:	60e2                	ld	ra,24(sp)
    80004dca:	6442                	ld	s0,16(sp)
    80004dcc:	64a2                	ld	s1,8(sp)
    80004dce:	6105                	addi	sp,sp,32
    80004dd0:	8082                	ret
      panic("virtio_disk_intr status");
    80004dd2:	00003517          	auipc	a0,0x3
    80004dd6:	92650513          	addi	a0,a0,-1754 # 800076f8 <etext+0x6f8>
    80004dda:	04f000ef          	jal	80005628 <panic>

0000000080004dde <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80004dde:	1141                	addi	sp,sp,-16
    80004de0:	e406                	sd	ra,8(sp)
    80004de2:	e022                	sd	s0,0(sp)
    80004de4:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80004de6:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80004dea:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80004dee:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80004df2:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80004df6:	577d                	li	a4,-1
    80004df8:	177e                	slli	a4,a4,0x3f
    80004dfa:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80004dfc:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80004e00:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80004e04:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80004e08:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80004e0c:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80004e10:	000f4737          	lui	a4,0xf4
    80004e14:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80004e18:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80004e1a:	14d79073          	csrw	stimecmp,a5
}
    80004e1e:	60a2                	ld	ra,8(sp)
    80004e20:	6402                	ld	s0,0(sp)
    80004e22:	0141                	addi	sp,sp,16
    80004e24:	8082                	ret

0000000080004e26 <start>:
{
    80004e26:	1141                	addi	sp,sp,-16
    80004e28:	e406                	sd	ra,8(sp)
    80004e2a:	e022                	sd	s0,0(sp)
    80004e2c:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80004e2e:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80004e32:	7779                	lui	a4,0xffffe
    80004e34:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd19f>
    80004e38:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80004e3a:	6705                	lui	a4,0x1
    80004e3c:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80004e40:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80004e42:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80004e46:	ffffb797          	auipc	a5,0xffffb
    80004e4a:	4ce78793          	addi	a5,a5,1230 # 80000314 <main>
    80004e4e:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80004e52:	4781                	li	a5,0
    80004e54:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80004e58:	67c1                	lui	a5,0x10
    80004e5a:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80004e5c:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80004e60:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80004e64:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80004e68:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80004e6c:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80004e70:	57fd                	li	a5,-1
    80004e72:	83a9                	srli	a5,a5,0xa
    80004e74:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80004e78:	47bd                	li	a5,15
    80004e7a:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80004e7e:	f61ff0ef          	jal	80004dde <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80004e82:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80004e86:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80004e88:	823e                	mv	tp,a5
  asm volatile("mret");
    80004e8a:	30200073          	mret
}
    80004e8e:	60a2                	ld	ra,8(sp)
    80004e90:	6402                	ld	s0,0(sp)
    80004e92:	0141                	addi	sp,sp,16
    80004e94:	8082                	ret

0000000080004e96 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80004e96:	711d                	addi	sp,sp,-96
    80004e98:	ec86                	sd	ra,88(sp)
    80004e9a:	e8a2                	sd	s0,80(sp)
    80004e9c:	e0ca                	sd	s2,64(sp)
    80004e9e:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    80004ea0:	04c05763          	blez	a2,80004eee <consolewrite+0x58>
    80004ea4:	e4a6                	sd	s1,72(sp)
    80004ea6:	fc4e                	sd	s3,56(sp)
    80004ea8:	f852                	sd	s4,48(sp)
    80004eaa:	f456                	sd	s5,40(sp)
    80004eac:	f05a                	sd	s6,32(sp)
    80004eae:	ec5e                	sd	s7,24(sp)
    80004eb0:	8a2a                	mv	s4,a0
    80004eb2:	84ae                	mv	s1,a1
    80004eb4:	89b2                	mv	s3,a2
    80004eb6:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80004eb8:	faf40b93          	addi	s7,s0,-81
    80004ebc:	4b05                	li	s6,1
    80004ebe:	5afd                	li	s5,-1
    80004ec0:	86da                	mv	a3,s6
    80004ec2:	8626                	mv	a2,s1
    80004ec4:	85d2                	mv	a1,s4
    80004ec6:	855e                	mv	a0,s7
    80004ec8:	863fc0ef          	jal	8000172a <either_copyin>
    80004ecc:	03550363          	beq	a0,s5,80004ef2 <consolewrite+0x5c>
      break;
    uartputc(c);
    80004ed0:	faf44503          	lbu	a0,-81(s0)
    80004ed4:	0cb000ef          	jal	8000579e <uartputc>
  for(i = 0; i < n; i++){
    80004ed8:	2905                	addiw	s2,s2,1
    80004eda:	0485                	addi	s1,s1,1
    80004edc:	ff2992e3          	bne	s3,s2,80004ec0 <consolewrite+0x2a>
    80004ee0:	64a6                	ld	s1,72(sp)
    80004ee2:	79e2                	ld	s3,56(sp)
    80004ee4:	7a42                	ld	s4,48(sp)
    80004ee6:	7aa2                	ld	s5,40(sp)
    80004ee8:	7b02                	ld	s6,32(sp)
    80004eea:	6be2                	ld	s7,24(sp)
    80004eec:	a809                	j	80004efe <consolewrite+0x68>
    80004eee:	4901                	li	s2,0
    80004ef0:	a039                	j	80004efe <consolewrite+0x68>
    80004ef2:	64a6                	ld	s1,72(sp)
    80004ef4:	79e2                	ld	s3,56(sp)
    80004ef6:	7a42                	ld	s4,48(sp)
    80004ef8:	7aa2                	ld	s5,40(sp)
    80004efa:	7b02                	ld	s6,32(sp)
    80004efc:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    80004efe:	854a                	mv	a0,s2
    80004f00:	60e6                	ld	ra,88(sp)
    80004f02:	6446                	ld	s0,80(sp)
    80004f04:	6906                	ld	s2,64(sp)
    80004f06:	6125                	addi	sp,sp,96
    80004f08:	8082                	ret

0000000080004f0a <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80004f0a:	711d                	addi	sp,sp,-96
    80004f0c:	ec86                	sd	ra,88(sp)
    80004f0e:	e8a2                	sd	s0,80(sp)
    80004f10:	e4a6                	sd	s1,72(sp)
    80004f12:	e0ca                	sd	s2,64(sp)
    80004f14:	fc4e                	sd	s3,56(sp)
    80004f16:	f852                	sd	s4,48(sp)
    80004f18:	f05a                	sd	s6,32(sp)
    80004f1a:	ec5e                	sd	s7,24(sp)
    80004f1c:	1080                	addi	s0,sp,96
    80004f1e:	8b2a                	mv	s6,a0
    80004f20:	8a2e                	mv	s4,a1
    80004f22:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80004f24:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80004f26:	0001c517          	auipc	a0,0x1c
    80004f2a:	63a50513          	addi	a0,a0,1594 # 80021560 <cons>
    80004f2e:	20f000ef          	jal	8000593c <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80004f32:	0001c497          	auipc	s1,0x1c
    80004f36:	62e48493          	addi	s1,s1,1582 # 80021560 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80004f3a:	0001c917          	auipc	s2,0x1c
    80004f3e:	6be90913          	addi	s2,s2,1726 # 800215f8 <cons+0x98>
  while(n > 0){
    80004f42:	0b305b63          	blez	s3,80004ff8 <consoleread+0xee>
    while(cons.r == cons.w){
    80004f46:	0984a783          	lw	a5,152(s1)
    80004f4a:	09c4a703          	lw	a4,156(s1)
    80004f4e:	0af71063          	bne	a4,a5,80004fee <consoleread+0xe4>
      if(killed(myproc())){
    80004f52:	e31fb0ef          	jal	80000d82 <myproc>
    80004f56:	e6cfc0ef          	jal	800015c2 <killed>
    80004f5a:	e12d                	bnez	a0,80004fbc <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    80004f5c:	85a6                	mv	a1,s1
    80004f5e:	854a                	mv	a0,s2
    80004f60:	c26fc0ef          	jal	80001386 <sleep>
    while(cons.r == cons.w){
    80004f64:	0984a783          	lw	a5,152(s1)
    80004f68:	09c4a703          	lw	a4,156(s1)
    80004f6c:	fef703e3          	beq	a4,a5,80004f52 <consoleread+0x48>
    80004f70:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80004f72:	0001c717          	auipc	a4,0x1c
    80004f76:	5ee70713          	addi	a4,a4,1518 # 80021560 <cons>
    80004f7a:	0017869b          	addiw	a3,a5,1
    80004f7e:	08d72c23          	sw	a3,152(a4)
    80004f82:	07f7f693          	andi	a3,a5,127
    80004f86:	9736                	add	a4,a4,a3
    80004f88:	01874703          	lbu	a4,24(a4)
    80004f8c:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    80004f90:	4691                	li	a3,4
    80004f92:	04da8663          	beq	s5,a3,80004fde <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80004f96:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004f9a:	4685                	li	a3,1
    80004f9c:	faf40613          	addi	a2,s0,-81
    80004fa0:	85d2                	mv	a1,s4
    80004fa2:	855a                	mv	a0,s6
    80004fa4:	f3cfc0ef          	jal	800016e0 <either_copyout>
    80004fa8:	57fd                	li	a5,-1
    80004faa:	04f50663          	beq	a0,a5,80004ff6 <consoleread+0xec>
      break;

    dst++;
    80004fae:	0a05                	addi	s4,s4,1
    --n;
    80004fb0:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80004fb2:	47a9                	li	a5,10
    80004fb4:	04fa8b63          	beq	s5,a5,8000500a <consoleread+0x100>
    80004fb8:	7aa2                	ld	s5,40(sp)
    80004fba:	b761                	j	80004f42 <consoleread+0x38>
        release(&cons.lock);
    80004fbc:	0001c517          	auipc	a0,0x1c
    80004fc0:	5a450513          	addi	a0,a0,1444 # 80021560 <cons>
    80004fc4:	20d000ef          	jal	800059d0 <release>
        return -1;
    80004fc8:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80004fca:	60e6                	ld	ra,88(sp)
    80004fcc:	6446                	ld	s0,80(sp)
    80004fce:	64a6                	ld	s1,72(sp)
    80004fd0:	6906                	ld	s2,64(sp)
    80004fd2:	79e2                	ld	s3,56(sp)
    80004fd4:	7a42                	ld	s4,48(sp)
    80004fd6:	7b02                	ld	s6,32(sp)
    80004fd8:	6be2                	ld	s7,24(sp)
    80004fda:	6125                	addi	sp,sp,96
    80004fdc:	8082                	ret
      if(n < target){
    80004fde:	0179fa63          	bgeu	s3,s7,80004ff2 <consoleread+0xe8>
        cons.r--;
    80004fe2:	0001c717          	auipc	a4,0x1c
    80004fe6:	60f72b23          	sw	a5,1558(a4) # 800215f8 <cons+0x98>
    80004fea:	7aa2                	ld	s5,40(sp)
    80004fec:	a031                	j	80004ff8 <consoleread+0xee>
    80004fee:	f456                	sd	s5,40(sp)
    80004ff0:	b749                	j	80004f72 <consoleread+0x68>
    80004ff2:	7aa2                	ld	s5,40(sp)
    80004ff4:	a011                	j	80004ff8 <consoleread+0xee>
    80004ff6:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80004ff8:	0001c517          	auipc	a0,0x1c
    80004ffc:	56850513          	addi	a0,a0,1384 # 80021560 <cons>
    80005000:	1d1000ef          	jal	800059d0 <release>
  return target - n;
    80005004:	413b853b          	subw	a0,s7,s3
    80005008:	b7c9                	j	80004fca <consoleread+0xc0>
    8000500a:	7aa2                	ld	s5,40(sp)
    8000500c:	b7f5                	j	80004ff8 <consoleread+0xee>

000000008000500e <consputc>:
{
    8000500e:	1141                	addi	sp,sp,-16
    80005010:	e406                	sd	ra,8(sp)
    80005012:	e022                	sd	s0,0(sp)
    80005014:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80005016:	10000793          	li	a5,256
    8000501a:	00f50863          	beq	a0,a5,8000502a <consputc+0x1c>
    uartputc_sync(c);
    8000501e:	69e000ef          	jal	800056bc <uartputc_sync>
}
    80005022:	60a2                	ld	ra,8(sp)
    80005024:	6402                	ld	s0,0(sp)
    80005026:	0141                	addi	sp,sp,16
    80005028:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000502a:	4521                	li	a0,8
    8000502c:	690000ef          	jal	800056bc <uartputc_sync>
    80005030:	02000513          	li	a0,32
    80005034:	688000ef          	jal	800056bc <uartputc_sync>
    80005038:	4521                	li	a0,8
    8000503a:	682000ef          	jal	800056bc <uartputc_sync>
    8000503e:	b7d5                	j	80005022 <consputc+0x14>

0000000080005040 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80005040:	1101                	addi	sp,sp,-32
    80005042:	ec06                	sd	ra,24(sp)
    80005044:	e822                	sd	s0,16(sp)
    80005046:	e426                	sd	s1,8(sp)
    80005048:	1000                	addi	s0,sp,32
    8000504a:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    8000504c:	0001c517          	auipc	a0,0x1c
    80005050:	51450513          	addi	a0,a0,1300 # 80021560 <cons>
    80005054:	0e9000ef          	jal	8000593c <acquire>

  switch(c){
    80005058:	47d5                	li	a5,21
    8000505a:	08f48d63          	beq	s1,a5,800050f4 <consoleintr+0xb4>
    8000505e:	0297c563          	blt	a5,s1,80005088 <consoleintr+0x48>
    80005062:	47a1                	li	a5,8
    80005064:	0ef48263          	beq	s1,a5,80005148 <consoleintr+0x108>
    80005068:	47c1                	li	a5,16
    8000506a:	10f49363          	bne	s1,a5,80005170 <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    8000506e:	f06fc0ef          	jal	80001774 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    80005072:	0001c517          	auipc	a0,0x1c
    80005076:	4ee50513          	addi	a0,a0,1262 # 80021560 <cons>
    8000507a:	157000ef          	jal	800059d0 <release>
}
    8000507e:	60e2                	ld	ra,24(sp)
    80005080:	6442                	ld	s0,16(sp)
    80005082:	64a2                	ld	s1,8(sp)
    80005084:	6105                	addi	sp,sp,32
    80005086:	8082                	ret
  switch(c){
    80005088:	07f00793          	li	a5,127
    8000508c:	0af48e63          	beq	s1,a5,80005148 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005090:	0001c717          	auipc	a4,0x1c
    80005094:	4d070713          	addi	a4,a4,1232 # 80021560 <cons>
    80005098:	0a072783          	lw	a5,160(a4)
    8000509c:	09872703          	lw	a4,152(a4)
    800050a0:	9f99                	subw	a5,a5,a4
    800050a2:	07f00713          	li	a4,127
    800050a6:	fcf766e3          	bltu	a4,a5,80005072 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    800050aa:	47b5                	li	a5,13
    800050ac:	0cf48563          	beq	s1,a5,80005176 <consoleintr+0x136>
      consputc(c);
    800050b0:	8526                	mv	a0,s1
    800050b2:	f5dff0ef          	jal	8000500e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800050b6:	0001c717          	auipc	a4,0x1c
    800050ba:	4aa70713          	addi	a4,a4,1194 # 80021560 <cons>
    800050be:	0a072683          	lw	a3,160(a4)
    800050c2:	0016879b          	addiw	a5,a3,1
    800050c6:	863e                	mv	a2,a5
    800050c8:	0af72023          	sw	a5,160(a4)
    800050cc:	07f6f693          	andi	a3,a3,127
    800050d0:	9736                	add	a4,a4,a3
    800050d2:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    800050d6:	ff648713          	addi	a4,s1,-10
    800050da:	c371                	beqz	a4,8000519e <consoleintr+0x15e>
    800050dc:	14f1                	addi	s1,s1,-4
    800050de:	c0e1                	beqz	s1,8000519e <consoleintr+0x15e>
    800050e0:	0001c717          	auipc	a4,0x1c
    800050e4:	51872703          	lw	a4,1304(a4) # 800215f8 <cons+0x98>
    800050e8:	9f99                	subw	a5,a5,a4
    800050ea:	08000713          	li	a4,128
    800050ee:	f8e792e3          	bne	a5,a4,80005072 <consoleintr+0x32>
    800050f2:	a075                	j	8000519e <consoleintr+0x15e>
    800050f4:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    800050f6:	0001c717          	auipc	a4,0x1c
    800050fa:	46a70713          	addi	a4,a4,1130 # 80021560 <cons>
    800050fe:	0a072783          	lw	a5,160(a4)
    80005102:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005106:	0001c497          	auipc	s1,0x1c
    8000510a:	45a48493          	addi	s1,s1,1114 # 80021560 <cons>
    while(cons.e != cons.w &&
    8000510e:	4929                	li	s2,10
    80005110:	02f70863          	beq	a4,a5,80005140 <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005114:	37fd                	addiw	a5,a5,-1
    80005116:	07f7f713          	andi	a4,a5,127
    8000511a:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000511c:	01874703          	lbu	a4,24(a4)
    80005120:	03270263          	beq	a4,s2,80005144 <consoleintr+0x104>
      cons.e--;
    80005124:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005128:	10000513          	li	a0,256
    8000512c:	ee3ff0ef          	jal	8000500e <consputc>
    while(cons.e != cons.w &&
    80005130:	0a04a783          	lw	a5,160(s1)
    80005134:	09c4a703          	lw	a4,156(s1)
    80005138:	fcf71ee3          	bne	a4,a5,80005114 <consoleintr+0xd4>
    8000513c:	6902                	ld	s2,0(sp)
    8000513e:	bf15                	j	80005072 <consoleintr+0x32>
    80005140:	6902                	ld	s2,0(sp)
    80005142:	bf05                	j	80005072 <consoleintr+0x32>
    80005144:	6902                	ld	s2,0(sp)
    80005146:	b735                	j	80005072 <consoleintr+0x32>
    if(cons.e != cons.w){
    80005148:	0001c717          	auipc	a4,0x1c
    8000514c:	41870713          	addi	a4,a4,1048 # 80021560 <cons>
    80005150:	0a072783          	lw	a5,160(a4)
    80005154:	09c72703          	lw	a4,156(a4)
    80005158:	f0f70de3          	beq	a4,a5,80005072 <consoleintr+0x32>
      cons.e--;
    8000515c:	37fd                	addiw	a5,a5,-1
    8000515e:	0001c717          	auipc	a4,0x1c
    80005162:	4af72123          	sw	a5,1186(a4) # 80021600 <cons+0xa0>
      consputc(BACKSPACE);
    80005166:	10000513          	li	a0,256
    8000516a:	ea5ff0ef          	jal	8000500e <consputc>
    8000516e:	b711                	j	80005072 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005170:	f00481e3          	beqz	s1,80005072 <consoleintr+0x32>
    80005174:	bf31                	j	80005090 <consoleintr+0x50>
      consputc(c);
    80005176:	4529                	li	a0,10
    80005178:	e97ff0ef          	jal	8000500e <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    8000517c:	0001c797          	auipc	a5,0x1c
    80005180:	3e478793          	addi	a5,a5,996 # 80021560 <cons>
    80005184:	0a07a703          	lw	a4,160(a5)
    80005188:	0017069b          	addiw	a3,a4,1
    8000518c:	8636                	mv	a2,a3
    8000518e:	0ad7a023          	sw	a3,160(a5)
    80005192:	07f77713          	andi	a4,a4,127
    80005196:	97ba                	add	a5,a5,a4
    80005198:	4729                	li	a4,10
    8000519a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000519e:	0001c797          	auipc	a5,0x1c
    800051a2:	44c7af23          	sw	a2,1118(a5) # 800215fc <cons+0x9c>
        wakeup(&cons.r);
    800051a6:	0001c517          	auipc	a0,0x1c
    800051aa:	45250513          	addi	a0,a0,1106 # 800215f8 <cons+0x98>
    800051ae:	a24fc0ef          	jal	800013d2 <wakeup>
    800051b2:	b5c1                	j	80005072 <consoleintr+0x32>

00000000800051b4 <consoleinit>:

void
consoleinit(void)
{
    800051b4:	1141                	addi	sp,sp,-16
    800051b6:	e406                	sd	ra,8(sp)
    800051b8:	e022                	sd	s0,0(sp)
    800051ba:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800051bc:	00002597          	auipc	a1,0x2
    800051c0:	55458593          	addi	a1,a1,1364 # 80007710 <etext+0x710>
    800051c4:	0001c517          	auipc	a0,0x1c
    800051c8:	39c50513          	addi	a0,a0,924 # 80021560 <cons>
    800051cc:	6e6000ef          	jal	800058b2 <initlock>

  uartinit();
    800051d0:	496000ef          	jal	80005666 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    800051d4:	00013797          	auipc	a5,0x13
    800051d8:	1f478793          	addi	a5,a5,500 # 800183c8 <devsw>
    800051dc:	00000717          	auipc	a4,0x0
    800051e0:	d2e70713          	addi	a4,a4,-722 # 80004f0a <consoleread>
    800051e4:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    800051e6:	00000717          	auipc	a4,0x0
    800051ea:	cb070713          	addi	a4,a4,-848 # 80004e96 <consolewrite>
    800051ee:	ef98                	sd	a4,24(a5)
}
    800051f0:	60a2                	ld	ra,8(sp)
    800051f2:	6402                	ld	s0,0(sp)
    800051f4:	0141                	addi	sp,sp,16
    800051f6:	8082                	ret

00000000800051f8 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    800051f8:	7179                	addi	sp,sp,-48
    800051fa:	f406                	sd	ra,40(sp)
    800051fc:	f022                	sd	s0,32(sp)
    800051fe:	e84a                	sd	s2,16(sp)
    80005200:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80005202:	c219                	beqz	a2,80005208 <printint+0x10>
    80005204:	08054163          	bltz	a0,80005286 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80005208:	4301                	li	t1,0

  i = 0;
    8000520a:	fd040913          	addi	s2,s0,-48
    x = xx;
    8000520e:	86ca                	mv	a3,s2
  i = 0;
    80005210:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005212:	00002817          	auipc	a6,0x2
    80005216:	67e80813          	addi	a6,a6,1662 # 80007890 <digits>
    8000521a:	88ba                	mv	a7,a4
    8000521c:	0017061b          	addiw	a2,a4,1
    80005220:	8732                	mv	a4,a2
    80005222:	02b577b3          	remu	a5,a0,a1
    80005226:	97c2                	add	a5,a5,a6
    80005228:	0007c783          	lbu	a5,0(a5)
    8000522c:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005230:	87aa                	mv	a5,a0
    80005232:	02b55533          	divu	a0,a0,a1
    80005236:	0685                	addi	a3,a3,1
    80005238:	feb7f1e3          	bgeu	a5,a1,8000521a <printint+0x22>

  if(sign)
    8000523c:	00030c63          	beqz	t1,80005254 <printint+0x5c>
    buf[i++] = '-';
    80005240:	fe060793          	addi	a5,a2,-32
    80005244:	00878633          	add	a2,a5,s0
    80005248:	02d00793          	li	a5,45
    8000524c:	fef60823          	sb	a5,-16(a2)
    80005250:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80005254:	02e05463          	blez	a4,8000527c <printint+0x84>
    80005258:	ec26                	sd	s1,24(sp)
    8000525a:	377d                	addiw	a4,a4,-1
    8000525c:	00e904b3          	add	s1,s2,a4
    80005260:	197d                	addi	s2,s2,-1
    80005262:	993a                	add	s2,s2,a4
    80005264:	1702                	slli	a4,a4,0x20
    80005266:	9301                	srli	a4,a4,0x20
    80005268:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    8000526c:	0004c503          	lbu	a0,0(s1)
    80005270:	d9fff0ef          	jal	8000500e <consputc>
  while(--i >= 0)
    80005274:	14fd                	addi	s1,s1,-1
    80005276:	ff249be3          	bne	s1,s2,8000526c <printint+0x74>
    8000527a:	64e2                	ld	s1,24(sp)
}
    8000527c:	70a2                	ld	ra,40(sp)
    8000527e:	7402                	ld	s0,32(sp)
    80005280:	6942                	ld	s2,16(sp)
    80005282:	6145                	addi	sp,sp,48
    80005284:	8082                	ret
    x = -xx;
    80005286:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    8000528a:	4305                	li	t1,1
    x = -xx;
    8000528c:	bfbd                	j	8000520a <printint+0x12>

000000008000528e <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    8000528e:	7131                	addi	sp,sp,-192
    80005290:	fc86                	sd	ra,120(sp)
    80005292:	f8a2                	sd	s0,112(sp)
    80005294:	f0ca                	sd	s2,96(sp)
    80005296:	ec6e                	sd	s11,24(sp)
    80005298:	0100                	addi	s0,sp,128
    8000529a:	892a                	mv	s2,a0
    8000529c:	e40c                	sd	a1,8(s0)
    8000529e:	e810                	sd	a2,16(s0)
    800052a0:	ec14                	sd	a3,24(s0)
    800052a2:	f018                	sd	a4,32(s0)
    800052a4:	f41c                	sd	a5,40(s0)
    800052a6:	03043823          	sd	a6,48(s0)
    800052aa:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800052ae:	0001cd97          	auipc	s11,0x1c
    800052b2:	372dad83          	lw	s11,882(s11) # 80021620 <pr+0x18>
  if(locking)
    800052b6:	020d9d63          	bnez	s11,800052f0 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800052ba:	00840793          	addi	a5,s0,8
    800052be:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800052c2:	00054503          	lbu	a0,0(a0)
    800052c6:	20050f63          	beqz	a0,800054e4 <printf+0x256>
    800052ca:	f4a6                	sd	s1,104(sp)
    800052cc:	ecce                	sd	s3,88(sp)
    800052ce:	e8d2                	sd	s4,80(sp)
    800052d0:	e4d6                	sd	s5,72(sp)
    800052d2:	e0da                	sd	s6,64(sp)
    800052d4:	fc5e                	sd	s7,56(sp)
    800052d6:	f862                	sd	s8,48(sp)
    800052d8:	f06a                	sd	s10,32(sp)
    800052da:	4a81                	li	s5,0
    if(cx != '%'){
    800052dc:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    800052e0:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    800052e4:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    800052e8:	4b29                	li	s6,10
    if(c0 == 'd'){
    800052ea:	06400b93          	li	s7,100
    800052ee:	a80d                	j	80005320 <printf+0x92>
    acquire(&pr.lock);
    800052f0:	0001c517          	auipc	a0,0x1c
    800052f4:	31850513          	addi	a0,a0,792 # 80021608 <pr>
    800052f8:	644000ef          	jal	8000593c <acquire>
  va_start(ap, fmt);
    800052fc:	00840793          	addi	a5,s0,8
    80005300:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005304:	00094503          	lbu	a0,0(s2)
    80005308:	f169                	bnez	a0,800052ca <printf+0x3c>
    8000530a:	aae5                	j	80005502 <printf+0x274>
      consputc(cx);
    8000530c:	d03ff0ef          	jal	8000500e <consputc>
      continue;
    80005310:	84d6                	mv	s1,s5
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005312:	2485                	addiw	s1,s1,1
    80005314:	8aa6                	mv	s5,s1
    80005316:	94ca                	add	s1,s1,s2
    80005318:	0004c503          	lbu	a0,0(s1)
    8000531c:	1a050a63          	beqz	a0,800054d0 <printf+0x242>
    if(cx != '%'){
    80005320:	ff3516e3          	bne	a0,s3,8000530c <printf+0x7e>
    i++;
    80005324:	001a879b          	addiw	a5,s5,1
    80005328:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000532a:	00f90733          	add	a4,s2,a5
    8000532e:	00074a03          	lbu	s4,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005332:	1e0a0863          	beqz	s4,80005522 <printf+0x294>
    80005336:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000533a:	1c068b63          	beqz	a3,80005510 <printf+0x282>
    if(c0 == 'd'){
    8000533e:	037a0863          	beq	s4,s7,8000536e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005342:	f94a0713          	addi	a4,s4,-108
    80005346:	00173713          	seqz	a4,a4
    8000534a:	f9c68613          	addi	a2,a3,-100
    8000534e:	ee05                	bnez	a2,80005386 <printf+0xf8>
    80005350:	cb1d                	beqz	a4,80005386 <printf+0xf8>
      printint(va_arg(ap, uint64), 10, 1);
    80005352:	f8843783          	ld	a5,-120(s0)
    80005356:	00878713          	addi	a4,a5,8
    8000535a:	f8e43423          	sd	a4,-120(s0)
    8000535e:	4605                	li	a2,1
    80005360:	85da                	mv	a1,s6
    80005362:	6388                	ld	a0,0(a5)
    80005364:	e95ff0ef          	jal	800051f8 <printint>
      i += 1;
    80005368:	002a849b          	addiw	s1,s5,2
    8000536c:	b75d                	j	80005312 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    8000536e:	f8843783          	ld	a5,-120(s0)
    80005372:	00878713          	addi	a4,a5,8
    80005376:	f8e43423          	sd	a4,-120(s0)
    8000537a:	4605                	li	a2,1
    8000537c:	85da                	mv	a1,s6
    8000537e:	4388                	lw	a0,0(a5)
    80005380:	e79ff0ef          	jal	800051f8 <printint>
    80005384:	b779                	j	80005312 <printf+0x84>
    if(c1) c2 = fmt[i+2] & 0xff;
    80005386:	97ca                	add	a5,a5,s2
    80005388:	8636                	mv	a2,a3
    8000538a:	0027c683          	lbu	a3,2(a5)
    8000538e:	a245                	j	8000552e <printf+0x2a0>
      printint(va_arg(ap, uint64), 10, 1);
    80005390:	f8843783          	ld	a5,-120(s0)
    80005394:	00878713          	addi	a4,a5,8
    80005398:	f8e43423          	sd	a4,-120(s0)
    8000539c:	4605                	li	a2,1
    8000539e:	45a9                	li	a1,10
    800053a0:	6388                	ld	a0,0(a5)
    800053a2:	e57ff0ef          	jal	800051f8 <printint>
      i += 2;
    800053a6:	003a849b          	addiw	s1,s5,3
    800053aa:	b7a5                	j	80005312 <printf+0x84>
      printint(va_arg(ap, int), 10, 0);
    800053ac:	f8843783          	ld	a5,-120(s0)
    800053b0:	00878713          	addi	a4,a5,8
    800053b4:	f8e43423          	sd	a4,-120(s0)
    800053b8:	4601                	li	a2,0
    800053ba:	85da                	mv	a1,s6
    800053bc:	4388                	lw	a0,0(a5)
    800053be:	e3bff0ef          	jal	800051f8 <printint>
    800053c2:	bf81                	j	80005312 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800053c4:	f8843783          	ld	a5,-120(s0)
    800053c8:	00878713          	addi	a4,a5,8
    800053cc:	f8e43423          	sd	a4,-120(s0)
    800053d0:	4601                	li	a2,0
    800053d2:	85da                	mv	a1,s6
    800053d4:	6388                	ld	a0,0(a5)
    800053d6:	e23ff0ef          	jal	800051f8 <printint>
      i += 1;
    800053da:	002a849b          	addiw	s1,s5,2
    800053de:	bf15                	j	80005312 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    800053e0:	f8843783          	ld	a5,-120(s0)
    800053e4:	00878713          	addi	a4,a5,8
    800053e8:	f8e43423          	sd	a4,-120(s0)
    800053ec:	4601                	li	a2,0
    800053ee:	45a9                	li	a1,10
    800053f0:	6388                	ld	a0,0(a5)
    800053f2:	e07ff0ef          	jal	800051f8 <printint>
      i += 2;
    800053f6:	003a849b          	addiw	s1,s5,3
    800053fa:	bf21                	j	80005312 <printf+0x84>
      printint(va_arg(ap, int), 16, 0);
    800053fc:	f8843783          	ld	a5,-120(s0)
    80005400:	00878713          	addi	a4,a5,8
    80005404:	f8e43423          	sd	a4,-120(s0)
    80005408:	4601                	li	a2,0
    8000540a:	45c1                	li	a1,16
    8000540c:	4388                	lw	a0,0(a5)
    8000540e:	debff0ef          	jal	800051f8 <printint>
    80005412:	b701                	j	80005312 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80005414:	f8843783          	ld	a5,-120(s0)
    80005418:	00878713          	addi	a4,a5,8
    8000541c:	f8e43423          	sd	a4,-120(s0)
    80005420:	45c1                	li	a1,16
    80005422:	6388                	ld	a0,0(a5)
    80005424:	dd5ff0ef          	jal	800051f8 <printint>
      i += 1;
    80005428:	002a849b          	addiw	s1,s5,2
    8000542c:	b5dd                	j	80005312 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    8000542e:	f8843783          	ld	a5,-120(s0)
    80005432:	00878713          	addi	a4,a5,8
    80005436:	f8e43423          	sd	a4,-120(s0)
    8000543a:	4601                	li	a2,0
    8000543c:	45c1                	li	a1,16
    8000543e:	6388                	ld	a0,0(a5)
    80005440:	db9ff0ef          	jal	800051f8 <printint>
      i += 2;
    80005444:	003a849b          	addiw	s1,s5,3
    80005448:	b5e9                	j	80005312 <printf+0x84>
    8000544a:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    8000544c:	f8843783          	ld	a5,-120(s0)
    80005450:	00878713          	addi	a4,a5,8
    80005454:	f8e43423          	sd	a4,-120(s0)
    80005458:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    8000545c:	03000513          	li	a0,48
    80005460:	bafff0ef          	jal	8000500e <consputc>
  consputc('x');
    80005464:	07800513          	li	a0,120
    80005468:	ba7ff0ef          	jal	8000500e <consputc>
    8000546c:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000546e:	00002c97          	auipc	s9,0x2
    80005472:	422c8c93          	addi	s9,s9,1058 # 80007890 <digits>
    80005476:	03cad793          	srli	a5,s5,0x3c
    8000547a:	97e6                	add	a5,a5,s9
    8000547c:	0007c503          	lbu	a0,0(a5)
    80005480:	b8fff0ef          	jal	8000500e <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    80005484:	0a92                	slli	s5,s5,0x4
    80005486:	3a7d                	addiw	s4,s4,-1
    80005488:	fe0a17e3          	bnez	s4,80005476 <printf+0x1e8>
    8000548c:	7ca2                	ld	s9,40(sp)
    8000548e:	b551                	j	80005312 <printf+0x84>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80005490:	f8843783          	ld	a5,-120(s0)
    80005494:	00878713          	addi	a4,a5,8
    80005498:	f8e43423          	sd	a4,-120(s0)
    8000549c:	0007ba03          	ld	s4,0(a5)
    800054a0:	000a0d63          	beqz	s4,800054ba <printf+0x22c>
        s = "(null)";
      for(; *s; s++)
    800054a4:	000a4503          	lbu	a0,0(s4)
    800054a8:	e60505e3          	beqz	a0,80005312 <printf+0x84>
        consputc(*s);
    800054ac:	b63ff0ef          	jal	8000500e <consputc>
      for(; *s; s++)
    800054b0:	0a05                	addi	s4,s4,1
    800054b2:	000a4503          	lbu	a0,0(s4)
    800054b6:	f97d                	bnez	a0,800054ac <printf+0x21e>
    800054b8:	bda9                	j	80005312 <printf+0x84>
        s = "(null)";
    800054ba:	00002a17          	auipc	s4,0x2
    800054be:	25ea0a13          	addi	s4,s4,606 # 80007718 <etext+0x718>
      for(; *s; s++)
    800054c2:	02800513          	li	a0,40
    800054c6:	b7dd                	j	800054ac <printf+0x21e>
    } else if(c0 == '%'){
      consputc('%');
    800054c8:	8552                	mv	a0,s4
    800054ca:	b45ff0ef          	jal	8000500e <consputc>
    800054ce:	b591                	j	80005312 <printf+0x84>
    }
#endif
  }
  va_end(ap);

  if(locking)
    800054d0:	020d9163          	bnez	s11,800054f2 <printf+0x264>
    800054d4:	74a6                	ld	s1,104(sp)
    800054d6:	69e6                	ld	s3,88(sp)
    800054d8:	6a46                	ld	s4,80(sp)
    800054da:	6aa6                	ld	s5,72(sp)
    800054dc:	6b06                	ld	s6,64(sp)
    800054de:	7be2                	ld	s7,56(sp)
    800054e0:	7c42                	ld	s8,48(sp)
    800054e2:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    800054e4:	4501                	li	a0,0
    800054e6:	70e6                	ld	ra,120(sp)
    800054e8:	7446                	ld	s0,112(sp)
    800054ea:	7906                	ld	s2,96(sp)
    800054ec:	6de2                	ld	s11,24(sp)
    800054ee:	6129                	addi	sp,sp,192
    800054f0:	8082                	ret
    800054f2:	74a6                	ld	s1,104(sp)
    800054f4:	69e6                	ld	s3,88(sp)
    800054f6:	6a46                	ld	s4,80(sp)
    800054f8:	6aa6                	ld	s5,72(sp)
    800054fa:	6b06                	ld	s6,64(sp)
    800054fc:	7be2                	ld	s7,56(sp)
    800054fe:	7c42                	ld	s8,48(sp)
    80005500:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80005502:	0001c517          	auipc	a0,0x1c
    80005506:	10650513          	addi	a0,a0,262 # 80021608 <pr>
    8000550a:	4c6000ef          	jal	800059d0 <release>
    8000550e:	bfd9                	j	800054e4 <printf+0x256>
    if(c0 == 'd'){
    80005510:	e57a0fe3          	beq	s4,s7,8000536e <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005514:	f94a0713          	addi	a4,s4,-108
    80005518:	00173713          	seqz	a4,a4
    8000551c:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000551e:	4781                	li	a5,0
    80005520:	a00d                	j	80005542 <printf+0x2b4>
    } else if(c0 == 'l' && c1 == 'd'){
    80005522:	f94a0713          	addi	a4,s4,-108
    80005526:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    8000552a:	8652                	mv	a2,s4
    8000552c:	86d2                	mv	a3,s4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000552e:	f9460793          	addi	a5,a2,-108
    80005532:	0017b793          	seqz	a5,a5
    80005536:	8ff9                	and	a5,a5,a4
    80005538:	f9c68593          	addi	a1,a3,-100
    8000553c:	e199                	bnez	a1,80005542 <printf+0x2b4>
    8000553e:	e40799e3          	bnez	a5,80005390 <printf+0x102>
    } else if(c0 == 'u'){
    80005542:	e78a05e3          	beq	s4,s8,800053ac <printf+0x11e>
    } else if(c0 == 'l' && c1 == 'u'){
    80005546:	f8b60593          	addi	a1,a2,-117
    8000554a:	e199                	bnez	a1,80005550 <printf+0x2c2>
    8000554c:	e6071ce3          	bnez	a4,800053c4 <printf+0x136>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005550:	f8b68593          	addi	a1,a3,-117
    80005554:	e199                	bnez	a1,8000555a <printf+0x2cc>
    80005556:	e80795e3          	bnez	a5,800053e0 <printf+0x152>
    } else if(c0 == 'x'){
    8000555a:	ebaa01e3          	beq	s4,s10,800053fc <printf+0x16e>
    } else if(c0 == 'l' && c1 == 'x'){
    8000555e:	f8860613          	addi	a2,a2,-120
    80005562:	e219                	bnez	a2,80005568 <printf+0x2da>
    80005564:	ea0718e3          	bnez	a4,80005414 <printf+0x186>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    80005568:	f8868693          	addi	a3,a3,-120
    8000556c:	e299                	bnez	a3,80005572 <printf+0x2e4>
    8000556e:	ec0790e3          	bnez	a5,8000542e <printf+0x1a0>
    } else if(c0 == 'p'){
    80005572:	07000793          	li	a5,112
    80005576:	ecfa0ae3          	beq	s4,a5,8000544a <printf+0x1bc>
    } else if(c0 == 's'){
    8000557a:	07300793          	li	a5,115
    8000557e:	f0fa09e3          	beq	s4,a5,80005490 <printf+0x202>
    } else if(c0 == '%'){
    80005582:	02500793          	li	a5,37
    80005586:	f4fa01e3          	beq	s4,a5,800054c8 <printf+0x23a>
    } else if(c0 == 0){
    8000558a:	f40a03e3          	beqz	s4,800054d0 <printf+0x242>
      consputc('%');
    8000558e:	02500513          	li	a0,37
    80005592:	a7dff0ef          	jal	8000500e <consputc>
      consputc(c0);
    80005596:	8552                	mv	a0,s4
    80005598:	a77ff0ef          	jal	8000500e <consputc>
    8000559c:	bb9d                	j	80005312 <printf+0x84>

000000008000559e <printfinit>:
    ;
}

void
printfinit(void)
{
    8000559e:	1141                	addi	sp,sp,-16
    800055a0:	e406                	sd	ra,8(sp)
    800055a2:	e022                	sd	s0,0(sp)
    800055a4:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    800055a6:	00002597          	auipc	a1,0x2
    800055aa:	17a58593          	addi	a1,a1,378 # 80007720 <etext+0x720>
    800055ae:	0001c517          	auipc	a0,0x1c
    800055b2:	05a50513          	addi	a0,a0,90 # 80021608 <pr>
    800055b6:	2fc000ef          	jal	800058b2 <initlock>
  pr.locking = 1;
    800055ba:	4785                	li	a5,1
    800055bc:	0001c717          	auipc	a4,0x1c
    800055c0:	06f72223          	sw	a5,100(a4) # 80021620 <pr+0x18>
}
    800055c4:	60a2                	ld	ra,8(sp)
    800055c6:	6402                	ld	s0,0(sp)
    800055c8:	0141                	addi	sp,sp,16
    800055ca:	8082                	ret

00000000800055cc <backtrace>:

void
backtrace(void)
{
    800055cc:	7139                	addi	sp,sp,-64
    800055ce:	fc06                	sd	ra,56(sp)
    800055d0:	f822                	sd	s0,48(sp)
    800055d2:	f426                	sd	s1,40(sp)
    800055d4:	f04a                	sd	s2,32(sp)
    800055d6:	ec4e                	sd	s3,24(sp)
    800055d8:	e852                	sd	s4,16(sp)
    800055da:	e456                	sd	s5,8(sp)
    800055dc:	0080                	addi	s0,sp,64

static inline uint64
r_fp()
{
  uint64 x;
  asm volatile("mv %0, s0" : "=r" (x) );
    800055de:	89a2                	mv	s3,s0
  uint64 ra;
  uint64 *p;
  uint64 top = PGROUNDDOWN(fp);
  int i;

  printf("backtrace:\n");
    800055e0:	00002517          	auipc	a0,0x2
    800055e4:	14850513          	addi	a0,a0,328 # 80007728 <etext+0x728>
    800055e8:	ca7ff0ef          	jal	8000528e <printf>
  uint64 fp = r_fp();
    800055ec:	84ce                	mv	s1,s3
  printf("backtrace:\n");
    800055ee:	4929                	li	s2,10
  for(i = 0; i < 10; i++){
    if(PGROUNDDOWN(fp) != top)
      break;
    p = (uint64*)fp;
    ra = p[-1];
    printf("%p\n", (void *)ra);
    800055f0:	00002a17          	auipc	s4,0x2
    800055f4:	148a0a13          	addi	s4,s4,328 # 80007738 <etext+0x738>
    if(PGROUNDDOWN(fp) != top)
    800055f8:	6a85                	lui	s5,0x1
    printf("%p\n", (void *)ra);
    800055fa:	ff84b583          	ld	a1,-8(s1)
    800055fe:	8552                	mv	a0,s4
    80005600:	c8fff0ef          	jal	8000528e <printf>
  for(i = 0; i < 10; i++){
    80005604:	397d                	addiw	s2,s2,-1
    80005606:	00090863          	beqz	s2,80005616 <backtrace+0x4a>
    fp = p[-2];
    8000560a:	ff04b483          	ld	s1,-16(s1)
    if(PGROUNDDOWN(fp) != top)
    8000560e:	0134c7b3          	xor	a5,s1,s3
    80005612:	ff57e4e3          	bltu	a5,s5,800055fa <backtrace+0x2e>
  }
    80005616:	70e2                	ld	ra,56(sp)
    80005618:	7442                	ld	s0,48(sp)
    8000561a:	74a2                	ld	s1,40(sp)
    8000561c:	7902                	ld	s2,32(sp)
    8000561e:	69e2                	ld	s3,24(sp)
    80005620:	6a42                	ld	s4,16(sp)
    80005622:	6aa2                	ld	s5,8(sp)
    80005624:	6121                	addi	sp,sp,64
    80005626:	8082                	ret

0000000080005628 <panic>:
{
    80005628:	1101                	addi	sp,sp,-32
    8000562a:	ec06                	sd	ra,24(sp)
    8000562c:	e822                	sd	s0,16(sp)
    8000562e:	e426                	sd	s1,8(sp)
    80005630:	1000                	addi	s0,sp,32
    80005632:	84aa                	mv	s1,a0
  backtrace();
    80005634:	f99ff0ef          	jal	800055cc <backtrace>
  pr.locking = 0;
    80005638:	0001c797          	auipc	a5,0x1c
    8000563c:	fe07a423          	sw	zero,-24(a5) # 80021620 <pr+0x18>
  printf("panic: ");
    80005640:	00002517          	auipc	a0,0x2
    80005644:	10050513          	addi	a0,a0,256 # 80007740 <etext+0x740>
    80005648:	c47ff0ef          	jal	8000528e <printf>
  printf("%s\n", s);
    8000564c:	85a6                	mv	a1,s1
    8000564e:	00002517          	auipc	a0,0x2
    80005652:	0fa50513          	addi	a0,a0,250 # 80007748 <etext+0x748>
    80005656:	c39ff0ef          	jal	8000528e <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000565a:	4785                	li	a5,1
    8000565c:	00002717          	auipc	a4,0x2
    80005660:	2cf72023          	sw	a5,704(a4) # 8000791c <panicked>
  for(;;)
    80005664:	a001                	j	80005664 <panic+0x3c>

0000000080005666 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80005666:	1141                	addi	sp,sp,-16
    80005668:	e406                	sd	ra,8(sp)
    8000566a:	e022                	sd	s0,0(sp)
    8000566c:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000566e:	100007b7          	lui	a5,0x10000
    80005672:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80005676:	10000737          	lui	a4,0x10000
    8000567a:	f8000693          	li	a3,-128
    8000567e:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005682:	468d                	li	a3,3
    80005684:	10000637          	lui	a2,0x10000
    80005688:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000568c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80005690:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80005694:	8732                	mv	a4,a2
    80005696:	461d                	li	a2,7
    80005698:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000569c:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    800056a0:	00002597          	auipc	a1,0x2
    800056a4:	0b058593          	addi	a1,a1,176 # 80007750 <etext+0x750>
    800056a8:	0001c517          	auipc	a0,0x1c
    800056ac:	f8050513          	addi	a0,a0,-128 # 80021628 <uart_tx_lock>
    800056b0:	202000ef          	jal	800058b2 <initlock>
}
    800056b4:	60a2                	ld	ra,8(sp)
    800056b6:	6402                	ld	s0,0(sp)
    800056b8:	0141                	addi	sp,sp,16
    800056ba:	8082                	ret

00000000800056bc <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800056bc:	1101                	addi	sp,sp,-32
    800056be:	ec06                	sd	ra,24(sp)
    800056c0:	e822                	sd	s0,16(sp)
    800056c2:	e426                	sd	s1,8(sp)
    800056c4:	1000                	addi	s0,sp,32
    800056c6:	84aa                	mv	s1,a0
  push_off();
    800056c8:	230000ef          	jal	800058f8 <push_off>

  if(panicked){
    800056cc:	00002797          	auipc	a5,0x2
    800056d0:	2507a783          	lw	a5,592(a5) # 8000791c <panicked>
    800056d4:	e795                	bnez	a5,80005700 <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800056d6:	10000737          	lui	a4,0x10000
    800056da:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    800056dc:	00074783          	lbu	a5,0(a4)
    800056e0:	0207f793          	andi	a5,a5,32
    800056e4:	dfe5                	beqz	a5,800056dc <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    800056e6:	0ff4f513          	zext.b	a0,s1
    800056ea:	100007b7          	lui	a5,0x10000
    800056ee:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800056f2:	28e000ef          	jal	80005980 <pop_off>
}
    800056f6:	60e2                	ld	ra,24(sp)
    800056f8:	6442                	ld	s0,16(sp)
    800056fa:	64a2                	ld	s1,8(sp)
    800056fc:	6105                	addi	sp,sp,32
    800056fe:	8082                	ret
    for(;;)
    80005700:	a001                	j	80005700 <uartputc_sync+0x44>

0000000080005702 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80005702:	00002797          	auipc	a5,0x2
    80005706:	21e7b783          	ld	a5,542(a5) # 80007920 <uart_tx_r>
    8000570a:	00002717          	auipc	a4,0x2
    8000570e:	21e73703          	ld	a4,542(a4) # 80007928 <uart_tx_w>
    80005712:	08f70163          	beq	a4,a5,80005794 <uartstart+0x92>
{
    80005716:	7139                	addi	sp,sp,-64
    80005718:	fc06                	sd	ra,56(sp)
    8000571a:	f822                	sd	s0,48(sp)
    8000571c:	f426                	sd	s1,40(sp)
    8000571e:	f04a                	sd	s2,32(sp)
    80005720:	ec4e                	sd	s3,24(sp)
    80005722:	e852                	sd	s4,16(sp)
    80005724:	e456                	sd	s5,8(sp)
    80005726:	e05a                	sd	s6,0(sp)
    80005728:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000572a:	10000937          	lui	s2,0x10000
    8000572e:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005730:	0001ca97          	auipc	s5,0x1c
    80005734:	ef8a8a93          	addi	s5,s5,-264 # 80021628 <uart_tx_lock>
    uart_tx_r += 1;
    80005738:	00002497          	auipc	s1,0x2
    8000573c:	1e848493          	addi	s1,s1,488 # 80007920 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    80005740:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80005744:	00002997          	auipc	s3,0x2
    80005748:	1e498993          	addi	s3,s3,484 # 80007928 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000574c:	00094703          	lbu	a4,0(s2)
    80005750:	02077713          	andi	a4,a4,32
    80005754:	c715                	beqz	a4,80005780 <uartstart+0x7e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005756:	01f7f713          	andi	a4,a5,31
    8000575a:	9756                	add	a4,a4,s5
    8000575c:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    80005760:	0785                	addi	a5,a5,1
    80005762:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80005764:	8526                	mv	a0,s1
    80005766:	c6dfb0ef          	jal	800013d2 <wakeup>
    WriteReg(THR, c);
    8000576a:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    8000576e:	609c                	ld	a5,0(s1)
    80005770:	0009b703          	ld	a4,0(s3)
    80005774:	fcf71ce3          	bne	a4,a5,8000574c <uartstart+0x4a>
      ReadReg(ISR);
    80005778:	100007b7          	lui	a5,0x10000
    8000577c:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005780:	70e2                	ld	ra,56(sp)
    80005782:	7442                	ld	s0,48(sp)
    80005784:	74a2                	ld	s1,40(sp)
    80005786:	7902                	ld	s2,32(sp)
    80005788:	69e2                	ld	s3,24(sp)
    8000578a:	6a42                	ld	s4,16(sp)
    8000578c:	6aa2                	ld	s5,8(sp)
    8000578e:	6b02                	ld	s6,0(sp)
    80005790:	6121                	addi	sp,sp,64
    80005792:	8082                	ret
      ReadReg(ISR);
    80005794:	100007b7          	lui	a5,0x10000
    80005798:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    8000579c:	8082                	ret

000000008000579e <uartputc>:
{
    8000579e:	7179                	addi	sp,sp,-48
    800057a0:	f406                	sd	ra,40(sp)
    800057a2:	f022                	sd	s0,32(sp)
    800057a4:	ec26                	sd	s1,24(sp)
    800057a6:	e84a                	sd	s2,16(sp)
    800057a8:	e44e                	sd	s3,8(sp)
    800057aa:	e052                	sd	s4,0(sp)
    800057ac:	1800                	addi	s0,sp,48
    800057ae:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    800057b0:	0001c517          	auipc	a0,0x1c
    800057b4:	e7850513          	addi	a0,a0,-392 # 80021628 <uart_tx_lock>
    800057b8:	184000ef          	jal	8000593c <acquire>
  if(panicked){
    800057bc:	00002797          	auipc	a5,0x2
    800057c0:	1607a783          	lw	a5,352(a5) # 8000791c <panicked>
    800057c4:	e3d1                	bnez	a5,80005848 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800057c6:	00002717          	auipc	a4,0x2
    800057ca:	16273703          	ld	a4,354(a4) # 80007928 <uart_tx_w>
    800057ce:	00002797          	auipc	a5,0x2
    800057d2:	1527b783          	ld	a5,338(a5) # 80007920 <uart_tx_r>
    800057d6:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800057da:	0001c997          	auipc	s3,0x1c
    800057de:	e4e98993          	addi	s3,s3,-434 # 80021628 <uart_tx_lock>
    800057e2:	00002497          	auipc	s1,0x2
    800057e6:	13e48493          	addi	s1,s1,318 # 80007920 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800057ea:	00002917          	auipc	s2,0x2
    800057ee:	13e90913          	addi	s2,s2,318 # 80007928 <uart_tx_w>
    800057f2:	00e79d63          	bne	a5,a4,8000580c <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800057f6:	85ce                	mv	a1,s3
    800057f8:	8526                	mv	a0,s1
    800057fa:	b8dfb0ef          	jal	80001386 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800057fe:	00093703          	ld	a4,0(s2)
    80005802:	609c                	ld	a5,0(s1)
    80005804:	02078793          	addi	a5,a5,32
    80005808:	fee787e3          	beq	a5,a4,800057f6 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    8000580c:	01f77693          	andi	a3,a4,31
    80005810:	0001c797          	auipc	a5,0x1c
    80005814:	e1878793          	addi	a5,a5,-488 # 80021628 <uart_tx_lock>
    80005818:	97b6                	add	a5,a5,a3
    8000581a:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    8000581e:	0705                	addi	a4,a4,1
    80005820:	00002797          	auipc	a5,0x2
    80005824:	10e7b423          	sd	a4,264(a5) # 80007928 <uart_tx_w>
  uartstart();
    80005828:	edbff0ef          	jal	80005702 <uartstart>
  release(&uart_tx_lock);
    8000582c:	0001c517          	auipc	a0,0x1c
    80005830:	dfc50513          	addi	a0,a0,-516 # 80021628 <uart_tx_lock>
    80005834:	19c000ef          	jal	800059d0 <release>
}
    80005838:	70a2                	ld	ra,40(sp)
    8000583a:	7402                	ld	s0,32(sp)
    8000583c:	64e2                	ld	s1,24(sp)
    8000583e:	6942                	ld	s2,16(sp)
    80005840:	69a2                	ld	s3,8(sp)
    80005842:	6a02                	ld	s4,0(sp)
    80005844:	6145                	addi	sp,sp,48
    80005846:	8082                	ret
    for(;;)
    80005848:	a001                	j	80005848 <uartputc+0xaa>

000000008000584a <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    8000584a:	1141                	addi	sp,sp,-16
    8000584c:	e406                	sd	ra,8(sp)
    8000584e:	e022                	sd	s0,0(sp)
    80005850:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80005852:	100007b7          	lui	a5,0x10000
    80005856:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    8000585a:	8b85                	andi	a5,a5,1
    8000585c:	cb89                	beqz	a5,8000586e <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    8000585e:	100007b7          	lui	a5,0x10000
    80005862:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80005866:	60a2                	ld	ra,8(sp)
    80005868:	6402                	ld	s0,0(sp)
    8000586a:	0141                	addi	sp,sp,16
    8000586c:	8082                	ret
    return -1;
    8000586e:	557d                	li	a0,-1
    80005870:	bfdd                	j	80005866 <uartgetc+0x1c>

0000000080005872 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80005872:	1101                	addi	sp,sp,-32
    80005874:	ec06                	sd	ra,24(sp)
    80005876:	e822                	sd	s0,16(sp)
    80005878:	e426                	sd	s1,8(sp)
    8000587a:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    8000587c:	54fd                	li	s1,-1
    int c = uartgetc();
    8000587e:	fcdff0ef          	jal	8000584a <uartgetc>
    if(c == -1)
    80005882:	00950563          	beq	a0,s1,8000588c <uartintr+0x1a>
      break;
    consoleintr(c);
    80005886:	fbaff0ef          	jal	80005040 <consoleintr>
  while(1){
    8000588a:	bfd5                	j	8000587e <uartintr+0xc>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    8000588c:	0001c517          	auipc	a0,0x1c
    80005890:	d9c50513          	addi	a0,a0,-612 # 80021628 <uart_tx_lock>
    80005894:	0a8000ef          	jal	8000593c <acquire>
  uartstart();
    80005898:	e6bff0ef          	jal	80005702 <uartstart>
  release(&uart_tx_lock);
    8000589c:	0001c517          	auipc	a0,0x1c
    800058a0:	d8c50513          	addi	a0,a0,-628 # 80021628 <uart_tx_lock>
    800058a4:	12c000ef          	jal	800059d0 <release>
}
    800058a8:	60e2                	ld	ra,24(sp)
    800058aa:	6442                	ld	s0,16(sp)
    800058ac:	64a2                	ld	s1,8(sp)
    800058ae:	6105                	addi	sp,sp,32
    800058b0:	8082                	ret

00000000800058b2 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    800058b2:	1141                	addi	sp,sp,-16
    800058b4:	e406                	sd	ra,8(sp)
    800058b6:	e022                	sd	s0,0(sp)
    800058b8:	0800                	addi	s0,sp,16
  lk->name = name;
    800058ba:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    800058bc:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    800058c0:	00053823          	sd	zero,16(a0)
}
    800058c4:	60a2                	ld	ra,8(sp)
    800058c6:	6402                	ld	s0,0(sp)
    800058c8:	0141                	addi	sp,sp,16
    800058ca:	8082                	ret

00000000800058cc <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    800058cc:	411c                	lw	a5,0(a0)
    800058ce:	e399                	bnez	a5,800058d4 <holding+0x8>
    800058d0:	4501                	li	a0,0
  return r;
}
    800058d2:	8082                	ret
{
    800058d4:	1101                	addi	sp,sp,-32
    800058d6:	ec06                	sd	ra,24(sp)
    800058d8:	e822                	sd	s0,16(sp)
    800058da:	e426                	sd	s1,8(sp)
    800058dc:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    800058de:	691c                	ld	a5,16(a0)
    800058e0:	84be                	mv	s1,a5
    800058e2:	c80fb0ef          	jal	80000d62 <mycpu>
    800058e6:	40a48533          	sub	a0,s1,a0
    800058ea:	00153513          	seqz	a0,a0
}
    800058ee:	60e2                	ld	ra,24(sp)
    800058f0:	6442                	ld	s0,16(sp)
    800058f2:	64a2                	ld	s1,8(sp)
    800058f4:	6105                	addi	sp,sp,32
    800058f6:	8082                	ret

00000000800058f8 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    800058f8:	1101                	addi	sp,sp,-32
    800058fa:	ec06                	sd	ra,24(sp)
    800058fc:	e822                	sd	s0,16(sp)
    800058fe:	e426                	sd	s1,8(sp)
    80005900:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005902:	100027f3          	csrr	a5,sstatus
    80005906:	84be                	mv	s1,a5
    80005908:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000590c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000590e:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80005912:	c50fb0ef          	jal	80000d62 <mycpu>
    80005916:	5d3c                	lw	a5,120(a0)
    80005918:	cb99                	beqz	a5,8000592e <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    8000591a:	c48fb0ef          	jal	80000d62 <mycpu>
    8000591e:	5d3c                	lw	a5,120(a0)
    80005920:	2785                	addiw	a5,a5,1
    80005922:	dd3c                	sw	a5,120(a0)
}
    80005924:	60e2                	ld	ra,24(sp)
    80005926:	6442                	ld	s0,16(sp)
    80005928:	64a2                	ld	s1,8(sp)
    8000592a:	6105                	addi	sp,sp,32
    8000592c:	8082                	ret
    mycpu()->intena = old;
    8000592e:	c34fb0ef          	jal	80000d62 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80005932:	0014d793          	srli	a5,s1,0x1
    80005936:	8b85                	andi	a5,a5,1
    80005938:	dd7c                	sw	a5,124(a0)
    8000593a:	b7c5                	j	8000591a <push_off+0x22>

000000008000593c <acquire>:
{
    8000593c:	1101                	addi	sp,sp,-32
    8000593e:	ec06                	sd	ra,24(sp)
    80005940:	e822                	sd	s0,16(sp)
    80005942:	e426                	sd	s1,8(sp)
    80005944:	1000                	addi	s0,sp,32
    80005946:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80005948:	fb1ff0ef          	jal	800058f8 <push_off>
  if(holding(lk))
    8000594c:	8526                	mv	a0,s1
    8000594e:	f7fff0ef          	jal	800058cc <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005952:	4705                	li	a4,1
  if(holding(lk))
    80005954:	e105                	bnez	a0,80005974 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005956:	87ba                	mv	a5,a4
    80005958:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    8000595c:	2781                	sext.w	a5,a5
    8000595e:	ffe5                	bnez	a5,80005956 <acquire+0x1a>
  __sync_synchronize();
    80005960:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80005964:	bfefb0ef          	jal	80000d62 <mycpu>
    80005968:	e888                	sd	a0,16(s1)
}
    8000596a:	60e2                	ld	ra,24(sp)
    8000596c:	6442                	ld	s0,16(sp)
    8000596e:	64a2                	ld	s1,8(sp)
    80005970:	6105                	addi	sp,sp,32
    80005972:	8082                	ret
    panic("acquire");
    80005974:	00002517          	auipc	a0,0x2
    80005978:	de450513          	addi	a0,a0,-540 # 80007758 <etext+0x758>
    8000597c:	cadff0ef          	jal	80005628 <panic>

0000000080005980 <pop_off>:

void
pop_off(void)
{
    80005980:	1141                	addi	sp,sp,-16
    80005982:	e406                	sd	ra,8(sp)
    80005984:	e022                	sd	s0,0(sp)
    80005986:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005988:	bdafb0ef          	jal	80000d62 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000598c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80005990:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005992:	e39d                	bnez	a5,800059b8 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005994:	5d3c                	lw	a5,120(a0)
    80005996:	02f05763          	blez	a5,800059c4 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    8000599a:	37fd                	addiw	a5,a5,-1
    8000599c:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    8000599e:	eb89                	bnez	a5,800059b0 <pop_off+0x30>
    800059a0:	5d7c                	lw	a5,124(a0)
    800059a2:	c799                	beqz	a5,800059b0 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800059a4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800059a8:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800059ac:	10079073          	csrw	sstatus,a5
    intr_on();
}
    800059b0:	60a2                	ld	ra,8(sp)
    800059b2:	6402                	ld	s0,0(sp)
    800059b4:	0141                	addi	sp,sp,16
    800059b6:	8082                	ret
    panic("pop_off - interruptible");
    800059b8:	00002517          	auipc	a0,0x2
    800059bc:	da850513          	addi	a0,a0,-600 # 80007760 <etext+0x760>
    800059c0:	c69ff0ef          	jal	80005628 <panic>
    panic("pop_off");
    800059c4:	00002517          	auipc	a0,0x2
    800059c8:	db450513          	addi	a0,a0,-588 # 80007778 <etext+0x778>
    800059cc:	c5dff0ef          	jal	80005628 <panic>

00000000800059d0 <release>:
{
    800059d0:	1101                	addi	sp,sp,-32
    800059d2:	ec06                	sd	ra,24(sp)
    800059d4:	e822                	sd	s0,16(sp)
    800059d6:	e426                	sd	s1,8(sp)
    800059d8:	1000                	addi	s0,sp,32
    800059da:	84aa                	mv	s1,a0
  if(!holding(lk))
    800059dc:	ef1ff0ef          	jal	800058cc <holding>
    800059e0:	c105                	beqz	a0,80005a00 <release+0x30>
  lk->cpu = 0;
    800059e2:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    800059e6:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    800059ea:	0310000f          	fence	rw,w
    800059ee:	0004a023          	sw	zero,0(s1)
  pop_off();
    800059f2:	f8fff0ef          	jal	80005980 <pop_off>
}
    800059f6:	60e2                	ld	ra,24(sp)
    800059f8:	6442                	ld	s0,16(sp)
    800059fa:	64a2                	ld	s1,8(sp)
    800059fc:	6105                	addi	sp,sp,32
    800059fe:	8082                	ret
    panic("release");
    80005a00:	00002517          	auipc	a0,0x2
    80005a04:	d8050513          	addi	a0,a0,-640 # 80007780 <etext+0x780>
    80005a08:	c21ff0ef          	jal	80005628 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
