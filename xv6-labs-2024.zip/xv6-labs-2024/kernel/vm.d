kernel/vm.o: kernel/vm.c kernel/param.h kernel/types.h kernel/memlayout.h \
 kernel/elf.h kernel/riscv.h kernel/defs.h kernel/spinlock.h \
 kernel/proc.h kernel/fs.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/lib/gcc/riscv64-unknown-elf/15.1.0/include/stdint.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/stdint.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/machine/_default_types.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/features.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/_newlib_version.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/_intsup.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/_stdint.h
