
user/_stats:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#define SZ 4096
char buf[SZ];

int
main(void)
{
   0:	7139                	addi	sp,sp,-64
   2:	fc06                	sd	ra,56(sp)
   4:	f822                	sd	s0,48(sp)
   6:	f426                	sd	s1,40(sp)
   8:	f04a                	sd	s2,32(sp)
   a:	ec4e                	sd	s3,24(sp)
   c:	e852                	sd	s4,16(sp)
   e:	e456                	sd	s5,8(sp)
  10:	e05a                	sd	s6,0(sp)
  12:	0080                	addi	s0,sp,64
  int i, n;
  
  while (1) {
    n = statistics(buf, SZ);
  14:	6a85                	lui	s5,0x1
  16:	00001b17          	auipc	s6,0x1
  1a:	ffab0b13          	addi	s6,s6,-6 # 1010 <buf>
    for (i = 0; i < n; i++) {
      write(1, buf+i, 1);
  1e:	4905                	li	s2,1
    n = statistics(buf, SZ);
  20:	85d6                	mv	a1,s5
  22:	855a                	mv	a0,s6
  24:	097000ef          	jal	8ba <statistics>
  28:	8a2a                	mv	s4,a0
    for (i = 0; i < n; i++) {
  2a:	02a05263          	blez	a0,4e <main+0x4e>
  2e:	00001497          	auipc	s1,0x1
  32:	fe248493          	addi	s1,s1,-30 # 1010 <buf>
  36:	009509b3          	add	s3,a0,s1
      write(1, buf+i, 1);
  3a:	864a                	mv	a2,s2
  3c:	85a6                	mv	a1,s1
  3e:	854a                	mv	a0,s2
  40:	2c0000ef          	jal	300 <write>
    for (i = 0; i < n; i++) {
  44:	0485                	addi	s1,s1,1
  46:	ff349ae3          	bne	s1,s3,3a <main+0x3a>
    }
    if (n != SZ)
  4a:	fd5a0be3          	beq	s4,s5,20 <main+0x20>
      break;
  }

  exit(0);
  4e:	4501                	li	a0,0
  50:	290000ef          	jal	2e0 <exit>

0000000000000054 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  54:	1141                	addi	sp,sp,-16
  56:	e406                	sd	ra,8(sp)
  58:	e022                	sd	s0,0(sp)
  5a:	0800                	addi	s0,sp,16
  extern int main();
  main();
  5c:	fa5ff0ef          	jal	0 <main>
  exit(0);
  60:	4501                	li	a0,0
  62:	27e000ef          	jal	2e0 <exit>

0000000000000066 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  66:	1141                	addi	sp,sp,-16
  68:	e406                	sd	ra,8(sp)
  6a:	e022                	sd	s0,0(sp)
  6c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  6e:	87aa                	mv	a5,a0
  70:	0585                	addi	a1,a1,1
  72:	0785                	addi	a5,a5,1
  74:	fff5c703          	lbu	a4,-1(a1)
  78:	fee78fa3          	sb	a4,-1(a5)
  7c:	fb75                	bnez	a4,70 <strcpy+0xa>
    ;
  return os;
}
  7e:	60a2                	ld	ra,8(sp)
  80:	6402                	ld	s0,0(sp)
  82:	0141                	addi	sp,sp,16
  84:	8082                	ret

0000000000000086 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  86:	1141                	addi	sp,sp,-16
  88:	e406                	sd	ra,8(sp)
  8a:	e022                	sd	s0,0(sp)
  8c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  8e:	00054783          	lbu	a5,0(a0)
  92:	cb91                	beqz	a5,a6 <strcmp+0x20>
  94:	0005c703          	lbu	a4,0(a1)
  98:	00f71763          	bne	a4,a5,a6 <strcmp+0x20>
    p++, q++;
  9c:	0505                	addi	a0,a0,1
  9e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  a0:	00054783          	lbu	a5,0(a0)
  a4:	fbe5                	bnez	a5,94 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  a6:	0005c503          	lbu	a0,0(a1)
}
  aa:	40a7853b          	subw	a0,a5,a0
  ae:	60a2                	ld	ra,8(sp)
  b0:	6402                	ld	s0,0(sp)
  b2:	0141                	addi	sp,sp,16
  b4:	8082                	ret

00000000000000b6 <strlen>:

uint
strlen(const char *s)
{
  b6:	1141                	addi	sp,sp,-16
  b8:	e406                	sd	ra,8(sp)
  ba:	e022                	sd	s0,0(sp)
  bc:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  be:	00054783          	lbu	a5,0(a0)
  c2:	cf91                	beqz	a5,de <strlen+0x28>
  c4:	00150793          	addi	a5,a0,1
  c8:	86be                	mv	a3,a5
  ca:	0785                	addi	a5,a5,1
  cc:	fff7c703          	lbu	a4,-1(a5)
  d0:	ff65                	bnez	a4,c8 <strlen+0x12>
  d2:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  d6:	60a2                	ld	ra,8(sp)
  d8:	6402                	ld	s0,0(sp)
  da:	0141                	addi	sp,sp,16
  dc:	8082                	ret
  for(n = 0; s[n]; n++)
  de:	4501                	li	a0,0
  e0:	bfdd                	j	d6 <strlen+0x20>

00000000000000e2 <memset>:

void*
memset(void *dst, int c, uint n)
{
  e2:	1141                	addi	sp,sp,-16
  e4:	e406                	sd	ra,8(sp)
  e6:	e022                	sd	s0,0(sp)
  e8:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  ea:	ca19                	beqz	a2,100 <memset+0x1e>
  ec:	87aa                	mv	a5,a0
  ee:	1602                	slli	a2,a2,0x20
  f0:	9201                	srli	a2,a2,0x20
  f2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  f6:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  fa:	0785                	addi	a5,a5,1
  fc:	fee79de3          	bne	a5,a4,f6 <memset+0x14>
  }
  return dst;
}
 100:	60a2                	ld	ra,8(sp)
 102:	6402                	ld	s0,0(sp)
 104:	0141                	addi	sp,sp,16
 106:	8082                	ret

0000000000000108 <strchr>:

char*
strchr(const char *s, char c)
{
 108:	1141                	addi	sp,sp,-16
 10a:	e406                	sd	ra,8(sp)
 10c:	e022                	sd	s0,0(sp)
 10e:	0800                	addi	s0,sp,16
  for(; *s; s++)
 110:	00054783          	lbu	a5,0(a0)
 114:	cf81                	beqz	a5,12c <strchr+0x24>
    if(*s == c)
 116:	00f58763          	beq	a1,a5,124 <strchr+0x1c>
  for(; *s; s++)
 11a:	0505                	addi	a0,a0,1
 11c:	00054783          	lbu	a5,0(a0)
 120:	fbfd                	bnez	a5,116 <strchr+0xe>
      return (char*)s;
  return 0;
 122:	4501                	li	a0,0
}
 124:	60a2                	ld	ra,8(sp)
 126:	6402                	ld	s0,0(sp)
 128:	0141                	addi	sp,sp,16
 12a:	8082                	ret
  return 0;
 12c:	4501                	li	a0,0
 12e:	bfdd                	j	124 <strchr+0x1c>

0000000000000130 <gets>:

char*
gets(char *buf, int max)
{
 130:	711d                	addi	sp,sp,-96
 132:	ec86                	sd	ra,88(sp)
 134:	e8a2                	sd	s0,80(sp)
 136:	e4a6                	sd	s1,72(sp)
 138:	e0ca                	sd	s2,64(sp)
 13a:	fc4e                	sd	s3,56(sp)
 13c:	f852                	sd	s4,48(sp)
 13e:	f456                	sd	s5,40(sp)
 140:	f05a                	sd	s6,32(sp)
 142:	ec5e                	sd	s7,24(sp)
 144:	e862                	sd	s8,16(sp)
 146:	1080                	addi	s0,sp,96
 148:	8baa                	mv	s7,a0
 14a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 14c:	892a                	mv	s2,a0
 14e:	4481                	li	s1,0
    cc = read(0, &c, 1);
 150:	faf40b13          	addi	s6,s0,-81
 154:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 156:	8c26                	mv	s8,s1
 158:	0014899b          	addiw	s3,s1,1
 15c:	84ce                	mv	s1,s3
 15e:	0349d463          	bge	s3,s4,186 <gets+0x56>
    cc = read(0, &c, 1);
 162:	8656                	mv	a2,s5
 164:	85da                	mv	a1,s6
 166:	4501                	li	a0,0
 168:	190000ef          	jal	2f8 <read>
    if(cc < 1)
 16c:	00a05d63          	blez	a0,186 <gets+0x56>
      break;
    buf[i++] = c;
 170:	faf44783          	lbu	a5,-81(s0)
 174:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 178:	0905                	addi	s2,s2,1
 17a:	ff678713          	addi	a4,a5,-10
 17e:	c319                	beqz	a4,184 <gets+0x54>
 180:	17cd                	addi	a5,a5,-13
 182:	fbf1                	bnez	a5,156 <gets+0x26>
    buf[i++] = c;
 184:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 186:	9c5e                	add	s8,s8,s7
 188:	000c0023          	sb	zero,0(s8)
  return buf;
}
 18c:	855e                	mv	a0,s7
 18e:	60e6                	ld	ra,88(sp)
 190:	6446                	ld	s0,80(sp)
 192:	64a6                	ld	s1,72(sp)
 194:	6906                	ld	s2,64(sp)
 196:	79e2                	ld	s3,56(sp)
 198:	7a42                	ld	s4,48(sp)
 19a:	7aa2                	ld	s5,40(sp)
 19c:	7b02                	ld	s6,32(sp)
 19e:	6be2                	ld	s7,24(sp)
 1a0:	6c42                	ld	s8,16(sp)
 1a2:	6125                	addi	sp,sp,96
 1a4:	8082                	ret

00000000000001a6 <stat>:

int
stat(const char *n, struct stat *st)
{
 1a6:	1101                	addi	sp,sp,-32
 1a8:	ec06                	sd	ra,24(sp)
 1aa:	e822                	sd	s0,16(sp)
 1ac:	e04a                	sd	s2,0(sp)
 1ae:	1000                	addi	s0,sp,32
 1b0:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1b2:	4581                	li	a1,0
 1b4:	16c000ef          	jal	320 <open>
  if(fd < 0)
 1b8:	02054263          	bltz	a0,1dc <stat+0x36>
 1bc:	e426                	sd	s1,8(sp)
 1be:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 1c0:	85ca                	mv	a1,s2
 1c2:	176000ef          	jal	338 <fstat>
 1c6:	892a                	mv	s2,a0
  close(fd);
 1c8:	8526                	mv	a0,s1
 1ca:	13e000ef          	jal	308 <close>
  return r;
 1ce:	64a2                	ld	s1,8(sp)
}
 1d0:	854a                	mv	a0,s2
 1d2:	60e2                	ld	ra,24(sp)
 1d4:	6442                	ld	s0,16(sp)
 1d6:	6902                	ld	s2,0(sp)
 1d8:	6105                	addi	sp,sp,32
 1da:	8082                	ret
    return -1;
 1dc:	57fd                	li	a5,-1
 1de:	893e                	mv	s2,a5
 1e0:	bfc5                	j	1d0 <stat+0x2a>

00000000000001e2 <atoi>:

int
atoi(const char *s)
{
 1e2:	1141                	addi	sp,sp,-16
 1e4:	e406                	sd	ra,8(sp)
 1e6:	e022                	sd	s0,0(sp)
 1e8:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1ea:	00054683          	lbu	a3,0(a0)
 1ee:	fd06879b          	addiw	a5,a3,-48
 1f2:	0ff7f793          	zext.b	a5,a5
 1f6:	4625                	li	a2,9
 1f8:	02f66963          	bltu	a2,a5,22a <atoi+0x48>
 1fc:	872a                	mv	a4,a0
  n = 0;
 1fe:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 200:	0705                	addi	a4,a4,1
 202:	0025179b          	slliw	a5,a0,0x2
 206:	9fa9                	addw	a5,a5,a0
 208:	0017979b          	slliw	a5,a5,0x1
 20c:	9fb5                	addw	a5,a5,a3
 20e:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 212:	00074683          	lbu	a3,0(a4)
 216:	fd06879b          	addiw	a5,a3,-48
 21a:	0ff7f793          	zext.b	a5,a5
 21e:	fef671e3          	bgeu	a2,a5,200 <atoi+0x1e>
  return n;
}
 222:	60a2                	ld	ra,8(sp)
 224:	6402                	ld	s0,0(sp)
 226:	0141                	addi	sp,sp,16
 228:	8082                	ret
  n = 0;
 22a:	4501                	li	a0,0
 22c:	bfdd                	j	222 <atoi+0x40>

000000000000022e <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 22e:	1141                	addi	sp,sp,-16
 230:	e406                	sd	ra,8(sp)
 232:	e022                	sd	s0,0(sp)
 234:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 236:	02b57563          	bgeu	a0,a1,260 <memmove+0x32>
    while(n-- > 0)
 23a:	00c05f63          	blez	a2,258 <memmove+0x2a>
 23e:	1602                	slli	a2,a2,0x20
 240:	9201                	srli	a2,a2,0x20
 242:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 246:	872a                	mv	a4,a0
      *dst++ = *src++;
 248:	0585                	addi	a1,a1,1
 24a:	0705                	addi	a4,a4,1
 24c:	fff5c683          	lbu	a3,-1(a1)
 250:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 254:	fee79ae3          	bne	a5,a4,248 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 258:	60a2                	ld	ra,8(sp)
 25a:	6402                	ld	s0,0(sp)
 25c:	0141                	addi	sp,sp,16
 25e:	8082                	ret
    while(n-- > 0)
 260:	fec05ce3          	blez	a2,258 <memmove+0x2a>
    dst += n;
 264:	00c50733          	add	a4,a0,a2
    src += n;
 268:	95b2                	add	a1,a1,a2
 26a:	fff6079b          	addiw	a5,a2,-1
 26e:	1782                	slli	a5,a5,0x20
 270:	9381                	srli	a5,a5,0x20
 272:	fff7c793          	not	a5,a5
 276:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 278:	15fd                	addi	a1,a1,-1
 27a:	177d                	addi	a4,a4,-1
 27c:	0005c683          	lbu	a3,0(a1)
 280:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 284:	fef71ae3          	bne	a4,a5,278 <memmove+0x4a>
 288:	bfc1                	j	258 <memmove+0x2a>

000000000000028a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 28a:	1141                	addi	sp,sp,-16
 28c:	e406                	sd	ra,8(sp)
 28e:	e022                	sd	s0,0(sp)
 290:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 292:	c61d                	beqz	a2,2c0 <memcmp+0x36>
 294:	1602                	slli	a2,a2,0x20
 296:	9201                	srli	a2,a2,0x20
 298:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 29c:	00054783          	lbu	a5,0(a0)
 2a0:	0005c703          	lbu	a4,0(a1)
 2a4:	00e79863          	bne	a5,a4,2b4 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 2a8:	0505                	addi	a0,a0,1
    p2++;
 2aa:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 2ac:	fed518e3          	bne	a0,a3,29c <memcmp+0x12>
  }
  return 0;
 2b0:	4501                	li	a0,0
 2b2:	a019                	j	2b8 <memcmp+0x2e>
      return *p1 - *p2;
 2b4:	40e7853b          	subw	a0,a5,a4
}
 2b8:	60a2                	ld	ra,8(sp)
 2ba:	6402                	ld	s0,0(sp)
 2bc:	0141                	addi	sp,sp,16
 2be:	8082                	ret
  return 0;
 2c0:	4501                	li	a0,0
 2c2:	bfdd                	j	2b8 <memcmp+0x2e>

00000000000002c4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 2c4:	1141                	addi	sp,sp,-16
 2c6:	e406                	sd	ra,8(sp)
 2c8:	e022                	sd	s0,0(sp)
 2ca:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 2cc:	f63ff0ef          	jal	22e <memmove>
}
 2d0:	60a2                	ld	ra,8(sp)
 2d2:	6402                	ld	s0,0(sp)
 2d4:	0141                	addi	sp,sp,16
 2d6:	8082                	ret

00000000000002d8 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2d8:	4885                	li	a7,1
 ecall
 2da:	00000073          	ecall
 ret
 2de:	8082                	ret

00000000000002e0 <exit>:
.global exit
exit:
 li a7, SYS_exit
 2e0:	4889                	li	a7,2
 ecall
 2e2:	00000073          	ecall
 ret
 2e6:	8082                	ret

00000000000002e8 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2e8:	488d                	li	a7,3
 ecall
 2ea:	00000073          	ecall
 ret
 2ee:	8082                	ret

00000000000002f0 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2f0:	4891                	li	a7,4
 ecall
 2f2:	00000073          	ecall
 ret
 2f6:	8082                	ret

00000000000002f8 <read>:
.global read
read:
 li a7, SYS_read
 2f8:	4895                	li	a7,5
 ecall
 2fa:	00000073          	ecall
 ret
 2fe:	8082                	ret

0000000000000300 <write>:
.global write
write:
 li a7, SYS_write
 300:	48c1                	li	a7,16
 ecall
 302:	00000073          	ecall
 ret
 306:	8082                	ret

0000000000000308 <close>:
.global close
close:
 li a7, SYS_close
 308:	48d5                	li	a7,21
 ecall
 30a:	00000073          	ecall
 ret
 30e:	8082                	ret

0000000000000310 <kill>:
.global kill
kill:
 li a7, SYS_kill
 310:	4899                	li	a7,6
 ecall
 312:	00000073          	ecall
 ret
 316:	8082                	ret

0000000000000318 <exec>:
.global exec
exec:
 li a7, SYS_exec
 318:	489d                	li	a7,7
 ecall
 31a:	00000073          	ecall
 ret
 31e:	8082                	ret

0000000000000320 <open>:
.global open
open:
 li a7, SYS_open
 320:	48bd                	li	a7,15
 ecall
 322:	00000073          	ecall
 ret
 326:	8082                	ret

0000000000000328 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 328:	48c5                	li	a7,17
 ecall
 32a:	00000073          	ecall
 ret
 32e:	8082                	ret

0000000000000330 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 330:	48c9                	li	a7,18
 ecall
 332:	00000073          	ecall
 ret
 336:	8082                	ret

0000000000000338 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 338:	48a1                	li	a7,8
 ecall
 33a:	00000073          	ecall
 ret
 33e:	8082                	ret

0000000000000340 <link>:
.global link
link:
 li a7, SYS_link
 340:	48cd                	li	a7,19
 ecall
 342:	00000073          	ecall
 ret
 346:	8082                	ret

0000000000000348 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 348:	48d1                	li	a7,20
 ecall
 34a:	00000073          	ecall
 ret
 34e:	8082                	ret

0000000000000350 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 350:	48a5                	li	a7,9
 ecall
 352:	00000073          	ecall
 ret
 356:	8082                	ret

0000000000000358 <dup>:
.global dup
dup:
 li a7, SYS_dup
 358:	48a9                	li	a7,10
 ecall
 35a:	00000073          	ecall
 ret
 35e:	8082                	ret

0000000000000360 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 360:	48ad                	li	a7,11
 ecall
 362:	00000073          	ecall
 ret
 366:	8082                	ret

0000000000000368 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 368:	48b1                	li	a7,12
 ecall
 36a:	00000073          	ecall
 ret
 36e:	8082                	ret

0000000000000370 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 370:	48b5                	li	a7,13
 ecall
 372:	00000073          	ecall
 ret
 376:	8082                	ret

0000000000000378 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 378:	48b9                	li	a7,14
 ecall
 37a:	00000073          	ecall
 ret
 37e:	8082                	ret

0000000000000380 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 380:	1101                	addi	sp,sp,-32
 382:	ec06                	sd	ra,24(sp)
 384:	e822                	sd	s0,16(sp)
 386:	1000                	addi	s0,sp,32
 388:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 38c:	4605                	li	a2,1
 38e:	fef40593          	addi	a1,s0,-17
 392:	f6fff0ef          	jal	300 <write>
}
 396:	60e2                	ld	ra,24(sp)
 398:	6442                	ld	s0,16(sp)
 39a:	6105                	addi	sp,sp,32
 39c:	8082                	ret

000000000000039e <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 39e:	7139                	addi	sp,sp,-64
 3a0:	fc06                	sd	ra,56(sp)
 3a2:	f822                	sd	s0,48(sp)
 3a4:	f04a                	sd	s2,32(sp)
 3a6:	ec4e                	sd	s3,24(sp)
 3a8:	0080                	addi	s0,sp,64
 3aa:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 3ac:	cac9                	beqz	a3,43e <printint+0xa0>
 3ae:	01f5d79b          	srliw	a5,a1,0x1f
 3b2:	c7d1                	beqz	a5,43e <printint+0xa0>
    neg = 1;
    x = -xx;
 3b4:	40b005bb          	negw	a1,a1
    neg = 1;
 3b8:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 3ba:	fc040993          	addi	s3,s0,-64
  neg = 0;
 3be:	86ce                	mv	a3,s3
  i = 0;
 3c0:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 3c2:	00000817          	auipc	a6,0x0
 3c6:	59e80813          	addi	a6,a6,1438 # 960 <digits>
 3ca:	88ba                	mv	a7,a4
 3cc:	0017051b          	addiw	a0,a4,1
 3d0:	872a                	mv	a4,a0
 3d2:	02c5f7bb          	remuw	a5,a1,a2
 3d6:	1782                	slli	a5,a5,0x20
 3d8:	9381                	srli	a5,a5,0x20
 3da:	97c2                	add	a5,a5,a6
 3dc:	0007c783          	lbu	a5,0(a5)
 3e0:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 3e4:	87ae                	mv	a5,a1
 3e6:	02c5d5bb          	divuw	a1,a1,a2
 3ea:	0685                	addi	a3,a3,1
 3ec:	fcc7ffe3          	bgeu	a5,a2,3ca <printint+0x2c>
  if(neg)
 3f0:	00030c63          	beqz	t1,408 <printint+0x6a>
    buf[i++] = '-';
 3f4:	fd050793          	addi	a5,a0,-48
 3f8:	00878533          	add	a0,a5,s0
 3fc:	02d00793          	li	a5,45
 400:	fef50823          	sb	a5,-16(a0)
 404:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 408:	02e05563          	blez	a4,432 <printint+0x94>
 40c:	f426                	sd	s1,40(sp)
 40e:	377d                	addiw	a4,a4,-1
 410:	00e984b3          	add	s1,s3,a4
 414:	19fd                	addi	s3,s3,-1
 416:	99ba                	add	s3,s3,a4
 418:	1702                	slli	a4,a4,0x20
 41a:	9301                	srli	a4,a4,0x20
 41c:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 420:	0004c583          	lbu	a1,0(s1)
 424:	854a                	mv	a0,s2
 426:	f5bff0ef          	jal	380 <putc>
  while(--i >= 0)
 42a:	14fd                	addi	s1,s1,-1
 42c:	ff349ae3          	bne	s1,s3,420 <printint+0x82>
 430:	74a2                	ld	s1,40(sp)
}
 432:	70e2                	ld	ra,56(sp)
 434:	7442                	ld	s0,48(sp)
 436:	7902                	ld	s2,32(sp)
 438:	69e2                	ld	s3,24(sp)
 43a:	6121                	addi	sp,sp,64
 43c:	8082                	ret
  neg = 0;
 43e:	4301                	li	t1,0
 440:	bfad                	j	3ba <printint+0x1c>

0000000000000442 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 442:	711d                	addi	sp,sp,-96
 444:	ec86                	sd	ra,88(sp)
 446:	e8a2                	sd	s0,80(sp)
 448:	e4a6                	sd	s1,72(sp)
 44a:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 44c:	0005c483          	lbu	s1,0(a1)
 450:	20048963          	beqz	s1,662 <vprintf+0x220>
 454:	e0ca                	sd	s2,64(sp)
 456:	fc4e                	sd	s3,56(sp)
 458:	f852                	sd	s4,48(sp)
 45a:	f456                	sd	s5,40(sp)
 45c:	f05a                	sd	s6,32(sp)
 45e:	ec5e                	sd	s7,24(sp)
 460:	e862                	sd	s8,16(sp)
 462:	8b2a                	mv	s6,a0
 464:	8a2e                	mv	s4,a1
 466:	8bb2                	mv	s7,a2
  state = 0;
 468:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 46a:	4901                	li	s2,0
 46c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 46e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 472:	06400c13          	li	s8,100
 476:	a00d                	j	498 <vprintf+0x56>
        putc(fd, c0);
 478:	85a6                	mv	a1,s1
 47a:	855a                	mv	a0,s6
 47c:	f05ff0ef          	jal	380 <putc>
 480:	a019                	j	486 <vprintf+0x44>
    } else if(state == '%'){
 482:	03598363          	beq	s3,s5,4a8 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 486:	0019079b          	addiw	a5,s2,1
 48a:	893e                	mv	s2,a5
 48c:	873e                	mv	a4,a5
 48e:	97d2                	add	a5,a5,s4
 490:	0007c483          	lbu	s1,0(a5)
 494:	1c048063          	beqz	s1,654 <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 498:	0004879b          	sext.w	a5,s1
    if(state == 0){
 49c:	fe0993e3          	bnez	s3,482 <vprintf+0x40>
      if(c0 == '%'){
 4a0:	fd579ce3          	bne	a5,s5,478 <vprintf+0x36>
        state = '%';
 4a4:	89be                	mv	s3,a5
 4a6:	b7c5                	j	486 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 4a8:	00ea06b3          	add	a3,s4,a4
 4ac:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 4b0:	1a060e63          	beqz	a2,66c <vprintf+0x22a>
      if(c0 == 'd'){
 4b4:	03878763          	beq	a5,s8,4e2 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 4b8:	f9478693          	addi	a3,a5,-108
 4bc:	0016b693          	seqz	a3,a3
 4c0:	f9c60593          	addi	a1,a2,-100
 4c4:	e99d                	bnez	a1,4fa <vprintf+0xb8>
 4c6:	ca95                	beqz	a3,4fa <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 4c8:	008b8493          	addi	s1,s7,8
 4cc:	4685                	li	a3,1
 4ce:	4629                	li	a2,10
 4d0:	000ba583          	lw	a1,0(s7)
 4d4:	855a                	mv	a0,s6
 4d6:	ec9ff0ef          	jal	39e <printint>
        i += 1;
 4da:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 4dc:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 4de:	4981                	li	s3,0
 4e0:	b75d                	j	486 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 4e2:	008b8493          	addi	s1,s7,8
 4e6:	4685                	li	a3,1
 4e8:	4629                	li	a2,10
 4ea:	000ba583          	lw	a1,0(s7)
 4ee:	855a                	mv	a0,s6
 4f0:	eafff0ef          	jal	39e <printint>
 4f4:	8ba6                	mv	s7,s1
      state = 0;
 4f6:	4981                	li	s3,0
 4f8:	b779                	j	486 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 4fa:	9752                	add	a4,a4,s4
 4fc:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 500:	f9460713          	addi	a4,a2,-108
 504:	00173713          	seqz	a4,a4
 508:	8f75                	and	a4,a4,a3
 50a:	f9c58513          	addi	a0,a1,-100
 50e:	16051963          	bnez	a0,680 <vprintf+0x23e>
 512:	16070763          	beqz	a4,680 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 516:	008b8493          	addi	s1,s7,8
 51a:	4685                	li	a3,1
 51c:	4629                	li	a2,10
 51e:	000ba583          	lw	a1,0(s7)
 522:	855a                	mv	a0,s6
 524:	e7bff0ef          	jal	39e <printint>
        i += 2;
 528:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 52a:	8ba6                	mv	s7,s1
      state = 0;
 52c:	4981                	li	s3,0
        i += 2;
 52e:	bfa1                	j	486 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 530:	008b8493          	addi	s1,s7,8
 534:	4681                	li	a3,0
 536:	4629                	li	a2,10
 538:	000ba583          	lw	a1,0(s7)
 53c:	855a                	mv	a0,s6
 53e:	e61ff0ef          	jal	39e <printint>
 542:	8ba6                	mv	s7,s1
      state = 0;
 544:	4981                	li	s3,0
 546:	b781                	j	486 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 548:	008b8493          	addi	s1,s7,8
 54c:	4681                	li	a3,0
 54e:	4629                	li	a2,10
 550:	000ba583          	lw	a1,0(s7)
 554:	855a                	mv	a0,s6
 556:	e49ff0ef          	jal	39e <printint>
        i += 1;
 55a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 55c:	8ba6                	mv	s7,s1
      state = 0;
 55e:	4981                	li	s3,0
 560:	b71d                	j	486 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 562:	008b8493          	addi	s1,s7,8
 566:	4681                	li	a3,0
 568:	4629                	li	a2,10
 56a:	000ba583          	lw	a1,0(s7)
 56e:	855a                	mv	a0,s6
 570:	e2fff0ef          	jal	39e <printint>
        i += 2;
 574:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 576:	8ba6                	mv	s7,s1
      state = 0;
 578:	4981                	li	s3,0
        i += 2;
 57a:	b731                	j	486 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 57c:	008b8493          	addi	s1,s7,8
 580:	4681                	li	a3,0
 582:	4641                	li	a2,16
 584:	000ba583          	lw	a1,0(s7)
 588:	855a                	mv	a0,s6
 58a:	e15ff0ef          	jal	39e <printint>
 58e:	8ba6                	mv	s7,s1
      state = 0;
 590:	4981                	li	s3,0
 592:	bdd5                	j	486 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 594:	008b8493          	addi	s1,s7,8
 598:	4681                	li	a3,0
 59a:	4641                	li	a2,16
 59c:	000ba583          	lw	a1,0(s7)
 5a0:	855a                	mv	a0,s6
 5a2:	dfdff0ef          	jal	39e <printint>
        i += 1;
 5a6:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 5a8:	8ba6                	mv	s7,s1
      state = 0;
 5aa:	4981                	li	s3,0
 5ac:	bde9                	j	486 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5ae:	008b8493          	addi	s1,s7,8
 5b2:	4681                	li	a3,0
 5b4:	4641                	li	a2,16
 5b6:	000ba583          	lw	a1,0(s7)
 5ba:	855a                	mv	a0,s6
 5bc:	de3ff0ef          	jal	39e <printint>
        i += 2;
 5c0:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 5c2:	8ba6                	mv	s7,s1
      state = 0;
 5c4:	4981                	li	s3,0
        i += 2;
 5c6:	b5c1                	j	486 <vprintf+0x44>
 5c8:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 5ca:	008b8793          	addi	a5,s7,8
 5ce:	8cbe                	mv	s9,a5
 5d0:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 5d4:	03000593          	li	a1,48
 5d8:	855a                	mv	a0,s6
 5da:	da7ff0ef          	jal	380 <putc>
  putc(fd, 'x');
 5de:	07800593          	li	a1,120
 5e2:	855a                	mv	a0,s6
 5e4:	d9dff0ef          	jal	380 <putc>
 5e8:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5ea:	00000b97          	auipc	s7,0x0
 5ee:	376b8b93          	addi	s7,s7,886 # 960 <digits>
 5f2:	03c9d793          	srli	a5,s3,0x3c
 5f6:	97de                	add	a5,a5,s7
 5f8:	0007c583          	lbu	a1,0(a5)
 5fc:	855a                	mv	a0,s6
 5fe:	d83ff0ef          	jal	380 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 602:	0992                	slli	s3,s3,0x4
 604:	34fd                	addiw	s1,s1,-1
 606:	f4f5                	bnez	s1,5f2 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 608:	8be6                	mv	s7,s9
      state = 0;
 60a:	4981                	li	s3,0
 60c:	6ca2                	ld	s9,8(sp)
 60e:	bda5                	j	486 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 610:	008b8993          	addi	s3,s7,8
 614:	000bb483          	ld	s1,0(s7)
 618:	cc91                	beqz	s1,634 <vprintf+0x1f2>
        for(; *s; s++)
 61a:	0004c583          	lbu	a1,0(s1)
 61e:	c985                	beqz	a1,64e <vprintf+0x20c>
          putc(fd, *s);
 620:	855a                	mv	a0,s6
 622:	d5fff0ef          	jal	380 <putc>
        for(; *s; s++)
 626:	0485                	addi	s1,s1,1
 628:	0004c583          	lbu	a1,0(s1)
 62c:	f9f5                	bnez	a1,620 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 62e:	8bce                	mv	s7,s3
      state = 0;
 630:	4981                	li	s3,0
 632:	bd91                	j	486 <vprintf+0x44>
          s = "(null)";
 634:	00000497          	auipc	s1,0x0
 638:	2fc48493          	addi	s1,s1,764 # 930 <statistics+0x76>
        for(; *s; s++)
 63c:	02800593          	li	a1,40
 640:	b7c5                	j	620 <vprintf+0x1de>
        putc(fd, '%');
 642:	85be                	mv	a1,a5
 644:	855a                	mv	a0,s6
 646:	d3bff0ef          	jal	380 <putc>
      state = 0;
 64a:	4981                	li	s3,0
 64c:	bd2d                	j	486 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 64e:	8bce                	mv	s7,s3
      state = 0;
 650:	4981                	li	s3,0
 652:	bd15                	j	486 <vprintf+0x44>
 654:	6906                	ld	s2,64(sp)
 656:	79e2                	ld	s3,56(sp)
 658:	7a42                	ld	s4,48(sp)
 65a:	7aa2                	ld	s5,40(sp)
 65c:	7b02                	ld	s6,32(sp)
 65e:	6be2                	ld	s7,24(sp)
 660:	6c42                	ld	s8,16(sp)
    }
  }
}
 662:	60e6                	ld	ra,88(sp)
 664:	6446                	ld	s0,80(sp)
 666:	64a6                	ld	s1,72(sp)
 668:	6125                	addi	sp,sp,96
 66a:	8082                	ret
      if(c0 == 'd'){
 66c:	06400713          	li	a4,100
 670:	e6e789e3          	beq	a5,a4,4e2 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 674:	f9478693          	addi	a3,a5,-108
 678:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 67c:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 67e:	4701                	li	a4,0
      } else if(c0 == 'u'){
 680:	07500513          	li	a0,117
 684:	eaa786e3          	beq	a5,a0,530 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 688:	f8b60513          	addi	a0,a2,-117
 68c:	e119                	bnez	a0,692 <vprintf+0x250>
 68e:	ea069de3          	bnez	a3,548 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 692:	f8b58513          	addi	a0,a1,-117
 696:	e119                	bnez	a0,69c <vprintf+0x25a>
 698:	ec0715e3          	bnez	a4,562 <vprintf+0x120>
      } else if(c0 == 'x'){
 69c:	07800513          	li	a0,120
 6a0:	eca78ee3          	beq	a5,a0,57c <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 6a4:	f8860613          	addi	a2,a2,-120
 6a8:	e219                	bnez	a2,6ae <vprintf+0x26c>
 6aa:	ee0695e3          	bnez	a3,594 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6ae:	f8858593          	addi	a1,a1,-120
 6b2:	e199                	bnez	a1,6b8 <vprintf+0x276>
 6b4:	ee071de3          	bnez	a4,5ae <vprintf+0x16c>
      } else if(c0 == 'p'){
 6b8:	07000713          	li	a4,112
 6bc:	f0e786e3          	beq	a5,a4,5c8 <vprintf+0x186>
      } else if(c0 == 's'){
 6c0:	07300713          	li	a4,115
 6c4:	f4e786e3          	beq	a5,a4,610 <vprintf+0x1ce>
      } else if(c0 == '%'){
 6c8:	02500713          	li	a4,37
 6cc:	f6e78be3          	beq	a5,a4,642 <vprintf+0x200>
        putc(fd, '%');
 6d0:	02500593          	li	a1,37
 6d4:	855a                	mv	a0,s6
 6d6:	cabff0ef          	jal	380 <putc>
        putc(fd, c0);
 6da:	85a6                	mv	a1,s1
 6dc:	855a                	mv	a0,s6
 6de:	ca3ff0ef          	jal	380 <putc>
      state = 0;
 6e2:	4981                	li	s3,0
 6e4:	b34d                	j	486 <vprintf+0x44>

00000000000006e6 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6e6:	715d                	addi	sp,sp,-80
 6e8:	ec06                	sd	ra,24(sp)
 6ea:	e822                	sd	s0,16(sp)
 6ec:	1000                	addi	s0,sp,32
 6ee:	e010                	sd	a2,0(s0)
 6f0:	e414                	sd	a3,8(s0)
 6f2:	e818                	sd	a4,16(s0)
 6f4:	ec1c                	sd	a5,24(s0)
 6f6:	03043023          	sd	a6,32(s0)
 6fa:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6fe:	8622                	mv	a2,s0
 700:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 704:	d3fff0ef          	jal	442 <vprintf>
}
 708:	60e2                	ld	ra,24(sp)
 70a:	6442                	ld	s0,16(sp)
 70c:	6161                	addi	sp,sp,80
 70e:	8082                	ret

0000000000000710 <printf>:

void
printf(const char *fmt, ...)
{
 710:	711d                	addi	sp,sp,-96
 712:	ec06                	sd	ra,24(sp)
 714:	e822                	sd	s0,16(sp)
 716:	1000                	addi	s0,sp,32
 718:	e40c                	sd	a1,8(s0)
 71a:	e810                	sd	a2,16(s0)
 71c:	ec14                	sd	a3,24(s0)
 71e:	f018                	sd	a4,32(s0)
 720:	f41c                	sd	a5,40(s0)
 722:	03043823          	sd	a6,48(s0)
 726:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 72a:	00840613          	addi	a2,s0,8
 72e:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 732:	85aa                	mv	a1,a0
 734:	4505                	li	a0,1
 736:	d0dff0ef          	jal	442 <vprintf>
}
 73a:	60e2                	ld	ra,24(sp)
 73c:	6442                	ld	s0,16(sp)
 73e:	6125                	addi	sp,sp,96
 740:	8082                	ret

0000000000000742 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 742:	1141                	addi	sp,sp,-16
 744:	e406                	sd	ra,8(sp)
 746:	e022                	sd	s0,0(sp)
 748:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 74a:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 74e:	00001797          	auipc	a5,0x1
 752:	8b27b783          	ld	a5,-1870(a5) # 1000 <freep>
 756:	a039                	j	764 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 758:	6398                	ld	a4,0(a5)
 75a:	00e7e463          	bltu	a5,a4,762 <free+0x20>
 75e:	00e6ea63          	bltu	a3,a4,772 <free+0x30>
{
 762:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 764:	fed7fae3          	bgeu	a5,a3,758 <free+0x16>
 768:	6398                	ld	a4,0(a5)
 76a:	00e6e463          	bltu	a3,a4,772 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 76e:	fee7eae3          	bltu	a5,a4,762 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 772:	ff852583          	lw	a1,-8(a0)
 776:	6390                	ld	a2,0(a5)
 778:	02059813          	slli	a6,a1,0x20
 77c:	01c85713          	srli	a4,a6,0x1c
 780:	9736                	add	a4,a4,a3
 782:	02e60563          	beq	a2,a4,7ac <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 786:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 78a:	4790                	lw	a2,8(a5)
 78c:	02061593          	slli	a1,a2,0x20
 790:	01c5d713          	srli	a4,a1,0x1c
 794:	973e                	add	a4,a4,a5
 796:	02e68263          	beq	a3,a4,7ba <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 79a:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 79c:	00001717          	auipc	a4,0x1
 7a0:	86f73223          	sd	a5,-1948(a4) # 1000 <freep>
}
 7a4:	60a2                	ld	ra,8(sp)
 7a6:	6402                	ld	s0,0(sp)
 7a8:	0141                	addi	sp,sp,16
 7aa:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 7ac:	4618                	lw	a4,8(a2)
 7ae:	9f2d                	addw	a4,a4,a1
 7b0:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 7b4:	6398                	ld	a4,0(a5)
 7b6:	6310                	ld	a2,0(a4)
 7b8:	b7f9                	j	786 <free+0x44>
    p->s.size += bp->s.size;
 7ba:	ff852703          	lw	a4,-8(a0)
 7be:	9f31                	addw	a4,a4,a2
 7c0:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 7c2:	ff053683          	ld	a3,-16(a0)
 7c6:	bfd1                	j	79a <free+0x58>

00000000000007c8 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7c8:	7139                	addi	sp,sp,-64
 7ca:	fc06                	sd	ra,56(sp)
 7cc:	f822                	sd	s0,48(sp)
 7ce:	f04a                	sd	s2,32(sp)
 7d0:	ec4e                	sd	s3,24(sp)
 7d2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7d4:	02051993          	slli	s3,a0,0x20
 7d8:	0209d993          	srli	s3,s3,0x20
 7dc:	09bd                	addi	s3,s3,15
 7de:	0049d993          	srli	s3,s3,0x4
 7e2:	2985                	addiw	s3,s3,1
 7e4:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7e6:	00001517          	auipc	a0,0x1
 7ea:	81a53503          	ld	a0,-2022(a0) # 1000 <freep>
 7ee:	c905                	beqz	a0,81e <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7f0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7f2:	4798                	lw	a4,8(a5)
 7f4:	09377663          	bgeu	a4,s3,880 <malloc+0xb8>
 7f8:	f426                	sd	s1,40(sp)
 7fa:	e852                	sd	s4,16(sp)
 7fc:	e456                	sd	s5,8(sp)
 7fe:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 800:	8a4e                	mv	s4,s3
 802:	6705                	lui	a4,0x1
 804:	00e9f363          	bgeu	s3,a4,80a <malloc+0x42>
 808:	6a05                	lui	s4,0x1
 80a:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 80e:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 812:	00000497          	auipc	s1,0x0
 816:	7ee48493          	addi	s1,s1,2030 # 1000 <freep>
  if(p == (char*)-1)
 81a:	5afd                	li	s5,-1
 81c:	a83d                	j	85a <malloc+0x92>
 81e:	f426                	sd	s1,40(sp)
 820:	e852                	sd	s4,16(sp)
 822:	e456                	sd	s5,8(sp)
 824:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 826:	00001797          	auipc	a5,0x1
 82a:	7ea78793          	addi	a5,a5,2026 # 2010 <base>
 82e:	00000717          	auipc	a4,0x0
 832:	7cf73923          	sd	a5,2002(a4) # 1000 <freep>
 836:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 838:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 83c:	b7d1                	j	800 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 83e:	6398                	ld	a4,0(a5)
 840:	e118                	sd	a4,0(a0)
 842:	a899                	j	898 <malloc+0xd0>
  hp->s.size = nu;
 844:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 848:	0541                	addi	a0,a0,16
 84a:	ef9ff0ef          	jal	742 <free>
  return freep;
 84e:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 850:	c125                	beqz	a0,8b0 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 852:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 854:	4798                	lw	a4,8(a5)
 856:	03277163          	bgeu	a4,s2,878 <malloc+0xb0>
    if(p == freep)
 85a:	6098                	ld	a4,0(s1)
 85c:	853e                	mv	a0,a5
 85e:	fef71ae3          	bne	a4,a5,852 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 862:	8552                	mv	a0,s4
 864:	b05ff0ef          	jal	368 <sbrk>
  if(p == (char*)-1)
 868:	fd551ee3          	bne	a0,s5,844 <malloc+0x7c>
        return 0;
 86c:	4501                	li	a0,0
 86e:	74a2                	ld	s1,40(sp)
 870:	6a42                	ld	s4,16(sp)
 872:	6aa2                	ld	s5,8(sp)
 874:	6b02                	ld	s6,0(sp)
 876:	a03d                	j	8a4 <malloc+0xdc>
 878:	74a2                	ld	s1,40(sp)
 87a:	6a42                	ld	s4,16(sp)
 87c:	6aa2                	ld	s5,8(sp)
 87e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 880:	fae90fe3          	beq	s2,a4,83e <malloc+0x76>
        p->s.size -= nunits;
 884:	4137073b          	subw	a4,a4,s3
 888:	c798                	sw	a4,8(a5)
        p += p->s.size;
 88a:	02071693          	slli	a3,a4,0x20
 88e:	01c6d713          	srli	a4,a3,0x1c
 892:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 894:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 898:	00000717          	auipc	a4,0x0
 89c:	76a73423          	sd	a0,1896(a4) # 1000 <freep>
      return (void*)(p + 1);
 8a0:	01078513          	addi	a0,a5,16
  }
}
 8a4:	70e2                	ld	ra,56(sp)
 8a6:	7442                	ld	s0,48(sp)
 8a8:	7902                	ld	s2,32(sp)
 8aa:	69e2                	ld	s3,24(sp)
 8ac:	6121                	addi	sp,sp,64
 8ae:	8082                	ret
 8b0:	74a2                	ld	s1,40(sp)
 8b2:	6a42                	ld	s4,16(sp)
 8b4:	6aa2                	ld	s5,8(sp)
 8b6:	6b02                	ld	s6,0(sp)
 8b8:	b7f5                	j	8a4 <malloc+0xdc>

00000000000008ba <statistics>:
#include "kernel/fcntl.h"
#include "user/user.h"

int
statistics(void *buf, int sz)
{
 8ba:	7179                	addi	sp,sp,-48
 8bc:	f406                	sd	ra,40(sp)
 8be:	f022                	sd	s0,32(sp)
 8c0:	ec26                	sd	s1,24(sp)
 8c2:	e84a                	sd	s2,16(sp)
 8c4:	e44e                	sd	s3,8(sp)
 8c6:	e052                	sd	s4,0(sp)
 8c8:	1800                	addi	s0,sp,48
 8ca:	8a2a                	mv	s4,a0
 8cc:	892e                	mv	s2,a1
  int fd, i, n;
  
  fd = open("statistics", O_RDONLY);
 8ce:	4581                	li	a1,0
 8d0:	00000517          	auipc	a0,0x0
 8d4:	06850513          	addi	a0,a0,104 # 938 <statistics+0x7e>
 8d8:	a49ff0ef          	jal	320 <open>
  if(fd < 0) {
 8dc:	02054e63          	bltz	a0,918 <statistics+0x5e>
 8e0:	89aa                	mv	s3,a0
      fprintf(2, "stats: open failed\n");
      exit(1);
  }
  for (i = 0; i < sz; ) {
 8e2:	4481                	li	s1,0
 8e4:	01205e63          	blez	s2,900 <statistics+0x46>
    if ((n = read(fd, buf+i, sz-i)) < 0) {
 8e8:	4099063b          	subw	a2,s2,s1
 8ec:	009a05b3          	add	a1,s4,s1
 8f0:	854e                	mv	a0,s3
 8f2:	a07ff0ef          	jal	2f8 <read>
 8f6:	00054563          	bltz	a0,900 <statistics+0x46>
      break;
    }
    i += n;
 8fa:	9ca9                	addw	s1,s1,a0
  for (i = 0; i < sz; ) {
 8fc:	ff24c6e3          	blt	s1,s2,8e8 <statistics+0x2e>
  }
  close(fd);
 900:	854e                	mv	a0,s3
 902:	a07ff0ef          	jal	308 <close>
  return i;
}
 906:	8526                	mv	a0,s1
 908:	70a2                	ld	ra,40(sp)
 90a:	7402                	ld	s0,32(sp)
 90c:	64e2                	ld	s1,24(sp)
 90e:	6942                	ld	s2,16(sp)
 910:	69a2                	ld	s3,8(sp)
 912:	6a02                	ld	s4,0(sp)
 914:	6145                	addi	sp,sp,48
 916:	8082                	ret
      fprintf(2, "stats: open failed\n");
 918:	00000597          	auipc	a1,0x0
 91c:	03058593          	addi	a1,a1,48 # 948 <statistics+0x8e>
 920:	4509                	li	a0,2
 922:	dc5ff0ef          	jal	6e6 <fprintf>
      exit(1);
 926:	4505                	li	a0,1
 928:	9b9ff0ef          	jal	2e0 <exit>
