
user/_init:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:

char *argv[] = { "sh", 0 };

int
main(void)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	e04a                	sd	s2,0(sp)
   a:	1000                	addi	s0,sp,32
  int pid, wpid;

  if(open("console", O_RDWR) < 0){
   c:	4589                	li	a1,2
   e:	00001517          	auipc	a0,0x1
  12:	9a250513          	addi	a0,a0,-1630 # 9b0 <statistics+0x7e>
  16:	382000ef          	jal	398 <open>
  1a:	04054563          	bltz	a0,64 <main+0x64>
    mknod("console", CONSOLE, 0);
    mknod("statistics", STATS, 0);
    open("console", O_RDWR);
  }
  dup(0);  // stdout
  1e:	4501                	li	a0,0
  20:	3b0000ef          	jal	3d0 <dup>
  dup(0);  // stderr
  24:	4501                	li	a0,0
  26:	3aa000ef          	jal	3d0 <dup>

  for(;;){
    printf("init: starting sh\n");
  2a:	00001917          	auipc	s2,0x1
  2e:	99e90913          	addi	s2,s2,-1634 # 9c8 <statistics+0x96>
  32:	854a                	mv	a0,s2
  34:	754000ef          	jal	788 <printf>
    pid = fork();
  38:	318000ef          	jal	350 <fork>
  3c:	84aa                	mv	s1,a0
    if(pid < 0){
  3e:	04054b63          	bltz	a0,94 <main+0x94>
      printf("init: fork failed\n");
      exit(1);
    }
    if(pid == 0){
  42:	c135                	beqz	a0,a6 <main+0xa6>
    }

    for(;;){
      // this call to wait() returns if the shell exits,
      // or if a parentless process exits.
      wpid = wait((int *) 0);
  44:	4501                	li	a0,0
  46:	31a000ef          	jal	360 <wait>
      if(wpid == pid){
  4a:	fea484e3          	beq	s1,a0,32 <main+0x32>
        // the shell exited; restart it.
        break;
      } else if(wpid < 0){
  4e:	fe055be3          	bgez	a0,44 <main+0x44>
        printf("init: wait returned an error\n");
  52:	00001517          	auipc	a0,0x1
  56:	9c650513          	addi	a0,a0,-1594 # a18 <statistics+0xe6>
  5a:	72e000ef          	jal	788 <printf>
        exit(1);
  5e:	4505                	li	a0,1
  60:	2f8000ef          	jal	358 <exit>
    mknod("console", CONSOLE, 0);
  64:	4601                	li	a2,0
  66:	4585                	li	a1,1
  68:	00001517          	auipc	a0,0x1
  6c:	94850513          	addi	a0,a0,-1720 # 9b0 <statistics+0x7e>
  70:	330000ef          	jal	3a0 <mknod>
    mknod("statistics", STATS, 0);
  74:	4601                	li	a2,0
  76:	4589                	li	a1,2
  78:	00001517          	auipc	a0,0x1
  7c:	94050513          	addi	a0,a0,-1728 # 9b8 <statistics+0x86>
  80:	320000ef          	jal	3a0 <mknod>
    open("console", O_RDWR);
  84:	4589                	li	a1,2
  86:	00001517          	auipc	a0,0x1
  8a:	92a50513          	addi	a0,a0,-1750 # 9b0 <statistics+0x7e>
  8e:	30a000ef          	jal	398 <open>
  92:	b771                	j	1e <main+0x1e>
      printf("init: fork failed\n");
  94:	00001517          	auipc	a0,0x1
  98:	94c50513          	addi	a0,a0,-1716 # 9e0 <statistics+0xae>
  9c:	6ec000ef          	jal	788 <printf>
      exit(1);
  a0:	4505                	li	a0,1
  a2:	2b6000ef          	jal	358 <exit>
      exec("sh", argv);
  a6:	00001597          	auipc	a1,0x1
  aa:	f5a58593          	addi	a1,a1,-166 # 1000 <argv>
  ae:	00001517          	auipc	a0,0x1
  b2:	94a50513          	addi	a0,a0,-1718 # 9f8 <statistics+0xc6>
  b6:	2da000ef          	jal	390 <exec>
      printf("init: exec sh failed\n");
  ba:	00001517          	auipc	a0,0x1
  be:	94650513          	addi	a0,a0,-1722 # a00 <statistics+0xce>
  c2:	6c6000ef          	jal	788 <printf>
      exit(1);
  c6:	4505                	li	a0,1
  c8:	290000ef          	jal	358 <exit>

00000000000000cc <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  cc:	1141                	addi	sp,sp,-16
  ce:	e406                	sd	ra,8(sp)
  d0:	e022                	sd	s0,0(sp)
  d2:	0800                	addi	s0,sp,16
  extern int main();
  main();
  d4:	f2dff0ef          	jal	0 <main>
  exit(0);
  d8:	4501                	li	a0,0
  da:	27e000ef          	jal	358 <exit>

00000000000000de <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  de:	1141                	addi	sp,sp,-16
  e0:	e406                	sd	ra,8(sp)
  e2:	e022                	sd	s0,0(sp)
  e4:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  e6:	87aa                	mv	a5,a0
  e8:	0585                	addi	a1,a1,1
  ea:	0785                	addi	a5,a5,1
  ec:	fff5c703          	lbu	a4,-1(a1)
  f0:	fee78fa3          	sb	a4,-1(a5)
  f4:	fb75                	bnez	a4,e8 <strcpy+0xa>
    ;
  return os;
}
  f6:	60a2                	ld	ra,8(sp)
  f8:	6402                	ld	s0,0(sp)
  fa:	0141                	addi	sp,sp,16
  fc:	8082                	ret

00000000000000fe <strcmp>:

int
strcmp(const char *p, const char *q)
{
  fe:	1141                	addi	sp,sp,-16
 100:	e406                	sd	ra,8(sp)
 102:	e022                	sd	s0,0(sp)
 104:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 106:	00054783          	lbu	a5,0(a0)
 10a:	cb91                	beqz	a5,11e <strcmp+0x20>
 10c:	0005c703          	lbu	a4,0(a1)
 110:	00f71763          	bne	a4,a5,11e <strcmp+0x20>
    p++, q++;
 114:	0505                	addi	a0,a0,1
 116:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 118:	00054783          	lbu	a5,0(a0)
 11c:	fbe5                	bnez	a5,10c <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 11e:	0005c503          	lbu	a0,0(a1)
}
 122:	40a7853b          	subw	a0,a5,a0
 126:	60a2                	ld	ra,8(sp)
 128:	6402                	ld	s0,0(sp)
 12a:	0141                	addi	sp,sp,16
 12c:	8082                	ret

000000000000012e <strlen>:

uint
strlen(const char *s)
{
 12e:	1141                	addi	sp,sp,-16
 130:	e406                	sd	ra,8(sp)
 132:	e022                	sd	s0,0(sp)
 134:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 136:	00054783          	lbu	a5,0(a0)
 13a:	cf91                	beqz	a5,156 <strlen+0x28>
 13c:	00150793          	addi	a5,a0,1
 140:	86be                	mv	a3,a5
 142:	0785                	addi	a5,a5,1
 144:	fff7c703          	lbu	a4,-1(a5)
 148:	ff65                	bnez	a4,140 <strlen+0x12>
 14a:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 14e:	60a2                	ld	ra,8(sp)
 150:	6402                	ld	s0,0(sp)
 152:	0141                	addi	sp,sp,16
 154:	8082                	ret
  for(n = 0; s[n]; n++)
 156:	4501                	li	a0,0
 158:	bfdd                	j	14e <strlen+0x20>

000000000000015a <memset>:

void*
memset(void *dst, int c, uint n)
{
 15a:	1141                	addi	sp,sp,-16
 15c:	e406                	sd	ra,8(sp)
 15e:	e022                	sd	s0,0(sp)
 160:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 162:	ca19                	beqz	a2,178 <memset+0x1e>
 164:	87aa                	mv	a5,a0
 166:	1602                	slli	a2,a2,0x20
 168:	9201                	srli	a2,a2,0x20
 16a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 16e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 172:	0785                	addi	a5,a5,1
 174:	fee79de3          	bne	a5,a4,16e <memset+0x14>
  }
  return dst;
}
 178:	60a2                	ld	ra,8(sp)
 17a:	6402                	ld	s0,0(sp)
 17c:	0141                	addi	sp,sp,16
 17e:	8082                	ret

0000000000000180 <strchr>:

char*
strchr(const char *s, char c)
{
 180:	1141                	addi	sp,sp,-16
 182:	e406                	sd	ra,8(sp)
 184:	e022                	sd	s0,0(sp)
 186:	0800                	addi	s0,sp,16
  for(; *s; s++)
 188:	00054783          	lbu	a5,0(a0)
 18c:	cf81                	beqz	a5,1a4 <strchr+0x24>
    if(*s == c)
 18e:	00f58763          	beq	a1,a5,19c <strchr+0x1c>
  for(; *s; s++)
 192:	0505                	addi	a0,a0,1
 194:	00054783          	lbu	a5,0(a0)
 198:	fbfd                	bnez	a5,18e <strchr+0xe>
      return (char*)s;
  return 0;
 19a:	4501                	li	a0,0
}
 19c:	60a2                	ld	ra,8(sp)
 19e:	6402                	ld	s0,0(sp)
 1a0:	0141                	addi	sp,sp,16
 1a2:	8082                	ret
  return 0;
 1a4:	4501                	li	a0,0
 1a6:	bfdd                	j	19c <strchr+0x1c>

00000000000001a8 <gets>:

char*
gets(char *buf, int max)
{
 1a8:	711d                	addi	sp,sp,-96
 1aa:	ec86                	sd	ra,88(sp)
 1ac:	e8a2                	sd	s0,80(sp)
 1ae:	e4a6                	sd	s1,72(sp)
 1b0:	e0ca                	sd	s2,64(sp)
 1b2:	fc4e                	sd	s3,56(sp)
 1b4:	f852                	sd	s4,48(sp)
 1b6:	f456                	sd	s5,40(sp)
 1b8:	f05a                	sd	s6,32(sp)
 1ba:	ec5e                	sd	s7,24(sp)
 1bc:	e862                	sd	s8,16(sp)
 1be:	1080                	addi	s0,sp,96
 1c0:	8baa                	mv	s7,a0
 1c2:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1c4:	892a                	mv	s2,a0
 1c6:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1c8:	faf40b13          	addi	s6,s0,-81
 1cc:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1ce:	8c26                	mv	s8,s1
 1d0:	0014899b          	addiw	s3,s1,1
 1d4:	84ce                	mv	s1,s3
 1d6:	0349d463          	bge	s3,s4,1fe <gets+0x56>
    cc = read(0, &c, 1);
 1da:	8656                	mv	a2,s5
 1dc:	85da                	mv	a1,s6
 1de:	4501                	li	a0,0
 1e0:	190000ef          	jal	370 <read>
    if(cc < 1)
 1e4:	00a05d63          	blez	a0,1fe <gets+0x56>
      break;
    buf[i++] = c;
 1e8:	faf44783          	lbu	a5,-81(s0)
 1ec:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 1f0:	0905                	addi	s2,s2,1
 1f2:	ff678713          	addi	a4,a5,-10
 1f6:	c319                	beqz	a4,1fc <gets+0x54>
 1f8:	17cd                	addi	a5,a5,-13
 1fa:	fbf1                	bnez	a5,1ce <gets+0x26>
    buf[i++] = c;
 1fc:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1fe:	9c5e                	add	s8,s8,s7
 200:	000c0023          	sb	zero,0(s8)
  return buf;
}
 204:	855e                	mv	a0,s7
 206:	60e6                	ld	ra,88(sp)
 208:	6446                	ld	s0,80(sp)
 20a:	64a6                	ld	s1,72(sp)
 20c:	6906                	ld	s2,64(sp)
 20e:	79e2                	ld	s3,56(sp)
 210:	7a42                	ld	s4,48(sp)
 212:	7aa2                	ld	s5,40(sp)
 214:	7b02                	ld	s6,32(sp)
 216:	6be2                	ld	s7,24(sp)
 218:	6c42                	ld	s8,16(sp)
 21a:	6125                	addi	sp,sp,96
 21c:	8082                	ret

000000000000021e <stat>:

int
stat(const char *n, struct stat *st)
{
 21e:	1101                	addi	sp,sp,-32
 220:	ec06                	sd	ra,24(sp)
 222:	e822                	sd	s0,16(sp)
 224:	e04a                	sd	s2,0(sp)
 226:	1000                	addi	s0,sp,32
 228:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 22a:	4581                	li	a1,0
 22c:	16c000ef          	jal	398 <open>
  if(fd < 0)
 230:	02054263          	bltz	a0,254 <stat+0x36>
 234:	e426                	sd	s1,8(sp)
 236:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 238:	85ca                	mv	a1,s2
 23a:	176000ef          	jal	3b0 <fstat>
 23e:	892a                	mv	s2,a0
  close(fd);
 240:	8526                	mv	a0,s1
 242:	13e000ef          	jal	380 <close>
  return r;
 246:	64a2                	ld	s1,8(sp)
}
 248:	854a                	mv	a0,s2
 24a:	60e2                	ld	ra,24(sp)
 24c:	6442                	ld	s0,16(sp)
 24e:	6902                	ld	s2,0(sp)
 250:	6105                	addi	sp,sp,32
 252:	8082                	ret
    return -1;
 254:	57fd                	li	a5,-1
 256:	893e                	mv	s2,a5
 258:	bfc5                	j	248 <stat+0x2a>

000000000000025a <atoi>:

int
atoi(const char *s)
{
 25a:	1141                	addi	sp,sp,-16
 25c:	e406                	sd	ra,8(sp)
 25e:	e022                	sd	s0,0(sp)
 260:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 262:	00054683          	lbu	a3,0(a0)
 266:	fd06879b          	addiw	a5,a3,-48
 26a:	0ff7f793          	zext.b	a5,a5
 26e:	4625                	li	a2,9
 270:	02f66963          	bltu	a2,a5,2a2 <atoi+0x48>
 274:	872a                	mv	a4,a0
  n = 0;
 276:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 278:	0705                	addi	a4,a4,1
 27a:	0025179b          	slliw	a5,a0,0x2
 27e:	9fa9                	addw	a5,a5,a0
 280:	0017979b          	slliw	a5,a5,0x1
 284:	9fb5                	addw	a5,a5,a3
 286:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 28a:	00074683          	lbu	a3,0(a4)
 28e:	fd06879b          	addiw	a5,a3,-48
 292:	0ff7f793          	zext.b	a5,a5
 296:	fef671e3          	bgeu	a2,a5,278 <atoi+0x1e>
  return n;
}
 29a:	60a2                	ld	ra,8(sp)
 29c:	6402                	ld	s0,0(sp)
 29e:	0141                	addi	sp,sp,16
 2a0:	8082                	ret
  n = 0;
 2a2:	4501                	li	a0,0
 2a4:	bfdd                	j	29a <atoi+0x40>

00000000000002a6 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2a6:	1141                	addi	sp,sp,-16
 2a8:	e406                	sd	ra,8(sp)
 2aa:	e022                	sd	s0,0(sp)
 2ac:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2ae:	02b57563          	bgeu	a0,a1,2d8 <memmove+0x32>
    while(n-- > 0)
 2b2:	00c05f63          	blez	a2,2d0 <memmove+0x2a>
 2b6:	1602                	slli	a2,a2,0x20
 2b8:	9201                	srli	a2,a2,0x20
 2ba:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2be:	872a                	mv	a4,a0
      *dst++ = *src++;
 2c0:	0585                	addi	a1,a1,1
 2c2:	0705                	addi	a4,a4,1
 2c4:	fff5c683          	lbu	a3,-1(a1)
 2c8:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2cc:	fee79ae3          	bne	a5,a4,2c0 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2d0:	60a2                	ld	ra,8(sp)
 2d2:	6402                	ld	s0,0(sp)
 2d4:	0141                	addi	sp,sp,16
 2d6:	8082                	ret
    while(n-- > 0)
 2d8:	fec05ce3          	blez	a2,2d0 <memmove+0x2a>
    dst += n;
 2dc:	00c50733          	add	a4,a0,a2
    src += n;
 2e0:	95b2                	add	a1,a1,a2
 2e2:	fff6079b          	addiw	a5,a2,-1
 2e6:	1782                	slli	a5,a5,0x20
 2e8:	9381                	srli	a5,a5,0x20
 2ea:	fff7c793          	not	a5,a5
 2ee:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2f0:	15fd                	addi	a1,a1,-1
 2f2:	177d                	addi	a4,a4,-1
 2f4:	0005c683          	lbu	a3,0(a1)
 2f8:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 2fc:	fef71ae3          	bne	a4,a5,2f0 <memmove+0x4a>
 300:	bfc1                	j	2d0 <memmove+0x2a>

0000000000000302 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 302:	1141                	addi	sp,sp,-16
 304:	e406                	sd	ra,8(sp)
 306:	e022                	sd	s0,0(sp)
 308:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 30a:	c61d                	beqz	a2,338 <memcmp+0x36>
 30c:	1602                	slli	a2,a2,0x20
 30e:	9201                	srli	a2,a2,0x20
 310:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 314:	00054783          	lbu	a5,0(a0)
 318:	0005c703          	lbu	a4,0(a1)
 31c:	00e79863          	bne	a5,a4,32c <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 320:	0505                	addi	a0,a0,1
    p2++;
 322:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 324:	fed518e3          	bne	a0,a3,314 <memcmp+0x12>
  }
  return 0;
 328:	4501                	li	a0,0
 32a:	a019                	j	330 <memcmp+0x2e>
      return *p1 - *p2;
 32c:	40e7853b          	subw	a0,a5,a4
}
 330:	60a2                	ld	ra,8(sp)
 332:	6402                	ld	s0,0(sp)
 334:	0141                	addi	sp,sp,16
 336:	8082                	ret
  return 0;
 338:	4501                	li	a0,0
 33a:	bfdd                	j	330 <memcmp+0x2e>

000000000000033c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 33c:	1141                	addi	sp,sp,-16
 33e:	e406                	sd	ra,8(sp)
 340:	e022                	sd	s0,0(sp)
 342:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 344:	f63ff0ef          	jal	2a6 <memmove>
}
 348:	60a2                	ld	ra,8(sp)
 34a:	6402                	ld	s0,0(sp)
 34c:	0141                	addi	sp,sp,16
 34e:	8082                	ret

0000000000000350 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 350:	4885                	li	a7,1
 ecall
 352:	00000073          	ecall
 ret
 356:	8082                	ret

0000000000000358 <exit>:
.global exit
exit:
 li a7, SYS_exit
 358:	4889                	li	a7,2
 ecall
 35a:	00000073          	ecall
 ret
 35e:	8082                	ret

0000000000000360 <wait>:
.global wait
wait:
 li a7, SYS_wait
 360:	488d                	li	a7,3
 ecall
 362:	00000073          	ecall
 ret
 366:	8082                	ret

0000000000000368 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 368:	4891                	li	a7,4
 ecall
 36a:	00000073          	ecall
 ret
 36e:	8082                	ret

0000000000000370 <read>:
.global read
read:
 li a7, SYS_read
 370:	4895                	li	a7,5
 ecall
 372:	00000073          	ecall
 ret
 376:	8082                	ret

0000000000000378 <write>:
.global write
write:
 li a7, SYS_write
 378:	48c1                	li	a7,16
 ecall
 37a:	00000073          	ecall
 ret
 37e:	8082                	ret

0000000000000380 <close>:
.global close
close:
 li a7, SYS_close
 380:	48d5                	li	a7,21
 ecall
 382:	00000073          	ecall
 ret
 386:	8082                	ret

0000000000000388 <kill>:
.global kill
kill:
 li a7, SYS_kill
 388:	4899                	li	a7,6
 ecall
 38a:	00000073          	ecall
 ret
 38e:	8082                	ret

0000000000000390 <exec>:
.global exec
exec:
 li a7, SYS_exec
 390:	489d                	li	a7,7
 ecall
 392:	00000073          	ecall
 ret
 396:	8082                	ret

0000000000000398 <open>:
.global open
open:
 li a7, SYS_open
 398:	48bd                	li	a7,15
 ecall
 39a:	00000073          	ecall
 ret
 39e:	8082                	ret

00000000000003a0 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3a0:	48c5                	li	a7,17
 ecall
 3a2:	00000073          	ecall
 ret
 3a6:	8082                	ret

00000000000003a8 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3a8:	48c9                	li	a7,18
 ecall
 3aa:	00000073          	ecall
 ret
 3ae:	8082                	ret

00000000000003b0 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3b0:	48a1                	li	a7,8
 ecall
 3b2:	00000073          	ecall
 ret
 3b6:	8082                	ret

00000000000003b8 <link>:
.global link
link:
 li a7, SYS_link
 3b8:	48cd                	li	a7,19
 ecall
 3ba:	00000073          	ecall
 ret
 3be:	8082                	ret

00000000000003c0 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3c0:	48d1                	li	a7,20
 ecall
 3c2:	00000073          	ecall
 ret
 3c6:	8082                	ret

00000000000003c8 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3c8:	48a5                	li	a7,9
 ecall
 3ca:	00000073          	ecall
 ret
 3ce:	8082                	ret

00000000000003d0 <dup>:
.global dup
dup:
 li a7, SYS_dup
 3d0:	48a9                	li	a7,10
 ecall
 3d2:	00000073          	ecall
 ret
 3d6:	8082                	ret

00000000000003d8 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3d8:	48ad                	li	a7,11
 ecall
 3da:	00000073          	ecall
 ret
 3de:	8082                	ret

00000000000003e0 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 3e0:	48b1                	li	a7,12
 ecall
 3e2:	00000073          	ecall
 ret
 3e6:	8082                	ret

00000000000003e8 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 3e8:	48b5                	li	a7,13
 ecall
 3ea:	00000073          	ecall
 ret
 3ee:	8082                	ret

00000000000003f0 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 3f0:	48b9                	li	a7,14
 ecall
 3f2:	00000073          	ecall
 ret
 3f6:	8082                	ret

00000000000003f8 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 3f8:	1101                	addi	sp,sp,-32
 3fa:	ec06                	sd	ra,24(sp)
 3fc:	e822                	sd	s0,16(sp)
 3fe:	1000                	addi	s0,sp,32
 400:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 404:	4605                	li	a2,1
 406:	fef40593          	addi	a1,s0,-17
 40a:	f6fff0ef          	jal	378 <write>
}
 40e:	60e2                	ld	ra,24(sp)
 410:	6442                	ld	s0,16(sp)
 412:	6105                	addi	sp,sp,32
 414:	8082                	ret

0000000000000416 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 416:	7139                	addi	sp,sp,-64
 418:	fc06                	sd	ra,56(sp)
 41a:	f822                	sd	s0,48(sp)
 41c:	f04a                	sd	s2,32(sp)
 41e:	ec4e                	sd	s3,24(sp)
 420:	0080                	addi	s0,sp,64
 422:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 424:	cac9                	beqz	a3,4b6 <printint+0xa0>
 426:	01f5d79b          	srliw	a5,a1,0x1f
 42a:	c7d1                	beqz	a5,4b6 <printint+0xa0>
    neg = 1;
    x = -xx;
 42c:	40b005bb          	negw	a1,a1
    neg = 1;
 430:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 432:	fc040993          	addi	s3,s0,-64
  neg = 0;
 436:	86ce                	mv	a3,s3
  i = 0;
 438:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 43a:	00000817          	auipc	a6,0x0
 43e:	61e80813          	addi	a6,a6,1566 # a58 <digits>
 442:	88ba                	mv	a7,a4
 444:	0017051b          	addiw	a0,a4,1
 448:	872a                	mv	a4,a0
 44a:	02c5f7bb          	remuw	a5,a1,a2
 44e:	1782                	slli	a5,a5,0x20
 450:	9381                	srli	a5,a5,0x20
 452:	97c2                	add	a5,a5,a6
 454:	0007c783          	lbu	a5,0(a5)
 458:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 45c:	87ae                	mv	a5,a1
 45e:	02c5d5bb          	divuw	a1,a1,a2
 462:	0685                	addi	a3,a3,1
 464:	fcc7ffe3          	bgeu	a5,a2,442 <printint+0x2c>
  if(neg)
 468:	00030c63          	beqz	t1,480 <printint+0x6a>
    buf[i++] = '-';
 46c:	fd050793          	addi	a5,a0,-48
 470:	00878533          	add	a0,a5,s0
 474:	02d00793          	li	a5,45
 478:	fef50823          	sb	a5,-16(a0)
 47c:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 480:	02e05563          	blez	a4,4aa <printint+0x94>
 484:	f426                	sd	s1,40(sp)
 486:	377d                	addiw	a4,a4,-1
 488:	00e984b3          	add	s1,s3,a4
 48c:	19fd                	addi	s3,s3,-1
 48e:	99ba                	add	s3,s3,a4
 490:	1702                	slli	a4,a4,0x20
 492:	9301                	srli	a4,a4,0x20
 494:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 498:	0004c583          	lbu	a1,0(s1)
 49c:	854a                	mv	a0,s2
 49e:	f5bff0ef          	jal	3f8 <putc>
  while(--i >= 0)
 4a2:	14fd                	addi	s1,s1,-1
 4a4:	ff349ae3          	bne	s1,s3,498 <printint+0x82>
 4a8:	74a2                	ld	s1,40(sp)
}
 4aa:	70e2                	ld	ra,56(sp)
 4ac:	7442                	ld	s0,48(sp)
 4ae:	7902                	ld	s2,32(sp)
 4b0:	69e2                	ld	s3,24(sp)
 4b2:	6121                	addi	sp,sp,64
 4b4:	8082                	ret
  neg = 0;
 4b6:	4301                	li	t1,0
 4b8:	bfad                	j	432 <printint+0x1c>

00000000000004ba <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4ba:	711d                	addi	sp,sp,-96
 4bc:	ec86                	sd	ra,88(sp)
 4be:	e8a2                	sd	s0,80(sp)
 4c0:	e4a6                	sd	s1,72(sp)
 4c2:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 4c4:	0005c483          	lbu	s1,0(a1)
 4c8:	20048963          	beqz	s1,6da <vprintf+0x220>
 4cc:	e0ca                	sd	s2,64(sp)
 4ce:	fc4e                	sd	s3,56(sp)
 4d0:	f852                	sd	s4,48(sp)
 4d2:	f456                	sd	s5,40(sp)
 4d4:	f05a                	sd	s6,32(sp)
 4d6:	ec5e                	sd	s7,24(sp)
 4d8:	e862                	sd	s8,16(sp)
 4da:	8b2a                	mv	s6,a0
 4dc:	8a2e                	mv	s4,a1
 4de:	8bb2                	mv	s7,a2
  state = 0;
 4e0:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 4e2:	4901                	li	s2,0
 4e4:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 4e6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 4ea:	06400c13          	li	s8,100
 4ee:	a00d                	j	510 <vprintf+0x56>
        putc(fd, c0);
 4f0:	85a6                	mv	a1,s1
 4f2:	855a                	mv	a0,s6
 4f4:	f05ff0ef          	jal	3f8 <putc>
 4f8:	a019                	j	4fe <vprintf+0x44>
    } else if(state == '%'){
 4fa:	03598363          	beq	s3,s5,520 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 4fe:	0019079b          	addiw	a5,s2,1
 502:	893e                	mv	s2,a5
 504:	873e                	mv	a4,a5
 506:	97d2                	add	a5,a5,s4
 508:	0007c483          	lbu	s1,0(a5)
 50c:	1c048063          	beqz	s1,6cc <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 510:	0004879b          	sext.w	a5,s1
    if(state == 0){
 514:	fe0993e3          	bnez	s3,4fa <vprintf+0x40>
      if(c0 == '%'){
 518:	fd579ce3          	bne	a5,s5,4f0 <vprintf+0x36>
        state = '%';
 51c:	89be                	mv	s3,a5
 51e:	b7c5                	j	4fe <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 520:	00ea06b3          	add	a3,s4,a4
 524:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 528:	1a060e63          	beqz	a2,6e4 <vprintf+0x22a>
      if(c0 == 'd'){
 52c:	03878763          	beq	a5,s8,55a <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 530:	f9478693          	addi	a3,a5,-108
 534:	0016b693          	seqz	a3,a3
 538:	f9c60593          	addi	a1,a2,-100
 53c:	e99d                	bnez	a1,572 <vprintf+0xb8>
 53e:	ca95                	beqz	a3,572 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 540:	008b8493          	addi	s1,s7,8
 544:	4685                	li	a3,1
 546:	4629                	li	a2,10
 548:	000ba583          	lw	a1,0(s7)
 54c:	855a                	mv	a0,s6
 54e:	ec9ff0ef          	jal	416 <printint>
        i += 1;
 552:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 554:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 556:	4981                	li	s3,0
 558:	b75d                	j	4fe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 55a:	008b8493          	addi	s1,s7,8
 55e:	4685                	li	a3,1
 560:	4629                	li	a2,10
 562:	000ba583          	lw	a1,0(s7)
 566:	855a                	mv	a0,s6
 568:	eafff0ef          	jal	416 <printint>
 56c:	8ba6                	mv	s7,s1
      state = 0;
 56e:	4981                	li	s3,0
 570:	b779                	j	4fe <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 572:	9752                	add	a4,a4,s4
 574:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 578:	f9460713          	addi	a4,a2,-108
 57c:	00173713          	seqz	a4,a4
 580:	8f75                	and	a4,a4,a3
 582:	f9c58513          	addi	a0,a1,-100
 586:	16051963          	bnez	a0,6f8 <vprintf+0x23e>
 58a:	16070763          	beqz	a4,6f8 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 58e:	008b8493          	addi	s1,s7,8
 592:	4685                	li	a3,1
 594:	4629                	li	a2,10
 596:	000ba583          	lw	a1,0(s7)
 59a:	855a                	mv	a0,s6
 59c:	e7bff0ef          	jal	416 <printint>
        i += 2;
 5a0:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 5a2:	8ba6                	mv	s7,s1
      state = 0;
 5a4:	4981                	li	s3,0
        i += 2;
 5a6:	bfa1                	j	4fe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 5a8:	008b8493          	addi	s1,s7,8
 5ac:	4681                	li	a3,0
 5ae:	4629                	li	a2,10
 5b0:	000ba583          	lw	a1,0(s7)
 5b4:	855a                	mv	a0,s6
 5b6:	e61ff0ef          	jal	416 <printint>
 5ba:	8ba6                	mv	s7,s1
      state = 0;
 5bc:	4981                	li	s3,0
 5be:	b781                	j	4fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5c0:	008b8493          	addi	s1,s7,8
 5c4:	4681                	li	a3,0
 5c6:	4629                	li	a2,10
 5c8:	000ba583          	lw	a1,0(s7)
 5cc:	855a                	mv	a0,s6
 5ce:	e49ff0ef          	jal	416 <printint>
        i += 1;
 5d2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5d4:	8ba6                	mv	s7,s1
      state = 0;
 5d6:	4981                	li	s3,0
 5d8:	b71d                	j	4fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5da:	008b8493          	addi	s1,s7,8
 5de:	4681                	li	a3,0
 5e0:	4629                	li	a2,10
 5e2:	000ba583          	lw	a1,0(s7)
 5e6:	855a                	mv	a0,s6
 5e8:	e2fff0ef          	jal	416 <printint>
        i += 2;
 5ec:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5ee:	8ba6                	mv	s7,s1
      state = 0;
 5f0:	4981                	li	s3,0
        i += 2;
 5f2:	b731                	j	4fe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 5f4:	008b8493          	addi	s1,s7,8
 5f8:	4681                	li	a3,0
 5fa:	4641                	li	a2,16
 5fc:	000ba583          	lw	a1,0(s7)
 600:	855a                	mv	a0,s6
 602:	e15ff0ef          	jal	416 <printint>
 606:	8ba6                	mv	s7,s1
      state = 0;
 608:	4981                	li	s3,0
 60a:	bdd5                	j	4fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 60c:	008b8493          	addi	s1,s7,8
 610:	4681                	li	a3,0
 612:	4641                	li	a2,16
 614:	000ba583          	lw	a1,0(s7)
 618:	855a                	mv	a0,s6
 61a:	dfdff0ef          	jal	416 <printint>
        i += 1;
 61e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 620:	8ba6                	mv	s7,s1
      state = 0;
 622:	4981                	li	s3,0
 624:	bde9                	j	4fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 626:	008b8493          	addi	s1,s7,8
 62a:	4681                	li	a3,0
 62c:	4641                	li	a2,16
 62e:	000ba583          	lw	a1,0(s7)
 632:	855a                	mv	a0,s6
 634:	de3ff0ef          	jal	416 <printint>
        i += 2;
 638:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 63a:	8ba6                	mv	s7,s1
      state = 0;
 63c:	4981                	li	s3,0
        i += 2;
 63e:	b5c1                	j	4fe <vprintf+0x44>
 640:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 642:	008b8793          	addi	a5,s7,8
 646:	8cbe                	mv	s9,a5
 648:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 64c:	03000593          	li	a1,48
 650:	855a                	mv	a0,s6
 652:	da7ff0ef          	jal	3f8 <putc>
  putc(fd, 'x');
 656:	07800593          	li	a1,120
 65a:	855a                	mv	a0,s6
 65c:	d9dff0ef          	jal	3f8 <putc>
 660:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 662:	00000b97          	auipc	s7,0x0
 666:	3f6b8b93          	addi	s7,s7,1014 # a58 <digits>
 66a:	03c9d793          	srli	a5,s3,0x3c
 66e:	97de                	add	a5,a5,s7
 670:	0007c583          	lbu	a1,0(a5)
 674:	855a                	mv	a0,s6
 676:	d83ff0ef          	jal	3f8 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 67a:	0992                	slli	s3,s3,0x4
 67c:	34fd                	addiw	s1,s1,-1
 67e:	f4f5                	bnez	s1,66a <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 680:	8be6                	mv	s7,s9
      state = 0;
 682:	4981                	li	s3,0
 684:	6ca2                	ld	s9,8(sp)
 686:	bda5                	j	4fe <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 688:	008b8993          	addi	s3,s7,8
 68c:	000bb483          	ld	s1,0(s7)
 690:	cc91                	beqz	s1,6ac <vprintf+0x1f2>
        for(; *s; s++)
 692:	0004c583          	lbu	a1,0(s1)
 696:	c985                	beqz	a1,6c6 <vprintf+0x20c>
          putc(fd, *s);
 698:	855a                	mv	a0,s6
 69a:	d5fff0ef          	jal	3f8 <putc>
        for(; *s; s++)
 69e:	0485                	addi	s1,s1,1
 6a0:	0004c583          	lbu	a1,0(s1)
 6a4:	f9f5                	bnez	a1,698 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 6a6:	8bce                	mv	s7,s3
      state = 0;
 6a8:	4981                	li	s3,0
 6aa:	bd91                	j	4fe <vprintf+0x44>
          s = "(null)";
 6ac:	00000497          	auipc	s1,0x0
 6b0:	38c48493          	addi	s1,s1,908 # a38 <statistics+0x106>
        for(; *s; s++)
 6b4:	02800593          	li	a1,40
 6b8:	b7c5                	j	698 <vprintf+0x1de>
        putc(fd, '%');
 6ba:	85be                	mv	a1,a5
 6bc:	855a                	mv	a0,s6
 6be:	d3bff0ef          	jal	3f8 <putc>
      state = 0;
 6c2:	4981                	li	s3,0
 6c4:	bd2d                	j	4fe <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6c6:	8bce                	mv	s7,s3
      state = 0;
 6c8:	4981                	li	s3,0
 6ca:	bd15                	j	4fe <vprintf+0x44>
 6cc:	6906                	ld	s2,64(sp)
 6ce:	79e2                	ld	s3,56(sp)
 6d0:	7a42                	ld	s4,48(sp)
 6d2:	7aa2                	ld	s5,40(sp)
 6d4:	7b02                	ld	s6,32(sp)
 6d6:	6be2                	ld	s7,24(sp)
 6d8:	6c42                	ld	s8,16(sp)
    }
  }
}
 6da:	60e6                	ld	ra,88(sp)
 6dc:	6446                	ld	s0,80(sp)
 6de:	64a6                	ld	s1,72(sp)
 6e0:	6125                	addi	sp,sp,96
 6e2:	8082                	ret
      if(c0 == 'd'){
 6e4:	06400713          	li	a4,100
 6e8:	e6e789e3          	beq	a5,a4,55a <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 6ec:	f9478693          	addi	a3,a5,-108
 6f0:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 6f4:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6f6:	4701                	li	a4,0
      } else if(c0 == 'u'){
 6f8:	07500513          	li	a0,117
 6fc:	eaa786e3          	beq	a5,a0,5a8 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 700:	f8b60513          	addi	a0,a2,-117
 704:	e119                	bnez	a0,70a <vprintf+0x250>
 706:	ea069de3          	bnez	a3,5c0 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 70a:	f8b58513          	addi	a0,a1,-117
 70e:	e119                	bnez	a0,714 <vprintf+0x25a>
 710:	ec0715e3          	bnez	a4,5da <vprintf+0x120>
      } else if(c0 == 'x'){
 714:	07800513          	li	a0,120
 718:	eca78ee3          	beq	a5,a0,5f4 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 71c:	f8860613          	addi	a2,a2,-120
 720:	e219                	bnez	a2,726 <vprintf+0x26c>
 722:	ee0695e3          	bnez	a3,60c <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 726:	f8858593          	addi	a1,a1,-120
 72a:	e199                	bnez	a1,730 <vprintf+0x276>
 72c:	ee071de3          	bnez	a4,626 <vprintf+0x16c>
      } else if(c0 == 'p'){
 730:	07000713          	li	a4,112
 734:	f0e786e3          	beq	a5,a4,640 <vprintf+0x186>
      } else if(c0 == 's'){
 738:	07300713          	li	a4,115
 73c:	f4e786e3          	beq	a5,a4,688 <vprintf+0x1ce>
      } else if(c0 == '%'){
 740:	02500713          	li	a4,37
 744:	f6e78be3          	beq	a5,a4,6ba <vprintf+0x200>
        putc(fd, '%');
 748:	02500593          	li	a1,37
 74c:	855a                	mv	a0,s6
 74e:	cabff0ef          	jal	3f8 <putc>
        putc(fd, c0);
 752:	85a6                	mv	a1,s1
 754:	855a                	mv	a0,s6
 756:	ca3ff0ef          	jal	3f8 <putc>
      state = 0;
 75a:	4981                	li	s3,0
 75c:	b34d                	j	4fe <vprintf+0x44>

000000000000075e <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 75e:	715d                	addi	sp,sp,-80
 760:	ec06                	sd	ra,24(sp)
 762:	e822                	sd	s0,16(sp)
 764:	1000                	addi	s0,sp,32
 766:	e010                	sd	a2,0(s0)
 768:	e414                	sd	a3,8(s0)
 76a:	e818                	sd	a4,16(s0)
 76c:	ec1c                	sd	a5,24(s0)
 76e:	03043023          	sd	a6,32(s0)
 772:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 776:	8622                	mv	a2,s0
 778:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 77c:	d3fff0ef          	jal	4ba <vprintf>
}
 780:	60e2                	ld	ra,24(sp)
 782:	6442                	ld	s0,16(sp)
 784:	6161                	addi	sp,sp,80
 786:	8082                	ret

0000000000000788 <printf>:

void
printf(const char *fmt, ...)
{
 788:	711d                	addi	sp,sp,-96
 78a:	ec06                	sd	ra,24(sp)
 78c:	e822                	sd	s0,16(sp)
 78e:	1000                	addi	s0,sp,32
 790:	e40c                	sd	a1,8(s0)
 792:	e810                	sd	a2,16(s0)
 794:	ec14                	sd	a3,24(s0)
 796:	f018                	sd	a4,32(s0)
 798:	f41c                	sd	a5,40(s0)
 79a:	03043823          	sd	a6,48(s0)
 79e:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7a2:	00840613          	addi	a2,s0,8
 7a6:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7aa:	85aa                	mv	a1,a0
 7ac:	4505                	li	a0,1
 7ae:	d0dff0ef          	jal	4ba <vprintf>
}
 7b2:	60e2                	ld	ra,24(sp)
 7b4:	6442                	ld	s0,16(sp)
 7b6:	6125                	addi	sp,sp,96
 7b8:	8082                	ret

00000000000007ba <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7ba:	1141                	addi	sp,sp,-16
 7bc:	e406                	sd	ra,8(sp)
 7be:	e022                	sd	s0,0(sp)
 7c0:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 7c2:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7c6:	00001797          	auipc	a5,0x1
 7ca:	84a7b783          	ld	a5,-1974(a5) # 1010 <freep>
 7ce:	a039                	j	7dc <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7d0:	6398                	ld	a4,0(a5)
 7d2:	00e7e463          	bltu	a5,a4,7da <free+0x20>
 7d6:	00e6ea63          	bltu	a3,a4,7ea <free+0x30>
{
 7da:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7dc:	fed7fae3          	bgeu	a5,a3,7d0 <free+0x16>
 7e0:	6398                	ld	a4,0(a5)
 7e2:	00e6e463          	bltu	a3,a4,7ea <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7e6:	fee7eae3          	bltu	a5,a4,7da <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 7ea:	ff852583          	lw	a1,-8(a0)
 7ee:	6390                	ld	a2,0(a5)
 7f0:	02059813          	slli	a6,a1,0x20
 7f4:	01c85713          	srli	a4,a6,0x1c
 7f8:	9736                	add	a4,a4,a3
 7fa:	02e60563          	beq	a2,a4,824 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 7fe:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 802:	4790                	lw	a2,8(a5)
 804:	02061593          	slli	a1,a2,0x20
 808:	01c5d713          	srli	a4,a1,0x1c
 80c:	973e                	add	a4,a4,a5
 80e:	02e68263          	beq	a3,a4,832 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 812:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 814:	00000717          	auipc	a4,0x0
 818:	7ef73e23          	sd	a5,2044(a4) # 1010 <freep>
}
 81c:	60a2                	ld	ra,8(sp)
 81e:	6402                	ld	s0,0(sp)
 820:	0141                	addi	sp,sp,16
 822:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 824:	4618                	lw	a4,8(a2)
 826:	9f2d                	addw	a4,a4,a1
 828:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 82c:	6398                	ld	a4,0(a5)
 82e:	6310                	ld	a2,0(a4)
 830:	b7f9                	j	7fe <free+0x44>
    p->s.size += bp->s.size;
 832:	ff852703          	lw	a4,-8(a0)
 836:	9f31                	addw	a4,a4,a2
 838:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 83a:	ff053683          	ld	a3,-16(a0)
 83e:	bfd1                	j	812 <free+0x58>

0000000000000840 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 840:	7139                	addi	sp,sp,-64
 842:	fc06                	sd	ra,56(sp)
 844:	f822                	sd	s0,48(sp)
 846:	f04a                	sd	s2,32(sp)
 848:	ec4e                	sd	s3,24(sp)
 84a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 84c:	02051993          	slli	s3,a0,0x20
 850:	0209d993          	srli	s3,s3,0x20
 854:	09bd                	addi	s3,s3,15
 856:	0049d993          	srli	s3,s3,0x4
 85a:	2985                	addiw	s3,s3,1
 85c:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 85e:	00000517          	auipc	a0,0x0
 862:	7b253503          	ld	a0,1970(a0) # 1010 <freep>
 866:	c905                	beqz	a0,896 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 868:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 86a:	4798                	lw	a4,8(a5)
 86c:	09377663          	bgeu	a4,s3,8f8 <malloc+0xb8>
 870:	f426                	sd	s1,40(sp)
 872:	e852                	sd	s4,16(sp)
 874:	e456                	sd	s5,8(sp)
 876:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 878:	8a4e                	mv	s4,s3
 87a:	6705                	lui	a4,0x1
 87c:	00e9f363          	bgeu	s3,a4,882 <malloc+0x42>
 880:	6a05                	lui	s4,0x1
 882:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 886:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 88a:	00000497          	auipc	s1,0x0
 88e:	78648493          	addi	s1,s1,1926 # 1010 <freep>
  if(p == (char*)-1)
 892:	5afd                	li	s5,-1
 894:	a83d                	j	8d2 <malloc+0x92>
 896:	f426                	sd	s1,40(sp)
 898:	e852                	sd	s4,16(sp)
 89a:	e456                	sd	s5,8(sp)
 89c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 89e:	00000797          	auipc	a5,0x0
 8a2:	78278793          	addi	a5,a5,1922 # 1020 <base>
 8a6:	00000717          	auipc	a4,0x0
 8aa:	76f73523          	sd	a5,1898(a4) # 1010 <freep>
 8ae:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8b0:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 8b4:	b7d1                	j	878 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 8b6:	6398                	ld	a4,0(a5)
 8b8:	e118                	sd	a4,0(a0)
 8ba:	a899                	j	910 <malloc+0xd0>
  hp->s.size = nu;
 8bc:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 8c0:	0541                	addi	a0,a0,16
 8c2:	ef9ff0ef          	jal	7ba <free>
  return freep;
 8c6:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 8c8:	c125                	beqz	a0,928 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8ca:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8cc:	4798                	lw	a4,8(a5)
 8ce:	03277163          	bgeu	a4,s2,8f0 <malloc+0xb0>
    if(p == freep)
 8d2:	6098                	ld	a4,0(s1)
 8d4:	853e                	mv	a0,a5
 8d6:	fef71ae3          	bne	a4,a5,8ca <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 8da:	8552                	mv	a0,s4
 8dc:	b05ff0ef          	jal	3e0 <sbrk>
  if(p == (char*)-1)
 8e0:	fd551ee3          	bne	a0,s5,8bc <malloc+0x7c>
        return 0;
 8e4:	4501                	li	a0,0
 8e6:	74a2                	ld	s1,40(sp)
 8e8:	6a42                	ld	s4,16(sp)
 8ea:	6aa2                	ld	s5,8(sp)
 8ec:	6b02                	ld	s6,0(sp)
 8ee:	a03d                	j	91c <malloc+0xdc>
 8f0:	74a2                	ld	s1,40(sp)
 8f2:	6a42                	ld	s4,16(sp)
 8f4:	6aa2                	ld	s5,8(sp)
 8f6:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 8f8:	fae90fe3          	beq	s2,a4,8b6 <malloc+0x76>
        p->s.size -= nunits;
 8fc:	4137073b          	subw	a4,a4,s3
 900:	c798                	sw	a4,8(a5)
        p += p->s.size;
 902:	02071693          	slli	a3,a4,0x20
 906:	01c6d713          	srli	a4,a3,0x1c
 90a:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 90c:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 910:	00000717          	auipc	a4,0x0
 914:	70a73023          	sd	a0,1792(a4) # 1010 <freep>
      return (void*)(p + 1);
 918:	01078513          	addi	a0,a5,16
  }
}
 91c:	70e2                	ld	ra,56(sp)
 91e:	7442                	ld	s0,48(sp)
 920:	7902                	ld	s2,32(sp)
 922:	69e2                	ld	s3,24(sp)
 924:	6121                	addi	sp,sp,64
 926:	8082                	ret
 928:	74a2                	ld	s1,40(sp)
 92a:	6a42                	ld	s4,16(sp)
 92c:	6aa2                	ld	s5,8(sp)
 92e:	6b02                	ld	s6,0(sp)
 930:	b7f5                	j	91c <malloc+0xdc>

0000000000000932 <statistics>:
#include "kernel/fcntl.h"
#include "user/user.h"

int
statistics(void *buf, int sz)
{
 932:	7179                	addi	sp,sp,-48
 934:	f406                	sd	ra,40(sp)
 936:	f022                	sd	s0,32(sp)
 938:	ec26                	sd	s1,24(sp)
 93a:	e84a                	sd	s2,16(sp)
 93c:	e44e                	sd	s3,8(sp)
 93e:	e052                	sd	s4,0(sp)
 940:	1800                	addi	s0,sp,48
 942:	8a2a                	mv	s4,a0
 944:	892e                	mv	s2,a1
  int fd, i, n;
  
  fd = open("statistics", O_RDONLY);
 946:	4581                	li	a1,0
 948:	00000517          	auipc	a0,0x0
 94c:	07050513          	addi	a0,a0,112 # 9b8 <statistics+0x86>
 950:	a49ff0ef          	jal	398 <open>
  if(fd < 0) {
 954:	02054e63          	bltz	a0,990 <statistics+0x5e>
 958:	89aa                	mv	s3,a0
      fprintf(2, "stats: open failed\n");
      exit(1);
  }
  for (i = 0; i < sz; ) {
 95a:	4481                	li	s1,0
 95c:	01205e63          	blez	s2,978 <statistics+0x46>
    if ((n = read(fd, buf+i, sz-i)) < 0) {
 960:	4099063b          	subw	a2,s2,s1
 964:	009a05b3          	add	a1,s4,s1
 968:	854e                	mv	a0,s3
 96a:	a07ff0ef          	jal	370 <read>
 96e:	00054563          	bltz	a0,978 <statistics+0x46>
      break;
    }
    i += n;
 972:	9ca9                	addw	s1,s1,a0
  for (i = 0; i < sz; ) {
 974:	ff24c6e3          	blt	s1,s2,960 <statistics+0x2e>
  }
  close(fd);
 978:	854e                	mv	a0,s3
 97a:	a07ff0ef          	jal	380 <close>
  return i;
}
 97e:	8526                	mv	a0,s1
 980:	70a2                	ld	ra,40(sp)
 982:	7402                	ld	s0,32(sp)
 984:	64e2                	ld	s1,24(sp)
 986:	6942                	ld	s2,16(sp)
 988:	69a2                	ld	s3,8(sp)
 98a:	6a02                	ld	s4,0(sp)
 98c:	6145                	addi	sp,sp,48
 98e:	8082                	ret
      fprintf(2, "stats: open failed\n");
 990:	00000597          	auipc	a1,0x0
 994:	0b058593          	addi	a1,a1,176 # a40 <statistics+0x10e>
 998:	4509                	li	a0,2
 99a:	dc5ff0ef          	jal	75e <fprintf>
      exit(1);
 99e:	4505                	li	a0,1
 9a0:	9b9ff0ef          	jal	358 <exit>
