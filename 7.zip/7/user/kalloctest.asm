
user/_kalloctest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <ntas>:
  test3();
  exit(0);
}

int ntas(int print)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	e04a                	sd	s2,0(sp)
   a:	1000                	addi	s0,sp,32
   c:	892a                	mv	s2,a0
  int n;
  char *c;

  if (statistics(buf, SZ) <= 0) {
   e:	6585                	lui	a1,0x1
  10:	00001517          	auipc	a0,0x1
  14:	00050513          	mv	a0,a0
  18:	4bb000ef          	jal	cd2 <statistics>
  1c:	02a05763          	blez	a0,4a <ntas+0x4a>
    fprintf(2, "ntas: no stats\n");
  }
  c = strchr(buf, '=');
  20:	03d00593          	li	a1,61
  24:	00001517          	auipc	a0,0x1
  28:	fec50513          	addi	a0,a0,-20 # 1010 <buf>
  2c:	4f4000ef          	jal	520 <strchr>
  n = atoi(c+2);
  30:	0509                	addi	a0,a0,2
  32:	5c8000ef          	jal	5fa <atoi>
  36:	84aa                	mv	s1,a0
  if(print)
  38:	02091163          	bnez	s2,5a <ntas+0x5a>
    printf("%s", buf);
  return n;
}
  3c:	8526                	mv	a0,s1
  3e:	60e2                	ld	ra,24(sp)
  40:	6442                	ld	s0,16(sp)
  42:	64a2                	ld	s1,8(sp)
  44:	6902                	ld	s2,0(sp)
  46:	6105                	addi	sp,sp,32
  48:	8082                	ret
    fprintf(2, "ntas: no stats\n");
  4a:	00001597          	auipc	a1,0x1
  4e:	d0658593          	addi	a1,a1,-762 # d50 <statistics+0x7e>
  52:	4509                	li	a0,2
  54:	2ab000ef          	jal	afe <fprintf>
  58:	b7e1                	j	20 <ntas+0x20>
    printf("%s", buf);
  5a:	00001597          	auipc	a1,0x1
  5e:	fb658593          	addi	a1,a1,-74 # 1010 <buf>
  62:	00001517          	auipc	a0,0x1
  66:	cfe50513          	addi	a0,a0,-770 # d60 <statistics+0x8e>
  6a:	2bf000ef          	jal	b28 <printf>
  6e:	b7f9                	j	3c <ntas+0x3c>

0000000000000070 <test1>:

// Test concurrent kallocs and kfrees
void test1(void)
{
  70:	715d                	addi	sp,sp,-80
  72:	e486                	sd	ra,72(sp)
  74:	e0a2                	sd	s0,64(sp)
  76:	fc26                	sd	s1,56(sp)
  78:	0880                	addi	s0,sp,80
  void *a, *a1;
  int n, m;

  printf("start test1\n");  
  7a:	00001517          	auipc	a0,0x1
  7e:	cee50513          	addi	a0,a0,-786 # d68 <statistics+0x96>
  82:	2a7000ef          	jal	b28 <printf>
  m = ntas(0);
  86:	4501                	li	a0,0
  88:	f79ff0ef          	jal	0 <ntas>
  8c:	84aa                	mv	s1,a0
  for(int i = 0; i < NCHILD; i++){
    int pid = fork();
  8e:	662000ef          	jal	6f0 <fork>
    if(pid < 0){
  92:	06054063          	bltz	a0,f2 <test1+0x82>
      printf("fork failed");
      exit(-1);
    }
    if(pid == 0){
  96:	c93d                	beqz	a0,10c <test1+0x9c>
    int pid = fork();
  98:	658000ef          	jal	6f0 <fork>
    if(pid < 0){
  9c:	04054b63          	bltz	a0,f2 <test1+0x82>
    if(pid == 0){
  a0:	c535                	beqz	a0,10c <test1+0x9c>
        }
      }
      exit(0);
    }
  }
  int status = 0;
  a2:	fa042e23          	sw	zero,-68(s0)
  for(int i = 0; i < NCHILD; i++){
    wait(&status);
  a6:	fbc40513          	addi	a0,s0,-68
  aa:	656000ef          	jal	700 <wait>
    if (status != 0) {
  ae:	fbc42783          	lw	a5,-68(s0)
  b2:	e3d5                	bnez	a5,156 <test1+0xe6>
    wait(&status);
  b4:	fbc40513          	addi	a0,s0,-68
  b8:	648000ef          	jal	700 <wait>
    if (status != 0) {
  bc:	fbc42783          	lw	a5,-68(s0)
  c0:	ebd9                	bnez	a5,156 <test1+0xe6>
      printf("FAIL: a child failed\n");
      exit(1);
    }
  }
  printf("test1 results:\n");
  c2:	00001517          	auipc	a0,0x1
  c6:	cf650513          	addi	a0,a0,-778 # db8 <statistics+0xe6>
  ca:	25f000ef          	jal	b28 <printf>
  n = ntas(1);
  ce:	4505                	li	a0,1
  d0:	f31ff0ef          	jal	0 <ntas>
  if(n-m < 10) 
  d4:	9d05                	subw	a0,a0,s1
  d6:	47a5                	li	a5,9
  d8:	08a7cc63          	blt	a5,a0,170 <test1+0x100>
    printf("test1 OK\n");
  dc:	00001517          	auipc	a0,0x1
  e0:	cec50513          	addi	a0,a0,-788 # dc8 <statistics+0xf6>
  e4:	245000ef          	jal	b28 <printf>
  else
    printf("test1 FAIL\n");
}
  e8:	60a6                	ld	ra,72(sp)
  ea:	6406                	ld	s0,64(sp)
  ec:	74e2                	ld	s1,56(sp)
  ee:	6161                	addi	sp,sp,80
  f0:	8082                	ret
  f2:	f84a                	sd	s2,48(sp)
  f4:	f44e                	sd	s3,40(sp)
  f6:	f052                	sd	s4,32(sp)
  f8:	ec56                	sd	s5,24(sp)
      printf("fork failed");
  fa:	00001517          	auipc	a0,0x1
  fe:	c7e50513          	addi	a0,a0,-898 # d78 <statistics+0xa6>
 102:	227000ef          	jal	b28 <printf>
      exit(-1);
 106:	557d                	li	a0,-1
 108:	5f0000ef          	jal	6f8 <exit>
 10c:	f84a                	sd	s2,48(sp)
 10e:	f44e                	sd	s3,40(sp)
 110:	f052                	sd	s4,32(sp)
 112:	ec56                	sd	s5,24(sp)
{
 114:	6961                	lui	s2,0x18
 116:	6a090913          	addi	s2,s2,1696 # 186a0 <base+0x16690>
        a = sbrk(4096);
 11a:	6985                	lui	s3,0x1
        *(int *)(a+4) = 1;
 11c:	4a85                	li	s5,1
        a1 = sbrk(-4096);
 11e:	7a7d                	lui	s4,0xfffff
        a = sbrk(4096);
 120:	854e                	mv	a0,s3
 122:	65e000ef          	jal	780 <sbrk>
 126:	84aa                	mv	s1,a0
        *(int *)(a+4) = 1;
 128:	01552223          	sw	s5,4(a0)
        a1 = sbrk(-4096);
 12c:	8552                	mv	a0,s4
 12e:	652000ef          	jal	780 <sbrk>
        if (a1 != a + 4096) {
 132:	94ce                	add	s1,s1,s3
 134:	00951863          	bne	a0,s1,144 <test1+0xd4>
      for(i = 0; i < N; i++) {
 138:	397d                	addiw	s2,s2,-1
 13a:	fe0913e3          	bnez	s2,120 <test1+0xb0>
      exit(0);
 13e:	4501                	li	a0,0
 140:	5b8000ef          	jal	6f8 <exit>
          printf("test1: FAIL wrong sbrk\n");
 144:	00001517          	auipc	a0,0x1
 148:	c4450513          	addi	a0,a0,-956 # d88 <statistics+0xb6>
 14c:	1dd000ef          	jal	b28 <printf>
          exit(1);
 150:	4505                	li	a0,1
 152:	5a6000ef          	jal	6f8 <exit>
 156:	f84a                	sd	s2,48(sp)
 158:	f44e                	sd	s3,40(sp)
 15a:	f052                	sd	s4,32(sp)
 15c:	ec56                	sd	s5,24(sp)
      printf("FAIL: a child failed\n");
 15e:	00001517          	auipc	a0,0x1
 162:	c4250513          	addi	a0,a0,-958 # da0 <statistics+0xce>
 166:	1c3000ef          	jal	b28 <printf>
      exit(1);
 16a:	4505                	li	a0,1
 16c:	58c000ef          	jal	6f8 <exit>
    printf("test1 FAIL\n");
 170:	00001517          	auipc	a0,0x1
 174:	c6850513          	addi	a0,a0,-920 # dd8 <statistics+0x106>
 178:	1b1000ef          	jal	b28 <printf>
}
 17c:	b7b5                	j	e8 <test1+0x78>

000000000000017e <countfree>:
//
// countfree() from usertests.c
//
int
countfree()
{
 17e:	7139                	addi	sp,sp,-64
 180:	fc06                	sd	ra,56(sp)
 182:	f822                	sd	s0,48(sp)
 184:	f426                	sd	s1,40(sp)
 186:	f04a                	sd	s2,32(sp)
 188:	ec4e                	sd	s3,24(sp)
 18a:	e852                	sd	s4,16(sp)
 18c:	e456                	sd	s5,8(sp)
 18e:	0080                	addi	s0,sp,64
  uint64 sz0 = (uint64)sbrk(0);
 190:	4501                	li	a0,0
 192:	5ee000ef          	jal	780 <sbrk>
 196:	8aaa                	mv	s5,a0
  int n = 0;
 198:	4481                	li	s1,0

  while(1){
    uint64 a = (uint64) sbrk(4096);
 19a:	6905                	lui	s2,0x1
    if(a == 0xffffffffffffffff){
 19c:	59fd                	li	s3,-1
      break;
    }
    // modify the memory to make sure it's really allocated.
    *(char *)(a + 4096 - 1) = 1;
 19e:	4a05                	li	s4,1
    uint64 a = (uint64) sbrk(4096);
 1a0:	854a                	mv	a0,s2
 1a2:	5de000ef          	jal	780 <sbrk>
    if(a == 0xffffffffffffffff){
 1a6:	01350763          	beq	a0,s3,1b4 <countfree+0x36>
    *(char *)(a + 4096 - 1) = 1;
 1aa:	954a                	add	a0,a0,s2
 1ac:	ff450fa3          	sb	s4,-1(a0)
    n += 1;
 1b0:	2485                	addiw	s1,s1,1
  while(1){
 1b2:	b7fd                	j	1a0 <countfree+0x22>
  }
  sbrk(-((uint64)sbrk(0) - sz0));
 1b4:	4501                	li	a0,0
 1b6:	5ca000ef          	jal	780 <sbrk>
 1ba:	40aa853b          	subw	a0,s5,a0
 1be:	5c2000ef          	jal	780 <sbrk>
  return n;
}
 1c2:	8526                	mv	a0,s1
 1c4:	70e2                	ld	ra,56(sp)
 1c6:	7442                	ld	s0,48(sp)
 1c8:	74a2                	ld	s1,40(sp)
 1ca:	7902                	ld	s2,32(sp)
 1cc:	69e2                	ld	s3,24(sp)
 1ce:	6a42                	ld	s4,16(sp)
 1d0:	6aa2                	ld	s5,8(sp)
 1d2:	6121                	addi	sp,sp,64
 1d4:	8082                	ret

00000000000001d6 <test2>:
void test2() {
 1d6:	715d                	addi	sp,sp,-80
 1d8:	e486                	sd	ra,72(sp)
 1da:	e0a2                	sd	s0,64(sp)
 1dc:	fc26                	sd	s1,56(sp)
 1de:	f84a                	sd	s2,48(sp)
 1e0:	f44e                	sd	s3,40(sp)
 1e2:	f052                	sd	s4,32(sp)
 1e4:	ec56                	sd	s5,24(sp)
 1e6:	e85a                	sd	s6,16(sp)
 1e8:	e45e                	sd	s7,8(sp)
 1ea:	0880                	addi	s0,sp,80
  int free0 = countfree();
 1ec:	f93ff0ef          	jal	17e <countfree>
 1f0:	89aa                	mv	s3,a0
  printf("start test2\n");  
 1f2:	00001517          	auipc	a0,0x1
 1f6:	bf650513          	addi	a0,a0,-1034 # de8 <statistics+0x116>
 1fa:	12f000ef          	jal	b28 <printf>
  printf("total free number of pages: %d (out of %d)\n", free0, n);
 1fe:	6621                	lui	a2,0x8
 200:	85ce                	mv	a1,s3
 202:	00001517          	auipc	a0,0x1
 206:	bf650513          	addi	a0,a0,-1034 # df8 <statistics+0x126>
 20a:	11f000ef          	jal	b28 <printf>
  if(n - free0 > 1000) {
 20e:	67a1                	lui	a5,0x8
 210:	c1778793          	addi	a5,a5,-1001 # 7c17 <base+0x5c07>
 214:	0137df63          	bge	a5,s3,232 <test2+0x5c>
 218:	4481                	li	s1,0
    if(i % 10 == 9)
 21a:	66666a37          	lui	s4,0x66666
 21e:	667a0a13          	addi	s4,s4,1639 # 66666667 <base+0x66664657>
 222:	4b25                	li	s6,9
      printf(".");
 224:	00001b97          	auipc	s7,0x1
 228:	c34b8b93          	addi	s7,s7,-972 # e58 <statistics+0x186>
  for (int i = 0; i < 50; i++) {
 22c:	03200a93          	li	s5,50
 230:	a839                	j	24e <test2+0x78>
    printf("test2 FAILED: cannot allocate enough memory");
 232:	00001517          	auipc	a0,0x1
 236:	bf650513          	addi	a0,a0,-1034 # e28 <statistics+0x156>
 23a:	0ef000ef          	jal	b28 <printf>
    exit(1);
 23e:	4505                	li	a0,1
 240:	4b8000ef          	jal	6f8 <exit>
    if(free1 != free0) {
 244:	03299b63          	bne	s3,s2,27a <test2+0xa4>
  for (int i = 0; i < 50; i++) {
 248:	2485                	addiw	s1,s1,1
 24a:	05548363          	beq	s1,s5,290 <test2+0xba>
    free1 = countfree();
 24e:	f31ff0ef          	jal	17e <countfree>
 252:	892a                	mv	s2,a0
    if(i % 10 == 9)
 254:	03448733          	mul	a4,s1,s4
 258:	9709                	srai	a4,a4,0x22
 25a:	41f4d79b          	sraiw	a5,s1,0x1f
 25e:	9f1d                	subw	a4,a4,a5
 260:	0027179b          	slliw	a5,a4,0x2
 264:	9fb9                	addw	a5,a5,a4
 266:	0017979b          	slliw	a5,a5,0x1
 26a:	40f487bb          	subw	a5,s1,a5
 26e:	fd679be3          	bne	a5,s6,244 <test2+0x6e>
      printf(".");
 272:	855e                	mv	a0,s7
 274:	0b5000ef          	jal	b28 <printf>
 278:	b7f1                	j	244 <test2+0x6e>
      printf("test2 FAIL: losing pages %d %d\n", free0, free1);
 27a:	864a                	mv	a2,s2
 27c:	85ce                	mv	a1,s3
 27e:	00001517          	auipc	a0,0x1
 282:	be250513          	addi	a0,a0,-1054 # e60 <statistics+0x18e>
 286:	0a3000ef          	jal	b28 <printf>
      exit(1);
 28a:	4505                	li	a0,1
 28c:	46c000ef          	jal	6f8 <exit>
  printf("\ntest2 OK\n");  
 290:	00001517          	auipc	a0,0x1
 294:	bf050513          	addi	a0,a0,-1040 # e80 <statistics+0x1ae>
 298:	091000ef          	jal	b28 <printf>
}
 29c:	60a6                	ld	ra,72(sp)
 29e:	6406                	ld	s0,64(sp)
 2a0:	74e2                	ld	s1,56(sp)
 2a2:	7942                	ld	s2,48(sp)
 2a4:	79a2                	ld	s3,40(sp)
 2a6:	7a02                	ld	s4,32(sp)
 2a8:	6ae2                	ld	s5,24(sp)
 2aa:	6b42                	ld	s6,16(sp)
 2ac:	6ba2                	ld	s7,8(sp)
 2ae:	6161                	addi	sp,sp,80
 2b0:	8082                	ret

00000000000002b2 <test3>:
{
 2b2:	711d                	addi	sp,sp,-96
 2b4:	ec86                	sd	ra,88(sp)
 2b6:	e8a2                	sd	s0,80(sp)
 2b8:	e0ca                	sd	s2,64(sp)
 2ba:	1080                	addi	s0,sp,96
  m = ntas(0);
 2bc:	4501                	li	a0,0
 2be:	d43ff0ef          	jal	0 <ntas>
 2c2:	892a                	mv	s2,a0
  printf("start test3\n");
 2c4:	00001517          	auipc	a0,0x1
 2c8:	bcc50513          	addi	a0,a0,-1076 # e90 <statistics+0x1be>
 2cc:	05d000ef          	jal	b28 <printf>
    pid = fork();
 2d0:	420000ef          	jal	6f0 <fork>
    if(pid < 0){
 2d4:	04054e63          	bltz	a0,330 <test3+0x7e>
    if(pid == 0){
 2d8:	c55d                	beqz	a0,386 <test3+0xd4>
 2da:	e4a6                	sd	s1,72(sp)
    pid = fork();
 2dc:	414000ef          	jal	6f0 <fork>
 2e0:	84aa                	mv	s1,a0
    if(pid < 0){
 2e2:	04054863          	bltz	a0,332 <test3+0x80>
    if(pid == 0){
 2e6:	c52d                	beqz	a0,350 <test3+0x9e>
  int status = 0;
 2e8:	fa042623          	sw	zero,-84(s0)
    wait(&status);
 2ec:	fac40513          	addi	a0,s0,-84
 2f0:	410000ef          	jal	700 <wait>
    if (status != 0) {
 2f4:	fac42783          	lw	a5,-84(s0)
 2f8:	12079663          	bnez	a5,424 <test3+0x172>
  kill(pid);
 2fc:	8526                	mv	a0,s1
 2fe:	42a000ef          	jal	728 <kill>
  n = ntas(1);
 302:	4505                	li	a0,1
 304:	cfdff0ef          	jal	0 <ntas>
 308:	862a                	mv	a2,a0
  if(n-m < 10000) 
 30a:	4125073b          	subw	a4,a0,s2
 30e:	6789                	lui	a5,0x2
 310:	70f78793          	addi	a5,a5,1807 # 270f <base+0x6ff>
 314:	12e7c763          	blt	a5,a4,442 <test3+0x190>
    printf("\ntest3 OK\n");
 318:	00001517          	auipc	a0,0x1
 31c:	be050513          	addi	a0,a0,-1056 # ef8 <statistics+0x226>
 320:	009000ef          	jal	b28 <printf>
 324:	64a6                	ld	s1,72(sp)
}
 326:	60e6                	ld	ra,88(sp)
 328:	6446                	ld	s0,80(sp)
 32a:	6906                	ld	s2,64(sp)
 32c:	6125                	addi	sp,sp,96
 32e:	8082                	ret
 330:	e4a6                	sd	s1,72(sp)
 332:	fc4e                	sd	s3,56(sp)
 334:	f852                	sd	s4,48(sp)
 336:	f456                	sd	s5,40(sp)
 338:	f05a                	sd	s6,32(sp)
 33a:	ec5e                	sd	s7,24(sp)
 33c:	e862                	sd	s8,16(sp)
      printf("fork failed");
 33e:	00001517          	auipc	a0,0x1
 342:	a3a50513          	addi	a0,a0,-1478 # d78 <statistics+0xa6>
 346:	7e2000ef          	jal	b28 <printf>
      exit(-1);
 34a:	557d                	li	a0,-1
 34c:	3ac000ef          	jal	6f8 <exit>
 350:	fc4e                	sd	s3,56(sp)
 352:	f852                	sd	s4,48(sp)
 354:	f456                	sd	s5,40(sp)
 356:	f05a                	sd	s6,32(sp)
 358:	ec5e                	sd	s7,24(sp)
 35a:	e862                	sd	s8,16(sp)
          if(free0 - free1 > 1) {
 35c:	4485                	li	s1,1
          int free0 = countfree();
 35e:	e21ff0ef          	jal	17e <countfree>
 362:	892a                	mv	s2,a0
          int free1 = countfree();
 364:	e1bff0ef          	jal	17e <countfree>
 368:	862a                	mv	a2,a0
          if(free0 - free1 > 1) {
 36a:	40a907bb          	subw	a5,s2,a0
 36e:	fef4d8e3          	bge	s1,a5,35e <test3+0xac>
            printf("test3 FAIL: losing pages %d %d\n", free0, free1);
 372:	85ca                	mv	a1,s2
 374:	00001517          	auipc	a0,0x1
 378:	b5450513          	addi	a0,a0,-1196 # ec8 <statistics+0x1f6>
 37c:	7ac000ef          	jal	b28 <printf>
            exit(1);
 380:	4505                	li	a0,1
 382:	376000ef          	jal	6f8 <exit>
 386:	e4a6                	sd	s1,72(sp)
 388:	fc4e                	sd	s3,56(sp)
 38a:	f852                	sd	s4,48(sp)
 38c:	f456                	sd	s5,40(sp)
 38e:	f05a                	sd	s6,32(sp)
 390:	ec5e                	sd	s7,24(sp)
 392:	e862                	sd	s8,16(sp)
    if(pid == 0){
 394:	4485                	li	s1,1
          a = (uint64) sbrk(4096);
 396:	6905                	lui	s2,0x1
          if(a == 0xffffffffffffffff){
 398:	59fd                	li	s3,-1
          *(int *)(a+4) = 1;
 39a:	8ba6                	mv	s7,s1
          a1 = (uint64) sbrk(-4096);
 39c:	7b7d                	lui	s6,0xfffff
          if ((i + 1) % 10000 == 0) {
 39e:	68db9ab7          	lui	s5,0x68db9
 3a2:	bada8a93          	addi	s5,s5,-1107 # 68db8bad <base+0x68db6b9d>
 3a6:	6a09                	lui	s4,0x2
 3a8:	710a0a1b          	addiw	s4,s4,1808 # 2710 <base+0x700>
 3ac:	a005                	j	3cc <test3+0x11a>
            printf("test3 FAIL: wrong sbrk\n");
 3ae:	00001517          	auipc	a0,0x1
 3b2:	af250513          	addi	a0,a0,-1294 # ea0 <statistics+0x1ce>
 3b6:	772000ef          	jal	b28 <printf>
            exit(1);
 3ba:	4505                	li	a0,1
 3bc:	33c000ef          	jal	6f8 <exit>
        for(i = 0; i < N; i++) {
 3c0:	2485                	addiw	s1,s1,1
 3c2:	67e1                	lui	a5,0x18
 3c4:	6a178793          	addi	a5,a5,1697 # 186a1 <base+0x16691>
 3c8:	04f48263          	beq	s1,a5,40c <test3+0x15a>
          a = (uint64) sbrk(4096);
 3cc:	854a                	mv	a0,s2
 3ce:	3b2000ef          	jal	780 <sbrk>
 3d2:	8c2a                	mv	s8,a0
          if(a == 0xffffffffffffffff){
 3d4:	ff3506e3          	beq	a0,s3,3c0 <test3+0x10e>
          *(int *)(a+4) = 1;
 3d8:	01752223          	sw	s7,4(a0)
          a1 = (uint64) sbrk(-4096);
 3dc:	855a                	mv	a0,s6
 3de:	3a2000ef          	jal	780 <sbrk>
          if (a1 != a + 4096) {
 3e2:	9c4a                	add	s8,s8,s2
 3e4:	fd8515e3          	bne	a0,s8,3ae <test3+0xfc>
          if ((i + 1) % 10000 == 0) {
 3e8:	035487b3          	mul	a5,s1,s5
 3ec:	97b1                	srai	a5,a5,0x2c
 3ee:	41f4d71b          	sraiw	a4,s1,0x1f
 3f2:	9f99                	subw	a5,a5,a4
 3f4:	02fa07bb          	mulw	a5,s4,a5
 3f8:	40f487bb          	subw	a5,s1,a5
 3fc:	f3f1                	bnez	a5,3c0 <test3+0x10e>
            printf(".");
 3fe:	00001517          	auipc	a0,0x1
 402:	a5a50513          	addi	a0,a0,-1446 # e58 <statistics+0x186>
 406:	722000ef          	jal	b28 <printf>
 40a:	bf5d                	j	3c0 <test3+0x10e>
        printf("child done %d\n", i);
 40c:	65e1                	lui	a1,0x18
 40e:	6a058593          	addi	a1,a1,1696 # 186a0 <base+0x16690>
 412:	00001517          	auipc	a0,0x1
 416:	aa650513          	addi	a0,a0,-1370 # eb8 <statistics+0x1e6>
 41a:	70e000ef          	jal	b28 <printf>
        exit(0);
 41e:	4501                	li	a0,0
 420:	2d8000ef          	jal	6f8 <exit>
 424:	fc4e                	sd	s3,56(sp)
 426:	f852                	sd	s4,48(sp)
 428:	f456                	sd	s5,40(sp)
 42a:	f05a                	sd	s6,32(sp)
 42c:	ec5e                	sd	s7,24(sp)
 42e:	e862                	sd	s8,16(sp)
      printf("a child failed\n");
 430:	00001517          	auipc	a0,0x1
 434:	ab850513          	addi	a0,a0,-1352 # ee8 <statistics+0x216>
 438:	6f0000ef          	jal	b28 <printf>
      exit(1);
 43c:	4505                	li	a0,1
 43e:	2ba000ef          	jal	6f8 <exit>
    printf("test3 FAIL m %d n %d\n", m, n);
 442:	85ca                	mv	a1,s2
 444:	00001517          	auipc	a0,0x1
 448:	ac450513          	addi	a0,a0,-1340 # f08 <statistics+0x236>
 44c:	6dc000ef          	jal	b28 <printf>
}
 450:	bdd1                	j	324 <test3+0x72>

0000000000000452 <main>:
{
 452:	1141                	addi	sp,sp,-16
 454:	e406                	sd	ra,8(sp)
 456:	e022                	sd	s0,0(sp)
 458:	0800                	addi	s0,sp,16
  test1();
 45a:	c17ff0ef          	jal	70 <test1>
  test2();
 45e:	d79ff0ef          	jal	1d6 <test2>
  test3();
 462:	e51ff0ef          	jal	2b2 <test3>
  exit(0);
 466:	4501                	li	a0,0
 468:	290000ef          	jal	6f8 <exit>

000000000000046c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 46c:	1141                	addi	sp,sp,-16
 46e:	e406                	sd	ra,8(sp)
 470:	e022                	sd	s0,0(sp)
 472:	0800                	addi	s0,sp,16
  extern int main();
  main();
 474:	fdfff0ef          	jal	452 <main>
  exit(0);
 478:	4501                	li	a0,0
 47a:	27e000ef          	jal	6f8 <exit>

000000000000047e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 47e:	1141                	addi	sp,sp,-16
 480:	e406                	sd	ra,8(sp)
 482:	e022                	sd	s0,0(sp)
 484:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 486:	87aa                	mv	a5,a0
 488:	0585                	addi	a1,a1,1
 48a:	0785                	addi	a5,a5,1
 48c:	fff5c703          	lbu	a4,-1(a1)
 490:	fee78fa3          	sb	a4,-1(a5)
 494:	fb75                	bnez	a4,488 <strcpy+0xa>
    ;
  return os;
}
 496:	60a2                	ld	ra,8(sp)
 498:	6402                	ld	s0,0(sp)
 49a:	0141                	addi	sp,sp,16
 49c:	8082                	ret

000000000000049e <strcmp>:

int
strcmp(const char *p, const char *q)
{
 49e:	1141                	addi	sp,sp,-16
 4a0:	e406                	sd	ra,8(sp)
 4a2:	e022                	sd	s0,0(sp)
 4a4:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 4a6:	00054783          	lbu	a5,0(a0)
 4aa:	cb91                	beqz	a5,4be <strcmp+0x20>
 4ac:	0005c703          	lbu	a4,0(a1)
 4b0:	00f71763          	bne	a4,a5,4be <strcmp+0x20>
    p++, q++;
 4b4:	0505                	addi	a0,a0,1
 4b6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 4b8:	00054783          	lbu	a5,0(a0)
 4bc:	fbe5                	bnez	a5,4ac <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 4be:	0005c503          	lbu	a0,0(a1)
}
 4c2:	40a7853b          	subw	a0,a5,a0
 4c6:	60a2                	ld	ra,8(sp)
 4c8:	6402                	ld	s0,0(sp)
 4ca:	0141                	addi	sp,sp,16
 4cc:	8082                	ret

00000000000004ce <strlen>:

uint
strlen(const char *s)
{
 4ce:	1141                	addi	sp,sp,-16
 4d0:	e406                	sd	ra,8(sp)
 4d2:	e022                	sd	s0,0(sp)
 4d4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 4d6:	00054783          	lbu	a5,0(a0)
 4da:	cf91                	beqz	a5,4f6 <strlen+0x28>
 4dc:	00150793          	addi	a5,a0,1
 4e0:	86be                	mv	a3,a5
 4e2:	0785                	addi	a5,a5,1
 4e4:	fff7c703          	lbu	a4,-1(a5)
 4e8:	ff65                	bnez	a4,4e0 <strlen+0x12>
 4ea:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 4ee:	60a2                	ld	ra,8(sp)
 4f0:	6402                	ld	s0,0(sp)
 4f2:	0141                	addi	sp,sp,16
 4f4:	8082                	ret
  for(n = 0; s[n]; n++)
 4f6:	4501                	li	a0,0
 4f8:	bfdd                	j	4ee <strlen+0x20>

00000000000004fa <memset>:

void*
memset(void *dst, int c, uint n)
{
 4fa:	1141                	addi	sp,sp,-16
 4fc:	e406                	sd	ra,8(sp)
 4fe:	e022                	sd	s0,0(sp)
 500:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 502:	ca19                	beqz	a2,518 <memset+0x1e>
 504:	87aa                	mv	a5,a0
 506:	1602                	slli	a2,a2,0x20
 508:	9201                	srli	a2,a2,0x20
 50a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 50e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 512:	0785                	addi	a5,a5,1
 514:	fee79de3          	bne	a5,a4,50e <memset+0x14>
  }
  return dst;
}
 518:	60a2                	ld	ra,8(sp)
 51a:	6402                	ld	s0,0(sp)
 51c:	0141                	addi	sp,sp,16
 51e:	8082                	ret

0000000000000520 <strchr>:

char*
strchr(const char *s, char c)
{
 520:	1141                	addi	sp,sp,-16
 522:	e406                	sd	ra,8(sp)
 524:	e022                	sd	s0,0(sp)
 526:	0800                	addi	s0,sp,16
  for(; *s; s++)
 528:	00054783          	lbu	a5,0(a0)
 52c:	cf81                	beqz	a5,544 <strchr+0x24>
    if(*s == c)
 52e:	00f58763          	beq	a1,a5,53c <strchr+0x1c>
  for(; *s; s++)
 532:	0505                	addi	a0,a0,1
 534:	00054783          	lbu	a5,0(a0)
 538:	fbfd                	bnez	a5,52e <strchr+0xe>
      return (char*)s;
  return 0;
 53a:	4501                	li	a0,0
}
 53c:	60a2                	ld	ra,8(sp)
 53e:	6402                	ld	s0,0(sp)
 540:	0141                	addi	sp,sp,16
 542:	8082                	ret
  return 0;
 544:	4501                	li	a0,0
 546:	bfdd                	j	53c <strchr+0x1c>

0000000000000548 <gets>:

char*
gets(char *buf, int max)
{
 548:	711d                	addi	sp,sp,-96
 54a:	ec86                	sd	ra,88(sp)
 54c:	e8a2                	sd	s0,80(sp)
 54e:	e4a6                	sd	s1,72(sp)
 550:	e0ca                	sd	s2,64(sp)
 552:	fc4e                	sd	s3,56(sp)
 554:	f852                	sd	s4,48(sp)
 556:	f456                	sd	s5,40(sp)
 558:	f05a                	sd	s6,32(sp)
 55a:	ec5e                	sd	s7,24(sp)
 55c:	e862                	sd	s8,16(sp)
 55e:	1080                	addi	s0,sp,96
 560:	8baa                	mv	s7,a0
 562:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 564:	892a                	mv	s2,a0
 566:	4481                	li	s1,0
    cc = read(0, &c, 1);
 568:	faf40b13          	addi	s6,s0,-81
 56c:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 56e:	8c26                	mv	s8,s1
 570:	0014899b          	addiw	s3,s1,1
 574:	84ce                	mv	s1,s3
 576:	0349d463          	bge	s3,s4,59e <gets+0x56>
    cc = read(0, &c, 1);
 57a:	8656                	mv	a2,s5
 57c:	85da                	mv	a1,s6
 57e:	4501                	li	a0,0
 580:	190000ef          	jal	710 <read>
    if(cc < 1)
 584:	00a05d63          	blez	a0,59e <gets+0x56>
      break;
    buf[i++] = c;
 588:	faf44783          	lbu	a5,-81(s0)
 58c:	00f90023          	sb	a5,0(s2) # 1000 <freep>
    if(c == '\n' || c == '\r')
 590:	0905                	addi	s2,s2,1
 592:	ff678713          	addi	a4,a5,-10
 596:	c319                	beqz	a4,59c <gets+0x54>
 598:	17cd                	addi	a5,a5,-13
 59a:	fbf1                	bnez	a5,56e <gets+0x26>
    buf[i++] = c;
 59c:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 59e:	9c5e                	add	s8,s8,s7
 5a0:	000c0023          	sb	zero,0(s8)
  return buf;
}
 5a4:	855e                	mv	a0,s7
 5a6:	60e6                	ld	ra,88(sp)
 5a8:	6446                	ld	s0,80(sp)
 5aa:	64a6                	ld	s1,72(sp)
 5ac:	6906                	ld	s2,64(sp)
 5ae:	79e2                	ld	s3,56(sp)
 5b0:	7a42                	ld	s4,48(sp)
 5b2:	7aa2                	ld	s5,40(sp)
 5b4:	7b02                	ld	s6,32(sp)
 5b6:	6be2                	ld	s7,24(sp)
 5b8:	6c42                	ld	s8,16(sp)
 5ba:	6125                	addi	sp,sp,96
 5bc:	8082                	ret

00000000000005be <stat>:

int
stat(const char *n, struct stat *st)
{
 5be:	1101                	addi	sp,sp,-32
 5c0:	ec06                	sd	ra,24(sp)
 5c2:	e822                	sd	s0,16(sp)
 5c4:	e04a                	sd	s2,0(sp)
 5c6:	1000                	addi	s0,sp,32
 5c8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 5ca:	4581                	li	a1,0
 5cc:	16c000ef          	jal	738 <open>
  if(fd < 0)
 5d0:	02054263          	bltz	a0,5f4 <stat+0x36>
 5d4:	e426                	sd	s1,8(sp)
 5d6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 5d8:	85ca                	mv	a1,s2
 5da:	176000ef          	jal	750 <fstat>
 5de:	892a                	mv	s2,a0
  close(fd);
 5e0:	8526                	mv	a0,s1
 5e2:	13e000ef          	jal	720 <close>
  return r;
 5e6:	64a2                	ld	s1,8(sp)
}
 5e8:	854a                	mv	a0,s2
 5ea:	60e2                	ld	ra,24(sp)
 5ec:	6442                	ld	s0,16(sp)
 5ee:	6902                	ld	s2,0(sp)
 5f0:	6105                	addi	sp,sp,32
 5f2:	8082                	ret
    return -1;
 5f4:	57fd                	li	a5,-1
 5f6:	893e                	mv	s2,a5
 5f8:	bfc5                	j	5e8 <stat+0x2a>

00000000000005fa <atoi>:

int
atoi(const char *s)
{
 5fa:	1141                	addi	sp,sp,-16
 5fc:	e406                	sd	ra,8(sp)
 5fe:	e022                	sd	s0,0(sp)
 600:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 602:	00054683          	lbu	a3,0(a0)
 606:	fd06879b          	addiw	a5,a3,-48
 60a:	0ff7f793          	zext.b	a5,a5
 60e:	4625                	li	a2,9
 610:	02f66963          	bltu	a2,a5,642 <atoi+0x48>
 614:	872a                	mv	a4,a0
  n = 0;
 616:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 618:	0705                	addi	a4,a4,1
 61a:	0025179b          	slliw	a5,a0,0x2
 61e:	9fa9                	addw	a5,a5,a0
 620:	0017979b          	slliw	a5,a5,0x1
 624:	9fb5                	addw	a5,a5,a3
 626:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 62a:	00074683          	lbu	a3,0(a4)
 62e:	fd06879b          	addiw	a5,a3,-48
 632:	0ff7f793          	zext.b	a5,a5
 636:	fef671e3          	bgeu	a2,a5,618 <atoi+0x1e>
  return n;
}
 63a:	60a2                	ld	ra,8(sp)
 63c:	6402                	ld	s0,0(sp)
 63e:	0141                	addi	sp,sp,16
 640:	8082                	ret
  n = 0;
 642:	4501                	li	a0,0
 644:	bfdd                	j	63a <atoi+0x40>

0000000000000646 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 646:	1141                	addi	sp,sp,-16
 648:	e406                	sd	ra,8(sp)
 64a:	e022                	sd	s0,0(sp)
 64c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 64e:	02b57563          	bgeu	a0,a1,678 <memmove+0x32>
    while(n-- > 0)
 652:	00c05f63          	blez	a2,670 <memmove+0x2a>
 656:	1602                	slli	a2,a2,0x20
 658:	9201                	srli	a2,a2,0x20
 65a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 65e:	872a                	mv	a4,a0
      *dst++ = *src++;
 660:	0585                	addi	a1,a1,1
 662:	0705                	addi	a4,a4,1
 664:	fff5c683          	lbu	a3,-1(a1)
 668:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 66c:	fee79ae3          	bne	a5,a4,660 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 670:	60a2                	ld	ra,8(sp)
 672:	6402                	ld	s0,0(sp)
 674:	0141                	addi	sp,sp,16
 676:	8082                	ret
    while(n-- > 0)
 678:	fec05ce3          	blez	a2,670 <memmove+0x2a>
    dst += n;
 67c:	00c50733          	add	a4,a0,a2
    src += n;
 680:	95b2                	add	a1,a1,a2
 682:	fff6079b          	addiw	a5,a2,-1 # 7fff <base+0x5fef>
 686:	1782                	slli	a5,a5,0x20
 688:	9381                	srli	a5,a5,0x20
 68a:	fff7c793          	not	a5,a5
 68e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 690:	15fd                	addi	a1,a1,-1
 692:	177d                	addi	a4,a4,-1
 694:	0005c683          	lbu	a3,0(a1)
 698:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 69c:	fef71ae3          	bne	a4,a5,690 <memmove+0x4a>
 6a0:	bfc1                	j	670 <memmove+0x2a>

00000000000006a2 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 6a2:	1141                	addi	sp,sp,-16
 6a4:	e406                	sd	ra,8(sp)
 6a6:	e022                	sd	s0,0(sp)
 6a8:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 6aa:	c61d                	beqz	a2,6d8 <memcmp+0x36>
 6ac:	1602                	slli	a2,a2,0x20
 6ae:	9201                	srli	a2,a2,0x20
 6b0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 6b4:	00054783          	lbu	a5,0(a0)
 6b8:	0005c703          	lbu	a4,0(a1)
 6bc:	00e79863          	bne	a5,a4,6cc <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 6c0:	0505                	addi	a0,a0,1
    p2++;
 6c2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 6c4:	fed518e3          	bne	a0,a3,6b4 <memcmp+0x12>
  }
  return 0;
 6c8:	4501                	li	a0,0
 6ca:	a019                	j	6d0 <memcmp+0x2e>
      return *p1 - *p2;
 6cc:	40e7853b          	subw	a0,a5,a4
}
 6d0:	60a2                	ld	ra,8(sp)
 6d2:	6402                	ld	s0,0(sp)
 6d4:	0141                	addi	sp,sp,16
 6d6:	8082                	ret
  return 0;
 6d8:	4501                	li	a0,0
 6da:	bfdd                	j	6d0 <memcmp+0x2e>

00000000000006dc <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 6dc:	1141                	addi	sp,sp,-16
 6de:	e406                	sd	ra,8(sp)
 6e0:	e022                	sd	s0,0(sp)
 6e2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 6e4:	f63ff0ef          	jal	646 <memmove>
}
 6e8:	60a2                	ld	ra,8(sp)
 6ea:	6402                	ld	s0,0(sp)
 6ec:	0141                	addi	sp,sp,16
 6ee:	8082                	ret

00000000000006f0 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 6f0:	4885                	li	a7,1
 ecall
 6f2:	00000073          	ecall
 ret
 6f6:	8082                	ret

00000000000006f8 <exit>:
.global exit
exit:
 li a7, SYS_exit
 6f8:	4889                	li	a7,2
 ecall
 6fa:	00000073          	ecall
 ret
 6fe:	8082                	ret

0000000000000700 <wait>:
.global wait
wait:
 li a7, SYS_wait
 700:	488d                	li	a7,3
 ecall
 702:	00000073          	ecall
 ret
 706:	8082                	ret

0000000000000708 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 708:	4891                	li	a7,4
 ecall
 70a:	00000073          	ecall
 ret
 70e:	8082                	ret

0000000000000710 <read>:
.global read
read:
 li a7, SYS_read
 710:	4895                	li	a7,5
 ecall
 712:	00000073          	ecall
 ret
 716:	8082                	ret

0000000000000718 <write>:
.global write
write:
 li a7, SYS_write
 718:	48c1                	li	a7,16
 ecall
 71a:	00000073          	ecall
 ret
 71e:	8082                	ret

0000000000000720 <close>:
.global close
close:
 li a7, SYS_close
 720:	48d5                	li	a7,21
 ecall
 722:	00000073          	ecall
 ret
 726:	8082                	ret

0000000000000728 <kill>:
.global kill
kill:
 li a7, SYS_kill
 728:	4899                	li	a7,6
 ecall
 72a:	00000073          	ecall
 ret
 72e:	8082                	ret

0000000000000730 <exec>:
.global exec
exec:
 li a7, SYS_exec
 730:	489d                	li	a7,7
 ecall
 732:	00000073          	ecall
 ret
 736:	8082                	ret

0000000000000738 <open>:
.global open
open:
 li a7, SYS_open
 738:	48bd                	li	a7,15
 ecall
 73a:	00000073          	ecall
 ret
 73e:	8082                	ret

0000000000000740 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 740:	48c5                	li	a7,17
 ecall
 742:	00000073          	ecall
 ret
 746:	8082                	ret

0000000000000748 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 748:	48c9                	li	a7,18
 ecall
 74a:	00000073          	ecall
 ret
 74e:	8082                	ret

0000000000000750 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 750:	48a1                	li	a7,8
 ecall
 752:	00000073          	ecall
 ret
 756:	8082                	ret

0000000000000758 <link>:
.global link
link:
 li a7, SYS_link
 758:	48cd                	li	a7,19
 ecall
 75a:	00000073          	ecall
 ret
 75e:	8082                	ret

0000000000000760 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 760:	48d1                	li	a7,20
 ecall
 762:	00000073          	ecall
 ret
 766:	8082                	ret

0000000000000768 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 768:	48a5                	li	a7,9
 ecall
 76a:	00000073          	ecall
 ret
 76e:	8082                	ret

0000000000000770 <dup>:
.global dup
dup:
 li a7, SYS_dup
 770:	48a9                	li	a7,10
 ecall
 772:	00000073          	ecall
 ret
 776:	8082                	ret

0000000000000778 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 778:	48ad                	li	a7,11
 ecall
 77a:	00000073          	ecall
 ret
 77e:	8082                	ret

0000000000000780 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 780:	48b1                	li	a7,12
 ecall
 782:	00000073          	ecall
 ret
 786:	8082                	ret

0000000000000788 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 788:	48b5                	li	a7,13
 ecall
 78a:	00000073          	ecall
 ret
 78e:	8082                	ret

0000000000000790 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 790:	48b9                	li	a7,14
 ecall
 792:	00000073          	ecall
 ret
 796:	8082                	ret

0000000000000798 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 798:	1101                	addi	sp,sp,-32
 79a:	ec06                	sd	ra,24(sp)
 79c:	e822                	sd	s0,16(sp)
 79e:	1000                	addi	s0,sp,32
 7a0:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 7a4:	4605                	li	a2,1
 7a6:	fef40593          	addi	a1,s0,-17
 7aa:	f6fff0ef          	jal	718 <write>
}
 7ae:	60e2                	ld	ra,24(sp)
 7b0:	6442                	ld	s0,16(sp)
 7b2:	6105                	addi	sp,sp,32
 7b4:	8082                	ret

00000000000007b6 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 7b6:	7139                	addi	sp,sp,-64
 7b8:	fc06                	sd	ra,56(sp)
 7ba:	f822                	sd	s0,48(sp)
 7bc:	f04a                	sd	s2,32(sp)
 7be:	ec4e                	sd	s3,24(sp)
 7c0:	0080                	addi	s0,sp,64
 7c2:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 7c4:	cac9                	beqz	a3,856 <printint+0xa0>
 7c6:	01f5d79b          	srliw	a5,a1,0x1f
 7ca:	c7d1                	beqz	a5,856 <printint+0xa0>
    neg = 1;
    x = -xx;
 7cc:	40b005bb          	negw	a1,a1
    neg = 1;
 7d0:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 7d2:	fc040993          	addi	s3,s0,-64
  neg = 0;
 7d6:	86ce                	mv	a3,s3
  i = 0;
 7d8:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 7da:	00000817          	auipc	a6,0x0
 7de:	77680813          	addi	a6,a6,1910 # f50 <digits>
 7e2:	88ba                	mv	a7,a4
 7e4:	0017051b          	addiw	a0,a4,1
 7e8:	872a                	mv	a4,a0
 7ea:	02c5f7bb          	remuw	a5,a1,a2
 7ee:	1782                	slli	a5,a5,0x20
 7f0:	9381                	srli	a5,a5,0x20
 7f2:	97c2                	add	a5,a5,a6
 7f4:	0007c783          	lbu	a5,0(a5)
 7f8:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 7fc:	87ae                	mv	a5,a1
 7fe:	02c5d5bb          	divuw	a1,a1,a2
 802:	0685                	addi	a3,a3,1
 804:	fcc7ffe3          	bgeu	a5,a2,7e2 <printint+0x2c>
  if(neg)
 808:	00030c63          	beqz	t1,820 <printint+0x6a>
    buf[i++] = '-';
 80c:	fd050793          	addi	a5,a0,-48
 810:	00878533          	add	a0,a5,s0
 814:	02d00793          	li	a5,45
 818:	fef50823          	sb	a5,-16(a0)
 81c:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 820:	02e05563          	blez	a4,84a <printint+0x94>
 824:	f426                	sd	s1,40(sp)
 826:	377d                	addiw	a4,a4,-1
 828:	00e984b3          	add	s1,s3,a4
 82c:	19fd                	addi	s3,s3,-1 # fff <digits+0xaf>
 82e:	99ba                	add	s3,s3,a4
 830:	1702                	slli	a4,a4,0x20
 832:	9301                	srli	a4,a4,0x20
 834:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 838:	0004c583          	lbu	a1,0(s1)
 83c:	854a                	mv	a0,s2
 83e:	f5bff0ef          	jal	798 <putc>
  while(--i >= 0)
 842:	14fd                	addi	s1,s1,-1
 844:	ff349ae3          	bne	s1,s3,838 <printint+0x82>
 848:	74a2                	ld	s1,40(sp)
}
 84a:	70e2                	ld	ra,56(sp)
 84c:	7442                	ld	s0,48(sp)
 84e:	7902                	ld	s2,32(sp)
 850:	69e2                	ld	s3,24(sp)
 852:	6121                	addi	sp,sp,64
 854:	8082                	ret
  neg = 0;
 856:	4301                	li	t1,0
 858:	bfad                	j	7d2 <printint+0x1c>

000000000000085a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 85a:	711d                	addi	sp,sp,-96
 85c:	ec86                	sd	ra,88(sp)
 85e:	e8a2                	sd	s0,80(sp)
 860:	e4a6                	sd	s1,72(sp)
 862:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 864:	0005c483          	lbu	s1,0(a1)
 868:	20048963          	beqz	s1,a7a <vprintf+0x220>
 86c:	e0ca                	sd	s2,64(sp)
 86e:	fc4e                	sd	s3,56(sp)
 870:	f852                	sd	s4,48(sp)
 872:	f456                	sd	s5,40(sp)
 874:	f05a                	sd	s6,32(sp)
 876:	ec5e                	sd	s7,24(sp)
 878:	e862                	sd	s8,16(sp)
 87a:	8b2a                	mv	s6,a0
 87c:	8a2e                	mv	s4,a1
 87e:	8bb2                	mv	s7,a2
  state = 0;
 880:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 882:	4901                	li	s2,0
 884:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 886:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 88a:	06400c13          	li	s8,100
 88e:	a00d                	j	8b0 <vprintf+0x56>
        putc(fd, c0);
 890:	85a6                	mv	a1,s1
 892:	855a                	mv	a0,s6
 894:	f05ff0ef          	jal	798 <putc>
 898:	a019                	j	89e <vprintf+0x44>
    } else if(state == '%'){
 89a:	03598363          	beq	s3,s5,8c0 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 89e:	0019079b          	addiw	a5,s2,1
 8a2:	893e                	mv	s2,a5
 8a4:	873e                	mv	a4,a5
 8a6:	97d2                	add	a5,a5,s4
 8a8:	0007c483          	lbu	s1,0(a5)
 8ac:	1c048063          	beqz	s1,a6c <vprintf+0x212>
    c0 = fmt[i] & 0xff;
 8b0:	0004879b          	sext.w	a5,s1
    if(state == 0){
 8b4:	fe0993e3          	bnez	s3,89a <vprintf+0x40>
      if(c0 == '%'){
 8b8:	fd579ce3          	bne	a5,s5,890 <vprintf+0x36>
        state = '%';
 8bc:	89be                	mv	s3,a5
 8be:	b7c5                	j	89e <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 8c0:	00ea06b3          	add	a3,s4,a4
 8c4:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 8c8:	1a060e63          	beqz	a2,a84 <vprintf+0x22a>
      if(c0 == 'd'){
 8cc:	03878763          	beq	a5,s8,8fa <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 8d0:	f9478693          	addi	a3,a5,-108
 8d4:	0016b693          	seqz	a3,a3
 8d8:	f9c60593          	addi	a1,a2,-100
 8dc:	e99d                	bnez	a1,912 <vprintf+0xb8>
 8de:	ca95                	beqz	a3,912 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8e0:	008b8493          	addi	s1,s7,8
 8e4:	4685                	li	a3,1
 8e6:	4629                	li	a2,10
 8e8:	000ba583          	lw	a1,0(s7)
 8ec:	855a                	mv	a0,s6
 8ee:	ec9ff0ef          	jal	7b6 <printint>
        i += 1;
 8f2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 8f4:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 8f6:	4981                	li	s3,0
 8f8:	b75d                	j	89e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 8fa:	008b8493          	addi	s1,s7,8
 8fe:	4685                	li	a3,1
 900:	4629                	li	a2,10
 902:	000ba583          	lw	a1,0(s7)
 906:	855a                	mv	a0,s6
 908:	eafff0ef          	jal	7b6 <printint>
 90c:	8ba6                	mv	s7,s1
      state = 0;
 90e:	4981                	li	s3,0
 910:	b779                	j	89e <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 912:	9752                	add	a4,a4,s4
 914:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 918:	f9460713          	addi	a4,a2,-108
 91c:	00173713          	seqz	a4,a4
 920:	8f75                	and	a4,a4,a3
 922:	f9c58513          	addi	a0,a1,-100
 926:	16051963          	bnez	a0,a98 <vprintf+0x23e>
 92a:	16070763          	beqz	a4,a98 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
 92e:	008b8493          	addi	s1,s7,8
 932:	4685                	li	a3,1
 934:	4629                	li	a2,10
 936:	000ba583          	lw	a1,0(s7)
 93a:	855a                	mv	a0,s6
 93c:	e7bff0ef          	jal	7b6 <printint>
        i += 2;
 940:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 942:	8ba6                	mv	s7,s1
      state = 0;
 944:	4981                	li	s3,0
        i += 2;
 946:	bfa1                	j	89e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 948:	008b8493          	addi	s1,s7,8
 94c:	4681                	li	a3,0
 94e:	4629                	li	a2,10
 950:	000ba583          	lw	a1,0(s7)
 954:	855a                	mv	a0,s6
 956:	e61ff0ef          	jal	7b6 <printint>
 95a:	8ba6                	mv	s7,s1
      state = 0;
 95c:	4981                	li	s3,0
 95e:	b781                	j	89e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 960:	008b8493          	addi	s1,s7,8
 964:	4681                	li	a3,0
 966:	4629                	li	a2,10
 968:	000ba583          	lw	a1,0(s7)
 96c:	855a                	mv	a0,s6
 96e:	e49ff0ef          	jal	7b6 <printint>
        i += 1;
 972:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 974:	8ba6                	mv	s7,s1
      state = 0;
 976:	4981                	li	s3,0
 978:	b71d                	j	89e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 97a:	008b8493          	addi	s1,s7,8
 97e:	4681                	li	a3,0
 980:	4629                	li	a2,10
 982:	000ba583          	lw	a1,0(s7)
 986:	855a                	mv	a0,s6
 988:	e2fff0ef          	jal	7b6 <printint>
        i += 2;
 98c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 98e:	8ba6                	mv	s7,s1
      state = 0;
 990:	4981                	li	s3,0
        i += 2;
 992:	b731                	j	89e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 994:	008b8493          	addi	s1,s7,8
 998:	4681                	li	a3,0
 99a:	4641                	li	a2,16
 99c:	000ba583          	lw	a1,0(s7)
 9a0:	855a                	mv	a0,s6
 9a2:	e15ff0ef          	jal	7b6 <printint>
 9a6:	8ba6                	mv	s7,s1
      state = 0;
 9a8:	4981                	li	s3,0
 9aa:	bdd5                	j	89e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 9ac:	008b8493          	addi	s1,s7,8
 9b0:	4681                	li	a3,0
 9b2:	4641                	li	a2,16
 9b4:	000ba583          	lw	a1,0(s7)
 9b8:	855a                	mv	a0,s6
 9ba:	dfdff0ef          	jal	7b6 <printint>
        i += 1;
 9be:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 9c0:	8ba6                	mv	s7,s1
      state = 0;
 9c2:	4981                	li	s3,0
 9c4:	bde9                	j	89e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 9c6:	008b8493          	addi	s1,s7,8
 9ca:	4681                	li	a3,0
 9cc:	4641                	li	a2,16
 9ce:	000ba583          	lw	a1,0(s7)
 9d2:	855a                	mv	a0,s6
 9d4:	de3ff0ef          	jal	7b6 <printint>
        i += 2;
 9d8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 9da:	8ba6                	mv	s7,s1
      state = 0;
 9dc:	4981                	li	s3,0
        i += 2;
 9de:	b5c1                	j	89e <vprintf+0x44>
 9e0:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 9e2:	008b8793          	addi	a5,s7,8
 9e6:	8cbe                	mv	s9,a5
 9e8:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 9ec:	03000593          	li	a1,48
 9f0:	855a                	mv	a0,s6
 9f2:	da7ff0ef          	jal	798 <putc>
  putc(fd, 'x');
 9f6:	07800593          	li	a1,120
 9fa:	855a                	mv	a0,s6
 9fc:	d9dff0ef          	jal	798 <putc>
 a00:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a02:	00000b97          	auipc	s7,0x0
 a06:	54eb8b93          	addi	s7,s7,1358 # f50 <digits>
 a0a:	03c9d793          	srli	a5,s3,0x3c
 a0e:	97de                	add	a5,a5,s7
 a10:	0007c583          	lbu	a1,0(a5)
 a14:	855a                	mv	a0,s6
 a16:	d83ff0ef          	jal	798 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 a1a:	0992                	slli	s3,s3,0x4
 a1c:	34fd                	addiw	s1,s1,-1
 a1e:	f4f5                	bnez	s1,a0a <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 a20:	8be6                	mv	s7,s9
      state = 0;
 a22:	4981                	li	s3,0
 a24:	6ca2                	ld	s9,8(sp)
 a26:	bda5                	j	89e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 a28:	008b8993          	addi	s3,s7,8
 a2c:	000bb483          	ld	s1,0(s7)
 a30:	cc91                	beqz	s1,a4c <vprintf+0x1f2>
        for(; *s; s++)
 a32:	0004c583          	lbu	a1,0(s1)
 a36:	c985                	beqz	a1,a66 <vprintf+0x20c>
          putc(fd, *s);
 a38:	855a                	mv	a0,s6
 a3a:	d5fff0ef          	jal	798 <putc>
        for(; *s; s++)
 a3e:	0485                	addi	s1,s1,1
 a40:	0004c583          	lbu	a1,0(s1)
 a44:	f9f5                	bnez	a1,a38 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
 a46:	8bce                	mv	s7,s3
      state = 0;
 a48:	4981                	li	s3,0
 a4a:	bd91                	j	89e <vprintf+0x44>
          s = "(null)";
 a4c:	00000497          	auipc	s1,0x0
 a50:	4d448493          	addi	s1,s1,1236 # f20 <statistics+0x24e>
        for(; *s; s++)
 a54:	02800593          	li	a1,40
 a58:	b7c5                	j	a38 <vprintf+0x1de>
        putc(fd, '%');
 a5a:	85be                	mv	a1,a5
 a5c:	855a                	mv	a0,s6
 a5e:	d3bff0ef          	jal	798 <putc>
      state = 0;
 a62:	4981                	li	s3,0
 a64:	bd2d                	j	89e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 a66:	8bce                	mv	s7,s3
      state = 0;
 a68:	4981                	li	s3,0
 a6a:	bd15                	j	89e <vprintf+0x44>
 a6c:	6906                	ld	s2,64(sp)
 a6e:	79e2                	ld	s3,56(sp)
 a70:	7a42                	ld	s4,48(sp)
 a72:	7aa2                	ld	s5,40(sp)
 a74:	7b02                	ld	s6,32(sp)
 a76:	6be2                	ld	s7,24(sp)
 a78:	6c42                	ld	s8,16(sp)
    }
  }
}
 a7a:	60e6                	ld	ra,88(sp)
 a7c:	6446                	ld	s0,80(sp)
 a7e:	64a6                	ld	s1,72(sp)
 a80:	6125                	addi	sp,sp,96
 a82:	8082                	ret
      if(c0 == 'd'){
 a84:	06400713          	li	a4,100
 a88:	e6e789e3          	beq	a5,a4,8fa <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 a8c:	f9478693          	addi	a3,a5,-108
 a90:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 a94:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 a96:	4701                	li	a4,0
      } else if(c0 == 'u'){
 a98:	07500513          	li	a0,117
 a9c:	eaa786e3          	beq	a5,a0,948 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 aa0:	f8b60513          	addi	a0,a2,-117
 aa4:	e119                	bnez	a0,aaa <vprintf+0x250>
 aa6:	ea069de3          	bnez	a3,960 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 aaa:	f8b58513          	addi	a0,a1,-117
 aae:	e119                	bnez	a0,ab4 <vprintf+0x25a>
 ab0:	ec0715e3          	bnez	a4,97a <vprintf+0x120>
      } else if(c0 == 'x'){
 ab4:	07800513          	li	a0,120
 ab8:	eca78ee3          	beq	a5,a0,994 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 abc:	f8860613          	addi	a2,a2,-120
 ac0:	e219                	bnez	a2,ac6 <vprintf+0x26c>
 ac2:	ee0695e3          	bnez	a3,9ac <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 ac6:	f8858593          	addi	a1,a1,-120
 aca:	e199                	bnez	a1,ad0 <vprintf+0x276>
 acc:	ee071de3          	bnez	a4,9c6 <vprintf+0x16c>
      } else if(c0 == 'p'){
 ad0:	07000713          	li	a4,112
 ad4:	f0e786e3          	beq	a5,a4,9e0 <vprintf+0x186>
      } else if(c0 == 's'){
 ad8:	07300713          	li	a4,115
 adc:	f4e786e3          	beq	a5,a4,a28 <vprintf+0x1ce>
      } else if(c0 == '%'){
 ae0:	02500713          	li	a4,37
 ae4:	f6e78be3          	beq	a5,a4,a5a <vprintf+0x200>
        putc(fd, '%');
 ae8:	02500593          	li	a1,37
 aec:	855a                	mv	a0,s6
 aee:	cabff0ef          	jal	798 <putc>
        putc(fd, c0);
 af2:	85a6                	mv	a1,s1
 af4:	855a                	mv	a0,s6
 af6:	ca3ff0ef          	jal	798 <putc>
      state = 0;
 afa:	4981                	li	s3,0
 afc:	b34d                	j	89e <vprintf+0x44>

0000000000000afe <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 afe:	715d                	addi	sp,sp,-80
 b00:	ec06                	sd	ra,24(sp)
 b02:	e822                	sd	s0,16(sp)
 b04:	1000                	addi	s0,sp,32
 b06:	e010                	sd	a2,0(s0)
 b08:	e414                	sd	a3,8(s0)
 b0a:	e818                	sd	a4,16(s0)
 b0c:	ec1c                	sd	a5,24(s0)
 b0e:	03043023          	sd	a6,32(s0)
 b12:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 b16:	8622                	mv	a2,s0
 b18:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 b1c:	d3fff0ef          	jal	85a <vprintf>
}
 b20:	60e2                	ld	ra,24(sp)
 b22:	6442                	ld	s0,16(sp)
 b24:	6161                	addi	sp,sp,80
 b26:	8082                	ret

0000000000000b28 <printf>:

void
printf(const char *fmt, ...)
{
 b28:	711d                	addi	sp,sp,-96
 b2a:	ec06                	sd	ra,24(sp)
 b2c:	e822                	sd	s0,16(sp)
 b2e:	1000                	addi	s0,sp,32
 b30:	e40c                	sd	a1,8(s0)
 b32:	e810                	sd	a2,16(s0)
 b34:	ec14                	sd	a3,24(s0)
 b36:	f018                	sd	a4,32(s0)
 b38:	f41c                	sd	a5,40(s0)
 b3a:	03043823          	sd	a6,48(s0)
 b3e:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 b42:	00840613          	addi	a2,s0,8
 b46:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 b4a:	85aa                	mv	a1,a0
 b4c:	4505                	li	a0,1
 b4e:	d0dff0ef          	jal	85a <vprintf>
}
 b52:	60e2                	ld	ra,24(sp)
 b54:	6442                	ld	s0,16(sp)
 b56:	6125                	addi	sp,sp,96
 b58:	8082                	ret

0000000000000b5a <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 b5a:	1141                	addi	sp,sp,-16
 b5c:	e406                	sd	ra,8(sp)
 b5e:	e022                	sd	s0,0(sp)
 b60:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 b62:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b66:	00000797          	auipc	a5,0x0
 b6a:	49a7b783          	ld	a5,1178(a5) # 1000 <freep>
 b6e:	a039                	j	b7c <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b70:	6398                	ld	a4,0(a5)
 b72:	00e7e463          	bltu	a5,a4,b7a <free+0x20>
 b76:	00e6ea63          	bltu	a3,a4,b8a <free+0x30>
{
 b7a:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b7c:	fed7fae3          	bgeu	a5,a3,b70 <free+0x16>
 b80:	6398                	ld	a4,0(a5)
 b82:	00e6e463          	bltu	a3,a4,b8a <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b86:	fee7eae3          	bltu	a5,a4,b7a <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 b8a:	ff852583          	lw	a1,-8(a0)
 b8e:	6390                	ld	a2,0(a5)
 b90:	02059813          	slli	a6,a1,0x20
 b94:	01c85713          	srli	a4,a6,0x1c
 b98:	9736                	add	a4,a4,a3
 b9a:	02e60563          	beq	a2,a4,bc4 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 b9e:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 ba2:	4790                	lw	a2,8(a5)
 ba4:	02061593          	slli	a1,a2,0x20
 ba8:	01c5d713          	srli	a4,a1,0x1c
 bac:	973e                	add	a4,a4,a5
 bae:	02e68263          	beq	a3,a4,bd2 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 bb2:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 bb4:	00000717          	auipc	a4,0x0
 bb8:	44f73623          	sd	a5,1100(a4) # 1000 <freep>
}
 bbc:	60a2                	ld	ra,8(sp)
 bbe:	6402                	ld	s0,0(sp)
 bc0:	0141                	addi	sp,sp,16
 bc2:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 bc4:	4618                	lw	a4,8(a2)
 bc6:	9f2d                	addw	a4,a4,a1
 bc8:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 bcc:	6398                	ld	a4,0(a5)
 bce:	6310                	ld	a2,0(a4)
 bd0:	b7f9                	j	b9e <free+0x44>
    p->s.size += bp->s.size;
 bd2:	ff852703          	lw	a4,-8(a0)
 bd6:	9f31                	addw	a4,a4,a2
 bd8:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 bda:	ff053683          	ld	a3,-16(a0)
 bde:	bfd1                	j	bb2 <free+0x58>

0000000000000be0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 be0:	7139                	addi	sp,sp,-64
 be2:	fc06                	sd	ra,56(sp)
 be4:	f822                	sd	s0,48(sp)
 be6:	f04a                	sd	s2,32(sp)
 be8:	ec4e                	sd	s3,24(sp)
 bea:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 bec:	02051993          	slli	s3,a0,0x20
 bf0:	0209d993          	srli	s3,s3,0x20
 bf4:	09bd                	addi	s3,s3,15
 bf6:	0049d993          	srli	s3,s3,0x4
 bfa:	2985                	addiw	s3,s3,1
 bfc:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 bfe:	00000517          	auipc	a0,0x0
 c02:	40253503          	ld	a0,1026(a0) # 1000 <freep>
 c06:	c905                	beqz	a0,c36 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c08:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 c0a:	4798                	lw	a4,8(a5)
 c0c:	09377663          	bgeu	a4,s3,c98 <malloc+0xb8>
 c10:	f426                	sd	s1,40(sp)
 c12:	e852                	sd	s4,16(sp)
 c14:	e456                	sd	s5,8(sp)
 c16:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 c18:	8a4e                	mv	s4,s3
 c1a:	6705                	lui	a4,0x1
 c1c:	00e9f363          	bgeu	s3,a4,c22 <malloc+0x42>
 c20:	6a05                	lui	s4,0x1
 c22:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 c26:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 c2a:	00000497          	auipc	s1,0x0
 c2e:	3d648493          	addi	s1,s1,982 # 1000 <freep>
  if(p == (char*)-1)
 c32:	5afd                	li	s5,-1
 c34:	a83d                	j	c72 <malloc+0x92>
 c36:	f426                	sd	s1,40(sp)
 c38:	e852                	sd	s4,16(sp)
 c3a:	e456                	sd	s5,8(sp)
 c3c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 c3e:	00001797          	auipc	a5,0x1
 c42:	3d278793          	addi	a5,a5,978 # 2010 <base>
 c46:	00000717          	auipc	a4,0x0
 c4a:	3af73d23          	sd	a5,954(a4) # 1000 <freep>
 c4e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 c50:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 c54:	b7d1                	j	c18 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 c56:	6398                	ld	a4,0(a5)
 c58:	e118                	sd	a4,0(a0)
 c5a:	a899                	j	cb0 <malloc+0xd0>
  hp->s.size = nu;
 c5c:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 c60:	0541                	addi	a0,a0,16
 c62:	ef9ff0ef          	jal	b5a <free>
  return freep;
 c66:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 c68:	c125                	beqz	a0,cc8 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c6a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 c6c:	4798                	lw	a4,8(a5)
 c6e:	03277163          	bgeu	a4,s2,c90 <malloc+0xb0>
    if(p == freep)
 c72:	6098                	ld	a4,0(s1)
 c74:	853e                	mv	a0,a5
 c76:	fef71ae3          	bne	a4,a5,c6a <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 c7a:	8552                	mv	a0,s4
 c7c:	b05ff0ef          	jal	780 <sbrk>
  if(p == (char*)-1)
 c80:	fd551ee3          	bne	a0,s5,c5c <malloc+0x7c>
        return 0;
 c84:	4501                	li	a0,0
 c86:	74a2                	ld	s1,40(sp)
 c88:	6a42                	ld	s4,16(sp)
 c8a:	6aa2                	ld	s5,8(sp)
 c8c:	6b02                	ld	s6,0(sp)
 c8e:	a03d                	j	cbc <malloc+0xdc>
 c90:	74a2                	ld	s1,40(sp)
 c92:	6a42                	ld	s4,16(sp)
 c94:	6aa2                	ld	s5,8(sp)
 c96:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 c98:	fae90fe3          	beq	s2,a4,c56 <malloc+0x76>
        p->s.size -= nunits;
 c9c:	4137073b          	subw	a4,a4,s3
 ca0:	c798                	sw	a4,8(a5)
        p += p->s.size;
 ca2:	02071693          	slli	a3,a4,0x20
 ca6:	01c6d713          	srli	a4,a3,0x1c
 caa:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 cac:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 cb0:	00000717          	auipc	a4,0x0
 cb4:	34a73823          	sd	a0,848(a4) # 1000 <freep>
      return (void*)(p + 1);
 cb8:	01078513          	addi	a0,a5,16
  }
}
 cbc:	70e2                	ld	ra,56(sp)
 cbe:	7442                	ld	s0,48(sp)
 cc0:	7902                	ld	s2,32(sp)
 cc2:	69e2                	ld	s3,24(sp)
 cc4:	6121                	addi	sp,sp,64
 cc6:	8082                	ret
 cc8:	74a2                	ld	s1,40(sp)
 cca:	6a42                	ld	s4,16(sp)
 ccc:	6aa2                	ld	s5,8(sp)
 cce:	6b02                	ld	s6,0(sp)
 cd0:	b7f5                	j	cbc <malloc+0xdc>

0000000000000cd2 <statistics>:
#include "kernel/fcntl.h"
#include "user/user.h"

int
statistics(void *buf, int sz)
{
 cd2:	7179                	addi	sp,sp,-48
 cd4:	f406                	sd	ra,40(sp)
 cd6:	f022                	sd	s0,32(sp)
 cd8:	ec26                	sd	s1,24(sp)
 cda:	e84a                	sd	s2,16(sp)
 cdc:	e44e                	sd	s3,8(sp)
 cde:	e052                	sd	s4,0(sp)
 ce0:	1800                	addi	s0,sp,48
 ce2:	8a2a                	mv	s4,a0
 ce4:	892e                	mv	s2,a1
  int fd, i, n;
  
  fd = open("statistics", O_RDONLY);
 ce6:	4581                	li	a1,0
 ce8:	00000517          	auipc	a0,0x0
 cec:	24050513          	addi	a0,a0,576 # f28 <statistics+0x256>
 cf0:	a49ff0ef          	jal	738 <open>
  if(fd < 0) {
 cf4:	02054e63          	bltz	a0,d30 <statistics+0x5e>
 cf8:	89aa                	mv	s3,a0
      fprintf(2, "stats: open failed\n");
      exit(1);
  }
  for (i = 0; i < sz; ) {
 cfa:	4481                	li	s1,0
 cfc:	01205e63          	blez	s2,d18 <statistics+0x46>
    if ((n = read(fd, buf+i, sz-i)) < 0) {
 d00:	4099063b          	subw	a2,s2,s1
 d04:	009a05b3          	add	a1,s4,s1
 d08:	854e                	mv	a0,s3
 d0a:	a07ff0ef          	jal	710 <read>
 d0e:	00054563          	bltz	a0,d18 <statistics+0x46>
      break;
    }
    i += n;
 d12:	9ca9                	addw	s1,s1,a0
  for (i = 0; i < sz; ) {
 d14:	ff24c6e3          	blt	s1,s2,d00 <statistics+0x2e>
  }
  close(fd);
 d18:	854e                	mv	a0,s3
 d1a:	a07ff0ef          	jal	720 <close>
  return i;
}
 d1e:	8526                	mv	a0,s1
 d20:	70a2                	ld	ra,40(sp)
 d22:	7402                	ld	s0,32(sp)
 d24:	64e2                	ld	s1,24(sp)
 d26:	6942                	ld	s2,16(sp)
 d28:	69a2                	ld	s3,8(sp)
 d2a:	6a02                	ld	s4,0(sp)
 d2c:	6145                	addi	sp,sp,48
 d2e:	8082                	ret
      fprintf(2, "stats: open failed\n");
 d30:	00000597          	auipc	a1,0x0
 d34:	20858593          	addi	a1,a1,520 # f38 <statistics+0x266>
 d38:	4509                	li	a0,2
 d3a:	dc5ff0ef          	jal	afe <fprintf>
      exit(1);
 d3e:	4505                	li	a0,1
 d40:	9b9ff0ef          	jal	6f8 <exit>
