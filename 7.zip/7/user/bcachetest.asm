
user/_bcachetest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <createfile>:
  exit(0);
}

void
createfile(char *file, int nblock)
{
       0:	bc010113          	addi	sp,sp,-1088
       4:	42113c23          	sd	ra,1080(sp)
       8:	42813823          	sd	s0,1072(sp)
       c:	42913423          	sd	s1,1064(sp)
      10:	43213023          	sd	s2,1056(sp)
      14:	41313c23          	sd	s3,1048(sp)
      18:	41413823          	sd	s4,1040(sp)
      1c:	41513423          	sd	s5,1032(sp)
      20:	41613023          	sd	s6,1024(sp)
      24:	44010413          	addi	s0,sp,1088
      28:	8b2a                	mv	s6,a0
      2a:	8a2e                	mv	s4,a1
  int fd;
  char buf[BSIZE];
  int i;
  
  fd = open(file, O_CREATE | O_RDWR);
      2c:	20200593          	li	a1,514
      30:	3a7000ef          	jal	bd6 <open>
  if(fd < 0){
      34:	04054a63          	bltz	a0,88 <createfile+0x88>
      38:	89aa                	mv	s3,a0
    printf("createfile %s failed\n", file);
    exit(-1);
  }
  for(i = 0; i < nblock; i++) {
      3a:	4481                	li	s1,0
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)) {
      3c:	bc040a93          	addi	s5,s0,-1088
      40:	40000913          	li	s2,1024
  for(i = 0; i < nblock; i++) {
      44:	01405c63          	blez	s4,5c <createfile+0x5c>
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)) {
      48:	864a                	mv	a2,s2
      4a:	85d6                	mv	a1,s5
      4c:	854e                	mv	a0,s3
      4e:	369000ef          	jal	bb6 <write>
      52:	05251563          	bne	a0,s2,9c <createfile+0x9c>
  for(i = 0; i < nblock; i++) {
      56:	2485                	addiw	s1,s1,1
      58:	fe9a18e3          	bne	s4,s1,48 <createfile+0x48>
      printf("write %s failed\n", file);
      exit(-1);
    }
  }
  close(fd);
      5c:	854e                	mv	a0,s3
      5e:	361000ef          	jal	bbe <close>
}
      62:	43813083          	ld	ra,1080(sp)
      66:	43013403          	ld	s0,1072(sp)
      6a:	42813483          	ld	s1,1064(sp)
      6e:	42013903          	ld	s2,1056(sp)
      72:	41813983          	ld	s3,1048(sp)
      76:	41013a03          	ld	s4,1040(sp)
      7a:	40813a83          	ld	s5,1032(sp)
      7e:	40013b03          	ld	s6,1024(sp)
      82:	44010113          	addi	sp,sp,1088
      86:	8082                	ret
    printf("createfile %s failed\n", file);
      88:	85da                	mv	a1,s6
      8a:	00001517          	auipc	a0,0x1
      8e:	16650513          	addi	a0,a0,358 # 11f0 <statistics+0x80>
      92:	735000ef          	jal	fc6 <printf>
    exit(-1);
      96:	557d                	li	a0,-1
      98:	2ff000ef          	jal	b96 <exit>
      printf("write %s failed\n", file);
      9c:	85da                	mv	a1,s6
      9e:	00001517          	auipc	a0,0x1
      a2:	17250513          	addi	a0,a0,370 # 1210 <statistics+0xa0>
      a6:	721000ef          	jal	fc6 <printf>
      exit(-1);
      aa:	557d                	li	a0,-1
      ac:	2eb000ef          	jal	b96 <exit>

00000000000000b0 <readfile>:

void
readfile(char *file, int nbytes, int inc)
{
      b0:	bc010113          	addi	sp,sp,-1088
      b4:	42113c23          	sd	ra,1080(sp)
      b8:	42813823          	sd	s0,1072(sp)
      bc:	42913423          	sd	s1,1064(sp)
      c0:	43213023          	sd	s2,1056(sp)
      c4:	41313c23          	sd	s3,1048(sp)
      c8:	41413823          	sd	s4,1040(sp)
      cc:	41513423          	sd	s5,1032(sp)
      d0:	41613023          	sd	s6,1024(sp)
      d4:	44010413          	addi	s0,sp,1088
  char buf[BSIZE];
  int fd;
  int i;

  if(inc > BSIZE) {
      d8:	40000793          	li	a5,1024
      dc:	06c7c163          	blt	a5,a2,13e <readfile+0x8e>
      e0:	8b2a                	mv	s6,a0
      e2:	8a2e                	mv	s4,a1
      e4:	84b2                	mv	s1,a2
    printf("readfile: inc too large\n");
    exit(-1);
  }
  if ((fd = open(file, O_RDONLY)) < 0) {
      e6:	4581                	li	a1,0
      e8:	2ef000ef          	jal	bd6 <open>
      ec:	89aa                	mv	s3,a0
      ee:	06054163          	bltz	a0,150 <readfile+0xa0>
    printf("readfile open %s failed\n", file);
    exit(-1);
  }
  for (i = 0; i < nbytes; i += inc) {
      f2:	4901                	li	s2,0
    if(read(fd, buf, inc) != inc) {
      f4:	bc040a93          	addi	s5,s0,-1088
  for (i = 0; i < nbytes; i += inc) {
      f8:	01405d63          	blez	s4,112 <readfile+0x62>
    if(read(fd, buf, inc) != inc) {
      fc:	8626                	mv	a2,s1
      fe:	85d6                	mv	a1,s5
     100:	854e                	mv	a0,s3
     102:	2ad000ef          	jal	bae <read>
     106:	04951f63          	bne	a0,s1,164 <readfile+0xb4>
  for (i = 0; i < nbytes; i += inc) {
     10a:	0124893b          	addw	s2,s1,s2
     10e:	ff4947e3          	blt	s2,s4,fc <readfile+0x4c>
      printf("read %s failed for block %d (%d)\n", file, i, nbytes);
      exit(-1);
    }
  }
  close(fd);
     112:	854e                	mv	a0,s3
     114:	2ab000ef          	jal	bbe <close>
}
     118:	43813083          	ld	ra,1080(sp)
     11c:	43013403          	ld	s0,1072(sp)
     120:	42813483          	ld	s1,1064(sp)
     124:	42013903          	ld	s2,1056(sp)
     128:	41813983          	ld	s3,1048(sp)
     12c:	41013a03          	ld	s4,1040(sp)
     130:	40813a83          	ld	s5,1032(sp)
     134:	40013b03          	ld	s6,1024(sp)
     138:	44010113          	addi	sp,sp,1088
     13c:	8082                	ret
    printf("readfile: inc too large\n");
     13e:	00001517          	auipc	a0,0x1
     142:	0ea50513          	addi	a0,a0,234 # 1228 <statistics+0xb8>
     146:	681000ef          	jal	fc6 <printf>
    exit(-1);
     14a:	557d                	li	a0,-1
     14c:	24b000ef          	jal	b96 <exit>
    printf("readfile open %s failed\n", file);
     150:	85da                	mv	a1,s6
     152:	00001517          	auipc	a0,0x1
     156:	0f650513          	addi	a0,a0,246 # 1248 <statistics+0xd8>
     15a:	66d000ef          	jal	fc6 <printf>
    exit(-1);
     15e:	557d                	li	a0,-1
     160:	237000ef          	jal	b96 <exit>
      printf("read %s failed for block %d (%d)\n", file, i, nbytes);
     164:	86d2                	mv	a3,s4
     166:	864a                	mv	a2,s2
     168:	85da                	mv	a1,s6
     16a:	00001517          	auipc	a0,0x1
     16e:	0fe50513          	addi	a0,a0,254 # 1268 <statistics+0xf8>
     172:	655000ef          	jal	fc6 <printf>
      exit(-1);
     176:	557d                	li	a0,-1
     178:	21f000ef          	jal	b96 <exit>

000000000000017c <ntas>:

int ntas(int print)
{
     17c:	1101                	addi	sp,sp,-32
     17e:	ec06                	sd	ra,24(sp)
     180:	e822                	sd	s0,16(sp)
     182:	e426                	sd	s1,8(sp)
     184:	e04a                	sd	s2,0(sp)
     186:	1000                	addi	s0,sp,32
     188:	892a                	mv	s2,a0
  int n;
  char *c;

  if (statistics(buf, SZ) <= 0) {
     18a:	6585                	lui	a1,0x1
     18c:	00003517          	auipc	a0,0x3
     190:	68450513          	addi	a0,a0,1668 # 3810 <buf>
     194:	7dd000ef          	jal	1170 <statistics>
     198:	02a05763          	blez	a0,1c6 <ntas+0x4a>
    fprintf(2, "ntas: no stats\n");
  }
  c = strchr(buf, '=');
     19c:	03d00593          	li	a1,61
     1a0:	00003517          	auipc	a0,0x3
     1a4:	67050513          	addi	a0,a0,1648 # 3810 <buf>
     1a8:	017000ef          	jal	9be <strchr>
  n = atoi(c+2);
     1ac:	0509                	addi	a0,a0,2
     1ae:	0eb000ef          	jal	a98 <atoi>
     1b2:	84aa                	mv	s1,a0
  if(print)
     1b4:	02091163          	bnez	s2,1d6 <ntas+0x5a>
    printf("%s", buf);
  return n;
}
     1b8:	8526                	mv	a0,s1
     1ba:	60e2                	ld	ra,24(sp)
     1bc:	6442                	ld	s0,16(sp)
     1be:	64a2                	ld	s1,8(sp)
     1c0:	6902                	ld	s2,0(sp)
     1c2:	6105                	addi	sp,sp,32
     1c4:	8082                	ret
    fprintf(2, "ntas: no stats\n");
     1c6:	00001597          	auipc	a1,0x1
     1ca:	0ca58593          	addi	a1,a1,202 # 1290 <statistics+0x120>
     1ce:	4509                	li	a0,2
     1d0:	5cd000ef          	jal	f9c <fprintf>
     1d4:	b7e1                	j	19c <ntas+0x20>
    printf("%s", buf);
     1d6:	00003597          	auipc	a1,0x3
     1da:	63a58593          	addi	a1,a1,1594 # 3810 <buf>
     1de:	00001517          	auipc	a0,0x1
     1e2:	0c250513          	addi	a0,a0,194 # 12a0 <statistics+0x130>
     1e6:	5e1000ef          	jal	fc6 <printf>
     1ea:	b7f9                	j	1b8 <ntas+0x3c>

00000000000001ec <test0>:

// Test reading small files concurrently
void
test0()
{
     1ec:	711d                	addi	sp,sp,-96
     1ee:	ec86                	sd	ra,88(sp)
     1f0:	e8a2                	sd	s0,80(sp)
     1f2:	e4a6                	sd	s1,72(sp)
     1f4:	e0ca                	sd	s2,64(sp)
     1f6:	fc4e                	sd	s3,56(sp)
     1f8:	f852                	sd	s4,48(sp)
     1fa:	f456                	sd	s5,40(sp)
     1fc:	f05a                	sd	s6,32(sp)
     1fe:	1080                	addi	s0,sp,96
  char file[2];
  char dir[2];
  enum { N = 10, NCHILD = 3 };
  int m, n;

  dir[0] = '0';
     200:	03000793          	li	a5,48
     204:	faf40823          	sb	a5,-80(s0)
  dir[1] = '\0';
     208:	fa0408a3          	sb	zero,-79(s0)
  file[0] = 'F';
     20c:	04600793          	li	a5,70
     210:	faf40c23          	sb	a5,-72(s0)
  file[1] = '\0';
     214:	fa040ca3          	sb	zero,-71(s0)

  printf("start test0\n");
     218:	00001517          	auipc	a0,0x1
     21c:	09050513          	addi	a0,a0,144 # 12a8 <statistics+0x138>
     220:	5a7000ef          	jal	fc6 <printf>
     224:	03000493          	li	s1,48
  for(int i = 0; i < NCHILD; i++){
    dir[0] = '0' + i;
    mkdir(dir);
     228:	fb040913          	addi	s2,s0,-80
    if (chdir(dir) < 0) {
      printf("chdir failed\n");
      exit(1);
    }
    unlink(file);
     22c:	fb840993          	addi	s3,s0,-72
    createfile(file, N);
     230:	4b29                	li	s6,10
    if (chdir("..") < 0) {
     232:	00001a97          	auipc	s5,0x1
     236:	096a8a93          	addi	s5,s5,150 # 12c8 <statistics+0x158>
  for(int i = 0; i < NCHILD; i++){
     23a:	03300a13          	li	s4,51
    dir[0] = '0' + i;
     23e:	fa940823          	sb	s1,-80(s0)
    mkdir(dir);
     242:	854a                	mv	a0,s2
     244:	1bb000ef          	jal	bfe <mkdir>
    if (chdir(dir) < 0) {
     248:	854a                	mv	a0,s2
     24a:	1bd000ef          	jal	c06 <chdir>
     24e:	0a054363          	bltz	a0,2f4 <test0+0x108>
    unlink(file);
     252:	854e                	mv	a0,s3
     254:	193000ef          	jal	be6 <unlink>
    createfile(file, N);
     258:	85da                	mv	a1,s6
     25a:	854e                	mv	a0,s3
     25c:	da5ff0ef          	jal	0 <createfile>
    if (chdir("..") < 0) {
     260:	8556                	mv	a0,s5
     262:	1a5000ef          	jal	c06 <chdir>
     266:	0a054063          	bltz	a0,306 <test0+0x11a>
  for(int i = 0; i < NCHILD; i++){
     26a:	2485                	addiw	s1,s1,1
     26c:	0ff4f493          	zext.b	s1,s1
     270:	fd4497e3          	bne	s1,s4,23e <test0+0x52>
      printf("chdir failed\n");
      exit(1);
    }
  }
  m = ntas(0);
     274:	4501                	li	a0,0
     276:	f07ff0ef          	jal	17c <ntas>
     27a:	892a                	mv	s2,a0
     27c:	03000493          	li	s1,48
  for(int i = 0; i < NCHILD; i++){
     280:	03300993          	li	s3,51
    dir[0] = '0' + i;
     284:	fa940823          	sb	s1,-80(s0)
    int pid = fork();
     288:	107000ef          	jal	b8e <fork>
    if(pid < 0){
     28c:	08054663          	bltz	a0,318 <test0+0x12c>
      printf("fork failed");
      exit(-1);
    }
    if(pid == 0){
     290:	cd49                	beqz	a0,32a <test0+0x13e>
  for(int i = 0; i < NCHILD; i++){
     292:	2485                	addiw	s1,s1,1
     294:	0ff4f493          	zext.b	s1,s1
     298:	ff3496e3          	bne	s1,s3,284 <test0+0x98>

      exit(0);
    }
  }
  
  int status = 0;
     29c:	fa042623          	sw	zero,-84(s0)
     2a0:	448d                	li	s1,3
  for(int i = 0; i < NCHILD; i++){
    wait(&status);
     2a2:	fac40993          	addi	s3,s0,-84
     2a6:	854e                	mv	a0,s3
     2a8:	0f7000ef          	jal	b9e <wait>
    if (status != 0) {
     2ac:	fac42783          	lw	a5,-84(s0)
     2b0:	e7dd                	bnez	a5,35e <test0+0x172>
  for(int i = 0; i < NCHILD; i++){
     2b2:	34fd                	addiw	s1,s1,-1
     2b4:	f8ed                	bnez	s1,2a6 <test0+0xba>
      printf("FAIL: a child failed\n");
      exit(1);
    }  
  }
  
  printf("test0 results:\n");
     2b6:	00001517          	auipc	a0,0x1
     2ba:	04250513          	addi	a0,a0,66 # 12f8 <statistics+0x188>
     2be:	509000ef          	jal	fc6 <printf>
  n = ntas(1);
     2c2:	4505                	li	a0,1
     2c4:	eb9ff0ef          	jal	17c <ntas>
  if (n-m < 500)
     2c8:	4125053b          	subw	a0,a0,s2
     2cc:	1f300793          	li	a5,499
     2d0:	0aa7c063          	blt	a5,a0,370 <test0+0x184>
    printf("test0: OK\n");
     2d4:	00001517          	auipc	a0,0x1
     2d8:	03450513          	addi	a0,a0,52 # 1308 <statistics+0x198>
     2dc:	4eb000ef          	jal	fc6 <printf>
  else
    printf("test0: FAIL\n");
}
     2e0:	60e6                	ld	ra,88(sp)
     2e2:	6446                	ld	s0,80(sp)
     2e4:	64a6                	ld	s1,72(sp)
     2e6:	6906                	ld	s2,64(sp)
     2e8:	79e2                	ld	s3,56(sp)
     2ea:	7a42                	ld	s4,48(sp)
     2ec:	7aa2                	ld	s5,40(sp)
     2ee:	7b02                	ld	s6,32(sp)
     2f0:	6125                	addi	sp,sp,96
     2f2:	8082                	ret
      printf("chdir failed\n");
     2f4:	00001517          	auipc	a0,0x1
     2f8:	fc450513          	addi	a0,a0,-60 # 12b8 <statistics+0x148>
     2fc:	4cb000ef          	jal	fc6 <printf>
      exit(1);
     300:	4505                	li	a0,1
     302:	095000ef          	jal	b96 <exit>
      printf("chdir failed\n");
     306:	00001517          	auipc	a0,0x1
     30a:	fb250513          	addi	a0,a0,-78 # 12b8 <statistics+0x148>
     30e:	4b9000ef          	jal	fc6 <printf>
      exit(1);
     312:	4505                	li	a0,1
     314:	083000ef          	jal	b96 <exit>
      printf("fork failed");
     318:	00001517          	auipc	a0,0x1
     31c:	fb850513          	addi	a0,a0,-72 # 12d0 <statistics+0x160>
     320:	4a7000ef          	jal	fc6 <printf>
      exit(-1);
     324:	557d                	li	a0,-1
     326:	071000ef          	jal	b96 <exit>
      if (chdir(dir) < 0) {
     32a:	fb040513          	addi	a0,s0,-80
     32e:	0d9000ef          	jal	c06 <chdir>
     332:	00054d63          	bltz	a0,34c <test0+0x160>
      readfile(file, N*BSIZE, 1);
     336:	4605                	li	a2,1
     338:	658d                	lui	a1,0x3
     33a:	80058593          	addi	a1,a1,-2048 # 2800 <junk.0+0x7f0>
     33e:	fb840513          	addi	a0,s0,-72
     342:	d6fff0ef          	jal	b0 <readfile>
      exit(0);
     346:	4501                	li	a0,0
     348:	04f000ef          	jal	b96 <exit>
        printf("chdir failed\n");
     34c:	00001517          	auipc	a0,0x1
     350:	f6c50513          	addi	a0,a0,-148 # 12b8 <statistics+0x148>
     354:	473000ef          	jal	fc6 <printf>
        exit(1);
     358:	4505                	li	a0,1
     35a:	03d000ef          	jal	b96 <exit>
      printf("FAIL: a child failed\n");
     35e:	00001517          	auipc	a0,0x1
     362:	f8250513          	addi	a0,a0,-126 # 12e0 <statistics+0x170>
     366:	461000ef          	jal	fc6 <printf>
      exit(1);
     36a:	4505                	li	a0,1
     36c:	02b000ef          	jal	b96 <exit>
    printf("test0: FAIL\n");
     370:	00001517          	auipc	a0,0x1
     374:	fa850513          	addi	a0,a0,-88 # 1318 <statistics+0x1a8>
     378:	44f000ef          	jal	fc6 <printf>
}
     37c:	b795                	j	2e0 <test0+0xf4>

000000000000037e <test1>:

// Test bcache evictions by reading a large file concurrently
void test1()
{
     37e:	7139                	addi	sp,sp,-64
     380:	fc06                	sd	ra,56(sp)
     382:	f822                	sd	s0,48(sp)
     384:	f426                	sd	s1,40(sp)
     386:	f04a                	sd	s2,32(sp)
     388:	ec4e                	sd	s3,24(sp)
     38a:	e852                	sd	s4,16(sp)
     38c:	0080                	addi	s0,sp,64
  char file[3];
  enum { N = 200, BIG=100, NCHILD=2 };
  
  printf("start test1\n");
     38e:	00001517          	auipc	a0,0x1
     392:	f9a50513          	addi	a0,a0,-102 # 1328 <statistics+0x1b8>
     396:	431000ef          	jal	fc6 <printf>
  file[0] = 'B';
     39a:	04200793          	li	a5,66
     39e:	fcf40423          	sb	a5,-56(s0)
  file[2] = '\0';
     3a2:	fc040523          	sb	zero,-54(s0)
  for(int i = 0; i < NCHILD; i++){
     3a6:	4481                	li	s1,0
    file[1] = '0' + i;
    unlink(file);
     3a8:	fc840913          	addi	s2,s0,-56
    if (i == 0) {
      createfile(file, BIG);
    } else {
      createfile(file, 1);
     3ac:	4a05                	li	s4,1
  for(int i = 0; i < NCHILD; i++){
     3ae:	4989                	li	s3,2
    file[1] = '0' + i;
     3b0:	0304879b          	addiw	a5,s1,48
     3b4:	fcf404a3          	sb	a5,-55(s0)
    unlink(file);
     3b8:	854a                	mv	a0,s2
     3ba:	02d000ef          	jal	be6 <unlink>
    if (i == 0) {
     3be:	c8a5                	beqz	s1,42e <test1+0xb0>
      createfile(file, 1);
     3c0:	85d2                	mv	a1,s4
     3c2:	854a                	mv	a0,s2
     3c4:	c3dff0ef          	jal	0 <createfile>
  for(int i = 0; i < NCHILD; i++){
     3c8:	2485                	addiw	s1,s1,1
     3ca:	ff3493e3          	bne	s1,s3,3b0 <test1+0x32>
    }
  }
  for(int i = 0; i < NCHILD; i++){
    file[1] = '0' + i;
     3ce:	03000793          	li	a5,48
     3d2:	fcf404a3          	sb	a5,-55(s0)
    int pid = fork();
     3d6:	7b8000ef          	jal	b8e <fork>
    if(pid < 0){
     3da:	06054263          	bltz	a0,43e <test1+0xc0>
      printf("fork failed");
      exit(-1);
    }
    if(pid == 0){
     3de:	c92d                	beqz	a0,450 <test1+0xd2>
    file[1] = '0' + i;
     3e0:	03100793          	li	a5,49
     3e4:	fcf404a3          	sb	a5,-55(s0)
    int pid = fork();
     3e8:	7a6000ef          	jal	b8e <fork>
    if(pid < 0){
     3ec:	04054963          	bltz	a0,43e <test1+0xc0>
    if(pid == 0){
     3f0:	c549                	beqz	a0,47a <test1+0xfc>
      }
      exit(0);
    }
  }

  int status = 0;
     3f2:	fc042223          	sw	zero,-60(s0)
  for(int i = 0; i < NCHILD; i++){
    wait(&status);
     3f6:	fc440513          	addi	a0,s0,-60
     3fa:	7a4000ef          	jal	b9e <wait>
    if (status != 0) {
     3fe:	fc442783          	lw	a5,-60(s0)
     402:	e3d5                	bnez	a5,4a6 <test1+0x128>
    wait(&status);
     404:	fc440513          	addi	a0,s0,-60
     408:	796000ef          	jal	b9e <wait>
    if (status != 0) {
     40c:	fc442783          	lw	a5,-60(s0)
     410:	ebd9                	bnez	a5,4a6 <test1+0x128>
      printf("FAIL: a child failed\n");
      exit(1);
    }  
  }

  printf("\ntest1 OK\n");
     412:	00001517          	auipc	a0,0x1
     416:	f2650513          	addi	a0,a0,-218 # 1338 <statistics+0x1c8>
     41a:	3ad000ef          	jal	fc6 <printf>
}
     41e:	70e2                	ld	ra,56(sp)
     420:	7442                	ld	s0,48(sp)
     422:	74a2                	ld	s1,40(sp)
     424:	7902                	ld	s2,32(sp)
     426:	69e2                	ld	s3,24(sp)
     428:	6a42                	ld	s4,16(sp)
     42a:	6121                	addi	sp,sp,64
     42c:	8082                	ret
      createfile(file, BIG);
     42e:	06400593          	li	a1,100
     432:	fc840513          	addi	a0,s0,-56
     436:	bcbff0ef          	jal	0 <createfile>
  for(int i = 0; i < NCHILD; i++){
     43a:	2485                	addiw	s1,s1,1
     43c:	bf95                	j	3b0 <test1+0x32>
      printf("fork failed");
     43e:	00001517          	auipc	a0,0x1
     442:	e9250513          	addi	a0,a0,-366 # 12d0 <statistics+0x160>
     446:	381000ef          	jal	fc6 <printf>
      exit(-1);
     44a:	557d                	li	a0,-1
     44c:	74a000ef          	jal	b96 <exit>
    if(pid == 0){
     450:	0c800493          	li	s1,200
          readfile(file, BIG*BSIZE, BSIZE);
     454:	fc840a13          	addi	s4,s0,-56
     458:	40000993          	li	s3,1024
     45c:	6965                	lui	s2,0x19
     45e:	864e                	mv	a2,s3
     460:	85ca                	mv	a1,s2
     462:	8552                	mv	a0,s4
     464:	c4dff0ef          	jal	b0 <readfile>
        for (i = 0; i < N; i++) {
     468:	34fd                	addiw	s1,s1,-1
     46a:	f8f5                	bnez	s1,45e <test1+0xe0>
        unlink(file);
     46c:	fc840513          	addi	a0,s0,-56
     470:	776000ef          	jal	be6 <unlink>
        exit(0);
     474:	4501                	li	a0,0
     476:	720000ef          	jal	b96 <exit>
     47a:	6485                	lui	s1,0x1
     47c:	fa048493          	addi	s1,s1,-96 # fa0 <fprintf+0x4>
          readfile(file, 1, BSIZE);
     480:	fc840a13          	addi	s4,s0,-56
     484:	40000993          	li	s3,1024
     488:	4905                	li	s2,1
     48a:	864e                	mv	a2,s3
     48c:	85ca                	mv	a1,s2
     48e:	8552                	mv	a0,s4
     490:	c21ff0ef          	jal	b0 <readfile>
        for (i = 0; i < N*20; i++) {
     494:	34fd                	addiw	s1,s1,-1
     496:	f8f5                	bnez	s1,48a <test1+0x10c>
        unlink(file);
     498:	fc840513          	addi	a0,s0,-56
     49c:	74a000ef          	jal	be6 <unlink>
      exit(0);
     4a0:	4501                	li	a0,0
     4a2:	6f4000ef          	jal	b96 <exit>
      printf("FAIL: a child failed\n");
     4a6:	00001517          	auipc	a0,0x1
     4aa:	e3a50513          	addi	a0,a0,-454 # 12e0 <statistics+0x170>
     4ae:	319000ef          	jal	fc6 <printf>
      exit(1);
     4b2:	4505                	li	a0,1
     4b4:	6e2000ef          	jal	b96 <exit>

00000000000004b8 <test2>:
//
// test concurrent creates.
//
void
test2()
{
     4b8:	7175                	addi	sp,sp,-144
     4ba:	e506                	sd	ra,136(sp)
     4bc:	e122                	sd	s0,128(sp)
     4be:	fca6                	sd	s1,120(sp)
     4c0:	f8ca                	sd	s2,112(sp)
     4c2:	f4ce                	sd	s3,104(sp)
     4c4:	f0d2                	sd	s4,96(sp)
     4c6:	ecd6                	sd	s5,88(sp)
     4c8:	e8da                	sd	s6,80(sp)
     4ca:	0900                	addi	s0,sp,144
  int nc = 4;
  char file[16];

  printf("start test2\n");
     4cc:	00001517          	auipc	a0,0x1
     4d0:	e7c50513          	addi	a0,a0,-388 # 1348 <statistics+0x1d8>
     4d4:	2f3000ef          	jal	fc6 <printf>
  
  mkdir("d2");
     4d8:	00001517          	auipc	a0,0x1
     4dc:	e8050513          	addi	a0,a0,-384 # 1358 <statistics+0x1e8>
     4e0:	71e000ef          	jal	bfe <mkdir>

  file[0] = 'd';
     4e4:	06400793          	li	a5,100
     4e8:	f8f40023          	sb	a5,-128(s0)
  file[1] = '2';
     4ec:	03200793          	li	a5,50
     4f0:	f8f400a3          	sb	a5,-127(s0)
  file[2] = '/';
     4f4:	02f00793          	li	a5,47
     4f8:	f8f40123          	sb	a5,-126(s0)
     4fc:	03000913          	li	s2,48
{
     500:	06100b13          	li	s6,97
  for(int i = 0; i < 50; i++){
    for(int ci = 0; ci < nc; ci++){
      file[3] = 'a' + ci;
      file[4] = '0' + i;
      file[5] = '\0';
      unlink(file);
     504:	f8040a13          	addi	s4,s0,-128
    for(int ci = 0; ci < nc; ci++){
     508:	06500993          	li	s3,101
  for(int i = 0; i < 50; i++){
     50c:	06200a93          	li	s5,98
{
     510:	84da                	mv	s1,s6
      file[3] = 'a' + ci;
     512:	f89401a3          	sb	s1,-125(s0)
      file[4] = '0' + i;
     516:	f9240223          	sb	s2,-124(s0)
      file[5] = '\0';
     51a:	f80402a3          	sb	zero,-123(s0)
      unlink(file);
     51e:	8552                	mv	a0,s4
     520:	6c6000ef          	jal	be6 <unlink>
    for(int ci = 0; ci < nc; ci++){
     524:	2485                	addiw	s1,s1,1
     526:	0ff4f493          	zext.b	s1,s1
     52a:	ff3494e3          	bne	s1,s3,512 <test2+0x5a>
  for(int i = 0; i < 50; i++){
     52e:	2905                	addiw	s2,s2,1 # 19001 <base+0x147f1>
     530:	0ff97913          	zext.b	s2,s2
     534:	fd591ee3          	bne	s2,s5,510 <test2+0x58>
    }
  }

  int pids[nc];
  for(int ci = 0; ci < nc; ci++){
     538:	4901                	li	s2,0
     53a:	4991                	li	s3,4
    pids[ci] = fork();
     53c:	652000ef          	jal	b8e <fork>
     540:	84aa                	mv	s1,a0
    if(pids[ci] < 0){
     542:	00054f63          	bltz	a0,560 <test2+0xa8>
      printf("test2: fork failed\n");
      exit(1);
    }
    if(pids[ci] == 0){
     546:	c91d                	beqz	a0,57c <test2+0xc4>
  for(int ci = 0; ci < nc; ci++){
     548:	2905                	addiw	s2,s2,1
     54a:	ff3919e3          	bne	s2,s3,53c <test2+0x84>
     54e:	4491                	li	s1,4

      exit(0);
    }
  }

  int ok = 1;
     550:	4905                	li	s2,1

  for(int ci = 0; ci < nc; ci++){
    int st = 0;
    int ret = wait(&st);
     552:	f7c40993          	addi	s3,s0,-132
    if(ret <= 0){
      printf("test2: wait() failed\n");
     556:	00001a17          	auipc	s4,0x1
     55a:	eeaa0a13          	addi	s4,s4,-278 # 1440 <statistics+0x2d0>
     55e:	a2c5                	j	73e <test2+0x286>
     560:	e4de                	sd	s7,72(sp)
     562:	e0e2                	sd	s8,64(sp)
     564:	fc66                	sd	s9,56(sp)
     566:	f86a                	sd	s10,48(sp)
     568:	f46e                	sd	s11,40(sp)
      printf("test2: fork failed\n");
     56a:	00001517          	auipc	a0,0x1
     56e:	df650513          	addi	a0,a0,-522 # 1360 <statistics+0x1f0>
     572:	255000ef          	jal	fc6 <printf>
      exit(1);
     576:	4505                	li	a0,1
     578:	61e000ef          	jal	b96 <exit>
     57c:	e4de                	sd	s7,72(sp)
     57e:	e0e2                	sd	s8,64(sp)
     580:	fc66                	sd	s9,56(sp)
     582:	f86a                	sd	s10,48(sp)
     584:	f46e                	sd	s11,40(sp)
      char me = "abcdefghijklmnop"[ci];
     586:	00001797          	auipc	a5,0x1
     58a:	ef278793          	addi	a5,a5,-270 # 1478 <statistics+0x308>
     58e:	97ca                	add	a5,a5,s2
     590:	0007cb03          	lbu	s6,0(a5)
      int pid = getpid();
     594:	682000ef          	jal	c16 <getpid>
     598:	8caa                	mv	s9,a0
      int nf = (ci == 0 ? 10 : 15);
     59a:	4d3d                	li	s10,15
     59c:	00091363          	bnez	s2,5a2 <test2+0xea>
     5a0:	4d29                	li	s10,10
      for(int i = 0; i < nf; i++){
     5a2:	8ba6                	mv	s7,s1
        int fd = open(file, O_CREATE | O_RDWR);
     5a4:	f8040d93          	addi	s11,s0,-128
        int xx = (pid << 16) | i;
     5a8:	010c9c9b          	slliw	s9,s9,0x10
          sleep(1);
     5ac:	4c05                	li	s8,1
          if(write(fd, &xx, sizeof(xx)) <= 0){
     5ae:	f7c40a93          	addi	s5,s0,-132
     5b2:	4991                	li	s3,4
     5b4:	a011                	j	5b8 <test2+0x100>
     5b6:	8bd2                	mv	s7,s4
        file[3] = me;
     5b8:	f96401a3          	sb	s6,-125(s0)
        file[4] = '0' + i;
     5bc:	030b879b          	addiw	a5,s7,48
     5c0:	f8f40223          	sb	a5,-124(s0)
        file[5] = '\0';
     5c4:	f80402a3          	sb	zero,-123(s0)
        int fd = open(file, O_CREATE | O_RDWR);
     5c8:	20200593          	li	a1,514
     5cc:	856e                	mv	a0,s11
     5ce:	608000ef          	jal	bd6 <open>
     5d2:	892a                	mv	s2,a0
        if(fd < 0){
     5d4:	04054063          	bltz	a0,614 <test2+0x15c>
        int xx = (pid << 16) | i;
     5d8:	017ce7b3          	or	a5,s9,s7
     5dc:	f6f42e23          	sw	a5,-132(s0)
     5e0:	4a09                	li	s4,2
          sleep(1);
     5e2:	8562                	mv	a0,s8
     5e4:	642000ef          	jal	c26 <sleep>
          if(write(fd, &xx, sizeof(xx)) <= 0){
     5e8:	864e                	mv	a2,s3
     5ea:	85d6                	mv	a1,s5
     5ec:	854a                	mv	a0,s2
     5ee:	5c8000ef          	jal	bb6 <write>
     5f2:	02a05c63          	blez	a0,62a <test2+0x172>
        for(int nw = 0; nw < 2; nw++){
     5f6:	3a7d                	addiw	s4,s4,-1
     5f8:	fe0a15e3          	bnez	s4,5e2 <test2+0x12a>
        close(fd);
     5fc:	854a                	mv	a0,s2
     5fe:	5c0000ef          	jal	bbe <close>
      for(int i = 0; i < nf; i++){
     602:	001b8a1b          	addiw	s4,s7,1
     606:	fb4d18e3          	bne	s10,s4,5b6 <test2+0xfe>
          sleep(1);
     60a:	4d85                	li	s11,1
          int n = read(fd, &z, sizeof(z));
     60c:	f7c40d13          	addi	s10,s0,-132
     610:	4c11                	li	s8,4
     612:	a805                	j	642 <test2+0x18a>
          printf("test2: create %s failed\n", file);
     614:	f8040593          	addi	a1,s0,-128
     618:	00001517          	auipc	a0,0x1
     61c:	d6050513          	addi	a0,a0,-672 # 1378 <statistics+0x208>
     620:	1a7000ef          	jal	fc6 <printf>
          exit(1);
     624:	4505                	li	a0,1
     626:	570000ef          	jal	b96 <exit>
            printf("test2: write %s failed\n", file);
     62a:	f8040593          	addi	a1,s0,-128
     62e:	00001517          	auipc	a0,0x1
     632:	d6a50513          	addi	a0,a0,-662 # 1398 <statistics+0x228>
     636:	191000ef          	jal	fc6 <printf>
            exit(1);
     63a:	4505                	li	a0,1
     63c:	55a000ef          	jal	b96 <exit>
     640:	84be                	mv	s1,a5
        file[3] = me;
     642:	f96401a3          	sb	s6,-125(s0)
        file[4] = '0' + i;
     646:	0304879b          	addiw	a5,s1,48
     64a:	f8f40223          	sb	a5,-124(s0)
        file[5] = '\0';
     64e:	f80402a3          	sb	zero,-123(s0)
        int fd = open(file, O_RDWR);
     652:	4589                	li	a1,2
     654:	f8040513          	addi	a0,s0,-128
     658:	57e000ef          	jal	bd6 <open>
     65c:	892a                	mv	s2,a0
        if(fd < 0){
     65e:	06054963          	bltz	a0,6d0 <test2+0x218>
        int xx = (pid << 16) | i;
     662:	009ceab3          	or	s5,s9,s1
     666:	2a81                	sext.w	s5,s5
     668:	4989                	li	s3,2
          int z = 0;
     66a:	f6042e23          	sw	zero,-132(s0)
          sleep(1);
     66e:	856e                	mv	a0,s11
     670:	5b6000ef          	jal	c26 <sleep>
          int n = read(fd, &z, sizeof(z));
     674:	8662                	mv	a2,s8
     676:	85ea                	mv	a1,s10
     678:	854a                	mv	a0,s2
     67a:	534000ef          	jal	bae <read>
          if(n != sizeof(z)){
     67e:	07851463          	bne	a0,s8,6e6 <test2+0x22e>
          if(z != xx){
     682:	f7c42603          	lw	a2,-132(s0)
     686:	07561d63          	bne	a2,s5,700 <test2+0x248>
        for(int nr = 0; nr < 2; nr++){
     68a:	39fd                	addiw	s3,s3,-1
     68c:	fc099fe3          	bnez	s3,66a <test2+0x1b2>
        close(fd);
     690:	854a                	mv	a0,s2
     692:	52c000ef          	jal	bbe <close>
      for(int i = 0; i < nf; i++){
     696:	0014879b          	addiw	a5,s1,1
     69a:	fa9b93e3          	bne	s7,s1,640 <test2+0x188>
     69e:	030a091b          	addiw	s2,s4,48
     6a2:	0ff97913          	zext.b	s2,s2
     6a6:	03000493          	li	s1,48
        if(unlink(file) != 0){
     6aa:	f8040993          	addi	s3,s0,-128
        file[3] = me;
     6ae:	f96401a3          	sb	s6,-125(s0)
        file[4] = '0' + i;
     6b2:	f8940223          	sb	s1,-124(s0)
        file[5] = '\0';
     6b6:	f80402a3          	sb	zero,-123(s0)
        if(unlink(file) != 0){
     6ba:	854e                	mv	a0,s3
     6bc:	52a000ef          	jal	be6 <unlink>
     6c0:	ed21                	bnez	a0,718 <test2+0x260>
      for(int i = 0; i < nf; i++){
     6c2:	2485                	addiw	s1,s1,1
     6c4:	0ff4f493          	zext.b	s1,s1
     6c8:	ff2493e3          	bne	s1,s2,6ae <test2+0x1f6>
      exit(0);
     6cc:	4ca000ef          	jal	b96 <exit>
          printf("test2: open %s failed\n", file);
     6d0:	f8040593          	addi	a1,s0,-128
     6d4:	00001517          	auipc	a0,0x1
     6d8:	cdc50513          	addi	a0,a0,-804 # 13b0 <statistics+0x240>
     6dc:	0eb000ef          	jal	fc6 <printf>
          exit(1);
     6e0:	4505                	li	a0,1
     6e2:	4b4000ef          	jal	b96 <exit>
            printf("test2: read %s returned %d, expected %ld\n", file, n, sizeof(z));
     6e6:	4691                	li	a3,4
     6e8:	862a                	mv	a2,a0
     6ea:	f8040593          	addi	a1,s0,-128
     6ee:	00001517          	auipc	a0,0x1
     6f2:	cda50513          	addi	a0,a0,-806 # 13c8 <statistics+0x258>
     6f6:	0d1000ef          	jal	fc6 <printf>
            exit(1);
     6fa:	4505                	li	a0,1
     6fc:	49a000ef          	jal	b96 <exit>
            printf("test2: file %s contained %d, not %d\n", file, z, xx);
     700:	86d6                	mv	a3,s5
     702:	f8040593          	addi	a1,s0,-128
     706:	00001517          	auipc	a0,0x1
     70a:	cf250513          	addi	a0,a0,-782 # 13f8 <statistics+0x288>
     70e:	0b9000ef          	jal	fc6 <printf>
            exit(1);
     712:	4505                	li	a0,1
     714:	482000ef          	jal	b96 <exit>
          printf("test2: unlink %s failed\n", file);
     718:	f8040593          	addi	a1,s0,-128
     71c:	00001517          	auipc	a0,0x1
     720:	d0450513          	addi	a0,a0,-764 # 1420 <statistics+0x2b0>
     724:	0a3000ef          	jal	fc6 <printf>
          exit(1);
     728:	4505                	li	a0,1
     72a:	46c000ef          	jal	b96 <exit>
      ok = 0;
    }
    if(st != 0)
     72e:	f7c42783          	lw	a5,-132(s0)
     732:	0017b793          	seqz	a5,a5
     736:	00f97933          	and	s2,s2,a5
  for(int ci = 0; ci < nc; ci++){
     73a:	34fd                	addiw	s1,s1,-1
     73c:	cc89                	beqz	s1,756 <test2+0x29e>
    int st = 0;
     73e:	f6042e23          	sw	zero,-132(s0)
    int ret = wait(&st);
     742:	854e                	mv	a0,s3
     744:	45a000ef          	jal	b9e <wait>
    if(ret <= 0){
     748:	fea043e3          	bgtz	a0,72e <test2+0x276>
      printf("test2: wait() failed\n");
     74c:	8552                	mv	a0,s4
     74e:	079000ef          	jal	fc6 <printf>
      ok = 0;
     752:	4901                	li	s2,0
     754:	bfe9                	j	72e <test2+0x276>
      ok = 0;
  }
  if(ok) {
     756:	02090263          	beqz	s2,77a <test2+0x2c2>
    printf("\ntest2 OK\n");
     75a:	00001517          	auipc	a0,0x1
     75e:	cfe50513          	addi	a0,a0,-770 # 1458 <statistics+0x2e8>
     762:	065000ef          	jal	fc6 <printf>
  } else {
    printf("test2 failed\n");
  }
}
     766:	60aa                	ld	ra,136(sp)
     768:	640a                	ld	s0,128(sp)
     76a:	74e6                	ld	s1,120(sp)
     76c:	7946                	ld	s2,112(sp)
     76e:	79a6                	ld	s3,104(sp)
     770:	7a06                	ld	s4,96(sp)
     772:	6ae6                	ld	s5,88(sp)
     774:	6b46                	ld	s6,80(sp)
     776:	6149                	addi	sp,sp,144
     778:	8082                	ret
    printf("test2 failed\n");
     77a:	00001517          	auipc	a0,0x1
     77e:	cee50513          	addi	a0,a0,-786 # 1468 <statistics+0x2f8>
     782:	045000ef          	jal	fc6 <printf>
}
     786:	b7c5                	j	766 <test2+0x2ae>

0000000000000788 <test3>:
// generate big log transactions to check that bget() can
// make use of any of the NBUF buffers for any block number.
//
void
test3()
{
     788:	715d                	addi	sp,sp,-80
     78a:	e486                	sd	ra,72(sp)
     78c:	e0a2                	sd	s0,64(sp)
     78e:	fc26                	sd	s1,56(sp)
     790:	f84a                	sd	s2,48(sp)
     792:	f44e                	sd	s3,40(sp)
     794:	f052                	sd	s4,32(sp)
     796:	0880                	addi	s0,sp,80
  int nc = 5;
  char file[16];

  printf("start test3\n");
     798:	00001517          	auipc	a0,0x1
     79c:	cf850513          	addi	a0,a0,-776 # 1490 <statistics+0x320>
     7a0:	027000ef          	jal	fc6 <printf>
  
  mkdir("d2");
     7a4:	00001517          	auipc	a0,0x1
     7a8:	bb450513          	addi	a0,a0,-1100 # 1358 <statistics+0x1e8>
     7ac:	452000ef          	jal	bfe <mkdir>

  file[0] = 'd';
     7b0:	06400793          	li	a5,100
     7b4:	fcf40023          	sb	a5,-64(s0)
  file[1] = '2';
     7b8:	03200793          	li	a5,50
     7bc:	fcf400a3          	sb	a5,-63(s0)
  file[2] = '/';
     7c0:	02f00793          	li	a5,47
     7c4:	fcf40123          	sb	a5,-62(s0)

  int pids[nc];
  for(int ci = 0; ci < nc; ci++){
     7c8:	4481                	li	s1,0
     7ca:	4915                	li	s2,5
    pids[ci] = fork();
     7cc:	3c2000ef          	jal	b8e <fork>
    if(pids[ci] < 0){
     7d0:	00054f63          	bltz	a0,7ee <test3+0x66>
      printf("test3: fork failed\n");
      exit(1);
    }
    if(pids[ci] == 0){
     7d4:	c515                	beqz	a0,800 <test3+0x78>
  for(int ci = 0; ci < nc; ci++){
     7d6:	2485                	addiw	s1,s1,1
     7d8:	ff249ae3          	bne	s1,s2,7cc <test3+0x44>
     7dc:	4495                	li	s1,5
      }
      exit(0);
    }
  }

  int ok = 1;
     7de:	4905                	li	s2,1

  for(int ci = 0; ci < nc; ci++){
    int st = 0;
    int ret = wait(&st);
     7e0:	fbc40993          	addi	s3,s0,-68
    if(ret <= 0){
      printf("test3: wait() failed\n");
     7e4:	00001a17          	auipc	s4,0x1
     7e8:	cfca0a13          	addi	s4,s4,-772 # 14e0 <statistics+0x370>
     7ec:	a859                	j	882 <test3+0xfa>
      printf("test3: fork failed\n");
     7ee:	00001517          	auipc	a0,0x1
     7f2:	cb250513          	addi	a0,a0,-846 # 14a0 <statistics+0x330>
     7f6:	7d0000ef          	jal	fc6 <printf>
      exit(1);
     7fa:	4505                	li	a0,1
     7fc:	39a000ef          	jal	b96 <exit>
      file[3] = 'a' + ci;
     800:	0614849b          	addiw	s1,s1,97
     804:	fc9401a3          	sb	s1,-61(s0)
      file[4] = '\0';
     808:	fc040223          	sb	zero,-60(s0)
      unlink(file);
     80c:	fc040493          	addi	s1,s0,-64
     810:	8526                	mv	a0,s1
     812:	3d4000ef          	jal	be6 <unlink>
      int fd = open(file, O_CREATE | O_RDWR);
     816:	20200593          	li	a1,514
     81a:	8526                	mv	a0,s1
     81c:	3ba000ef          	jal	bd6 <open>
     820:	892a                	mv	s2,a0
      if(fd < 0){
     822:	02054e63          	bltz	a0,85e <test3+0xd6>
      write(fd, "x", 1);
     826:	4605                	li	a2,1
     828:	00001597          	auipc	a1,0x1
     82c:	cb058593          	addi	a1,a1,-848 # 14d8 <statistics+0x368>
     830:	386000ef          	jal	bb6 <write>
     834:	44b1                	li	s1,12
        write(fd, junk, sizeof(junk));
     836:	6989                	lui	s3,0x2
     838:	80098993          	addi	s3,s3,-2048 # 1800 <digits+0x2b8>
     83c:	00001a17          	auipc	s4,0x1
     840:	7d4a0a13          	addi	s4,s4,2004 # 2010 <junk.0>
        sleep(1);
     844:	4505                	li	a0,1
     846:	3e0000ef          	jal	c26 <sleep>
        write(fd, junk, sizeof(junk));
     84a:	864e                	mv	a2,s3
     84c:	85d2                	mv	a1,s4
     84e:	854a                	mv	a0,s2
     850:	366000ef          	jal	bb6 <write>
      for(int i = 0; i < 12; i++){
     854:	34fd                	addiw	s1,s1,-1
     856:	f4fd                	bnez	s1,844 <test3+0xbc>
      exit(0);
     858:	4501                	li	a0,0
     85a:	33c000ef          	jal	b96 <exit>
        printf("test3: create %s failed\n", file);
     85e:	85a6                	mv	a1,s1
     860:	00001517          	auipc	a0,0x1
     864:	c5850513          	addi	a0,a0,-936 # 14b8 <statistics+0x348>
     868:	75e000ef          	jal	fc6 <printf>
        exit(1);
     86c:	4505                	li	a0,1
     86e:	328000ef          	jal	b96 <exit>
      ok = 0;
    }
    if(st != 0)
     872:	fbc42783          	lw	a5,-68(s0)
     876:	0017b793          	seqz	a5,a5
     87a:	00f97933          	and	s2,s2,a5
  for(int ci = 0; ci < nc; ci++){
     87e:	34fd                	addiw	s1,s1,-1
     880:	cc89                	beqz	s1,89a <test3+0x112>
    int st = 0;
     882:	fa042e23          	sw	zero,-68(s0)
    int ret = wait(&st);
     886:	854e                	mv	a0,s3
     888:	316000ef          	jal	b9e <wait>
    if(ret <= 0){
     88c:	fea043e3          	bgtz	a0,872 <test3+0xea>
      printf("test3: wait() failed\n");
     890:	8552                	mv	a0,s4
     892:	734000ef          	jal	fc6 <printf>
      ok = 0;
     896:	4901                	li	s2,0
     898:	bfe9                	j	872 <test3+0xea>
     89a:	06100493          	li	s1,97
  }

  for(int ci = 0; ci < nc; ci++){
    file[3] = 'a' + ci;
    file[4] = '\0';
    unlink(file);
     89e:	fc040a13          	addi	s4,s0,-64
  for(int ci = 0; ci < nc; ci++){
     8a2:	06600993          	li	s3,102
    file[3] = 'a' + ci;
     8a6:	fc9401a3          	sb	s1,-61(s0)
    file[4] = '\0';
     8aa:	fc040223          	sb	zero,-60(s0)
    unlink(file);
     8ae:	8552                	mv	a0,s4
     8b0:	336000ef          	jal	be6 <unlink>
  for(int ci = 0; ci < nc; ci++){
     8b4:	2485                	addiw	s1,s1,1
     8b6:	0ff4f493          	zext.b	s1,s1
     8ba:	ff3496e3          	bne	s1,s3,8a6 <test3+0x11e>
  }

  if(ok) {
     8be:	02090063          	beqz	s2,8de <test3+0x156>
    printf("\ntest3 OK\n");
     8c2:	00001517          	auipc	a0,0x1
     8c6:	c3650513          	addi	a0,a0,-970 # 14f8 <statistics+0x388>
     8ca:	6fc000ef          	jal	fc6 <printf>
  } else {
    printf("test3 failed\n");
  }
}
     8ce:	60a6                	ld	ra,72(sp)
     8d0:	6406                	ld	s0,64(sp)
     8d2:	74e2                	ld	s1,56(sp)
     8d4:	7942                	ld	s2,48(sp)
     8d6:	79a2                	ld	s3,40(sp)
     8d8:	7a02                	ld	s4,32(sp)
     8da:	6161                	addi	sp,sp,80
     8dc:	8082                	ret
    printf("test3 failed\n");
     8de:	00001517          	auipc	a0,0x1
     8e2:	c2a50513          	addi	a0,a0,-982 # 1508 <statistics+0x398>
     8e6:	6e0000ef          	jal	fc6 <printf>
}
     8ea:	b7d5                	j	8ce <test3+0x146>

00000000000008ec <main>:
{
     8ec:	1141                	addi	sp,sp,-16
     8ee:	e406                	sd	ra,8(sp)
     8f0:	e022                	sd	s0,0(sp)
     8f2:	0800                	addi	s0,sp,16
  test0();
     8f4:	8f9ff0ef          	jal	1ec <test0>
  test1();
     8f8:	a87ff0ef          	jal	37e <test1>
  test2();
     8fc:	bbdff0ef          	jal	4b8 <test2>
  test3();
     900:	e89ff0ef          	jal	788 <test3>
  exit(0);
     904:	4501                	li	a0,0
     906:	290000ef          	jal	b96 <exit>

000000000000090a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
     90a:	1141                	addi	sp,sp,-16
     90c:	e406                	sd	ra,8(sp)
     90e:	e022                	sd	s0,0(sp)
     910:	0800                	addi	s0,sp,16
  extern int main();
  main();
     912:	fdbff0ef          	jal	8ec <main>
  exit(0);
     916:	4501                	li	a0,0
     918:	27e000ef          	jal	b96 <exit>

000000000000091c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
     91c:	1141                	addi	sp,sp,-16
     91e:	e406                	sd	ra,8(sp)
     920:	e022                	sd	s0,0(sp)
     922:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     924:	87aa                	mv	a5,a0
     926:	0585                	addi	a1,a1,1
     928:	0785                	addi	a5,a5,1
     92a:	fff5c703          	lbu	a4,-1(a1)
     92e:	fee78fa3          	sb	a4,-1(a5)
     932:	fb75                	bnez	a4,926 <strcpy+0xa>
    ;
  return os;
}
     934:	60a2                	ld	ra,8(sp)
     936:	6402                	ld	s0,0(sp)
     938:	0141                	addi	sp,sp,16
     93a:	8082                	ret

000000000000093c <strcmp>:

int
strcmp(const char *p, const char *q)
{
     93c:	1141                	addi	sp,sp,-16
     93e:	e406                	sd	ra,8(sp)
     940:	e022                	sd	s0,0(sp)
     942:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
     944:	00054783          	lbu	a5,0(a0)
     948:	cb91                	beqz	a5,95c <strcmp+0x20>
     94a:	0005c703          	lbu	a4,0(a1)
     94e:	00f71763          	bne	a4,a5,95c <strcmp+0x20>
    p++, q++;
     952:	0505                	addi	a0,a0,1
     954:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
     956:	00054783          	lbu	a5,0(a0)
     95a:	fbe5                	bnez	a5,94a <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
     95c:	0005c503          	lbu	a0,0(a1)
}
     960:	40a7853b          	subw	a0,a5,a0
     964:	60a2                	ld	ra,8(sp)
     966:	6402                	ld	s0,0(sp)
     968:	0141                	addi	sp,sp,16
     96a:	8082                	ret

000000000000096c <strlen>:

uint
strlen(const char *s)
{
     96c:	1141                	addi	sp,sp,-16
     96e:	e406                	sd	ra,8(sp)
     970:	e022                	sd	s0,0(sp)
     972:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
     974:	00054783          	lbu	a5,0(a0)
     978:	cf91                	beqz	a5,994 <strlen+0x28>
     97a:	00150793          	addi	a5,a0,1
     97e:	86be                	mv	a3,a5
     980:	0785                	addi	a5,a5,1
     982:	fff7c703          	lbu	a4,-1(a5)
     986:	ff65                	bnez	a4,97e <strlen+0x12>
     988:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
     98c:	60a2                	ld	ra,8(sp)
     98e:	6402                	ld	s0,0(sp)
     990:	0141                	addi	sp,sp,16
     992:	8082                	ret
  for(n = 0; s[n]; n++)
     994:	4501                	li	a0,0
     996:	bfdd                	j	98c <strlen+0x20>

0000000000000998 <memset>:

void*
memset(void *dst, int c, uint n)
{
     998:	1141                	addi	sp,sp,-16
     99a:	e406                	sd	ra,8(sp)
     99c:	e022                	sd	s0,0(sp)
     99e:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     9a0:	ca19                	beqz	a2,9b6 <memset+0x1e>
     9a2:	87aa                	mv	a5,a0
     9a4:	1602                	slli	a2,a2,0x20
     9a6:	9201                	srli	a2,a2,0x20
     9a8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
     9ac:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
     9b0:	0785                	addi	a5,a5,1
     9b2:	fee79de3          	bne	a5,a4,9ac <memset+0x14>
  }
  return dst;
}
     9b6:	60a2                	ld	ra,8(sp)
     9b8:	6402                	ld	s0,0(sp)
     9ba:	0141                	addi	sp,sp,16
     9bc:	8082                	ret

00000000000009be <strchr>:

char*
strchr(const char *s, char c)
{
     9be:	1141                	addi	sp,sp,-16
     9c0:	e406                	sd	ra,8(sp)
     9c2:	e022                	sd	s0,0(sp)
     9c4:	0800                	addi	s0,sp,16
  for(; *s; s++)
     9c6:	00054783          	lbu	a5,0(a0)
     9ca:	cf81                	beqz	a5,9e2 <strchr+0x24>
    if(*s == c)
     9cc:	00f58763          	beq	a1,a5,9da <strchr+0x1c>
  for(; *s; s++)
     9d0:	0505                	addi	a0,a0,1
     9d2:	00054783          	lbu	a5,0(a0)
     9d6:	fbfd                	bnez	a5,9cc <strchr+0xe>
      return (char*)s;
  return 0;
     9d8:	4501                	li	a0,0
}
     9da:	60a2                	ld	ra,8(sp)
     9dc:	6402                	ld	s0,0(sp)
     9de:	0141                	addi	sp,sp,16
     9e0:	8082                	ret
  return 0;
     9e2:	4501                	li	a0,0
     9e4:	bfdd                	j	9da <strchr+0x1c>

00000000000009e6 <gets>:

char*
gets(char *buf, int max)
{
     9e6:	711d                	addi	sp,sp,-96
     9e8:	ec86                	sd	ra,88(sp)
     9ea:	e8a2                	sd	s0,80(sp)
     9ec:	e4a6                	sd	s1,72(sp)
     9ee:	e0ca                	sd	s2,64(sp)
     9f0:	fc4e                	sd	s3,56(sp)
     9f2:	f852                	sd	s4,48(sp)
     9f4:	f456                	sd	s5,40(sp)
     9f6:	f05a                	sd	s6,32(sp)
     9f8:	ec5e                	sd	s7,24(sp)
     9fa:	e862                	sd	s8,16(sp)
     9fc:	1080                	addi	s0,sp,96
     9fe:	8baa                	mv	s7,a0
     a00:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     a02:	892a                	mv	s2,a0
     a04:	4481                	li	s1,0
    cc = read(0, &c, 1);
     a06:	faf40b13          	addi	s6,s0,-81
     a0a:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
     a0c:	8c26                	mv	s8,s1
     a0e:	0014899b          	addiw	s3,s1,1
     a12:	84ce                	mv	s1,s3
     a14:	0349d463          	bge	s3,s4,a3c <gets+0x56>
    cc = read(0, &c, 1);
     a18:	8656                	mv	a2,s5
     a1a:	85da                	mv	a1,s6
     a1c:	4501                	li	a0,0
     a1e:	190000ef          	jal	bae <read>
    if(cc < 1)
     a22:	00a05d63          	blez	a0,a3c <gets+0x56>
      break;
    buf[i++] = c;
     a26:	faf44783          	lbu	a5,-81(s0)
     a2a:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
     a2e:	0905                	addi	s2,s2,1
     a30:	ff678713          	addi	a4,a5,-10
     a34:	c319                	beqz	a4,a3a <gets+0x54>
     a36:	17cd                	addi	a5,a5,-13
     a38:	fbf1                	bnez	a5,a0c <gets+0x26>
    buf[i++] = c;
     a3a:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
     a3c:	9c5e                	add	s8,s8,s7
     a3e:	000c0023          	sb	zero,0(s8)
  return buf;
}
     a42:	855e                	mv	a0,s7
     a44:	60e6                	ld	ra,88(sp)
     a46:	6446                	ld	s0,80(sp)
     a48:	64a6                	ld	s1,72(sp)
     a4a:	6906                	ld	s2,64(sp)
     a4c:	79e2                	ld	s3,56(sp)
     a4e:	7a42                	ld	s4,48(sp)
     a50:	7aa2                	ld	s5,40(sp)
     a52:	7b02                	ld	s6,32(sp)
     a54:	6be2                	ld	s7,24(sp)
     a56:	6c42                	ld	s8,16(sp)
     a58:	6125                	addi	sp,sp,96
     a5a:	8082                	ret

0000000000000a5c <stat>:

int
stat(const char *n, struct stat *st)
{
     a5c:	1101                	addi	sp,sp,-32
     a5e:	ec06                	sd	ra,24(sp)
     a60:	e822                	sd	s0,16(sp)
     a62:	e04a                	sd	s2,0(sp)
     a64:	1000                	addi	s0,sp,32
     a66:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     a68:	4581                	li	a1,0
     a6a:	16c000ef          	jal	bd6 <open>
  if(fd < 0)
     a6e:	02054263          	bltz	a0,a92 <stat+0x36>
     a72:	e426                	sd	s1,8(sp)
     a74:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
     a76:	85ca                	mv	a1,s2
     a78:	176000ef          	jal	bee <fstat>
     a7c:	892a                	mv	s2,a0
  close(fd);
     a7e:	8526                	mv	a0,s1
     a80:	13e000ef          	jal	bbe <close>
  return r;
     a84:	64a2                	ld	s1,8(sp)
}
     a86:	854a                	mv	a0,s2
     a88:	60e2                	ld	ra,24(sp)
     a8a:	6442                	ld	s0,16(sp)
     a8c:	6902                	ld	s2,0(sp)
     a8e:	6105                	addi	sp,sp,32
     a90:	8082                	ret
    return -1;
     a92:	57fd                	li	a5,-1
     a94:	893e                	mv	s2,a5
     a96:	bfc5                	j	a86 <stat+0x2a>

0000000000000a98 <atoi>:

int
atoi(const char *s)
{
     a98:	1141                	addi	sp,sp,-16
     a9a:	e406                	sd	ra,8(sp)
     a9c:	e022                	sd	s0,0(sp)
     a9e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     aa0:	00054683          	lbu	a3,0(a0)
     aa4:	fd06879b          	addiw	a5,a3,-48
     aa8:	0ff7f793          	zext.b	a5,a5
     aac:	4625                	li	a2,9
     aae:	02f66963          	bltu	a2,a5,ae0 <atoi+0x48>
     ab2:	872a                	mv	a4,a0
  n = 0;
     ab4:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
     ab6:	0705                	addi	a4,a4,1
     ab8:	0025179b          	slliw	a5,a0,0x2
     abc:	9fa9                	addw	a5,a5,a0
     abe:	0017979b          	slliw	a5,a5,0x1
     ac2:	9fb5                	addw	a5,a5,a3
     ac4:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
     ac8:	00074683          	lbu	a3,0(a4)
     acc:	fd06879b          	addiw	a5,a3,-48
     ad0:	0ff7f793          	zext.b	a5,a5
     ad4:	fef671e3          	bgeu	a2,a5,ab6 <atoi+0x1e>
  return n;
}
     ad8:	60a2                	ld	ra,8(sp)
     ada:	6402                	ld	s0,0(sp)
     adc:	0141                	addi	sp,sp,16
     ade:	8082                	ret
  n = 0;
     ae0:	4501                	li	a0,0
     ae2:	bfdd                	j	ad8 <atoi+0x40>

0000000000000ae4 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     ae4:	1141                	addi	sp,sp,-16
     ae6:	e406                	sd	ra,8(sp)
     ae8:	e022                	sd	s0,0(sp)
     aea:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     aec:	02b57563          	bgeu	a0,a1,b16 <memmove+0x32>
    while(n-- > 0)
     af0:	00c05f63          	blez	a2,b0e <memmove+0x2a>
     af4:	1602                	slli	a2,a2,0x20
     af6:	9201                	srli	a2,a2,0x20
     af8:	00c507b3          	add	a5,a0,a2
  dst = vdst;
     afc:	872a                	mv	a4,a0
      *dst++ = *src++;
     afe:	0585                	addi	a1,a1,1
     b00:	0705                	addi	a4,a4,1
     b02:	fff5c683          	lbu	a3,-1(a1)
     b06:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
     b0a:	fee79ae3          	bne	a5,a4,afe <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
     b0e:	60a2                	ld	ra,8(sp)
     b10:	6402                	ld	s0,0(sp)
     b12:	0141                	addi	sp,sp,16
     b14:	8082                	ret
    while(n-- > 0)
     b16:	fec05ce3          	blez	a2,b0e <memmove+0x2a>
    dst += n;
     b1a:	00c50733          	add	a4,a0,a2
    src += n;
     b1e:	95b2                	add	a1,a1,a2
     b20:	fff6079b          	addiw	a5,a2,-1
     b24:	1782                	slli	a5,a5,0x20
     b26:	9381                	srli	a5,a5,0x20
     b28:	fff7c793          	not	a5,a5
     b2c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
     b2e:	15fd                	addi	a1,a1,-1
     b30:	177d                	addi	a4,a4,-1
     b32:	0005c683          	lbu	a3,0(a1)
     b36:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
     b3a:	fef71ae3          	bne	a4,a5,b2e <memmove+0x4a>
     b3e:	bfc1                	j	b0e <memmove+0x2a>

0000000000000b40 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
     b40:	1141                	addi	sp,sp,-16
     b42:	e406                	sd	ra,8(sp)
     b44:	e022                	sd	s0,0(sp)
     b46:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     b48:	c61d                	beqz	a2,b76 <memcmp+0x36>
     b4a:	1602                	slli	a2,a2,0x20
     b4c:	9201                	srli	a2,a2,0x20
     b4e:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
     b52:	00054783          	lbu	a5,0(a0)
     b56:	0005c703          	lbu	a4,0(a1)
     b5a:	00e79863          	bne	a5,a4,b6a <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
     b5e:	0505                	addi	a0,a0,1
    p2++;
     b60:	0585                	addi	a1,a1,1
  while (n-- > 0) {
     b62:	fed518e3          	bne	a0,a3,b52 <memcmp+0x12>
  }
  return 0;
     b66:	4501                	li	a0,0
     b68:	a019                	j	b6e <memcmp+0x2e>
      return *p1 - *p2;
     b6a:	40e7853b          	subw	a0,a5,a4
}
     b6e:	60a2                	ld	ra,8(sp)
     b70:	6402                	ld	s0,0(sp)
     b72:	0141                	addi	sp,sp,16
     b74:	8082                	ret
  return 0;
     b76:	4501                	li	a0,0
     b78:	bfdd                	j	b6e <memcmp+0x2e>

0000000000000b7a <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
     b7a:	1141                	addi	sp,sp,-16
     b7c:	e406                	sd	ra,8(sp)
     b7e:	e022                	sd	s0,0(sp)
     b80:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
     b82:	f63ff0ef          	jal	ae4 <memmove>
}
     b86:	60a2                	ld	ra,8(sp)
     b88:	6402                	ld	s0,0(sp)
     b8a:	0141                	addi	sp,sp,16
     b8c:	8082                	ret

0000000000000b8e <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
     b8e:	4885                	li	a7,1
 ecall
     b90:	00000073          	ecall
 ret
     b94:	8082                	ret

0000000000000b96 <exit>:
.global exit
exit:
 li a7, SYS_exit
     b96:	4889                	li	a7,2
 ecall
     b98:	00000073          	ecall
 ret
     b9c:	8082                	ret

0000000000000b9e <wait>:
.global wait
wait:
 li a7, SYS_wait
     b9e:	488d                	li	a7,3
 ecall
     ba0:	00000073          	ecall
 ret
     ba4:	8082                	ret

0000000000000ba6 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
     ba6:	4891                	li	a7,4
 ecall
     ba8:	00000073          	ecall
 ret
     bac:	8082                	ret

0000000000000bae <read>:
.global read
read:
 li a7, SYS_read
     bae:	4895                	li	a7,5
 ecall
     bb0:	00000073          	ecall
 ret
     bb4:	8082                	ret

0000000000000bb6 <write>:
.global write
write:
 li a7, SYS_write
     bb6:	48c1                	li	a7,16
 ecall
     bb8:	00000073          	ecall
 ret
     bbc:	8082                	ret

0000000000000bbe <close>:
.global close
close:
 li a7, SYS_close
     bbe:	48d5                	li	a7,21
 ecall
     bc0:	00000073          	ecall
 ret
     bc4:	8082                	ret

0000000000000bc6 <kill>:
.global kill
kill:
 li a7, SYS_kill
     bc6:	4899                	li	a7,6
 ecall
     bc8:	00000073          	ecall
 ret
     bcc:	8082                	ret

0000000000000bce <exec>:
.global exec
exec:
 li a7, SYS_exec
     bce:	489d                	li	a7,7
 ecall
     bd0:	00000073          	ecall
 ret
     bd4:	8082                	ret

0000000000000bd6 <open>:
.global open
open:
 li a7, SYS_open
     bd6:	48bd                	li	a7,15
 ecall
     bd8:	00000073          	ecall
 ret
     bdc:	8082                	ret

0000000000000bde <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
     bde:	48c5                	li	a7,17
 ecall
     be0:	00000073          	ecall
 ret
     be4:	8082                	ret

0000000000000be6 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
     be6:	48c9                	li	a7,18
 ecall
     be8:	00000073          	ecall
 ret
     bec:	8082                	ret

0000000000000bee <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
     bee:	48a1                	li	a7,8
 ecall
     bf0:	00000073          	ecall
 ret
     bf4:	8082                	ret

0000000000000bf6 <link>:
.global link
link:
 li a7, SYS_link
     bf6:	48cd                	li	a7,19
 ecall
     bf8:	00000073          	ecall
 ret
     bfc:	8082                	ret

0000000000000bfe <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
     bfe:	48d1                	li	a7,20
 ecall
     c00:	00000073          	ecall
 ret
     c04:	8082                	ret

0000000000000c06 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
     c06:	48a5                	li	a7,9
 ecall
     c08:	00000073          	ecall
 ret
     c0c:	8082                	ret

0000000000000c0e <dup>:
.global dup
dup:
 li a7, SYS_dup
     c0e:	48a9                	li	a7,10
 ecall
     c10:	00000073          	ecall
 ret
     c14:	8082                	ret

0000000000000c16 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
     c16:	48ad                	li	a7,11
 ecall
     c18:	00000073          	ecall
 ret
     c1c:	8082                	ret

0000000000000c1e <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
     c1e:	48b1                	li	a7,12
 ecall
     c20:	00000073          	ecall
 ret
     c24:	8082                	ret

0000000000000c26 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
     c26:	48b5                	li	a7,13
 ecall
     c28:	00000073          	ecall
 ret
     c2c:	8082                	ret

0000000000000c2e <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
     c2e:	48b9                	li	a7,14
 ecall
     c30:	00000073          	ecall
 ret
     c34:	8082                	ret

0000000000000c36 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
     c36:	1101                	addi	sp,sp,-32
     c38:	ec06                	sd	ra,24(sp)
     c3a:	e822                	sd	s0,16(sp)
     c3c:	1000                	addi	s0,sp,32
     c3e:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
     c42:	4605                	li	a2,1
     c44:	fef40593          	addi	a1,s0,-17
     c48:	f6fff0ef          	jal	bb6 <write>
}
     c4c:	60e2                	ld	ra,24(sp)
     c4e:	6442                	ld	s0,16(sp)
     c50:	6105                	addi	sp,sp,32
     c52:	8082                	ret

0000000000000c54 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
     c54:	7139                	addi	sp,sp,-64
     c56:	fc06                	sd	ra,56(sp)
     c58:	f822                	sd	s0,48(sp)
     c5a:	f04a                	sd	s2,32(sp)
     c5c:	ec4e                	sd	s3,24(sp)
     c5e:	0080                	addi	s0,sp,64
     c60:	892a                	mv	s2,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     c62:	cac9                	beqz	a3,cf4 <printint+0xa0>
     c64:	01f5d79b          	srliw	a5,a1,0x1f
     c68:	c7d1                	beqz	a5,cf4 <printint+0xa0>
    neg = 1;
    x = -xx;
     c6a:	40b005bb          	negw	a1,a1
    neg = 1;
     c6e:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
     c70:	fc040993          	addi	s3,s0,-64
  neg = 0;
     c74:	86ce                	mv	a3,s3
  i = 0;
     c76:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
     c78:	00001817          	auipc	a6,0x1
     c7c:	8d080813          	addi	a6,a6,-1840 # 1548 <digits>
     c80:	88ba                	mv	a7,a4
     c82:	0017051b          	addiw	a0,a4,1
     c86:	872a                	mv	a4,a0
     c88:	02c5f7bb          	remuw	a5,a1,a2
     c8c:	1782                	slli	a5,a5,0x20
     c8e:	9381                	srli	a5,a5,0x20
     c90:	97c2                	add	a5,a5,a6
     c92:	0007c783          	lbu	a5,0(a5)
     c96:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
     c9a:	87ae                	mv	a5,a1
     c9c:	02c5d5bb          	divuw	a1,a1,a2
     ca0:	0685                	addi	a3,a3,1
     ca2:	fcc7ffe3          	bgeu	a5,a2,c80 <printint+0x2c>
  if(neg)
     ca6:	00030c63          	beqz	t1,cbe <printint+0x6a>
    buf[i++] = '-';
     caa:	fd050793          	addi	a5,a0,-48
     cae:	00878533          	add	a0,a5,s0
     cb2:	02d00793          	li	a5,45
     cb6:	fef50823          	sb	a5,-16(a0)
     cba:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
     cbe:	02e05563          	blez	a4,ce8 <printint+0x94>
     cc2:	f426                	sd	s1,40(sp)
     cc4:	377d                	addiw	a4,a4,-1
     cc6:	00e984b3          	add	s1,s3,a4
     cca:	19fd                	addi	s3,s3,-1
     ccc:	99ba                	add	s3,s3,a4
     cce:	1702                	slli	a4,a4,0x20
     cd0:	9301                	srli	a4,a4,0x20
     cd2:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
     cd6:	0004c583          	lbu	a1,0(s1)
     cda:	854a                	mv	a0,s2
     cdc:	f5bff0ef          	jal	c36 <putc>
  while(--i >= 0)
     ce0:	14fd                	addi	s1,s1,-1
     ce2:	ff349ae3          	bne	s1,s3,cd6 <printint+0x82>
     ce6:	74a2                	ld	s1,40(sp)
}
     ce8:	70e2                	ld	ra,56(sp)
     cea:	7442                	ld	s0,48(sp)
     cec:	7902                	ld	s2,32(sp)
     cee:	69e2                	ld	s3,24(sp)
     cf0:	6121                	addi	sp,sp,64
     cf2:	8082                	ret
  neg = 0;
     cf4:	4301                	li	t1,0
     cf6:	bfad                	j	c70 <printint+0x1c>

0000000000000cf8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
     cf8:	711d                	addi	sp,sp,-96
     cfa:	ec86                	sd	ra,88(sp)
     cfc:	e8a2                	sd	s0,80(sp)
     cfe:	e4a6                	sd	s1,72(sp)
     d00:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
     d02:	0005c483          	lbu	s1,0(a1)
     d06:	20048963          	beqz	s1,f18 <vprintf+0x220>
     d0a:	e0ca                	sd	s2,64(sp)
     d0c:	fc4e                	sd	s3,56(sp)
     d0e:	f852                	sd	s4,48(sp)
     d10:	f456                	sd	s5,40(sp)
     d12:	f05a                	sd	s6,32(sp)
     d14:	ec5e                	sd	s7,24(sp)
     d16:	e862                	sd	s8,16(sp)
     d18:	8b2a                	mv	s6,a0
     d1a:	8a2e                	mv	s4,a1
     d1c:	8bb2                	mv	s7,a2
  state = 0;
     d1e:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
     d20:	4901                	li	s2,0
     d22:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
     d24:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
     d28:	06400c13          	li	s8,100
     d2c:	a00d                	j	d4e <vprintf+0x56>
        putc(fd, c0);
     d2e:	85a6                	mv	a1,s1
     d30:	855a                	mv	a0,s6
     d32:	f05ff0ef          	jal	c36 <putc>
     d36:	a019                	j	d3c <vprintf+0x44>
    } else if(state == '%'){
     d38:	03598363          	beq	s3,s5,d5e <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
     d3c:	0019079b          	addiw	a5,s2,1
     d40:	893e                	mv	s2,a5
     d42:	873e                	mv	a4,a5
     d44:	97d2                	add	a5,a5,s4
     d46:	0007c483          	lbu	s1,0(a5)
     d4a:	1c048063          	beqz	s1,f0a <vprintf+0x212>
    c0 = fmt[i] & 0xff;
     d4e:	0004879b          	sext.w	a5,s1
    if(state == 0){
     d52:	fe0993e3          	bnez	s3,d38 <vprintf+0x40>
      if(c0 == '%'){
     d56:	fd579ce3          	bne	a5,s5,d2e <vprintf+0x36>
        state = '%';
     d5a:	89be                	mv	s3,a5
     d5c:	b7c5                	j	d3c <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
     d5e:	00ea06b3          	add	a3,s4,a4
     d62:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
     d66:	1a060e63          	beqz	a2,f22 <vprintf+0x22a>
      if(c0 == 'd'){
     d6a:	03878763          	beq	a5,s8,d98 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
     d6e:	f9478693          	addi	a3,a5,-108
     d72:	0016b693          	seqz	a3,a3
     d76:	f9c60593          	addi	a1,a2,-100
     d7a:	e99d                	bnez	a1,db0 <vprintf+0xb8>
     d7c:	ca95                	beqz	a3,db0 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
     d7e:	008b8493          	addi	s1,s7,8
     d82:	4685                	li	a3,1
     d84:	4629                	li	a2,10
     d86:	000ba583          	lw	a1,0(s7)
     d8a:	855a                	mv	a0,s6
     d8c:	ec9ff0ef          	jal	c54 <printint>
        i += 1;
     d90:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
     d92:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
     d94:	4981                	li	s3,0
     d96:	b75d                	j	d3c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
     d98:	008b8493          	addi	s1,s7,8
     d9c:	4685                	li	a3,1
     d9e:	4629                	li	a2,10
     da0:	000ba583          	lw	a1,0(s7)
     da4:	855a                	mv	a0,s6
     da6:	eafff0ef          	jal	c54 <printint>
     daa:	8ba6                	mv	s7,s1
      state = 0;
     dac:	4981                	li	s3,0
     dae:	b779                	j	d3c <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
     db0:	9752                	add	a4,a4,s4
     db2:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
     db6:	f9460713          	addi	a4,a2,-108
     dba:	00173713          	seqz	a4,a4
     dbe:	8f75                	and	a4,a4,a3
     dc0:	f9c58513          	addi	a0,a1,-100
     dc4:	16051963          	bnez	a0,f36 <vprintf+0x23e>
     dc8:	16070763          	beqz	a4,f36 <vprintf+0x23e>
        printint(fd, va_arg(ap, uint64), 10, 1);
     dcc:	008b8493          	addi	s1,s7,8
     dd0:	4685                	li	a3,1
     dd2:	4629                	li	a2,10
     dd4:	000ba583          	lw	a1,0(s7)
     dd8:	855a                	mv	a0,s6
     dda:	e7bff0ef          	jal	c54 <printint>
        i += 2;
     dde:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
     de0:	8ba6                	mv	s7,s1
      state = 0;
     de2:	4981                	li	s3,0
        i += 2;
     de4:	bfa1                	j	d3c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
     de6:	008b8493          	addi	s1,s7,8
     dea:	4681                	li	a3,0
     dec:	4629                	li	a2,10
     dee:	000ba583          	lw	a1,0(s7)
     df2:	855a                	mv	a0,s6
     df4:	e61ff0ef          	jal	c54 <printint>
     df8:	8ba6                	mv	s7,s1
      state = 0;
     dfa:	4981                	li	s3,0
     dfc:	b781                	j	d3c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     dfe:	008b8493          	addi	s1,s7,8
     e02:	4681                	li	a3,0
     e04:	4629                	li	a2,10
     e06:	000ba583          	lw	a1,0(s7)
     e0a:	855a                	mv	a0,s6
     e0c:	e49ff0ef          	jal	c54 <printint>
        i += 1;
     e10:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
     e12:	8ba6                	mv	s7,s1
      state = 0;
     e14:	4981                	li	s3,0
     e16:	b71d                	j	d3c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     e18:	008b8493          	addi	s1,s7,8
     e1c:	4681                	li	a3,0
     e1e:	4629                	li	a2,10
     e20:	000ba583          	lw	a1,0(s7)
     e24:	855a                	mv	a0,s6
     e26:	e2fff0ef          	jal	c54 <printint>
        i += 2;
     e2a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
     e2c:	8ba6                	mv	s7,s1
      state = 0;
     e2e:	4981                	li	s3,0
        i += 2;
     e30:	b731                	j	d3c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
     e32:	008b8493          	addi	s1,s7,8
     e36:	4681                	li	a3,0
     e38:	4641                	li	a2,16
     e3a:	000ba583          	lw	a1,0(s7)
     e3e:	855a                	mv	a0,s6
     e40:	e15ff0ef          	jal	c54 <printint>
     e44:	8ba6                	mv	s7,s1
      state = 0;
     e46:	4981                	li	s3,0
     e48:	bdd5                	j	d3c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     e4a:	008b8493          	addi	s1,s7,8
     e4e:	4681                	li	a3,0
     e50:	4641                	li	a2,16
     e52:	000ba583          	lw	a1,0(s7)
     e56:	855a                	mv	a0,s6
     e58:	dfdff0ef          	jal	c54 <printint>
        i += 1;
     e5c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
     e5e:	8ba6                	mv	s7,s1
      state = 0;
     e60:	4981                	li	s3,0
     e62:	bde9                	j	d3c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     e64:	008b8493          	addi	s1,s7,8
     e68:	4681                	li	a3,0
     e6a:	4641                	li	a2,16
     e6c:	000ba583          	lw	a1,0(s7)
     e70:	855a                	mv	a0,s6
     e72:	de3ff0ef          	jal	c54 <printint>
        i += 2;
     e76:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
     e78:	8ba6                	mv	s7,s1
      state = 0;
     e7a:	4981                	li	s3,0
        i += 2;
     e7c:	b5c1                	j	d3c <vprintf+0x44>
     e7e:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
     e80:	008b8793          	addi	a5,s7,8
     e84:	8cbe                	mv	s9,a5
     e86:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
     e8a:	03000593          	li	a1,48
     e8e:	855a                	mv	a0,s6
     e90:	da7ff0ef          	jal	c36 <putc>
  putc(fd, 'x');
     e94:	07800593          	li	a1,120
     e98:	855a                	mv	a0,s6
     e9a:	d9dff0ef          	jal	c36 <putc>
     e9e:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     ea0:	00000b97          	auipc	s7,0x0
     ea4:	6a8b8b93          	addi	s7,s7,1704 # 1548 <digits>
     ea8:	03c9d793          	srli	a5,s3,0x3c
     eac:	97de                	add	a5,a5,s7
     eae:	0007c583          	lbu	a1,0(a5)
     eb2:	855a                	mv	a0,s6
     eb4:	d83ff0ef          	jal	c36 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     eb8:	0992                	slli	s3,s3,0x4
     eba:	34fd                	addiw	s1,s1,-1
     ebc:	f4f5                	bnez	s1,ea8 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
     ebe:	8be6                	mv	s7,s9
      state = 0;
     ec0:	4981                	li	s3,0
     ec2:	6ca2                	ld	s9,8(sp)
     ec4:	bda5                	j	d3c <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
     ec6:	008b8993          	addi	s3,s7,8
     eca:	000bb483          	ld	s1,0(s7)
     ece:	cc91                	beqz	s1,eea <vprintf+0x1f2>
        for(; *s; s++)
     ed0:	0004c583          	lbu	a1,0(s1)
     ed4:	c985                	beqz	a1,f04 <vprintf+0x20c>
          putc(fd, *s);
     ed6:	855a                	mv	a0,s6
     ed8:	d5fff0ef          	jal	c36 <putc>
        for(; *s; s++)
     edc:	0485                	addi	s1,s1,1
     ede:	0004c583          	lbu	a1,0(s1)
     ee2:	f9f5                	bnez	a1,ed6 <vprintf+0x1de>
        if((s = va_arg(ap, char*)) == 0)
     ee4:	8bce                	mv	s7,s3
      state = 0;
     ee6:	4981                	li	s3,0
     ee8:	bd91                	j	d3c <vprintf+0x44>
          s = "(null)";
     eea:	00000497          	auipc	s1,0x0
     eee:	62e48493          	addi	s1,s1,1582 # 1518 <statistics+0x3a8>
        for(; *s; s++)
     ef2:	02800593          	li	a1,40
     ef6:	b7c5                	j	ed6 <vprintf+0x1de>
        putc(fd, '%');
     ef8:	85be                	mv	a1,a5
     efa:	855a                	mv	a0,s6
     efc:	d3bff0ef          	jal	c36 <putc>
      state = 0;
     f00:	4981                	li	s3,0
     f02:	bd2d                	j	d3c <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
     f04:	8bce                	mv	s7,s3
      state = 0;
     f06:	4981                	li	s3,0
     f08:	bd15                	j	d3c <vprintf+0x44>
     f0a:	6906                	ld	s2,64(sp)
     f0c:	79e2                	ld	s3,56(sp)
     f0e:	7a42                	ld	s4,48(sp)
     f10:	7aa2                	ld	s5,40(sp)
     f12:	7b02                	ld	s6,32(sp)
     f14:	6be2                	ld	s7,24(sp)
     f16:	6c42                	ld	s8,16(sp)
    }
  }
}
     f18:	60e6                	ld	ra,88(sp)
     f1a:	6446                	ld	s0,80(sp)
     f1c:	64a6                	ld	s1,72(sp)
     f1e:	6125                	addi	sp,sp,96
     f20:	8082                	ret
      if(c0 == 'd'){
     f22:	06400713          	li	a4,100
     f26:	e6e789e3          	beq	a5,a4,d98 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
     f2a:	f9478693          	addi	a3,a5,-108
     f2e:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
     f32:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
     f34:	4701                	li	a4,0
      } else if(c0 == 'u'){
     f36:	07500513          	li	a0,117
     f3a:	eaa786e3          	beq	a5,a0,de6 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
     f3e:	f8b60513          	addi	a0,a2,-117
     f42:	e119                	bnez	a0,f48 <vprintf+0x250>
     f44:	ea069de3          	bnez	a3,dfe <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
     f48:	f8b58513          	addi	a0,a1,-117
     f4c:	e119                	bnez	a0,f52 <vprintf+0x25a>
     f4e:	ec0715e3          	bnez	a4,e18 <vprintf+0x120>
      } else if(c0 == 'x'){
     f52:	07800513          	li	a0,120
     f56:	eca78ee3          	beq	a5,a0,e32 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
     f5a:	f8860613          	addi	a2,a2,-120
     f5e:	e219                	bnez	a2,f64 <vprintf+0x26c>
     f60:	ee0695e3          	bnez	a3,e4a <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
     f64:	f8858593          	addi	a1,a1,-120
     f68:	e199                	bnez	a1,f6e <vprintf+0x276>
     f6a:	ee071de3          	bnez	a4,e64 <vprintf+0x16c>
      } else if(c0 == 'p'){
     f6e:	07000713          	li	a4,112
     f72:	f0e786e3          	beq	a5,a4,e7e <vprintf+0x186>
      } else if(c0 == 's'){
     f76:	07300713          	li	a4,115
     f7a:	f4e786e3          	beq	a5,a4,ec6 <vprintf+0x1ce>
      } else if(c0 == '%'){
     f7e:	02500713          	li	a4,37
     f82:	f6e78be3          	beq	a5,a4,ef8 <vprintf+0x200>
        putc(fd, '%');
     f86:	02500593          	li	a1,37
     f8a:	855a                	mv	a0,s6
     f8c:	cabff0ef          	jal	c36 <putc>
        putc(fd, c0);
     f90:	85a6                	mv	a1,s1
     f92:	855a                	mv	a0,s6
     f94:	ca3ff0ef          	jal	c36 <putc>
      state = 0;
     f98:	4981                	li	s3,0
     f9a:	b34d                	j	d3c <vprintf+0x44>

0000000000000f9c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
     f9c:	715d                	addi	sp,sp,-80
     f9e:	ec06                	sd	ra,24(sp)
     fa0:	e822                	sd	s0,16(sp)
     fa2:	1000                	addi	s0,sp,32
     fa4:	e010                	sd	a2,0(s0)
     fa6:	e414                	sd	a3,8(s0)
     fa8:	e818                	sd	a4,16(s0)
     faa:	ec1c                	sd	a5,24(s0)
     fac:	03043023          	sd	a6,32(s0)
     fb0:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
     fb4:	8622                	mv	a2,s0
     fb6:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
     fba:	d3fff0ef          	jal	cf8 <vprintf>
}
     fbe:	60e2                	ld	ra,24(sp)
     fc0:	6442                	ld	s0,16(sp)
     fc2:	6161                	addi	sp,sp,80
     fc4:	8082                	ret

0000000000000fc6 <printf>:

void
printf(const char *fmt, ...)
{
     fc6:	711d                	addi	sp,sp,-96
     fc8:	ec06                	sd	ra,24(sp)
     fca:	e822                	sd	s0,16(sp)
     fcc:	1000                	addi	s0,sp,32
     fce:	e40c                	sd	a1,8(s0)
     fd0:	e810                	sd	a2,16(s0)
     fd2:	ec14                	sd	a3,24(s0)
     fd4:	f018                	sd	a4,32(s0)
     fd6:	f41c                	sd	a5,40(s0)
     fd8:	03043823          	sd	a6,48(s0)
     fdc:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
     fe0:	00840613          	addi	a2,s0,8
     fe4:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
     fe8:	85aa                	mv	a1,a0
     fea:	4505                	li	a0,1
     fec:	d0dff0ef          	jal	cf8 <vprintf>
}
     ff0:	60e2                	ld	ra,24(sp)
     ff2:	6442                	ld	s0,16(sp)
     ff4:	6125                	addi	sp,sp,96
     ff6:	8082                	ret

0000000000000ff8 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
     ff8:	1141                	addi	sp,sp,-16
     ffa:	e406                	sd	ra,8(sp)
     ffc:	e022                	sd	s0,0(sp)
     ffe:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    1000:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1004:	00001797          	auipc	a5,0x1
    1008:	ffc7b783          	ld	a5,-4(a5) # 2000 <freep>
    100c:	a039                	j	101a <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    100e:	6398                	ld	a4,0(a5)
    1010:	00e7e463          	bltu	a5,a4,1018 <free+0x20>
    1014:	00e6ea63          	bltu	a3,a4,1028 <free+0x30>
{
    1018:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    101a:	fed7fae3          	bgeu	a5,a3,100e <free+0x16>
    101e:	6398                	ld	a4,0(a5)
    1020:	00e6e463          	bltu	a3,a4,1028 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1024:	fee7eae3          	bltu	a5,a4,1018 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
    1028:	ff852583          	lw	a1,-8(a0)
    102c:	6390                	ld	a2,0(a5)
    102e:	02059813          	slli	a6,a1,0x20
    1032:	01c85713          	srli	a4,a6,0x1c
    1036:	9736                	add	a4,a4,a3
    1038:	02e60563          	beq	a2,a4,1062 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    103c:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    1040:	4790                	lw	a2,8(a5)
    1042:	02061593          	slli	a1,a2,0x20
    1046:	01c5d713          	srli	a4,a1,0x1c
    104a:	973e                	add	a4,a4,a5
    104c:	02e68263          	beq	a3,a4,1070 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    1050:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    1052:	00001717          	auipc	a4,0x1
    1056:	faf73723          	sd	a5,-82(a4) # 2000 <freep>
}
    105a:	60a2                	ld	ra,8(sp)
    105c:	6402                	ld	s0,0(sp)
    105e:	0141                	addi	sp,sp,16
    1060:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    1062:	4618                	lw	a4,8(a2)
    1064:	9f2d                	addw	a4,a4,a1
    1066:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    106a:	6398                	ld	a4,0(a5)
    106c:	6310                	ld	a2,0(a4)
    106e:	b7f9                	j	103c <free+0x44>
    p->s.size += bp->s.size;
    1070:	ff852703          	lw	a4,-8(a0)
    1074:	9f31                	addw	a4,a4,a2
    1076:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    1078:	ff053683          	ld	a3,-16(a0)
    107c:	bfd1                	j	1050 <free+0x58>

000000000000107e <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    107e:	7139                	addi	sp,sp,-64
    1080:	fc06                	sd	ra,56(sp)
    1082:	f822                	sd	s0,48(sp)
    1084:	f04a                	sd	s2,32(sp)
    1086:	ec4e                	sd	s3,24(sp)
    1088:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    108a:	02051993          	slli	s3,a0,0x20
    108e:	0209d993          	srli	s3,s3,0x20
    1092:	09bd                	addi	s3,s3,15
    1094:	0049d993          	srli	s3,s3,0x4
    1098:	2985                	addiw	s3,s3,1
    109a:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
    109c:	00001517          	auipc	a0,0x1
    10a0:	f6453503          	ld	a0,-156(a0) # 2000 <freep>
    10a4:	c905                	beqz	a0,10d4 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    10a6:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    10a8:	4798                	lw	a4,8(a5)
    10aa:	09377663          	bgeu	a4,s3,1136 <malloc+0xb8>
    10ae:	f426                	sd	s1,40(sp)
    10b0:	e852                	sd	s4,16(sp)
    10b2:	e456                	sd	s5,8(sp)
    10b4:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
    10b6:	8a4e                	mv	s4,s3
    10b8:	6705                	lui	a4,0x1
    10ba:	00e9f363          	bgeu	s3,a4,10c0 <malloc+0x42>
    10be:	6a05                	lui	s4,0x1
    10c0:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    10c4:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    10c8:	00001497          	auipc	s1,0x1
    10cc:	f3848493          	addi	s1,s1,-200 # 2000 <freep>
  if(p == (char*)-1)
    10d0:	5afd                	li	s5,-1
    10d2:	a83d                	j	1110 <malloc+0x92>
    10d4:	f426                	sd	s1,40(sp)
    10d6:	e852                	sd	s4,16(sp)
    10d8:	e456                	sd	s5,8(sp)
    10da:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    10dc:	00003797          	auipc	a5,0x3
    10e0:	73478793          	addi	a5,a5,1844 # 4810 <base>
    10e4:	00001717          	auipc	a4,0x1
    10e8:	f0f73e23          	sd	a5,-228(a4) # 2000 <freep>
    10ec:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    10ee:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    10f2:	b7d1                	j	10b6 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    10f4:	6398                	ld	a4,0(a5)
    10f6:	e118                	sd	a4,0(a0)
    10f8:	a899                	j	114e <malloc+0xd0>
  hp->s.size = nu;
    10fa:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    10fe:	0541                	addi	a0,a0,16
    1100:	ef9ff0ef          	jal	ff8 <free>
  return freep;
    1104:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
    1106:	c125                	beqz	a0,1166 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1108:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    110a:	4798                	lw	a4,8(a5)
    110c:	03277163          	bgeu	a4,s2,112e <malloc+0xb0>
    if(p == freep)
    1110:	6098                	ld	a4,0(s1)
    1112:	853e                	mv	a0,a5
    1114:	fef71ae3          	bne	a4,a5,1108 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    1118:	8552                	mv	a0,s4
    111a:	b05ff0ef          	jal	c1e <sbrk>
  if(p == (char*)-1)
    111e:	fd551ee3          	bne	a0,s5,10fa <malloc+0x7c>
        return 0;
    1122:	4501                	li	a0,0
    1124:	74a2                	ld	s1,40(sp)
    1126:	6a42                	ld	s4,16(sp)
    1128:	6aa2                	ld	s5,8(sp)
    112a:	6b02                	ld	s6,0(sp)
    112c:	a03d                	j	115a <malloc+0xdc>
    112e:	74a2                	ld	s1,40(sp)
    1130:	6a42                	ld	s4,16(sp)
    1132:	6aa2                	ld	s5,8(sp)
    1134:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
    1136:	fae90fe3          	beq	s2,a4,10f4 <malloc+0x76>
        p->s.size -= nunits;
    113a:	4137073b          	subw	a4,a4,s3
    113e:	c798                	sw	a4,8(a5)
        p += p->s.size;
    1140:	02071693          	slli	a3,a4,0x20
    1144:	01c6d713          	srli	a4,a3,0x1c
    1148:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    114a:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    114e:	00001717          	auipc	a4,0x1
    1152:	eaa73923          	sd	a0,-334(a4) # 2000 <freep>
      return (void*)(p + 1);
    1156:	01078513          	addi	a0,a5,16
  }
}
    115a:	70e2                	ld	ra,56(sp)
    115c:	7442                	ld	s0,48(sp)
    115e:	7902                	ld	s2,32(sp)
    1160:	69e2                	ld	s3,24(sp)
    1162:	6121                	addi	sp,sp,64
    1164:	8082                	ret
    1166:	74a2                	ld	s1,40(sp)
    1168:	6a42                	ld	s4,16(sp)
    116a:	6aa2                	ld	s5,8(sp)
    116c:	6b02                	ld	s6,0(sp)
    116e:	b7f5                	j	115a <malloc+0xdc>

0000000000001170 <statistics>:
#include "kernel/fcntl.h"
#include "user/user.h"

int
statistics(void *buf, int sz)
{
    1170:	7179                	addi	sp,sp,-48
    1172:	f406                	sd	ra,40(sp)
    1174:	f022                	sd	s0,32(sp)
    1176:	ec26                	sd	s1,24(sp)
    1178:	e84a                	sd	s2,16(sp)
    117a:	e44e                	sd	s3,8(sp)
    117c:	e052                	sd	s4,0(sp)
    117e:	1800                	addi	s0,sp,48
    1180:	8a2a                	mv	s4,a0
    1182:	892e                	mv	s2,a1
  int fd, i, n;
  
  fd = open("statistics", O_RDONLY);
    1184:	4581                	li	a1,0
    1186:	00000517          	auipc	a0,0x0
    118a:	39a50513          	addi	a0,a0,922 # 1520 <statistics+0x3b0>
    118e:	a49ff0ef          	jal	bd6 <open>
  if(fd < 0) {
    1192:	02054e63          	bltz	a0,11ce <statistics+0x5e>
    1196:	89aa                	mv	s3,a0
      fprintf(2, "stats: open failed\n");
      exit(1);
  }
  for (i = 0; i < sz; ) {
    1198:	4481                	li	s1,0
    119a:	01205e63          	blez	s2,11b6 <statistics+0x46>
    if ((n = read(fd, buf+i, sz-i)) < 0) {
    119e:	4099063b          	subw	a2,s2,s1
    11a2:	009a05b3          	add	a1,s4,s1
    11a6:	854e                	mv	a0,s3
    11a8:	a07ff0ef          	jal	bae <read>
    11ac:	00054563          	bltz	a0,11b6 <statistics+0x46>
      break;
    }
    i += n;
    11b0:	9ca9                	addw	s1,s1,a0
  for (i = 0; i < sz; ) {
    11b2:	ff24c6e3          	blt	s1,s2,119e <statistics+0x2e>
  }
  close(fd);
    11b6:	854e                	mv	a0,s3
    11b8:	a07ff0ef          	jal	bbe <close>
  return i;
}
    11bc:	8526                	mv	a0,s1
    11be:	70a2                	ld	ra,40(sp)
    11c0:	7402                	ld	s0,32(sp)
    11c2:	64e2                	ld	s1,24(sp)
    11c4:	6942                	ld	s2,16(sp)
    11c6:	69a2                	ld	s3,8(sp)
    11c8:	6a02                	ld	s4,0(sp)
    11ca:	6145                	addi	sp,sp,48
    11cc:	8082                	ret
      fprintf(2, "stats: open failed\n");
    11ce:	00000597          	auipc	a1,0x0
    11d2:	36258593          	addi	a1,a1,866 # 1530 <statistics+0x3c0>
    11d6:	4509                	li	a0,2
    11d8:	dc5ff0ef          	jal	f9c <fprintf>
      exit(1);
    11dc:	4505                	li	a0,1
    11de:	9b9ff0ef          	jal	b96 <exit>
