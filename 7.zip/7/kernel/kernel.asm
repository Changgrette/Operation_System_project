
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	0001c117          	auipc	sp,0x1c
    80000004:	5b010113          	addi	sp,sp,1456 # 8001c5b0 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	6f4050ef          	jal	8000570a <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <try_take_batch_from>:
 * return head of stolen list and set *stolen to number taken. Caller must not
 * hold dst lock. We hold src lock only long enough to split the list.
 */
static struct run*
try_take_batch_from(int src, int want, int *stolen)
{
    8000001c:	7139                	addi	sp,sp,-64
    8000001e:	fc06                	sd	ra,56(sp)
    80000020:	f822                	sd	s0,48(sp)
    80000022:	f426                	sd	s1,40(sp)
    80000024:	f04a                	sd	s2,32(sp)
    80000026:	ec4e                	sd	s3,24(sp)
    80000028:	e852                	sd	s4,16(sp)
    8000002a:	e456                	sd	s5,8(sp)
    8000002c:	0080                	addi	s0,sp,64
    8000002e:	892a                	mv	s2,a0
    80000030:	84ae                	mv	s1,a1
    80000032:	8ab2                	mv	s5,a2
    struct run *head;

    acquire(&kmem[src].lock);
    80000034:	00251793          	slli	a5,a0,0x2
    80000038:	97aa                	add	a5,a5,a0
    8000003a:	078e                	slli	a5,a5,0x3
    8000003c:	00009997          	auipc	s3,0x9
    80000040:	9d498993          	addi	s3,s3,-1580 # 80008a10 <kmem>
    80000044:	99be                	add	s3,s3,a5
    80000046:	854e                	mv	a0,s3
    80000048:	15e060ef          	jal	800061a6 <acquire>
    head = kmem[src].freelist;
    8000004c:	0209ba03          	ld	s4,32(s3)
        return 0;
    }

    // count available (cheap linear scan)
    int avail = 0;
    struct run *p = head;
    80000050:	8752                	mv	a4,s4
    int avail = 0;
    80000052:	4781                	li	a5,0
    if(!head){
    80000054:	060a0b63          	beqz	s4,800000ca <try_take_batch_from+0xae>
    while(p){
        avail++;
    80000058:	2785                	addiw	a5,a5,1
        p = p->next;
        if(avail >= want) break; // no need to traverse full list if we already have enough
    8000005a:	0897d263          	bge	a5,s1,800000de <try_take_batch_from+0xc2>
        p = p->next;
    8000005e:	6318                	ld	a4,0(a4)
    while(p){
    80000060:	ff65                	bnez	a4,80000058 <try_take_batch_from+0x3c>
    80000062:	84d2                	mv	s1,s4
    80000064:	4781                	li	a5,0
        // count full list to get true avail if we broke early
        if(avail < want){
            // finish counting full list
            p = head;
            avail = 0;
            while(p){ avail++; p = p->next; }
    80000066:	0017871b          	addiw	a4,a5,1
    8000006a:	87ba                	mv	a5,a4
    8000006c:	6084                	ld	s1,0(s1)
    8000006e:	fce5                	bnez	s1,80000066 <try_take_batch_from+0x4a>
        }
        if(avail <= 1){
    80000070:	4685                	li	a3,1
    80000072:	06e6d163          	bge	a3,a4,800000d4 <try_take_batch_from+0xb8>
            // don't steal if only 0 or 1 (leave small lists alone)
            release(&kmem[src].lock);
            *stolen = 0;
            return 0;
        }
        take = avail / 2;
    80000076:	01f7549b          	srliw	s1,a4,0x1f
    8000007a:	9cb9                	addw	s1,s1,a4
    8000007c:	4014d49b          	sraiw	s1,s1,0x1
    }

    // now split the first 'take' nodes
    struct run *prev = 0;
    p = head;
    for(int i = 0; i < take && p; i++){
    80000080:	87d2                	mv	a5,s4
    80000082:	4681                	li	a3,0
        prev = p;
        p = p->next;
    80000084:	863e                	mv	a2,a5
    80000086:	639c                	ld	a5,0(a5)
    for(int i = 0; i < take && p; i++){
    80000088:	0016871b          	addiw	a4,a3,1
    8000008c:	86ba                	mv	a3,a4
    8000008e:	00975363          	bge	a4,s1,80000094 <try_take_batch_from+0x78>
    80000092:	fbed                	bnez	a5,80000084 <try_take_batch_from+0x68>
    }
    // prev is tail of taken chunk, p is remainder
    if(prev)
        prev->next = 0;
    80000094:	00063023          	sd	zero,0(a2)
    kmem[src].freelist = p;
    80000098:	00291713          	slli	a4,s2,0x2
    8000009c:	974a                	add	a4,a4,s2
    8000009e:	070e                	slli	a4,a4,0x3
    800000a0:	00009697          	auipc	a3,0x9
    800000a4:	97068693          	addi	a3,a3,-1680 # 80008a10 <kmem>
    800000a8:	9736                	add	a4,a4,a3
    800000aa:	f31c                	sd	a5,32(a4)
    release(&kmem[src].lock);
    800000ac:	854e                	mv	a0,s3
    800000ae:	1a0060ef          	jal	8000624e <release>
        *stolen = 0;
    800000b2:	009aa023          	sw	s1,0(s5)

    *stolen = take;
    return head;
}
    800000b6:	8552                	mv	a0,s4
    800000b8:	70e2                	ld	ra,56(sp)
    800000ba:	7442                	ld	s0,48(sp)
    800000bc:	74a2                	ld	s1,40(sp)
    800000be:	7902                	ld	s2,32(sp)
    800000c0:	69e2                	ld	s3,24(sp)
    800000c2:	6a42                	ld	s4,16(sp)
    800000c4:	6aa2                	ld	s5,8(sp)
    800000c6:	6121                	addi	sp,sp,64
    800000c8:	8082                	ret
        release(&kmem[src].lock);
    800000ca:	854e                	mv	a0,s3
    800000cc:	182060ef          	jal	8000624e <release>
        return 0;
    800000d0:	4481                	li	s1,0
    800000d2:	b7c5                	j	800000b2 <try_take_batch_from+0x96>
            release(&kmem[src].lock);
    800000d4:	854e                	mv	a0,s3
    800000d6:	178060ef          	jal	8000624e <release>
            return 0;
    800000da:	8a26                	mv	s4,s1
    800000dc:	bfd9                	j	800000b2 <try_take_batch_from+0x96>
    p = head;
    800000de:	87d2                	mv	a5,s4
    for(int i = 0; i < take && p; i++){
    800000e0:	fa9040e3          	bgtz	s1,80000080 <try_take_batch_from+0x64>
    800000e4:	bf55                	j	80000098 <try_take_batch_from+0x7c>

00000000800000e6 <attach_batch_to_cpu>:
 * Caller must ensure head != 0 and nodes terminated with next==0 at tail.
 */
static void
attach_batch_to_cpu(int dst, struct run *head)
{
    if(!head) return;
    800000e6:	c5b5                	beqz	a1,80000152 <attach_batch_to_cpu+0x6c>
{
    800000e8:	7179                	addi	sp,sp,-48
    800000ea:	f406                	sd	ra,40(sp)
    800000ec:	f022                	sd	s0,32(sp)
    800000ee:	ec26                	sd	s1,24(sp)
    800000f0:	e84a                	sd	s2,16(sp)
    800000f2:	e44e                	sd	s3,8(sp)
    800000f4:	1800                	addi	s0,sp,48
    800000f6:	84aa                	mv	s1,a0
    800000f8:	892e                	mv	s2,a1
    acquire(&kmem[dst].lock);
    800000fa:	00251793          	slli	a5,a0,0x2
    800000fe:	97aa                	add	a5,a5,a0
    80000100:	078e                	slli	a5,a5,0x3
    80000102:	00009717          	auipc	a4,0x9
    80000106:	90e70713          	addi	a4,a4,-1778 # 80008a10 <kmem>
    8000010a:	97ba                	add	a5,a5,a4
    8000010c:	89be                	mv	s3,a5
    8000010e:	853e                	mv	a0,a5
    80000110:	096060ef          	jal	800061a6 <acquire>
    // find tail of head
    struct run *t = head;
    80000114:	87ca                	mv	a5,s2
    while(t->next) t = t->next;
    80000116:	873e                	mv	a4,a5
    80000118:	639c                	ld	a5,0(a5)
    8000011a:	fff5                	bnez	a5,80000116 <attach_batch_to_cpu+0x30>
    t->next = kmem[dst].freelist;
    8000011c:	00009617          	auipc	a2,0x9
    80000120:	8f460613          	addi	a2,a2,-1804 # 80008a10 <kmem>
    80000124:	00249793          	slli	a5,s1,0x2
    80000128:	009786b3          	add	a3,a5,s1
    8000012c:	068e                	slli	a3,a3,0x3
    8000012e:	96b2                	add	a3,a3,a2
    80000130:	7294                	ld	a3,32(a3)
    80000132:	e314                	sd	a3,0(a4)
    kmem[dst].freelist = head;
    80000134:	97a6                	add	a5,a5,s1
    80000136:	078e                	slli	a5,a5,0x3
    80000138:	963e                	add	a2,a2,a5
    8000013a:	03263023          	sd	s2,32(a2)
    release(&kmem[dst].lock);
    8000013e:	854e                	mv	a0,s3
    80000140:	10e060ef          	jal	8000624e <release>
}
    80000144:	70a2                	ld	ra,40(sp)
    80000146:	7402                	ld	s0,32(sp)
    80000148:	64e2                	ld	s1,24(sp)
    8000014a:	6942                	ld	s2,16(sp)
    8000014c:	69a2                	ld	s3,8(sp)
    8000014e:	6145                	addi	sp,sp,48
    80000150:	8082                	ret
    80000152:	8082                	ret

0000000080000154 <freerange>:
{
    80000154:	715d                	addi	sp,sp,-80
    80000156:	e486                	sd	ra,72(sp)
    80000158:	e0a2                	sd	s0,64(sp)
    8000015a:	f44e                	sd	s3,40(sp)
    8000015c:	0880                	addi	s0,sp,80
    p = (char*)PGROUNDUP((uint64)pa_start);
    8000015e:	6785                	lui	a5,0x1
    80000160:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000164:	00e509b3          	add	s3,a0,a4
    80000168:	777d                	lui	a4,0xfffff
    8000016a:	00e9f9b3          	and	s3,s3,a4
    for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    8000016e:	99be                	add	s3,s3,a5
    80000170:	0735e863          	bltu	a1,s3,800001e0 <freerange+0x8c>
    80000174:	fc26                	sd	s1,56(sp)
    80000176:	f84a                	sd	s2,48(sp)
    80000178:	f052                	sd	s4,32(sp)
    8000017a:	ec56                	sd	s5,24(sp)
    8000017c:	e85a                	sd	s6,16(sp)
    8000017e:	e45e                	sd	s7,8(sp)
    80000180:	e062                	sd	s8,0(sp)
    80000182:	8a2e                	mv	s4,a1
    int cid = 0;
    80000184:	4481                	li	s1,0
    80000186:	8bba                	mv	s7,a4
        acquire(&kmem[cid].lock);
    80000188:	00009b17          	auipc	s6,0x9
    8000018c:	888b0b13          	addi	s6,s6,-1912 # 80008a10 <kmem>
    for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    80000190:	8abe                	mv	s5,a5
    80000192:	01798c33          	add	s8,s3,s7
        r->next = 0;
    80000196:	000c3023          	sd	zero,0(s8)
        acquire(&kmem[cid].lock);
    8000019a:	00249913          	slli	s2,s1,0x2
    8000019e:	9926                	add	s2,s2,s1
    800001a0:	090e                	slli	s2,s2,0x3
    800001a2:	995a                	add	s2,s2,s6
    800001a4:	854a                	mv	a0,s2
    800001a6:	000060ef          	jal	800061a6 <acquire>
        r->next = kmem[cid].freelist;
    800001aa:	02093783          	ld	a5,32(s2)
    800001ae:	00fc3023          	sd	a5,0(s8)
        kmem[cid].freelist = r;
    800001b2:	03893023          	sd	s8,32(s2)
        release(&kmem[cid].lock);
    800001b6:	854a                	mv	a0,s2
    800001b8:	096060ef          	jal	8000624e <release>
        cid = (cid + 1) % NCPU;
    800001bc:	2485                	addiw	s1,s1,1
    800001be:	41f4d79b          	sraiw	a5,s1,0x1f
    800001c2:	01d7d79b          	srliw	a5,a5,0x1d
    800001c6:	9cbd                	addw	s1,s1,a5
    800001c8:	889d                	andi	s1,s1,7
    800001ca:	9c9d                	subw	s1,s1,a5
    for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    800001cc:	99d6                	add	s3,s3,s5
    800001ce:	fd3a72e3          	bgeu	s4,s3,80000192 <freerange+0x3e>
    800001d2:	74e2                	ld	s1,56(sp)
    800001d4:	7942                	ld	s2,48(sp)
    800001d6:	7a02                	ld	s4,32(sp)
    800001d8:	6ae2                	ld	s5,24(sp)
    800001da:	6b42                	ld	s6,16(sp)
    800001dc:	6ba2                	ld	s7,8(sp)
    800001de:	6c02                	ld	s8,0(sp)
}
    800001e0:	60a6                	ld	ra,72(sp)
    800001e2:	6406                	ld	s0,64(sp)
    800001e4:	79a2                	ld	s3,40(sp)
    800001e6:	6161                	addi	sp,sp,80
    800001e8:	8082                	ret

00000000800001ea <kinit>:
{
    800001ea:	711d                	addi	sp,sp,-96
    800001ec:	ec86                	sd	ra,88(sp)
    800001ee:	e8a2                	sd	s0,80(sp)
    800001f0:	e4a6                	sd	s1,72(sp)
    800001f2:	e0ca                	sd	s2,64(sp)
    800001f4:	fc4e                	sd	s3,56(sp)
    800001f6:	f852                	sd	s4,48(sp)
    800001f8:	f456                	sd	s5,40(sp)
    800001fa:	f05a                	sd	s6,32(sp)
    800001fc:	ec5e                	sd	s7,24(sp)
    800001fe:	1080                	addi	s0,sp,96
    for(i = 0; i < NCPU; i++){
    80000200:	00009917          	auipc	s2,0x9
    80000204:	81090913          	addi	s2,s2,-2032 # 80008a10 <kmem>
    80000208:	00009997          	auipc	s3,0x9
    8000020c:	94898993          	addi	s3,s3,-1720 # 80008b50 <steal_cursor>
    80000210:	4481                	li	s1,0
        snprintf(lockname, sizeof(lockname), "kmem_%d", i);
    80000212:	fa040a13          	addi	s4,s0,-96
    80000216:	00008b97          	auipc	s7,0x8
    8000021a:	deab8b93          	addi	s7,s7,-534 # 80008000 <etext>
    8000021e:	4b31                	li	s6,12
    for(i = 0; i < NCPU; i++){
    80000220:	4aa1                	li	s5,8
        snprintf(lockname, sizeof(lockname), "kmem_%d", i);
    80000222:	86a6                	mv	a3,s1
    80000224:	865e                	mv	a2,s7
    80000226:	85da                	mv	a1,s6
    80000228:	8552                	mv	a0,s4
    8000022a:	31e050ef          	jal	80005548 <snprintf>
        initlock(&kmem[i].lock, lockname);
    8000022e:	85d2                	mv	a1,s4
    80000230:	854a                	mv	a0,s2
    80000232:	0b4060ef          	jal	800062e6 <initlock>
        kmem[i].freelist = 0;
    80000236:	02093023          	sd	zero,32(s2)
        steal_cursor[i] = (i + 1) % NCPU; // start search at a different offset
    8000023a:	0014879b          	addiw	a5,s1,1
    8000023e:	84be                	mv	s1,a5
    80000240:	41f7d71b          	sraiw	a4,a5,0x1f
    80000244:	01d7571b          	srliw	a4,a4,0x1d
    80000248:	9fb9                	addw	a5,a5,a4
    8000024a:	8b9d                	andi	a5,a5,7
    8000024c:	9f99                	subw	a5,a5,a4
    8000024e:	00f9a023          	sw	a5,0(s3)
    for(i = 0; i < NCPU; i++){
    80000252:	02890913          	addi	s2,s2,40
    80000256:	0991                	addi	s3,s3,4
    80000258:	fd5495e3          	bne	s1,s5,80000222 <kinit+0x38>
    freerange(end, (void*)PHYSTOP);
    8000025c:	45c5                	li	a1,17
    8000025e:	05ee                	slli	a1,a1,0x1b
    80000260:	00025517          	auipc	a0,0x25
    80000264:	42850513          	addi	a0,a0,1064 # 80025688 <end>
    80000268:	eedff0ef          	jal	80000154 <freerange>
}
    8000026c:	60e6                	ld	ra,88(sp)
    8000026e:	6446                	ld	s0,80(sp)
    80000270:	64a6                	ld	s1,72(sp)
    80000272:	6906                	ld	s2,64(sp)
    80000274:	79e2                	ld	s3,56(sp)
    80000276:	7a42                	ld	s4,48(sp)
    80000278:	7aa2                	ld	s5,40(sp)
    8000027a:	7b02                	ld	s6,32(sp)
    8000027c:	6be2                	ld	s7,24(sp)
    8000027e:	6125                	addi	sp,sp,96
    80000280:	8082                	ret

0000000080000282 <kfree>:
{
    80000282:	7139                	addi	sp,sp,-64
    80000284:	fc06                	sd	ra,56(sp)
    80000286:	f822                	sd	s0,48(sp)
    80000288:	f426                	sd	s1,40(sp)
    8000028a:	f04a                	sd	s2,32(sp)
    8000028c:	ec4e                	sd	s3,24(sp)
    8000028e:	e852                	sd	s4,16(sp)
    80000290:	e456                	sd	s5,8(sp)
    80000292:	0080                	addi	s0,sp,64
    if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000294:	00025797          	auipc	a5,0x25
    80000298:	3f478793          	addi	a5,a5,1012 # 80025688 <end>
    8000029c:	00f53733          	sltu	a4,a0,a5
    800002a0:	47c5                	li	a5,17
    800002a2:	07ee                	slli	a5,a5,0x1b
    800002a4:	17fd                	addi	a5,a5,-1
    800002a6:	00a7b7b3          	sltu	a5,a5,a0
    800002aa:	8fd9                	or	a5,a5,a4
    800002ac:	efa9                	bnez	a5,80000306 <kfree+0x84>
    800002ae:	84aa                	mv	s1,a0
    800002b0:	03451793          	slli	a5,a0,0x34
    800002b4:	eba9                	bnez	a5,80000306 <kfree+0x84>
    memset(pa, 1, PGSIZE);
    800002b6:	6605                	lui	a2,0x1
    800002b8:	4585                	li	a1,1
    800002ba:	21e000ef          	jal	800004d8 <memset>
    push_off();
    800002be:	6a5050ef          	jal	80006162 <push_off>
    int c = cpuid();
    800002c2:	60f000ef          	jal	800010d0 <cpuid>
    acquire(&kmem[c].lock);
    800002c6:	00008a97          	auipc	s5,0x8
    800002ca:	74aa8a93          	addi	s5,s5,1866 # 80008a10 <kmem>
    800002ce:	00251993          	slli	s3,a0,0x2
    800002d2:	00a98933          	add	s2,s3,a0
    800002d6:	090e                	slli	s2,s2,0x3
    800002d8:	9956                	add	s2,s2,s5
    800002da:	854a                	mv	a0,s2
    800002dc:	6cb050ef          	jal	800061a6 <acquire>
    r->next = kmem[c].freelist;
    800002e0:	02093783          	ld	a5,32(s2)
    800002e4:	e09c                	sd	a5,0(s1)
    kmem[c].freelist = r;
    800002e6:	02993023          	sd	s1,32(s2)
    release(&kmem[c].lock);
    800002ea:	854a                	mv	a0,s2
    800002ec:	763050ef          	jal	8000624e <release>
    pop_off();
    800002f0:	70f050ef          	jal	800061fe <pop_off>
}
    800002f4:	70e2                	ld	ra,56(sp)
    800002f6:	7442                	ld	s0,48(sp)
    800002f8:	74a2                	ld	s1,40(sp)
    800002fa:	7902                	ld	s2,32(sp)
    800002fc:	69e2                	ld	s3,24(sp)
    800002fe:	6a42                	ld	s4,16(sp)
    80000300:	6aa2                	ld	s5,8(sp)
    80000302:	6121                	addi	sp,sp,64
    80000304:	8082                	ret
        panic("kfree");
    80000306:	00008517          	auipc	a0,0x8
    8000030a:	d0250513          	addi	a0,a0,-766 # 80008008 <etext+0x8>
    8000030e:	375050ef          	jal	80005e82 <panic>

0000000080000312 <kalloc>:

// Allocate one 4096-byte page of physical memory.
void *
kalloc(void)
{
    80000312:	7119                	addi	sp,sp,-128
    80000314:	fc86                	sd	ra,120(sp)
    80000316:	f8a2                	sd	s0,112(sp)
    80000318:	ecce                	sd	s3,88(sp)
    8000031a:	e8d2                	sd	s4,80(sp)
    8000031c:	e0da                	sd	s6,64(sp)
    8000031e:	0100                	addi	s0,sp,128
    struct run *r = 0;

    // only disable interrupts to read cpuid
    push_off();
    80000320:	643050ef          	jal	80006162 <push_off>
    int c = cpuid();
    80000324:	5ad000ef          	jal	800010d0 <cpuid>
    80000328:	89aa                	mv	s3,a0
    pop_off();
    8000032a:	6d5050ef          	jal	800061fe <pop_off>

    // fast path: local freelist
    acquire(&kmem[c].lock);
    8000032e:	00299793          	slli	a5,s3,0x2
    80000332:	97ce                	add	a5,a5,s3
    80000334:	078e                	slli	a5,a5,0x3
    80000336:	00008a17          	auipc	s4,0x8
    8000033a:	6daa0a13          	addi	s4,s4,1754 # 80008a10 <kmem>
    8000033e:	9a3e                	add	s4,s4,a5
    80000340:	8552                	mv	a0,s4
    80000342:	665050ef          	jal	800061a6 <acquire>
    r = kmem[c].freelist;
    80000346:	020a3b03          	ld	s6,32(s4)
    if(r)
    8000034a:	140b0263          	beqz	s6,8000048e <kalloc+0x17c>
        kmem[c].freelist = r->next;
    8000034e:	000b3683          	ld	a3,0(s6)
    80000352:	02da3023          	sd	a3,32(s4)
    release(&kmem[c].lock);
    80000356:	8552                	mv	a0,s4
    80000358:	6f7050ef          	jal	8000624e <release>

    if(r) {
        memset((char*)r, 5, PGSIZE);
    8000035c:	6605                	lui	a2,0x1
    8000035e:	4595                	li	a1,5
    80000360:	855a                	mv	a0,s6
    80000362:	176000ef          	jal	800004d8 <memset>
    }

    if(r)
        memset((char*)r, 5, PGSIZE);
    return (void*)r;
}
    80000366:	855a                	mv	a0,s6
    80000368:	70e6                	ld	ra,120(sp)
    8000036a:	7446                	ld	s0,112(sp)
    8000036c:	69e6                	ld	s3,88(sp)
    8000036e:	6a46                	ld	s4,80(sp)
    80000370:	6b06                	ld	s6,64(sp)
    80000372:	6109                	addi	sp,sp,128
    80000374:	8082                	ret
        for(int other = 0; other < NCPU; other++){
    80000376:	4901                	li	s2,0
            struct run *batch = try_take_batch_from(other, STEAL_MIN * 8, &stolen);
    80000378:	f8c40c13          	addi	s8,s0,-116
    8000037c:	10000b93          	li	s7,256
        for(int other = 0; other < NCPU; other++){
    80000380:	4aa1                	li	s5,8
    80000382:	a005                	j	800003a2 <kalloc+0x90>
    80000384:	74a6                	ld	s1,104(sp)
    80000386:	7906                	ld	s2,96(sp)
    80000388:	6aa6                	ld	s5,72(sp)
    8000038a:	7be2                	ld	s7,56(sp)
    8000038c:	7c42                	ld	s8,48(sp)
    8000038e:	7ca2                	ld	s9,40(sp)
    80000390:	7d02                	ld	s10,32(sp)
    80000392:	6de2                	ld	s11,24(sp)
    80000394:	bfc9                	j	80000366 <kalloc+0x54>
                release(&kmem[c].lock);
    80000396:	8552                	mv	a0,s4
    80000398:	6b7050ef          	jal	8000624e <release>
        for(int other = 0; other < NCPU; other++){
    8000039c:	2905                	addiw	s2,s2,1
    8000039e:	ff5903e3          	beq	s2,s5,80000384 <kalloc+0x72>
            if(other == c) continue;
    800003a2:	ff298de3          	beq	s3,s2,8000039c <kalloc+0x8a>
            struct run *batch = try_take_batch_from(other, STEAL_MIN * 8, &stolen);
    800003a6:	8662                	mv	a2,s8
    800003a8:	85de                	mv	a1,s7
    800003aa:	854a                	mv	a0,s2
    800003ac:	c71ff0ef          	jal	8000001c <try_take_batch_from>
            if(stolen > 0 && batch){
    800003b0:	f8c42783          	lw	a5,-116(s0)
    800003b4:	fef054e3          	blez	a5,8000039c <kalloc+0x8a>
    800003b8:	d175                	beqz	a0,8000039c <kalloc+0x8a>
                attach_batch_to_cpu(c, batch);
    800003ba:	85aa                	mv	a1,a0
    800003bc:	854e                	mv	a0,s3
    800003be:	d29ff0ef          	jal	800000e6 <attach_batch_to_cpu>
                acquire(&kmem[c].lock);
    800003c2:	8552                	mv	a0,s4
    800003c4:	5e3050ef          	jal	800061a6 <acquire>
                r = kmem[c].freelist;
    800003c8:	00299793          	slli	a5,s3,0x2
    800003cc:	97ce                	add	a5,a5,s3
    800003ce:	078e                	slli	a5,a5,0x3
    800003d0:	00008717          	auipc	a4,0x8
    800003d4:	64070713          	addi	a4,a4,1600 # 80008a10 <kmem>
    800003d8:	97ba                	add	a5,a5,a4
    800003da:	7384                	ld	s1,32(a5)
                if(r)
    800003dc:	dccd                	beqz	s1,80000396 <kalloc+0x84>
                    kmem[c].freelist = r->next;
    800003de:	6094                	ld	a3,0(s1)
    800003e0:	00299793          	slli	a5,s3,0x2
    800003e4:	97ce                	add	a5,a5,s3
    800003e6:	078e                	slli	a5,a5,0x3
    800003e8:	97ba                	add	a5,a5,a4
    800003ea:	f394                	sd	a3,32(a5)
                release(&kmem[c].lock);
    800003ec:	8552                	mv	a0,s4
    800003ee:	661050ef          	jal	8000624e <release>
    if(r)
    800003f2:	a8bd                	j	80000470 <kalloc+0x15e>
            release(&kmem[c].lock);
    800003f4:	8552                	mv	a0,s4
    800003f6:	659050ef          	jal	8000624e <release>
    for(int i = 0; i < NCPU; i++){
    800003fa:	2905                	addiw	s2,s2,1
    800003fc:	f7590de3          	beq	s2,s5,80000376 <kalloc+0x64>
        int other = (start + i) % NCPU;
    80000400:	41f9579b          	sraiw	a5,s2,0x1f
    80000404:	01d7d79b          	srliw	a5,a5,0x1d
    80000408:	012784bb          	addw	s1,a5,s2
    8000040c:	889d                	andi	s1,s1,7
    8000040e:	9c9d                	subw	s1,s1,a5
        if(other == c) continue;
    80000410:	fe9985e3          	beq	s3,s1,800003fa <kalloc+0xe8>
        struct run *batch = try_take_batch_from(other, STEAL_MIN, &stolen);
    80000414:	8662                	mv	a2,s8
    80000416:	85de                	mv	a1,s7
    80000418:	8526                	mv	a0,s1
    8000041a:	c03ff0ef          	jal	8000001c <try_take_batch_from>
        if(stolen > 0 && batch){
    8000041e:	f8c42783          	lw	a5,-116(s0)
    80000422:	fcf05ce3          	blez	a5,800003fa <kalloc+0xe8>
    80000426:	d971                	beqz	a0,800003fa <kalloc+0xe8>
            attach_batch_to_cpu(c, batch);
    80000428:	85aa                	mv	a1,a0
    8000042a:	854e                	mv	a0,s3
    8000042c:	cbbff0ef          	jal	800000e6 <attach_batch_to_cpu>
            steal_cursor[c] = (other + 1) % NCPU;
    80000430:	01ac8733          	add	a4,s9,s10
    80000434:	2485                	addiw	s1,s1,1
    80000436:	41f4d79b          	sraiw	a5,s1,0x1f
    8000043a:	01d7d79b          	srliw	a5,a5,0x1d
    8000043e:	9cbd                	addw	s1,s1,a5
    80000440:	889d                	andi	s1,s1,7
    80000442:	9c9d                	subw	s1,s1,a5
    80000444:	14972023          	sw	s1,320(a4)
            acquire(&kmem[c].lock);
    80000448:	8552                	mv	a0,s4
    8000044a:	55d050ef          	jal	800061a6 <acquire>
            r = kmem[c].freelist;
    8000044e:	020db483          	ld	s1,32(s11)
            if(r)
    80000452:	d0cd                	beqz	s1,800003f4 <kalloc+0xe2>
                kmem[c].freelist = r->next;
    80000454:	6094                	ld	a3,0(s1)
    80000456:	00299793          	slli	a5,s3,0x2
    8000045a:	97ce                	add	a5,a5,s3
    8000045c:	078e                	slli	a5,a5,0x3
    8000045e:	00008717          	auipc	a4,0x8
    80000462:	5b270713          	addi	a4,a4,1458 # 80008a10 <kmem>
    80000466:	97ba                	add	a5,a5,a4
    80000468:	f394                	sd	a3,32(a5)
            release(&kmem[c].lock);
    8000046a:	8552                	mv	a0,s4
    8000046c:	5e3050ef          	jal	8000624e <release>
        memset((char*)r, 5, PGSIZE);
    80000470:	6605                	lui	a2,0x1
    80000472:	4595                	li	a1,5
    80000474:	8526                	mv	a0,s1
    80000476:	062000ef          	jal	800004d8 <memset>
    8000047a:	8b26                	mv	s6,s1
    8000047c:	74a6                	ld	s1,104(sp)
    8000047e:	7906                	ld	s2,96(sp)
    80000480:	6aa6                	ld	s5,72(sp)
    80000482:	7be2                	ld	s7,56(sp)
    80000484:	7c42                	ld	s8,48(sp)
    80000486:	7ca2                	ld	s9,40(sp)
    80000488:	7d02                	ld	s10,32(sp)
    8000048a:	6de2                	ld	s11,24(sp)
    8000048c:	bde9                	j	80000366 <kalloc+0x54>
    8000048e:	f4a6                	sd	s1,104(sp)
    80000490:	f0ca                	sd	s2,96(sp)
    80000492:	e4d6                	sd	s5,72(sp)
    80000494:	fc5e                	sd	s7,56(sp)
    80000496:	f862                	sd	s8,48(sp)
    80000498:	f466                	sd	s9,40(sp)
    8000049a:	f06a                	sd	s10,32(sp)
    8000049c:	ec6e                	sd	s11,24(sp)
    release(&kmem[c].lock);
    8000049e:	8552                	mv	a0,s4
    800004a0:	5af050ef          	jal	8000624e <release>
    int start = steal_cursor[c];
    800004a4:	00299713          	slli	a4,s3,0x2
    800004a8:	00008797          	auipc	a5,0x8
    800004ac:	56878793          	addi	a5,a5,1384 # 80008a10 <kmem>
    800004b0:	97ba                	add	a5,a5,a4
    800004b2:	1407a903          	lw	s2,320(a5)
    800004b6:	00890a9b          	addiw	s5,s2,8
        struct run *batch = try_take_batch_from(other, STEAL_MIN, &stolen);
    800004ba:	f8c40c13          	addi	s8,s0,-116
    800004be:	02000b93          	li	s7,32
            steal_cursor[c] = (other + 1) % NCPU;
    800004c2:	00008c97          	auipc	s9,0x8
    800004c6:	54ec8c93          	addi	s9,s9,1358 # 80008a10 <kmem>
    800004ca:	8d3a                	mv	s10,a4
            r = kmem[c].freelist;
    800004cc:	013707b3          	add	a5,a4,s3
    800004d0:	078e                	slli	a5,a5,0x3
    800004d2:	97e6                	add	a5,a5,s9
    800004d4:	8dbe                	mv	s11,a5
    800004d6:	b72d                	j	80000400 <kalloc+0xee>

00000000800004d8 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    800004d8:	1141                	addi	sp,sp,-16
    800004da:	e406                	sd	ra,8(sp)
    800004dc:	e022                	sd	s0,0(sp)
    800004de:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    800004e0:	ca19                	beqz	a2,800004f6 <memset+0x1e>
    800004e2:	87aa                	mv	a5,a0
    800004e4:	1602                	slli	a2,a2,0x20
    800004e6:	9201                	srli	a2,a2,0x20
    800004e8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    800004ec:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    800004f0:	0785                	addi	a5,a5,1
    800004f2:	fee79de3          	bne	a5,a4,800004ec <memset+0x14>
  }
  return dst;
}
    800004f6:	60a2                	ld	ra,8(sp)
    800004f8:	6402                	ld	s0,0(sp)
    800004fa:	0141                	addi	sp,sp,16
    800004fc:	8082                	ret

00000000800004fe <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    800004fe:	1141                	addi	sp,sp,-16
    80000500:	e406                	sd	ra,8(sp)
    80000502:	e022                	sd	s0,0(sp)
    80000504:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000506:	c61d                	beqz	a2,80000534 <memcmp+0x36>
    80000508:	1602                	slli	a2,a2,0x20
    8000050a:	9201                	srli	a2,a2,0x20
    8000050c:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000510:	00054783          	lbu	a5,0(a0)
    80000514:	0005c703          	lbu	a4,0(a1)
    80000518:	00e79863          	bne	a5,a4,80000528 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    8000051c:	0505                	addi	a0,a0,1
    8000051e:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000520:	fed518e3          	bne	a0,a3,80000510 <memcmp+0x12>
  }

  return 0;
    80000524:	4501                	li	a0,0
    80000526:	a019                	j	8000052c <memcmp+0x2e>
      return *s1 - *s2;
    80000528:	40e7853b          	subw	a0,a5,a4
}
    8000052c:	60a2                	ld	ra,8(sp)
    8000052e:	6402                	ld	s0,0(sp)
    80000530:	0141                	addi	sp,sp,16
    80000532:	8082                	ret
  return 0;
    80000534:	4501                	li	a0,0
    80000536:	bfdd                	j	8000052c <memcmp+0x2e>

0000000080000538 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000538:	1141                	addi	sp,sp,-16
    8000053a:	e406                	sd	ra,8(sp)
    8000053c:	e022                	sd	s0,0(sp)
    8000053e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000540:	c205                	beqz	a2,80000560 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000542:	02a5e363          	bltu	a1,a0,80000568 <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000546:	1602                	slli	a2,a2,0x20
    80000548:	9201                	srli	a2,a2,0x20
    8000054a:	00c587b3          	add	a5,a1,a2
{
    8000054e:	872a                	mv	a4,a0
      *d++ = *s++;
    80000550:	0585                	addi	a1,a1,1
    80000552:	0705                	addi	a4,a4,1
    80000554:	fff5c683          	lbu	a3,-1(a1)
    80000558:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    8000055c:	feb79ae3          	bne	a5,a1,80000550 <memmove+0x18>

  return dst;
}
    80000560:	60a2                	ld	ra,8(sp)
    80000562:	6402                	ld	s0,0(sp)
    80000564:	0141                	addi	sp,sp,16
    80000566:	8082                	ret
  if(s < d && s + n > d){
    80000568:	02061693          	slli	a3,a2,0x20
    8000056c:	9281                	srli	a3,a3,0x20
    8000056e:	00d58733          	add	a4,a1,a3
    80000572:	fce57ae3          	bgeu	a0,a4,80000546 <memmove+0xe>
    d += n;
    80000576:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000578:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    8000057c:	1782                	slli	a5,a5,0x20
    8000057e:	9381                	srli	a5,a5,0x20
    80000580:	fff7c793          	not	a5,a5
    80000584:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000586:	177d                	addi	a4,a4,-1
    80000588:	16fd                	addi	a3,a3,-1
    8000058a:	00074603          	lbu	a2,0(a4)
    8000058e:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000592:	fee79ae3          	bne	a5,a4,80000586 <memmove+0x4e>
    80000596:	b7e9                	j	80000560 <memmove+0x28>

0000000080000598 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000598:	1141                	addi	sp,sp,-16
    8000059a:	e406                	sd	ra,8(sp)
    8000059c:	e022                	sd	s0,0(sp)
    8000059e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    800005a0:	f99ff0ef          	jal	80000538 <memmove>
}
    800005a4:	60a2                	ld	ra,8(sp)
    800005a6:	6402                	ld	s0,0(sp)
    800005a8:	0141                	addi	sp,sp,16
    800005aa:	8082                	ret

00000000800005ac <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    800005ac:	1141                	addi	sp,sp,-16
    800005ae:	e406                	sd	ra,8(sp)
    800005b0:	e022                	sd	s0,0(sp)
    800005b2:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    800005b4:	ce11                	beqz	a2,800005d0 <strncmp+0x24>
    800005b6:	00054783          	lbu	a5,0(a0)
    800005ba:	cf89                	beqz	a5,800005d4 <strncmp+0x28>
    800005bc:	0005c703          	lbu	a4,0(a1)
    800005c0:	00f71a63          	bne	a4,a5,800005d4 <strncmp+0x28>
    n--, p++, q++;
    800005c4:	367d                	addiw	a2,a2,-1
    800005c6:	0505                	addi	a0,a0,1
    800005c8:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    800005ca:	f675                	bnez	a2,800005b6 <strncmp+0xa>
  if(n == 0)
    return 0;
    800005cc:	4501                	li	a0,0
    800005ce:	a801                	j	800005de <strncmp+0x32>
    800005d0:	4501                	li	a0,0
    800005d2:	a031                	j	800005de <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    800005d4:	00054503          	lbu	a0,0(a0)
    800005d8:	0005c783          	lbu	a5,0(a1)
    800005dc:	9d1d                	subw	a0,a0,a5
}
    800005de:	60a2                	ld	ra,8(sp)
    800005e0:	6402                	ld	s0,0(sp)
    800005e2:	0141                	addi	sp,sp,16
    800005e4:	8082                	ret

00000000800005e6 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    800005e6:	1141                	addi	sp,sp,-16
    800005e8:	e406                	sd	ra,8(sp)
    800005ea:	e022                	sd	s0,0(sp)
    800005ec:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    800005ee:	87aa                	mv	a5,a0
    800005f0:	a011                	j	800005f4 <strncpy+0xe>
    800005f2:	8636                	mv	a2,a3
    800005f4:	02c05863          	blez	a2,80000624 <strncpy+0x3e>
    800005f8:	fff6069b          	addiw	a3,a2,-1
    800005fc:	8836                	mv	a6,a3
    800005fe:	0785                	addi	a5,a5,1
    80000600:	0005c703          	lbu	a4,0(a1)
    80000604:	fee78fa3          	sb	a4,-1(a5)
    80000608:	0585                	addi	a1,a1,1
    8000060a:	f765                	bnez	a4,800005f2 <strncpy+0xc>
    ;
  while(n-- > 0)
    8000060c:	873e                	mv	a4,a5
    8000060e:	01005b63          	blez	a6,80000624 <strncpy+0x3e>
    80000612:	9fb1                	addw	a5,a5,a2
    80000614:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000616:	0705                	addi	a4,a4,1
    80000618:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    8000061c:	40e786bb          	subw	a3,a5,a4
    80000620:	fed04be3          	bgtz	a3,80000616 <strncpy+0x30>
  return os;
}
    80000624:	60a2                	ld	ra,8(sp)
    80000626:	6402                	ld	s0,0(sp)
    80000628:	0141                	addi	sp,sp,16
    8000062a:	8082                	ret

000000008000062c <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    8000062c:	1141                	addi	sp,sp,-16
    8000062e:	e406                	sd	ra,8(sp)
    80000630:	e022                	sd	s0,0(sp)
    80000632:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000634:	02c05363          	blez	a2,8000065a <safestrcpy+0x2e>
    80000638:	fff6069b          	addiw	a3,a2,-1
    8000063c:	1682                	slli	a3,a3,0x20
    8000063e:	9281                	srli	a3,a3,0x20
    80000640:	96ae                	add	a3,a3,a1
    80000642:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000644:	00d58963          	beq	a1,a3,80000656 <safestrcpy+0x2a>
    80000648:	0585                	addi	a1,a1,1
    8000064a:	0785                	addi	a5,a5,1
    8000064c:	fff5c703          	lbu	a4,-1(a1)
    80000650:	fee78fa3          	sb	a4,-1(a5)
    80000654:	fb65                	bnez	a4,80000644 <safestrcpy+0x18>
    ;
  *s = 0;
    80000656:	00078023          	sb	zero,0(a5)
  return os;
}
    8000065a:	60a2                	ld	ra,8(sp)
    8000065c:	6402                	ld	s0,0(sp)
    8000065e:	0141                	addi	sp,sp,16
    80000660:	8082                	ret

0000000080000662 <strlen>:

int
strlen(const char *s)
{
    80000662:	1141                	addi	sp,sp,-16
    80000664:	e406                	sd	ra,8(sp)
    80000666:	e022                	sd	s0,0(sp)
    80000668:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    8000066a:	00054783          	lbu	a5,0(a0)
    8000066e:	cf91                	beqz	a5,8000068a <strlen+0x28>
    80000670:	00150793          	addi	a5,a0,1
    80000674:	86be                	mv	a3,a5
    80000676:	0785                	addi	a5,a5,1
    80000678:	fff7c703          	lbu	a4,-1(a5)
    8000067c:	ff65                	bnez	a4,80000674 <strlen+0x12>
    8000067e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000682:	60a2                	ld	ra,8(sp)
    80000684:	6402                	ld	s0,0(sp)
    80000686:	0141                	addi	sp,sp,16
    80000688:	8082                	ret
  for(n = 0; s[n]; n++)
    8000068a:	4501                	li	a0,0
    8000068c:	bfdd                	j	80000682 <strlen+0x20>

000000008000068e <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    8000068e:	1101                	addi	sp,sp,-32
    80000690:	ec06                	sd	ra,24(sp)
    80000692:	e822                	sd	s0,16(sp)
    80000694:	e426                	sd	s1,8(sp)
    80000696:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    80000698:	239000ef          	jal	800010d0 <cpuid>
    kcsaninit();
#endif
    __sync_synchronize();
    started = 1;
  } else {
    while(atomic_read4((int *) &started) == 0)
    8000069c:	00008497          	auipc	s1,0x8
    800006a0:	34448493          	addi	s1,s1,836 # 800089e0 <started>
  if(cpuid() == 0){
    800006a4:	c905                	beqz	a0,800006d4 <main+0x46>
    while(atomic_read4((int *) &started) == 0)
    800006a6:	8526                	mv	a0,s1
    800006a8:	4b3050ef          	jal	8000635a <atomic_read4>
    800006ac:	dd6d                	beqz	a0,800006a6 <main+0x18>
      ;
    __sync_synchronize();
    800006ae:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    800006b2:	21f000ef          	jal	800010d0 <cpuid>
    800006b6:	85aa                	mv	a1,a0
    800006b8:	00008517          	auipc	a0,0x8
    800006bc:	97850513          	addi	a0,a0,-1672 # 80008030 <etext+0x30>
    800006c0:	4b2050ef          	jal	80005b72 <printf>
    kvminithart();    // turn on paging
    800006c4:	084000ef          	jal	80000748 <kvminithart>
    trapinithart();   // install kernel trap vector
    800006c8:	52e010ef          	jal	80001bf6 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    800006cc:	71c040ef          	jal	80004de8 <plicinithart>
  }

  scheduler();        
    800006d0:	66b000ef          	jal	8000153a <scheduler>
    consoleinit();
    800006d4:	3c4050ef          	jal	80005a98 <consoleinit>
    statsinit();
    800006d8:	595040ef          	jal	8000546c <statsinit>
    printfinit();
    800006dc:	7e0050ef          	jal	80005ebc <printfinit>
    printf("\n");
    800006e0:	00008517          	auipc	a0,0x8
    800006e4:	93050513          	addi	a0,a0,-1744 # 80008010 <etext+0x10>
    800006e8:	48a050ef          	jal	80005b72 <printf>
    printf("xv6 kernel is booting\n");
    800006ec:	00008517          	auipc	a0,0x8
    800006f0:	92c50513          	addi	a0,a0,-1748 # 80008018 <etext+0x18>
    800006f4:	47e050ef          	jal	80005b72 <printf>
    printf("\n");
    800006f8:	00008517          	auipc	a0,0x8
    800006fc:	91850513          	addi	a0,a0,-1768 # 80008010 <etext+0x10>
    80000700:	472050ef          	jal	80005b72 <printf>
    kinit();         // physical page allocator
    80000704:	ae7ff0ef          	jal	800001ea <kinit>
    kvminit();       // create kernel page table
    80000708:	2cc000ef          	jal	800009d4 <kvminit>
    kvminithart();   // turn on paging
    8000070c:	03c000ef          	jal	80000748 <kvminithart>
    procinit();      // process table
    80000710:	10b000ef          	jal	8000101a <procinit>
    trapinit();      // trap vectors
    80000714:	4be010ef          	jal	80001bd2 <trapinit>
    trapinithart();  // install kernel trap vector
    80000718:	4de010ef          	jal	80001bf6 <trapinithart>
    plicinit();      // set up interrupt controller
    8000071c:	6b2040ef          	jal	80004dce <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000720:	6c8040ef          	jal	80004de8 <plicinithart>
    binit();         // buffer cache
    80000724:	30f010ef          	jal	80002232 <binit>
    iinit();         // inode table
    80000728:	3ce020ef          	jal	80002af6 <iinit>
    fileinit();      // file table
    8000072c:	1c0030ef          	jal	800038ec <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000730:	7a8040ef          	jal	80004ed8 <virtio_disk_init>
    userinit();      // first user process
    80000734:	43b000ef          	jal	8000136e <userinit>
    __sync_synchronize();
    80000738:	0330000f          	fence	rw,rw
    started = 1;
    8000073c:	4785                	li	a5,1
    8000073e:	00008717          	auipc	a4,0x8
    80000742:	2af72123          	sw	a5,674(a4) # 800089e0 <started>
    80000746:	b769                	j	800006d0 <main+0x42>

0000000080000748 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000748:	1141                	addi	sp,sp,-16
    8000074a:	e406                	sd	ra,8(sp)
    8000074c:	e022                	sd	s0,0(sp)
    8000074e:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000750:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000754:	00008797          	auipc	a5,0x8
    80000758:	2947b783          	ld	a5,660(a5) # 800089e8 <kernel_pagetable>
    8000075c:	83b1                	srli	a5,a5,0xc
    8000075e:	577d                	li	a4,-1
    80000760:	177e                	slli	a4,a4,0x3f
    80000762:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000764:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000768:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    8000076c:	60a2                	ld	ra,8(sp)
    8000076e:	6402                	ld	s0,0(sp)
    80000770:	0141                	addi	sp,sp,16
    80000772:	8082                	ret

0000000080000774 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000774:	7139                	addi	sp,sp,-64
    80000776:	fc06                	sd	ra,56(sp)
    80000778:	f822                	sd	s0,48(sp)
    8000077a:	f426                	sd	s1,40(sp)
    8000077c:	f04a                	sd	s2,32(sp)
    8000077e:	ec4e                	sd	s3,24(sp)
    80000780:	e852                	sd	s4,16(sp)
    80000782:	e456                	sd	s5,8(sp)
    80000784:	e05a                	sd	s6,0(sp)
    80000786:	0080                	addi	s0,sp,64
    80000788:	84aa                	mv	s1,a0
    8000078a:	89ae                	mv	s3,a1
    8000078c:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    8000078e:	57fd                	li	a5,-1
    80000790:	83e9                	srli	a5,a5,0x1a
    80000792:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000794:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000796:	04b7e263          	bltu	a5,a1,800007da <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    8000079a:	0149d933          	srl	s2,s3,s4
    8000079e:	1ff97913          	andi	s2,s2,511
    800007a2:	090e                	slli	s2,s2,0x3
    800007a4:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    800007a6:	00093483          	ld	s1,0(s2)
    800007aa:	0014f793          	andi	a5,s1,1
    800007ae:	cf85                	beqz	a5,800007e6 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    800007b0:	80a9                	srli	s1,s1,0xa
    800007b2:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    800007b4:	3a5d                	addiw	s4,s4,-9
    800007b6:	ff5a12e3          	bne	s4,s5,8000079a <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    800007ba:	00c9d513          	srli	a0,s3,0xc
    800007be:	1ff57513          	andi	a0,a0,511
    800007c2:	050e                	slli	a0,a0,0x3
    800007c4:	9526                	add	a0,a0,s1
}
    800007c6:	70e2                	ld	ra,56(sp)
    800007c8:	7442                	ld	s0,48(sp)
    800007ca:	74a2                	ld	s1,40(sp)
    800007cc:	7902                	ld	s2,32(sp)
    800007ce:	69e2                	ld	s3,24(sp)
    800007d0:	6a42                	ld	s4,16(sp)
    800007d2:	6aa2                	ld	s5,8(sp)
    800007d4:	6b02                	ld	s6,0(sp)
    800007d6:	6121                	addi	sp,sp,64
    800007d8:	8082                	ret
    panic("walk");
    800007da:	00008517          	auipc	a0,0x8
    800007de:	86e50513          	addi	a0,a0,-1938 # 80008048 <etext+0x48>
    800007e2:	6a0050ef          	jal	80005e82 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    800007e6:	020b0263          	beqz	s6,8000080a <walk+0x96>
    800007ea:	b29ff0ef          	jal	80000312 <kalloc>
    800007ee:	84aa                	mv	s1,a0
    800007f0:	d979                	beqz	a0,800007c6 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    800007f2:	6605                	lui	a2,0x1
    800007f4:	4581                	li	a1,0
    800007f6:	ce3ff0ef          	jal	800004d8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    800007fa:	00c4d793          	srli	a5,s1,0xc
    800007fe:	07aa                	slli	a5,a5,0xa
    80000800:	0017e793          	ori	a5,a5,1
    80000804:	00f93023          	sd	a5,0(s2)
    80000808:	b775                	j	800007b4 <walk+0x40>
        return 0;
    8000080a:	4501                	li	a0,0
    8000080c:	bf6d                	j	800007c6 <walk+0x52>

000000008000080e <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000080e:	57fd                	li	a5,-1
    80000810:	83e9                	srli	a5,a5,0x1a
    80000812:	00b7f463          	bgeu	a5,a1,8000081a <walkaddr+0xc>
    return 0;
    80000816:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000818:	8082                	ret
{
    8000081a:	1141                	addi	sp,sp,-16
    8000081c:	e406                	sd	ra,8(sp)
    8000081e:	e022                	sd	s0,0(sp)
    80000820:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000822:	4601                	li	a2,0
    80000824:	f51ff0ef          	jal	80000774 <walk>
  if(pte == 0)
    80000828:	c901                	beqz	a0,80000838 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    8000082a:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000082c:	0117f693          	andi	a3,a5,17
    80000830:	4745                	li	a4,17
    return 0;
    80000832:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000834:	00e68663          	beq	a3,a4,80000840 <walkaddr+0x32>
}
    80000838:	60a2                	ld	ra,8(sp)
    8000083a:	6402                	ld	s0,0(sp)
    8000083c:	0141                	addi	sp,sp,16
    8000083e:	8082                	ret
  pa = PTE2PA(*pte);
    80000840:	83a9                	srli	a5,a5,0xa
    80000842:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000846:	bfcd                	j	80000838 <walkaddr+0x2a>

0000000080000848 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000848:	715d                	addi	sp,sp,-80
    8000084a:	e486                	sd	ra,72(sp)
    8000084c:	e0a2                	sd	s0,64(sp)
    8000084e:	fc26                	sd	s1,56(sp)
    80000850:	f84a                	sd	s2,48(sp)
    80000852:	f44e                	sd	s3,40(sp)
    80000854:	f052                	sd	s4,32(sp)
    80000856:	ec56                	sd	s5,24(sp)
    80000858:	e85a                	sd	s6,16(sp)
    8000085a:	e45e                	sd	s7,8(sp)
    8000085c:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000085e:	03459793          	slli	a5,a1,0x34
    80000862:	eba1                	bnez	a5,800008b2 <mappages+0x6a>
    80000864:	8a2a                	mv	s4,a0
    80000866:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80000868:	03461793          	slli	a5,a2,0x34
    8000086c:	eba9                	bnez	a5,800008be <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    8000086e:	ce31                	beqz	a2,800008ca <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80000870:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    80000874:	80060613          	addi	a2,a2,-2048
    80000878:	00b60933          	add	s2,a2,a1
  a = va;
    8000087c:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    8000087e:	4b05                	li	s6,1
    80000880:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80000884:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    80000886:	865a                	mv	a2,s6
    80000888:	85a6                	mv	a1,s1
    8000088a:	8552                	mv	a0,s4
    8000088c:	ee9ff0ef          	jal	80000774 <walk>
    80000890:	c929                	beqz	a0,800008e2 <mappages+0x9a>
    if(*pte & PTE_V)
    80000892:	611c                	ld	a5,0(a0)
    80000894:	8b85                	andi	a5,a5,1
    80000896:	e3a1                	bnez	a5,800008d6 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000898:	013487b3          	add	a5,s1,s3
    8000089c:	83b1                	srli	a5,a5,0xc
    8000089e:	07aa                	slli	a5,a5,0xa
    800008a0:	0157e7b3          	or	a5,a5,s5
    800008a4:	0017e793          	ori	a5,a5,1
    800008a8:	e11c                	sd	a5,0(a0)
    if(a == last)
    800008aa:	05248863          	beq	s1,s2,800008fa <mappages+0xb2>
    a += PGSIZE;
    800008ae:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800008b0:	bfd9                	j	80000886 <mappages+0x3e>
    panic("mappages: va not aligned");
    800008b2:	00007517          	auipc	a0,0x7
    800008b6:	79e50513          	addi	a0,a0,1950 # 80008050 <etext+0x50>
    800008ba:	5c8050ef          	jal	80005e82 <panic>
    panic("mappages: size not aligned");
    800008be:	00007517          	auipc	a0,0x7
    800008c2:	7b250513          	addi	a0,a0,1970 # 80008070 <etext+0x70>
    800008c6:	5bc050ef          	jal	80005e82 <panic>
    panic("mappages: size");
    800008ca:	00007517          	auipc	a0,0x7
    800008ce:	7c650513          	addi	a0,a0,1990 # 80008090 <etext+0x90>
    800008d2:	5b0050ef          	jal	80005e82 <panic>
      panic("mappages: remap");
    800008d6:	00007517          	auipc	a0,0x7
    800008da:	7ca50513          	addi	a0,a0,1994 # 800080a0 <etext+0xa0>
    800008de:	5a4050ef          	jal	80005e82 <panic>
      return -1;
    800008e2:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800008e4:	60a6                	ld	ra,72(sp)
    800008e6:	6406                	ld	s0,64(sp)
    800008e8:	74e2                	ld	s1,56(sp)
    800008ea:	7942                	ld	s2,48(sp)
    800008ec:	79a2                	ld	s3,40(sp)
    800008ee:	7a02                	ld	s4,32(sp)
    800008f0:	6ae2                	ld	s5,24(sp)
    800008f2:	6b42                	ld	s6,16(sp)
    800008f4:	6ba2                	ld	s7,8(sp)
    800008f6:	6161                	addi	sp,sp,80
    800008f8:	8082                	ret
  return 0;
    800008fa:	4501                	li	a0,0
    800008fc:	b7e5                	j	800008e4 <mappages+0x9c>

00000000800008fe <kvmmap>:
{
    800008fe:	1141                	addi	sp,sp,-16
    80000900:	e406                	sd	ra,8(sp)
    80000902:	e022                	sd	s0,0(sp)
    80000904:	0800                	addi	s0,sp,16
    80000906:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000908:	86b2                	mv	a3,a2
    8000090a:	863e                	mv	a2,a5
    8000090c:	f3dff0ef          	jal	80000848 <mappages>
    80000910:	e509                	bnez	a0,8000091a <kvmmap+0x1c>
}
    80000912:	60a2                	ld	ra,8(sp)
    80000914:	6402                	ld	s0,0(sp)
    80000916:	0141                	addi	sp,sp,16
    80000918:	8082                	ret
    panic("kvmmap");
    8000091a:	00007517          	auipc	a0,0x7
    8000091e:	79650513          	addi	a0,a0,1942 # 800080b0 <etext+0xb0>
    80000922:	560050ef          	jal	80005e82 <panic>

0000000080000926 <kvmmake>:
{
    80000926:	1101                	addi	sp,sp,-32
    80000928:	ec06                	sd	ra,24(sp)
    8000092a:	e822                	sd	s0,16(sp)
    8000092c:	e426                	sd	s1,8(sp)
    8000092e:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80000930:	9e3ff0ef          	jal	80000312 <kalloc>
    80000934:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80000936:	6605                	lui	a2,0x1
    80000938:	4581                	li	a1,0
    8000093a:	b9fff0ef          	jal	800004d8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000093e:	4719                	li	a4,6
    80000940:	6685                	lui	a3,0x1
    80000942:	10000637          	lui	a2,0x10000
    80000946:	85b2                	mv	a1,a2
    80000948:	8526                	mv	a0,s1
    8000094a:	fb5ff0ef          	jal	800008fe <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000094e:	4719                	li	a4,6
    80000950:	6685                	lui	a3,0x1
    80000952:	10001637          	lui	a2,0x10001
    80000956:	85b2                	mv	a1,a2
    80000958:	8526                	mv	a0,s1
    8000095a:	fa5ff0ef          	jal	800008fe <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000095e:	4719                	li	a4,6
    80000960:	040006b7          	lui	a3,0x4000
    80000964:	0c000637          	lui	a2,0xc000
    80000968:	85b2                	mv	a1,a2
    8000096a:	8526                	mv	a0,s1
    8000096c:	f93ff0ef          	jal	800008fe <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80000970:	4729                	li	a4,10
    80000972:	80007697          	auipc	a3,0x80007
    80000976:	68e68693          	addi	a3,a3,1678 # 8000 <_entry-0x7fff8000>
    8000097a:	4605                	li	a2,1
    8000097c:	067e                	slli	a2,a2,0x1f
    8000097e:	85b2                	mv	a1,a2
    80000980:	8526                	mv	a0,s1
    80000982:	f7dff0ef          	jal	800008fe <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80000986:	4719                	li	a4,6
    80000988:	00007697          	auipc	a3,0x7
    8000098c:	67868693          	addi	a3,a3,1656 # 80008000 <etext>
    80000990:	47c5                	li	a5,17
    80000992:	07ee                	slli	a5,a5,0x1b
    80000994:	40d786b3          	sub	a3,a5,a3
    80000998:	00007617          	auipc	a2,0x7
    8000099c:	66860613          	addi	a2,a2,1640 # 80008000 <etext>
    800009a0:	85b2                	mv	a1,a2
    800009a2:	8526                	mv	a0,s1
    800009a4:	f5bff0ef          	jal	800008fe <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800009a8:	4729                	li	a4,10
    800009aa:	6685                	lui	a3,0x1
    800009ac:	00006617          	auipc	a2,0x6
    800009b0:	65460613          	addi	a2,a2,1620 # 80007000 <_trampoline>
    800009b4:	040005b7          	lui	a1,0x4000
    800009b8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800009ba:	05b2                	slli	a1,a1,0xc
    800009bc:	8526                	mv	a0,s1
    800009be:	f41ff0ef          	jal	800008fe <kvmmap>
  proc_mapstacks(kpgtbl);
    800009c2:	8526                	mv	a0,s1
    800009c4:	5b2000ef          	jal	80000f76 <proc_mapstacks>
}
    800009c8:	8526                	mv	a0,s1
    800009ca:	60e2                	ld	ra,24(sp)
    800009cc:	6442                	ld	s0,16(sp)
    800009ce:	64a2                	ld	s1,8(sp)
    800009d0:	6105                	addi	sp,sp,32
    800009d2:	8082                	ret

00000000800009d4 <kvminit>:
{
    800009d4:	1141                	addi	sp,sp,-16
    800009d6:	e406                	sd	ra,8(sp)
    800009d8:	e022                	sd	s0,0(sp)
    800009da:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800009dc:	f4bff0ef          	jal	80000926 <kvmmake>
    800009e0:	00008797          	auipc	a5,0x8
    800009e4:	00a7b423          	sd	a0,8(a5) # 800089e8 <kernel_pagetable>
}
    800009e8:	60a2                	ld	ra,8(sp)
    800009ea:	6402                	ld	s0,0(sp)
    800009ec:	0141                	addi	sp,sp,16
    800009ee:	8082                	ret

00000000800009f0 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800009f0:	715d                	addi	sp,sp,-80
    800009f2:	e486                	sd	ra,72(sp)
    800009f4:	e0a2                	sd	s0,64(sp)
    800009f6:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800009f8:	03459793          	slli	a5,a1,0x34
    800009fc:	e39d                	bnez	a5,80000a22 <uvmunmap+0x32>
    800009fe:	f84a                	sd	s2,48(sp)
    80000a00:	f44e                	sd	s3,40(sp)
    80000a02:	f052                	sd	s4,32(sp)
    80000a04:	ec56                	sd	s5,24(sp)
    80000a06:	e85a                	sd	s6,16(sp)
    80000a08:	e45e                	sd	s7,8(sp)
    80000a0a:	8a2a                	mv	s4,a0
    80000a0c:	892e                	mv	s2,a1
    80000a0e:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80000a10:	0632                	slli	a2,a2,0xc
    80000a12:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    80000a16:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80000a18:	6b05                	lui	s6,0x1
    80000a1a:	0735ff63          	bgeu	a1,s3,80000a98 <uvmunmap+0xa8>
    80000a1e:	fc26                	sd	s1,56(sp)
    80000a20:	a0a9                	j	80000a6a <uvmunmap+0x7a>
    80000a22:	fc26                	sd	s1,56(sp)
    80000a24:	f84a                	sd	s2,48(sp)
    80000a26:	f44e                	sd	s3,40(sp)
    80000a28:	f052                	sd	s4,32(sp)
    80000a2a:	ec56                	sd	s5,24(sp)
    80000a2c:	e85a                	sd	s6,16(sp)
    80000a2e:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    80000a30:	00007517          	auipc	a0,0x7
    80000a34:	68850513          	addi	a0,a0,1672 # 800080b8 <etext+0xb8>
    80000a38:	44a050ef          	jal	80005e82 <panic>
      panic("uvmunmap: walk");
    80000a3c:	00007517          	auipc	a0,0x7
    80000a40:	69450513          	addi	a0,a0,1684 # 800080d0 <etext+0xd0>
    80000a44:	43e050ef          	jal	80005e82 <panic>
      panic("uvmunmap: not mapped");
    80000a48:	00007517          	auipc	a0,0x7
    80000a4c:	69850513          	addi	a0,a0,1688 # 800080e0 <etext+0xe0>
    80000a50:	432050ef          	jal	80005e82 <panic>
      panic("uvmunmap: not a leaf");
    80000a54:	00007517          	auipc	a0,0x7
    80000a58:	6a450513          	addi	a0,a0,1700 # 800080f8 <etext+0xf8>
    80000a5c:	426050ef          	jal	80005e82 <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80000a60:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80000a64:	995a                	add	s2,s2,s6
    80000a66:	03397863          	bgeu	s2,s3,80000a96 <uvmunmap+0xa6>
    if((pte = walk(pagetable, a, 0)) == 0)
    80000a6a:	4601                	li	a2,0
    80000a6c:	85ca                	mv	a1,s2
    80000a6e:	8552                	mv	a0,s4
    80000a70:	d05ff0ef          	jal	80000774 <walk>
    80000a74:	84aa                	mv	s1,a0
    80000a76:	d179                	beqz	a0,80000a3c <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0)
    80000a78:	6108                	ld	a0,0(a0)
    80000a7a:	00157793          	andi	a5,a0,1
    80000a7e:	d7e9                	beqz	a5,80000a48 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    80000a80:	3ff57793          	andi	a5,a0,1023
    80000a84:	fd7788e3          	beq	a5,s7,80000a54 <uvmunmap+0x64>
    if(do_free){
    80000a88:	fc0a8ce3          	beqz	s5,80000a60 <uvmunmap+0x70>
      uint64 pa = PTE2PA(*pte);
    80000a8c:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    80000a8e:	0532                	slli	a0,a0,0xc
    80000a90:	ff2ff0ef          	jal	80000282 <kfree>
    80000a94:	b7f1                	j	80000a60 <uvmunmap+0x70>
    80000a96:	74e2                	ld	s1,56(sp)
    80000a98:	7942                	ld	s2,48(sp)
    80000a9a:	79a2                	ld	s3,40(sp)
    80000a9c:	7a02                	ld	s4,32(sp)
    80000a9e:	6ae2                	ld	s5,24(sp)
    80000aa0:	6b42                	ld	s6,16(sp)
    80000aa2:	6ba2                	ld	s7,8(sp)
  }
}
    80000aa4:	60a6                	ld	ra,72(sp)
    80000aa6:	6406                	ld	s0,64(sp)
    80000aa8:	6161                	addi	sp,sp,80
    80000aaa:	8082                	ret

0000000080000aac <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80000aac:	1101                	addi	sp,sp,-32
    80000aae:	ec06                	sd	ra,24(sp)
    80000ab0:	e822                	sd	s0,16(sp)
    80000ab2:	e426                	sd	s1,8(sp)
    80000ab4:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80000ab6:	85dff0ef          	jal	80000312 <kalloc>
    80000aba:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000abc:	c509                	beqz	a0,80000ac6 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80000abe:	6605                	lui	a2,0x1
    80000ac0:	4581                	li	a1,0
    80000ac2:	a17ff0ef          	jal	800004d8 <memset>
  return pagetable;
}
    80000ac6:	8526                	mv	a0,s1
    80000ac8:	60e2                	ld	ra,24(sp)
    80000aca:	6442                	ld	s0,16(sp)
    80000acc:	64a2                	ld	s1,8(sp)
    80000ace:	6105                	addi	sp,sp,32
    80000ad0:	8082                	ret

0000000080000ad2 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80000ad2:	7179                	addi	sp,sp,-48
    80000ad4:	f406                	sd	ra,40(sp)
    80000ad6:	f022                	sd	s0,32(sp)
    80000ad8:	ec26                	sd	s1,24(sp)
    80000ada:	e84a                	sd	s2,16(sp)
    80000adc:	e44e                	sd	s3,8(sp)
    80000ade:	e052                	sd	s4,0(sp)
    80000ae0:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80000ae2:	6785                	lui	a5,0x1
    80000ae4:	04f67063          	bgeu	a2,a5,80000b24 <uvmfirst+0x52>
    80000ae8:	89aa                	mv	s3,a0
    80000aea:	8a2e                	mv	s4,a1
    80000aec:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    80000aee:	825ff0ef          	jal	80000312 <kalloc>
    80000af2:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000af4:	6605                	lui	a2,0x1
    80000af6:	4581                	li	a1,0
    80000af8:	9e1ff0ef          	jal	800004d8 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    80000afc:	4779                	li	a4,30
    80000afe:	86ca                	mv	a3,s2
    80000b00:	6605                	lui	a2,0x1
    80000b02:	4581                	li	a1,0
    80000b04:	854e                	mv	a0,s3
    80000b06:	d43ff0ef          	jal	80000848 <mappages>
  memmove(mem, src, sz);
    80000b0a:	8626                	mv	a2,s1
    80000b0c:	85d2                	mv	a1,s4
    80000b0e:	854a                	mv	a0,s2
    80000b10:	a29ff0ef          	jal	80000538 <memmove>
}
    80000b14:	70a2                	ld	ra,40(sp)
    80000b16:	7402                	ld	s0,32(sp)
    80000b18:	64e2                	ld	s1,24(sp)
    80000b1a:	6942                	ld	s2,16(sp)
    80000b1c:	69a2                	ld	s3,8(sp)
    80000b1e:	6a02                	ld	s4,0(sp)
    80000b20:	6145                	addi	sp,sp,48
    80000b22:	8082                	ret
    panic("uvmfirst: more than a page");
    80000b24:	00007517          	auipc	a0,0x7
    80000b28:	5ec50513          	addi	a0,a0,1516 # 80008110 <etext+0x110>
    80000b2c:	356050ef          	jal	80005e82 <panic>

0000000080000b30 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80000b30:	1101                	addi	sp,sp,-32
    80000b32:	ec06                	sd	ra,24(sp)
    80000b34:	e822                	sd	s0,16(sp)
    80000b36:	e426                	sd	s1,8(sp)
    80000b38:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80000b3a:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    80000b3c:	00b67d63          	bgeu	a2,a1,80000b56 <uvmdealloc+0x26>
    80000b40:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80000b42:	6785                	lui	a5,0x1
    80000b44:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000b46:	00f60733          	add	a4,a2,a5
    80000b4a:	76fd                	lui	a3,0xfffff
    80000b4c:	8f75                	and	a4,a4,a3
    80000b4e:	97ae                	add	a5,a5,a1
    80000b50:	8ff5                	and	a5,a5,a3
    80000b52:	00f76863          	bltu	a4,a5,80000b62 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80000b56:	8526                	mv	a0,s1
    80000b58:	60e2                	ld	ra,24(sp)
    80000b5a:	6442                	ld	s0,16(sp)
    80000b5c:	64a2                	ld	s1,8(sp)
    80000b5e:	6105                	addi	sp,sp,32
    80000b60:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80000b62:	8f99                	sub	a5,a5,a4
    80000b64:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80000b66:	4685                	li	a3,1
    80000b68:	0007861b          	sext.w	a2,a5
    80000b6c:	85ba                	mv	a1,a4
    80000b6e:	e83ff0ef          	jal	800009f0 <uvmunmap>
    80000b72:	b7d5                	j	80000b56 <uvmdealloc+0x26>

0000000080000b74 <uvmalloc>:
  if(newsz < oldsz)
    80000b74:	0ab66163          	bltu	a2,a1,80000c16 <uvmalloc+0xa2>
{
    80000b78:	715d                	addi	sp,sp,-80
    80000b7a:	e486                	sd	ra,72(sp)
    80000b7c:	e0a2                	sd	s0,64(sp)
    80000b7e:	f84a                	sd	s2,48(sp)
    80000b80:	f052                	sd	s4,32(sp)
    80000b82:	ec56                	sd	s5,24(sp)
    80000b84:	e45e                	sd	s7,8(sp)
    80000b86:	0880                	addi	s0,sp,80
    80000b88:	8aaa                	mv	s5,a0
    80000b8a:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80000b8c:	6785                	lui	a5,0x1
    80000b8e:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000b90:	95be                	add	a1,a1,a5
    80000b92:	77fd                	lui	a5,0xfffff
    80000b94:	00f5f933          	and	s2,a1,a5
    80000b98:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000b9a:	08c97063          	bgeu	s2,a2,80000c1a <uvmalloc+0xa6>
    80000b9e:	fc26                	sd	s1,56(sp)
    80000ba0:	f44e                	sd	s3,40(sp)
    80000ba2:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    80000ba4:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000ba6:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80000baa:	f68ff0ef          	jal	80000312 <kalloc>
    80000bae:	84aa                	mv	s1,a0
    if(mem == 0){
    80000bb0:	c50d                	beqz	a0,80000bda <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    80000bb2:	864e                	mv	a2,s3
    80000bb4:	4581                	li	a1,0
    80000bb6:	923ff0ef          	jal	800004d8 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000bba:	875a                	mv	a4,s6
    80000bbc:	86a6                	mv	a3,s1
    80000bbe:	864e                	mv	a2,s3
    80000bc0:	85ca                	mv	a1,s2
    80000bc2:	8556                	mv	a0,s5
    80000bc4:	c85ff0ef          	jal	80000848 <mappages>
    80000bc8:	e915                	bnez	a0,80000bfc <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000bca:	994e                	add	s2,s2,s3
    80000bcc:	fd496fe3          	bltu	s2,s4,80000baa <uvmalloc+0x36>
  return newsz;
    80000bd0:	8552                	mv	a0,s4
    80000bd2:	74e2                	ld	s1,56(sp)
    80000bd4:	79a2                	ld	s3,40(sp)
    80000bd6:	6b42                	ld	s6,16(sp)
    80000bd8:	a811                	j	80000bec <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80000bda:	865e                	mv	a2,s7
    80000bdc:	85ca                	mv	a1,s2
    80000bde:	8556                	mv	a0,s5
    80000be0:	f51ff0ef          	jal	80000b30 <uvmdealloc>
      return 0;
    80000be4:	4501                	li	a0,0
    80000be6:	74e2                	ld	s1,56(sp)
    80000be8:	79a2                	ld	s3,40(sp)
    80000bea:	6b42                	ld	s6,16(sp)
}
    80000bec:	60a6                	ld	ra,72(sp)
    80000bee:	6406                	ld	s0,64(sp)
    80000bf0:	7942                	ld	s2,48(sp)
    80000bf2:	7a02                	ld	s4,32(sp)
    80000bf4:	6ae2                	ld	s5,24(sp)
    80000bf6:	6ba2                	ld	s7,8(sp)
    80000bf8:	6161                	addi	sp,sp,80
    80000bfa:	8082                	ret
      kfree(mem);
    80000bfc:	8526                	mv	a0,s1
    80000bfe:	e84ff0ef          	jal	80000282 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80000c02:	865e                	mv	a2,s7
    80000c04:	85ca                	mv	a1,s2
    80000c06:	8556                	mv	a0,s5
    80000c08:	f29ff0ef          	jal	80000b30 <uvmdealloc>
      return 0;
    80000c0c:	4501                	li	a0,0
    80000c0e:	74e2                	ld	s1,56(sp)
    80000c10:	79a2                	ld	s3,40(sp)
    80000c12:	6b42                	ld	s6,16(sp)
    80000c14:	bfe1                	j	80000bec <uvmalloc+0x78>
    return oldsz;
    80000c16:	852e                	mv	a0,a1
}
    80000c18:	8082                	ret
  return newsz;
    80000c1a:	8532                	mv	a0,a2
    80000c1c:	bfc1                	j	80000bec <uvmalloc+0x78>

0000000080000c1e <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80000c1e:	7179                	addi	sp,sp,-48
    80000c20:	f406                	sd	ra,40(sp)
    80000c22:	f022                	sd	s0,32(sp)
    80000c24:	ec26                	sd	s1,24(sp)
    80000c26:	e84a                	sd	s2,16(sp)
    80000c28:	e44e                	sd	s3,8(sp)
    80000c2a:	1800                	addi	s0,sp,48
    80000c2c:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    80000c2e:	84aa                	mv	s1,a0
    80000c30:	6905                	lui	s2,0x1
    80000c32:	992a                	add	s2,s2,a0
    80000c34:	a811                	j	80000c48 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    80000c36:	00007517          	auipc	a0,0x7
    80000c3a:	4fa50513          	addi	a0,a0,1274 # 80008130 <etext+0x130>
    80000c3e:	244050ef          	jal	80005e82 <panic>
  for(int i = 0; i < 512; i++){
    80000c42:	04a1                	addi	s1,s1,8
    80000c44:	03248163          	beq	s1,s2,80000c66 <freewalk+0x48>
    pte_t pte = pagetable[i];
    80000c48:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000c4a:	0017f713          	andi	a4,a5,1
    80000c4e:	db75                	beqz	a4,80000c42 <freewalk+0x24>
    80000c50:	00e7f713          	andi	a4,a5,14
    80000c54:	f36d                	bnez	a4,80000c36 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80000c56:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80000c58:	00c79513          	slli	a0,a5,0xc
    80000c5c:	fc3ff0ef          	jal	80000c1e <freewalk>
      pagetable[i] = 0;
    80000c60:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000c64:	bff9                	j	80000c42 <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    80000c66:	854e                	mv	a0,s3
    80000c68:	e1aff0ef          	jal	80000282 <kfree>
}
    80000c6c:	70a2                	ld	ra,40(sp)
    80000c6e:	7402                	ld	s0,32(sp)
    80000c70:	64e2                	ld	s1,24(sp)
    80000c72:	6942                	ld	s2,16(sp)
    80000c74:	69a2                	ld	s3,8(sp)
    80000c76:	6145                	addi	sp,sp,48
    80000c78:	8082                	ret

0000000080000c7a <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80000c7a:	1101                	addi	sp,sp,-32
    80000c7c:	ec06                	sd	ra,24(sp)
    80000c7e:	e822                	sd	s0,16(sp)
    80000c80:	e426                	sd	s1,8(sp)
    80000c82:	1000                	addi	s0,sp,32
    80000c84:	84aa                	mv	s1,a0
  if(sz > 0)
    80000c86:	e989                	bnez	a1,80000c98 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80000c88:	8526                	mv	a0,s1
    80000c8a:	f95ff0ef          	jal	80000c1e <freewalk>
}
    80000c8e:	60e2                	ld	ra,24(sp)
    80000c90:	6442                	ld	s0,16(sp)
    80000c92:	64a2                	ld	s1,8(sp)
    80000c94:	6105                	addi	sp,sp,32
    80000c96:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80000c98:	6785                	lui	a5,0x1
    80000c9a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000c9c:	95be                	add	a1,a1,a5
    80000c9e:	4685                	li	a3,1
    80000ca0:	00c5d613          	srli	a2,a1,0xc
    80000ca4:	4581                	li	a1,0
    80000ca6:	d4bff0ef          	jal	800009f0 <uvmunmap>
    80000caa:	bff9                	j	80000c88 <uvmfree+0xe>

0000000080000cac <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80000cac:	c64d                	beqz	a2,80000d56 <uvmcopy+0xaa>
{
    80000cae:	715d                	addi	sp,sp,-80
    80000cb0:	e486                	sd	ra,72(sp)
    80000cb2:	e0a2                	sd	s0,64(sp)
    80000cb4:	fc26                	sd	s1,56(sp)
    80000cb6:	f84a                	sd	s2,48(sp)
    80000cb8:	f44e                	sd	s3,40(sp)
    80000cba:	f052                	sd	s4,32(sp)
    80000cbc:	ec56                	sd	s5,24(sp)
    80000cbe:	e85a                	sd	s6,16(sp)
    80000cc0:	e45e                	sd	s7,8(sp)
    80000cc2:	0880                	addi	s0,sp,80
    80000cc4:	8b2a                	mv	s6,a0
    80000cc6:	8aae                	mv	s5,a1
    80000cc8:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80000cca:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80000ccc:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    80000cce:	4601                	li	a2,0
    80000cd0:	85ca                	mv	a1,s2
    80000cd2:	855a                	mv	a0,s6
    80000cd4:	aa1ff0ef          	jal	80000774 <walk>
    80000cd8:	cd0d                	beqz	a0,80000d12 <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    80000cda:	00053b83          	ld	s7,0(a0)
    80000cde:	001bf793          	andi	a5,s7,1
    80000ce2:	cf95                	beqz	a5,80000d1e <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    80000ce4:	e2eff0ef          	jal	80000312 <kalloc>
    80000ce8:	84aa                	mv	s1,a0
    80000cea:	c139                	beqz	a0,80000d30 <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    80000cec:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80000cf0:	864e                	mv	a2,s3
    80000cf2:	05b2                	slli	a1,a1,0xc
    80000cf4:	845ff0ef          	jal	80000538 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80000cf8:	3ffbf713          	andi	a4,s7,1023
    80000cfc:	86a6                	mv	a3,s1
    80000cfe:	864e                	mv	a2,s3
    80000d00:	85ca                	mv	a1,s2
    80000d02:	8556                	mv	a0,s5
    80000d04:	b45ff0ef          	jal	80000848 <mappages>
    80000d08:	e10d                	bnez	a0,80000d2a <uvmcopy+0x7e>
  for(i = 0; i < sz; i += PGSIZE){
    80000d0a:	994e                	add	s2,s2,s3
    80000d0c:	fd4961e3          	bltu	s2,s4,80000cce <uvmcopy+0x22>
    80000d10:	a805                	j	80000d40 <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    80000d12:	00007517          	auipc	a0,0x7
    80000d16:	42e50513          	addi	a0,a0,1070 # 80008140 <etext+0x140>
    80000d1a:	168050ef          	jal	80005e82 <panic>
      panic("uvmcopy: page not present");
    80000d1e:	00007517          	auipc	a0,0x7
    80000d22:	44250513          	addi	a0,a0,1090 # 80008160 <etext+0x160>
    80000d26:	15c050ef          	jal	80005e82 <panic>
      kfree(mem);
    80000d2a:	8526                	mv	a0,s1
    80000d2c:	d56ff0ef          	jal	80000282 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80000d30:	4685                	li	a3,1
    80000d32:	00c95613          	srli	a2,s2,0xc
    80000d36:	4581                	li	a1,0
    80000d38:	8556                	mv	a0,s5
    80000d3a:	cb7ff0ef          	jal	800009f0 <uvmunmap>
  return -1;
    80000d3e:	557d                	li	a0,-1
}
    80000d40:	60a6                	ld	ra,72(sp)
    80000d42:	6406                	ld	s0,64(sp)
    80000d44:	74e2                	ld	s1,56(sp)
    80000d46:	7942                	ld	s2,48(sp)
    80000d48:	79a2                	ld	s3,40(sp)
    80000d4a:	7a02                	ld	s4,32(sp)
    80000d4c:	6ae2                	ld	s5,24(sp)
    80000d4e:	6b42                	ld	s6,16(sp)
    80000d50:	6ba2                	ld	s7,8(sp)
    80000d52:	6161                	addi	sp,sp,80
    80000d54:	8082                	ret
  return 0;
    80000d56:	4501                	li	a0,0
}
    80000d58:	8082                	ret

0000000080000d5a <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80000d5a:	1141                	addi	sp,sp,-16
    80000d5c:	e406                	sd	ra,8(sp)
    80000d5e:	e022                	sd	s0,0(sp)
    80000d60:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80000d62:	4601                	li	a2,0
    80000d64:	a11ff0ef          	jal	80000774 <walk>
  if(pte == 0)
    80000d68:	c901                	beqz	a0,80000d78 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80000d6a:	611c                	ld	a5,0(a0)
    80000d6c:	9bbd                	andi	a5,a5,-17
    80000d6e:	e11c                	sd	a5,0(a0)
}
    80000d70:	60a2                	ld	ra,8(sp)
    80000d72:	6402                	ld	s0,0(sp)
    80000d74:	0141                	addi	sp,sp,16
    80000d76:	8082                	ret
    panic("uvmclear");
    80000d78:	00007517          	auipc	a0,0x7
    80000d7c:	40850513          	addi	a0,a0,1032 # 80008180 <etext+0x180>
    80000d80:	102050ef          	jal	80005e82 <panic>

0000000080000d84 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    80000d84:	c2d9                	beqz	a3,80000e0a <copyout+0x86>
{
    80000d86:	711d                	addi	sp,sp,-96
    80000d88:	ec86                	sd	ra,88(sp)
    80000d8a:	e8a2                	sd	s0,80(sp)
    80000d8c:	e4a6                	sd	s1,72(sp)
    80000d8e:	e0ca                	sd	s2,64(sp)
    80000d90:	fc4e                	sd	s3,56(sp)
    80000d92:	f852                	sd	s4,48(sp)
    80000d94:	f456                	sd	s5,40(sp)
    80000d96:	f05a                	sd	s6,32(sp)
    80000d98:	ec5e                	sd	s7,24(sp)
    80000d9a:	e862                	sd	s8,16(sp)
    80000d9c:	e466                	sd	s9,8(sp)
    80000d9e:	e06a                	sd	s10,0(sp)
    80000da0:	1080                	addi	s0,sp,96
    80000da2:	8c2a                	mv	s8,a0
    80000da4:	892e                	mv	s2,a1
    80000da6:	8ab2                	mv	s5,a2
    80000da8:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80000daa:	7cfd                	lui	s9,0xfffff
    if(va0 >= MAXVA)
    80000dac:	5bfd                	li	s7,-1
    80000dae:	01abdb93          	srli	s7,s7,0x1a
      return -1;
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000db2:	4d55                	li	s10,21
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    n = PGSIZE - (dstva - va0);
    80000db4:	6b05                	lui	s6,0x1
    80000db6:	a015                	j	80000dda <copyout+0x56>
    pa0 = PTE2PA(*pte);
    80000db8:	83a9                	srli	a5,a5,0xa
    80000dba:	07b2                	slli	a5,a5,0xc
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000dbc:	41390533          	sub	a0,s2,s3
    80000dc0:	0004861b          	sext.w	a2,s1
    80000dc4:	85d6                	mv	a1,s5
    80000dc6:	953e                	add	a0,a0,a5
    80000dc8:	f70ff0ef          	jal	80000538 <memmove>

    len -= n;
    80000dcc:	409a0a33          	sub	s4,s4,s1
    src += n;
    80000dd0:	9aa6                	add	s5,s5,s1
    dstva = va0 + PGSIZE;
    80000dd2:	01698933          	add	s2,s3,s6
  while(len > 0){
    80000dd6:	020a0863          	beqz	s4,80000e06 <copyout+0x82>
    va0 = PGROUNDDOWN(dstva);
    80000dda:	019979b3          	and	s3,s2,s9
    if(va0 >= MAXVA)
    80000dde:	033be863          	bltu	s7,s3,80000e0e <copyout+0x8a>
    pte = walk(pagetable, va0, 0);
    80000de2:	4601                	li	a2,0
    80000de4:	85ce                	mv	a1,s3
    80000de6:	8562                	mv	a0,s8
    80000de8:	98dff0ef          	jal	80000774 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000dec:	c11d                	beqz	a0,80000e12 <copyout+0x8e>
    80000dee:	611c                	ld	a5,0(a0)
    80000df0:	0157f713          	andi	a4,a5,21
    80000df4:	03a71163          	bne	a4,s10,80000e16 <copyout+0x92>
    n = PGSIZE - (dstva - va0);
    80000df8:	412984b3          	sub	s1,s3,s2
    80000dfc:	94da                	add	s1,s1,s6
    if(n > len)
    80000dfe:	fa9a7de3          	bgeu	s4,s1,80000db8 <copyout+0x34>
    80000e02:	84d2                	mv	s1,s4
    80000e04:	bf55                	j	80000db8 <copyout+0x34>
  }
  return 0;
    80000e06:	4501                	li	a0,0
    80000e08:	a801                	j	80000e18 <copyout+0x94>
    80000e0a:	4501                	li	a0,0
}
    80000e0c:	8082                	ret
      return -1;
    80000e0e:	557d                	li	a0,-1
    80000e10:	a021                	j	80000e18 <copyout+0x94>
      return -1;
    80000e12:	557d                	li	a0,-1
    80000e14:	a011                	j	80000e18 <copyout+0x94>
    80000e16:	557d                	li	a0,-1
}
    80000e18:	60e6                	ld	ra,88(sp)
    80000e1a:	6446                	ld	s0,80(sp)
    80000e1c:	64a6                	ld	s1,72(sp)
    80000e1e:	6906                	ld	s2,64(sp)
    80000e20:	79e2                	ld	s3,56(sp)
    80000e22:	7a42                	ld	s4,48(sp)
    80000e24:	7aa2                	ld	s5,40(sp)
    80000e26:	7b02                	ld	s6,32(sp)
    80000e28:	6be2                	ld	s7,24(sp)
    80000e2a:	6c42                	ld	s8,16(sp)
    80000e2c:	6ca2                	ld	s9,8(sp)
    80000e2e:	6d02                	ld	s10,0(sp)
    80000e30:	6125                	addi	sp,sp,96
    80000e32:	8082                	ret

0000000080000e34 <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80000e34:	c6a5                	beqz	a3,80000e9c <copyin+0x68>
{
    80000e36:	715d                	addi	sp,sp,-80
    80000e38:	e486                	sd	ra,72(sp)
    80000e3a:	e0a2                	sd	s0,64(sp)
    80000e3c:	fc26                	sd	s1,56(sp)
    80000e3e:	f84a                	sd	s2,48(sp)
    80000e40:	f44e                	sd	s3,40(sp)
    80000e42:	f052                	sd	s4,32(sp)
    80000e44:	ec56                	sd	s5,24(sp)
    80000e46:	e85a                	sd	s6,16(sp)
    80000e48:	e45e                	sd	s7,8(sp)
    80000e4a:	e062                	sd	s8,0(sp)
    80000e4c:	0880                	addi	s0,sp,80
    80000e4e:	8b2a                	mv	s6,a0
    80000e50:	8a2e                	mv	s4,a1
    80000e52:	8c32                	mv	s8,a2
    80000e54:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000e56:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000e58:	6a85                	lui	s5,0x1
    80000e5a:	a00d                	j	80000e7c <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000e5c:	018505b3          	add	a1,a0,s8
    80000e60:	0004861b          	sext.w	a2,s1
    80000e64:	412585b3          	sub	a1,a1,s2
    80000e68:	8552                	mv	a0,s4
    80000e6a:	eceff0ef          	jal	80000538 <memmove>

    len -= n;
    80000e6e:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000e72:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000e74:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000e78:	02098063          	beqz	s3,80000e98 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000e7c:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000e80:	85ca                	mv	a1,s2
    80000e82:	855a                	mv	a0,s6
    80000e84:	98bff0ef          	jal	8000080e <walkaddr>
    if(pa0 == 0)
    80000e88:	cd01                	beqz	a0,80000ea0 <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000e8a:	418904b3          	sub	s1,s2,s8
    80000e8e:	94d6                	add	s1,s1,s5
    if(n > len)
    80000e90:	fc99f6e3          	bgeu	s3,s1,80000e5c <copyin+0x28>
    80000e94:	84ce                	mv	s1,s3
    80000e96:	b7d9                	j	80000e5c <copyin+0x28>
  }
  return 0;
    80000e98:	4501                	li	a0,0
    80000e9a:	a021                	j	80000ea2 <copyin+0x6e>
    80000e9c:	4501                	li	a0,0
}
    80000e9e:	8082                	ret
      return -1;
    80000ea0:	557d                	li	a0,-1
}
    80000ea2:	60a6                	ld	ra,72(sp)
    80000ea4:	6406                	ld	s0,64(sp)
    80000ea6:	74e2                	ld	s1,56(sp)
    80000ea8:	7942                	ld	s2,48(sp)
    80000eaa:	79a2                	ld	s3,40(sp)
    80000eac:	7a02                	ld	s4,32(sp)
    80000eae:	6ae2                	ld	s5,24(sp)
    80000eb0:	6b42                	ld	s6,16(sp)
    80000eb2:	6ba2                	ld	s7,8(sp)
    80000eb4:	6c02                	ld	s8,0(sp)
    80000eb6:	6161                	addi	sp,sp,80
    80000eb8:	8082                	ret

0000000080000eba <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000eba:	cac5                	beqz	a3,80000f6a <copyinstr+0xb0>
{
    80000ebc:	715d                	addi	sp,sp,-80
    80000ebe:	e486                	sd	ra,72(sp)
    80000ec0:	e0a2                	sd	s0,64(sp)
    80000ec2:	fc26                	sd	s1,56(sp)
    80000ec4:	f84a                	sd	s2,48(sp)
    80000ec6:	f44e                	sd	s3,40(sp)
    80000ec8:	f052                	sd	s4,32(sp)
    80000eca:	ec56                	sd	s5,24(sp)
    80000ecc:	e85a                	sd	s6,16(sp)
    80000ece:	e45e                	sd	s7,8(sp)
    80000ed0:	0880                	addi	s0,sp,80
    80000ed2:	8aaa                	mv	s5,a0
    80000ed4:	84ae                	mv	s1,a1
    80000ed6:	8bb2                	mv	s7,a2
    80000ed8:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000eda:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000edc:	6a05                	lui	s4,0x1
    80000ede:	a82d                	j	80000f18 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000ee0:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80000ee4:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000ee6:	0017c793          	xori	a5,a5,1
    80000eea:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000eee:	60a6                	ld	ra,72(sp)
    80000ef0:	6406                	ld	s0,64(sp)
    80000ef2:	74e2                	ld	s1,56(sp)
    80000ef4:	7942                	ld	s2,48(sp)
    80000ef6:	79a2                	ld	s3,40(sp)
    80000ef8:	7a02                	ld	s4,32(sp)
    80000efa:	6ae2                	ld	s5,24(sp)
    80000efc:	6b42                	ld	s6,16(sp)
    80000efe:	6ba2                	ld	s7,8(sp)
    80000f00:	6161                	addi	sp,sp,80
    80000f02:	8082                	ret
    80000f04:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80000f08:	9726                	add	a4,a4,s1
      --max;
    80000f0a:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80000f0e:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80000f12:	04e58463          	beq	a1,a4,80000f5a <copyinstr+0xa0>
{
    80000f16:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80000f18:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80000f1c:	85ca                	mv	a1,s2
    80000f1e:	8556                	mv	a0,s5
    80000f20:	8efff0ef          	jal	8000080e <walkaddr>
    if(pa0 == 0)
    80000f24:	cd0d                	beqz	a0,80000f5e <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80000f26:	417906b3          	sub	a3,s2,s7
    80000f2a:	96d2                	add	a3,a3,s4
    if(n > max)
    80000f2c:	00d9f363          	bgeu	s3,a3,80000f32 <copyinstr+0x78>
    80000f30:	86ce                	mv	a3,s3
    while(n > 0){
    80000f32:	ca85                	beqz	a3,80000f62 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80000f34:	01750633          	add	a2,a0,s7
    80000f38:	41260633          	sub	a2,a2,s2
    80000f3c:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80000f3e:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80000f40:	96a6                	add	a3,a3,s1
    80000f42:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000f44:	00f60733          	add	a4,a2,a5
    80000f48:	00074703          	lbu	a4,0(a4)
    80000f4c:	db51                	beqz	a4,80000ee0 <copyinstr+0x26>
        *dst = *p;
    80000f4e:	00e78023          	sb	a4,0(a5)
      dst++;
    80000f52:	0785                	addi	a5,a5,1
    while(n > 0){
    80000f54:	fed797e3          	bne	a5,a3,80000f42 <copyinstr+0x88>
    80000f58:	b775                	j	80000f04 <copyinstr+0x4a>
    80000f5a:	4781                	li	a5,0
    80000f5c:	b769                	j	80000ee6 <copyinstr+0x2c>
      return -1;
    80000f5e:	557d                	li	a0,-1
    80000f60:	b779                	j	80000eee <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80000f62:	6b85                	lui	s7,0x1
    80000f64:	9bca                	add	s7,s7,s2
    80000f66:	87a6                	mv	a5,s1
    80000f68:	b77d                	j	80000f16 <copyinstr+0x5c>
  int got_null = 0;
    80000f6a:	4781                	li	a5,0
  if(got_null){
    80000f6c:	0017c793          	xori	a5,a5,1
    80000f70:	40f0053b          	negw	a0,a5
}
    80000f74:	8082                	ret

0000000080000f76 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000f76:	715d                	addi	sp,sp,-80
    80000f78:	e486                	sd	ra,72(sp)
    80000f7a:	e0a2                	sd	s0,64(sp)
    80000f7c:	fc26                	sd	s1,56(sp)
    80000f7e:	f84a                	sd	s2,48(sp)
    80000f80:	f44e                	sd	s3,40(sp)
    80000f82:	f052                	sd	s4,32(sp)
    80000f84:	ec56                	sd	s5,24(sp)
    80000f86:	e85a                	sd	s6,16(sp)
    80000f88:	e45e                	sd	s7,8(sp)
    80000f8a:	e062                	sd	s8,0(sp)
    80000f8c:	0880                	addi	s0,sp,80
    80000f8e:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000f90:	00008497          	auipc	s1,0x8
    80000f94:	02048493          	addi	s1,s1,32 # 80008fb0 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000f98:	8c26                	mv	s8,s1
    80000f9a:	ff4df937          	lui	s2,0xff4df
    80000f9e:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4b9335>
    80000fa2:	0936                	slli	s2,s2,0xd
    80000fa4:	6f590913          	addi	s2,s2,1781
    80000fa8:	0936                	slli	s2,s2,0xd
    80000faa:	bd390913          	addi	s2,s2,-1069
    80000fae:	0932                	slli	s2,s2,0xc
    80000fb0:	7a790913          	addi	s2,s2,1959
    80000fb4:	040009b7          	lui	s3,0x4000
    80000fb8:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000fba:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000fbc:	4b99                	li	s7,6
    80000fbe:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80000fc0:	0000ea97          	auipc	s5,0xe
    80000fc4:	bf0a8a93          	addi	s5,s5,-1040 # 8000ebb0 <tickslock>
    char *pa = kalloc();
    80000fc8:	b4aff0ef          	jal	80000312 <kalloc>
    80000fcc:	862a                	mv	a2,a0
    if(pa == 0)
    80000fce:	c121                	beqz	a0,8000100e <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    80000fd0:	418485b3          	sub	a1,s1,s8
    80000fd4:	8591                	srai	a1,a1,0x4
    80000fd6:	032585b3          	mul	a1,a1,s2
    80000fda:	05b6                	slli	a1,a1,0xd
    80000fdc:	6789                	lui	a5,0x2
    80000fde:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000fe0:	875e                	mv	a4,s7
    80000fe2:	86da                	mv	a3,s6
    80000fe4:	40b985b3          	sub	a1,s3,a1
    80000fe8:	8552                	mv	a0,s4
    80000fea:	915ff0ef          	jal	800008fe <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000fee:	17048493          	addi	s1,s1,368
    80000ff2:	fd549be3          	bne	s1,s5,80000fc8 <proc_mapstacks+0x52>
  }
}
    80000ff6:	60a6                	ld	ra,72(sp)
    80000ff8:	6406                	ld	s0,64(sp)
    80000ffa:	74e2                	ld	s1,56(sp)
    80000ffc:	7942                	ld	s2,48(sp)
    80000ffe:	79a2                	ld	s3,40(sp)
    80001000:	7a02                	ld	s4,32(sp)
    80001002:	6ae2                	ld	s5,24(sp)
    80001004:	6b42                	ld	s6,16(sp)
    80001006:	6ba2                	ld	s7,8(sp)
    80001008:	6c02                	ld	s8,0(sp)
    8000100a:	6161                	addi	sp,sp,80
    8000100c:	8082                	ret
      panic("kalloc");
    8000100e:	00007517          	auipc	a0,0x7
    80001012:	18250513          	addi	a0,a0,386 # 80008190 <etext+0x190>
    80001016:	66d040ef          	jal	80005e82 <panic>

000000008000101a <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000101a:	7139                	addi	sp,sp,-64
    8000101c:	fc06                	sd	ra,56(sp)
    8000101e:	f822                	sd	s0,48(sp)
    80001020:	f426                	sd	s1,40(sp)
    80001022:	f04a                	sd	s2,32(sp)
    80001024:	ec4e                	sd	s3,24(sp)
    80001026:	e852                	sd	s4,16(sp)
    80001028:	e456                	sd	s5,8(sp)
    8000102a:	e05a                	sd	s6,0(sp)
    8000102c:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    8000102e:	00007597          	auipc	a1,0x7
    80001032:	16a58593          	addi	a1,a1,362 # 80008198 <etext+0x198>
    80001036:	00008517          	auipc	a0,0x8
    8000103a:	b3a50513          	addi	a0,a0,-1222 # 80008b70 <pid_lock>
    8000103e:	2a8050ef          	jal	800062e6 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001042:	00007597          	auipc	a1,0x7
    80001046:	15e58593          	addi	a1,a1,350 # 800081a0 <etext+0x1a0>
    8000104a:	00008517          	auipc	a0,0x8
    8000104e:	b4650513          	addi	a0,a0,-1210 # 80008b90 <wait_lock>
    80001052:	294050ef          	jal	800062e6 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001056:	00008497          	auipc	s1,0x8
    8000105a:	f5a48493          	addi	s1,s1,-166 # 80008fb0 <proc>
      initlock(&p->lock, "proc");
    8000105e:	00007b17          	auipc	s6,0x7
    80001062:	152b0b13          	addi	s6,s6,338 # 800081b0 <etext+0x1b0>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001066:	8aa6                	mv	s5,s1
    80001068:	ff4df937          	lui	s2,0xff4df
    8000106c:	9bd90913          	addi	s2,s2,-1603 # ffffffffff4de9bd <end+0xffffffff7f4b9335>
    80001070:	0936                	slli	s2,s2,0xd
    80001072:	6f590913          	addi	s2,s2,1781
    80001076:	0936                	slli	s2,s2,0xd
    80001078:	bd390913          	addi	s2,s2,-1069
    8000107c:	0932                	slli	s2,s2,0xc
    8000107e:	7a790913          	addi	s2,s2,1959
    80001082:	040009b7          	lui	s3,0x4000
    80001086:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001088:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    8000108a:	0000ea17          	auipc	s4,0xe
    8000108e:	b26a0a13          	addi	s4,s4,-1242 # 8000ebb0 <tickslock>
      initlock(&p->lock, "proc");
    80001092:	85da                	mv	a1,s6
    80001094:	8526                	mv	a0,s1
    80001096:	250050ef          	jal	800062e6 <initlock>
      p->state = UNUSED;
    8000109a:	0204a023          	sw	zero,32(s1)
      p->kstack = KSTACK((int) (p - proc));
    8000109e:	415487b3          	sub	a5,s1,s5
    800010a2:	8791                	srai	a5,a5,0x4
    800010a4:	032787b3          	mul	a5,a5,s2
    800010a8:	07b6                	slli	a5,a5,0xd
    800010aa:	6709                	lui	a4,0x2
    800010ac:	9fb9                	addw	a5,a5,a4
    800010ae:	40f987b3          	sub	a5,s3,a5
    800010b2:	e4bc                	sd	a5,72(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800010b4:	17048493          	addi	s1,s1,368
    800010b8:	fd449de3          	bne	s1,s4,80001092 <procinit+0x78>
  }
}
    800010bc:	70e2                	ld	ra,56(sp)
    800010be:	7442                	ld	s0,48(sp)
    800010c0:	74a2                	ld	s1,40(sp)
    800010c2:	7902                	ld	s2,32(sp)
    800010c4:	69e2                	ld	s3,24(sp)
    800010c6:	6a42                	ld	s4,16(sp)
    800010c8:	6aa2                	ld	s5,8(sp)
    800010ca:	6b02                	ld	s6,0(sp)
    800010cc:	6121                	addi	sp,sp,64
    800010ce:	8082                	ret

00000000800010d0 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800010d0:	1141                	addi	sp,sp,-16
    800010d2:	e406                	sd	ra,8(sp)
    800010d4:	e022                	sd	s0,0(sp)
    800010d6:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800010d8:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800010da:	2501                	sext.w	a0,a0
    800010dc:	60a2                	ld	ra,8(sp)
    800010de:	6402                	ld	s0,0(sp)
    800010e0:	0141                	addi	sp,sp,16
    800010e2:	8082                	ret

00000000800010e4 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    800010e4:	1141                	addi	sp,sp,-16
    800010e6:	e406                	sd	ra,8(sp)
    800010e8:	e022                	sd	s0,0(sp)
    800010ea:	0800                	addi	s0,sp,16
    800010ec:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800010ee:	2781                	sext.w	a5,a5
    800010f0:	079e                	slli	a5,a5,0x7
  return c;
}
    800010f2:	00008517          	auipc	a0,0x8
    800010f6:	abe50513          	addi	a0,a0,-1346 # 80008bb0 <cpus>
    800010fa:	953e                	add	a0,a0,a5
    800010fc:	60a2                	ld	ra,8(sp)
    800010fe:	6402                	ld	s0,0(sp)
    80001100:	0141                	addi	sp,sp,16
    80001102:	8082                	ret

0000000080001104 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001104:	1101                	addi	sp,sp,-32
    80001106:	ec06                	sd	ra,24(sp)
    80001108:	e822                	sd	s0,16(sp)
    8000110a:	e426                	sd	s1,8(sp)
    8000110c:	1000                	addi	s0,sp,32
  push_off();
    8000110e:	054050ef          	jal	80006162 <push_off>
    80001112:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001114:	2781                	sext.w	a5,a5
    80001116:	079e                	slli	a5,a5,0x7
    80001118:	00008717          	auipc	a4,0x8
    8000111c:	a5870713          	addi	a4,a4,-1448 # 80008b70 <pid_lock>
    80001120:	97ba                	add	a5,a5,a4
    80001122:	63bc                	ld	a5,64(a5)
    80001124:	84be                	mv	s1,a5
  pop_off();
    80001126:	0d8050ef          	jal	800061fe <pop_off>
  return p;
}
    8000112a:	8526                	mv	a0,s1
    8000112c:	60e2                	ld	ra,24(sp)
    8000112e:	6442                	ld	s0,16(sp)
    80001130:	64a2                	ld	s1,8(sp)
    80001132:	6105                	addi	sp,sp,32
    80001134:	8082                	ret

0000000080001136 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001136:	1141                	addi	sp,sp,-16
    80001138:	e406                	sd	ra,8(sp)
    8000113a:	e022                	sd	s0,0(sp)
    8000113c:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    8000113e:	fc7ff0ef          	jal	80001104 <myproc>
    80001142:	10c050ef          	jal	8000624e <release>

  if (first) {
    80001146:	00008797          	auipc	a5,0x8
    8000114a:	84a7a783          	lw	a5,-1974(a5) # 80008990 <first.1>
    8000114e:	e799                	bnez	a5,8000115c <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80001150:	2c3000ef          	jal	80001c12 <usertrapret>
}
    80001154:	60a2                	ld	ra,8(sp)
    80001156:	6402                	ld	s0,0(sp)
    80001158:	0141                	addi	sp,sp,16
    8000115a:	8082                	ret
    fsinit(ROOTDEV);
    8000115c:	4505                	li	a0,1
    8000115e:	12f010ef          	jal	80002a8c <fsinit>
    first = 0;
    80001162:	00008797          	auipc	a5,0x8
    80001166:	8207a723          	sw	zero,-2002(a5) # 80008990 <first.1>
    __sync_synchronize();
    8000116a:	0330000f          	fence	rw,rw
    8000116e:	b7cd                	j	80001150 <forkret+0x1a>

0000000080001170 <allocpid>:
{
    80001170:	1101                	addi	sp,sp,-32
    80001172:	ec06                	sd	ra,24(sp)
    80001174:	e822                	sd	s0,16(sp)
    80001176:	e426                	sd	s1,8(sp)
    80001178:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    8000117a:	00008517          	auipc	a0,0x8
    8000117e:	9f650513          	addi	a0,a0,-1546 # 80008b70 <pid_lock>
    80001182:	024050ef          	jal	800061a6 <acquire>
  pid = nextpid;
    80001186:	00008797          	auipc	a5,0x8
    8000118a:	80e78793          	addi	a5,a5,-2034 # 80008994 <nextpid>
    8000118e:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001190:	0014871b          	addiw	a4,s1,1
    80001194:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001196:	00008517          	auipc	a0,0x8
    8000119a:	9da50513          	addi	a0,a0,-1574 # 80008b70 <pid_lock>
    8000119e:	0b0050ef          	jal	8000624e <release>
}
    800011a2:	8526                	mv	a0,s1
    800011a4:	60e2                	ld	ra,24(sp)
    800011a6:	6442                	ld	s0,16(sp)
    800011a8:	64a2                	ld	s1,8(sp)
    800011aa:	6105                	addi	sp,sp,32
    800011ac:	8082                	ret

00000000800011ae <proc_pagetable>:
{
    800011ae:	1101                	addi	sp,sp,-32
    800011b0:	ec06                	sd	ra,24(sp)
    800011b2:	e822                	sd	s0,16(sp)
    800011b4:	e426                	sd	s1,8(sp)
    800011b6:	e04a                	sd	s2,0(sp)
    800011b8:	1000                	addi	s0,sp,32
    800011ba:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800011bc:	8f1ff0ef          	jal	80000aac <uvmcreate>
    800011c0:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800011c2:	cd05                	beqz	a0,800011fa <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    800011c4:	4729                	li	a4,10
    800011c6:	00006697          	auipc	a3,0x6
    800011ca:	e3a68693          	addi	a3,a3,-454 # 80007000 <_trampoline>
    800011ce:	6605                	lui	a2,0x1
    800011d0:	040005b7          	lui	a1,0x4000
    800011d4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011d6:	05b2                	slli	a1,a1,0xc
    800011d8:	e70ff0ef          	jal	80000848 <mappages>
    800011dc:	02054663          	bltz	a0,80001208 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    800011e0:	4719                	li	a4,6
    800011e2:	06093683          	ld	a3,96(s2)
    800011e6:	6605                	lui	a2,0x1
    800011e8:	020005b7          	lui	a1,0x2000
    800011ec:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    800011ee:	05b6                	slli	a1,a1,0xd
    800011f0:	8526                	mv	a0,s1
    800011f2:	e56ff0ef          	jal	80000848 <mappages>
    800011f6:	00054f63          	bltz	a0,80001214 <proc_pagetable+0x66>
}
    800011fa:	8526                	mv	a0,s1
    800011fc:	60e2                	ld	ra,24(sp)
    800011fe:	6442                	ld	s0,16(sp)
    80001200:	64a2                	ld	s1,8(sp)
    80001202:	6902                	ld	s2,0(sp)
    80001204:	6105                	addi	sp,sp,32
    80001206:	8082                	ret
    uvmfree(pagetable, 0);
    80001208:	4581                	li	a1,0
    8000120a:	8526                	mv	a0,s1
    8000120c:	a6fff0ef          	jal	80000c7a <uvmfree>
    return 0;
    80001210:	4481                	li	s1,0
    80001212:	b7e5                	j	800011fa <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001214:	4681                	li	a3,0
    80001216:	4605                	li	a2,1
    80001218:	040005b7          	lui	a1,0x4000
    8000121c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000121e:	05b2                	slli	a1,a1,0xc
    80001220:	8526                	mv	a0,s1
    80001222:	fceff0ef          	jal	800009f0 <uvmunmap>
    uvmfree(pagetable, 0);
    80001226:	4581                	li	a1,0
    80001228:	8526                	mv	a0,s1
    8000122a:	a51ff0ef          	jal	80000c7a <uvmfree>
    return 0;
    8000122e:	4481                	li	s1,0
    80001230:	b7e9                	j	800011fa <proc_pagetable+0x4c>

0000000080001232 <proc_freepagetable>:
{
    80001232:	1101                	addi	sp,sp,-32
    80001234:	ec06                	sd	ra,24(sp)
    80001236:	e822                	sd	s0,16(sp)
    80001238:	e426                	sd	s1,8(sp)
    8000123a:	e04a                	sd	s2,0(sp)
    8000123c:	1000                	addi	s0,sp,32
    8000123e:	84aa                	mv	s1,a0
    80001240:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001242:	4681                	li	a3,0
    80001244:	4605                	li	a2,1
    80001246:	040005b7          	lui	a1,0x4000
    8000124a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000124c:	05b2                	slli	a1,a1,0xc
    8000124e:	fa2ff0ef          	jal	800009f0 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001252:	4681                	li	a3,0
    80001254:	4605                	li	a2,1
    80001256:	020005b7          	lui	a1,0x2000
    8000125a:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    8000125c:	05b6                	slli	a1,a1,0xd
    8000125e:	8526                	mv	a0,s1
    80001260:	f90ff0ef          	jal	800009f0 <uvmunmap>
  uvmfree(pagetable, sz);
    80001264:	85ca                	mv	a1,s2
    80001266:	8526                	mv	a0,s1
    80001268:	a13ff0ef          	jal	80000c7a <uvmfree>
}
    8000126c:	60e2                	ld	ra,24(sp)
    8000126e:	6442                	ld	s0,16(sp)
    80001270:	64a2                	ld	s1,8(sp)
    80001272:	6902                	ld	s2,0(sp)
    80001274:	6105                	addi	sp,sp,32
    80001276:	8082                	ret

0000000080001278 <freeproc>:
{
    80001278:	1101                	addi	sp,sp,-32
    8000127a:	ec06                	sd	ra,24(sp)
    8000127c:	e822                	sd	s0,16(sp)
    8000127e:	e426                	sd	s1,8(sp)
    80001280:	1000                	addi	s0,sp,32
    80001282:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001284:	7128                	ld	a0,96(a0)
    80001286:	c119                	beqz	a0,8000128c <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001288:	ffbfe0ef          	jal	80000282 <kfree>
  p->trapframe = 0;
    8000128c:	0604b023          	sd	zero,96(s1)
  if(p->pagetable)
    80001290:	6ca8                	ld	a0,88(s1)
    80001292:	c501                	beqz	a0,8000129a <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001294:	68ac                	ld	a1,80(s1)
    80001296:	f9dff0ef          	jal	80001232 <proc_freepagetable>
  p->pagetable = 0;
    8000129a:	0404bc23          	sd	zero,88(s1)
  p->sz = 0;
    8000129e:	0404b823          	sd	zero,80(s1)
  p->pid = 0;
    800012a2:	0204ac23          	sw	zero,56(s1)
  p->parent = 0;
    800012a6:	0404b023          	sd	zero,64(s1)
  p->name[0] = 0;
    800012aa:	16048023          	sb	zero,352(s1)
  p->chan = 0;
    800012ae:	0204b423          	sd	zero,40(s1)
  p->killed = 0;
    800012b2:	0204a823          	sw	zero,48(s1)
  p->xstate = 0;
    800012b6:	0204aa23          	sw	zero,52(s1)
  p->state = UNUSED;
    800012ba:	0204a023          	sw	zero,32(s1)
}
    800012be:	60e2                	ld	ra,24(sp)
    800012c0:	6442                	ld	s0,16(sp)
    800012c2:	64a2                	ld	s1,8(sp)
    800012c4:	6105                	addi	sp,sp,32
    800012c6:	8082                	ret

00000000800012c8 <allocproc>:
{
    800012c8:	1101                	addi	sp,sp,-32
    800012ca:	ec06                	sd	ra,24(sp)
    800012cc:	e822                	sd	s0,16(sp)
    800012ce:	e426                	sd	s1,8(sp)
    800012d0:	e04a                	sd	s2,0(sp)
    800012d2:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    800012d4:	00008497          	auipc	s1,0x8
    800012d8:	cdc48493          	addi	s1,s1,-804 # 80008fb0 <proc>
    800012dc:	0000e917          	auipc	s2,0xe
    800012e0:	8d490913          	addi	s2,s2,-1836 # 8000ebb0 <tickslock>
    acquire(&p->lock);
    800012e4:	8526                	mv	a0,s1
    800012e6:	6c1040ef          	jal	800061a6 <acquire>
    if(p->state == UNUSED) {
    800012ea:	509c                	lw	a5,32(s1)
    800012ec:	cb91                	beqz	a5,80001300 <allocproc+0x38>
      release(&p->lock);
    800012ee:	8526                	mv	a0,s1
    800012f0:	75f040ef          	jal	8000624e <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800012f4:	17048493          	addi	s1,s1,368
    800012f8:	ff2496e3          	bne	s1,s2,800012e4 <allocproc+0x1c>
  return 0;
    800012fc:	4481                	li	s1,0
    800012fe:	a089                	j	80001340 <allocproc+0x78>
  p->pid = allocpid();
    80001300:	e71ff0ef          	jal	80001170 <allocpid>
    80001304:	dc88                	sw	a0,56(s1)
  p->state = USED;
    80001306:	4785                	li	a5,1
    80001308:	d09c                	sw	a5,32(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    8000130a:	808ff0ef          	jal	80000312 <kalloc>
    8000130e:	892a                	mv	s2,a0
    80001310:	f0a8                	sd	a0,96(s1)
    80001312:	cd15                	beqz	a0,8000134e <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001314:	8526                	mv	a0,s1
    80001316:	e99ff0ef          	jal	800011ae <proc_pagetable>
    8000131a:	892a                	mv	s2,a0
    8000131c:	eca8                	sd	a0,88(s1)
  if(p->pagetable == 0){
    8000131e:	c121                	beqz	a0,8000135e <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001320:	07000613          	li	a2,112
    80001324:	4581                	li	a1,0
    80001326:	06848513          	addi	a0,s1,104
    8000132a:	9aeff0ef          	jal	800004d8 <memset>
  p->context.ra = (uint64)forkret;
    8000132e:	00000797          	auipc	a5,0x0
    80001332:	e0878793          	addi	a5,a5,-504 # 80001136 <forkret>
    80001336:	f4bc                	sd	a5,104(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001338:	64bc                	ld	a5,72(s1)
    8000133a:	6705                	lui	a4,0x1
    8000133c:	97ba                	add	a5,a5,a4
    8000133e:	f8bc                	sd	a5,112(s1)
}
    80001340:	8526                	mv	a0,s1
    80001342:	60e2                	ld	ra,24(sp)
    80001344:	6442                	ld	s0,16(sp)
    80001346:	64a2                	ld	s1,8(sp)
    80001348:	6902                	ld	s2,0(sp)
    8000134a:	6105                	addi	sp,sp,32
    8000134c:	8082                	ret
    freeproc(p);
    8000134e:	8526                	mv	a0,s1
    80001350:	f29ff0ef          	jal	80001278 <freeproc>
    release(&p->lock);
    80001354:	8526                	mv	a0,s1
    80001356:	6f9040ef          	jal	8000624e <release>
    return 0;
    8000135a:	84ca                	mv	s1,s2
    8000135c:	b7d5                	j	80001340 <allocproc+0x78>
    freeproc(p);
    8000135e:	8526                	mv	a0,s1
    80001360:	f19ff0ef          	jal	80001278 <freeproc>
    release(&p->lock);
    80001364:	8526                	mv	a0,s1
    80001366:	6e9040ef          	jal	8000624e <release>
    return 0;
    8000136a:	84ca                	mv	s1,s2
    8000136c:	bfd1                	j	80001340 <allocproc+0x78>

000000008000136e <userinit>:
{
    8000136e:	1101                	addi	sp,sp,-32
    80001370:	ec06                	sd	ra,24(sp)
    80001372:	e822                	sd	s0,16(sp)
    80001374:	e426                	sd	s1,8(sp)
    80001376:	1000                	addi	s0,sp,32
  p = allocproc();
    80001378:	f51ff0ef          	jal	800012c8 <allocproc>
    8000137c:	84aa                	mv	s1,a0
  initproc = p;
    8000137e:	00007797          	auipc	a5,0x7
    80001382:	66a7b923          	sd	a0,1650(a5) # 800089f0 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001386:	03400613          	li	a2,52
    8000138a:	00007597          	auipc	a1,0x7
    8000138e:	61658593          	addi	a1,a1,1558 # 800089a0 <initcode>
    80001392:	6d28                	ld	a0,88(a0)
    80001394:	f3eff0ef          	jal	80000ad2 <uvmfirst>
  p->sz = PGSIZE;
    80001398:	6785                	lui	a5,0x1
    8000139a:	e8bc                	sd	a5,80(s1)
  p->trapframe->epc = 0;      // user program counter
    8000139c:	70b8                	ld	a4,96(s1)
    8000139e:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    800013a2:	70b8                	ld	a4,96(s1)
    800013a4:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    800013a6:	4641                	li	a2,16
    800013a8:	00007597          	auipc	a1,0x7
    800013ac:	e1058593          	addi	a1,a1,-496 # 800081b8 <etext+0x1b8>
    800013b0:	16048513          	addi	a0,s1,352
    800013b4:	a78ff0ef          	jal	8000062c <safestrcpy>
  p->cwd = namei("/");
    800013b8:	00007517          	auipc	a0,0x7
    800013bc:	e1050513          	addi	a0,a0,-496 # 800081c8 <etext+0x1c8>
    800013c0:	000020ef          	jal	800033c0 <namei>
    800013c4:	14a4bc23          	sd	a0,344(s1)
  p->state = RUNNABLE;
    800013c8:	478d                	li	a5,3
    800013ca:	d09c                	sw	a5,32(s1)
  release(&p->lock);
    800013cc:	8526                	mv	a0,s1
    800013ce:	681040ef          	jal	8000624e <release>
}
    800013d2:	60e2                	ld	ra,24(sp)
    800013d4:	6442                	ld	s0,16(sp)
    800013d6:	64a2                	ld	s1,8(sp)
    800013d8:	6105                	addi	sp,sp,32
    800013da:	8082                	ret

00000000800013dc <growproc>:
{
    800013dc:	1101                	addi	sp,sp,-32
    800013de:	ec06                	sd	ra,24(sp)
    800013e0:	e822                	sd	s0,16(sp)
    800013e2:	e426                	sd	s1,8(sp)
    800013e4:	e04a                	sd	s2,0(sp)
    800013e6:	1000                	addi	s0,sp,32
    800013e8:	892a                	mv	s2,a0
  struct proc *p = myproc();
    800013ea:	d1bff0ef          	jal	80001104 <myproc>
    800013ee:	84aa                	mv	s1,a0
  sz = p->sz;
    800013f0:	692c                	ld	a1,80(a0)
  if(n > 0){
    800013f2:	01204c63          	bgtz	s2,8000140a <growproc+0x2e>
  } else if(n < 0){
    800013f6:	02094463          	bltz	s2,8000141e <growproc+0x42>
  p->sz = sz;
    800013fa:	e8ac                	sd	a1,80(s1)
  return 0;
    800013fc:	4501                	li	a0,0
}
    800013fe:	60e2                	ld	ra,24(sp)
    80001400:	6442                	ld	s0,16(sp)
    80001402:	64a2                	ld	s1,8(sp)
    80001404:	6902                	ld	s2,0(sp)
    80001406:	6105                	addi	sp,sp,32
    80001408:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    8000140a:	4691                	li	a3,4
    8000140c:	00b90633          	add	a2,s2,a1
    80001410:	6d28                	ld	a0,88(a0)
    80001412:	f62ff0ef          	jal	80000b74 <uvmalloc>
    80001416:	85aa                	mv	a1,a0
    80001418:	f16d                	bnez	a0,800013fa <growproc+0x1e>
      return -1;
    8000141a:	557d                	li	a0,-1
    8000141c:	b7cd                	j	800013fe <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    8000141e:	00b90633          	add	a2,s2,a1
    80001422:	6d28                	ld	a0,88(a0)
    80001424:	f0cff0ef          	jal	80000b30 <uvmdealloc>
    80001428:	85aa                	mv	a1,a0
    8000142a:	bfc1                	j	800013fa <growproc+0x1e>

000000008000142c <fork>:
{
    8000142c:	7139                	addi	sp,sp,-64
    8000142e:	fc06                	sd	ra,56(sp)
    80001430:	f822                	sd	s0,48(sp)
    80001432:	f426                	sd	s1,40(sp)
    80001434:	e456                	sd	s5,8(sp)
    80001436:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001438:	ccdff0ef          	jal	80001104 <myproc>
    8000143c:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    8000143e:	e8bff0ef          	jal	800012c8 <allocproc>
    80001442:	0e050a63          	beqz	a0,80001536 <fork+0x10a>
    80001446:	e852                	sd	s4,16(sp)
    80001448:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    8000144a:	050ab603          	ld	a2,80(s5)
    8000144e:	6d2c                	ld	a1,88(a0)
    80001450:	058ab503          	ld	a0,88(s5)
    80001454:	859ff0ef          	jal	80000cac <uvmcopy>
    80001458:	04054863          	bltz	a0,800014a8 <fork+0x7c>
    8000145c:	f04a                	sd	s2,32(sp)
    8000145e:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001460:	050ab783          	ld	a5,80(s5)
    80001464:	04fa3823          	sd	a5,80(s4)
  *(np->trapframe) = *(p->trapframe);
    80001468:	060ab683          	ld	a3,96(s5)
    8000146c:	87b6                	mv	a5,a3
    8000146e:	060a3703          	ld	a4,96(s4)
    80001472:	12068693          	addi	a3,a3,288
    80001476:	6388                	ld	a0,0(a5)
    80001478:	678c                	ld	a1,8(a5)
    8000147a:	6b90                	ld	a2,16(a5)
    8000147c:	e308                	sd	a0,0(a4)
    8000147e:	e70c                	sd	a1,8(a4)
    80001480:	eb10                	sd	a2,16(a4)
    80001482:	6f90                	ld	a2,24(a5)
    80001484:	ef10                	sd	a2,24(a4)
    80001486:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    8000148a:	02070713          	addi	a4,a4,32
    8000148e:	fed794e3          	bne	a5,a3,80001476 <fork+0x4a>
  np->trapframe->a0 = 0;
    80001492:	060a3783          	ld	a5,96(s4)
    80001496:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    8000149a:	0d8a8493          	addi	s1,s5,216
    8000149e:	0d8a0913          	addi	s2,s4,216
    800014a2:	158a8993          	addi	s3,s5,344
    800014a6:	a831                	j	800014c2 <fork+0x96>
    freeproc(np);
    800014a8:	8552                	mv	a0,s4
    800014aa:	dcfff0ef          	jal	80001278 <freeproc>
    release(&np->lock);
    800014ae:	8552                	mv	a0,s4
    800014b0:	59f040ef          	jal	8000624e <release>
    return -1;
    800014b4:	54fd                	li	s1,-1
    800014b6:	6a42                	ld	s4,16(sp)
    800014b8:	a885                	j	80001528 <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    800014ba:	04a1                	addi	s1,s1,8
    800014bc:	0921                	addi	s2,s2,8
    800014be:	01348963          	beq	s1,s3,800014d0 <fork+0xa4>
    if(p->ofile[i])
    800014c2:	6088                	ld	a0,0(s1)
    800014c4:	d97d                	beqz	a0,800014ba <fork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    800014c6:	4a8020ef          	jal	8000396e <filedup>
    800014ca:	00a93023          	sd	a0,0(s2)
    800014ce:	b7f5                	j	800014ba <fork+0x8e>
  np->cwd = idup(p->cwd);
    800014d0:	158ab503          	ld	a0,344(s5)
    800014d4:	7b4010ef          	jal	80002c88 <idup>
    800014d8:	14aa3c23          	sd	a0,344(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    800014dc:	4641                	li	a2,16
    800014de:	160a8593          	addi	a1,s5,352
    800014e2:	160a0513          	addi	a0,s4,352
    800014e6:	946ff0ef          	jal	8000062c <safestrcpy>
  pid = np->pid;
    800014ea:	038a2483          	lw	s1,56(s4)
  release(&np->lock);
    800014ee:	8552                	mv	a0,s4
    800014f0:	55f040ef          	jal	8000624e <release>
  acquire(&wait_lock);
    800014f4:	00007517          	auipc	a0,0x7
    800014f8:	69c50513          	addi	a0,a0,1692 # 80008b90 <wait_lock>
    800014fc:	4ab040ef          	jal	800061a6 <acquire>
  np->parent = p;
    80001500:	055a3023          	sd	s5,64(s4)
  release(&wait_lock);
    80001504:	00007517          	auipc	a0,0x7
    80001508:	68c50513          	addi	a0,a0,1676 # 80008b90 <wait_lock>
    8000150c:	543040ef          	jal	8000624e <release>
  acquire(&np->lock);
    80001510:	8552                	mv	a0,s4
    80001512:	495040ef          	jal	800061a6 <acquire>
  np->state = RUNNABLE;
    80001516:	478d                	li	a5,3
    80001518:	02fa2023          	sw	a5,32(s4)
  release(&np->lock);
    8000151c:	8552                	mv	a0,s4
    8000151e:	531040ef          	jal	8000624e <release>
  return pid;
    80001522:	7902                	ld	s2,32(sp)
    80001524:	69e2                	ld	s3,24(sp)
    80001526:	6a42                	ld	s4,16(sp)
}
    80001528:	8526                	mv	a0,s1
    8000152a:	70e2                	ld	ra,56(sp)
    8000152c:	7442                	ld	s0,48(sp)
    8000152e:	74a2                	ld	s1,40(sp)
    80001530:	6aa2                	ld	s5,8(sp)
    80001532:	6121                	addi	sp,sp,64
    80001534:	8082                	ret
    return -1;
    80001536:	54fd                	li	s1,-1
    80001538:	bfc5                	j	80001528 <fork+0xfc>

000000008000153a <scheduler>:
{
    8000153a:	715d                	addi	sp,sp,-80
    8000153c:	e486                	sd	ra,72(sp)
    8000153e:	e0a2                	sd	s0,64(sp)
    80001540:	fc26                	sd	s1,56(sp)
    80001542:	f84a                	sd	s2,48(sp)
    80001544:	f44e                	sd	s3,40(sp)
    80001546:	f052                	sd	s4,32(sp)
    80001548:	ec56                	sd	s5,24(sp)
    8000154a:	e85a                	sd	s6,16(sp)
    8000154c:	e45e                	sd	s7,8(sp)
    8000154e:	e062                	sd	s8,0(sp)
    80001550:	0880                	addi	s0,sp,80
    80001552:	8792                	mv	a5,tp
  int id = r_tp();
    80001554:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001556:	00779b13          	slli	s6,a5,0x7
    8000155a:	00007717          	auipc	a4,0x7
    8000155e:	61670713          	addi	a4,a4,1558 # 80008b70 <pid_lock>
    80001562:	975a                	add	a4,a4,s6
    80001564:	04073023          	sd	zero,64(a4)
        swtch(&c->context, &p->context);
    80001568:	00007717          	auipc	a4,0x7
    8000156c:	65070713          	addi	a4,a4,1616 # 80008bb8 <cpus+0x8>
    80001570:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001572:	4c11                	li	s8,4
        c->proc = p;
    80001574:	079e                	slli	a5,a5,0x7
    80001576:	00007a17          	auipc	s4,0x7
    8000157a:	5faa0a13          	addi	s4,s4,1530 # 80008b70 <pid_lock>
    8000157e:	9a3e                	add	s4,s4,a5
        found = 1;
    80001580:	4b85                	li	s7,1
    80001582:	a0a9                	j	800015cc <scheduler+0x92>
      release(&p->lock);
    80001584:	8526                	mv	a0,s1
    80001586:	4c9040ef          	jal	8000624e <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    8000158a:	17048493          	addi	s1,s1,368
    8000158e:	03248563          	beq	s1,s2,800015b8 <scheduler+0x7e>
      acquire(&p->lock);
    80001592:	8526                	mv	a0,s1
    80001594:	413040ef          	jal	800061a6 <acquire>
      if(p->state == RUNNABLE) {
    80001598:	509c                	lw	a5,32(s1)
    8000159a:	ff3795e3          	bne	a5,s3,80001584 <scheduler+0x4a>
        p->state = RUNNING;
    8000159e:	0384a023          	sw	s8,32(s1)
        c->proc = p;
    800015a2:	049a3023          	sd	s1,64(s4)
        swtch(&c->context, &p->context);
    800015a6:	06848593          	addi	a1,s1,104
    800015aa:	855a                	mv	a0,s6
    800015ac:	5bc000ef          	jal	80001b68 <swtch>
        c->proc = 0;
    800015b0:	040a3023          	sd	zero,64(s4)
        found = 1;
    800015b4:	8ade                	mv	s5,s7
    800015b6:	b7f9                	j	80001584 <scheduler+0x4a>
    if(found == 0) {
    800015b8:	000a9a63          	bnez	s5,800015cc <scheduler+0x92>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800015bc:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800015c0:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800015c4:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    800015c8:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800015cc:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800015d0:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800015d4:	10079073          	csrw	sstatus,a5
    int found = 0;
    800015d8:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    800015da:	00008497          	auipc	s1,0x8
    800015de:	9d648493          	addi	s1,s1,-1578 # 80008fb0 <proc>
      if(p->state == RUNNABLE) {
    800015e2:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    800015e4:	0000d917          	auipc	s2,0xd
    800015e8:	5cc90913          	addi	s2,s2,1484 # 8000ebb0 <tickslock>
    800015ec:	b75d                	j	80001592 <scheduler+0x58>

00000000800015ee <sched>:
{
    800015ee:	7179                	addi	sp,sp,-48
    800015f0:	f406                	sd	ra,40(sp)
    800015f2:	f022                	sd	s0,32(sp)
    800015f4:	ec26                	sd	s1,24(sp)
    800015f6:	e84a                	sd	s2,16(sp)
    800015f8:	e44e                	sd	s3,8(sp)
    800015fa:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    800015fc:	b09ff0ef          	jal	80001104 <myproc>
    80001600:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001602:	335040ef          	jal	80006136 <holding>
    80001606:	c935                	beqz	a0,8000167a <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001608:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    8000160a:	2781                	sext.w	a5,a5
    8000160c:	079e                	slli	a5,a5,0x7
    8000160e:	00007717          	auipc	a4,0x7
    80001612:	56270713          	addi	a4,a4,1378 # 80008b70 <pid_lock>
    80001616:	97ba                	add	a5,a5,a4
    80001618:	0b87a703          	lw	a4,184(a5)
    8000161c:	4785                	li	a5,1
    8000161e:	06f71463          	bne	a4,a5,80001686 <sched+0x98>
  if(p->state == RUNNING)
    80001622:	5098                	lw	a4,32(s1)
    80001624:	4791                	li	a5,4
    80001626:	06f70663          	beq	a4,a5,80001692 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000162a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000162e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001630:	e7bd                	bnez	a5,8000169e <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001632:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001634:	00007917          	auipc	s2,0x7
    80001638:	53c90913          	addi	s2,s2,1340 # 80008b70 <pid_lock>
    8000163c:	2781                	sext.w	a5,a5
    8000163e:	079e                	slli	a5,a5,0x7
    80001640:	97ca                	add	a5,a5,s2
    80001642:	0bc7a983          	lw	s3,188(a5)
    80001646:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001648:	2781                	sext.w	a5,a5
    8000164a:	079e                	slli	a5,a5,0x7
    8000164c:	07a1                	addi	a5,a5,8
    8000164e:	00007597          	auipc	a1,0x7
    80001652:	56258593          	addi	a1,a1,1378 # 80008bb0 <cpus>
    80001656:	95be                	add	a1,a1,a5
    80001658:	06848513          	addi	a0,s1,104
    8000165c:	50c000ef          	jal	80001b68 <swtch>
    80001660:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001662:	2781                	sext.w	a5,a5
    80001664:	079e                	slli	a5,a5,0x7
    80001666:	993e                	add	s2,s2,a5
    80001668:	0b392e23          	sw	s3,188(s2)
}
    8000166c:	70a2                	ld	ra,40(sp)
    8000166e:	7402                	ld	s0,32(sp)
    80001670:	64e2                	ld	s1,24(sp)
    80001672:	6942                	ld	s2,16(sp)
    80001674:	69a2                	ld	s3,8(sp)
    80001676:	6145                	addi	sp,sp,48
    80001678:	8082                	ret
    panic("sched p->lock");
    8000167a:	00007517          	auipc	a0,0x7
    8000167e:	b5650513          	addi	a0,a0,-1194 # 800081d0 <etext+0x1d0>
    80001682:	001040ef          	jal	80005e82 <panic>
    panic("sched locks");
    80001686:	00007517          	auipc	a0,0x7
    8000168a:	b5a50513          	addi	a0,a0,-1190 # 800081e0 <etext+0x1e0>
    8000168e:	7f4040ef          	jal	80005e82 <panic>
    panic("sched running");
    80001692:	00007517          	auipc	a0,0x7
    80001696:	b5e50513          	addi	a0,a0,-1186 # 800081f0 <etext+0x1f0>
    8000169a:	7e8040ef          	jal	80005e82 <panic>
    panic("sched interruptible");
    8000169e:	00007517          	auipc	a0,0x7
    800016a2:	b6250513          	addi	a0,a0,-1182 # 80008200 <etext+0x200>
    800016a6:	7dc040ef          	jal	80005e82 <panic>

00000000800016aa <yield>:
{
    800016aa:	1101                	addi	sp,sp,-32
    800016ac:	ec06                	sd	ra,24(sp)
    800016ae:	e822                	sd	s0,16(sp)
    800016b0:	e426                	sd	s1,8(sp)
    800016b2:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800016b4:	a51ff0ef          	jal	80001104 <myproc>
    800016b8:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800016ba:	2ed040ef          	jal	800061a6 <acquire>
  p->state = RUNNABLE;
    800016be:	478d                	li	a5,3
    800016c0:	d09c                	sw	a5,32(s1)
  sched();
    800016c2:	f2dff0ef          	jal	800015ee <sched>
  release(&p->lock);
    800016c6:	8526                	mv	a0,s1
    800016c8:	387040ef          	jal	8000624e <release>
}
    800016cc:	60e2                	ld	ra,24(sp)
    800016ce:	6442                	ld	s0,16(sp)
    800016d0:	64a2                	ld	s1,8(sp)
    800016d2:	6105                	addi	sp,sp,32
    800016d4:	8082                	ret

00000000800016d6 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    800016d6:	7179                	addi	sp,sp,-48
    800016d8:	f406                	sd	ra,40(sp)
    800016da:	f022                	sd	s0,32(sp)
    800016dc:	ec26                	sd	s1,24(sp)
    800016de:	e84a                	sd	s2,16(sp)
    800016e0:	e44e                	sd	s3,8(sp)
    800016e2:	1800                	addi	s0,sp,48
    800016e4:	89aa                	mv	s3,a0
    800016e6:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800016e8:	a1dff0ef          	jal	80001104 <myproc>
    800016ec:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    800016ee:	2b9040ef          	jal	800061a6 <acquire>
  release(lk);
    800016f2:	854a                	mv	a0,s2
    800016f4:	35b040ef          	jal	8000624e <release>

  // Go to sleep.
  p->chan = chan;
    800016f8:	0334b423          	sd	s3,40(s1)
  p->state = SLEEPING;
    800016fc:	4789                	li	a5,2
    800016fe:	d09c                	sw	a5,32(s1)

  sched();
    80001700:	eefff0ef          	jal	800015ee <sched>

  // Tidy up.
  p->chan = 0;
    80001704:	0204b423          	sd	zero,40(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001708:	8526                	mv	a0,s1
    8000170a:	345040ef          	jal	8000624e <release>
  acquire(lk);
    8000170e:	854a                	mv	a0,s2
    80001710:	297040ef          	jal	800061a6 <acquire>
}
    80001714:	70a2                	ld	ra,40(sp)
    80001716:	7402                	ld	s0,32(sp)
    80001718:	64e2                	ld	s1,24(sp)
    8000171a:	6942                	ld	s2,16(sp)
    8000171c:	69a2                	ld	s3,8(sp)
    8000171e:	6145                	addi	sp,sp,48
    80001720:	8082                	ret

0000000080001722 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    80001722:	7139                	addi	sp,sp,-64
    80001724:	fc06                	sd	ra,56(sp)
    80001726:	f822                	sd	s0,48(sp)
    80001728:	f426                	sd	s1,40(sp)
    8000172a:	f04a                	sd	s2,32(sp)
    8000172c:	ec4e                	sd	s3,24(sp)
    8000172e:	e852                	sd	s4,16(sp)
    80001730:	e456                	sd	s5,8(sp)
    80001732:	0080                	addi	s0,sp,64
    80001734:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001736:	00008497          	auipc	s1,0x8
    8000173a:	87a48493          	addi	s1,s1,-1926 # 80008fb0 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    8000173e:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001740:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001742:	0000d917          	auipc	s2,0xd
    80001746:	46e90913          	addi	s2,s2,1134 # 8000ebb0 <tickslock>
    8000174a:	a801                	j	8000175a <wakeup+0x38>
      }
      release(&p->lock);
    8000174c:	8526                	mv	a0,s1
    8000174e:	301040ef          	jal	8000624e <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001752:	17048493          	addi	s1,s1,368
    80001756:	03248263          	beq	s1,s2,8000177a <wakeup+0x58>
    if(p != myproc()){
    8000175a:	9abff0ef          	jal	80001104 <myproc>
    8000175e:	fe950ae3          	beq	a0,s1,80001752 <wakeup+0x30>
      acquire(&p->lock);
    80001762:	8526                	mv	a0,s1
    80001764:	243040ef          	jal	800061a6 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001768:	509c                	lw	a5,32(s1)
    8000176a:	ff3791e3          	bne	a5,s3,8000174c <wakeup+0x2a>
    8000176e:	749c                	ld	a5,40(s1)
    80001770:	fd479ee3          	bne	a5,s4,8000174c <wakeup+0x2a>
        p->state = RUNNABLE;
    80001774:	0354a023          	sw	s5,32(s1)
    80001778:	bfd1                	j	8000174c <wakeup+0x2a>
    }
  }
}
    8000177a:	70e2                	ld	ra,56(sp)
    8000177c:	7442                	ld	s0,48(sp)
    8000177e:	74a2                	ld	s1,40(sp)
    80001780:	7902                	ld	s2,32(sp)
    80001782:	69e2                	ld	s3,24(sp)
    80001784:	6a42                	ld	s4,16(sp)
    80001786:	6aa2                	ld	s5,8(sp)
    80001788:	6121                	addi	sp,sp,64
    8000178a:	8082                	ret

000000008000178c <reparent>:
{
    8000178c:	7179                	addi	sp,sp,-48
    8000178e:	f406                	sd	ra,40(sp)
    80001790:	f022                	sd	s0,32(sp)
    80001792:	ec26                	sd	s1,24(sp)
    80001794:	e84a                	sd	s2,16(sp)
    80001796:	e44e                	sd	s3,8(sp)
    80001798:	e052                	sd	s4,0(sp)
    8000179a:	1800                	addi	s0,sp,48
    8000179c:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000179e:	00008497          	auipc	s1,0x8
    800017a2:	81248493          	addi	s1,s1,-2030 # 80008fb0 <proc>
      pp->parent = initproc;
    800017a6:	00007a17          	auipc	s4,0x7
    800017aa:	24aa0a13          	addi	s4,s4,586 # 800089f0 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800017ae:	0000d997          	auipc	s3,0xd
    800017b2:	40298993          	addi	s3,s3,1026 # 8000ebb0 <tickslock>
    800017b6:	a029                	j	800017c0 <reparent+0x34>
    800017b8:	17048493          	addi	s1,s1,368
    800017bc:	01348b63          	beq	s1,s3,800017d2 <reparent+0x46>
    if(pp->parent == p){
    800017c0:	60bc                	ld	a5,64(s1)
    800017c2:	ff279be3          	bne	a5,s2,800017b8 <reparent+0x2c>
      pp->parent = initproc;
    800017c6:	000a3503          	ld	a0,0(s4)
    800017ca:	e0a8                	sd	a0,64(s1)
      wakeup(initproc);
    800017cc:	f57ff0ef          	jal	80001722 <wakeup>
    800017d0:	b7e5                	j	800017b8 <reparent+0x2c>
}
    800017d2:	70a2                	ld	ra,40(sp)
    800017d4:	7402                	ld	s0,32(sp)
    800017d6:	64e2                	ld	s1,24(sp)
    800017d8:	6942                	ld	s2,16(sp)
    800017da:	69a2                	ld	s3,8(sp)
    800017dc:	6a02                	ld	s4,0(sp)
    800017de:	6145                	addi	sp,sp,48
    800017e0:	8082                	ret

00000000800017e2 <exit>:
{
    800017e2:	7179                	addi	sp,sp,-48
    800017e4:	f406                	sd	ra,40(sp)
    800017e6:	f022                	sd	s0,32(sp)
    800017e8:	ec26                	sd	s1,24(sp)
    800017ea:	e84a                	sd	s2,16(sp)
    800017ec:	e44e                	sd	s3,8(sp)
    800017ee:	e052                	sd	s4,0(sp)
    800017f0:	1800                	addi	s0,sp,48
    800017f2:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800017f4:	911ff0ef          	jal	80001104 <myproc>
    800017f8:	89aa                	mv	s3,a0
  if(p == initproc)
    800017fa:	00007797          	auipc	a5,0x7
    800017fe:	1f67b783          	ld	a5,502(a5) # 800089f0 <initproc>
    80001802:	0d850493          	addi	s1,a0,216
    80001806:	15850913          	addi	s2,a0,344
    8000180a:	00a79b63          	bne	a5,a0,80001820 <exit+0x3e>
    panic("init exiting");
    8000180e:	00007517          	auipc	a0,0x7
    80001812:	a0a50513          	addi	a0,a0,-1526 # 80008218 <etext+0x218>
    80001816:	66c040ef          	jal	80005e82 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    8000181a:	04a1                	addi	s1,s1,8
    8000181c:	01248963          	beq	s1,s2,8000182e <exit+0x4c>
    if(p->ofile[fd]){
    80001820:	6088                	ld	a0,0(s1)
    80001822:	dd65                	beqz	a0,8000181a <exit+0x38>
      fileclose(f);
    80001824:	190020ef          	jal	800039b4 <fileclose>
      p->ofile[fd] = 0;
    80001828:	0004b023          	sd	zero,0(s1)
    8000182c:	b7fd                	j	8000181a <exit+0x38>
  begin_op();
    8000182e:	555010ef          	jal	80003582 <begin_op>
  iput(p->cwd);
    80001832:	1589b503          	ld	a0,344(s3)
    80001836:	616010ef          	jal	80002e4c <iput>
  end_op();
    8000183a:	5b9010ef          	jal	800035f2 <end_op>
  p->cwd = 0;
    8000183e:	1409bc23          	sd	zero,344(s3)
  acquire(&wait_lock);
    80001842:	00007517          	auipc	a0,0x7
    80001846:	34e50513          	addi	a0,a0,846 # 80008b90 <wait_lock>
    8000184a:	15d040ef          	jal	800061a6 <acquire>
  reparent(p);
    8000184e:	854e                	mv	a0,s3
    80001850:	f3dff0ef          	jal	8000178c <reparent>
  wakeup(p->parent);
    80001854:	0409b503          	ld	a0,64(s3)
    80001858:	ecbff0ef          	jal	80001722 <wakeup>
  acquire(&p->lock);
    8000185c:	854e                	mv	a0,s3
    8000185e:	149040ef          	jal	800061a6 <acquire>
  p->xstate = status;
    80001862:	0349aa23          	sw	s4,52(s3)
  p->state = ZOMBIE;
    80001866:	4795                	li	a5,5
    80001868:	02f9a023          	sw	a5,32(s3)
  release(&wait_lock);
    8000186c:	00007517          	auipc	a0,0x7
    80001870:	32450513          	addi	a0,a0,804 # 80008b90 <wait_lock>
    80001874:	1db040ef          	jal	8000624e <release>
  sched();
    80001878:	d77ff0ef          	jal	800015ee <sched>
  panic("zombie exit");
    8000187c:	00007517          	auipc	a0,0x7
    80001880:	9ac50513          	addi	a0,a0,-1620 # 80008228 <etext+0x228>
    80001884:	5fe040ef          	jal	80005e82 <panic>

0000000080001888 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80001888:	7179                	addi	sp,sp,-48
    8000188a:	f406                	sd	ra,40(sp)
    8000188c:	f022                	sd	s0,32(sp)
    8000188e:	ec26                	sd	s1,24(sp)
    80001890:	e84a                	sd	s2,16(sp)
    80001892:	e44e                	sd	s3,8(sp)
    80001894:	1800                	addi	s0,sp,48
    80001896:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80001898:	00007497          	auipc	s1,0x7
    8000189c:	71848493          	addi	s1,s1,1816 # 80008fb0 <proc>
    800018a0:	0000d997          	auipc	s3,0xd
    800018a4:	31098993          	addi	s3,s3,784 # 8000ebb0 <tickslock>
    acquire(&p->lock);
    800018a8:	8526                	mv	a0,s1
    800018aa:	0fd040ef          	jal	800061a6 <acquire>
    if(p->pid == pid){
    800018ae:	5c9c                	lw	a5,56(s1)
    800018b0:	01278b63          	beq	a5,s2,800018c6 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800018b4:	8526                	mv	a0,s1
    800018b6:	199040ef          	jal	8000624e <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800018ba:	17048493          	addi	s1,s1,368
    800018be:	ff3495e3          	bne	s1,s3,800018a8 <kill+0x20>
  }
  return -1;
    800018c2:	557d                	li	a0,-1
    800018c4:	a819                	j	800018da <kill+0x52>
      p->killed = 1;
    800018c6:	4785                	li	a5,1
    800018c8:	d89c                	sw	a5,48(s1)
      if(p->state == SLEEPING){
    800018ca:	5098                	lw	a4,32(s1)
    800018cc:	4789                	li	a5,2
    800018ce:	00f70d63          	beq	a4,a5,800018e8 <kill+0x60>
      release(&p->lock);
    800018d2:	8526                	mv	a0,s1
    800018d4:	17b040ef          	jal	8000624e <release>
      return 0;
    800018d8:	4501                	li	a0,0
}
    800018da:	70a2                	ld	ra,40(sp)
    800018dc:	7402                	ld	s0,32(sp)
    800018de:	64e2                	ld	s1,24(sp)
    800018e0:	6942                	ld	s2,16(sp)
    800018e2:	69a2                	ld	s3,8(sp)
    800018e4:	6145                	addi	sp,sp,48
    800018e6:	8082                	ret
        p->state = RUNNABLE;
    800018e8:	478d                	li	a5,3
    800018ea:	d09c                	sw	a5,32(s1)
    800018ec:	b7dd                	j	800018d2 <kill+0x4a>

00000000800018ee <setkilled>:

void
setkilled(struct proc *p)
{
    800018ee:	1101                	addi	sp,sp,-32
    800018f0:	ec06                	sd	ra,24(sp)
    800018f2:	e822                	sd	s0,16(sp)
    800018f4:	e426                	sd	s1,8(sp)
    800018f6:	1000                	addi	s0,sp,32
    800018f8:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800018fa:	0ad040ef          	jal	800061a6 <acquire>
  p->killed = 1;
    800018fe:	4785                	li	a5,1
    80001900:	d89c                	sw	a5,48(s1)
  release(&p->lock);
    80001902:	8526                	mv	a0,s1
    80001904:	14b040ef          	jal	8000624e <release>
}
    80001908:	60e2                	ld	ra,24(sp)
    8000190a:	6442                	ld	s0,16(sp)
    8000190c:	64a2                	ld	s1,8(sp)
    8000190e:	6105                	addi	sp,sp,32
    80001910:	8082                	ret

0000000080001912 <killed>:

int
killed(struct proc *p)
{
    80001912:	1101                	addi	sp,sp,-32
    80001914:	ec06                	sd	ra,24(sp)
    80001916:	e822                	sd	s0,16(sp)
    80001918:	e426                	sd	s1,8(sp)
    8000191a:	e04a                	sd	s2,0(sp)
    8000191c:	1000                	addi	s0,sp,32
    8000191e:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80001920:	087040ef          	jal	800061a6 <acquire>
  k = p->killed;
    80001924:	589c                	lw	a5,48(s1)
    80001926:	893e                	mv	s2,a5
  release(&p->lock);
    80001928:	8526                	mv	a0,s1
    8000192a:	125040ef          	jal	8000624e <release>
  return k;
}
    8000192e:	854a                	mv	a0,s2
    80001930:	60e2                	ld	ra,24(sp)
    80001932:	6442                	ld	s0,16(sp)
    80001934:	64a2                	ld	s1,8(sp)
    80001936:	6902                	ld	s2,0(sp)
    80001938:	6105                	addi	sp,sp,32
    8000193a:	8082                	ret

000000008000193c <wait>:
{
    8000193c:	715d                	addi	sp,sp,-80
    8000193e:	e486                	sd	ra,72(sp)
    80001940:	e0a2                	sd	s0,64(sp)
    80001942:	fc26                	sd	s1,56(sp)
    80001944:	f84a                	sd	s2,48(sp)
    80001946:	f44e                	sd	s3,40(sp)
    80001948:	f052                	sd	s4,32(sp)
    8000194a:	ec56                	sd	s5,24(sp)
    8000194c:	e85a                	sd	s6,16(sp)
    8000194e:	e45e                	sd	s7,8(sp)
    80001950:	0880                	addi	s0,sp,80
    80001952:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    80001954:	fb0ff0ef          	jal	80001104 <myproc>
    80001958:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000195a:	00007517          	auipc	a0,0x7
    8000195e:	23650513          	addi	a0,a0,566 # 80008b90 <wait_lock>
    80001962:	045040ef          	jal	800061a6 <acquire>
        if(pp->state == ZOMBIE){
    80001966:	4a15                	li	s4,5
        havekids = 1;
    80001968:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000196a:	0000d997          	auipc	s3,0xd
    8000196e:	24698993          	addi	s3,s3,582 # 8000ebb0 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80001972:	00007b17          	auipc	s6,0x7
    80001976:	21eb0b13          	addi	s6,s6,542 # 80008b90 <wait_lock>
    8000197a:	a869                	j	80001a14 <wait+0xd8>
          pid = pp->pid;
    8000197c:	0384a983          	lw	s3,56(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80001980:	000b8c63          	beqz	s7,80001998 <wait+0x5c>
    80001984:	4691                	li	a3,4
    80001986:	03448613          	addi	a2,s1,52
    8000198a:	85de                	mv	a1,s7
    8000198c:	05893503          	ld	a0,88(s2)
    80001990:	bf4ff0ef          	jal	80000d84 <copyout>
    80001994:	02054a63          	bltz	a0,800019c8 <wait+0x8c>
          freeproc(pp);
    80001998:	8526                	mv	a0,s1
    8000199a:	8dfff0ef          	jal	80001278 <freeproc>
          release(&pp->lock);
    8000199e:	8526                	mv	a0,s1
    800019a0:	0af040ef          	jal	8000624e <release>
          release(&wait_lock);
    800019a4:	00007517          	auipc	a0,0x7
    800019a8:	1ec50513          	addi	a0,a0,492 # 80008b90 <wait_lock>
    800019ac:	0a3040ef          	jal	8000624e <release>
}
    800019b0:	854e                	mv	a0,s3
    800019b2:	60a6                	ld	ra,72(sp)
    800019b4:	6406                	ld	s0,64(sp)
    800019b6:	74e2                	ld	s1,56(sp)
    800019b8:	7942                	ld	s2,48(sp)
    800019ba:	79a2                	ld	s3,40(sp)
    800019bc:	7a02                	ld	s4,32(sp)
    800019be:	6ae2                	ld	s5,24(sp)
    800019c0:	6b42                	ld	s6,16(sp)
    800019c2:	6ba2                	ld	s7,8(sp)
    800019c4:	6161                	addi	sp,sp,80
    800019c6:	8082                	ret
            release(&pp->lock);
    800019c8:	8526                	mv	a0,s1
    800019ca:	085040ef          	jal	8000624e <release>
            release(&wait_lock);
    800019ce:	00007517          	auipc	a0,0x7
    800019d2:	1c250513          	addi	a0,a0,450 # 80008b90 <wait_lock>
    800019d6:	079040ef          	jal	8000624e <release>
            return -1;
    800019da:	59fd                	li	s3,-1
    800019dc:	bfd1                	j	800019b0 <wait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800019de:	17048493          	addi	s1,s1,368
    800019e2:	03348063          	beq	s1,s3,80001a02 <wait+0xc6>
      if(pp->parent == p){
    800019e6:	60bc                	ld	a5,64(s1)
    800019e8:	ff279be3          	bne	a5,s2,800019de <wait+0xa2>
        acquire(&pp->lock);
    800019ec:	8526                	mv	a0,s1
    800019ee:	7b8040ef          	jal	800061a6 <acquire>
        if(pp->state == ZOMBIE){
    800019f2:	509c                	lw	a5,32(s1)
    800019f4:	f94784e3          	beq	a5,s4,8000197c <wait+0x40>
        release(&pp->lock);
    800019f8:	8526                	mv	a0,s1
    800019fa:	055040ef          	jal	8000624e <release>
        havekids = 1;
    800019fe:	8756                	mv	a4,s5
    80001a00:	bff9                	j	800019de <wait+0xa2>
    if(!havekids || killed(p)){
    80001a02:	cf19                	beqz	a4,80001a20 <wait+0xe4>
    80001a04:	854a                	mv	a0,s2
    80001a06:	f0dff0ef          	jal	80001912 <killed>
    80001a0a:	e919                	bnez	a0,80001a20 <wait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80001a0c:	85da                	mv	a1,s6
    80001a0e:	854a                	mv	a0,s2
    80001a10:	cc7ff0ef          	jal	800016d6 <sleep>
    havekids = 0;
    80001a14:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001a16:	00007497          	auipc	s1,0x7
    80001a1a:	59a48493          	addi	s1,s1,1434 # 80008fb0 <proc>
    80001a1e:	b7e1                	j	800019e6 <wait+0xaa>
      release(&wait_lock);
    80001a20:	00007517          	auipc	a0,0x7
    80001a24:	17050513          	addi	a0,a0,368 # 80008b90 <wait_lock>
    80001a28:	027040ef          	jal	8000624e <release>
      return -1;
    80001a2c:	59fd                	li	s3,-1
    80001a2e:	b749                	j	800019b0 <wait+0x74>

0000000080001a30 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80001a30:	7179                	addi	sp,sp,-48
    80001a32:	f406                	sd	ra,40(sp)
    80001a34:	f022                	sd	s0,32(sp)
    80001a36:	ec26                	sd	s1,24(sp)
    80001a38:	e84a                	sd	s2,16(sp)
    80001a3a:	e44e                	sd	s3,8(sp)
    80001a3c:	e052                	sd	s4,0(sp)
    80001a3e:	1800                	addi	s0,sp,48
    80001a40:	84aa                	mv	s1,a0
    80001a42:	8a2e                	mv	s4,a1
    80001a44:	89b2                	mv	s3,a2
    80001a46:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80001a48:	ebcff0ef          	jal	80001104 <myproc>
  if(user_dst){
    80001a4c:	cc99                	beqz	s1,80001a6a <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80001a4e:	86ca                	mv	a3,s2
    80001a50:	864e                	mv	a2,s3
    80001a52:	85d2                	mv	a1,s4
    80001a54:	6d28                	ld	a0,88(a0)
    80001a56:	b2eff0ef          	jal	80000d84 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80001a5a:	70a2                	ld	ra,40(sp)
    80001a5c:	7402                	ld	s0,32(sp)
    80001a5e:	64e2                	ld	s1,24(sp)
    80001a60:	6942                	ld	s2,16(sp)
    80001a62:	69a2                	ld	s3,8(sp)
    80001a64:	6a02                	ld	s4,0(sp)
    80001a66:	6145                	addi	sp,sp,48
    80001a68:	8082                	ret
    memmove((char *)dst, src, len);
    80001a6a:	0009061b          	sext.w	a2,s2
    80001a6e:	85ce                	mv	a1,s3
    80001a70:	8552                	mv	a0,s4
    80001a72:	ac7fe0ef          	jal	80000538 <memmove>
    return 0;
    80001a76:	8526                	mv	a0,s1
    80001a78:	b7cd                	j	80001a5a <either_copyout+0x2a>

0000000080001a7a <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80001a7a:	7179                	addi	sp,sp,-48
    80001a7c:	f406                	sd	ra,40(sp)
    80001a7e:	f022                	sd	s0,32(sp)
    80001a80:	ec26                	sd	s1,24(sp)
    80001a82:	e84a                	sd	s2,16(sp)
    80001a84:	e44e                	sd	s3,8(sp)
    80001a86:	e052                	sd	s4,0(sp)
    80001a88:	1800                	addi	s0,sp,48
    80001a8a:	8a2a                	mv	s4,a0
    80001a8c:	84ae                	mv	s1,a1
    80001a8e:	89b2                	mv	s3,a2
    80001a90:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80001a92:	e72ff0ef          	jal	80001104 <myproc>
  if(user_src){
    80001a96:	cc99                	beqz	s1,80001ab4 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80001a98:	86ca                	mv	a3,s2
    80001a9a:	864e                	mv	a2,s3
    80001a9c:	85d2                	mv	a1,s4
    80001a9e:	6d28                	ld	a0,88(a0)
    80001aa0:	b94ff0ef          	jal	80000e34 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80001aa4:	70a2                	ld	ra,40(sp)
    80001aa6:	7402                	ld	s0,32(sp)
    80001aa8:	64e2                	ld	s1,24(sp)
    80001aaa:	6942                	ld	s2,16(sp)
    80001aac:	69a2                	ld	s3,8(sp)
    80001aae:	6a02                	ld	s4,0(sp)
    80001ab0:	6145                	addi	sp,sp,48
    80001ab2:	8082                	ret
    memmove(dst, (char*)src, len);
    80001ab4:	0009061b          	sext.w	a2,s2
    80001ab8:	85ce                	mv	a1,s3
    80001aba:	8552                	mv	a0,s4
    80001abc:	a7dfe0ef          	jal	80000538 <memmove>
    return 0;
    80001ac0:	8526                	mv	a0,s1
    80001ac2:	b7cd                	j	80001aa4 <either_copyin+0x2a>

0000000080001ac4 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80001ac4:	715d                	addi	sp,sp,-80
    80001ac6:	e486                	sd	ra,72(sp)
    80001ac8:	e0a2                	sd	s0,64(sp)
    80001aca:	fc26                	sd	s1,56(sp)
    80001acc:	f84a                	sd	s2,48(sp)
    80001ace:	f44e                	sd	s3,40(sp)
    80001ad0:	f052                	sd	s4,32(sp)
    80001ad2:	ec56                	sd	s5,24(sp)
    80001ad4:	e85a                	sd	s6,16(sp)
    80001ad6:	e45e                	sd	s7,8(sp)
    80001ad8:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80001ada:	00006517          	auipc	a0,0x6
    80001ade:	53650513          	addi	a0,a0,1334 # 80008010 <etext+0x10>
    80001ae2:	090040ef          	jal	80005b72 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001ae6:	00007497          	auipc	s1,0x7
    80001aea:	62a48493          	addi	s1,s1,1578 # 80009110 <proc+0x160>
    80001aee:	0000d917          	auipc	s2,0xd
    80001af2:	22290913          	addi	s2,s2,546 # 8000ed10 <bcache_bucket+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001af6:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80001af8:	00006997          	auipc	s3,0x6
    80001afc:	74098993          	addi	s3,s3,1856 # 80008238 <etext+0x238>
    printf("%d %s %s", p->pid, state, p->name);
    80001b00:	00006a97          	auipc	s5,0x6
    80001b04:	740a8a93          	addi	s5,s5,1856 # 80008240 <etext+0x240>
    printf("\n");
    80001b08:	00006a17          	auipc	s4,0x6
    80001b0c:	508a0a13          	addi	s4,s4,1288 # 80008010 <etext+0x10>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001b10:	00007b97          	auipc	s7,0x7
    80001b14:	d58b8b93          	addi	s7,s7,-680 # 80008868 <states.0>
    80001b18:	a829                	j	80001b32 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80001b1a:	ed86a583          	lw	a1,-296(a3)
    80001b1e:	8556                	mv	a0,s5
    80001b20:	052040ef          	jal	80005b72 <printf>
    printf("\n");
    80001b24:	8552                	mv	a0,s4
    80001b26:	04c040ef          	jal	80005b72 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001b2a:	17048493          	addi	s1,s1,368
    80001b2e:	03248263          	beq	s1,s2,80001b52 <procdump+0x8e>
    if(p->state == UNUSED)
    80001b32:	86a6                	mv	a3,s1
    80001b34:	ec04a783          	lw	a5,-320(s1)
    80001b38:	dbed                	beqz	a5,80001b2a <procdump+0x66>
      state = "???";
    80001b3a:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001b3c:	fcfb6fe3          	bltu	s6,a5,80001b1a <procdump+0x56>
    80001b40:	02079713          	slli	a4,a5,0x20
    80001b44:	01d75793          	srli	a5,a4,0x1d
    80001b48:	97de                	add	a5,a5,s7
    80001b4a:	6390                	ld	a2,0(a5)
    80001b4c:	f679                	bnez	a2,80001b1a <procdump+0x56>
      state = "???";
    80001b4e:	864e                	mv	a2,s3
    80001b50:	b7e9                	j	80001b1a <procdump+0x56>
  }
}
    80001b52:	60a6                	ld	ra,72(sp)
    80001b54:	6406                	ld	s0,64(sp)
    80001b56:	74e2                	ld	s1,56(sp)
    80001b58:	7942                	ld	s2,48(sp)
    80001b5a:	79a2                	ld	s3,40(sp)
    80001b5c:	7a02                	ld	s4,32(sp)
    80001b5e:	6ae2                	ld	s5,24(sp)
    80001b60:	6b42                	ld	s6,16(sp)
    80001b62:	6ba2                	ld	s7,8(sp)
    80001b64:	6161                	addi	sp,sp,80
    80001b66:	8082                	ret

0000000080001b68 <swtch>:
    80001b68:	00153023          	sd	ra,0(a0)
    80001b6c:	00253423          	sd	sp,8(a0)
    80001b70:	e900                	sd	s0,16(a0)
    80001b72:	ed04                	sd	s1,24(a0)
    80001b74:	03253023          	sd	s2,32(a0)
    80001b78:	03353423          	sd	s3,40(a0)
    80001b7c:	03453823          	sd	s4,48(a0)
    80001b80:	03553c23          	sd	s5,56(a0)
    80001b84:	05653023          	sd	s6,64(a0)
    80001b88:	05753423          	sd	s7,72(a0)
    80001b8c:	05853823          	sd	s8,80(a0)
    80001b90:	05953c23          	sd	s9,88(a0)
    80001b94:	07a53023          	sd	s10,96(a0)
    80001b98:	07b53423          	sd	s11,104(a0)
    80001b9c:	0005b083          	ld	ra,0(a1)
    80001ba0:	0085b103          	ld	sp,8(a1)
    80001ba4:	6980                	ld	s0,16(a1)
    80001ba6:	6d84                	ld	s1,24(a1)
    80001ba8:	0205b903          	ld	s2,32(a1)
    80001bac:	0285b983          	ld	s3,40(a1)
    80001bb0:	0305ba03          	ld	s4,48(a1)
    80001bb4:	0385ba83          	ld	s5,56(a1)
    80001bb8:	0405bb03          	ld	s6,64(a1)
    80001bbc:	0485bb83          	ld	s7,72(a1)
    80001bc0:	0505bc03          	ld	s8,80(a1)
    80001bc4:	0585bc83          	ld	s9,88(a1)
    80001bc8:	0605bd03          	ld	s10,96(a1)
    80001bcc:	0685bd83          	ld	s11,104(a1)
    80001bd0:	8082                	ret

0000000080001bd2 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001bd2:	1141                	addi	sp,sp,-16
    80001bd4:	e406                	sd	ra,8(sp)
    80001bd6:	e022                	sd	s0,0(sp)
    80001bd8:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001bda:	00006597          	auipc	a1,0x6
    80001bde:	6a658593          	addi	a1,a1,1702 # 80008280 <etext+0x280>
    80001be2:	0000d517          	auipc	a0,0xd
    80001be6:	fce50513          	addi	a0,a0,-50 # 8000ebb0 <tickslock>
    80001bea:	6fc040ef          	jal	800062e6 <initlock>
}
    80001bee:	60a2                	ld	ra,8(sp)
    80001bf0:	6402                	ld	s0,0(sp)
    80001bf2:	0141                	addi	sp,sp,16
    80001bf4:	8082                	ret

0000000080001bf6 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80001bf6:	1141                	addi	sp,sp,-16
    80001bf8:	e406                	sd	ra,8(sp)
    80001bfa:	e022                	sd	s0,0(sp)
    80001bfc:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001bfe:	00003797          	auipc	a5,0x3
    80001c02:	17278793          	addi	a5,a5,370 # 80004d70 <kernelvec>
    80001c06:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80001c0a:	60a2                	ld	ra,8(sp)
    80001c0c:	6402                	ld	s0,0(sp)
    80001c0e:	0141                	addi	sp,sp,16
    80001c10:	8082                	ret

0000000080001c12 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80001c12:	1141                	addi	sp,sp,-16
    80001c14:	e406                	sd	ra,8(sp)
    80001c16:	e022                	sd	s0,0(sp)
    80001c18:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80001c1a:	ceaff0ef          	jal	80001104 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c1e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001c22:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001c24:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80001c28:	00005697          	auipc	a3,0x5
    80001c2c:	3d868693          	addi	a3,a3,984 # 80007000 <_trampoline>
    80001c30:	00005717          	auipc	a4,0x5
    80001c34:	3d070713          	addi	a4,a4,976 # 80007000 <_trampoline>
    80001c38:	8f15                	sub	a4,a4,a3
    80001c3a:	040007b7          	lui	a5,0x4000
    80001c3e:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80001c40:	07b2                	slli	a5,a5,0xc
    80001c42:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001c44:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80001c48:	7138                	ld	a4,96(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80001c4a:	18002673          	csrr	a2,satp
    80001c4e:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80001c50:	7130                	ld	a2,96(a0)
    80001c52:	6538                	ld	a4,72(a0)
    80001c54:	6585                	lui	a1,0x1
    80001c56:	972e                	add	a4,a4,a1
    80001c58:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80001c5a:	7138                	ld	a4,96(a0)
    80001c5c:	00000617          	auipc	a2,0x0
    80001c60:	11460613          	addi	a2,a2,276 # 80001d70 <usertrap>
    80001c64:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80001c66:	7138                	ld	a4,96(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80001c68:	8612                	mv	a2,tp
    80001c6a:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c6c:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80001c70:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80001c74:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001c78:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80001c7c:	7138                	ld	a4,96(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001c7e:	6f18                	ld	a4,24(a4)
    80001c80:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001c84:	6d28                	ld	a0,88(a0)
    80001c86:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001c88:	00005717          	auipc	a4,0x5
    80001c8c:	41470713          	addi	a4,a4,1044 # 8000709c <userret>
    80001c90:	8f15                	sub	a4,a4,a3
    80001c92:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001c94:	577d                	li	a4,-1
    80001c96:	177e                	slli	a4,a4,0x3f
    80001c98:	8d59                	or	a0,a0,a4
    80001c9a:	9782                	jalr	a5
}
    80001c9c:	60a2                	ld	ra,8(sp)
    80001c9e:	6402                	ld	s0,0(sp)
    80001ca0:	0141                	addi	sp,sp,16
    80001ca2:	8082                	ret

0000000080001ca4 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001ca4:	1141                	addi	sp,sp,-16
    80001ca6:	e406                	sd	ra,8(sp)
    80001ca8:	e022                	sd	s0,0(sp)
    80001caa:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80001cac:	c24ff0ef          	jal	800010d0 <cpuid>
    80001cb0:	cd11                	beqz	a0,80001ccc <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001cb2:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001cb6:	000f4737          	lui	a4,0xf4
    80001cba:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80001cbe:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80001cc0:	14d79073          	csrw	stimecmp,a5
}
    80001cc4:	60a2                	ld	ra,8(sp)
    80001cc6:	6402                	ld	s0,0(sp)
    80001cc8:	0141                	addi	sp,sp,16
    80001cca:	8082                	ret
    acquire(&tickslock);
    80001ccc:	0000d517          	auipc	a0,0xd
    80001cd0:	ee450513          	addi	a0,a0,-284 # 8000ebb0 <tickslock>
    80001cd4:	4d2040ef          	jal	800061a6 <acquire>
    ticks++;
    80001cd8:	00007717          	auipc	a4,0x7
    80001cdc:	d2070713          	addi	a4,a4,-736 # 800089f8 <ticks>
    80001ce0:	431c                	lw	a5,0(a4)
    80001ce2:	2785                	addiw	a5,a5,1
    80001ce4:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80001ce6:	853a                	mv	a0,a4
    80001ce8:	a3bff0ef          	jal	80001722 <wakeup>
    release(&tickslock);
    80001cec:	0000d517          	auipc	a0,0xd
    80001cf0:	ec450513          	addi	a0,a0,-316 # 8000ebb0 <tickslock>
    80001cf4:	55a040ef          	jal	8000624e <release>
    80001cf8:	bf6d                	j	80001cb2 <clockintr+0xe>

0000000080001cfa <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001cfa:	1101                	addi	sp,sp,-32
    80001cfc:	ec06                	sd	ra,24(sp)
    80001cfe:	e822                	sd	s0,16(sp)
    80001d00:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001d02:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001d06:	57fd                	li	a5,-1
    80001d08:	17fe                	slli	a5,a5,0x3f
    80001d0a:	07a5                	addi	a5,a5,9
    80001d0c:	00f70c63          	beq	a4,a5,80001d24 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80001d10:	57fd                	li	a5,-1
    80001d12:	17fe                	slli	a5,a5,0x3f
    80001d14:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001d16:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001d18:	04f70863          	beq	a4,a5,80001d68 <devintr+0x6e>
  }
}
    80001d1c:	60e2                	ld	ra,24(sp)
    80001d1e:	6442                	ld	s0,16(sp)
    80001d20:	6105                	addi	sp,sp,32
    80001d22:	8082                	ret
    80001d24:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80001d26:	0f6030ef          	jal	80004e1c <plic_claim>
    80001d2a:	872a                	mv	a4,a0
    80001d2c:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001d2e:	47a9                	li	a5,10
    80001d30:	00f50963          	beq	a0,a5,80001d42 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    80001d34:	4785                	li	a5,1
    80001d36:	00f50963          	beq	a0,a5,80001d48 <devintr+0x4e>
    return 1;
    80001d3a:	4505                	li	a0,1
    } else if(irq){
    80001d3c:	eb09                	bnez	a4,80001d4e <devintr+0x54>
    80001d3e:	64a2                	ld	s1,8(sp)
    80001d40:	bff1                	j	80001d1c <devintr+0x22>
      uartintr();
    80001d42:	3b4040ef          	jal	800060f6 <uartintr>
    if(irq)
    80001d46:	a819                	j	80001d5c <devintr+0x62>
      virtio_disk_intr();
    80001d48:	5a2030ef          	jal	800052ea <virtio_disk_intr>
    if(irq)
    80001d4c:	a801                	j	80001d5c <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    80001d4e:	85ba                	mv	a1,a4
    80001d50:	00006517          	auipc	a0,0x6
    80001d54:	53850513          	addi	a0,a0,1336 # 80008288 <etext+0x288>
    80001d58:	61b030ef          	jal	80005b72 <printf>
      plic_complete(irq);
    80001d5c:	8526                	mv	a0,s1
    80001d5e:	0de030ef          	jal	80004e3c <plic_complete>
    return 1;
    80001d62:	4505                	li	a0,1
    80001d64:	64a2                	ld	s1,8(sp)
    80001d66:	bf5d                	j	80001d1c <devintr+0x22>
    clockintr();
    80001d68:	f3dff0ef          	jal	80001ca4 <clockintr>
    return 2;
    80001d6c:	4509                	li	a0,2
    80001d6e:	b77d                	j	80001d1c <devintr+0x22>

0000000080001d70 <usertrap>:
{
    80001d70:	1101                	addi	sp,sp,-32
    80001d72:	ec06                	sd	ra,24(sp)
    80001d74:	e822                	sd	s0,16(sp)
    80001d76:	e426                	sd	s1,8(sp)
    80001d78:	e04a                	sd	s2,0(sp)
    80001d7a:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001d7c:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80001d80:	1007f793          	andi	a5,a5,256
    80001d84:	ef85                	bnez	a5,80001dbc <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001d86:	00003797          	auipc	a5,0x3
    80001d8a:	fea78793          	addi	a5,a5,-22 # 80004d70 <kernelvec>
    80001d8e:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001d92:	b72ff0ef          	jal	80001104 <myproc>
    80001d96:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001d98:	713c                	ld	a5,96(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001d9a:	14102773          	csrr	a4,sepc
    80001d9e:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001da0:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001da4:	47a1                	li	a5,8
    80001da6:	02f70163          	beq	a4,a5,80001dc8 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001daa:	f51ff0ef          	jal	80001cfa <devintr>
    80001dae:	892a                	mv	s2,a0
    80001db0:	c135                	beqz	a0,80001e14 <usertrap+0xa4>
  if(killed(p))
    80001db2:	8526                	mv	a0,s1
    80001db4:	b5fff0ef          	jal	80001912 <killed>
    80001db8:	cd1d                	beqz	a0,80001df6 <usertrap+0x86>
    80001dba:	a81d                	j	80001df0 <usertrap+0x80>
    panic("usertrap: not from user mode");
    80001dbc:	00006517          	auipc	a0,0x6
    80001dc0:	4ec50513          	addi	a0,a0,1260 # 800082a8 <etext+0x2a8>
    80001dc4:	0be040ef          	jal	80005e82 <panic>
    if(killed(p))
    80001dc8:	b4bff0ef          	jal	80001912 <killed>
    80001dcc:	e121                	bnez	a0,80001e0c <usertrap+0x9c>
    p->trapframe->epc += 4;
    80001dce:	70b8                	ld	a4,96(s1)
    80001dd0:	6f1c                	ld	a5,24(a4)
    80001dd2:	0791                	addi	a5,a5,4
    80001dd4:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dd6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001dda:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001dde:	10079073          	csrw	sstatus,a5
    syscall();
    80001de2:	242000ef          	jal	80002024 <syscall>
  if(killed(p))
    80001de6:	8526                	mv	a0,s1
    80001de8:	b2bff0ef          	jal	80001912 <killed>
    80001dec:	c901                	beqz	a0,80001dfc <usertrap+0x8c>
    80001dee:	4901                	li	s2,0
    exit(-1);
    80001df0:	557d                	li	a0,-1
    80001df2:	9f1ff0ef          	jal	800017e2 <exit>
  if(which_dev == 2)
    80001df6:	4789                	li	a5,2
    80001df8:	04f90563          	beq	s2,a5,80001e42 <usertrap+0xd2>
  usertrapret();
    80001dfc:	e17ff0ef          	jal	80001c12 <usertrapret>
}
    80001e00:	60e2                	ld	ra,24(sp)
    80001e02:	6442                	ld	s0,16(sp)
    80001e04:	64a2                	ld	s1,8(sp)
    80001e06:	6902                	ld	s2,0(sp)
    80001e08:	6105                	addi	sp,sp,32
    80001e0a:	8082                	ret
      exit(-1);
    80001e0c:	557d                	li	a0,-1
    80001e0e:	9d5ff0ef          	jal	800017e2 <exit>
    80001e12:	bf75                	j	80001dce <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001e14:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001e18:	5c90                	lw	a2,56(s1)
    80001e1a:	00006517          	auipc	a0,0x6
    80001e1e:	4ae50513          	addi	a0,a0,1198 # 800082c8 <etext+0x2c8>
    80001e22:	551030ef          	jal	80005b72 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001e26:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001e2a:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001e2e:	00006517          	auipc	a0,0x6
    80001e32:	4ca50513          	addi	a0,a0,1226 # 800082f8 <etext+0x2f8>
    80001e36:	53d030ef          	jal	80005b72 <printf>
    setkilled(p);
    80001e3a:	8526                	mv	a0,s1
    80001e3c:	ab3ff0ef          	jal	800018ee <setkilled>
    80001e40:	b75d                	j	80001de6 <usertrap+0x76>
    yield();
    80001e42:	869ff0ef          	jal	800016aa <yield>
    80001e46:	bf5d                	j	80001dfc <usertrap+0x8c>

0000000080001e48 <kerneltrap>:
{
    80001e48:	7179                	addi	sp,sp,-48
    80001e4a:	f406                	sd	ra,40(sp)
    80001e4c:	f022                	sd	s0,32(sp)
    80001e4e:	ec26                	sd	s1,24(sp)
    80001e50:	e84a                	sd	s2,16(sp)
    80001e52:	e44e                	sd	s3,8(sp)
    80001e54:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001e56:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e5a:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001e5e:	142027f3          	csrr	a5,scause
    80001e62:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80001e64:	1004f793          	andi	a5,s1,256
    80001e68:	c795                	beqz	a5,80001e94 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e6a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e6e:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001e70:	eb85                	bnez	a5,80001ea0 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80001e72:	e89ff0ef          	jal	80001cfa <devintr>
    80001e76:	c91d                	beqz	a0,80001eac <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80001e78:	4789                	li	a5,2
    80001e7a:	04f50a63          	beq	a0,a5,80001ece <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001e7e:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e82:	10049073          	csrw	sstatus,s1
}
    80001e86:	70a2                	ld	ra,40(sp)
    80001e88:	7402                	ld	s0,32(sp)
    80001e8a:	64e2                	ld	s1,24(sp)
    80001e8c:	6942                	ld	s2,16(sp)
    80001e8e:	69a2                	ld	s3,8(sp)
    80001e90:	6145                	addi	sp,sp,48
    80001e92:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001e94:	00006517          	auipc	a0,0x6
    80001e98:	48c50513          	addi	a0,a0,1164 # 80008320 <etext+0x320>
    80001e9c:	7e7030ef          	jal	80005e82 <panic>
    panic("kerneltrap: interrupts enabled");
    80001ea0:	00006517          	auipc	a0,0x6
    80001ea4:	4a850513          	addi	a0,a0,1192 # 80008348 <etext+0x348>
    80001ea8:	7db030ef          	jal	80005e82 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001eac:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001eb0:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001eb4:	85ce                	mv	a1,s3
    80001eb6:	00006517          	auipc	a0,0x6
    80001eba:	4b250513          	addi	a0,a0,1202 # 80008368 <etext+0x368>
    80001ebe:	4b5030ef          	jal	80005b72 <printf>
    panic("kerneltrap");
    80001ec2:	00006517          	auipc	a0,0x6
    80001ec6:	4ce50513          	addi	a0,a0,1230 # 80008390 <etext+0x390>
    80001eca:	7b9030ef          	jal	80005e82 <panic>
  if(which_dev == 2 && myproc() != 0)
    80001ece:	a36ff0ef          	jal	80001104 <myproc>
    80001ed2:	d555                	beqz	a0,80001e7e <kerneltrap+0x36>
    yield();
    80001ed4:	fd6ff0ef          	jal	800016aa <yield>
    80001ed8:	b75d                	j	80001e7e <kerneltrap+0x36>

0000000080001eda <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001eda:	1101                	addi	sp,sp,-32
    80001edc:	ec06                	sd	ra,24(sp)
    80001ede:	e822                	sd	s0,16(sp)
    80001ee0:	e426                	sd	s1,8(sp)
    80001ee2:	1000                	addi	s0,sp,32
    80001ee4:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001ee6:	a1eff0ef          	jal	80001104 <myproc>
  switch (n) {
    80001eea:	4795                	li	a5,5
    80001eec:	0497e163          	bltu	a5,s1,80001f2e <argraw+0x54>
    80001ef0:	048a                	slli	s1,s1,0x2
    80001ef2:	00007717          	auipc	a4,0x7
    80001ef6:	9a670713          	addi	a4,a4,-1626 # 80008898 <states.0+0x30>
    80001efa:	94ba                	add	s1,s1,a4
    80001efc:	409c                	lw	a5,0(s1)
    80001efe:	97ba                	add	a5,a5,a4
    80001f00:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001f02:	713c                	ld	a5,96(a0)
    80001f04:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001f06:	60e2                	ld	ra,24(sp)
    80001f08:	6442                	ld	s0,16(sp)
    80001f0a:	64a2                	ld	s1,8(sp)
    80001f0c:	6105                	addi	sp,sp,32
    80001f0e:	8082                	ret
    return p->trapframe->a1;
    80001f10:	713c                	ld	a5,96(a0)
    80001f12:	7fa8                	ld	a0,120(a5)
    80001f14:	bfcd                	j	80001f06 <argraw+0x2c>
    return p->trapframe->a2;
    80001f16:	713c                	ld	a5,96(a0)
    80001f18:	63c8                	ld	a0,128(a5)
    80001f1a:	b7f5                	j	80001f06 <argraw+0x2c>
    return p->trapframe->a3;
    80001f1c:	713c                	ld	a5,96(a0)
    80001f1e:	67c8                	ld	a0,136(a5)
    80001f20:	b7dd                	j	80001f06 <argraw+0x2c>
    return p->trapframe->a4;
    80001f22:	713c                	ld	a5,96(a0)
    80001f24:	6bc8                	ld	a0,144(a5)
    80001f26:	b7c5                	j	80001f06 <argraw+0x2c>
    return p->trapframe->a5;
    80001f28:	713c                	ld	a5,96(a0)
    80001f2a:	6fc8                	ld	a0,152(a5)
    80001f2c:	bfe9                	j	80001f06 <argraw+0x2c>
  panic("argraw");
    80001f2e:	00006517          	auipc	a0,0x6
    80001f32:	47250513          	addi	a0,a0,1138 # 800083a0 <etext+0x3a0>
    80001f36:	74d030ef          	jal	80005e82 <panic>

0000000080001f3a <fetchaddr>:
{
    80001f3a:	1101                	addi	sp,sp,-32
    80001f3c:	ec06                	sd	ra,24(sp)
    80001f3e:	e822                	sd	s0,16(sp)
    80001f40:	e426                	sd	s1,8(sp)
    80001f42:	e04a                	sd	s2,0(sp)
    80001f44:	1000                	addi	s0,sp,32
    80001f46:	84aa                	mv	s1,a0
    80001f48:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001f4a:	9baff0ef          	jal	80001104 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001f4e:	693c                	ld	a5,80(a0)
    80001f50:	02f4f663          	bgeu	s1,a5,80001f7c <fetchaddr+0x42>
    80001f54:	00848713          	addi	a4,s1,8
    80001f58:	02e7e463          	bltu	a5,a4,80001f80 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001f5c:	46a1                	li	a3,8
    80001f5e:	8626                	mv	a2,s1
    80001f60:	85ca                	mv	a1,s2
    80001f62:	6d28                	ld	a0,88(a0)
    80001f64:	ed1fe0ef          	jal	80000e34 <copyin>
    80001f68:	00a03533          	snez	a0,a0
    80001f6c:	40a0053b          	negw	a0,a0
}
    80001f70:	60e2                	ld	ra,24(sp)
    80001f72:	6442                	ld	s0,16(sp)
    80001f74:	64a2                	ld	s1,8(sp)
    80001f76:	6902                	ld	s2,0(sp)
    80001f78:	6105                	addi	sp,sp,32
    80001f7a:	8082                	ret
    return -1;
    80001f7c:	557d                	li	a0,-1
    80001f7e:	bfcd                	j	80001f70 <fetchaddr+0x36>
    80001f80:	557d                	li	a0,-1
    80001f82:	b7fd                	j	80001f70 <fetchaddr+0x36>

0000000080001f84 <fetchstr>:
{
    80001f84:	7179                	addi	sp,sp,-48
    80001f86:	f406                	sd	ra,40(sp)
    80001f88:	f022                	sd	s0,32(sp)
    80001f8a:	ec26                	sd	s1,24(sp)
    80001f8c:	e84a                	sd	s2,16(sp)
    80001f8e:	e44e                	sd	s3,8(sp)
    80001f90:	1800                	addi	s0,sp,48
    80001f92:	89aa                	mv	s3,a0
    80001f94:	84ae                	mv	s1,a1
    80001f96:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80001f98:	96cff0ef          	jal	80001104 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001f9c:	86ca                	mv	a3,s2
    80001f9e:	864e                	mv	a2,s3
    80001fa0:	85a6                	mv	a1,s1
    80001fa2:	6d28                	ld	a0,88(a0)
    80001fa4:	f17fe0ef          	jal	80000eba <copyinstr>
    80001fa8:	00054c63          	bltz	a0,80001fc0 <fetchstr+0x3c>
  return strlen(buf);
    80001fac:	8526                	mv	a0,s1
    80001fae:	eb4fe0ef          	jal	80000662 <strlen>
}
    80001fb2:	70a2                	ld	ra,40(sp)
    80001fb4:	7402                	ld	s0,32(sp)
    80001fb6:	64e2                	ld	s1,24(sp)
    80001fb8:	6942                	ld	s2,16(sp)
    80001fba:	69a2                	ld	s3,8(sp)
    80001fbc:	6145                	addi	sp,sp,48
    80001fbe:	8082                	ret
    return -1;
    80001fc0:	557d                	li	a0,-1
    80001fc2:	bfc5                	j	80001fb2 <fetchstr+0x2e>

0000000080001fc4 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001fc4:	1101                	addi	sp,sp,-32
    80001fc6:	ec06                	sd	ra,24(sp)
    80001fc8:	e822                	sd	s0,16(sp)
    80001fca:	e426                	sd	s1,8(sp)
    80001fcc:	1000                	addi	s0,sp,32
    80001fce:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001fd0:	f0bff0ef          	jal	80001eda <argraw>
    80001fd4:	c088                	sw	a0,0(s1)
}
    80001fd6:	60e2                	ld	ra,24(sp)
    80001fd8:	6442                	ld	s0,16(sp)
    80001fda:	64a2                	ld	s1,8(sp)
    80001fdc:	6105                	addi	sp,sp,32
    80001fde:	8082                	ret

0000000080001fe0 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001fe0:	1101                	addi	sp,sp,-32
    80001fe2:	ec06                	sd	ra,24(sp)
    80001fe4:	e822                	sd	s0,16(sp)
    80001fe6:	e426                	sd	s1,8(sp)
    80001fe8:	1000                	addi	s0,sp,32
    80001fea:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001fec:	eefff0ef          	jal	80001eda <argraw>
    80001ff0:	e088                	sd	a0,0(s1)
}
    80001ff2:	60e2                	ld	ra,24(sp)
    80001ff4:	6442                	ld	s0,16(sp)
    80001ff6:	64a2                	ld	s1,8(sp)
    80001ff8:	6105                	addi	sp,sp,32
    80001ffa:	8082                	ret

0000000080001ffc <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001ffc:	1101                	addi	sp,sp,-32
    80001ffe:	ec06                	sd	ra,24(sp)
    80002000:	e822                	sd	s0,16(sp)
    80002002:	e426                	sd	s1,8(sp)
    80002004:	e04a                	sd	s2,0(sp)
    80002006:	1000                	addi	s0,sp,32
    80002008:	892e                	mv	s2,a1
    8000200a:	84b2                	mv	s1,a2
  *ip = argraw(n);
    8000200c:	ecfff0ef          	jal	80001eda <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80002010:	8626                	mv	a2,s1
    80002012:	85ca                	mv	a1,s2
    80002014:	f71ff0ef          	jal	80001f84 <fetchstr>
}
    80002018:	60e2                	ld	ra,24(sp)
    8000201a:	6442                	ld	s0,16(sp)
    8000201c:	64a2                	ld	s1,8(sp)
    8000201e:	6902                	ld	s2,0(sp)
    80002020:	6105                	addi	sp,sp,32
    80002022:	8082                	ret

0000000080002024 <syscall>:
[SYS_close]   sys_close,
};

void
syscall(void)
{
    80002024:	1101                	addi	sp,sp,-32
    80002026:	ec06                	sd	ra,24(sp)
    80002028:	e822                	sd	s0,16(sp)
    8000202a:	e426                	sd	s1,8(sp)
    8000202c:	e04a                	sd	s2,0(sp)
    8000202e:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002030:	8d4ff0ef          	jal	80001104 <myproc>
    80002034:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002036:	06053903          	ld	s2,96(a0)
    8000203a:	0a893783          	ld	a5,168(s2)
    8000203e:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002042:	37fd                	addiw	a5,a5,-1
    80002044:	4751                	li	a4,20
    80002046:	00f76f63          	bltu	a4,a5,80002064 <syscall+0x40>
    8000204a:	00369713          	slli	a4,a3,0x3
    8000204e:	00007797          	auipc	a5,0x7
    80002052:	86278793          	addi	a5,a5,-1950 # 800088b0 <syscalls>
    80002056:	97ba                	add	a5,a5,a4
    80002058:	639c                	ld	a5,0(a5)
    8000205a:	c789                	beqz	a5,80002064 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    8000205c:	9782                	jalr	a5
    8000205e:	06a93823          	sd	a0,112(s2)
    80002062:	a829                	j	8000207c <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002064:	16048613          	addi	a2,s1,352
    80002068:	5c8c                	lw	a1,56(s1)
    8000206a:	00006517          	auipc	a0,0x6
    8000206e:	33e50513          	addi	a0,a0,830 # 800083a8 <etext+0x3a8>
    80002072:	301030ef          	jal	80005b72 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002076:	70bc                	ld	a5,96(s1)
    80002078:	577d                	li	a4,-1
    8000207a:	fbb8                	sd	a4,112(a5)
  }
}
    8000207c:	60e2                	ld	ra,24(sp)
    8000207e:	6442                	ld	s0,16(sp)
    80002080:	64a2                	ld	s1,8(sp)
    80002082:	6902                	ld	s2,0(sp)
    80002084:	6105                	addi	sp,sp,32
    80002086:	8082                	ret

0000000080002088 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80002088:	1101                	addi	sp,sp,-32
    8000208a:	ec06                	sd	ra,24(sp)
    8000208c:	e822                	sd	s0,16(sp)
    8000208e:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002090:	fec40593          	addi	a1,s0,-20
    80002094:	4501                	li	a0,0
    80002096:	f2fff0ef          	jal	80001fc4 <argint>
  exit(n);
    8000209a:	fec42503          	lw	a0,-20(s0)
    8000209e:	f44ff0ef          	jal	800017e2 <exit>
  return 0;  // not reached
}
    800020a2:	4501                	li	a0,0
    800020a4:	60e2                	ld	ra,24(sp)
    800020a6:	6442                	ld	s0,16(sp)
    800020a8:	6105                	addi	sp,sp,32
    800020aa:	8082                	ret

00000000800020ac <sys_getpid>:

uint64
sys_getpid(void)
{
    800020ac:	1141                	addi	sp,sp,-16
    800020ae:	e406                	sd	ra,8(sp)
    800020b0:	e022                	sd	s0,0(sp)
    800020b2:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800020b4:	850ff0ef          	jal	80001104 <myproc>
}
    800020b8:	5d08                	lw	a0,56(a0)
    800020ba:	60a2                	ld	ra,8(sp)
    800020bc:	6402                	ld	s0,0(sp)
    800020be:	0141                	addi	sp,sp,16
    800020c0:	8082                	ret

00000000800020c2 <sys_fork>:

uint64
sys_fork(void)
{
    800020c2:	1141                	addi	sp,sp,-16
    800020c4:	e406                	sd	ra,8(sp)
    800020c6:	e022                	sd	s0,0(sp)
    800020c8:	0800                	addi	s0,sp,16
  return fork();
    800020ca:	b62ff0ef          	jal	8000142c <fork>
}
    800020ce:	60a2                	ld	ra,8(sp)
    800020d0:	6402                	ld	s0,0(sp)
    800020d2:	0141                	addi	sp,sp,16
    800020d4:	8082                	ret

00000000800020d6 <sys_wait>:

uint64
sys_wait(void)
{
    800020d6:	1101                	addi	sp,sp,-32
    800020d8:	ec06                	sd	ra,24(sp)
    800020da:	e822                	sd	s0,16(sp)
    800020dc:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    800020de:	fe840593          	addi	a1,s0,-24
    800020e2:	4501                	li	a0,0
    800020e4:	efdff0ef          	jal	80001fe0 <argaddr>
  return wait(p);
    800020e8:	fe843503          	ld	a0,-24(s0)
    800020ec:	851ff0ef          	jal	8000193c <wait>
}
    800020f0:	60e2                	ld	ra,24(sp)
    800020f2:	6442                	ld	s0,16(sp)
    800020f4:	6105                	addi	sp,sp,32
    800020f6:	8082                	ret

00000000800020f8 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    800020f8:	7179                	addi	sp,sp,-48
    800020fa:	f406                	sd	ra,40(sp)
    800020fc:	f022                	sd	s0,32(sp)
    800020fe:	ec26                	sd	s1,24(sp)
    80002100:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002102:	fdc40593          	addi	a1,s0,-36
    80002106:	4501                	li	a0,0
    80002108:	ebdff0ef          	jal	80001fc4 <argint>
  addr = myproc()->sz;
    8000210c:	ff9fe0ef          	jal	80001104 <myproc>
    80002110:	693c                	ld	a5,80(a0)
    80002112:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80002114:	fdc42503          	lw	a0,-36(s0)
    80002118:	ac4ff0ef          	jal	800013dc <growproc>
    8000211c:	00054863          	bltz	a0,8000212c <sys_sbrk+0x34>
    return -1;
  return addr;
}
    80002120:	8526                	mv	a0,s1
    80002122:	70a2                	ld	ra,40(sp)
    80002124:	7402                	ld	s0,32(sp)
    80002126:	64e2                	ld	s1,24(sp)
    80002128:	6145                	addi	sp,sp,48
    8000212a:	8082                	ret
    return -1;
    8000212c:	57fd                	li	a5,-1
    8000212e:	84be                	mv	s1,a5
    80002130:	bfc5                	j	80002120 <sys_sbrk+0x28>

0000000080002132 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002132:	7139                	addi	sp,sp,-64
    80002134:	fc06                	sd	ra,56(sp)
    80002136:	f822                	sd	s0,48(sp)
    80002138:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    8000213a:	fcc40593          	addi	a1,s0,-52
    8000213e:	4501                	li	a0,0
    80002140:	e85ff0ef          	jal	80001fc4 <argint>
  if(n < 0)
    80002144:	fcc42783          	lw	a5,-52(s0)
    80002148:	0607c863          	bltz	a5,800021b8 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    8000214c:	0000d517          	auipc	a0,0xd
    80002150:	a6450513          	addi	a0,a0,-1436 # 8000ebb0 <tickslock>
    80002154:	052040ef          	jal	800061a6 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002158:	fcc42783          	lw	a5,-52(s0)
    8000215c:	c3b9                	beqz	a5,800021a2 <sys_sleep+0x70>
    8000215e:	f426                	sd	s1,40(sp)
    80002160:	f04a                	sd	s2,32(sp)
    80002162:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002164:	00007997          	auipc	s3,0x7
    80002168:	8949a983          	lw	s3,-1900(s3) # 800089f8 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    8000216c:	0000d917          	auipc	s2,0xd
    80002170:	a4490913          	addi	s2,s2,-1468 # 8000ebb0 <tickslock>
    80002174:	00007497          	auipc	s1,0x7
    80002178:	88448493          	addi	s1,s1,-1916 # 800089f8 <ticks>
    if(killed(myproc())){
    8000217c:	f89fe0ef          	jal	80001104 <myproc>
    80002180:	f92ff0ef          	jal	80001912 <killed>
    80002184:	ed0d                	bnez	a0,800021be <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80002186:	85ca                	mv	a1,s2
    80002188:	8526                	mv	a0,s1
    8000218a:	d4cff0ef          	jal	800016d6 <sleep>
  while(ticks - ticks0 < n){
    8000218e:	409c                	lw	a5,0(s1)
    80002190:	413787bb          	subw	a5,a5,s3
    80002194:	fcc42703          	lw	a4,-52(s0)
    80002198:	fee7e2e3          	bltu	a5,a4,8000217c <sys_sleep+0x4a>
    8000219c:	74a2                	ld	s1,40(sp)
    8000219e:	7902                	ld	s2,32(sp)
    800021a0:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    800021a2:	0000d517          	auipc	a0,0xd
    800021a6:	a0e50513          	addi	a0,a0,-1522 # 8000ebb0 <tickslock>
    800021aa:	0a4040ef          	jal	8000624e <release>
  return 0;
    800021ae:	4501                	li	a0,0
}
    800021b0:	70e2                	ld	ra,56(sp)
    800021b2:	7442                	ld	s0,48(sp)
    800021b4:	6121                	addi	sp,sp,64
    800021b6:	8082                	ret
    n = 0;
    800021b8:	fc042623          	sw	zero,-52(s0)
    800021bc:	bf41                	j	8000214c <sys_sleep+0x1a>
      release(&tickslock);
    800021be:	0000d517          	auipc	a0,0xd
    800021c2:	9f250513          	addi	a0,a0,-1550 # 8000ebb0 <tickslock>
    800021c6:	088040ef          	jal	8000624e <release>
      return -1;
    800021ca:	557d                	li	a0,-1
    800021cc:	74a2                	ld	s1,40(sp)
    800021ce:	7902                	ld	s2,32(sp)
    800021d0:	69e2                	ld	s3,24(sp)
    800021d2:	bff9                	j	800021b0 <sys_sleep+0x7e>

00000000800021d4 <sys_kill>:

uint64
sys_kill(void)
{
    800021d4:	1101                	addi	sp,sp,-32
    800021d6:	ec06                	sd	ra,24(sp)
    800021d8:	e822                	sd	s0,16(sp)
    800021da:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    800021dc:	fec40593          	addi	a1,s0,-20
    800021e0:	4501                	li	a0,0
    800021e2:	de3ff0ef          	jal	80001fc4 <argint>
  return kill(pid);
    800021e6:	fec42503          	lw	a0,-20(s0)
    800021ea:	e9eff0ef          	jal	80001888 <kill>
}
    800021ee:	60e2                	ld	ra,24(sp)
    800021f0:	6442                	ld	s0,16(sp)
    800021f2:	6105                	addi	sp,sp,32
    800021f4:	8082                	ret

00000000800021f6 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    800021f6:	1101                	addi	sp,sp,-32
    800021f8:	ec06                	sd	ra,24(sp)
    800021fa:	e822                	sd	s0,16(sp)
    800021fc:	e426                	sd	s1,8(sp)
    800021fe:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002200:	0000d517          	auipc	a0,0xd
    80002204:	9b050513          	addi	a0,a0,-1616 # 8000ebb0 <tickslock>
    80002208:	79f030ef          	jal	800061a6 <acquire>
  xticks = ticks;
    8000220c:	00006797          	auipc	a5,0x6
    80002210:	7ec7a783          	lw	a5,2028(a5) # 800089f8 <ticks>
    80002214:	84be                	mv	s1,a5
  release(&tickslock);
    80002216:	0000d517          	auipc	a0,0xd
    8000221a:	99a50513          	addi	a0,a0,-1638 # 8000ebb0 <tickslock>
    8000221e:	030040ef          	jal	8000624e <release>
  return xticks;
}
    80002222:	02049513          	slli	a0,s1,0x20
    80002226:	9101                	srli	a0,a0,0x20
    80002228:	60e2                	ld	ra,24(sp)
    8000222a:	6442                	ld	s0,16(sp)
    8000222c:	64a2                	ld	s1,8(sp)
    8000222e:	6105                	addi	sp,sp,32
    80002230:	8082                	ret

0000000080002232 <binit>:
    return blockno % NBUCKET;
}

// Initialize buffer cache and distribute buffers among buckets
void
binit(void) {
    80002232:	7119                	addi	sp,sp,-128
    80002234:	fc86                	sd	ra,120(sp)
    80002236:	f8a2                	sd	s0,112(sp)
    80002238:	f4a6                	sd	s1,104(sp)
    8000223a:	f0ca                	sd	s2,96(sp)
    8000223c:	ecce                	sd	s3,88(sp)
    8000223e:	e8d2                	sd	s4,80(sp)
    80002240:	e4d6                	sd	s5,72(sp)
    80002242:	e0da                	sd	s6,64(sp)
    80002244:	fc5e                	sd	s7,56(sp)
    80002246:	f862                	sd	s8,48(sp)
    80002248:	f466                	sd	s9,40(sp)
    8000224a:	0100                	addi	s0,sp,128
    struct buf *b;
    char lockname[32];

    initlock(&bcache.lock, "bcache");
    8000224c:	00006597          	auipc	a1,0x6
    80002250:	17c58593          	addi	a1,a1,380 # 800083c8 <etext+0x3c8>
    80002254:	0000e517          	auipc	a0,0xe
    80002258:	02450513          	addi	a0,a0,36 # 80010278 <bcache>
    8000225c:	08a040ef          	jal	800062e6 <initlock>

    // Initialize each bucket
    for(int i = 0; i < NBUCKET; i++) {
    80002260:	0000d497          	auipc	s1,0xd
    80002264:	97048493          	addi	s1,s1,-1680 # 8000ebd0 <bcache_bucket>
    80002268:	4901                	li	s2,0
        snprintf(lockname, sizeof(lockname), "bcache%d", i);
    8000226a:	f8040993          	addi	s3,s0,-128
    8000226e:	00006b17          	auipc	s6,0x6
    80002272:	162b0b13          	addi	s6,s6,354 # 800083d0 <etext+0x3d0>
    80002276:	02000a93          	li	s5,32
    for(int i = 0; i < NBUCKET; i++) {
    8000227a:	4a15                	li	s4,5
        snprintf(lockname, sizeof(lockname), "bcache%d", i);
    8000227c:	86ca                	mv	a3,s2
    8000227e:	865a                	mv	a2,s6
    80002280:	85d6                	mv	a1,s5
    80002282:	854e                	mv	a0,s3
    80002284:	2c4030ef          	jal	80005548 <snprintf>
        initlock(&bcache_bucket[i].lock, lockname);
    80002288:	85ce                	mv	a1,s3
    8000228a:	8526                	mv	a0,s1
    8000228c:	05a040ef          	jal	800062e6 <initlock>
        bcache_bucket[i].head.prev = &bcache_bucket[i].head;
    80002290:	02048793          	addi	a5,s1,32
    80002294:	f8bc                	sd	a5,112(s1)
        bcache_bucket[i].head.next = &bcache_bucket[i].head;
    80002296:	fcbc                	sd	a5,120(s1)
        bcache_bucket[i].nbuf = 0;
    80002298:	4804a023          	sw	zero,1152(s1)
    for(int i = 0; i < NBUCKET; i++) {
    8000229c:	2905                	addiw	s2,s2,1
    8000229e:	48848493          	addi	s1,s1,1160
    800022a2:	fd491de3          	bne	s2,s4,8000227c <binit+0x4a>
    }

    // Distribute all buffers evenly among buckets
    for(b = bcache.buf; b < bcache.buf + NBUF; b++) {
    800022a6:	0000e497          	auipc	s1,0xe
    800022aa:	ff248493          	addi	s1,s1,-14 # 80010298 <bcache+0x20>
        uint bucket_id = (b - bcache.buf) / NBUF_PER_BUCKET;
    800022ae:	8ba6                	mv	s7,s1
    800022b0:	faf8b9b7          	lui	s3,0xfaf8b
    800022b4:	f8b98993          	addi	s3,s3,-117 # fffffffffaf8af8b <end+0xffffffff7af65903>
    800022b8:	09b2                	slli	s3,s3,0xc
    800022ba:	f8b98993          	addi	s3,s3,-117
    800022be:	09b2                	slli	s3,s3,0xc
    800022c0:	f8b98993          	addi	s3,s3,-117
    800022c4:	09b2                	slli	s3,s3,0xc
    800022c6:	f8b98993          	addi	s3,s3,-117
    800022ca:	000ab7b7          	lui	a5,0xab
    800022ce:	aab78793          	addi	a5,a5,-1365 # aaaab <_entry-0x7ff55555>
    800022d2:	07b2                	slli	a5,a5,0xc
    800022d4:	aab78793          	addi	a5,a5,-1365
    800022d8:	2aaaba37          	lui	s4,0x2aaab
    800022dc:	aaaa0a13          	addi	s4,s4,-1366 # 2aaaaaaa <_entry-0x55555556>
    800022e0:	1a02                	slli	s4,s4,0x20
    800022e2:	9a3e                	add	s4,s4,a5
        if(bucket_id >= NBUCKET) bucket_id = NBUCKET - 1;
    800022e4:	4b11                	li	s6,4
    800022e6:	4c11                	li	s8,4

        b->next = bcache_bucket[bucket_id].head.next;
    800022e8:	0000d917          	auipc	s2,0xd
    800022ec:	8e890913          	addi	s2,s2,-1816 # 8000ebd0 <bcache_bucket>
    800022f0:	48800a93          	li	s5,1160
    800022f4:	a881                	j	80002344 <binit+0x112>
    800022f6:	1782                	slli	a5,a5,0x20
    800022f8:	9381                	srli	a5,a5,0x20
    800022fa:	035787b3          	mul	a5,a5,s5
    800022fe:	00f90cb3          	add	s9,s2,a5
    80002302:	078cb703          	ld	a4,120(s9) # fffffffffffff078 <end+0xffffffff7ffd99f0>
    80002306:	ecb8                	sd	a4,88(s1)
        b->prev = &bcache_bucket[bucket_id].head;
    80002308:	02078793          	addi	a5,a5,32
    8000230c:	97ca                	add	a5,a5,s2
    8000230e:	e8bc                	sd	a5,80(s1)
        initsleeplock(&b->lock, "buffer");
    80002310:	00006597          	auipc	a1,0x6
    80002314:	0d058593          	addi	a1,a1,208 # 800083e0 <etext+0x3e0>
    80002318:	01048513          	addi	a0,s1,16
    8000231c:	4d2010ef          	jal	800037ee <initsleeplock>
        bcache_bucket[bucket_id].head.next->prev = b;
    80002320:	078cb783          	ld	a5,120(s9)
    80002324:	eba4                	sd	s1,80(a5)
        bcache_bucket[bucket_id].head.next = b;
    80002326:	069cbc23          	sd	s1,120(s9)
        bcache_bucket[bucket_id].nbuf++;
    8000232a:	480ca783          	lw	a5,1152(s9)
    8000232e:	2785                	addiw	a5,a5,1
    80002330:	48fca023          	sw	a5,1152(s9)
    for(b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002334:	46048493          	addi	s1,s1,1120
    80002338:	00016797          	auipc	a5,0x16
    8000233c:	2a078793          	addi	a5,a5,672 # 800185d8 <sb>
    80002340:	02f48163          	beq	s1,a5,80002362 <binit+0x130>
        uint bucket_id = (b - bcache.buf) / NBUF_PER_BUCKET;
    80002344:	417487b3          	sub	a5,s1,s7
    80002348:	8795                	srai	a5,a5,0x5
    8000234a:	033787b3          	mul	a5,a5,s3
    8000234e:	03479733          	mulh	a4,a5,s4
    80002352:	97fd                	srai	a5,a5,0x3f
    80002354:	8f1d                	sub	a4,a4,a5
    80002356:	87ba                	mv	a5,a4
        if(bucket_id >= NBUCKET) bucket_id = NBUCKET - 1;
    80002358:	2701                	sext.w	a4,a4
    8000235a:	f8eb7ee3          	bgeu	s6,a4,800022f6 <binit+0xc4>
    8000235e:	87e2                	mv	a5,s8
    80002360:	bf59                	j	800022f6 <binit+0xc4>
    }
}
    80002362:	70e6                	ld	ra,120(sp)
    80002364:	7446                	ld	s0,112(sp)
    80002366:	74a6                	ld	s1,104(sp)
    80002368:	7906                	ld	s2,96(sp)
    8000236a:	69e6                	ld	s3,88(sp)
    8000236c:	6a46                	ld	s4,80(sp)
    8000236e:	6aa6                	ld	s5,72(sp)
    80002370:	6b06                	ld	s6,64(sp)
    80002372:	7be2                	ld	s7,56(sp)
    80002374:	7c42                	ld	s8,48(sp)
    80002376:	7ca2                	ld	s9,40(sp)
    80002378:	6109                	addi	sp,sp,128
    8000237a:	8082                	ret

000000008000237c <bread>:
    panic("bget: no buffers available");
}

// Return a locked buffer containing the data of the specified block
struct buf*
bread(uint dev, uint blockno) {
    8000237c:	7119                	addi	sp,sp,-128
    8000237e:	fc86                	sd	ra,120(sp)
    80002380:	f8a2                	sd	s0,112(sp)
    80002382:	f4a6                	sd	s1,104(sp)
    80002384:	f0ca                	sd	s2,96(sp)
    80002386:	ecce                	sd	s3,88(sp)
    80002388:	e8d2                	sd	s4,80(sp)
    8000238a:	e4d6                	sd	s5,72(sp)
    8000238c:	fc5e                	sd	s7,56(sp)
    8000238e:	f466                	sd	s9,40(sp)
    80002390:	ec6e                	sd	s11,24(sp)
    80002392:	0100                	addi	s0,sp,128
    80002394:	89aa                	mv	s3,a0
    80002396:	8a2e                	mv	s4,a1
    return blockno % NBUCKET;
    80002398:	02059713          	slli	a4,a1,0x20
    8000239c:	9301                	srli	a4,a4,0x20
    8000239e:	000cd7b7          	lui	a5,0xcd
    800023a2:	ccd78793          	addi	a5,a5,-819 # ccccd <_entry-0x7ff33333>
    800023a6:	07b2                	slli	a5,a5,0xc
    800023a8:	ccd78793          	addi	a5,a5,-819
    800023ac:	02f707b3          	mul	a5,a4,a5
    800023b0:	9389                	srli	a5,a5,0x22
    800023b2:	0027971b          	slliw	a4,a5,0x2
    800023b6:	9fb9                	addw	a5,a5,a4
    800023b8:	40f587bb          	subw	a5,a1,a5
    800023bc:	8dbe                	mv	s11,a5
    800023be:	8cbe                	mv	s9,a5
    acquire(&bcache_bucket[bucket_id].lock);
    800023c0:	02079913          	slli	s2,a5,0x20
    800023c4:	02095913          	srli	s2,s2,0x20
    800023c8:	48800793          	li	a5,1160
    800023cc:	02f90933          	mul	s2,s2,a5
    800023d0:	0000da97          	auipc	s5,0xd
    800023d4:	800a8a93          	addi	s5,s5,-2048 # 8000ebd0 <bcache_bucket>
    800023d8:	01590bb3          	add	s7,s2,s5
    800023dc:	855e                	mv	a0,s7
    800023de:	5c9030ef          	jal	800061a6 <acquire>
    for(b = bcache_bucket[bucket_id].head.next; b != &bcache_bucket[bucket_id].head; b = b->next) {
    800023e2:	078bb483          	ld	s1,120(s7)
    800023e6:	02090913          	addi	s2,s2,32
    800023ea:	9956                	add	s2,s2,s5
    800023ec:	05249963          	bne	s1,s2,8000243e <bread+0xc2>
    for(b = bcache_bucket[bucket_id].head.prev; b != &bcache_bucket[bucket_id].head; b = b->prev) {
    800023f0:	020d9713          	slli	a4,s11,0x20
    800023f4:	9301                	srli	a4,a4,0x20
    800023f6:	48800793          	li	a5,1160
    800023fa:	02f70733          	mul	a4,a4,a5
    800023fe:	0000c797          	auipc	a5,0xc
    80002402:	7d278793          	addi	a5,a5,2002 # 8000ebd0 <bcache_bucket>
    80002406:	97ba                	add	a5,a5,a4
    80002408:	7ba4                	ld	s1,112(a5)
    8000240a:	01248763          	beq	s1,s2,80002418 <bread+0x9c>
        if(b->refcnt == 0) {
    8000240e:	44bc                	lw	a5,72(s1)
    80002410:	cba1                	beqz	a5,80002460 <bread+0xe4>
    for(b = bcache_bucket[bucket_id].head.prev; b != &bcache_bucket[bucket_id].head; b = b->prev) {
    80002412:	68a4                	ld	s1,80(s1)
    80002414:	ff249de3          	bne	s1,s2,8000240e <bread+0x92>
    80002418:	e0da                	sd	s6,64(sp)
    8000241a:	f862                	sd	s8,48(sp)
    8000241c:	f06a                	sd	s10,32(sp)
    release(&bcache_bucket[bucket_id].lock);
    8000241e:	855e                	mv	a0,s7
    80002420:	62f030ef          	jal	8000624e <release>
    for(int i = 0; i < NBUCKET; i++) {
    80002424:	0000c797          	auipc	a5,0xc
    80002428:	7cc78793          	addi	a5,a5,1996 # 8000ebf0 <bcache_bucket+0x20>
    8000242c:	f8f43423          	sd	a5,-120(s0)
    release(&bcache_bucket[bucket_id].lock);
    80002430:	8abe                	mv	s5,a5
    for(int i = 0; i < NBUCKET; i++) {
    80002432:	4b01                	li	s6,0
    80002434:	4d15                	li	s10,5
    80002436:	a061                	j	800024be <bread+0x142>
    for(b = bcache_bucket[bucket_id].head.next; b != &bcache_bucket[bucket_id].head; b = b->next) {
    80002438:	6ca4                	ld	s1,88(s1)
    8000243a:	fb248be3          	beq	s1,s2,800023f0 <bread+0x74>
        if(b->dev == dev && b->blockno == blockno) {
    8000243e:	449c                	lw	a5,8(s1)
    80002440:	ff379ce3          	bne	a5,s3,80002438 <bread+0xbc>
    80002444:	44dc                	lw	a5,12(s1)
    80002446:	ff4799e3          	bne	a5,s4,80002438 <bread+0xbc>
            b->refcnt++;
    8000244a:	44bc                	lw	a5,72(s1)
    8000244c:	2785                	addiw	a5,a5,1
    8000244e:	c4bc                	sw	a5,72(s1)
            release(&bcache_bucket[bucket_id].lock);
    80002450:	855e                	mv	a0,s7
    80002452:	5fd030ef          	jal	8000624e <release>
            acquiresleep(&b->lock);
    80002456:	01048513          	addi	a0,s1,16
    8000245a:	3ca010ef          	jal	80003824 <acquiresleep>
            return b;
    8000245e:	a28d                	j	800025c0 <bread+0x244>
            b->dev = dev;
    80002460:	0134a423          	sw	s3,8(s1)
            b->blockno = blockno;
    80002464:	0144a623          	sw	s4,12(s1)
            b->valid = 0;
    80002468:	0004a023          	sw	zero,0(s1)
            b->refcnt = 1;
    8000246c:	4785                	li	a5,1
    8000246e:	c4bc                	sw	a5,72(s1)
            release(&bcache_bucket[bucket_id].lock);
    80002470:	855e                	mv	a0,s7
    80002472:	5dd030ef          	jal	8000624e <release>
            acquiresleep(&b->lock);
    80002476:	01048513          	addi	a0,s1,16
    8000247a:	3aa010ef          	jal	80003824 <acquiresleep>
            return b;
    8000247e:	a289                	j	800025c0 <bread+0x244>
            victim->next->prev = victim->prev;
    80002480:	6cb8                	ld	a4,88(s1)
    80002482:	68bc                	ld	a5,80(s1)
    80002484:	eb3c                	sd	a5,80(a4)
            victim->prev->next = victim->next;
    80002486:	6cb8                	ld	a4,88(s1)
    80002488:	efb8                	sd	a4,88(a5)
            bcache_bucket[i].nbuf--;
    8000248a:	48800793          	li	a5,1160
    8000248e:	02fb0b33          	mul	s6,s6,a5
    80002492:	0000c797          	auipc	a5,0xc
    80002496:	73e78793          	addi	a5,a5,1854 # 8000ebd0 <bcache_bucket>
    8000249a:	97da                	add	a5,a5,s6
    8000249c:	4807a703          	lw	a4,1152(a5)
    800024a0:	377d                	addiw	a4,a4,-1
    800024a2:	48e7a023          	sw	a4,1152(a5)
            release(&bcache_bucket[i].lock);
    800024a6:	8562                	mv	a0,s8
    800024a8:	5a7030ef          	jal	8000624e <release>
    if(victim) {
    800024ac:	a86d                	j	80002566 <bread+0x1ea>
        release(&bcache_bucket[i].lock);
    800024ae:	8562                	mv	a0,s8
    800024b0:	59f030ef          	jal	8000624e <release>
    for(int i = 0; i < NBUCKET; i++) {
    800024b4:	2b05                	addiw	s6,s6,1
    800024b6:	488a8a93          	addi	s5,s5,1160
    800024ba:	03ab0963          	beq	s6,s10,800024ec <bread+0x170>
        if(i == bucket_id) continue;
    800024be:	ff6c8be3          	beq	s9,s6,800024b4 <bread+0x138>
        acquire(&bcache_bucket[i].lock);
    800024c2:	fe0a8c13          	addi	s8,s5,-32
    800024c6:	8562                	mv	a0,s8
    800024c8:	4df030ef          	jal	800061a6 <acquire>
        if(bcache_bucket[i].nbuf > NBUF_PER_BUCKET) {
    800024cc:	8756                	mv	a4,s5
    800024ce:	460aa783          	lw	a5,1120(s5)
    800024d2:	4699                	li	a3,6
    800024d4:	fcf6dde3          	bge	a3,a5,800024ae <bread+0x132>
            for(b = bcache_bucket[i].head.prev; b != &bcache_bucket[i].head; b = b->prev) {
    800024d8:	050ab483          	ld	s1,80(s5)
    800024dc:	fd5489e3          	beq	s1,s5,800024ae <bread+0x132>
                if(b->refcnt == 0) {
    800024e0:	44bc                	lw	a5,72(s1)
    800024e2:	dfd9                	beqz	a5,80002480 <bread+0x104>
            for(b = bcache_bucket[i].head.prev; b != &bcache_bucket[i].head; b = b->prev) {
    800024e4:	68a4                	ld	s1,80(s1)
    800024e6:	fee49de3          	bne	s1,a4,800024e0 <bread+0x164>
    800024ea:	b7d1                	j	800024ae <bread+0x132>
        for(int i = 0; i < NBUCKET; i++) {
    800024ec:	4a81                	li	s5,0
            if(i == bucket_id) continue;
    800024ee:	035c9263          	bne	s9,s5,80002512 <bread+0x196>
        for(int i = 0; i < NBUCKET; i++) {
    800024f2:	2a85                	addiw	s5,s5,1
    800024f4:	f8843783          	ld	a5,-120(s0)
    800024f8:	48878793          	addi	a5,a5,1160
    800024fc:	f8f43423          	sd	a5,-120(s0)
    80002500:	4795                	li	a5,5
    80002502:	fefa96e3          	bne	s5,a5,800024ee <bread+0x172>
    panic("bget: no buffers available");
    80002506:	00006517          	auipc	a0,0x6
    8000250a:	ee250513          	addi	a0,a0,-286 # 800083e8 <etext+0x3e8>
    8000250e:	175030ef          	jal	80005e82 <panic>
            acquire(&bcache_bucket[i].lock);
    80002512:	f8843483          	ld	s1,-120(s0)
    80002516:	fe048b13          	addi	s6,s1,-32
    8000251a:	855a                	mv	a0,s6
    8000251c:	48b030ef          	jal	800061a6 <acquire>
            for(b = bcache_bucket[i].head.prev; b != &bcache_bucket[i].head; b = b->prev) {
    80002520:	8726                	mv	a4,s1
    80002522:	68a4                	ld	s1,80(s1)
    80002524:	00e48763          	beq	s1,a4,80002532 <bread+0x1b6>
                if(b->refcnt == 0) {
    80002528:	44bc                	lw	a5,72(s1)
    8000252a:	cb81                	beqz	a5,8000253a <bread+0x1be>
            for(b = bcache_bucket[i].head.prev; b != &bcache_bucket[i].head; b = b->prev) {
    8000252c:	68a4                	ld	s1,80(s1)
    8000252e:	fee49de3          	bne	s1,a4,80002528 <bread+0x1ac>
            release(&bcache_bucket[i].lock);
    80002532:	855a                	mv	a0,s6
    80002534:	51b030ef          	jal	8000624e <release>
    80002538:	bf6d                	j	800024f2 <bread+0x176>
                    victim->next->prev = victim->prev;
    8000253a:	6cb8                	ld	a4,88(s1)
    8000253c:	68bc                	ld	a5,80(s1)
    8000253e:	eb3c                	sd	a5,80(a4)
                    victim->prev->next = victim->next;
    80002540:	6cb8                	ld	a4,88(s1)
    80002542:	efb8                	sd	a4,88(a5)
                    bcache_bucket[i].nbuf--;
    80002544:	48800793          	li	a5,1160
    80002548:	02fa8ab3          	mul	s5,s5,a5
    8000254c:	0000c797          	auipc	a5,0xc
    80002550:	68478793          	addi	a5,a5,1668 # 8000ebd0 <bcache_bucket>
    80002554:	97d6                	add	a5,a5,s5
    80002556:	4807a703          	lw	a4,1152(a5)
    8000255a:	377d                	addiw	a4,a4,-1
    8000255c:	48e7a023          	sw	a4,1152(a5)
                    release(&bcache_bucket[i].lock);
    80002560:	855a                	mv	a0,s6
    80002562:	4ed030ef          	jal	8000624e <release>
        acquire(&bcache_bucket[bucket_id].lock);
    80002566:	855e                	mv	a0,s7
    80002568:	43f030ef          	jal	800061a6 <acquire>
        victim->dev = dev;
    8000256c:	0134a423          	sw	s3,8(s1)
        victim->blockno = blockno;
    80002570:	0144a623          	sw	s4,12(s1)
        victim->valid = 0;
    80002574:	0004a023          	sw	zero,0(s1)
        victim->refcnt = 1;
    80002578:	4785                	li	a5,1
    8000257a:	c4bc                	sw	a5,72(s1)
        victim->next = bcache_bucket[bucket_id].head.next;
    8000257c:	020d9793          	slli	a5,s11,0x20
    80002580:	9381                	srli	a5,a5,0x20
    80002582:	48800713          	li	a4,1160
    80002586:	02e787b3          	mul	a5,a5,a4
    8000258a:	0000c717          	auipc	a4,0xc
    8000258e:	64670713          	addi	a4,a4,1606 # 8000ebd0 <bcache_bucket>
    80002592:	97ba                	add	a5,a5,a4
    80002594:	7fb8                	ld	a4,120(a5)
    80002596:	ecb8                	sd	a4,88(s1)
        victim->prev = &bcache_bucket[bucket_id].head;
    80002598:	0524b823          	sd	s2,80(s1)
        bcache_bucket[bucket_id].head.next->prev = victim;
    8000259c:	7fb8                	ld	a4,120(a5)
    8000259e:	eb24                	sd	s1,80(a4)
        bcache_bucket[bucket_id].head.next = victim;
    800025a0:	ffa4                	sd	s1,120(a5)
        bcache_bucket[bucket_id].nbuf++;
    800025a2:	4807a703          	lw	a4,1152(a5)
    800025a6:	2705                	addiw	a4,a4,1
    800025a8:	48e7a023          	sw	a4,1152(a5)
        release(&bcache_bucket[bucket_id].lock);
    800025ac:	855e                	mv	a0,s7
    800025ae:	4a1030ef          	jal	8000624e <release>
        acquiresleep(&victim->lock);
    800025b2:	01048513          	addi	a0,s1,16
    800025b6:	26e010ef          	jal	80003824 <acquiresleep>
    800025ba:	6b06                	ld	s6,64(sp)
    800025bc:	7c42                	ld	s8,48(sp)
    800025be:	7d02                	ld	s10,32(sp)
    struct buf *b = bget(dev, blockno);
    if(!b->valid) {
    800025c0:	409c                	lw	a5,0(s1)
    800025c2:	cf91                	beqz	a5,800025de <bread+0x262>
        virtio_disk_rw(b, 0);
        b->valid = 1;
    }
    return b;
}
    800025c4:	8526                	mv	a0,s1
    800025c6:	70e6                	ld	ra,120(sp)
    800025c8:	7446                	ld	s0,112(sp)
    800025ca:	74a6                	ld	s1,104(sp)
    800025cc:	7906                	ld	s2,96(sp)
    800025ce:	69e6                	ld	s3,88(sp)
    800025d0:	6a46                	ld	s4,80(sp)
    800025d2:	6aa6                	ld	s5,72(sp)
    800025d4:	7be2                	ld	s7,56(sp)
    800025d6:	7ca2                	ld	s9,40(sp)
    800025d8:	6de2                	ld	s11,24(sp)
    800025da:	6109                	addi	sp,sp,128
    800025dc:	8082                	ret
        virtio_disk_rw(b, 0);
    800025de:	4581                	li	a1,0
    800025e0:	8526                	mv	a0,s1
    800025e2:	2bf020ef          	jal	800050a0 <virtio_disk_rw>
        b->valid = 1;
    800025e6:	4785                	li	a5,1
    800025e8:	c09c                	sw	a5,0(s1)
    return b;
    800025ea:	bfe9                	j	800025c4 <bread+0x248>

00000000800025ec <bwrite>:

// Write buffer contents to disk (buffer must be locked)
void
bwrite(struct buf *b) {
    800025ec:	1101                	addi	sp,sp,-32
    800025ee:	ec06                	sd	ra,24(sp)
    800025f0:	e822                	sd	s0,16(sp)
    800025f2:	e426                	sd	s1,8(sp)
    800025f4:	1000                	addi	s0,sp,32
    800025f6:	84aa                	mv	s1,a0
    if(!holdingsleep(&b->lock)) panic("bwrite: buffer not locked");
    800025f8:	0541                	addi	a0,a0,16
    800025fa:	2a8010ef          	jal	800038a2 <holdingsleep>
    800025fe:	c911                	beqz	a0,80002612 <bwrite+0x26>
    virtio_disk_rw(b, 1);
    80002600:	4585                	li	a1,1
    80002602:	8526                	mv	a0,s1
    80002604:	29d020ef          	jal	800050a0 <virtio_disk_rw>
}
    80002608:	60e2                	ld	ra,24(sp)
    8000260a:	6442                	ld	s0,16(sp)
    8000260c:	64a2                	ld	s1,8(sp)
    8000260e:	6105                	addi	sp,sp,32
    80002610:	8082                	ret
    if(!holdingsleep(&b->lock)) panic("bwrite: buffer not locked");
    80002612:	00006517          	auipc	a0,0x6
    80002616:	df650513          	addi	a0,a0,-522 # 80008408 <etext+0x408>
    8000261a:	069030ef          	jal	80005e82 <panic>

000000008000261e <brelse>:

// Release a locked buffer and move it to the MRU position in its bucket
void
brelse(struct buf *b) {
    8000261e:	7179                	addi	sp,sp,-48
    80002620:	f406                	sd	ra,40(sp)
    80002622:	f022                	sd	s0,32(sp)
    80002624:	ec26                	sd	s1,24(sp)
    80002626:	e84a                	sd	s2,16(sp)
    80002628:	e44e                	sd	s3,8(sp)
    8000262a:	e052                	sd	s4,0(sp)
    8000262c:	1800                	addi	s0,sp,48
    8000262e:	84aa                	mv	s1,a0
    if(!holdingsleep(&b->lock)) panic("brelse: buffer not locked");
    80002630:	01050913          	addi	s2,a0,16
    80002634:	854a                	mv	a0,s2
    80002636:	26c010ef          	jal	800038a2 <holdingsleep>
    8000263a:	c959                	beqz	a0,800026d0 <brelse+0xb2>

    releasesleep(&b->lock);
    8000263c:	854a                	mv	a0,s2
    8000263e:	22c010ef          	jal	8000386a <releasesleep>
    return blockno % NBUCKET;
    80002642:	44d4                	lw	a3,12(s1)
    80002644:	02069713          	slli	a4,a3,0x20
    80002648:	9301                	srli	a4,a4,0x20
    8000264a:	000cd7b7          	lui	a5,0xcd
    8000264e:	ccd78793          	addi	a5,a5,-819 # ccccd <_entry-0x7ff33333>
    80002652:	07b2                	slli	a5,a5,0xc
    80002654:	ccd78793          	addi	a5,a5,-819
    80002658:	02f707b3          	mul	a5,a4,a5
    8000265c:	9389                	srli	a5,a5,0x22
    8000265e:	0027971b          	slliw	a4,a5,0x2
    80002662:	9f3d                	addw	a4,a4,a5
    80002664:	40e6893b          	subw	s2,a3,a4

    uint bucket_id = hash(b->dev, b->blockno);
    acquire(&bcache_bucket[bucket_id].lock);
    80002668:	02091713          	slli	a4,s2,0x20
    8000266c:	9301                	srli	a4,a4,0x20
    8000266e:	48800793          	li	a5,1160
    80002672:	02f709b3          	mul	s3,a4,a5
    80002676:	0000c517          	auipc	a0,0xc
    8000267a:	55a50513          	addi	a0,a0,1370 # 8000ebd0 <bcache_bucket>
    8000267e:	00a98a33          	add	s4,s3,a0
    80002682:	8552                	mv	a0,s4
    80002684:	323030ef          	jal	800061a6 <acquire>
    b->refcnt--;
    80002688:	44b8                	lw	a4,72(s1)
    8000268a:	377d                	addiw	a4,a4,-1
    8000268c:	c4b8                	sw	a4,72(s1)
    if(b->refcnt == 0) {
    8000268e:	e715                	bnez	a4,800026ba <brelse+0x9c>
        // Move to the head of MRU list
        b->next->prev = b->prev;
    80002690:	6cb8                	ld	a4,88(s1)
    80002692:	68bc                	ld	a5,80(s1)
    80002694:	eb3c                	sd	a5,80(a4)
        b->prev->next = b->next;
    80002696:	6cb8                	ld	a4,88(s1)
    80002698:	efb8                	sd	a4,88(a5)
        b->next = bcache_bucket[bucket_id].head.next;
    8000269a:	0000c697          	auipc	a3,0xc
    8000269e:	53668693          	addi	a3,a3,1334 # 8000ebd0 <bcache_bucket>
    800026a2:	078a3703          	ld	a4,120(s4)
    800026a6:	ecb8                	sd	a4,88(s1)
        b->prev = &bcache_bucket[bucket_id].head;
    800026a8:	02098713          	addi	a4,s3,32
    800026ac:	9736                	add	a4,a4,a3
    800026ae:	e8b8                	sd	a4,80(s1)
        bcache_bucket[bucket_id].head.next->prev = b;
    800026b0:	078a3703          	ld	a4,120(s4)
    800026b4:	eb24                	sd	s1,80(a4)
        bcache_bucket[bucket_id].head.next = b;
    800026b6:	069a3c23          	sd	s1,120(s4)
    }
    release(&bcache_bucket[bucket_id].lock);
    800026ba:	8552                	mv	a0,s4
    800026bc:	393030ef          	jal	8000624e <release>
}
    800026c0:	70a2                	ld	ra,40(sp)
    800026c2:	7402                	ld	s0,32(sp)
    800026c4:	64e2                	ld	s1,24(sp)
    800026c6:	6942                	ld	s2,16(sp)
    800026c8:	69a2                	ld	s3,8(sp)
    800026ca:	6a02                	ld	s4,0(sp)
    800026cc:	6145                	addi	sp,sp,48
    800026ce:	8082                	ret
    if(!holdingsleep(&b->lock)) panic("brelse: buffer not locked");
    800026d0:	00006517          	auipc	a0,0x6
    800026d4:	d5850513          	addi	a0,a0,-680 # 80008428 <etext+0x428>
    800026d8:	7aa030ef          	jal	80005e82 <panic>

00000000800026dc <bpin>:

// Increment reference count to prevent eviction
void
bpin(struct buf *b) {
    800026dc:	1101                	addi	sp,sp,-32
    800026de:	ec06                	sd	ra,24(sp)
    800026e0:	e822                	sd	s0,16(sp)
    800026e2:	e426                	sd	s1,8(sp)
    800026e4:	e04a                	sd	s2,0(sp)
    800026e6:	1000                	addi	s0,sp,32
    800026e8:	892a                	mv	s2,a0
    return blockno % NBUCKET;
    800026ea:	4544                	lw	s1,12(a0)
    800026ec:	02049713          	slli	a4,s1,0x20
    800026f0:	9301                	srli	a4,a4,0x20
    800026f2:	000cd7b7          	lui	a5,0xcd
    800026f6:	ccd78793          	addi	a5,a5,-819 # ccccd <_entry-0x7ff33333>
    800026fa:	07b2                	slli	a5,a5,0xc
    800026fc:	ccd78793          	addi	a5,a5,-819
    80002700:	02f707b3          	mul	a5,a4,a5
    80002704:	9389                	srli	a5,a5,0x22
    80002706:	0027971b          	slliw	a4,a5,0x2
    8000270a:	9fb9                	addw	a5,a5,a4
    8000270c:	9c9d                	subw	s1,s1,a5
    uint bucket_id = hash(b->dev, b->blockno);
    acquire(&bcache_bucket[bucket_id].lock);
    8000270e:	1482                	slli	s1,s1,0x20
    80002710:	9081                	srli	s1,s1,0x20
    80002712:	48800793          	li	a5,1160
    80002716:	02f484b3          	mul	s1,s1,a5
    8000271a:	0000c797          	auipc	a5,0xc
    8000271e:	4b678793          	addi	a5,a5,1206 # 8000ebd0 <bcache_bucket>
    80002722:	94be                	add	s1,s1,a5
    80002724:	8526                	mv	a0,s1
    80002726:	281030ef          	jal	800061a6 <acquire>
    b->refcnt++;
    8000272a:	04892783          	lw	a5,72(s2)
    8000272e:	2785                	addiw	a5,a5,1
    80002730:	04f92423          	sw	a5,72(s2)
    release(&bcache_bucket[bucket_id].lock);
    80002734:	8526                	mv	a0,s1
    80002736:	319030ef          	jal	8000624e <release>
}
    8000273a:	60e2                	ld	ra,24(sp)
    8000273c:	6442                	ld	s0,16(sp)
    8000273e:	64a2                	ld	s1,8(sp)
    80002740:	6902                	ld	s2,0(sp)
    80002742:	6105                	addi	sp,sp,32
    80002744:	8082                	ret

0000000080002746 <bunpin>:

// Decrement reference count to allow eviction
void
bunpin(struct buf *b) {
    80002746:	1101                	addi	sp,sp,-32
    80002748:	ec06                	sd	ra,24(sp)
    8000274a:	e822                	sd	s0,16(sp)
    8000274c:	e426                	sd	s1,8(sp)
    8000274e:	e04a                	sd	s2,0(sp)
    80002750:	1000                	addi	s0,sp,32
    80002752:	892a                	mv	s2,a0
    return blockno % NBUCKET;
    80002754:	4544                	lw	s1,12(a0)
    80002756:	02049713          	slli	a4,s1,0x20
    8000275a:	9301                	srli	a4,a4,0x20
    8000275c:	000cd7b7          	lui	a5,0xcd
    80002760:	ccd78793          	addi	a5,a5,-819 # ccccd <_entry-0x7ff33333>
    80002764:	07b2                	slli	a5,a5,0xc
    80002766:	ccd78793          	addi	a5,a5,-819
    8000276a:	02f707b3          	mul	a5,a4,a5
    8000276e:	9389                	srli	a5,a5,0x22
    80002770:	0027971b          	slliw	a4,a5,0x2
    80002774:	9fb9                	addw	a5,a5,a4
    80002776:	9c9d                	subw	s1,s1,a5
    uint bucket_id = hash(b->dev, b->blockno);
    acquire(&bcache_bucket[bucket_id].lock);
    80002778:	1482                	slli	s1,s1,0x20
    8000277a:	9081                	srli	s1,s1,0x20
    8000277c:	48800793          	li	a5,1160
    80002780:	02f484b3          	mul	s1,s1,a5
    80002784:	0000c797          	auipc	a5,0xc
    80002788:	44c78793          	addi	a5,a5,1100 # 8000ebd0 <bcache_bucket>
    8000278c:	94be                	add	s1,s1,a5
    8000278e:	8526                	mv	a0,s1
    80002790:	217030ef          	jal	800061a6 <acquire>
    b->refcnt--;
    80002794:	04892783          	lw	a5,72(s2)
    80002798:	37fd                	addiw	a5,a5,-1
    8000279a:	04f92423          	sw	a5,72(s2)
    release(&bcache_bucket[bucket_id].lock);
    8000279e:	8526                	mv	a0,s1
    800027a0:	2af030ef          	jal	8000624e <release>
}
    800027a4:	60e2                	ld	ra,24(sp)
    800027a6:	6442                	ld	s0,16(sp)
    800027a8:	64a2                	ld	s1,8(sp)
    800027aa:	6902                	ld	s2,0(sp)
    800027ac:	6105                	addi	sp,sp,32
    800027ae:	8082                	ret

00000000800027b0 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    800027b0:	1101                	addi	sp,sp,-32
    800027b2:	ec06                	sd	ra,24(sp)
    800027b4:	e822                	sd	s0,16(sp)
    800027b6:	e426                	sd	s1,8(sp)
    800027b8:	e04a                	sd	s2,0(sp)
    800027ba:	1000                	addi	s0,sp,32
    800027bc:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    800027be:	00d5d79b          	srliw	a5,a1,0xd
    800027c2:	00016597          	auipc	a1,0x16
    800027c6:	e325a583          	lw	a1,-462(a1) # 800185f4 <sb+0x1c>
    800027ca:	9dbd                	addw	a1,a1,a5
    800027cc:	bb1ff0ef          	jal	8000237c <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    800027d0:	0074f713          	andi	a4,s1,7
    800027d4:	4785                	li	a5,1
    800027d6:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    800027da:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    800027dc:	90d9                	srli	s1,s1,0x36
    800027de:	00950733          	add	a4,a0,s1
    800027e2:	06074703          	lbu	a4,96(a4)
    800027e6:	00e7f6b3          	and	a3,a5,a4
    800027ea:	c29d                	beqz	a3,80002810 <bfree+0x60>
    800027ec:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800027ee:	94aa                	add	s1,s1,a0
    800027f0:	fff7c793          	not	a5,a5
    800027f4:	8f7d                	and	a4,a4,a5
    800027f6:	06e48023          	sb	a4,96(s1)
  log_write(bp);
    800027fa:	723000ef          	jal	8000371c <log_write>
  brelse(bp);
    800027fe:	854a                	mv	a0,s2
    80002800:	e1fff0ef          	jal	8000261e <brelse>
}
    80002804:	60e2                	ld	ra,24(sp)
    80002806:	6442                	ld	s0,16(sp)
    80002808:	64a2                	ld	s1,8(sp)
    8000280a:	6902                	ld	s2,0(sp)
    8000280c:	6105                	addi	sp,sp,32
    8000280e:	8082                	ret
    panic("freeing free block");
    80002810:	00006517          	auipc	a0,0x6
    80002814:	c3850513          	addi	a0,a0,-968 # 80008448 <etext+0x448>
    80002818:	66a030ef          	jal	80005e82 <panic>

000000008000281c <balloc>:
{
    8000281c:	715d                	addi	sp,sp,-80
    8000281e:	e486                	sd	ra,72(sp)
    80002820:	e0a2                	sd	s0,64(sp)
    80002822:	fc26                	sd	s1,56(sp)
    80002824:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002826:	00016797          	auipc	a5,0x16
    8000282a:	db67a783          	lw	a5,-586(a5) # 800185dc <sb+0x4>
    8000282e:	0e078263          	beqz	a5,80002912 <balloc+0xf6>
    80002832:	f84a                	sd	s2,48(sp)
    80002834:	f44e                	sd	s3,40(sp)
    80002836:	f052                	sd	s4,32(sp)
    80002838:	ec56                	sd	s5,24(sp)
    8000283a:	e85a                	sd	s6,16(sp)
    8000283c:	e45e                	sd	s7,8(sp)
    8000283e:	e062                	sd	s8,0(sp)
    80002840:	8baa                	mv	s7,a0
    80002842:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002844:	00016b17          	auipc	s6,0x16
    80002848:	d94b0b13          	addi	s6,s6,-620 # 800185d8 <sb>
      m = 1 << (bi % 8);
    8000284c:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000284e:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002850:	6c09                	lui	s8,0x2
    80002852:	a09d                	j	800028b8 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002854:	97ca                	add	a5,a5,s2
    80002856:	8e55                	or	a2,a2,a3
    80002858:	06c78023          	sb	a2,96(a5)
        log_write(bp);
    8000285c:	854a                	mv	a0,s2
    8000285e:	6bf000ef          	jal	8000371c <log_write>
        brelse(bp);
    80002862:	854a                	mv	a0,s2
    80002864:	dbbff0ef          	jal	8000261e <brelse>
  bp = bread(dev, bno);
    80002868:	85a6                	mv	a1,s1
    8000286a:	855e                	mv	a0,s7
    8000286c:	b11ff0ef          	jal	8000237c <bread>
    80002870:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002872:	40000613          	li	a2,1024
    80002876:	4581                	li	a1,0
    80002878:	06050513          	addi	a0,a0,96
    8000287c:	c5dfd0ef          	jal	800004d8 <memset>
  log_write(bp);
    80002880:	854a                	mv	a0,s2
    80002882:	69b000ef          	jal	8000371c <log_write>
  brelse(bp);
    80002886:	854a                	mv	a0,s2
    80002888:	d97ff0ef          	jal	8000261e <brelse>
}
    8000288c:	7942                	ld	s2,48(sp)
    8000288e:	79a2                	ld	s3,40(sp)
    80002890:	7a02                	ld	s4,32(sp)
    80002892:	6ae2                	ld	s5,24(sp)
    80002894:	6b42                	ld	s6,16(sp)
    80002896:	6ba2                	ld	s7,8(sp)
    80002898:	6c02                	ld	s8,0(sp)
}
    8000289a:	8526                	mv	a0,s1
    8000289c:	60a6                	ld	ra,72(sp)
    8000289e:	6406                	ld	s0,64(sp)
    800028a0:	74e2                	ld	s1,56(sp)
    800028a2:	6161                	addi	sp,sp,80
    800028a4:	8082                	ret
    brelse(bp);
    800028a6:	854a                	mv	a0,s2
    800028a8:	d77ff0ef          	jal	8000261e <brelse>
  for(b = 0; b < sb.size; b += BPB){
    800028ac:	015c0abb          	addw	s5,s8,s5
    800028b0:	004b2783          	lw	a5,4(s6)
    800028b4:	04faf863          	bgeu	s5,a5,80002904 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    800028b8:	40dad59b          	sraiw	a1,s5,0xd
    800028bc:	01cb2783          	lw	a5,28(s6)
    800028c0:	9dbd                	addw	a1,a1,a5
    800028c2:	855e                	mv	a0,s7
    800028c4:	ab9ff0ef          	jal	8000237c <bread>
    800028c8:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800028ca:	004b2503          	lw	a0,4(s6)
    800028ce:	84d6                	mv	s1,s5
    800028d0:	4701                	li	a4,0
    800028d2:	fca4fae3          	bgeu	s1,a0,800028a6 <balloc+0x8a>
      m = 1 << (bi % 8);
    800028d6:	00777693          	andi	a3,a4,7
    800028da:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800028de:	41f7579b          	sraiw	a5,a4,0x1f
    800028e2:	01d7d79b          	srliw	a5,a5,0x1d
    800028e6:	9fb9                	addw	a5,a5,a4
    800028e8:	4037d79b          	sraiw	a5,a5,0x3
    800028ec:	00f90633          	add	a2,s2,a5
    800028f0:	06064603          	lbu	a2,96(a2)
    800028f4:	00c6f5b3          	and	a1,a3,a2
    800028f8:	ddb1                	beqz	a1,80002854 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800028fa:	2705                	addiw	a4,a4,1
    800028fc:	2485                	addiw	s1,s1,1
    800028fe:	fd471ae3          	bne	a4,s4,800028d2 <balloc+0xb6>
    80002902:	b755                	j	800028a6 <balloc+0x8a>
    80002904:	7942                	ld	s2,48(sp)
    80002906:	79a2                	ld	s3,40(sp)
    80002908:	7a02                	ld	s4,32(sp)
    8000290a:	6ae2                	ld	s5,24(sp)
    8000290c:	6b42                	ld	s6,16(sp)
    8000290e:	6ba2                	ld	s7,8(sp)
    80002910:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    80002912:	00006517          	auipc	a0,0x6
    80002916:	b4e50513          	addi	a0,a0,-1202 # 80008460 <etext+0x460>
    8000291a:	258030ef          	jal	80005b72 <printf>
  return 0;
    8000291e:	4481                	li	s1,0
    80002920:	bfad                	j	8000289a <balloc+0x7e>

0000000080002922 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002922:	7179                	addi	sp,sp,-48
    80002924:	f406                	sd	ra,40(sp)
    80002926:	f022                	sd	s0,32(sp)
    80002928:	ec26                	sd	s1,24(sp)
    8000292a:	e84a                	sd	s2,16(sp)
    8000292c:	e44e                	sd	s3,8(sp)
    8000292e:	1800                	addi	s0,sp,48
    80002930:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002932:	47ad                	li	a5,11
    80002934:	02b7e363          	bltu	a5,a1,8000295a <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80002938:	02059793          	slli	a5,a1,0x20
    8000293c:	01e7d593          	srli	a1,a5,0x1e
    80002940:	00b509b3          	add	s3,a0,a1
    80002944:	0589a483          	lw	s1,88(s3)
    80002948:	e0b5                	bnez	s1,800029ac <bmap+0x8a>
      addr = balloc(ip->dev);
    8000294a:	4108                	lw	a0,0(a0)
    8000294c:	ed1ff0ef          	jal	8000281c <balloc>
    80002950:	84aa                	mv	s1,a0
      if(addr == 0)
    80002952:	cd29                	beqz	a0,800029ac <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002954:	04a9ac23          	sw	a0,88(s3)
    80002958:	a891                	j	800029ac <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    8000295a:	ff45879b          	addiw	a5,a1,-12
    8000295e:	873e                	mv	a4,a5
    80002960:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80002962:	0ff00793          	li	a5,255
    80002966:	06e7e763          	bltu	a5,a4,800029d4 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000296a:	08852483          	lw	s1,136(a0)
    8000296e:	e891                	bnez	s1,80002982 <bmap+0x60>
      addr = balloc(ip->dev);
    80002970:	4108                	lw	a0,0(a0)
    80002972:	eabff0ef          	jal	8000281c <balloc>
    80002976:	84aa                	mv	s1,a0
      if(addr == 0)
    80002978:	c915                	beqz	a0,800029ac <bmap+0x8a>
    8000297a:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000297c:	08a92423          	sw	a0,136(s2)
    80002980:	a011                	j	80002984 <bmap+0x62>
    80002982:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002984:	85a6                	mv	a1,s1
    80002986:	00092503          	lw	a0,0(s2)
    8000298a:	9f3ff0ef          	jal	8000237c <bread>
    8000298e:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002990:	06050793          	addi	a5,a0,96
    if((addr = a[bn]) == 0){
    80002994:	02099713          	slli	a4,s3,0x20
    80002998:	01e75593          	srli	a1,a4,0x1e
    8000299c:	97ae                	add	a5,a5,a1
    8000299e:	89be                	mv	s3,a5
    800029a0:	4384                	lw	s1,0(a5)
    800029a2:	cc89                	beqz	s1,800029bc <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    800029a4:	8552                	mv	a0,s4
    800029a6:	c79ff0ef          	jal	8000261e <brelse>
    return addr;
    800029aa:	6a02                	ld	s4,0(sp)
  }
  panic("bmap: out of range");
}
    800029ac:	8526                	mv	a0,s1
    800029ae:	70a2                	ld	ra,40(sp)
    800029b0:	7402                	ld	s0,32(sp)
    800029b2:	64e2                	ld	s1,24(sp)
    800029b4:	6942                	ld	s2,16(sp)
    800029b6:	69a2                	ld	s3,8(sp)
    800029b8:	6145                	addi	sp,sp,48
    800029ba:	8082                	ret
      addr = balloc(ip->dev);
    800029bc:	00092503          	lw	a0,0(s2)
    800029c0:	e5dff0ef          	jal	8000281c <balloc>
    800029c4:	84aa                	mv	s1,a0
      if(addr){
    800029c6:	dd79                	beqz	a0,800029a4 <bmap+0x82>
        a[bn] = addr;
    800029c8:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    800029cc:	8552                	mv	a0,s4
    800029ce:	54f000ef          	jal	8000371c <log_write>
    800029d2:	bfc9                	j	800029a4 <bmap+0x82>
    800029d4:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800029d6:	00006517          	auipc	a0,0x6
    800029da:	aa250513          	addi	a0,a0,-1374 # 80008478 <etext+0x478>
    800029de:	4a4030ef          	jal	80005e82 <panic>

00000000800029e2 <iget>:
{
    800029e2:	7179                	addi	sp,sp,-48
    800029e4:	f406                	sd	ra,40(sp)
    800029e6:	f022                	sd	s0,32(sp)
    800029e8:	ec26                	sd	s1,24(sp)
    800029ea:	e84a                	sd	s2,16(sp)
    800029ec:	e44e                	sd	s3,8(sp)
    800029ee:	e052                	sd	s4,0(sp)
    800029f0:	1800                	addi	s0,sp,48
    800029f2:	892a                	mv	s2,a0
    800029f4:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800029f6:	00016517          	auipc	a0,0x16
    800029fa:	c0250513          	addi	a0,a0,-1022 # 800185f8 <itable>
    800029fe:	7a8030ef          	jal	800061a6 <acquire>
  empty = 0;
    80002a02:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002a04:	00016497          	auipc	s1,0x16
    80002a08:	c1448493          	addi	s1,s1,-1004 # 80018618 <itable+0x20>
    80002a0c:	00018697          	auipc	a3,0x18
    80002a10:	82c68693          	addi	a3,a3,-2004 # 8001a238 <log>
    80002a14:	a809                	j	80002a26 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002a16:	e781                	bnez	a5,80002a1e <iget+0x3c>
    80002a18:	00099363          	bnez	s3,80002a1e <iget+0x3c>
      empty = ip;
    80002a1c:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002a1e:	09048493          	addi	s1,s1,144
    80002a22:	02d48563          	beq	s1,a3,80002a4c <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80002a26:	449c                	lw	a5,8(s1)
    80002a28:	fef057e3          	blez	a5,80002a16 <iget+0x34>
    80002a2c:	4098                	lw	a4,0(s1)
    80002a2e:	ff2718e3          	bne	a4,s2,80002a1e <iget+0x3c>
    80002a32:	40d8                	lw	a4,4(s1)
    80002a34:	ff4715e3          	bne	a4,s4,80002a1e <iget+0x3c>
      ip->ref++;
    80002a38:	2785                	addiw	a5,a5,1
    80002a3a:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002a3c:	00016517          	auipc	a0,0x16
    80002a40:	bbc50513          	addi	a0,a0,-1092 # 800185f8 <itable>
    80002a44:	00b030ef          	jal	8000624e <release>
      return ip;
    80002a48:	89a6                	mv	s3,s1
    80002a4a:	a015                	j	80002a6e <iget+0x8c>
  if(empty == 0)
    80002a4c:	02098a63          	beqz	s3,80002a80 <iget+0x9e>
  ip->dev = dev;
    80002a50:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    80002a54:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80002a58:	4785                	li	a5,1
    80002a5a:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    80002a5e:	0409a423          	sw	zero,72(s3)
  release(&itable.lock);
    80002a62:	00016517          	auipc	a0,0x16
    80002a66:	b9650513          	addi	a0,a0,-1130 # 800185f8 <itable>
    80002a6a:	7e4030ef          	jal	8000624e <release>
}
    80002a6e:	854e                	mv	a0,s3
    80002a70:	70a2                	ld	ra,40(sp)
    80002a72:	7402                	ld	s0,32(sp)
    80002a74:	64e2                	ld	s1,24(sp)
    80002a76:	6942                	ld	s2,16(sp)
    80002a78:	69a2                	ld	s3,8(sp)
    80002a7a:	6a02                	ld	s4,0(sp)
    80002a7c:	6145                	addi	sp,sp,48
    80002a7e:	8082                	ret
    panic("iget: no inodes");
    80002a80:	00006517          	auipc	a0,0x6
    80002a84:	a1050513          	addi	a0,a0,-1520 # 80008490 <etext+0x490>
    80002a88:	3fa030ef          	jal	80005e82 <panic>

0000000080002a8c <fsinit>:
fsinit(int dev) {
    80002a8c:	1101                	addi	sp,sp,-32
    80002a8e:	ec06                	sd	ra,24(sp)
    80002a90:	e822                	sd	s0,16(sp)
    80002a92:	e426                	sd	s1,8(sp)
    80002a94:	e04a                	sd	s2,0(sp)
    80002a96:	1000                	addi	s0,sp,32
    80002a98:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002a9a:	4585                	li	a1,1
    80002a9c:	8e1ff0ef          	jal	8000237c <bread>
    80002aa0:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002aa2:	02000613          	li	a2,32
    80002aa6:	06050593          	addi	a1,a0,96
    80002aaa:	00016517          	auipc	a0,0x16
    80002aae:	b2e50513          	addi	a0,a0,-1234 # 800185d8 <sb>
    80002ab2:	a87fd0ef          	jal	80000538 <memmove>
  brelse(bp);
    80002ab6:	8526                	mv	a0,s1
    80002ab8:	b67ff0ef          	jal	8000261e <brelse>
  if(sb.magic != FSMAGIC)
    80002abc:	00016717          	auipc	a4,0x16
    80002ac0:	b1c72703          	lw	a4,-1252(a4) # 800185d8 <sb>
    80002ac4:	102037b7          	lui	a5,0x10203
    80002ac8:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002acc:	00f71f63          	bne	a4,a5,80002aea <fsinit+0x5e>
  initlog(dev, &sb);
    80002ad0:	00016597          	auipc	a1,0x16
    80002ad4:	b0858593          	addi	a1,a1,-1272 # 800185d8 <sb>
    80002ad8:	854a                	mv	a0,s2
    80002ada:	225000ef          	jal	800034fe <initlog>
}
    80002ade:	60e2                	ld	ra,24(sp)
    80002ae0:	6442                	ld	s0,16(sp)
    80002ae2:	64a2                	ld	s1,8(sp)
    80002ae4:	6902                	ld	s2,0(sp)
    80002ae6:	6105                	addi	sp,sp,32
    80002ae8:	8082                	ret
    panic("invalid file system");
    80002aea:	00006517          	auipc	a0,0x6
    80002aee:	9b650513          	addi	a0,a0,-1610 # 800084a0 <etext+0x4a0>
    80002af2:	390030ef          	jal	80005e82 <panic>

0000000080002af6 <iinit>:
{
    80002af6:	7179                	addi	sp,sp,-48
    80002af8:	f406                	sd	ra,40(sp)
    80002afa:	f022                	sd	s0,32(sp)
    80002afc:	ec26                	sd	s1,24(sp)
    80002afe:	e84a                	sd	s2,16(sp)
    80002b00:	e44e                	sd	s3,8(sp)
    80002b02:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80002b04:	00006597          	auipc	a1,0x6
    80002b08:	9b458593          	addi	a1,a1,-1612 # 800084b8 <etext+0x4b8>
    80002b0c:	00016517          	auipc	a0,0x16
    80002b10:	aec50513          	addi	a0,a0,-1300 # 800185f8 <itable>
    80002b14:	7d2030ef          	jal	800062e6 <initlock>
  for(i = 0; i < NINODE; i++) {
    80002b18:	00016497          	auipc	s1,0x16
    80002b1c:	b1048493          	addi	s1,s1,-1264 # 80018628 <itable+0x30>
    80002b20:	00017997          	auipc	s3,0x17
    80002b24:	72898993          	addi	s3,s3,1832 # 8001a248 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80002b28:	00006917          	auipc	s2,0x6
    80002b2c:	99890913          	addi	s2,s2,-1640 # 800084c0 <etext+0x4c0>
    80002b30:	85ca                	mv	a1,s2
    80002b32:	8526                	mv	a0,s1
    80002b34:	4bb000ef          	jal	800037ee <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80002b38:	09048493          	addi	s1,s1,144
    80002b3c:	ff349ae3          	bne	s1,s3,80002b30 <iinit+0x3a>
}
    80002b40:	70a2                	ld	ra,40(sp)
    80002b42:	7402                	ld	s0,32(sp)
    80002b44:	64e2                	ld	s1,24(sp)
    80002b46:	6942                	ld	s2,16(sp)
    80002b48:	69a2                	ld	s3,8(sp)
    80002b4a:	6145                	addi	sp,sp,48
    80002b4c:	8082                	ret

0000000080002b4e <ialloc>:
{
    80002b4e:	7139                	addi	sp,sp,-64
    80002b50:	fc06                	sd	ra,56(sp)
    80002b52:	f822                	sd	s0,48(sp)
    80002b54:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80002b56:	00016717          	auipc	a4,0x16
    80002b5a:	a8e72703          	lw	a4,-1394(a4) # 800185e4 <sb+0xc>
    80002b5e:	4785                	li	a5,1
    80002b60:	06e7f063          	bgeu	a5,a4,80002bc0 <ialloc+0x72>
    80002b64:	f426                	sd	s1,40(sp)
    80002b66:	f04a                	sd	s2,32(sp)
    80002b68:	ec4e                	sd	s3,24(sp)
    80002b6a:	e852                	sd	s4,16(sp)
    80002b6c:	e456                	sd	s5,8(sp)
    80002b6e:	e05a                	sd	s6,0(sp)
    80002b70:	8aaa                	mv	s5,a0
    80002b72:	8b2e                	mv	s6,a1
    80002b74:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80002b76:	00016a17          	auipc	s4,0x16
    80002b7a:	a62a0a13          	addi	s4,s4,-1438 # 800185d8 <sb>
    80002b7e:	00495593          	srli	a1,s2,0x4
    80002b82:	018a2783          	lw	a5,24(s4)
    80002b86:	9dbd                	addw	a1,a1,a5
    80002b88:	8556                	mv	a0,s5
    80002b8a:	ff2ff0ef          	jal	8000237c <bread>
    80002b8e:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80002b90:	06050993          	addi	s3,a0,96
    80002b94:	00f97793          	andi	a5,s2,15
    80002b98:	079a                	slli	a5,a5,0x6
    80002b9a:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002b9c:	00099783          	lh	a5,0(s3)
    80002ba0:	cb9d                	beqz	a5,80002bd6 <ialloc+0x88>
    brelse(bp);
    80002ba2:	a7dff0ef          	jal	8000261e <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80002ba6:	0905                	addi	s2,s2,1
    80002ba8:	00ca2703          	lw	a4,12(s4)
    80002bac:	0009079b          	sext.w	a5,s2
    80002bb0:	fce7e7e3          	bltu	a5,a4,80002b7e <ialloc+0x30>
    80002bb4:	74a2                	ld	s1,40(sp)
    80002bb6:	7902                	ld	s2,32(sp)
    80002bb8:	69e2                	ld	s3,24(sp)
    80002bba:	6a42                	ld	s4,16(sp)
    80002bbc:	6aa2                	ld	s5,8(sp)
    80002bbe:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80002bc0:	00006517          	auipc	a0,0x6
    80002bc4:	90850513          	addi	a0,a0,-1784 # 800084c8 <etext+0x4c8>
    80002bc8:	7ab020ef          	jal	80005b72 <printf>
  return 0;
    80002bcc:	4501                	li	a0,0
}
    80002bce:	70e2                	ld	ra,56(sp)
    80002bd0:	7442                	ld	s0,48(sp)
    80002bd2:	6121                	addi	sp,sp,64
    80002bd4:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80002bd6:	04000613          	li	a2,64
    80002bda:	4581                	li	a1,0
    80002bdc:	854e                	mv	a0,s3
    80002bde:	8fbfd0ef          	jal	800004d8 <memset>
      dip->type = type;
    80002be2:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80002be6:	8526                	mv	a0,s1
    80002be8:	335000ef          	jal	8000371c <log_write>
      brelse(bp);
    80002bec:	8526                	mv	a0,s1
    80002bee:	a31ff0ef          	jal	8000261e <brelse>
      return iget(dev, inum);
    80002bf2:	0009059b          	sext.w	a1,s2
    80002bf6:	8556                	mv	a0,s5
    80002bf8:	debff0ef          	jal	800029e2 <iget>
    80002bfc:	74a2                	ld	s1,40(sp)
    80002bfe:	7902                	ld	s2,32(sp)
    80002c00:	69e2                	ld	s3,24(sp)
    80002c02:	6a42                	ld	s4,16(sp)
    80002c04:	6aa2                	ld	s5,8(sp)
    80002c06:	6b02                	ld	s6,0(sp)
    80002c08:	b7d9                	j	80002bce <ialloc+0x80>

0000000080002c0a <iupdate>:
{
    80002c0a:	1101                	addi	sp,sp,-32
    80002c0c:	ec06                	sd	ra,24(sp)
    80002c0e:	e822                	sd	s0,16(sp)
    80002c10:	e426                	sd	s1,8(sp)
    80002c12:	e04a                	sd	s2,0(sp)
    80002c14:	1000                	addi	s0,sp,32
    80002c16:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002c18:	415c                	lw	a5,4(a0)
    80002c1a:	0047d79b          	srliw	a5,a5,0x4
    80002c1e:	00016597          	auipc	a1,0x16
    80002c22:	9d25a583          	lw	a1,-1582(a1) # 800185f0 <sb+0x18>
    80002c26:	9dbd                	addw	a1,a1,a5
    80002c28:	4108                	lw	a0,0(a0)
    80002c2a:	f52ff0ef          	jal	8000237c <bread>
    80002c2e:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80002c30:	06050793          	addi	a5,a0,96
    80002c34:	40d8                	lw	a4,4(s1)
    80002c36:	8b3d                	andi	a4,a4,15
    80002c38:	071a                	slli	a4,a4,0x6
    80002c3a:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80002c3c:	04c49703          	lh	a4,76(s1)
    80002c40:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80002c44:	04e49703          	lh	a4,78(s1)
    80002c48:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80002c4c:	05049703          	lh	a4,80(s1)
    80002c50:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80002c54:	05249703          	lh	a4,82(s1)
    80002c58:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80002c5c:	48f8                	lw	a4,84(s1)
    80002c5e:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80002c60:	03400613          	li	a2,52
    80002c64:	05848593          	addi	a1,s1,88
    80002c68:	00c78513          	addi	a0,a5,12
    80002c6c:	8cdfd0ef          	jal	80000538 <memmove>
  log_write(bp);
    80002c70:	854a                	mv	a0,s2
    80002c72:	2ab000ef          	jal	8000371c <log_write>
  brelse(bp);
    80002c76:	854a                	mv	a0,s2
    80002c78:	9a7ff0ef          	jal	8000261e <brelse>
}
    80002c7c:	60e2                	ld	ra,24(sp)
    80002c7e:	6442                	ld	s0,16(sp)
    80002c80:	64a2                	ld	s1,8(sp)
    80002c82:	6902                	ld	s2,0(sp)
    80002c84:	6105                	addi	sp,sp,32
    80002c86:	8082                	ret

0000000080002c88 <idup>:
{
    80002c88:	1101                	addi	sp,sp,-32
    80002c8a:	ec06                	sd	ra,24(sp)
    80002c8c:	e822                	sd	s0,16(sp)
    80002c8e:	e426                	sd	s1,8(sp)
    80002c90:	1000                	addi	s0,sp,32
    80002c92:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002c94:	00016517          	auipc	a0,0x16
    80002c98:	96450513          	addi	a0,a0,-1692 # 800185f8 <itable>
    80002c9c:	50a030ef          	jal	800061a6 <acquire>
  ip->ref++;
    80002ca0:	449c                	lw	a5,8(s1)
    80002ca2:	2785                	addiw	a5,a5,1
    80002ca4:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002ca6:	00016517          	auipc	a0,0x16
    80002caa:	95250513          	addi	a0,a0,-1710 # 800185f8 <itable>
    80002cae:	5a0030ef          	jal	8000624e <release>
}
    80002cb2:	8526                	mv	a0,s1
    80002cb4:	60e2                	ld	ra,24(sp)
    80002cb6:	6442                	ld	s0,16(sp)
    80002cb8:	64a2                	ld	s1,8(sp)
    80002cba:	6105                	addi	sp,sp,32
    80002cbc:	8082                	ret

0000000080002cbe <ilock>:
{
    80002cbe:	1101                	addi	sp,sp,-32
    80002cc0:	ec06                	sd	ra,24(sp)
    80002cc2:	e822                	sd	s0,16(sp)
    80002cc4:	e426                	sd	s1,8(sp)
    80002cc6:	1000                	addi	s0,sp,32
  if(ip == 0 || atomic_read4(&ip->ref) < 1)
    80002cc8:	c115                	beqz	a0,80002cec <ilock+0x2e>
    80002cca:	84aa                	mv	s1,a0
    80002ccc:	0521                	addi	a0,a0,8
    80002cce:	68c030ef          	jal	8000635a <atomic_read4>
    80002cd2:	00a05d63          	blez	a0,80002cec <ilock+0x2e>
  acquiresleep(&ip->lock);
    80002cd6:	01048513          	addi	a0,s1,16
    80002cda:	34b000ef          	jal	80003824 <acquiresleep>
  if(ip->valid == 0){
    80002cde:	44bc                	lw	a5,72(s1)
    80002ce0:	cf89                	beqz	a5,80002cfa <ilock+0x3c>
}
    80002ce2:	60e2                	ld	ra,24(sp)
    80002ce4:	6442                	ld	s0,16(sp)
    80002ce6:	64a2                	ld	s1,8(sp)
    80002ce8:	6105                	addi	sp,sp,32
    80002cea:	8082                	ret
    80002cec:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80002cee:	00005517          	auipc	a0,0x5
    80002cf2:	7f250513          	addi	a0,a0,2034 # 800084e0 <etext+0x4e0>
    80002cf6:	18c030ef          	jal	80005e82 <panic>
    80002cfa:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002cfc:	40dc                	lw	a5,4(s1)
    80002cfe:	0047d79b          	srliw	a5,a5,0x4
    80002d02:	00016597          	auipc	a1,0x16
    80002d06:	8ee5a583          	lw	a1,-1810(a1) # 800185f0 <sb+0x18>
    80002d0a:	9dbd                	addw	a1,a1,a5
    80002d0c:	4088                	lw	a0,0(s1)
    80002d0e:	e6eff0ef          	jal	8000237c <bread>
    80002d12:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80002d14:	06050593          	addi	a1,a0,96
    80002d18:	40dc                	lw	a5,4(s1)
    80002d1a:	8bbd                	andi	a5,a5,15
    80002d1c:	079a                	slli	a5,a5,0x6
    80002d1e:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80002d20:	00059783          	lh	a5,0(a1)
    80002d24:	04f49623          	sh	a5,76(s1)
    ip->major = dip->major;
    80002d28:	00259783          	lh	a5,2(a1)
    80002d2c:	04f49723          	sh	a5,78(s1)
    ip->minor = dip->minor;
    80002d30:	00459783          	lh	a5,4(a1)
    80002d34:	04f49823          	sh	a5,80(s1)
    ip->nlink = dip->nlink;
    80002d38:	00659783          	lh	a5,6(a1)
    80002d3c:	04f49923          	sh	a5,82(s1)
    ip->size = dip->size;
    80002d40:	459c                	lw	a5,8(a1)
    80002d42:	c8fc                	sw	a5,84(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80002d44:	03400613          	li	a2,52
    80002d48:	05b1                	addi	a1,a1,12
    80002d4a:	05848513          	addi	a0,s1,88
    80002d4e:	feafd0ef          	jal	80000538 <memmove>
    brelse(bp);
    80002d52:	854a                	mv	a0,s2
    80002d54:	8cbff0ef          	jal	8000261e <brelse>
    ip->valid = 1;
    80002d58:	4785                	li	a5,1
    80002d5a:	c4bc                	sw	a5,72(s1)
    if(ip->type == 0)
    80002d5c:	04c49783          	lh	a5,76(s1)
    80002d60:	c399                	beqz	a5,80002d66 <ilock+0xa8>
    80002d62:	6902                	ld	s2,0(sp)
    80002d64:	bfbd                	j	80002ce2 <ilock+0x24>
      panic("ilock: no type");
    80002d66:	00005517          	auipc	a0,0x5
    80002d6a:	78250513          	addi	a0,a0,1922 # 800084e8 <etext+0x4e8>
    80002d6e:	114030ef          	jal	80005e82 <panic>

0000000080002d72 <iunlock>:
{
    80002d72:	1101                	addi	sp,sp,-32
    80002d74:	ec06                	sd	ra,24(sp)
    80002d76:	e822                	sd	s0,16(sp)
    80002d78:	e426                	sd	s1,8(sp)
    80002d7a:	e04a                	sd	s2,0(sp)
    80002d7c:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || atomic_read4(&ip->ref) < 1)
    80002d7e:	c51d                	beqz	a0,80002dac <iunlock+0x3a>
    80002d80:	84aa                	mv	s1,a0
    80002d82:	01050913          	addi	s2,a0,16
    80002d86:	854a                	mv	a0,s2
    80002d88:	31b000ef          	jal	800038a2 <holdingsleep>
    80002d8c:	c105                	beqz	a0,80002dac <iunlock+0x3a>
    80002d8e:	00848513          	addi	a0,s1,8
    80002d92:	5c8030ef          	jal	8000635a <atomic_read4>
    80002d96:	00a05b63          	blez	a0,80002dac <iunlock+0x3a>
  releasesleep(&ip->lock);
    80002d9a:	854a                	mv	a0,s2
    80002d9c:	2cf000ef          	jal	8000386a <releasesleep>
}
    80002da0:	60e2                	ld	ra,24(sp)
    80002da2:	6442                	ld	s0,16(sp)
    80002da4:	64a2                	ld	s1,8(sp)
    80002da6:	6902                	ld	s2,0(sp)
    80002da8:	6105                	addi	sp,sp,32
    80002daa:	8082                	ret
    panic("iunlock");
    80002dac:	00005517          	auipc	a0,0x5
    80002db0:	74c50513          	addi	a0,a0,1868 # 800084f8 <etext+0x4f8>
    80002db4:	0ce030ef          	jal	80005e82 <panic>

0000000080002db8 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80002db8:	7179                	addi	sp,sp,-48
    80002dba:	f406                	sd	ra,40(sp)
    80002dbc:	f022                	sd	s0,32(sp)
    80002dbe:	ec26                	sd	s1,24(sp)
    80002dc0:	e84a                	sd	s2,16(sp)
    80002dc2:	e44e                	sd	s3,8(sp)
    80002dc4:	1800                	addi	s0,sp,48
    80002dc6:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80002dc8:	05850493          	addi	s1,a0,88
    80002dcc:	08850913          	addi	s2,a0,136
    80002dd0:	a021                	j	80002dd8 <itrunc+0x20>
    80002dd2:	0491                	addi	s1,s1,4
    80002dd4:	01248b63          	beq	s1,s2,80002dea <itrunc+0x32>
    if(ip->addrs[i]){
    80002dd8:	408c                	lw	a1,0(s1)
    80002dda:	dde5                	beqz	a1,80002dd2 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80002ddc:	0009a503          	lw	a0,0(s3)
    80002de0:	9d1ff0ef          	jal	800027b0 <bfree>
      ip->addrs[i] = 0;
    80002de4:	0004a023          	sw	zero,0(s1)
    80002de8:	b7ed                	j	80002dd2 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80002dea:	0889a583          	lw	a1,136(s3)
    80002dee:	ed89                	bnez	a1,80002e08 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }
  
  ip->size = 0;
    80002df0:	0409aa23          	sw	zero,84(s3)
  iupdate(ip);
    80002df4:	854e                	mv	a0,s3
    80002df6:	e15ff0ef          	jal	80002c0a <iupdate>
}
    80002dfa:	70a2                	ld	ra,40(sp)
    80002dfc:	7402                	ld	s0,32(sp)
    80002dfe:	64e2                	ld	s1,24(sp)
    80002e00:	6942                	ld	s2,16(sp)
    80002e02:	69a2                	ld	s3,8(sp)
    80002e04:	6145                	addi	sp,sp,48
    80002e06:	8082                	ret
    80002e08:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80002e0a:	0009a503          	lw	a0,0(s3)
    80002e0e:	d6eff0ef          	jal	8000237c <bread>
    80002e12:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80002e14:	06050493          	addi	s1,a0,96
    80002e18:	46050913          	addi	s2,a0,1120
    80002e1c:	a021                	j	80002e24 <itrunc+0x6c>
    80002e1e:	0491                	addi	s1,s1,4
    80002e20:	01248963          	beq	s1,s2,80002e32 <itrunc+0x7a>
      if(a[j])
    80002e24:	408c                	lw	a1,0(s1)
    80002e26:	dde5                	beqz	a1,80002e1e <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80002e28:	0009a503          	lw	a0,0(s3)
    80002e2c:	985ff0ef          	jal	800027b0 <bfree>
    80002e30:	b7fd                	j	80002e1e <itrunc+0x66>
    brelse(bp);
    80002e32:	8552                	mv	a0,s4
    80002e34:	feaff0ef          	jal	8000261e <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80002e38:	0889a583          	lw	a1,136(s3)
    80002e3c:	0009a503          	lw	a0,0(s3)
    80002e40:	971ff0ef          	jal	800027b0 <bfree>
    ip->addrs[NDIRECT] = 0;
    80002e44:	0809a423          	sw	zero,136(s3)
    80002e48:	6a02                	ld	s4,0(sp)
    80002e4a:	b75d                	j	80002df0 <itrunc+0x38>

0000000080002e4c <iput>:
{
    80002e4c:	1101                	addi	sp,sp,-32
    80002e4e:	ec06                	sd	ra,24(sp)
    80002e50:	e822                	sd	s0,16(sp)
    80002e52:	e426                	sd	s1,8(sp)
    80002e54:	1000                	addi	s0,sp,32
    80002e56:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002e58:	00015517          	auipc	a0,0x15
    80002e5c:	7a050513          	addi	a0,a0,1952 # 800185f8 <itable>
    80002e60:	346030ef          	jal	800061a6 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002e64:	4498                	lw	a4,8(s1)
    80002e66:	4785                	li	a5,1
    80002e68:	02f70063          	beq	a4,a5,80002e88 <iput+0x3c>
  ip->ref--;
    80002e6c:	449c                	lw	a5,8(s1)
    80002e6e:	37fd                	addiw	a5,a5,-1
    80002e70:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002e72:	00015517          	auipc	a0,0x15
    80002e76:	78650513          	addi	a0,a0,1926 # 800185f8 <itable>
    80002e7a:	3d4030ef          	jal	8000624e <release>
}
    80002e7e:	60e2                	ld	ra,24(sp)
    80002e80:	6442                	ld	s0,16(sp)
    80002e82:	64a2                	ld	s1,8(sp)
    80002e84:	6105                	addi	sp,sp,32
    80002e86:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002e88:	44bc                	lw	a5,72(s1)
    80002e8a:	d3ed                	beqz	a5,80002e6c <iput+0x20>
    80002e8c:	05249783          	lh	a5,82(s1)
    80002e90:	fff1                	bnez	a5,80002e6c <iput+0x20>
    80002e92:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80002e94:	01048793          	addi	a5,s1,16
    80002e98:	893e                	mv	s2,a5
    80002e9a:	853e                	mv	a0,a5
    80002e9c:	189000ef          	jal	80003824 <acquiresleep>
    release(&itable.lock);
    80002ea0:	00015517          	auipc	a0,0x15
    80002ea4:	75850513          	addi	a0,a0,1880 # 800185f8 <itable>
    80002ea8:	3a6030ef          	jal	8000624e <release>
    itrunc(ip);
    80002eac:	8526                	mv	a0,s1
    80002eae:	f0bff0ef          	jal	80002db8 <itrunc>
    ip->type = 0;
    80002eb2:	04049623          	sh	zero,76(s1)
    iupdate(ip);
    80002eb6:	8526                	mv	a0,s1
    80002eb8:	d53ff0ef          	jal	80002c0a <iupdate>
    ip->valid = 0;
    80002ebc:	0404a423          	sw	zero,72(s1)
    releasesleep(&ip->lock);
    80002ec0:	854a                	mv	a0,s2
    80002ec2:	1a9000ef          	jal	8000386a <releasesleep>
    acquire(&itable.lock);
    80002ec6:	00015517          	auipc	a0,0x15
    80002eca:	73250513          	addi	a0,a0,1842 # 800185f8 <itable>
    80002ece:	2d8030ef          	jal	800061a6 <acquire>
    80002ed2:	6902                	ld	s2,0(sp)
    80002ed4:	bf61                	j	80002e6c <iput+0x20>

0000000080002ed6 <iunlockput>:
{
    80002ed6:	1101                	addi	sp,sp,-32
    80002ed8:	ec06                	sd	ra,24(sp)
    80002eda:	e822                	sd	s0,16(sp)
    80002edc:	e426                	sd	s1,8(sp)
    80002ede:	1000                	addi	s0,sp,32
    80002ee0:	84aa                	mv	s1,a0
  iunlock(ip);
    80002ee2:	e91ff0ef          	jal	80002d72 <iunlock>
  iput(ip);
    80002ee6:	8526                	mv	a0,s1
    80002ee8:	f65ff0ef          	jal	80002e4c <iput>
}
    80002eec:	60e2                	ld	ra,24(sp)
    80002eee:	6442                	ld	s0,16(sp)
    80002ef0:	64a2                	ld	s1,8(sp)
    80002ef2:	6105                	addi	sp,sp,32
    80002ef4:	8082                	ret

0000000080002ef6 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002ef6:	1141                	addi	sp,sp,-16
    80002ef8:	e406                	sd	ra,8(sp)
    80002efa:	e022                	sd	s0,0(sp)
    80002efc:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80002efe:	411c                	lw	a5,0(a0)
    80002f00:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002f02:	415c                	lw	a5,4(a0)
    80002f04:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002f06:	04c51783          	lh	a5,76(a0)
    80002f0a:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80002f0e:	05251783          	lh	a5,82(a0)
    80002f12:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002f16:	05456783          	lwu	a5,84(a0)
    80002f1a:	e99c                	sd	a5,16(a1)
}
    80002f1c:	60a2                	ld	ra,8(sp)
    80002f1e:	6402                	ld	s0,0(sp)
    80002f20:	0141                	addi	sp,sp,16
    80002f22:	8082                	ret

0000000080002f24 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002f24:	497c                	lw	a5,84(a0)
    80002f26:	0ed7e663          	bltu	a5,a3,80003012 <readi+0xee>
{
    80002f2a:	7159                	addi	sp,sp,-112
    80002f2c:	f486                	sd	ra,104(sp)
    80002f2e:	f0a2                	sd	s0,96(sp)
    80002f30:	eca6                	sd	s1,88(sp)
    80002f32:	e0d2                	sd	s4,64(sp)
    80002f34:	fc56                	sd	s5,56(sp)
    80002f36:	f85a                	sd	s6,48(sp)
    80002f38:	f45e                	sd	s7,40(sp)
    80002f3a:	1880                	addi	s0,sp,112
    80002f3c:	8b2a                	mv	s6,a0
    80002f3e:	8bae                	mv	s7,a1
    80002f40:	8a32                	mv	s4,a2
    80002f42:	84b6                	mv	s1,a3
    80002f44:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80002f46:	9f35                	addw	a4,a4,a3
    return 0;
    80002f48:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002f4a:	0ad76b63          	bltu	a4,a3,80003000 <readi+0xdc>
    80002f4e:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80002f50:	00e7f463          	bgeu	a5,a4,80002f58 <readi+0x34>
    n = ip->size - off;
    80002f54:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002f58:	080a8b63          	beqz	s5,80002fee <readi+0xca>
    80002f5c:	e8ca                	sd	s2,80(sp)
    80002f5e:	f062                	sd	s8,32(sp)
    80002f60:	ec66                	sd	s9,24(sp)
    80002f62:	e86a                	sd	s10,16(sp)
    80002f64:	e46e                	sd	s11,8(sp)
    80002f66:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002f68:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002f6c:	5c7d                	li	s8,-1
    80002f6e:	a80d                	j	80002fa0 <readi+0x7c>
    80002f70:	020d1d93          	slli	s11,s10,0x20
    80002f74:	020ddd93          	srli	s11,s11,0x20
    80002f78:	06090613          	addi	a2,s2,96
    80002f7c:	86ee                	mv	a3,s11
    80002f7e:	963e                	add	a2,a2,a5
    80002f80:	85d2                	mv	a1,s4
    80002f82:	855e                	mv	a0,s7
    80002f84:	aadfe0ef          	jal	80001a30 <either_copyout>
    80002f88:	05850363          	beq	a0,s8,80002fce <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002f8c:	854a                	mv	a0,s2
    80002f8e:	e90ff0ef          	jal	8000261e <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002f92:	013d09bb          	addw	s3,s10,s3
    80002f96:	009d04bb          	addw	s1,s10,s1
    80002f9a:	9a6e                	add	s4,s4,s11
    80002f9c:	0559f363          	bgeu	s3,s5,80002fe2 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002fa0:	00a4d59b          	srliw	a1,s1,0xa
    80002fa4:	855a                	mv	a0,s6
    80002fa6:	97dff0ef          	jal	80002922 <bmap>
    80002faa:	85aa                	mv	a1,a0
    if(addr == 0)
    80002fac:	c139                	beqz	a0,80002ff2 <readi+0xce>
    bp = bread(ip->dev, addr);
    80002fae:	000b2503          	lw	a0,0(s6)
    80002fb2:	bcaff0ef          	jal	8000237c <bread>
    80002fb6:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002fb8:	3ff4f793          	andi	a5,s1,1023
    80002fbc:	40fc873b          	subw	a4,s9,a5
    80002fc0:	413a86bb          	subw	a3,s5,s3
    80002fc4:	8d3a                	mv	s10,a4
    80002fc6:	fae6f5e3          	bgeu	a3,a4,80002f70 <readi+0x4c>
    80002fca:	8d36                	mv	s10,a3
    80002fcc:	b755                	j	80002f70 <readi+0x4c>
      brelse(bp);
    80002fce:	854a                	mv	a0,s2
    80002fd0:	e4eff0ef          	jal	8000261e <brelse>
      tot = -1;
    80002fd4:	59fd                	li	s3,-1
      break;
    80002fd6:	6946                	ld	s2,80(sp)
    80002fd8:	7c02                	ld	s8,32(sp)
    80002fda:	6ce2                	ld	s9,24(sp)
    80002fdc:	6d42                	ld	s10,16(sp)
    80002fde:	6da2                	ld	s11,8(sp)
    80002fe0:	a831                	j	80002ffc <readi+0xd8>
    80002fe2:	6946                	ld	s2,80(sp)
    80002fe4:	7c02                	ld	s8,32(sp)
    80002fe6:	6ce2                	ld	s9,24(sp)
    80002fe8:	6d42                	ld	s10,16(sp)
    80002fea:	6da2                	ld	s11,8(sp)
    80002fec:	a801                	j	80002ffc <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002fee:	89d6                	mv	s3,s5
    80002ff0:	a031                	j	80002ffc <readi+0xd8>
    80002ff2:	6946                	ld	s2,80(sp)
    80002ff4:	7c02                	ld	s8,32(sp)
    80002ff6:	6ce2                	ld	s9,24(sp)
    80002ff8:	6d42                	ld	s10,16(sp)
    80002ffa:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80002ffc:	854e                	mv	a0,s3
    80002ffe:	69a6                	ld	s3,72(sp)
}
    80003000:	70a6                	ld	ra,104(sp)
    80003002:	7406                	ld	s0,96(sp)
    80003004:	64e6                	ld	s1,88(sp)
    80003006:	6a06                	ld	s4,64(sp)
    80003008:	7ae2                	ld	s5,56(sp)
    8000300a:	7b42                	ld	s6,48(sp)
    8000300c:	7ba2                	ld	s7,40(sp)
    8000300e:	6165                	addi	sp,sp,112
    80003010:	8082                	ret
    return 0;
    80003012:	4501                	li	a0,0
}
    80003014:	8082                	ret

0000000080003016 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003016:	497c                	lw	a5,84(a0)
    80003018:	0ed7eb63          	bltu	a5,a3,8000310e <writei+0xf8>
{
    8000301c:	7159                	addi	sp,sp,-112
    8000301e:	f486                	sd	ra,104(sp)
    80003020:	f0a2                	sd	s0,96(sp)
    80003022:	e8ca                	sd	s2,80(sp)
    80003024:	e0d2                	sd	s4,64(sp)
    80003026:	fc56                	sd	s5,56(sp)
    80003028:	f85a                	sd	s6,48(sp)
    8000302a:	f45e                	sd	s7,40(sp)
    8000302c:	1880                	addi	s0,sp,112
    8000302e:	8aaa                	mv	s5,a0
    80003030:	8bae                	mv	s7,a1
    80003032:	8a32                	mv	s4,a2
    80003034:	8936                	mv	s2,a3
    80003036:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003038:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    8000303c:	00043737          	lui	a4,0x43
    80003040:	0cf76963          	bltu	a4,a5,80003112 <writei+0xfc>
    80003044:	0cd7e763          	bltu	a5,a3,80003112 <writei+0xfc>
    80003048:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    8000304a:	0a0b0a63          	beqz	s6,800030fe <writei+0xe8>
    8000304e:	eca6                	sd	s1,88(sp)
    80003050:	f062                	sd	s8,32(sp)
    80003052:	ec66                	sd	s9,24(sp)
    80003054:	e86a                	sd	s10,16(sp)
    80003056:	e46e                	sd	s11,8(sp)
    80003058:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    8000305a:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000305e:	5c7d                	li	s8,-1
    80003060:	a825                	j	80003098 <writei+0x82>
    80003062:	020d1d93          	slli	s11,s10,0x20
    80003066:	020ddd93          	srli	s11,s11,0x20
    8000306a:	06048513          	addi	a0,s1,96
    8000306e:	86ee                	mv	a3,s11
    80003070:	8652                	mv	a2,s4
    80003072:	85de                	mv	a1,s7
    80003074:	953e                	add	a0,a0,a5
    80003076:	a05fe0ef          	jal	80001a7a <either_copyin>
    8000307a:	05850663          	beq	a0,s8,800030c6 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    8000307e:	8526                	mv	a0,s1
    80003080:	69c000ef          	jal	8000371c <log_write>
    brelse(bp);
    80003084:	8526                	mv	a0,s1
    80003086:	d98ff0ef          	jal	8000261e <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    8000308a:	013d09bb          	addw	s3,s10,s3
    8000308e:	012d093b          	addw	s2,s10,s2
    80003092:	9a6e                	add	s4,s4,s11
    80003094:	0369fc63          	bgeu	s3,s6,800030cc <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80003098:	00a9559b          	srliw	a1,s2,0xa
    8000309c:	8556                	mv	a0,s5
    8000309e:	885ff0ef          	jal	80002922 <bmap>
    800030a2:	85aa                	mv	a1,a0
    if(addr == 0)
    800030a4:	c505                	beqz	a0,800030cc <writei+0xb6>
    bp = bread(ip->dev, addr);
    800030a6:	000aa503          	lw	a0,0(s5)
    800030aa:	ad2ff0ef          	jal	8000237c <bread>
    800030ae:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800030b0:	3ff97793          	andi	a5,s2,1023
    800030b4:	40fc873b          	subw	a4,s9,a5
    800030b8:	413b06bb          	subw	a3,s6,s3
    800030bc:	8d3a                	mv	s10,a4
    800030be:	fae6f2e3          	bgeu	a3,a4,80003062 <writei+0x4c>
    800030c2:	8d36                	mv	s10,a3
    800030c4:	bf79                	j	80003062 <writei+0x4c>
      brelse(bp);
    800030c6:	8526                	mv	a0,s1
    800030c8:	d56ff0ef          	jal	8000261e <brelse>
  }

  if(off > ip->size)
    800030cc:	054aa783          	lw	a5,84(s5)
    800030d0:	0327f963          	bgeu	a5,s2,80003102 <writei+0xec>
    ip->size = off;
    800030d4:	052aaa23          	sw	s2,84(s5)
    800030d8:	64e6                	ld	s1,88(sp)
    800030da:	7c02                	ld	s8,32(sp)
    800030dc:	6ce2                	ld	s9,24(sp)
    800030de:	6d42                	ld	s10,16(sp)
    800030e0:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800030e2:	8556                	mv	a0,s5
    800030e4:	b27ff0ef          	jal	80002c0a <iupdate>

  return tot;
    800030e8:	854e                	mv	a0,s3
    800030ea:	69a6                	ld	s3,72(sp)
}
    800030ec:	70a6                	ld	ra,104(sp)
    800030ee:	7406                	ld	s0,96(sp)
    800030f0:	6946                	ld	s2,80(sp)
    800030f2:	6a06                	ld	s4,64(sp)
    800030f4:	7ae2                	ld	s5,56(sp)
    800030f6:	7b42                	ld	s6,48(sp)
    800030f8:	7ba2                	ld	s7,40(sp)
    800030fa:	6165                	addi	sp,sp,112
    800030fc:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800030fe:	89da                	mv	s3,s6
    80003100:	b7cd                	j	800030e2 <writei+0xcc>
    80003102:	64e6                	ld	s1,88(sp)
    80003104:	7c02                	ld	s8,32(sp)
    80003106:	6ce2                	ld	s9,24(sp)
    80003108:	6d42                	ld	s10,16(sp)
    8000310a:	6da2                	ld	s11,8(sp)
    8000310c:	bfd9                	j	800030e2 <writei+0xcc>
    return -1;
    8000310e:	557d                	li	a0,-1
}
    80003110:	8082                	ret
    return -1;
    80003112:	557d                	li	a0,-1
    80003114:	bfe1                	j	800030ec <writei+0xd6>

0000000080003116 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003116:	1141                	addi	sp,sp,-16
    80003118:	e406                	sd	ra,8(sp)
    8000311a:	e022                	sd	s0,0(sp)
    8000311c:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    8000311e:	4639                	li	a2,14
    80003120:	c8cfd0ef          	jal	800005ac <strncmp>
}
    80003124:	60a2                	ld	ra,8(sp)
    80003126:	6402                	ld	s0,0(sp)
    80003128:	0141                	addi	sp,sp,16
    8000312a:	8082                	ret

000000008000312c <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    8000312c:	711d                	addi	sp,sp,-96
    8000312e:	ec86                	sd	ra,88(sp)
    80003130:	e8a2                	sd	s0,80(sp)
    80003132:	e4a6                	sd	s1,72(sp)
    80003134:	e0ca                	sd	s2,64(sp)
    80003136:	fc4e                	sd	s3,56(sp)
    80003138:	f852                	sd	s4,48(sp)
    8000313a:	f456                	sd	s5,40(sp)
    8000313c:	f05a                	sd	s6,32(sp)
    8000313e:	ec5e                	sd	s7,24(sp)
    80003140:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003142:	04c51703          	lh	a4,76(a0)
    80003146:	4785                	li	a5,1
    80003148:	00f71f63          	bne	a4,a5,80003166 <dirlookup+0x3a>
    8000314c:	892a                	mv	s2,a0
    8000314e:	8aae                	mv	s5,a1
    80003150:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003152:	497c                	lw	a5,84(a0)
    80003154:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003156:	fa040a13          	addi	s4,s0,-96
    8000315a:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    8000315c:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003160:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003162:	e39d                	bnez	a5,80003188 <dirlookup+0x5c>
    80003164:	a8b9                	j	800031c2 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80003166:	00005517          	auipc	a0,0x5
    8000316a:	39a50513          	addi	a0,a0,922 # 80008500 <etext+0x500>
    8000316e:	515020ef          	jal	80005e82 <panic>
      panic("dirlookup read");
    80003172:	00005517          	auipc	a0,0x5
    80003176:	3a650513          	addi	a0,a0,934 # 80008518 <etext+0x518>
    8000317a:	509020ef          	jal	80005e82 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000317e:	24c1                	addiw	s1,s1,16
    80003180:	05492783          	lw	a5,84(s2)
    80003184:	02f4fe63          	bgeu	s1,a5,800031c0 <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003188:	874e                	mv	a4,s3
    8000318a:	86a6                	mv	a3,s1
    8000318c:	8652                	mv	a2,s4
    8000318e:	4581                	li	a1,0
    80003190:	854a                	mv	a0,s2
    80003192:	d93ff0ef          	jal	80002f24 <readi>
    80003196:	fd351ee3          	bne	a0,s3,80003172 <dirlookup+0x46>
    if(de.inum == 0)
    8000319a:	fa045783          	lhu	a5,-96(s0)
    8000319e:	d3e5                	beqz	a5,8000317e <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    800031a0:	85da                	mv	a1,s6
    800031a2:	8556                	mv	a0,s5
    800031a4:	f73ff0ef          	jal	80003116 <namecmp>
    800031a8:	f979                	bnez	a0,8000317e <dirlookup+0x52>
      if(poff)
    800031aa:	000b8463          	beqz	s7,800031b2 <dirlookup+0x86>
        *poff = off;
    800031ae:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    800031b2:	fa045583          	lhu	a1,-96(s0)
    800031b6:	00092503          	lw	a0,0(s2)
    800031ba:	829ff0ef          	jal	800029e2 <iget>
    800031be:	a011                	j	800031c2 <dirlookup+0x96>
  return 0;
    800031c0:	4501                	li	a0,0
}
    800031c2:	60e6                	ld	ra,88(sp)
    800031c4:	6446                	ld	s0,80(sp)
    800031c6:	64a6                	ld	s1,72(sp)
    800031c8:	6906                	ld	s2,64(sp)
    800031ca:	79e2                	ld	s3,56(sp)
    800031cc:	7a42                	ld	s4,48(sp)
    800031ce:	7aa2                	ld	s5,40(sp)
    800031d0:	7b02                	ld	s6,32(sp)
    800031d2:	6be2                	ld	s7,24(sp)
    800031d4:	6125                	addi	sp,sp,96
    800031d6:	8082                	ret

00000000800031d8 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    800031d8:	711d                	addi	sp,sp,-96
    800031da:	ec86                	sd	ra,88(sp)
    800031dc:	e8a2                	sd	s0,80(sp)
    800031de:	e4a6                	sd	s1,72(sp)
    800031e0:	e0ca                	sd	s2,64(sp)
    800031e2:	fc4e                	sd	s3,56(sp)
    800031e4:	f852                	sd	s4,48(sp)
    800031e6:	f456                	sd	s5,40(sp)
    800031e8:	f05a                	sd	s6,32(sp)
    800031ea:	ec5e                	sd	s7,24(sp)
    800031ec:	e862                	sd	s8,16(sp)
    800031ee:	e466                	sd	s9,8(sp)
    800031f0:	e06a                	sd	s10,0(sp)
    800031f2:	1080                	addi	s0,sp,96
    800031f4:	84aa                	mv	s1,a0
    800031f6:	8b2e                	mv	s6,a1
    800031f8:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    800031fa:	00054703          	lbu	a4,0(a0)
    800031fe:	02f00793          	li	a5,47
    80003202:	00f70f63          	beq	a4,a5,80003220 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003206:	efffd0ef          	jal	80001104 <myproc>
    8000320a:	15853503          	ld	a0,344(a0)
    8000320e:	a7bff0ef          	jal	80002c88 <idup>
    80003212:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003214:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80003218:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    8000321a:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    8000321c:	4b85                	li	s7,1
    8000321e:	a879                	j	800032bc <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80003220:	4585                	li	a1,1
    80003222:	852e                	mv	a0,a1
    80003224:	fbeff0ef          	jal	800029e2 <iget>
    80003228:	8a2a                	mv	s4,a0
    8000322a:	b7ed                	j	80003214 <namex+0x3c>
      iunlockput(ip);
    8000322c:	8552                	mv	a0,s4
    8000322e:	ca9ff0ef          	jal	80002ed6 <iunlockput>
      return 0;
    80003232:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003234:	8552                	mv	a0,s4
    80003236:	60e6                	ld	ra,88(sp)
    80003238:	6446                	ld	s0,80(sp)
    8000323a:	64a6                	ld	s1,72(sp)
    8000323c:	6906                	ld	s2,64(sp)
    8000323e:	79e2                	ld	s3,56(sp)
    80003240:	7a42                	ld	s4,48(sp)
    80003242:	7aa2                	ld	s5,40(sp)
    80003244:	7b02                	ld	s6,32(sp)
    80003246:	6be2                	ld	s7,24(sp)
    80003248:	6c42                	ld	s8,16(sp)
    8000324a:	6ca2                	ld	s9,8(sp)
    8000324c:	6d02                	ld	s10,0(sp)
    8000324e:	6125                	addi	sp,sp,96
    80003250:	8082                	ret
      iunlock(ip);
    80003252:	8552                	mv	a0,s4
    80003254:	b1fff0ef          	jal	80002d72 <iunlock>
      return ip;
    80003258:	bff1                	j	80003234 <namex+0x5c>
      iunlockput(ip);
    8000325a:	8552                	mv	a0,s4
    8000325c:	c7bff0ef          	jal	80002ed6 <iunlockput>
      return 0;
    80003260:	8a4a                	mv	s4,s2
    80003262:	bfc9                	j	80003234 <namex+0x5c>
  len = path - s;
    80003264:	40990633          	sub	a2,s2,s1
    80003268:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    8000326c:	09ac5463          	bge	s8,s10,800032f4 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80003270:	8666                	mv	a2,s9
    80003272:	85a6                	mv	a1,s1
    80003274:	8556                	mv	a0,s5
    80003276:	ac2fd0ef          	jal	80000538 <memmove>
    8000327a:	84ca                	mv	s1,s2
  while(*path == '/')
    8000327c:	0004c783          	lbu	a5,0(s1)
    80003280:	01379763          	bne	a5,s3,8000328e <namex+0xb6>
    path++;
    80003284:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003286:	0004c783          	lbu	a5,0(s1)
    8000328a:	ff378de3          	beq	a5,s3,80003284 <namex+0xac>
    ilock(ip);
    8000328e:	8552                	mv	a0,s4
    80003290:	a2fff0ef          	jal	80002cbe <ilock>
    if(ip->type != T_DIR){
    80003294:	04ca1783          	lh	a5,76(s4)
    80003298:	f9779ae3          	bne	a5,s7,8000322c <namex+0x54>
    if(nameiparent && *path == '\0'){
    8000329c:	000b0563          	beqz	s6,800032a6 <namex+0xce>
    800032a0:	0004c783          	lbu	a5,0(s1)
    800032a4:	d7dd                	beqz	a5,80003252 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    800032a6:	4601                	li	a2,0
    800032a8:	85d6                	mv	a1,s5
    800032aa:	8552                	mv	a0,s4
    800032ac:	e81ff0ef          	jal	8000312c <dirlookup>
    800032b0:	892a                	mv	s2,a0
    800032b2:	d545                	beqz	a0,8000325a <namex+0x82>
    iunlockput(ip);
    800032b4:	8552                	mv	a0,s4
    800032b6:	c21ff0ef          	jal	80002ed6 <iunlockput>
    ip = next;
    800032ba:	8a4a                	mv	s4,s2
  while(*path == '/')
    800032bc:	0004c783          	lbu	a5,0(s1)
    800032c0:	01379763          	bne	a5,s3,800032ce <namex+0xf6>
    path++;
    800032c4:	0485                	addi	s1,s1,1
  while(*path == '/')
    800032c6:	0004c783          	lbu	a5,0(s1)
    800032ca:	ff378de3          	beq	a5,s3,800032c4 <namex+0xec>
  if(*path == 0)
    800032ce:	cf8d                	beqz	a5,80003308 <namex+0x130>
  while(*path != '/' && *path != 0)
    800032d0:	0004c783          	lbu	a5,0(s1)
    800032d4:	fd178713          	addi	a4,a5,-47
    800032d8:	cb19                	beqz	a4,800032ee <namex+0x116>
    800032da:	cb91                	beqz	a5,800032ee <namex+0x116>
    800032dc:	8926                	mv	s2,s1
    path++;
    800032de:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    800032e0:	00094783          	lbu	a5,0(s2)
    800032e4:	fd178713          	addi	a4,a5,-47
    800032e8:	df35                	beqz	a4,80003264 <namex+0x8c>
    800032ea:	fbf5                	bnez	a5,800032de <namex+0x106>
    800032ec:	bfa5                	j	80003264 <namex+0x8c>
    800032ee:	8926                	mv	s2,s1
  len = path - s;
    800032f0:	4d01                	li	s10,0
    800032f2:	4601                	li	a2,0
    memmove(name, s, len);
    800032f4:	2601                	sext.w	a2,a2
    800032f6:	85a6                	mv	a1,s1
    800032f8:	8556                	mv	a0,s5
    800032fa:	a3efd0ef          	jal	80000538 <memmove>
    name[len] = 0;
    800032fe:	9d56                	add	s10,s10,s5
    80003300:	000d0023          	sb	zero,0(s10)
    80003304:	84ca                	mv	s1,s2
    80003306:	bf9d                	j	8000327c <namex+0xa4>
  if(nameiparent){
    80003308:	f20b06e3          	beqz	s6,80003234 <namex+0x5c>
    iput(ip);
    8000330c:	8552                	mv	a0,s4
    8000330e:	b3fff0ef          	jal	80002e4c <iput>
    return 0;
    80003312:	4a01                	li	s4,0
    80003314:	b705                	j	80003234 <namex+0x5c>

0000000080003316 <dirlink>:
{
    80003316:	715d                	addi	sp,sp,-80
    80003318:	e486                	sd	ra,72(sp)
    8000331a:	e0a2                	sd	s0,64(sp)
    8000331c:	f84a                	sd	s2,48(sp)
    8000331e:	ec56                	sd	s5,24(sp)
    80003320:	e85a                	sd	s6,16(sp)
    80003322:	0880                	addi	s0,sp,80
    80003324:	892a                	mv	s2,a0
    80003326:	8aae                	mv	s5,a1
    80003328:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    8000332a:	4601                	li	a2,0
    8000332c:	e01ff0ef          	jal	8000312c <dirlookup>
    80003330:	ed1d                	bnez	a0,8000336e <dirlink+0x58>
    80003332:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003334:	05492483          	lw	s1,84(s2)
    80003338:	c4b9                	beqz	s1,80003386 <dirlink+0x70>
    8000333a:	f44e                	sd	s3,40(sp)
    8000333c:	f052                	sd	s4,32(sp)
    8000333e:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003340:	fb040a13          	addi	s4,s0,-80
    80003344:	49c1                	li	s3,16
    80003346:	874e                	mv	a4,s3
    80003348:	86a6                	mv	a3,s1
    8000334a:	8652                	mv	a2,s4
    8000334c:	4581                	li	a1,0
    8000334e:	854a                	mv	a0,s2
    80003350:	bd5ff0ef          	jal	80002f24 <readi>
    80003354:	03351163          	bne	a0,s3,80003376 <dirlink+0x60>
    if(de.inum == 0)
    80003358:	fb045783          	lhu	a5,-80(s0)
    8000335c:	c39d                	beqz	a5,80003382 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000335e:	24c1                	addiw	s1,s1,16
    80003360:	05492783          	lw	a5,84(s2)
    80003364:	fef4e1e3          	bltu	s1,a5,80003346 <dirlink+0x30>
    80003368:	79a2                	ld	s3,40(sp)
    8000336a:	7a02                	ld	s4,32(sp)
    8000336c:	a829                	j	80003386 <dirlink+0x70>
    iput(ip);
    8000336e:	adfff0ef          	jal	80002e4c <iput>
    return -1;
    80003372:	557d                	li	a0,-1
    80003374:	a83d                	j	800033b2 <dirlink+0x9c>
      panic("dirlink read");
    80003376:	00005517          	auipc	a0,0x5
    8000337a:	1b250513          	addi	a0,a0,434 # 80008528 <etext+0x528>
    8000337e:	305020ef          	jal	80005e82 <panic>
    80003382:	79a2                	ld	s3,40(sp)
    80003384:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003386:	4639                	li	a2,14
    80003388:	85d6                	mv	a1,s5
    8000338a:	fb240513          	addi	a0,s0,-78
    8000338e:	a58fd0ef          	jal	800005e6 <strncpy>
  de.inum = inum;
    80003392:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003396:	4741                	li	a4,16
    80003398:	86a6                	mv	a3,s1
    8000339a:	fb040613          	addi	a2,s0,-80
    8000339e:	4581                	li	a1,0
    800033a0:	854a                	mv	a0,s2
    800033a2:	c75ff0ef          	jal	80003016 <writei>
    800033a6:	1541                	addi	a0,a0,-16
    800033a8:	00a03533          	snez	a0,a0
    800033ac:	40a0053b          	negw	a0,a0
    800033b0:	74e2                	ld	s1,56(sp)
}
    800033b2:	60a6                	ld	ra,72(sp)
    800033b4:	6406                	ld	s0,64(sp)
    800033b6:	7942                	ld	s2,48(sp)
    800033b8:	6ae2                	ld	s5,24(sp)
    800033ba:	6b42                	ld	s6,16(sp)
    800033bc:	6161                	addi	sp,sp,80
    800033be:	8082                	ret

00000000800033c0 <namei>:

struct inode*
namei(char *path)
{
    800033c0:	1101                	addi	sp,sp,-32
    800033c2:	ec06                	sd	ra,24(sp)
    800033c4:	e822                	sd	s0,16(sp)
    800033c6:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    800033c8:	fe040613          	addi	a2,s0,-32
    800033cc:	4581                	li	a1,0
    800033ce:	e0bff0ef          	jal	800031d8 <namex>
}
    800033d2:	60e2                	ld	ra,24(sp)
    800033d4:	6442                	ld	s0,16(sp)
    800033d6:	6105                	addi	sp,sp,32
    800033d8:	8082                	ret

00000000800033da <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    800033da:	1141                	addi	sp,sp,-16
    800033dc:	e406                	sd	ra,8(sp)
    800033de:	e022                	sd	s0,0(sp)
    800033e0:	0800                	addi	s0,sp,16
    800033e2:	862e                	mv	a2,a1
  return namex(path, 1, name);
    800033e4:	4585                	li	a1,1
    800033e6:	df3ff0ef          	jal	800031d8 <namex>
}
    800033ea:	60a2                	ld	ra,8(sp)
    800033ec:	6402                	ld	s0,0(sp)
    800033ee:	0141                	addi	sp,sp,16
    800033f0:	8082                	ret

00000000800033f2 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    800033f2:	1101                	addi	sp,sp,-32
    800033f4:	ec06                	sd	ra,24(sp)
    800033f6:	e822                	sd	s0,16(sp)
    800033f8:	e426                	sd	s1,8(sp)
    800033fa:	e04a                	sd	s2,0(sp)
    800033fc:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    800033fe:	00017917          	auipc	s2,0x17
    80003402:	e3a90913          	addi	s2,s2,-454 # 8001a238 <log>
    80003406:	02092583          	lw	a1,32(s2)
    8000340a:	03092503          	lw	a0,48(s2)
    8000340e:	f6ffe0ef          	jal	8000237c <bread>
    80003412:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003414:	03492603          	lw	a2,52(s2)
    80003418:	d130                	sw	a2,96(a0)
  for (i = 0; i < log.lh.n; i++) {
    8000341a:	00c05f63          	blez	a2,80003438 <write_head+0x46>
    8000341e:	00017717          	auipc	a4,0x17
    80003422:	e5270713          	addi	a4,a4,-430 # 8001a270 <log+0x38>
    80003426:	87aa                	mv	a5,a0
    80003428:	060a                	slli	a2,a2,0x2
    8000342a:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    8000342c:	4314                	lw	a3,0(a4)
    8000342e:	d3f4                	sw	a3,100(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003430:	0711                	addi	a4,a4,4
    80003432:	0791                	addi	a5,a5,4
    80003434:	fec79ce3          	bne	a5,a2,8000342c <write_head+0x3a>
  }
  bwrite(buf);
    80003438:	8526                	mv	a0,s1
    8000343a:	9b2ff0ef          	jal	800025ec <bwrite>
  brelse(buf);
    8000343e:	8526                	mv	a0,s1
    80003440:	9deff0ef          	jal	8000261e <brelse>
}
    80003444:	60e2                	ld	ra,24(sp)
    80003446:	6442                	ld	s0,16(sp)
    80003448:	64a2                	ld	s1,8(sp)
    8000344a:	6902                	ld	s2,0(sp)
    8000344c:	6105                	addi	sp,sp,32
    8000344e:	8082                	ret

0000000080003450 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003450:	00017797          	auipc	a5,0x17
    80003454:	e1c7a783          	lw	a5,-484(a5) # 8001a26c <log+0x34>
    80003458:	0af05263          	blez	a5,800034fc <install_trans+0xac>
{
    8000345c:	715d                	addi	sp,sp,-80
    8000345e:	e486                	sd	ra,72(sp)
    80003460:	e0a2                	sd	s0,64(sp)
    80003462:	fc26                	sd	s1,56(sp)
    80003464:	f84a                	sd	s2,48(sp)
    80003466:	f44e                	sd	s3,40(sp)
    80003468:	f052                	sd	s4,32(sp)
    8000346a:	ec56                	sd	s5,24(sp)
    8000346c:	e85a                	sd	s6,16(sp)
    8000346e:	e45e                	sd	s7,8(sp)
    80003470:	0880                	addi	s0,sp,80
    80003472:	8b2a                	mv	s6,a0
    80003474:	00017a97          	auipc	s5,0x17
    80003478:	dfca8a93          	addi	s5,s5,-516 # 8001a270 <log+0x38>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000347c:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000347e:	00017997          	auipc	s3,0x17
    80003482:	dba98993          	addi	s3,s3,-582 # 8001a238 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003486:	40000b93          	li	s7,1024
    8000348a:	a829                	j	800034a4 <install_trans+0x54>
    brelse(lbuf);
    8000348c:	854a                	mv	a0,s2
    8000348e:	990ff0ef          	jal	8000261e <brelse>
    brelse(dbuf);
    80003492:	8526                	mv	a0,s1
    80003494:	98aff0ef          	jal	8000261e <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003498:	2a05                	addiw	s4,s4,1
    8000349a:	0a91                	addi	s5,s5,4
    8000349c:	0349a783          	lw	a5,52(s3)
    800034a0:	04fa5363          	bge	s4,a5,800034e6 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800034a4:	0209a583          	lw	a1,32(s3)
    800034a8:	014585bb          	addw	a1,a1,s4
    800034ac:	2585                	addiw	a1,a1,1
    800034ae:	0309a503          	lw	a0,48(s3)
    800034b2:	ecbfe0ef          	jal	8000237c <bread>
    800034b6:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    800034b8:	000aa583          	lw	a1,0(s5)
    800034bc:	0309a503          	lw	a0,48(s3)
    800034c0:	ebdfe0ef          	jal	8000237c <bread>
    800034c4:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    800034c6:	865e                	mv	a2,s7
    800034c8:	06090593          	addi	a1,s2,96
    800034cc:	06050513          	addi	a0,a0,96
    800034d0:	868fd0ef          	jal	80000538 <memmove>
    bwrite(dbuf);  // write dst to disk
    800034d4:	8526                	mv	a0,s1
    800034d6:	916ff0ef          	jal	800025ec <bwrite>
    if(recovering == 0)
    800034da:	fa0b19e3          	bnez	s6,8000348c <install_trans+0x3c>
      bunpin(dbuf);
    800034de:	8526                	mv	a0,s1
    800034e0:	a66ff0ef          	jal	80002746 <bunpin>
    800034e4:	b765                	j	8000348c <install_trans+0x3c>
}
    800034e6:	60a6                	ld	ra,72(sp)
    800034e8:	6406                	ld	s0,64(sp)
    800034ea:	74e2                	ld	s1,56(sp)
    800034ec:	7942                	ld	s2,48(sp)
    800034ee:	79a2                	ld	s3,40(sp)
    800034f0:	7a02                	ld	s4,32(sp)
    800034f2:	6ae2                	ld	s5,24(sp)
    800034f4:	6b42                	ld	s6,16(sp)
    800034f6:	6ba2                	ld	s7,8(sp)
    800034f8:	6161                	addi	sp,sp,80
    800034fa:	8082                	ret
    800034fc:	8082                	ret

00000000800034fe <initlog>:
{
    800034fe:	7179                	addi	sp,sp,-48
    80003500:	f406                	sd	ra,40(sp)
    80003502:	f022                	sd	s0,32(sp)
    80003504:	ec26                	sd	s1,24(sp)
    80003506:	e84a                	sd	s2,16(sp)
    80003508:	e44e                	sd	s3,8(sp)
    8000350a:	1800                	addi	s0,sp,48
    8000350c:	892a                	mv	s2,a0
    8000350e:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003510:	00017497          	auipc	s1,0x17
    80003514:	d2848493          	addi	s1,s1,-728 # 8001a238 <log>
    80003518:	00005597          	auipc	a1,0x5
    8000351c:	02058593          	addi	a1,a1,32 # 80008538 <etext+0x538>
    80003520:	8526                	mv	a0,s1
    80003522:	5c5020ef          	jal	800062e6 <initlock>
  log.start = sb->logstart;
    80003526:	0149a583          	lw	a1,20(s3)
    8000352a:	d08c                	sw	a1,32(s1)
  log.size = sb->nlog;
    8000352c:	0109a783          	lw	a5,16(s3)
    80003530:	d0dc                	sw	a5,36(s1)
  log.dev = dev;
    80003532:	0324a823          	sw	s2,48(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003536:	854a                	mv	a0,s2
    80003538:	e45fe0ef          	jal	8000237c <bread>
  log.lh.n = lh->n;
    8000353c:	5130                	lw	a2,96(a0)
    8000353e:	d8d0                	sw	a2,52(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003540:	00c05f63          	blez	a2,8000355e <initlog+0x60>
    80003544:	87aa                	mv	a5,a0
    80003546:	00017717          	auipc	a4,0x17
    8000354a:	d2a70713          	addi	a4,a4,-726 # 8001a270 <log+0x38>
    8000354e:	060a                	slli	a2,a2,0x2
    80003550:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003552:	53f4                	lw	a3,100(a5)
    80003554:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003556:	0791                	addi	a5,a5,4
    80003558:	0711                	addi	a4,a4,4
    8000355a:	fec79ce3          	bne	a5,a2,80003552 <initlog+0x54>
  brelse(buf);
    8000355e:	8c0ff0ef          	jal	8000261e <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003562:	4505                	li	a0,1
    80003564:	eedff0ef          	jal	80003450 <install_trans>
  log.lh.n = 0;
    80003568:	00017797          	auipc	a5,0x17
    8000356c:	d007a223          	sw	zero,-764(a5) # 8001a26c <log+0x34>
  write_head(); // clear the log
    80003570:	e83ff0ef          	jal	800033f2 <write_head>
}
    80003574:	70a2                	ld	ra,40(sp)
    80003576:	7402                	ld	s0,32(sp)
    80003578:	64e2                	ld	s1,24(sp)
    8000357a:	6942                	ld	s2,16(sp)
    8000357c:	69a2                	ld	s3,8(sp)
    8000357e:	6145                	addi	sp,sp,48
    80003580:	8082                	ret

0000000080003582 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003582:	1101                	addi	sp,sp,-32
    80003584:	ec06                	sd	ra,24(sp)
    80003586:	e822                	sd	s0,16(sp)
    80003588:	e426                	sd	s1,8(sp)
    8000358a:	e04a                	sd	s2,0(sp)
    8000358c:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000358e:	00017517          	auipc	a0,0x17
    80003592:	caa50513          	addi	a0,a0,-854 # 8001a238 <log>
    80003596:	411020ef          	jal	800061a6 <acquire>
  while(1){
    if(log.committing){
    8000359a:	00017497          	auipc	s1,0x17
    8000359e:	c9e48493          	addi	s1,s1,-866 # 8001a238 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    800035a2:	4979                	li	s2,30
    800035a4:	a029                	j	800035ae <begin_op+0x2c>
      sleep(&log, &log.lock);
    800035a6:	85a6                	mv	a1,s1
    800035a8:	8526                	mv	a0,s1
    800035aa:	92cfe0ef          	jal	800016d6 <sleep>
    if(log.committing){
    800035ae:	54dc                	lw	a5,44(s1)
    800035b0:	fbfd                	bnez	a5,800035a6 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    800035b2:	5498                	lw	a4,40(s1)
    800035b4:	2705                	addiw	a4,a4,1
    800035b6:	0027179b          	slliw	a5,a4,0x2
    800035ba:	9fb9                	addw	a5,a5,a4
    800035bc:	0017979b          	slliw	a5,a5,0x1
    800035c0:	58d4                	lw	a3,52(s1)
    800035c2:	9fb5                	addw	a5,a5,a3
    800035c4:	00f95763          	bge	s2,a5,800035d2 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    800035c8:	85a6                	mv	a1,s1
    800035ca:	8526                	mv	a0,s1
    800035cc:	90afe0ef          	jal	800016d6 <sleep>
    800035d0:	bff9                	j	800035ae <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    800035d2:	00017797          	auipc	a5,0x17
    800035d6:	c8e7a723          	sw	a4,-882(a5) # 8001a260 <log+0x28>
      release(&log.lock);
    800035da:	00017517          	auipc	a0,0x17
    800035de:	c5e50513          	addi	a0,a0,-930 # 8001a238 <log>
    800035e2:	46d020ef          	jal	8000624e <release>
      break;
    }
  }
}
    800035e6:	60e2                	ld	ra,24(sp)
    800035e8:	6442                	ld	s0,16(sp)
    800035ea:	64a2                	ld	s1,8(sp)
    800035ec:	6902                	ld	s2,0(sp)
    800035ee:	6105                	addi	sp,sp,32
    800035f0:	8082                	ret

00000000800035f2 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    800035f2:	7139                	addi	sp,sp,-64
    800035f4:	fc06                	sd	ra,56(sp)
    800035f6:	f822                	sd	s0,48(sp)
    800035f8:	f426                	sd	s1,40(sp)
    800035fa:	f04a                	sd	s2,32(sp)
    800035fc:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    800035fe:	00017497          	auipc	s1,0x17
    80003602:	c3a48493          	addi	s1,s1,-966 # 8001a238 <log>
    80003606:	8526                	mv	a0,s1
    80003608:	39f020ef          	jal	800061a6 <acquire>
  log.outstanding -= 1;
    8000360c:	549c                	lw	a5,40(s1)
    8000360e:	37fd                	addiw	a5,a5,-1
    80003610:	893e                	mv	s2,a5
    80003612:	d49c                	sw	a5,40(s1)
  if(log.committing)
    80003614:	54dc                	lw	a5,44(s1)
    80003616:	e7b1                	bnez	a5,80003662 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80003618:	04091e63          	bnez	s2,80003674 <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    8000361c:	00017497          	auipc	s1,0x17
    80003620:	c1c48493          	addi	s1,s1,-996 # 8001a238 <log>
    80003624:	4785                	li	a5,1
    80003626:	d4dc                	sw	a5,44(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003628:	8526                	mv	a0,s1
    8000362a:	425020ef          	jal	8000624e <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    8000362e:	58dc                	lw	a5,52(s1)
    80003630:	06f04463          	bgtz	a5,80003698 <end_op+0xa6>
    acquire(&log.lock);
    80003634:	00017517          	auipc	a0,0x17
    80003638:	c0450513          	addi	a0,a0,-1020 # 8001a238 <log>
    8000363c:	36b020ef          	jal	800061a6 <acquire>
    log.committing = 0;
    80003640:	00017797          	auipc	a5,0x17
    80003644:	c207a223          	sw	zero,-988(a5) # 8001a264 <log+0x2c>
    wakeup(&log);
    80003648:	00017517          	auipc	a0,0x17
    8000364c:	bf050513          	addi	a0,a0,-1040 # 8001a238 <log>
    80003650:	8d2fe0ef          	jal	80001722 <wakeup>
    release(&log.lock);
    80003654:	00017517          	auipc	a0,0x17
    80003658:	be450513          	addi	a0,a0,-1052 # 8001a238 <log>
    8000365c:	3f3020ef          	jal	8000624e <release>
}
    80003660:	a035                	j	8000368c <end_op+0x9a>
    80003662:	ec4e                	sd	s3,24(sp)
    80003664:	e852                	sd	s4,16(sp)
    80003666:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003668:	00005517          	auipc	a0,0x5
    8000366c:	ed850513          	addi	a0,a0,-296 # 80008540 <etext+0x540>
    80003670:	013020ef          	jal	80005e82 <panic>
    wakeup(&log);
    80003674:	00017517          	auipc	a0,0x17
    80003678:	bc450513          	addi	a0,a0,-1084 # 8001a238 <log>
    8000367c:	8a6fe0ef          	jal	80001722 <wakeup>
  release(&log.lock);
    80003680:	00017517          	auipc	a0,0x17
    80003684:	bb850513          	addi	a0,a0,-1096 # 8001a238 <log>
    80003688:	3c7020ef          	jal	8000624e <release>
}
    8000368c:	70e2                	ld	ra,56(sp)
    8000368e:	7442                	ld	s0,48(sp)
    80003690:	74a2                	ld	s1,40(sp)
    80003692:	7902                	ld	s2,32(sp)
    80003694:	6121                	addi	sp,sp,64
    80003696:	8082                	ret
    80003698:	ec4e                	sd	s3,24(sp)
    8000369a:	e852                	sd	s4,16(sp)
    8000369c:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    8000369e:	00017a97          	auipc	s5,0x17
    800036a2:	bd2a8a93          	addi	s5,s5,-1070 # 8001a270 <log+0x38>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    800036a6:	00017a17          	auipc	s4,0x17
    800036aa:	b92a0a13          	addi	s4,s4,-1134 # 8001a238 <log>
    800036ae:	020a2583          	lw	a1,32(s4)
    800036b2:	012585bb          	addw	a1,a1,s2
    800036b6:	2585                	addiw	a1,a1,1
    800036b8:	030a2503          	lw	a0,48(s4)
    800036bc:	cc1fe0ef          	jal	8000237c <bread>
    800036c0:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    800036c2:	000aa583          	lw	a1,0(s5)
    800036c6:	030a2503          	lw	a0,48(s4)
    800036ca:	cb3fe0ef          	jal	8000237c <bread>
    800036ce:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    800036d0:	40000613          	li	a2,1024
    800036d4:	06050593          	addi	a1,a0,96
    800036d8:	06048513          	addi	a0,s1,96
    800036dc:	e5dfc0ef          	jal	80000538 <memmove>
    bwrite(to);  // write the log
    800036e0:	8526                	mv	a0,s1
    800036e2:	f0bfe0ef          	jal	800025ec <bwrite>
    brelse(from);
    800036e6:	854e                	mv	a0,s3
    800036e8:	f37fe0ef          	jal	8000261e <brelse>
    brelse(to);
    800036ec:	8526                	mv	a0,s1
    800036ee:	f31fe0ef          	jal	8000261e <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800036f2:	2905                	addiw	s2,s2,1
    800036f4:	0a91                	addi	s5,s5,4
    800036f6:	034a2783          	lw	a5,52(s4)
    800036fa:	faf94ae3          	blt	s2,a5,800036ae <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800036fe:	cf5ff0ef          	jal	800033f2 <write_head>
    install_trans(0); // Now install writes to home locations
    80003702:	4501                	li	a0,0
    80003704:	d4dff0ef          	jal	80003450 <install_trans>
    log.lh.n = 0;
    80003708:	00017797          	auipc	a5,0x17
    8000370c:	b607a223          	sw	zero,-1180(a5) # 8001a26c <log+0x34>
    write_head();    // Erase the transaction from the log
    80003710:	ce3ff0ef          	jal	800033f2 <write_head>
    80003714:	69e2                	ld	s3,24(sp)
    80003716:	6a42                	ld	s4,16(sp)
    80003718:	6aa2                	ld	s5,8(sp)
    8000371a:	bf29                	j	80003634 <end_op+0x42>

000000008000371c <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000371c:	1101                	addi	sp,sp,-32
    8000371e:	ec06                	sd	ra,24(sp)
    80003720:	e822                	sd	s0,16(sp)
    80003722:	e426                	sd	s1,8(sp)
    80003724:	1000                	addi	s0,sp,32
    80003726:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003728:	00017517          	auipc	a0,0x17
    8000372c:	b1050513          	addi	a0,a0,-1264 # 8001a238 <log>
    80003730:	277020ef          	jal	800061a6 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003734:	00017617          	auipc	a2,0x17
    80003738:	b3862603          	lw	a2,-1224(a2) # 8001a26c <log+0x34>
    8000373c:	47f5                	li	a5,29
    8000373e:	06c7c463          	blt	a5,a2,800037a6 <log_write+0x8a>
    80003742:	00017797          	auipc	a5,0x17
    80003746:	b1a7a783          	lw	a5,-1254(a5) # 8001a25c <log+0x24>
    8000374a:	37fd                	addiw	a5,a5,-1
    8000374c:	04f65d63          	bge	a2,a5,800037a6 <log_write+0x8a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003750:	00017797          	auipc	a5,0x17
    80003754:	b107a783          	lw	a5,-1264(a5) # 8001a260 <log+0x28>
    80003758:	04f05d63          	blez	a5,800037b2 <log_write+0x96>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    8000375c:	4781                	li	a5,0
    8000375e:	06c05063          	blez	a2,800037be <log_write+0xa2>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003762:	44cc                	lw	a1,12(s1)
    80003764:	00017717          	auipc	a4,0x17
    80003768:	b0c70713          	addi	a4,a4,-1268 # 8001a270 <log+0x38>
  for (i = 0; i < log.lh.n; i++) {
    8000376c:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000376e:	4314                	lw	a3,0(a4)
    80003770:	04b68763          	beq	a3,a1,800037be <log_write+0xa2>
  for (i = 0; i < log.lh.n; i++) {
    80003774:	2785                	addiw	a5,a5,1
    80003776:	0711                	addi	a4,a4,4
    80003778:	fef61be3          	bne	a2,a5,8000376e <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    8000377c:	060a                	slli	a2,a2,0x2
    8000377e:	03060613          	addi	a2,a2,48
    80003782:	00017797          	auipc	a5,0x17
    80003786:	ab678793          	addi	a5,a5,-1354 # 8001a238 <log>
    8000378a:	97b2                	add	a5,a5,a2
    8000378c:	44d8                	lw	a4,12(s1)
    8000378e:	c798                	sw	a4,8(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003790:	8526                	mv	a0,s1
    80003792:	f4bfe0ef          	jal	800026dc <bpin>
    log.lh.n++;
    80003796:	00017717          	auipc	a4,0x17
    8000379a:	aa270713          	addi	a4,a4,-1374 # 8001a238 <log>
    8000379e:	5b5c                	lw	a5,52(a4)
    800037a0:	2785                	addiw	a5,a5,1
    800037a2:	db5c                	sw	a5,52(a4)
    800037a4:	a815                	j	800037d8 <log_write+0xbc>
    panic("too big a transaction");
    800037a6:	00005517          	auipc	a0,0x5
    800037aa:	daa50513          	addi	a0,a0,-598 # 80008550 <etext+0x550>
    800037ae:	6d4020ef          	jal	80005e82 <panic>
    panic("log_write outside of trans");
    800037b2:	00005517          	auipc	a0,0x5
    800037b6:	db650513          	addi	a0,a0,-586 # 80008568 <etext+0x568>
    800037ba:	6c8020ef          	jal	80005e82 <panic>
  log.lh.block[i] = b->blockno;
    800037be:	00279693          	slli	a3,a5,0x2
    800037c2:	03068693          	addi	a3,a3,48
    800037c6:	00017717          	auipc	a4,0x17
    800037ca:	a7270713          	addi	a4,a4,-1422 # 8001a238 <log>
    800037ce:	9736                	add	a4,a4,a3
    800037d0:	44d4                	lw	a3,12(s1)
    800037d2:	c714                	sw	a3,8(a4)
  if (i == log.lh.n) {  // Add new block to log?
    800037d4:	faf60ee3          	beq	a2,a5,80003790 <log_write+0x74>
  }
  release(&log.lock);
    800037d8:	00017517          	auipc	a0,0x17
    800037dc:	a6050513          	addi	a0,a0,-1440 # 8001a238 <log>
    800037e0:	26f020ef          	jal	8000624e <release>
}
    800037e4:	60e2                	ld	ra,24(sp)
    800037e6:	6442                	ld	s0,16(sp)
    800037e8:	64a2                	ld	s1,8(sp)
    800037ea:	6105                	addi	sp,sp,32
    800037ec:	8082                	ret

00000000800037ee <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800037ee:	1101                	addi	sp,sp,-32
    800037f0:	ec06                	sd	ra,24(sp)
    800037f2:	e822                	sd	s0,16(sp)
    800037f4:	e426                	sd	s1,8(sp)
    800037f6:	e04a                	sd	s2,0(sp)
    800037f8:	1000                	addi	s0,sp,32
    800037fa:	84aa                	mv	s1,a0
    800037fc:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800037fe:	00005597          	auipc	a1,0x5
    80003802:	d8a58593          	addi	a1,a1,-630 # 80008588 <etext+0x588>
    80003806:	0521                	addi	a0,a0,8
    80003808:	2df020ef          	jal	800062e6 <initlock>
  lk->name = name;
    8000380c:	0324b423          	sd	s2,40(s1)
  lk->locked = 0;
    80003810:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003814:	0204a823          	sw	zero,48(s1)
}
    80003818:	60e2                	ld	ra,24(sp)
    8000381a:	6442                	ld	s0,16(sp)
    8000381c:	64a2                	ld	s1,8(sp)
    8000381e:	6902                	ld	s2,0(sp)
    80003820:	6105                	addi	sp,sp,32
    80003822:	8082                	ret

0000000080003824 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003824:	1101                	addi	sp,sp,-32
    80003826:	ec06                	sd	ra,24(sp)
    80003828:	e822                	sd	s0,16(sp)
    8000382a:	e426                	sd	s1,8(sp)
    8000382c:	e04a                	sd	s2,0(sp)
    8000382e:	1000                	addi	s0,sp,32
    80003830:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003832:	00850913          	addi	s2,a0,8
    80003836:	854a                	mv	a0,s2
    80003838:	16f020ef          	jal	800061a6 <acquire>
  while (lk->locked) {
    8000383c:	409c                	lw	a5,0(s1)
    8000383e:	c799                	beqz	a5,8000384c <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003840:	85ca                	mv	a1,s2
    80003842:	8526                	mv	a0,s1
    80003844:	e93fd0ef          	jal	800016d6 <sleep>
  while (lk->locked) {
    80003848:	409c                	lw	a5,0(s1)
    8000384a:	fbfd                	bnez	a5,80003840 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000384c:	4785                	li	a5,1
    8000384e:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003850:	8b5fd0ef          	jal	80001104 <myproc>
    80003854:	5d1c                	lw	a5,56(a0)
    80003856:	d89c                	sw	a5,48(s1)
  release(&lk->lk);
    80003858:	854a                	mv	a0,s2
    8000385a:	1f5020ef          	jal	8000624e <release>
}
    8000385e:	60e2                	ld	ra,24(sp)
    80003860:	6442                	ld	s0,16(sp)
    80003862:	64a2                	ld	s1,8(sp)
    80003864:	6902                	ld	s2,0(sp)
    80003866:	6105                	addi	sp,sp,32
    80003868:	8082                	ret

000000008000386a <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    8000386a:	1101                	addi	sp,sp,-32
    8000386c:	ec06                	sd	ra,24(sp)
    8000386e:	e822                	sd	s0,16(sp)
    80003870:	e426                	sd	s1,8(sp)
    80003872:	e04a                	sd	s2,0(sp)
    80003874:	1000                	addi	s0,sp,32
    80003876:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003878:	00850913          	addi	s2,a0,8
    8000387c:	854a                	mv	a0,s2
    8000387e:	129020ef          	jal	800061a6 <acquire>
  lk->locked = 0;
    80003882:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003886:	0204a823          	sw	zero,48(s1)
  wakeup(lk);
    8000388a:	8526                	mv	a0,s1
    8000388c:	e97fd0ef          	jal	80001722 <wakeup>
  release(&lk->lk);
    80003890:	854a                	mv	a0,s2
    80003892:	1bd020ef          	jal	8000624e <release>
}
    80003896:	60e2                	ld	ra,24(sp)
    80003898:	6442                	ld	s0,16(sp)
    8000389a:	64a2                	ld	s1,8(sp)
    8000389c:	6902                	ld	s2,0(sp)
    8000389e:	6105                	addi	sp,sp,32
    800038a0:	8082                	ret

00000000800038a2 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800038a2:	7179                	addi	sp,sp,-48
    800038a4:	f406                	sd	ra,40(sp)
    800038a6:	f022                	sd	s0,32(sp)
    800038a8:	ec26                	sd	s1,24(sp)
    800038aa:	e84a                	sd	s2,16(sp)
    800038ac:	1800                	addi	s0,sp,48
    800038ae:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    800038b0:	00850913          	addi	s2,a0,8
    800038b4:	854a                	mv	a0,s2
    800038b6:	0f1020ef          	jal	800061a6 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800038ba:	409c                	lw	a5,0(s1)
    800038bc:	ef81                	bnez	a5,800038d4 <holdingsleep+0x32>
    800038be:	4481                	li	s1,0
  release(&lk->lk);
    800038c0:	854a                	mv	a0,s2
    800038c2:	18d020ef          	jal	8000624e <release>
  return r;
}
    800038c6:	8526                	mv	a0,s1
    800038c8:	70a2                	ld	ra,40(sp)
    800038ca:	7402                	ld	s0,32(sp)
    800038cc:	64e2                	ld	s1,24(sp)
    800038ce:	6942                	ld	s2,16(sp)
    800038d0:	6145                	addi	sp,sp,48
    800038d2:	8082                	ret
    800038d4:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800038d6:	0304a983          	lw	s3,48(s1)
    800038da:	82bfd0ef          	jal	80001104 <myproc>
    800038de:	5d04                	lw	s1,56(a0)
    800038e0:	413484b3          	sub	s1,s1,s3
    800038e4:	0014b493          	seqz	s1,s1
    800038e8:	69a2                	ld	s3,8(sp)
    800038ea:	bfd9                	j	800038c0 <holdingsleep+0x1e>

00000000800038ec <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800038ec:	1141                	addi	sp,sp,-16
    800038ee:	e406                	sd	ra,8(sp)
    800038f0:	e022                	sd	s0,0(sp)
    800038f2:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800038f4:	00005597          	auipc	a1,0x5
    800038f8:	ca458593          	addi	a1,a1,-860 # 80008598 <etext+0x598>
    800038fc:	00017517          	auipc	a0,0x17
    80003900:	a8c50513          	addi	a0,a0,-1396 # 8001a388 <ftable>
    80003904:	1e3020ef          	jal	800062e6 <initlock>
}
    80003908:	60a2                	ld	ra,8(sp)
    8000390a:	6402                	ld	s0,0(sp)
    8000390c:	0141                	addi	sp,sp,16
    8000390e:	8082                	ret

0000000080003910 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003910:	1101                	addi	sp,sp,-32
    80003912:	ec06                	sd	ra,24(sp)
    80003914:	e822                	sd	s0,16(sp)
    80003916:	e426                	sd	s1,8(sp)
    80003918:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    8000391a:	00017517          	auipc	a0,0x17
    8000391e:	a6e50513          	addi	a0,a0,-1426 # 8001a388 <ftable>
    80003922:	085020ef          	jal	800061a6 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003926:	00017497          	auipc	s1,0x17
    8000392a:	a8248493          	addi	s1,s1,-1406 # 8001a3a8 <ftable+0x20>
    8000392e:	00018717          	auipc	a4,0x18
    80003932:	a1a70713          	addi	a4,a4,-1510 # 8001b348 <disk>
    if(f->ref == 0){
    80003936:	40dc                	lw	a5,4(s1)
    80003938:	cf89                	beqz	a5,80003952 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000393a:	02848493          	addi	s1,s1,40
    8000393e:	fee49ce3          	bne	s1,a4,80003936 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003942:	00017517          	auipc	a0,0x17
    80003946:	a4650513          	addi	a0,a0,-1466 # 8001a388 <ftable>
    8000394a:	105020ef          	jal	8000624e <release>
  return 0;
    8000394e:	4481                	li	s1,0
    80003950:	a809                	j	80003962 <filealloc+0x52>
      f->ref = 1;
    80003952:	4785                	li	a5,1
    80003954:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003956:	00017517          	auipc	a0,0x17
    8000395a:	a3250513          	addi	a0,a0,-1486 # 8001a388 <ftable>
    8000395e:	0f1020ef          	jal	8000624e <release>
}
    80003962:	8526                	mv	a0,s1
    80003964:	60e2                	ld	ra,24(sp)
    80003966:	6442                	ld	s0,16(sp)
    80003968:	64a2                	ld	s1,8(sp)
    8000396a:	6105                	addi	sp,sp,32
    8000396c:	8082                	ret

000000008000396e <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    8000396e:	1101                	addi	sp,sp,-32
    80003970:	ec06                	sd	ra,24(sp)
    80003972:	e822                	sd	s0,16(sp)
    80003974:	e426                	sd	s1,8(sp)
    80003976:	1000                	addi	s0,sp,32
    80003978:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000397a:	00017517          	auipc	a0,0x17
    8000397e:	a0e50513          	addi	a0,a0,-1522 # 8001a388 <ftable>
    80003982:	025020ef          	jal	800061a6 <acquire>
  if(f->ref < 1)
    80003986:	40dc                	lw	a5,4(s1)
    80003988:	02f05063          	blez	a5,800039a8 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000398c:	2785                	addiw	a5,a5,1
    8000398e:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003990:	00017517          	auipc	a0,0x17
    80003994:	9f850513          	addi	a0,a0,-1544 # 8001a388 <ftable>
    80003998:	0b7020ef          	jal	8000624e <release>
  return f;
}
    8000399c:	8526                	mv	a0,s1
    8000399e:	60e2                	ld	ra,24(sp)
    800039a0:	6442                	ld	s0,16(sp)
    800039a2:	64a2                	ld	s1,8(sp)
    800039a4:	6105                	addi	sp,sp,32
    800039a6:	8082                	ret
    panic("filedup");
    800039a8:	00005517          	auipc	a0,0x5
    800039ac:	bf850513          	addi	a0,a0,-1032 # 800085a0 <etext+0x5a0>
    800039b0:	4d2020ef          	jal	80005e82 <panic>

00000000800039b4 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800039b4:	7139                	addi	sp,sp,-64
    800039b6:	fc06                	sd	ra,56(sp)
    800039b8:	f822                	sd	s0,48(sp)
    800039ba:	f426                	sd	s1,40(sp)
    800039bc:	0080                	addi	s0,sp,64
    800039be:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800039c0:	00017517          	auipc	a0,0x17
    800039c4:	9c850513          	addi	a0,a0,-1592 # 8001a388 <ftable>
    800039c8:	7de020ef          	jal	800061a6 <acquire>
  if(f->ref < 1)
    800039cc:	40dc                	lw	a5,4(s1)
    800039ce:	04f05a63          	blez	a5,80003a22 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    800039d2:	37fd                	addiw	a5,a5,-1
    800039d4:	c0dc                	sw	a5,4(s1)
    800039d6:	06f04063          	bgtz	a5,80003a36 <fileclose+0x82>
    800039da:	f04a                	sd	s2,32(sp)
    800039dc:	ec4e                	sd	s3,24(sp)
    800039de:	e852                	sd	s4,16(sp)
    800039e0:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800039e2:	0004a903          	lw	s2,0(s1)
    800039e6:	0094c783          	lbu	a5,9(s1)
    800039ea:	89be                	mv	s3,a5
    800039ec:	689c                	ld	a5,16(s1)
    800039ee:	8a3e                	mv	s4,a5
    800039f0:	6c9c                	ld	a5,24(s1)
    800039f2:	8abe                	mv	s5,a5
  f->ref = 0;
    800039f4:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800039f8:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800039fc:	00017517          	auipc	a0,0x17
    80003a00:	98c50513          	addi	a0,a0,-1652 # 8001a388 <ftable>
    80003a04:	04b020ef          	jal	8000624e <release>

  if(ff.type == FD_PIPE){
    80003a08:	4785                	li	a5,1
    80003a0a:	04f90163          	beq	s2,a5,80003a4c <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80003a0e:	ffe9079b          	addiw	a5,s2,-2
    80003a12:	4705                	li	a4,1
    80003a14:	04f77563          	bgeu	a4,a5,80003a5e <fileclose+0xaa>
    80003a18:	7902                	ld	s2,32(sp)
    80003a1a:	69e2                	ld	s3,24(sp)
    80003a1c:	6a42                	ld	s4,16(sp)
    80003a1e:	6aa2                	ld	s5,8(sp)
    80003a20:	a00d                	j	80003a42 <fileclose+0x8e>
    80003a22:	f04a                	sd	s2,32(sp)
    80003a24:	ec4e                	sd	s3,24(sp)
    80003a26:	e852                	sd	s4,16(sp)
    80003a28:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80003a2a:	00005517          	auipc	a0,0x5
    80003a2e:	b7e50513          	addi	a0,a0,-1154 # 800085a8 <etext+0x5a8>
    80003a32:	450020ef          	jal	80005e82 <panic>
    release(&ftable.lock);
    80003a36:	00017517          	auipc	a0,0x17
    80003a3a:	95250513          	addi	a0,a0,-1710 # 8001a388 <ftable>
    80003a3e:	011020ef          	jal	8000624e <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80003a42:	70e2                	ld	ra,56(sp)
    80003a44:	7442                	ld	s0,48(sp)
    80003a46:	74a2                	ld	s1,40(sp)
    80003a48:	6121                	addi	sp,sp,64
    80003a4a:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80003a4c:	85ce                	mv	a1,s3
    80003a4e:	8552                	mv	a0,s4
    80003a50:	348000ef          	jal	80003d98 <pipeclose>
    80003a54:	7902                	ld	s2,32(sp)
    80003a56:	69e2                	ld	s3,24(sp)
    80003a58:	6a42                	ld	s4,16(sp)
    80003a5a:	6aa2                	ld	s5,8(sp)
    80003a5c:	b7dd                	j	80003a42 <fileclose+0x8e>
    begin_op();
    80003a5e:	b25ff0ef          	jal	80003582 <begin_op>
    iput(ff.ip);
    80003a62:	8556                	mv	a0,s5
    80003a64:	be8ff0ef          	jal	80002e4c <iput>
    end_op();
    80003a68:	b8bff0ef          	jal	800035f2 <end_op>
    80003a6c:	7902                	ld	s2,32(sp)
    80003a6e:	69e2                	ld	s3,24(sp)
    80003a70:	6a42                	ld	s4,16(sp)
    80003a72:	6aa2                	ld	s5,8(sp)
    80003a74:	b7f9                	j	80003a42 <fileclose+0x8e>

0000000080003a76 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80003a76:	715d                	addi	sp,sp,-80
    80003a78:	e486                	sd	ra,72(sp)
    80003a7a:	e0a2                	sd	s0,64(sp)
    80003a7c:	fc26                	sd	s1,56(sp)
    80003a7e:	f052                	sd	s4,32(sp)
    80003a80:	0880                	addi	s0,sp,80
    80003a82:	84aa                	mv	s1,a0
    80003a84:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80003a86:	e7efd0ef          	jal	80001104 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003a8a:	409c                	lw	a5,0(s1)
    80003a8c:	37f9                	addiw	a5,a5,-2
    80003a8e:	4705                	li	a4,1
    80003a90:	04f76263          	bltu	a4,a5,80003ad4 <filestat+0x5e>
    80003a94:	f84a                	sd	s2,48(sp)
    80003a96:	f44e                	sd	s3,40(sp)
    80003a98:	89aa                	mv	s3,a0
    ilock(f->ip);
    80003a9a:	6c88                	ld	a0,24(s1)
    80003a9c:	a22ff0ef          	jal	80002cbe <ilock>
    stati(f->ip, &st);
    80003aa0:	fb840913          	addi	s2,s0,-72
    80003aa4:	85ca                	mv	a1,s2
    80003aa6:	6c88                	ld	a0,24(s1)
    80003aa8:	c4eff0ef          	jal	80002ef6 <stati>
    iunlock(f->ip);
    80003aac:	6c88                	ld	a0,24(s1)
    80003aae:	ac4ff0ef          	jal	80002d72 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003ab2:	46e1                	li	a3,24
    80003ab4:	864a                	mv	a2,s2
    80003ab6:	85d2                	mv	a1,s4
    80003ab8:	0589b503          	ld	a0,88(s3)
    80003abc:	ac8fd0ef          	jal	80000d84 <copyout>
    80003ac0:	41f5551b          	sraiw	a0,a0,0x1f
    80003ac4:	7942                	ld	s2,48(sp)
    80003ac6:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80003ac8:	60a6                	ld	ra,72(sp)
    80003aca:	6406                	ld	s0,64(sp)
    80003acc:	74e2                	ld	s1,56(sp)
    80003ace:	7a02                	ld	s4,32(sp)
    80003ad0:	6161                	addi	sp,sp,80
    80003ad2:	8082                	ret
  return -1;
    80003ad4:	557d                	li	a0,-1
    80003ad6:	bfcd                	j	80003ac8 <filestat+0x52>

0000000080003ad8 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003ad8:	7179                	addi	sp,sp,-48
    80003ada:	f406                	sd	ra,40(sp)
    80003adc:	f022                	sd	s0,32(sp)
    80003ade:	e84a                	sd	s2,16(sp)
    80003ae0:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003ae2:	00854783          	lbu	a5,8(a0)
    80003ae6:	cfd1                	beqz	a5,80003b82 <fileread+0xaa>
    80003ae8:	ec26                	sd	s1,24(sp)
    80003aea:	e44e                	sd	s3,8(sp)
    80003aec:	84aa                	mv	s1,a0
    80003aee:	892e                	mv	s2,a1
    80003af0:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    80003af2:	411c                	lw	a5,0(a0)
    80003af4:	4705                	li	a4,1
    80003af6:	04e78363          	beq	a5,a4,80003b3c <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003afa:	470d                	li	a4,3
    80003afc:	04e78763          	beq	a5,a4,80003b4a <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80003b00:	4709                	li	a4,2
    80003b02:	06e79a63          	bne	a5,a4,80003b76 <fileread+0x9e>
    ilock(f->ip);
    80003b06:	6d08                	ld	a0,24(a0)
    80003b08:	9b6ff0ef          	jal	80002cbe <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80003b0c:	874e                	mv	a4,s3
    80003b0e:	5094                	lw	a3,32(s1)
    80003b10:	864a                	mv	a2,s2
    80003b12:	4585                	li	a1,1
    80003b14:	6c88                	ld	a0,24(s1)
    80003b16:	c0eff0ef          	jal	80002f24 <readi>
    80003b1a:	892a                	mv	s2,a0
    80003b1c:	00a05563          	blez	a0,80003b26 <fileread+0x4e>
      f->off += r;
    80003b20:	509c                	lw	a5,32(s1)
    80003b22:	9fa9                	addw	a5,a5,a0
    80003b24:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80003b26:	6c88                	ld	a0,24(s1)
    80003b28:	a4aff0ef          	jal	80002d72 <iunlock>
    80003b2c:	64e2                	ld	s1,24(sp)
    80003b2e:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80003b30:	854a                	mv	a0,s2
    80003b32:	70a2                	ld	ra,40(sp)
    80003b34:	7402                	ld	s0,32(sp)
    80003b36:	6942                	ld	s2,16(sp)
    80003b38:	6145                	addi	sp,sp,48
    80003b3a:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80003b3c:	6908                	ld	a0,16(a0)
    80003b3e:	3b6000ef          	jal	80003ef4 <piperead>
    80003b42:	892a                	mv	s2,a0
    80003b44:	64e2                	ld	s1,24(sp)
    80003b46:	69a2                	ld	s3,8(sp)
    80003b48:	b7e5                	j	80003b30 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80003b4a:	02451783          	lh	a5,36(a0)
    80003b4e:	03079693          	slli	a3,a5,0x30
    80003b52:	92c1                	srli	a3,a3,0x30
    80003b54:	4725                	li	a4,9
    80003b56:	02d76963          	bltu	a4,a3,80003b88 <fileread+0xb0>
    80003b5a:	0792                	slli	a5,a5,0x4
    80003b5c:	00016717          	auipc	a4,0x16
    80003b60:	78c70713          	addi	a4,a4,1932 # 8001a2e8 <devsw>
    80003b64:	97ba                	add	a5,a5,a4
    80003b66:	639c                	ld	a5,0(a5)
    80003b68:	c78d                	beqz	a5,80003b92 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80003b6a:	4505                	li	a0,1
    80003b6c:	9782                	jalr	a5
    80003b6e:	892a                	mv	s2,a0
    80003b70:	64e2                	ld	s1,24(sp)
    80003b72:	69a2                	ld	s3,8(sp)
    80003b74:	bf75                	j	80003b30 <fileread+0x58>
    panic("fileread");
    80003b76:	00005517          	auipc	a0,0x5
    80003b7a:	a4250513          	addi	a0,a0,-1470 # 800085b8 <etext+0x5b8>
    80003b7e:	304020ef          	jal	80005e82 <panic>
    return -1;
    80003b82:	57fd                	li	a5,-1
    80003b84:	893e                	mv	s2,a5
    80003b86:	b76d                	j	80003b30 <fileread+0x58>
      return -1;
    80003b88:	57fd                	li	a5,-1
    80003b8a:	893e                	mv	s2,a5
    80003b8c:	64e2                	ld	s1,24(sp)
    80003b8e:	69a2                	ld	s3,8(sp)
    80003b90:	b745                	j	80003b30 <fileread+0x58>
    80003b92:	57fd                	li	a5,-1
    80003b94:	893e                	mv	s2,a5
    80003b96:	64e2                	ld	s1,24(sp)
    80003b98:	69a2                	ld	s3,8(sp)
    80003b9a:	bf59                	j	80003b30 <fileread+0x58>

0000000080003b9c <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80003b9c:	00954783          	lbu	a5,9(a0)
    80003ba0:	10078f63          	beqz	a5,80003cbe <filewrite+0x122>
{
    80003ba4:	711d                	addi	sp,sp,-96
    80003ba6:	ec86                	sd	ra,88(sp)
    80003ba8:	e8a2                	sd	s0,80(sp)
    80003baa:	e0ca                	sd	s2,64(sp)
    80003bac:	f456                	sd	s5,40(sp)
    80003bae:	f05a                	sd	s6,32(sp)
    80003bb0:	1080                	addi	s0,sp,96
    80003bb2:	892a                	mv	s2,a0
    80003bb4:	8b2e                	mv	s6,a1
    80003bb6:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    80003bb8:	411c                	lw	a5,0(a0)
    80003bba:	4705                	li	a4,1
    80003bbc:	02e78a63          	beq	a5,a4,80003bf0 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003bc0:	470d                	li	a4,3
    80003bc2:	02e78b63          	beq	a5,a4,80003bf8 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80003bc6:	4709                	li	a4,2
    80003bc8:	0ce79f63          	bne	a5,a4,80003ca6 <filewrite+0x10a>
    80003bcc:	f852                	sd	s4,48(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80003bce:	0ac05a63          	blez	a2,80003c82 <filewrite+0xe6>
    80003bd2:	e4a6                	sd	s1,72(sp)
    80003bd4:	fc4e                	sd	s3,56(sp)
    80003bd6:	ec5e                	sd	s7,24(sp)
    80003bd8:	e862                	sd	s8,16(sp)
    80003bda:	e466                	sd	s9,8(sp)
    int i = 0;
    80003bdc:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    80003bde:	6b85                	lui	s7,0x1
    80003be0:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80003be4:	6785                	lui	a5,0x1
    80003be6:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80003bea:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80003bec:	4c05                	li	s8,1
    80003bee:	a8ad                	j	80003c68 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80003bf0:	6908                	ld	a0,16(a0)
    80003bf2:	20a000ef          	jal	80003dfc <pipewrite>
    80003bf6:	a04d                	j	80003c98 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80003bf8:	02451783          	lh	a5,36(a0)
    80003bfc:	03079693          	slli	a3,a5,0x30
    80003c00:	92c1                	srli	a3,a3,0x30
    80003c02:	4725                	li	a4,9
    80003c04:	0ad76f63          	bltu	a4,a3,80003cc2 <filewrite+0x126>
    80003c08:	0792                	slli	a5,a5,0x4
    80003c0a:	00016717          	auipc	a4,0x16
    80003c0e:	6de70713          	addi	a4,a4,1758 # 8001a2e8 <devsw>
    80003c12:	97ba                	add	a5,a5,a4
    80003c14:	679c                	ld	a5,8(a5)
    80003c16:	cbc5                	beqz	a5,80003cc6 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    80003c18:	4505                	li	a0,1
    80003c1a:	9782                	jalr	a5
    80003c1c:	a8b5                	j	80003c98 <filewrite+0xfc>
      if(n1 > max)
    80003c1e:	2981                	sext.w	s3,s3
      begin_op();
    80003c20:	963ff0ef          	jal	80003582 <begin_op>
      ilock(f->ip);
    80003c24:	01893503          	ld	a0,24(s2)
    80003c28:	896ff0ef          	jal	80002cbe <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80003c2c:	874e                	mv	a4,s3
    80003c2e:	02092683          	lw	a3,32(s2)
    80003c32:	016a0633          	add	a2,s4,s6
    80003c36:	85e2                	mv	a1,s8
    80003c38:	01893503          	ld	a0,24(s2)
    80003c3c:	bdaff0ef          	jal	80003016 <writei>
    80003c40:	84aa                	mv	s1,a0
    80003c42:	00a05763          	blez	a0,80003c50 <filewrite+0xb4>
        f->off += r;
    80003c46:	02092783          	lw	a5,32(s2)
    80003c4a:	9fa9                	addw	a5,a5,a0
    80003c4c:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80003c50:	01893503          	ld	a0,24(s2)
    80003c54:	91eff0ef          	jal	80002d72 <iunlock>
      end_op();
    80003c58:	99bff0ef          	jal	800035f2 <end_op>

      if(r != n1){
    80003c5c:	02999563          	bne	s3,s1,80003c86 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    80003c60:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80003c64:	015a5963          	bge	s4,s5,80003c76 <filewrite+0xda>
      int n1 = n - i;
    80003c68:	414a87bb          	subw	a5,s5,s4
    80003c6c:	89be                	mv	s3,a5
      if(n1 > max)
    80003c6e:	fafbd8e3          	bge	s7,a5,80003c1e <filewrite+0x82>
    80003c72:	89e6                	mv	s3,s9
    80003c74:	b76d                	j	80003c1e <filewrite+0x82>
    80003c76:	64a6                	ld	s1,72(sp)
    80003c78:	79e2                	ld	s3,56(sp)
    80003c7a:	6be2                	ld	s7,24(sp)
    80003c7c:	6c42                	ld	s8,16(sp)
    80003c7e:	6ca2                	ld	s9,8(sp)
    80003c80:	a801                	j	80003c90 <filewrite+0xf4>
    int i = 0;
    80003c82:	4a01                	li	s4,0
    80003c84:	a031                	j	80003c90 <filewrite+0xf4>
    80003c86:	64a6                	ld	s1,72(sp)
    80003c88:	79e2                	ld	s3,56(sp)
    80003c8a:	6be2                	ld	s7,24(sp)
    80003c8c:	6c42                	ld	s8,16(sp)
    80003c8e:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    80003c90:	034a9d63          	bne	s5,s4,80003cca <filewrite+0x12e>
    80003c94:	8556                	mv	a0,s5
    80003c96:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80003c98:	60e6                	ld	ra,88(sp)
    80003c9a:	6446                	ld	s0,80(sp)
    80003c9c:	6906                	ld	s2,64(sp)
    80003c9e:	7aa2                	ld	s5,40(sp)
    80003ca0:	7b02                	ld	s6,32(sp)
    80003ca2:	6125                	addi	sp,sp,96
    80003ca4:	8082                	ret
    80003ca6:	e4a6                	sd	s1,72(sp)
    80003ca8:	fc4e                	sd	s3,56(sp)
    80003caa:	f852                	sd	s4,48(sp)
    80003cac:	ec5e                	sd	s7,24(sp)
    80003cae:	e862                	sd	s8,16(sp)
    80003cb0:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80003cb2:	00005517          	auipc	a0,0x5
    80003cb6:	91650513          	addi	a0,a0,-1770 # 800085c8 <etext+0x5c8>
    80003cba:	1c8020ef          	jal	80005e82 <panic>
    return -1;
    80003cbe:	557d                	li	a0,-1
}
    80003cc0:	8082                	ret
      return -1;
    80003cc2:	557d                	li	a0,-1
    80003cc4:	bfd1                	j	80003c98 <filewrite+0xfc>
    80003cc6:	557d                	li	a0,-1
    80003cc8:	bfc1                	j	80003c98 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    80003cca:	557d                	li	a0,-1
    80003ccc:	7a42                	ld	s4,48(sp)
    80003cce:	b7e9                	j	80003c98 <filewrite+0xfc>

0000000080003cd0 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80003cd0:	7179                	addi	sp,sp,-48
    80003cd2:	f406                	sd	ra,40(sp)
    80003cd4:	f022                	sd	s0,32(sp)
    80003cd6:	ec26                	sd	s1,24(sp)
    80003cd8:	e052                	sd	s4,0(sp)
    80003cda:	1800                	addi	s0,sp,48
    80003cdc:	84aa                	mv	s1,a0
    80003cde:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80003ce0:	0005b023          	sd	zero,0(a1)
    80003ce4:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80003ce8:	c29ff0ef          	jal	80003910 <filealloc>
    80003cec:	e088                	sd	a0,0(s1)
    80003cee:	c549                	beqz	a0,80003d78 <pipealloc+0xa8>
    80003cf0:	c21ff0ef          	jal	80003910 <filealloc>
    80003cf4:	00aa3023          	sd	a0,0(s4)
    80003cf8:	cd25                	beqz	a0,80003d70 <pipealloc+0xa0>
    80003cfa:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80003cfc:	e16fc0ef          	jal	80000312 <kalloc>
    80003d00:	892a                	mv	s2,a0
    80003d02:	c12d                	beqz	a0,80003d64 <pipealloc+0x94>
    80003d04:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80003d06:	4985                	li	s3,1
    80003d08:	23352423          	sw	s3,552(a0)
  pi->writeopen = 1;
    80003d0c:	23352623          	sw	s3,556(a0)
  pi->nwrite = 0;
    80003d10:	22052223          	sw	zero,548(a0)
  pi->nread = 0;
    80003d14:	22052023          	sw	zero,544(a0)
  initlock(&pi->lock, "pipe");
    80003d18:	00005597          	auipc	a1,0x5
    80003d1c:	8c058593          	addi	a1,a1,-1856 # 800085d8 <etext+0x5d8>
    80003d20:	5c6020ef          	jal	800062e6 <initlock>
  (*f0)->type = FD_PIPE;
    80003d24:	609c                	ld	a5,0(s1)
    80003d26:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80003d2a:	609c                	ld	a5,0(s1)
    80003d2c:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80003d30:	609c                	ld	a5,0(s1)
    80003d32:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80003d36:	609c                	ld	a5,0(s1)
    80003d38:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80003d3c:	000a3783          	ld	a5,0(s4)
    80003d40:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80003d44:	000a3783          	ld	a5,0(s4)
    80003d48:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80003d4c:	000a3783          	ld	a5,0(s4)
    80003d50:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80003d54:	000a3783          	ld	a5,0(s4)
    80003d58:	0127b823          	sd	s2,16(a5)
  return 0;
    80003d5c:	4501                	li	a0,0
    80003d5e:	6942                	ld	s2,16(sp)
    80003d60:	69a2                	ld	s3,8(sp)
    80003d62:	a01d                	j	80003d88 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80003d64:	6088                	ld	a0,0(s1)
    80003d66:	c119                	beqz	a0,80003d6c <pipealloc+0x9c>
    80003d68:	6942                	ld	s2,16(sp)
    80003d6a:	a029                	j	80003d74 <pipealloc+0xa4>
    80003d6c:	6942                	ld	s2,16(sp)
    80003d6e:	a029                	j	80003d78 <pipealloc+0xa8>
    80003d70:	6088                	ld	a0,0(s1)
    80003d72:	c10d                	beqz	a0,80003d94 <pipealloc+0xc4>
    fileclose(*f0);
    80003d74:	c41ff0ef          	jal	800039b4 <fileclose>
  if(*f1)
    80003d78:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80003d7c:	557d                	li	a0,-1
  if(*f1)
    80003d7e:	c789                	beqz	a5,80003d88 <pipealloc+0xb8>
    fileclose(*f1);
    80003d80:	853e                	mv	a0,a5
    80003d82:	c33ff0ef          	jal	800039b4 <fileclose>
  return -1;
    80003d86:	557d                	li	a0,-1
}
    80003d88:	70a2                	ld	ra,40(sp)
    80003d8a:	7402                	ld	s0,32(sp)
    80003d8c:	64e2                	ld	s1,24(sp)
    80003d8e:	6a02                	ld	s4,0(sp)
    80003d90:	6145                	addi	sp,sp,48
    80003d92:	8082                	ret
  return -1;
    80003d94:	557d                	li	a0,-1
    80003d96:	bfcd                	j	80003d88 <pipealloc+0xb8>

0000000080003d98 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80003d98:	1101                	addi	sp,sp,-32
    80003d9a:	ec06                	sd	ra,24(sp)
    80003d9c:	e822                	sd	s0,16(sp)
    80003d9e:	e426                	sd	s1,8(sp)
    80003da0:	e04a                	sd	s2,0(sp)
    80003da2:	1000                	addi	s0,sp,32
    80003da4:	84aa                	mv	s1,a0
    80003da6:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80003da8:	3fe020ef          	jal	800061a6 <acquire>
  if(writable){
    80003dac:	02090763          	beqz	s2,80003dda <pipeclose+0x42>
    pi->writeopen = 0;
    80003db0:	2204a623          	sw	zero,556(s1)
    wakeup(&pi->nread);
    80003db4:	22048513          	addi	a0,s1,544
    80003db8:	96bfd0ef          	jal	80001722 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80003dbc:	2284a783          	lw	a5,552(s1)
    80003dc0:	e781                	bnez	a5,80003dc8 <pipeclose+0x30>
    80003dc2:	22c4a783          	lw	a5,556(s1)
    80003dc6:	c38d                	beqz	a5,80003de8 <pipeclose+0x50>
#ifdef LAB_LOCK
    freelock(&pi->lock);
#endif    
    kfree((char*)pi);
  } else
    release(&pi->lock);
    80003dc8:	8526                	mv	a0,s1
    80003dca:	484020ef          	jal	8000624e <release>
}
    80003dce:	60e2                	ld	ra,24(sp)
    80003dd0:	6442                	ld	s0,16(sp)
    80003dd2:	64a2                	ld	s1,8(sp)
    80003dd4:	6902                	ld	s2,0(sp)
    80003dd6:	6105                	addi	sp,sp,32
    80003dd8:	8082                	ret
    pi->readopen = 0;
    80003dda:	2204a423          	sw	zero,552(s1)
    wakeup(&pi->nwrite);
    80003dde:	22448513          	addi	a0,s1,548
    80003de2:	941fd0ef          	jal	80001722 <wakeup>
    80003de6:	bfd9                	j	80003dbc <pipeclose+0x24>
    release(&pi->lock);
    80003de8:	8526                	mv	a0,s1
    80003dea:	464020ef          	jal	8000624e <release>
    freelock(&pi->lock);
    80003dee:	8526                	mv	a0,s1
    80003df0:	49a020ef          	jal	8000628a <freelock>
    kfree((char*)pi);
    80003df4:	8526                	mv	a0,s1
    80003df6:	c8cfc0ef          	jal	80000282 <kfree>
    80003dfa:	bfd1                	j	80003dce <pipeclose+0x36>

0000000080003dfc <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80003dfc:	7159                	addi	sp,sp,-112
    80003dfe:	f486                	sd	ra,104(sp)
    80003e00:	f0a2                	sd	s0,96(sp)
    80003e02:	eca6                	sd	s1,88(sp)
    80003e04:	e8ca                	sd	s2,80(sp)
    80003e06:	e4ce                	sd	s3,72(sp)
    80003e08:	e0d2                	sd	s4,64(sp)
    80003e0a:	fc56                	sd	s5,56(sp)
    80003e0c:	1880                	addi	s0,sp,112
    80003e0e:	84aa                	mv	s1,a0
    80003e10:	8aae                	mv	s5,a1
    80003e12:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80003e14:	af0fd0ef          	jal	80001104 <myproc>
    80003e18:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80003e1a:	8526                	mv	a0,s1
    80003e1c:	38a020ef          	jal	800061a6 <acquire>
  while(i < n){
    80003e20:	0d405263          	blez	s4,80003ee4 <pipewrite+0xe8>
    80003e24:	f85a                	sd	s6,48(sp)
    80003e26:	f45e                	sd	s7,40(sp)
    80003e28:	f062                	sd	s8,32(sp)
    80003e2a:	ec66                	sd	s9,24(sp)
    80003e2c:	e86a                	sd	s10,16(sp)
  int i = 0;
    80003e2e:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003e30:	f9f40c13          	addi	s8,s0,-97
    80003e34:	4b85                	li	s7,1
    80003e36:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80003e38:	22048d13          	addi	s10,s1,544
      sleep(&pi->nwrite, &pi->lock);
    80003e3c:	22448c93          	addi	s9,s1,548
    80003e40:	a82d                	j	80003e7a <pipewrite+0x7e>
      release(&pi->lock);
    80003e42:	8526                	mv	a0,s1
    80003e44:	40a020ef          	jal	8000624e <release>
      return -1;
    80003e48:	597d                	li	s2,-1
    80003e4a:	7b42                	ld	s6,48(sp)
    80003e4c:	7ba2                	ld	s7,40(sp)
    80003e4e:	7c02                	ld	s8,32(sp)
    80003e50:	6ce2                	ld	s9,24(sp)
    80003e52:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80003e54:	854a                	mv	a0,s2
    80003e56:	70a6                	ld	ra,104(sp)
    80003e58:	7406                	ld	s0,96(sp)
    80003e5a:	64e6                	ld	s1,88(sp)
    80003e5c:	6946                	ld	s2,80(sp)
    80003e5e:	69a6                	ld	s3,72(sp)
    80003e60:	6a06                	ld	s4,64(sp)
    80003e62:	7ae2                	ld	s5,56(sp)
    80003e64:	6165                	addi	sp,sp,112
    80003e66:	8082                	ret
      wakeup(&pi->nread);
    80003e68:	856a                	mv	a0,s10
    80003e6a:	8b9fd0ef          	jal	80001722 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80003e6e:	85a6                	mv	a1,s1
    80003e70:	8566                	mv	a0,s9
    80003e72:	865fd0ef          	jal	800016d6 <sleep>
  while(i < n){
    80003e76:	05495a63          	bge	s2,s4,80003eca <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80003e7a:	2284a783          	lw	a5,552(s1)
    80003e7e:	d3f1                	beqz	a5,80003e42 <pipewrite+0x46>
    80003e80:	854e                	mv	a0,s3
    80003e82:	a91fd0ef          	jal	80001912 <killed>
    80003e86:	fd55                	bnez	a0,80003e42 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80003e88:	2204a783          	lw	a5,544(s1)
    80003e8c:	2244a703          	lw	a4,548(s1)
    80003e90:	2007879b          	addiw	a5,a5,512
    80003e94:	fcf70ae3          	beq	a4,a5,80003e68 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003e98:	86de                	mv	a3,s7
    80003e9a:	01590633          	add	a2,s2,s5
    80003e9e:	85e2                	mv	a1,s8
    80003ea0:	0589b503          	ld	a0,88(s3)
    80003ea4:	f91fc0ef          	jal	80000e34 <copyin>
    80003ea8:	05650063          	beq	a0,s6,80003ee8 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80003eac:	2244a783          	lw	a5,548(s1)
    80003eb0:	0017871b          	addiw	a4,a5,1
    80003eb4:	22e4a223          	sw	a4,548(s1)
    80003eb8:	1ff7f793          	andi	a5,a5,511
    80003ebc:	97a6                	add	a5,a5,s1
    80003ebe:	f9f44703          	lbu	a4,-97(s0)
    80003ec2:	02e78023          	sb	a4,32(a5)
      i++;
    80003ec6:	2905                	addiw	s2,s2,1
    80003ec8:	b77d                	j	80003e76 <pipewrite+0x7a>
    80003eca:	7b42                	ld	s6,48(sp)
    80003ecc:	7ba2                	ld	s7,40(sp)
    80003ece:	7c02                	ld	s8,32(sp)
    80003ed0:	6ce2                	ld	s9,24(sp)
    80003ed2:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80003ed4:	22048513          	addi	a0,s1,544
    80003ed8:	84bfd0ef          	jal	80001722 <wakeup>
  release(&pi->lock);
    80003edc:	8526                	mv	a0,s1
    80003ede:	370020ef          	jal	8000624e <release>
  return i;
    80003ee2:	bf8d                	j	80003e54 <pipewrite+0x58>
  int i = 0;
    80003ee4:	4901                	li	s2,0
    80003ee6:	b7fd                	j	80003ed4 <pipewrite+0xd8>
    80003ee8:	7b42                	ld	s6,48(sp)
    80003eea:	7ba2                	ld	s7,40(sp)
    80003eec:	7c02                	ld	s8,32(sp)
    80003eee:	6ce2                	ld	s9,24(sp)
    80003ef0:	6d42                	ld	s10,16(sp)
    80003ef2:	b7cd                	j	80003ed4 <pipewrite+0xd8>

0000000080003ef4 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80003ef4:	711d                	addi	sp,sp,-96
    80003ef6:	ec86                	sd	ra,88(sp)
    80003ef8:	e8a2                	sd	s0,80(sp)
    80003efa:	e4a6                	sd	s1,72(sp)
    80003efc:	e0ca                	sd	s2,64(sp)
    80003efe:	fc4e                	sd	s3,56(sp)
    80003f00:	f852                	sd	s4,48(sp)
    80003f02:	f456                	sd	s5,40(sp)
    80003f04:	1080                	addi	s0,sp,96
    80003f06:	84aa                	mv	s1,a0
    80003f08:	892e                	mv	s2,a1
    80003f0a:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80003f0c:	9f8fd0ef          	jal	80001104 <myproc>
    80003f10:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80003f12:	8526                	mv	a0,s1
    80003f14:	292020ef          	jal	800061a6 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003f18:	2204a703          	lw	a4,544(s1)
    80003f1c:	2244a783          	lw	a5,548(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003f20:	22048993          	addi	s3,s1,544
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003f24:	02f71763          	bne	a4,a5,80003f52 <piperead+0x5e>
    80003f28:	22c4a783          	lw	a5,556(s1)
    80003f2c:	cf85                	beqz	a5,80003f64 <piperead+0x70>
    if(killed(pr)){
    80003f2e:	8552                	mv	a0,s4
    80003f30:	9e3fd0ef          	jal	80001912 <killed>
    80003f34:	e11d                	bnez	a0,80003f5a <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003f36:	85a6                	mv	a1,s1
    80003f38:	854e                	mv	a0,s3
    80003f3a:	f9cfd0ef          	jal	800016d6 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003f3e:	2204a703          	lw	a4,544(s1)
    80003f42:	2244a783          	lw	a5,548(s1)
    80003f46:	fef701e3          	beq	a4,a5,80003f28 <piperead+0x34>
    80003f4a:	f05a                	sd	s6,32(sp)
    80003f4c:	ec5e                	sd	s7,24(sp)
    80003f4e:	e862                	sd	s8,16(sp)
    80003f50:	a829                	j	80003f6a <piperead+0x76>
    80003f52:	f05a                	sd	s6,32(sp)
    80003f54:	ec5e                	sd	s7,24(sp)
    80003f56:	e862                	sd	s8,16(sp)
    80003f58:	a809                	j	80003f6a <piperead+0x76>
      release(&pi->lock);
    80003f5a:	8526                	mv	a0,s1
    80003f5c:	2f2020ef          	jal	8000624e <release>
      return -1;
    80003f60:	59fd                	li	s3,-1
    80003f62:	a09d                	j	80003fc8 <piperead+0xd4>
    80003f64:	f05a                	sd	s6,32(sp)
    80003f66:	ec5e                	sd	s7,24(sp)
    80003f68:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003f6a:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003f6c:	faf40c13          	addi	s8,s0,-81
    80003f70:	4b85                	li	s7,1
    80003f72:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003f74:	05505063          	blez	s5,80003fb4 <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    80003f78:	2204a783          	lw	a5,544(s1)
    80003f7c:	2244a703          	lw	a4,548(s1)
    80003f80:	02f70a63          	beq	a4,a5,80003fb4 <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003f84:	0017871b          	addiw	a4,a5,1
    80003f88:	22e4a023          	sw	a4,544(s1)
    80003f8c:	1ff7f793          	andi	a5,a5,511
    80003f90:	97a6                	add	a5,a5,s1
    80003f92:	0207c783          	lbu	a5,32(a5)
    80003f96:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003f9a:	86de                	mv	a3,s7
    80003f9c:	8662                	mv	a2,s8
    80003f9e:	85ca                	mv	a1,s2
    80003fa0:	058a3503          	ld	a0,88(s4)
    80003fa4:	de1fc0ef          	jal	80000d84 <copyout>
    80003fa8:	01650663          	beq	a0,s6,80003fb4 <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003fac:	2985                	addiw	s3,s3,1
    80003fae:	0905                	addi	s2,s2,1
    80003fb0:	fd3a94e3          	bne	s5,s3,80003f78 <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003fb4:	22448513          	addi	a0,s1,548
    80003fb8:	f6afd0ef          	jal	80001722 <wakeup>
  release(&pi->lock);
    80003fbc:	8526                	mv	a0,s1
    80003fbe:	290020ef          	jal	8000624e <release>
    80003fc2:	7b02                	ld	s6,32(sp)
    80003fc4:	6be2                	ld	s7,24(sp)
    80003fc6:	6c42                	ld	s8,16(sp)
  return i;
}
    80003fc8:	854e                	mv	a0,s3
    80003fca:	60e6                	ld	ra,88(sp)
    80003fcc:	6446                	ld	s0,80(sp)
    80003fce:	64a6                	ld	s1,72(sp)
    80003fd0:	6906                	ld	s2,64(sp)
    80003fd2:	79e2                	ld	s3,56(sp)
    80003fd4:	7a42                	ld	s4,48(sp)
    80003fd6:	7aa2                	ld	s5,40(sp)
    80003fd8:	6125                	addi	sp,sp,96
    80003fda:	8082                	ret

0000000080003fdc <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003fdc:	1141                	addi	sp,sp,-16
    80003fde:	e406                	sd	ra,8(sp)
    80003fe0:	e022                	sd	s0,0(sp)
    80003fe2:	0800                	addi	s0,sp,16
    80003fe4:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003fe6:	0035151b          	slliw	a0,a0,0x3
    80003fea:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80003fec:	8b89                	andi	a5,a5,2
    80003fee:	c399                	beqz	a5,80003ff4 <flags2perm+0x18>
      perm |= PTE_W;
    80003ff0:	00456513          	ori	a0,a0,4
    return perm;
}
    80003ff4:	60a2                	ld	ra,8(sp)
    80003ff6:	6402                	ld	s0,0(sp)
    80003ff8:	0141                	addi	sp,sp,16
    80003ffa:	8082                	ret

0000000080003ffc <exec>:

int
exec(char *path, char **argv)
{
    80003ffc:	de010113          	addi	sp,sp,-544
    80004000:	20113c23          	sd	ra,536(sp)
    80004004:	20813823          	sd	s0,528(sp)
    80004008:	20913423          	sd	s1,520(sp)
    8000400c:	21213023          	sd	s2,512(sp)
    80004010:	1400                	addi	s0,sp,544
    80004012:	892a                	mv	s2,a0
    80004014:	dea43823          	sd	a0,-528(s0)
    80004018:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    8000401c:	8e8fd0ef          	jal	80001104 <myproc>
    80004020:	84aa                	mv	s1,a0

  begin_op();
    80004022:	d60ff0ef          	jal	80003582 <begin_op>

  if((ip = namei(path)) == 0){
    80004026:	854a                	mv	a0,s2
    80004028:	b98ff0ef          	jal	800033c0 <namei>
    8000402c:	cd21                	beqz	a0,80004084 <exec+0x88>
    8000402e:	fbd2                	sd	s4,496(sp)
    80004030:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004032:	c8dfe0ef          	jal	80002cbe <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004036:	04000713          	li	a4,64
    8000403a:	4681                	li	a3,0
    8000403c:	e5040613          	addi	a2,s0,-432
    80004040:	4581                	li	a1,0
    80004042:	8552                	mv	a0,s4
    80004044:	ee1fe0ef          	jal	80002f24 <readi>
    80004048:	04000793          	li	a5,64
    8000404c:	00f51a63          	bne	a0,a5,80004060 <exec+0x64>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80004050:	e5042703          	lw	a4,-432(s0)
    80004054:	464c47b7          	lui	a5,0x464c4
    80004058:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    8000405c:	02f70863          	beq	a4,a5,8000408c <exec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004060:	8552                	mv	a0,s4
    80004062:	e75fe0ef          	jal	80002ed6 <iunlockput>
    end_op();
    80004066:	d8cff0ef          	jal	800035f2 <end_op>
  }
  return -1;
    8000406a:	557d                	li	a0,-1
    8000406c:	7a5e                	ld	s4,496(sp)
}
    8000406e:	21813083          	ld	ra,536(sp)
    80004072:	21013403          	ld	s0,528(sp)
    80004076:	20813483          	ld	s1,520(sp)
    8000407a:	20013903          	ld	s2,512(sp)
    8000407e:	22010113          	addi	sp,sp,544
    80004082:	8082                	ret
    end_op();
    80004084:	d6eff0ef          	jal	800035f2 <end_op>
    return -1;
    80004088:	557d                	li	a0,-1
    8000408a:	b7d5                	j	8000406e <exec+0x72>
    8000408c:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    8000408e:	8526                	mv	a0,s1
    80004090:	91efd0ef          	jal	800011ae <proc_pagetable>
    80004094:	8b2a                	mv	s6,a0
    80004096:	26050f63          	beqz	a0,80004314 <exec+0x318>
    8000409a:	ffce                	sd	s3,504(sp)
    8000409c:	f7d6                	sd	s5,488(sp)
    8000409e:	efde                	sd	s7,472(sp)
    800040a0:	ebe2                	sd	s8,464(sp)
    800040a2:	e7e6                	sd	s9,456(sp)
    800040a4:	e3ea                	sd	s10,448(sp)
    800040a6:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800040a8:	e8845783          	lhu	a5,-376(s0)
    800040ac:	0e078963          	beqz	a5,8000419e <exec+0x1a2>
    800040b0:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800040b4:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800040b6:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800040b8:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    800040bc:	6c85                	lui	s9,0x1
    800040be:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    800040c2:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    800040c6:	6a85                	lui	s5,0x1
    800040c8:	a085                	j	80004128 <exec+0x12c>
      panic("loadseg: address should exist");
    800040ca:	00004517          	auipc	a0,0x4
    800040ce:	51650513          	addi	a0,a0,1302 # 800085e0 <etext+0x5e0>
    800040d2:	5b1010ef          	jal	80005e82 <panic>
    if(sz - i < PGSIZE)
    800040d6:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800040d8:	874a                	mv	a4,s2
    800040da:	009b86bb          	addw	a3,s7,s1
    800040de:	4581                	li	a1,0
    800040e0:	8552                	mv	a0,s4
    800040e2:	e43fe0ef          	jal	80002f24 <readi>
    800040e6:	22a91b63          	bne	s2,a0,8000431c <exec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    800040ea:	009a84bb          	addw	s1,s5,s1
    800040ee:	0334f263          	bgeu	s1,s3,80004112 <exec+0x116>
    pa = walkaddr(pagetable, va + i);
    800040f2:	02049593          	slli	a1,s1,0x20
    800040f6:	9181                	srli	a1,a1,0x20
    800040f8:	95e2                	add	a1,a1,s8
    800040fa:	855a                	mv	a0,s6
    800040fc:	f12fc0ef          	jal	8000080e <walkaddr>
    80004100:	862a                	mv	a2,a0
    if(pa == 0)
    80004102:	d561                	beqz	a0,800040ca <exec+0xce>
    if(sz - i < PGSIZE)
    80004104:	409987bb          	subw	a5,s3,s1
    80004108:	893e                	mv	s2,a5
    8000410a:	fcfcf6e3          	bgeu	s9,a5,800040d6 <exec+0xda>
    8000410e:	8956                	mv	s2,s5
    80004110:	b7d9                	j	800040d6 <exec+0xda>
    sz = sz1;
    80004112:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004116:	2d05                	addiw	s10,s10,1
    80004118:	e0843783          	ld	a5,-504(s0)
    8000411c:	0387869b          	addiw	a3,a5,56
    80004120:	e8845783          	lhu	a5,-376(s0)
    80004124:	06fd5e63          	bge	s10,a5,800041a0 <exec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004128:	e0d43423          	sd	a3,-504(s0)
    8000412c:	876e                	mv	a4,s11
    8000412e:	e1840613          	addi	a2,s0,-488
    80004132:	4581                	li	a1,0
    80004134:	8552                	mv	a0,s4
    80004136:	deffe0ef          	jal	80002f24 <readi>
    8000413a:	1db51f63          	bne	a0,s11,80004318 <exec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    8000413e:	e1842783          	lw	a5,-488(s0)
    80004142:	4705                	li	a4,1
    80004144:	fce799e3          	bne	a5,a4,80004116 <exec+0x11a>
    if(ph.memsz < ph.filesz)
    80004148:	e4043483          	ld	s1,-448(s0)
    8000414c:	e3843783          	ld	a5,-456(s0)
    80004150:	1ef4e463          	bltu	s1,a5,80004338 <exec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004154:	e2843783          	ld	a5,-472(s0)
    80004158:	94be                	add	s1,s1,a5
    8000415a:	1ef4e263          	bltu	s1,a5,8000433e <exec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    8000415e:	de843703          	ld	a4,-536(s0)
    80004162:	8ff9                	and	a5,a5,a4
    80004164:	1e079063          	bnez	a5,80004344 <exec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004168:	e1c42503          	lw	a0,-484(s0)
    8000416c:	e71ff0ef          	jal	80003fdc <flags2perm>
    80004170:	86aa                	mv	a3,a0
    80004172:	8626                	mv	a2,s1
    80004174:	85ca                	mv	a1,s2
    80004176:	855a                	mv	a0,s6
    80004178:	9fdfc0ef          	jal	80000b74 <uvmalloc>
    8000417c:	dea43c23          	sd	a0,-520(s0)
    80004180:	1c050563          	beqz	a0,8000434a <exec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004184:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004188:	00098863          	beqz	s3,80004198 <exec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    8000418c:	e2843c03          	ld	s8,-472(s0)
    80004190:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004194:	4481                	li	s1,0
    80004196:	bfb1                	j	800040f2 <exec+0xf6>
    sz = sz1;
    80004198:	df843903          	ld	s2,-520(s0)
    8000419c:	bfad                	j	80004116 <exec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000419e:	4901                	li	s2,0
  iunlockput(ip);
    800041a0:	8552                	mv	a0,s4
    800041a2:	d35fe0ef          	jal	80002ed6 <iunlockput>
  end_op();
    800041a6:	c4cff0ef          	jal	800035f2 <end_op>
  p = myproc();
    800041aa:	f5bfc0ef          	jal	80001104 <myproc>
    800041ae:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    800041b0:	05053d03          	ld	s10,80(a0)
  sz = PGROUNDUP(sz);
    800041b4:	6985                	lui	s3,0x1
    800041b6:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    800041b8:	99ca                	add	s3,s3,s2
    800041ba:	77fd                	lui	a5,0xfffff
    800041bc:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800041c0:	4691                	li	a3,4
    800041c2:	6609                	lui	a2,0x2
    800041c4:	964e                	add	a2,a2,s3
    800041c6:	85ce                	mv	a1,s3
    800041c8:	855a                	mv	a0,s6
    800041ca:	9abfc0ef          	jal	80000b74 <uvmalloc>
    800041ce:	8a2a                	mv	s4,a0
    800041d0:	e105                	bnez	a0,800041f0 <exec+0x1f4>
    proc_freepagetable(pagetable, sz);
    800041d2:	85ce                	mv	a1,s3
    800041d4:	855a                	mv	a0,s6
    800041d6:	85cfd0ef          	jal	80001232 <proc_freepagetable>
  return -1;
    800041da:	557d                	li	a0,-1
    800041dc:	79fe                	ld	s3,504(sp)
    800041de:	7a5e                	ld	s4,496(sp)
    800041e0:	7abe                	ld	s5,488(sp)
    800041e2:	7b1e                	ld	s6,480(sp)
    800041e4:	6bfe                	ld	s7,472(sp)
    800041e6:	6c5e                	ld	s8,464(sp)
    800041e8:	6cbe                	ld	s9,456(sp)
    800041ea:	6d1e                	ld	s10,448(sp)
    800041ec:	7dfa                	ld	s11,440(sp)
    800041ee:	b541                	j	8000406e <exec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800041f0:	75f9                	lui	a1,0xffffe
    800041f2:	95aa                	add	a1,a1,a0
    800041f4:	855a                	mv	a0,s6
    800041f6:	b65fc0ef          	jal	80000d5a <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800041fa:	800a0b93          	addi	s7,s4,-2048
    800041fe:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80004202:	e0043783          	ld	a5,-512(s0)
    80004206:	6388                	ld	a0,0(a5)
  sp = sz;
    80004208:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    8000420a:	4481                	li	s1,0
    ustack[argc] = sp;
    8000420c:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80004210:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80004214:	cd21                	beqz	a0,8000426c <exec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80004216:	c4cfc0ef          	jal	80000662 <strlen>
    8000421a:	0015079b          	addiw	a5,a0,1
    8000421e:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004222:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004226:	13796563          	bltu	s2,s7,80004350 <exec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    8000422a:	e0043d83          	ld	s11,-512(s0)
    8000422e:	000db983          	ld	s3,0(s11)
    80004232:	854e                	mv	a0,s3
    80004234:	c2efc0ef          	jal	80000662 <strlen>
    80004238:	0015069b          	addiw	a3,a0,1
    8000423c:	864e                	mv	a2,s3
    8000423e:	85ca                	mv	a1,s2
    80004240:	855a                	mv	a0,s6
    80004242:	b43fc0ef          	jal	80000d84 <copyout>
    80004246:	10054763          	bltz	a0,80004354 <exec+0x358>
    ustack[argc] = sp;
    8000424a:	00349793          	slli	a5,s1,0x3
    8000424e:	97e6                	add	a5,a5,s9
    80004250:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffd9978>
  for(argc = 0; argv[argc]; argc++) {
    80004254:	0485                	addi	s1,s1,1
    80004256:	008d8793          	addi	a5,s11,8
    8000425a:	e0f43023          	sd	a5,-512(s0)
    8000425e:	008db503          	ld	a0,8(s11)
    80004262:	c509                	beqz	a0,8000426c <exec+0x270>
    if(argc >= MAXARG)
    80004264:	fb8499e3          	bne	s1,s8,80004216 <exec+0x21a>
  sz = sz1;
    80004268:	89d2                	mv	s3,s4
    8000426a:	b7a5                	j	800041d2 <exec+0x1d6>
  ustack[argc] = 0;
    8000426c:	00349793          	slli	a5,s1,0x3
    80004270:	f9078793          	addi	a5,a5,-112
    80004274:	97a2                	add	a5,a5,s0
    80004276:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    8000427a:	00349693          	slli	a3,s1,0x3
    8000427e:	06a1                	addi	a3,a3,8
    80004280:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004284:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004288:	89d2                	mv	s3,s4
  if(sp < stackbase)
    8000428a:	f57964e3          	bltu	s2,s7,800041d2 <exec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    8000428e:	e9040613          	addi	a2,s0,-368
    80004292:	85ca                	mv	a1,s2
    80004294:	855a                	mv	a0,s6
    80004296:	aeffc0ef          	jal	80000d84 <copyout>
    8000429a:	f2054ce3          	bltz	a0,800041d2 <exec+0x1d6>
  p->trapframe->a1 = sp;
    8000429e:	060ab783          	ld	a5,96(s5) # 1060 <_entry-0x7fffefa0>
    800042a2:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    800042a6:	df043783          	ld	a5,-528(s0)
    800042aa:	0007c703          	lbu	a4,0(a5)
    800042ae:	cf11                	beqz	a4,800042ca <exec+0x2ce>
    800042b0:	0785                	addi	a5,a5,1
    if(*s == '/')
    800042b2:	02f00693          	li	a3,47
    800042b6:	a029                	j	800042c0 <exec+0x2c4>
  for(last=s=path; *s; s++)
    800042b8:	0785                	addi	a5,a5,1
    800042ba:	fff7c703          	lbu	a4,-1(a5)
    800042be:	c711                	beqz	a4,800042ca <exec+0x2ce>
    if(*s == '/')
    800042c0:	fed71ce3          	bne	a4,a3,800042b8 <exec+0x2bc>
      last = s+1;
    800042c4:	def43823          	sd	a5,-528(s0)
    800042c8:	bfc5                	j	800042b8 <exec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    800042ca:	4641                	li	a2,16
    800042cc:	df043583          	ld	a1,-528(s0)
    800042d0:	160a8513          	addi	a0,s5,352
    800042d4:	b58fc0ef          	jal	8000062c <safestrcpy>
  oldpagetable = p->pagetable;
    800042d8:	058ab503          	ld	a0,88(s5)
  p->pagetable = pagetable;
    800042dc:	056abc23          	sd	s6,88(s5)
  p->sz = sz;
    800042e0:	054ab823          	sd	s4,80(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    800042e4:	060ab783          	ld	a5,96(s5)
    800042e8:	e6843703          	ld	a4,-408(s0)
    800042ec:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800042ee:	060ab783          	ld	a5,96(s5)
    800042f2:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800042f6:	85ea                	mv	a1,s10
    800042f8:	f3bfc0ef          	jal	80001232 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    800042fc:	0004851b          	sext.w	a0,s1
    80004300:	79fe                	ld	s3,504(sp)
    80004302:	7a5e                	ld	s4,496(sp)
    80004304:	7abe                	ld	s5,488(sp)
    80004306:	7b1e                	ld	s6,480(sp)
    80004308:	6bfe                	ld	s7,472(sp)
    8000430a:	6c5e                	ld	s8,464(sp)
    8000430c:	6cbe                	ld	s9,456(sp)
    8000430e:	6d1e                	ld	s10,448(sp)
    80004310:	7dfa                	ld	s11,440(sp)
    80004312:	bbb1                	j	8000406e <exec+0x72>
    80004314:	7b1e                	ld	s6,480(sp)
    80004316:	b3a9                	j	80004060 <exec+0x64>
    80004318:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    8000431c:	df843583          	ld	a1,-520(s0)
    80004320:	855a                	mv	a0,s6
    80004322:	f11fc0ef          	jal	80001232 <proc_freepagetable>
  if(ip){
    80004326:	79fe                	ld	s3,504(sp)
    80004328:	7abe                	ld	s5,488(sp)
    8000432a:	7b1e                	ld	s6,480(sp)
    8000432c:	6bfe                	ld	s7,472(sp)
    8000432e:	6c5e                	ld	s8,464(sp)
    80004330:	6cbe                	ld	s9,456(sp)
    80004332:	6d1e                	ld	s10,448(sp)
    80004334:	7dfa                	ld	s11,440(sp)
    80004336:	b32d                	j	80004060 <exec+0x64>
    80004338:	df243c23          	sd	s2,-520(s0)
    8000433c:	b7c5                	j	8000431c <exec+0x320>
    8000433e:	df243c23          	sd	s2,-520(s0)
    80004342:	bfe9                	j	8000431c <exec+0x320>
    80004344:	df243c23          	sd	s2,-520(s0)
    80004348:	bfd1                	j	8000431c <exec+0x320>
    8000434a:	df243c23          	sd	s2,-520(s0)
    8000434e:	b7f9                	j	8000431c <exec+0x320>
  sz = sz1;
    80004350:	89d2                	mv	s3,s4
    80004352:	b541                	j	800041d2 <exec+0x1d6>
    80004354:	89d2                	mv	s3,s4
    80004356:	bdb5                	j	800041d2 <exec+0x1d6>

0000000080004358 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004358:	7179                	addi	sp,sp,-48
    8000435a:	f406                	sd	ra,40(sp)
    8000435c:	f022                	sd	s0,32(sp)
    8000435e:	ec26                	sd	s1,24(sp)
    80004360:	e84a                	sd	s2,16(sp)
    80004362:	1800                	addi	s0,sp,48
    80004364:	892e                	mv	s2,a1
    80004366:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004368:	fdc40593          	addi	a1,s0,-36
    8000436c:	c59fd0ef          	jal	80001fc4 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004370:	fdc42703          	lw	a4,-36(s0)
    80004374:	47bd                	li	a5,15
    80004376:	02e7ea63          	bltu	a5,a4,800043aa <argfd+0x52>
    8000437a:	d8bfc0ef          	jal	80001104 <myproc>
    8000437e:	fdc42703          	lw	a4,-36(s0)
    80004382:	00371793          	slli	a5,a4,0x3
    80004386:	0d078793          	addi	a5,a5,208
    8000438a:	953e                	add	a0,a0,a5
    8000438c:	651c                	ld	a5,8(a0)
    8000438e:	c385                	beqz	a5,800043ae <argfd+0x56>
    return -1;
  if(pfd)
    80004390:	00090463          	beqz	s2,80004398 <argfd+0x40>
    *pfd = fd;
    80004394:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004398:	4501                	li	a0,0
  if(pf)
    8000439a:	c091                	beqz	s1,8000439e <argfd+0x46>
    *pf = f;
    8000439c:	e09c                	sd	a5,0(s1)
}
    8000439e:	70a2                	ld	ra,40(sp)
    800043a0:	7402                	ld	s0,32(sp)
    800043a2:	64e2                	ld	s1,24(sp)
    800043a4:	6942                	ld	s2,16(sp)
    800043a6:	6145                	addi	sp,sp,48
    800043a8:	8082                	ret
    return -1;
    800043aa:	557d                	li	a0,-1
    800043ac:	bfcd                	j	8000439e <argfd+0x46>
    800043ae:	557d                	li	a0,-1
    800043b0:	b7fd                	j	8000439e <argfd+0x46>

00000000800043b2 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    800043b2:	1101                	addi	sp,sp,-32
    800043b4:	ec06                	sd	ra,24(sp)
    800043b6:	e822                	sd	s0,16(sp)
    800043b8:	e426                	sd	s1,8(sp)
    800043ba:	1000                	addi	s0,sp,32
    800043bc:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    800043be:	d47fc0ef          	jal	80001104 <myproc>
    800043c2:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    800043c4:	0d850793          	addi	a5,a0,216
    800043c8:	4501                	li	a0,0
    800043ca:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    800043cc:	6398                	ld	a4,0(a5)
    800043ce:	cb19                	beqz	a4,800043e4 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    800043d0:	2505                	addiw	a0,a0,1
    800043d2:	07a1                	addi	a5,a5,8
    800043d4:	fed51ce3          	bne	a0,a3,800043cc <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    800043d8:	557d                	li	a0,-1
}
    800043da:	60e2                	ld	ra,24(sp)
    800043dc:	6442                	ld	s0,16(sp)
    800043de:	64a2                	ld	s1,8(sp)
    800043e0:	6105                	addi	sp,sp,32
    800043e2:	8082                	ret
      p->ofile[fd] = f;
    800043e4:	00351793          	slli	a5,a0,0x3
    800043e8:	0d078793          	addi	a5,a5,208
    800043ec:	963e                	add	a2,a2,a5
    800043ee:	e604                	sd	s1,8(a2)
      return fd;
    800043f0:	b7ed                	j	800043da <fdalloc+0x28>

00000000800043f2 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    800043f2:	715d                	addi	sp,sp,-80
    800043f4:	e486                	sd	ra,72(sp)
    800043f6:	e0a2                	sd	s0,64(sp)
    800043f8:	fc26                	sd	s1,56(sp)
    800043fa:	f84a                	sd	s2,48(sp)
    800043fc:	f44e                	sd	s3,40(sp)
    800043fe:	f052                	sd	s4,32(sp)
    80004400:	ec56                	sd	s5,24(sp)
    80004402:	e85a                	sd	s6,16(sp)
    80004404:	0880                	addi	s0,sp,80
    80004406:	892e                	mv	s2,a1
    80004408:	8a2e                	mv	s4,a1
    8000440a:	8ab2                	mv	s5,a2
    8000440c:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    8000440e:	fb040593          	addi	a1,s0,-80
    80004412:	fc9fe0ef          	jal	800033da <nameiparent>
    80004416:	84aa                	mv	s1,a0
    80004418:	10050763          	beqz	a0,80004526 <create+0x134>
    return 0;

  ilock(dp);
    8000441c:	8a3fe0ef          	jal	80002cbe <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004420:	4601                	li	a2,0
    80004422:	fb040593          	addi	a1,s0,-80
    80004426:	8526                	mv	a0,s1
    80004428:	d05fe0ef          	jal	8000312c <dirlookup>
    8000442c:	89aa                	mv	s3,a0
    8000442e:	c131                	beqz	a0,80004472 <create+0x80>
    iunlockput(dp);
    80004430:	8526                	mv	a0,s1
    80004432:	aa5fe0ef          	jal	80002ed6 <iunlockput>
    ilock(ip);
    80004436:	854e                	mv	a0,s3
    80004438:	887fe0ef          	jal	80002cbe <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    8000443c:	4789                	li	a5,2
    8000443e:	02f91563          	bne	s2,a5,80004468 <create+0x76>
    80004442:	04c9d783          	lhu	a5,76(s3)
    80004446:	37f9                	addiw	a5,a5,-2
    80004448:	17c2                	slli	a5,a5,0x30
    8000444a:	93c1                	srli	a5,a5,0x30
    8000444c:	4705                	li	a4,1
    8000444e:	00f76d63          	bltu	a4,a5,80004468 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004452:	854e                	mv	a0,s3
    80004454:	60a6                	ld	ra,72(sp)
    80004456:	6406                	ld	s0,64(sp)
    80004458:	74e2                	ld	s1,56(sp)
    8000445a:	7942                	ld	s2,48(sp)
    8000445c:	79a2                	ld	s3,40(sp)
    8000445e:	7a02                	ld	s4,32(sp)
    80004460:	6ae2                	ld	s5,24(sp)
    80004462:	6b42                	ld	s6,16(sp)
    80004464:	6161                	addi	sp,sp,80
    80004466:	8082                	ret
    iunlockput(ip);
    80004468:	854e                	mv	a0,s3
    8000446a:	a6dfe0ef          	jal	80002ed6 <iunlockput>
    return 0;
    8000446e:	4981                	li	s3,0
    80004470:	b7cd                	j	80004452 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004472:	85ca                	mv	a1,s2
    80004474:	4088                	lw	a0,0(s1)
    80004476:	ed8fe0ef          	jal	80002b4e <ialloc>
    8000447a:	892a                	mv	s2,a0
    8000447c:	cd15                	beqz	a0,800044b8 <create+0xc6>
  ilock(ip);
    8000447e:	841fe0ef          	jal	80002cbe <ilock>
  ip->major = major;
    80004482:	05591723          	sh	s5,78(s2)
  ip->minor = minor;
    80004486:	05691823          	sh	s6,80(s2)
  ip->nlink = 1;
    8000448a:	4785                	li	a5,1
    8000448c:	04f91923          	sh	a5,82(s2)
  iupdate(ip);
    80004490:	854a                	mv	a0,s2
    80004492:	f78fe0ef          	jal	80002c0a <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004496:	4705                	li	a4,1
    80004498:	02ea0463          	beq	s4,a4,800044c0 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    8000449c:	00492603          	lw	a2,4(s2)
    800044a0:	fb040593          	addi	a1,s0,-80
    800044a4:	8526                	mv	a0,s1
    800044a6:	e71fe0ef          	jal	80003316 <dirlink>
    800044aa:	06054263          	bltz	a0,8000450e <create+0x11c>
  iunlockput(dp);
    800044ae:	8526                	mv	a0,s1
    800044b0:	a27fe0ef          	jal	80002ed6 <iunlockput>
  return ip;
    800044b4:	89ca                	mv	s3,s2
    800044b6:	bf71                	j	80004452 <create+0x60>
    iunlockput(dp);
    800044b8:	8526                	mv	a0,s1
    800044ba:	a1dfe0ef          	jal	80002ed6 <iunlockput>
    return 0;
    800044be:	bf51                	j	80004452 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    800044c0:	00492603          	lw	a2,4(s2)
    800044c4:	00004597          	auipc	a1,0x4
    800044c8:	13c58593          	addi	a1,a1,316 # 80008600 <etext+0x600>
    800044cc:	854a                	mv	a0,s2
    800044ce:	e49fe0ef          	jal	80003316 <dirlink>
    800044d2:	02054e63          	bltz	a0,8000450e <create+0x11c>
    800044d6:	40d0                	lw	a2,4(s1)
    800044d8:	00004597          	auipc	a1,0x4
    800044dc:	13058593          	addi	a1,a1,304 # 80008608 <etext+0x608>
    800044e0:	854a                	mv	a0,s2
    800044e2:	e35fe0ef          	jal	80003316 <dirlink>
    800044e6:	02054463          	bltz	a0,8000450e <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    800044ea:	00492603          	lw	a2,4(s2)
    800044ee:	fb040593          	addi	a1,s0,-80
    800044f2:	8526                	mv	a0,s1
    800044f4:	e23fe0ef          	jal	80003316 <dirlink>
    800044f8:	00054b63          	bltz	a0,8000450e <create+0x11c>
    dp->nlink++;  // for ".."
    800044fc:	0524d783          	lhu	a5,82(s1)
    80004500:	2785                	addiw	a5,a5,1
    80004502:	04f49923          	sh	a5,82(s1)
    iupdate(dp);
    80004506:	8526                	mv	a0,s1
    80004508:	f02fe0ef          	jal	80002c0a <iupdate>
    8000450c:	b74d                	j	800044ae <create+0xbc>
  ip->nlink = 0;
    8000450e:	04091923          	sh	zero,82(s2)
  iupdate(ip);
    80004512:	854a                	mv	a0,s2
    80004514:	ef6fe0ef          	jal	80002c0a <iupdate>
  iunlockput(ip);
    80004518:	854a                	mv	a0,s2
    8000451a:	9bdfe0ef          	jal	80002ed6 <iunlockput>
  iunlockput(dp);
    8000451e:	8526                	mv	a0,s1
    80004520:	9b7fe0ef          	jal	80002ed6 <iunlockput>
  return 0;
    80004524:	b73d                	j	80004452 <create+0x60>
    return 0;
    80004526:	89aa                	mv	s3,a0
    80004528:	b72d                	j	80004452 <create+0x60>

000000008000452a <sys_dup>:
{
    8000452a:	7179                	addi	sp,sp,-48
    8000452c:	f406                	sd	ra,40(sp)
    8000452e:	f022                	sd	s0,32(sp)
    80004530:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004532:	fd840613          	addi	a2,s0,-40
    80004536:	4581                	li	a1,0
    80004538:	4501                	li	a0,0
    8000453a:	e1fff0ef          	jal	80004358 <argfd>
    return -1;
    8000453e:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004540:	02054363          	bltz	a0,80004566 <sys_dup+0x3c>
    80004544:	ec26                	sd	s1,24(sp)
    80004546:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004548:	fd843483          	ld	s1,-40(s0)
    8000454c:	8526                	mv	a0,s1
    8000454e:	e65ff0ef          	jal	800043b2 <fdalloc>
    80004552:	892a                	mv	s2,a0
    return -1;
    80004554:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004556:	00054d63          	bltz	a0,80004570 <sys_dup+0x46>
  filedup(f);
    8000455a:	8526                	mv	a0,s1
    8000455c:	c12ff0ef          	jal	8000396e <filedup>
  return fd;
    80004560:	87ca                	mv	a5,s2
    80004562:	64e2                	ld	s1,24(sp)
    80004564:	6942                	ld	s2,16(sp)
}
    80004566:	853e                	mv	a0,a5
    80004568:	70a2                	ld	ra,40(sp)
    8000456a:	7402                	ld	s0,32(sp)
    8000456c:	6145                	addi	sp,sp,48
    8000456e:	8082                	ret
    80004570:	64e2                	ld	s1,24(sp)
    80004572:	6942                	ld	s2,16(sp)
    80004574:	bfcd                	j	80004566 <sys_dup+0x3c>

0000000080004576 <sys_read>:
{
    80004576:	7179                	addi	sp,sp,-48
    80004578:	f406                	sd	ra,40(sp)
    8000457a:	f022                	sd	s0,32(sp)
    8000457c:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000457e:	fd840593          	addi	a1,s0,-40
    80004582:	4505                	li	a0,1
    80004584:	a5dfd0ef          	jal	80001fe0 <argaddr>
  argint(2, &n);
    80004588:	fe440593          	addi	a1,s0,-28
    8000458c:	4509                	li	a0,2
    8000458e:	a37fd0ef          	jal	80001fc4 <argint>
  if(argfd(0, 0, &f) < 0)
    80004592:	fe840613          	addi	a2,s0,-24
    80004596:	4581                	li	a1,0
    80004598:	4501                	li	a0,0
    8000459a:	dbfff0ef          	jal	80004358 <argfd>
    8000459e:	87aa                	mv	a5,a0
    return -1;
    800045a0:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800045a2:	0007ca63          	bltz	a5,800045b6 <sys_read+0x40>
  return fileread(f, p, n);
    800045a6:	fe442603          	lw	a2,-28(s0)
    800045aa:	fd843583          	ld	a1,-40(s0)
    800045ae:	fe843503          	ld	a0,-24(s0)
    800045b2:	d26ff0ef          	jal	80003ad8 <fileread>
}
    800045b6:	70a2                	ld	ra,40(sp)
    800045b8:	7402                	ld	s0,32(sp)
    800045ba:	6145                	addi	sp,sp,48
    800045bc:	8082                	ret

00000000800045be <sys_write>:
{
    800045be:	7179                	addi	sp,sp,-48
    800045c0:	f406                	sd	ra,40(sp)
    800045c2:	f022                	sd	s0,32(sp)
    800045c4:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800045c6:	fd840593          	addi	a1,s0,-40
    800045ca:	4505                	li	a0,1
    800045cc:	a15fd0ef          	jal	80001fe0 <argaddr>
  argint(2, &n);
    800045d0:	fe440593          	addi	a1,s0,-28
    800045d4:	4509                	li	a0,2
    800045d6:	9effd0ef          	jal	80001fc4 <argint>
  if(argfd(0, 0, &f) < 0)
    800045da:	fe840613          	addi	a2,s0,-24
    800045de:	4581                	li	a1,0
    800045e0:	4501                	li	a0,0
    800045e2:	d77ff0ef          	jal	80004358 <argfd>
    800045e6:	87aa                	mv	a5,a0
    return -1;
    800045e8:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800045ea:	0007ca63          	bltz	a5,800045fe <sys_write+0x40>
  return filewrite(f, p, n);
    800045ee:	fe442603          	lw	a2,-28(s0)
    800045f2:	fd843583          	ld	a1,-40(s0)
    800045f6:	fe843503          	ld	a0,-24(s0)
    800045fa:	da2ff0ef          	jal	80003b9c <filewrite>
}
    800045fe:	70a2                	ld	ra,40(sp)
    80004600:	7402                	ld	s0,32(sp)
    80004602:	6145                	addi	sp,sp,48
    80004604:	8082                	ret

0000000080004606 <sys_close>:
{
    80004606:	1101                	addi	sp,sp,-32
    80004608:	ec06                	sd	ra,24(sp)
    8000460a:	e822                	sd	s0,16(sp)
    8000460c:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    8000460e:	fe040613          	addi	a2,s0,-32
    80004612:	fec40593          	addi	a1,s0,-20
    80004616:	4501                	li	a0,0
    80004618:	d41ff0ef          	jal	80004358 <argfd>
    return -1;
    8000461c:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    8000461e:	02054163          	bltz	a0,80004640 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80004622:	ae3fc0ef          	jal	80001104 <myproc>
    80004626:	fec42783          	lw	a5,-20(s0)
    8000462a:	078e                	slli	a5,a5,0x3
    8000462c:	0d078793          	addi	a5,a5,208
    80004630:	953e                	add	a0,a0,a5
    80004632:	00053423          	sd	zero,8(a0)
  fileclose(f);
    80004636:	fe043503          	ld	a0,-32(s0)
    8000463a:	b7aff0ef          	jal	800039b4 <fileclose>
  return 0;
    8000463e:	4781                	li	a5,0
}
    80004640:	853e                	mv	a0,a5
    80004642:	60e2                	ld	ra,24(sp)
    80004644:	6442                	ld	s0,16(sp)
    80004646:	6105                	addi	sp,sp,32
    80004648:	8082                	ret

000000008000464a <sys_fstat>:
{
    8000464a:	1101                	addi	sp,sp,-32
    8000464c:	ec06                	sd	ra,24(sp)
    8000464e:	e822                	sd	s0,16(sp)
    80004650:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004652:	fe040593          	addi	a1,s0,-32
    80004656:	4505                	li	a0,1
    80004658:	989fd0ef          	jal	80001fe0 <argaddr>
  if(argfd(0, 0, &f) < 0)
    8000465c:	fe840613          	addi	a2,s0,-24
    80004660:	4581                	li	a1,0
    80004662:	4501                	li	a0,0
    80004664:	cf5ff0ef          	jal	80004358 <argfd>
    80004668:	87aa                	mv	a5,a0
    return -1;
    8000466a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000466c:	0007c863          	bltz	a5,8000467c <sys_fstat+0x32>
  return filestat(f, st);
    80004670:	fe043583          	ld	a1,-32(s0)
    80004674:	fe843503          	ld	a0,-24(s0)
    80004678:	bfeff0ef          	jal	80003a76 <filestat>
}
    8000467c:	60e2                	ld	ra,24(sp)
    8000467e:	6442                	ld	s0,16(sp)
    80004680:	6105                	addi	sp,sp,32
    80004682:	8082                	ret

0000000080004684 <sys_link>:
{
    80004684:	7169                	addi	sp,sp,-304
    80004686:	f606                	sd	ra,296(sp)
    80004688:	f222                	sd	s0,288(sp)
    8000468a:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000468c:	08000613          	li	a2,128
    80004690:	ed040593          	addi	a1,s0,-304
    80004694:	4501                	li	a0,0
    80004696:	967fd0ef          	jal	80001ffc <argstr>
    return -1;
    8000469a:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000469c:	0c054e63          	bltz	a0,80004778 <sys_link+0xf4>
    800046a0:	08000613          	li	a2,128
    800046a4:	f5040593          	addi	a1,s0,-176
    800046a8:	4505                	li	a0,1
    800046aa:	953fd0ef          	jal	80001ffc <argstr>
    return -1;
    800046ae:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800046b0:	0c054463          	bltz	a0,80004778 <sys_link+0xf4>
    800046b4:	ee26                	sd	s1,280(sp)
  begin_op();
    800046b6:	ecdfe0ef          	jal	80003582 <begin_op>
  if((ip = namei(old)) == 0){
    800046ba:	ed040513          	addi	a0,s0,-304
    800046be:	d03fe0ef          	jal	800033c0 <namei>
    800046c2:	84aa                	mv	s1,a0
    800046c4:	c53d                	beqz	a0,80004732 <sys_link+0xae>
  ilock(ip);
    800046c6:	df8fe0ef          	jal	80002cbe <ilock>
  if(ip->type == T_DIR){
    800046ca:	04c49703          	lh	a4,76(s1)
    800046ce:	4785                	li	a5,1
    800046d0:	06f70663          	beq	a4,a5,8000473c <sys_link+0xb8>
    800046d4:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    800046d6:	0524d783          	lhu	a5,82(s1)
    800046da:	2785                	addiw	a5,a5,1
    800046dc:	04f49923          	sh	a5,82(s1)
  iupdate(ip);
    800046e0:	8526                	mv	a0,s1
    800046e2:	d28fe0ef          	jal	80002c0a <iupdate>
  iunlock(ip);
    800046e6:	8526                	mv	a0,s1
    800046e8:	e8afe0ef          	jal	80002d72 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800046ec:	fd040593          	addi	a1,s0,-48
    800046f0:	f5040513          	addi	a0,s0,-176
    800046f4:	ce7fe0ef          	jal	800033da <nameiparent>
    800046f8:	892a                	mv	s2,a0
    800046fa:	cd21                	beqz	a0,80004752 <sys_link+0xce>
  ilock(dp);
    800046fc:	dc2fe0ef          	jal	80002cbe <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004700:	854a                	mv	a0,s2
    80004702:	00092703          	lw	a4,0(s2)
    80004706:	409c                	lw	a5,0(s1)
    80004708:	04f71263          	bne	a4,a5,8000474c <sys_link+0xc8>
    8000470c:	40d0                	lw	a2,4(s1)
    8000470e:	fd040593          	addi	a1,s0,-48
    80004712:	c05fe0ef          	jal	80003316 <dirlink>
    80004716:	02054b63          	bltz	a0,8000474c <sys_link+0xc8>
  iunlockput(dp);
    8000471a:	854a                	mv	a0,s2
    8000471c:	fbafe0ef          	jal	80002ed6 <iunlockput>
  iput(ip);
    80004720:	8526                	mv	a0,s1
    80004722:	f2afe0ef          	jal	80002e4c <iput>
  end_op();
    80004726:	ecdfe0ef          	jal	800035f2 <end_op>
  return 0;
    8000472a:	4781                	li	a5,0
    8000472c:	64f2                	ld	s1,280(sp)
    8000472e:	6952                	ld	s2,272(sp)
    80004730:	a0a1                	j	80004778 <sys_link+0xf4>
    end_op();
    80004732:	ec1fe0ef          	jal	800035f2 <end_op>
    return -1;
    80004736:	57fd                	li	a5,-1
    80004738:	64f2                	ld	s1,280(sp)
    8000473a:	a83d                	j	80004778 <sys_link+0xf4>
    iunlockput(ip);
    8000473c:	8526                	mv	a0,s1
    8000473e:	f98fe0ef          	jal	80002ed6 <iunlockput>
    end_op();
    80004742:	eb1fe0ef          	jal	800035f2 <end_op>
    return -1;
    80004746:	57fd                	li	a5,-1
    80004748:	64f2                	ld	s1,280(sp)
    8000474a:	a03d                	j	80004778 <sys_link+0xf4>
    iunlockput(dp);
    8000474c:	854a                	mv	a0,s2
    8000474e:	f88fe0ef          	jal	80002ed6 <iunlockput>
  ilock(ip);
    80004752:	8526                	mv	a0,s1
    80004754:	d6afe0ef          	jal	80002cbe <ilock>
  ip->nlink--;
    80004758:	0524d783          	lhu	a5,82(s1)
    8000475c:	37fd                	addiw	a5,a5,-1
    8000475e:	04f49923          	sh	a5,82(s1)
  iupdate(ip);
    80004762:	8526                	mv	a0,s1
    80004764:	ca6fe0ef          	jal	80002c0a <iupdate>
  iunlockput(ip);
    80004768:	8526                	mv	a0,s1
    8000476a:	f6cfe0ef          	jal	80002ed6 <iunlockput>
  end_op();
    8000476e:	e85fe0ef          	jal	800035f2 <end_op>
  return -1;
    80004772:	57fd                	li	a5,-1
    80004774:	64f2                	ld	s1,280(sp)
    80004776:	6952                	ld	s2,272(sp)
}
    80004778:	853e                	mv	a0,a5
    8000477a:	70b2                	ld	ra,296(sp)
    8000477c:	7412                	ld	s0,288(sp)
    8000477e:	6155                	addi	sp,sp,304
    80004780:	8082                	ret

0000000080004782 <sys_unlink>:
{
    80004782:	7151                	addi	sp,sp,-240
    80004784:	f586                	sd	ra,232(sp)
    80004786:	f1a2                	sd	s0,224(sp)
    80004788:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000478a:	08000613          	li	a2,128
    8000478e:	f3040593          	addi	a1,s0,-208
    80004792:	4501                	li	a0,0
    80004794:	869fd0ef          	jal	80001ffc <argstr>
    80004798:	14054d63          	bltz	a0,800048f2 <sys_unlink+0x170>
    8000479c:	eda6                	sd	s1,216(sp)
  begin_op();
    8000479e:	de5fe0ef          	jal	80003582 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    800047a2:	fb040593          	addi	a1,s0,-80
    800047a6:	f3040513          	addi	a0,s0,-208
    800047aa:	c31fe0ef          	jal	800033da <nameiparent>
    800047ae:	84aa                	mv	s1,a0
    800047b0:	c955                	beqz	a0,80004864 <sys_unlink+0xe2>
  ilock(dp);
    800047b2:	d0cfe0ef          	jal	80002cbe <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800047b6:	00004597          	auipc	a1,0x4
    800047ba:	e4a58593          	addi	a1,a1,-438 # 80008600 <etext+0x600>
    800047be:	fb040513          	addi	a0,s0,-80
    800047c2:	955fe0ef          	jal	80003116 <namecmp>
    800047c6:	10050b63          	beqz	a0,800048dc <sys_unlink+0x15a>
    800047ca:	00004597          	auipc	a1,0x4
    800047ce:	e3e58593          	addi	a1,a1,-450 # 80008608 <etext+0x608>
    800047d2:	fb040513          	addi	a0,s0,-80
    800047d6:	941fe0ef          	jal	80003116 <namecmp>
    800047da:	10050163          	beqz	a0,800048dc <sys_unlink+0x15a>
    800047de:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    800047e0:	f2c40613          	addi	a2,s0,-212
    800047e4:	fb040593          	addi	a1,s0,-80
    800047e8:	8526                	mv	a0,s1
    800047ea:	943fe0ef          	jal	8000312c <dirlookup>
    800047ee:	892a                	mv	s2,a0
    800047f0:	0e050563          	beqz	a0,800048da <sys_unlink+0x158>
    800047f4:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800047f6:	cc8fe0ef          	jal	80002cbe <ilock>
  if(ip->nlink < 1)
    800047fa:	05291783          	lh	a5,82(s2)
    800047fe:	06f05863          	blez	a5,8000486e <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004802:	04c91703          	lh	a4,76(s2)
    80004806:	4785                	li	a5,1
    80004808:	06f70963          	beq	a4,a5,8000487a <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    8000480c:	fc040993          	addi	s3,s0,-64
    80004810:	4641                	li	a2,16
    80004812:	4581                	li	a1,0
    80004814:	854e                	mv	a0,s3
    80004816:	cc3fb0ef          	jal	800004d8 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000481a:	4741                	li	a4,16
    8000481c:	f2c42683          	lw	a3,-212(s0)
    80004820:	864e                	mv	a2,s3
    80004822:	4581                	li	a1,0
    80004824:	8526                	mv	a0,s1
    80004826:	ff0fe0ef          	jal	80003016 <writei>
    8000482a:	47c1                	li	a5,16
    8000482c:	08f51863          	bne	a0,a5,800048bc <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    80004830:	04c91703          	lh	a4,76(s2)
    80004834:	4785                	li	a5,1
    80004836:	08f70963          	beq	a4,a5,800048c8 <sys_unlink+0x146>
  iunlockput(dp);
    8000483a:	8526                	mv	a0,s1
    8000483c:	e9afe0ef          	jal	80002ed6 <iunlockput>
  ip->nlink--;
    80004840:	05295783          	lhu	a5,82(s2)
    80004844:	37fd                	addiw	a5,a5,-1
    80004846:	04f91923          	sh	a5,82(s2)
  iupdate(ip);
    8000484a:	854a                	mv	a0,s2
    8000484c:	bbefe0ef          	jal	80002c0a <iupdate>
  iunlockput(ip);
    80004850:	854a                	mv	a0,s2
    80004852:	e84fe0ef          	jal	80002ed6 <iunlockput>
  end_op();
    80004856:	d9dfe0ef          	jal	800035f2 <end_op>
  return 0;
    8000485a:	4501                	li	a0,0
    8000485c:	64ee                	ld	s1,216(sp)
    8000485e:	694e                	ld	s2,208(sp)
    80004860:	69ae                	ld	s3,200(sp)
    80004862:	a061                	j	800048ea <sys_unlink+0x168>
    end_op();
    80004864:	d8ffe0ef          	jal	800035f2 <end_op>
    return -1;
    80004868:	557d                	li	a0,-1
    8000486a:	64ee                	ld	s1,216(sp)
    8000486c:	a8bd                	j	800048ea <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    8000486e:	00004517          	auipc	a0,0x4
    80004872:	da250513          	addi	a0,a0,-606 # 80008610 <etext+0x610>
    80004876:	60c010ef          	jal	80005e82 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000487a:	05492703          	lw	a4,84(s2)
    8000487e:	02000793          	li	a5,32
    80004882:	f8e7f5e3          	bgeu	a5,a4,8000480c <sys_unlink+0x8a>
    80004886:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004888:	4741                	li	a4,16
    8000488a:	86ce                	mv	a3,s3
    8000488c:	f1840613          	addi	a2,s0,-232
    80004890:	4581                	li	a1,0
    80004892:	854a                	mv	a0,s2
    80004894:	e90fe0ef          	jal	80002f24 <readi>
    80004898:	47c1                	li	a5,16
    8000489a:	00f51b63          	bne	a0,a5,800048b0 <sys_unlink+0x12e>
    if(de.inum != 0)
    8000489e:	f1845783          	lhu	a5,-232(s0)
    800048a2:	ebb1                	bnez	a5,800048f6 <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800048a4:	29c1                	addiw	s3,s3,16
    800048a6:	05492783          	lw	a5,84(s2)
    800048aa:	fcf9efe3          	bltu	s3,a5,80004888 <sys_unlink+0x106>
    800048ae:	bfb9                	j	8000480c <sys_unlink+0x8a>
      panic("isdirempty: readi");
    800048b0:	00004517          	auipc	a0,0x4
    800048b4:	d7850513          	addi	a0,a0,-648 # 80008628 <etext+0x628>
    800048b8:	5ca010ef          	jal	80005e82 <panic>
    panic("unlink: writei");
    800048bc:	00004517          	auipc	a0,0x4
    800048c0:	d8450513          	addi	a0,a0,-636 # 80008640 <etext+0x640>
    800048c4:	5be010ef          	jal	80005e82 <panic>
    dp->nlink--;
    800048c8:	0524d783          	lhu	a5,82(s1)
    800048cc:	37fd                	addiw	a5,a5,-1
    800048ce:	04f49923          	sh	a5,82(s1)
    iupdate(dp);
    800048d2:	8526                	mv	a0,s1
    800048d4:	b36fe0ef          	jal	80002c0a <iupdate>
    800048d8:	b78d                	j	8000483a <sys_unlink+0xb8>
    800048da:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800048dc:	8526                	mv	a0,s1
    800048de:	df8fe0ef          	jal	80002ed6 <iunlockput>
  end_op();
    800048e2:	d11fe0ef          	jal	800035f2 <end_op>
  return -1;
    800048e6:	557d                	li	a0,-1
    800048e8:	64ee                	ld	s1,216(sp)
}
    800048ea:	70ae                	ld	ra,232(sp)
    800048ec:	740e                	ld	s0,224(sp)
    800048ee:	616d                	addi	sp,sp,240
    800048f0:	8082                	ret
    return -1;
    800048f2:	557d                	li	a0,-1
    800048f4:	bfdd                	j	800048ea <sys_unlink+0x168>
    iunlockput(ip);
    800048f6:	854a                	mv	a0,s2
    800048f8:	ddefe0ef          	jal	80002ed6 <iunlockput>
    goto bad;
    800048fc:	694e                	ld	s2,208(sp)
    800048fe:	69ae                	ld	s3,200(sp)
    80004900:	bff1                	j	800048dc <sys_unlink+0x15a>

0000000080004902 <sys_open>:

uint64
sys_open(void)
{
    80004902:	7131                	addi	sp,sp,-192
    80004904:	fd06                	sd	ra,184(sp)
    80004906:	f922                	sd	s0,176(sp)
    80004908:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    8000490a:	f4c40593          	addi	a1,s0,-180
    8000490e:	4505                	li	a0,1
    80004910:	eb4fd0ef          	jal	80001fc4 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004914:	08000613          	li	a2,128
    80004918:	f5040593          	addi	a1,s0,-176
    8000491c:	4501                	li	a0,0
    8000491e:	edefd0ef          	jal	80001ffc <argstr>
    80004922:	87aa                	mv	a5,a0
    return -1;
    80004924:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004926:	0a07c363          	bltz	a5,800049cc <sys_open+0xca>
    8000492a:	f526                	sd	s1,168(sp)

  begin_op();
    8000492c:	c57fe0ef          	jal	80003582 <begin_op>

  if(omode & O_CREATE){
    80004930:	f4c42783          	lw	a5,-180(s0)
    80004934:	2007f793          	andi	a5,a5,512
    80004938:	c3dd                	beqz	a5,800049de <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    8000493a:	4681                	li	a3,0
    8000493c:	4601                	li	a2,0
    8000493e:	4589                	li	a1,2
    80004940:	f5040513          	addi	a0,s0,-176
    80004944:	aafff0ef          	jal	800043f2 <create>
    80004948:	84aa                	mv	s1,a0
    if(ip == 0){
    8000494a:	c549                	beqz	a0,800049d4 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    8000494c:	04c49703          	lh	a4,76(s1)
    80004950:	478d                	li	a5,3
    80004952:	00f71763          	bne	a4,a5,80004960 <sys_open+0x5e>
    80004956:	04e4d703          	lhu	a4,78(s1)
    8000495a:	47a5                	li	a5,9
    8000495c:	0ae7ee63          	bltu	a5,a4,80004a18 <sys_open+0x116>
    80004960:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004962:	faffe0ef          	jal	80003910 <filealloc>
    80004966:	892a                	mv	s2,a0
    80004968:	c561                	beqz	a0,80004a30 <sys_open+0x12e>
    8000496a:	ed4e                	sd	s3,152(sp)
    8000496c:	a47ff0ef          	jal	800043b2 <fdalloc>
    80004970:	89aa                	mv	s3,a0
    80004972:	0a054b63          	bltz	a0,80004a28 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004976:	04c49703          	lh	a4,76(s1)
    8000497a:	478d                	li	a5,3
    8000497c:	0cf70363          	beq	a4,a5,80004a42 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004980:	4789                	li	a5,2
    80004982:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004986:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    8000498a:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    8000498e:	f4c42783          	lw	a5,-180(s0)
    80004992:	0017f713          	andi	a4,a5,1
    80004996:	00174713          	xori	a4,a4,1
    8000499a:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000499e:	0037f713          	andi	a4,a5,3
    800049a2:	00e03733          	snez	a4,a4
    800049a6:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    800049aa:	4007f793          	andi	a5,a5,1024
    800049ae:	c791                	beqz	a5,800049ba <sys_open+0xb8>
    800049b0:	04c49703          	lh	a4,76(s1)
    800049b4:	4789                	li	a5,2
    800049b6:	08f70d63          	beq	a4,a5,80004a50 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    800049ba:	8526                	mv	a0,s1
    800049bc:	bb6fe0ef          	jal	80002d72 <iunlock>
  end_op();
    800049c0:	c33fe0ef          	jal	800035f2 <end_op>

  return fd;
    800049c4:	854e                	mv	a0,s3
    800049c6:	74aa                	ld	s1,168(sp)
    800049c8:	790a                	ld	s2,160(sp)
    800049ca:	69ea                	ld	s3,152(sp)
}
    800049cc:	70ea                	ld	ra,184(sp)
    800049ce:	744a                	ld	s0,176(sp)
    800049d0:	6129                	addi	sp,sp,192
    800049d2:	8082                	ret
      end_op();
    800049d4:	c1ffe0ef          	jal	800035f2 <end_op>
      return -1;
    800049d8:	557d                	li	a0,-1
    800049da:	74aa                	ld	s1,168(sp)
    800049dc:	bfc5                	j	800049cc <sys_open+0xca>
    if((ip = namei(path)) == 0){
    800049de:	f5040513          	addi	a0,s0,-176
    800049e2:	9dffe0ef          	jal	800033c0 <namei>
    800049e6:	84aa                	mv	s1,a0
    800049e8:	c11d                	beqz	a0,80004a0e <sys_open+0x10c>
    ilock(ip);
    800049ea:	ad4fe0ef          	jal	80002cbe <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800049ee:	04c49703          	lh	a4,76(s1)
    800049f2:	4785                	li	a5,1
    800049f4:	f4f71ce3          	bne	a4,a5,8000494c <sys_open+0x4a>
    800049f8:	f4c42783          	lw	a5,-180(s0)
    800049fc:	d3b5                	beqz	a5,80004960 <sys_open+0x5e>
      iunlockput(ip);
    800049fe:	8526                	mv	a0,s1
    80004a00:	cd6fe0ef          	jal	80002ed6 <iunlockput>
      end_op();
    80004a04:	beffe0ef          	jal	800035f2 <end_op>
      return -1;
    80004a08:	557d                	li	a0,-1
    80004a0a:	74aa                	ld	s1,168(sp)
    80004a0c:	b7c1                	j	800049cc <sys_open+0xca>
      end_op();
    80004a0e:	be5fe0ef          	jal	800035f2 <end_op>
      return -1;
    80004a12:	557d                	li	a0,-1
    80004a14:	74aa                	ld	s1,168(sp)
    80004a16:	bf5d                	j	800049cc <sys_open+0xca>
    iunlockput(ip);
    80004a18:	8526                	mv	a0,s1
    80004a1a:	cbcfe0ef          	jal	80002ed6 <iunlockput>
    end_op();
    80004a1e:	bd5fe0ef          	jal	800035f2 <end_op>
    return -1;
    80004a22:	557d                	li	a0,-1
    80004a24:	74aa                	ld	s1,168(sp)
    80004a26:	b75d                	j	800049cc <sys_open+0xca>
      fileclose(f);
    80004a28:	854a                	mv	a0,s2
    80004a2a:	f8bfe0ef          	jal	800039b4 <fileclose>
    80004a2e:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80004a30:	8526                	mv	a0,s1
    80004a32:	ca4fe0ef          	jal	80002ed6 <iunlockput>
    end_op();
    80004a36:	bbdfe0ef          	jal	800035f2 <end_op>
    return -1;
    80004a3a:	557d                	li	a0,-1
    80004a3c:	74aa                	ld	s1,168(sp)
    80004a3e:	790a                	ld	s2,160(sp)
    80004a40:	b771                	j	800049cc <sys_open+0xca>
    f->type = FD_DEVICE;
    80004a42:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80004a46:	04e49783          	lh	a5,78(s1)
    80004a4a:	02f91223          	sh	a5,36(s2)
    80004a4e:	bf35                	j	8000498a <sys_open+0x88>
    itrunc(ip);
    80004a50:	8526                	mv	a0,s1
    80004a52:	b66fe0ef          	jal	80002db8 <itrunc>
    80004a56:	b795                	j	800049ba <sys_open+0xb8>

0000000080004a58 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004a58:	7175                	addi	sp,sp,-144
    80004a5a:	e506                	sd	ra,136(sp)
    80004a5c:	e122                	sd	s0,128(sp)
    80004a5e:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004a60:	b23fe0ef          	jal	80003582 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80004a64:	08000613          	li	a2,128
    80004a68:	f7040593          	addi	a1,s0,-144
    80004a6c:	4501                	li	a0,0
    80004a6e:	d8efd0ef          	jal	80001ffc <argstr>
    80004a72:	02054363          	bltz	a0,80004a98 <sys_mkdir+0x40>
    80004a76:	4681                	li	a3,0
    80004a78:	4601                	li	a2,0
    80004a7a:	4585                	li	a1,1
    80004a7c:	f7040513          	addi	a0,s0,-144
    80004a80:	973ff0ef          	jal	800043f2 <create>
    80004a84:	c911                	beqz	a0,80004a98 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004a86:	c50fe0ef          	jal	80002ed6 <iunlockput>
  end_op();
    80004a8a:	b69fe0ef          	jal	800035f2 <end_op>
  return 0;
    80004a8e:	4501                	li	a0,0
}
    80004a90:	60aa                	ld	ra,136(sp)
    80004a92:	640a                	ld	s0,128(sp)
    80004a94:	6149                	addi	sp,sp,144
    80004a96:	8082                	ret
    end_op();
    80004a98:	b5bfe0ef          	jal	800035f2 <end_op>
    return -1;
    80004a9c:	557d                	li	a0,-1
    80004a9e:	bfcd                	j	80004a90 <sys_mkdir+0x38>

0000000080004aa0 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004aa0:	7135                	addi	sp,sp,-160
    80004aa2:	ed06                	sd	ra,152(sp)
    80004aa4:	e922                	sd	s0,144(sp)
    80004aa6:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004aa8:	adbfe0ef          	jal	80003582 <begin_op>
  argint(1, &major);
    80004aac:	f6c40593          	addi	a1,s0,-148
    80004ab0:	4505                	li	a0,1
    80004ab2:	d12fd0ef          	jal	80001fc4 <argint>
  argint(2, &minor);
    80004ab6:	f6840593          	addi	a1,s0,-152
    80004aba:	4509                	li	a0,2
    80004abc:	d08fd0ef          	jal	80001fc4 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004ac0:	08000613          	li	a2,128
    80004ac4:	f7040593          	addi	a1,s0,-144
    80004ac8:	4501                	li	a0,0
    80004aca:	d32fd0ef          	jal	80001ffc <argstr>
    80004ace:	02054563          	bltz	a0,80004af8 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004ad2:	f6841683          	lh	a3,-152(s0)
    80004ad6:	f6c41603          	lh	a2,-148(s0)
    80004ada:	458d                	li	a1,3
    80004adc:	f7040513          	addi	a0,s0,-144
    80004ae0:	913ff0ef          	jal	800043f2 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004ae4:	c911                	beqz	a0,80004af8 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004ae6:	bf0fe0ef          	jal	80002ed6 <iunlockput>
  end_op();
    80004aea:	b09fe0ef          	jal	800035f2 <end_op>
  return 0;
    80004aee:	4501                	li	a0,0
}
    80004af0:	60ea                	ld	ra,152(sp)
    80004af2:	644a                	ld	s0,144(sp)
    80004af4:	610d                	addi	sp,sp,160
    80004af6:	8082                	ret
    end_op();
    80004af8:	afbfe0ef          	jal	800035f2 <end_op>
    return -1;
    80004afc:	557d                	li	a0,-1
    80004afe:	bfcd                	j	80004af0 <sys_mknod+0x50>

0000000080004b00 <sys_chdir>:

uint64
sys_chdir(void)
{
    80004b00:	7135                	addi	sp,sp,-160
    80004b02:	ed06                	sd	ra,152(sp)
    80004b04:	e922                	sd	s0,144(sp)
    80004b06:	e14a                	sd	s2,128(sp)
    80004b08:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80004b0a:	dfafc0ef          	jal	80001104 <myproc>
    80004b0e:	892a                	mv	s2,a0
  
  begin_op();
    80004b10:	a73fe0ef          	jal	80003582 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80004b14:	08000613          	li	a2,128
    80004b18:	f6040593          	addi	a1,s0,-160
    80004b1c:	4501                	li	a0,0
    80004b1e:	cdefd0ef          	jal	80001ffc <argstr>
    80004b22:	04054363          	bltz	a0,80004b68 <sys_chdir+0x68>
    80004b26:	e526                	sd	s1,136(sp)
    80004b28:	f6040513          	addi	a0,s0,-160
    80004b2c:	895fe0ef          	jal	800033c0 <namei>
    80004b30:	84aa                	mv	s1,a0
    80004b32:	c915                	beqz	a0,80004b66 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80004b34:	98afe0ef          	jal	80002cbe <ilock>
  if(ip->type != T_DIR){
    80004b38:	04c49703          	lh	a4,76(s1)
    80004b3c:	4785                	li	a5,1
    80004b3e:	02f71963          	bne	a4,a5,80004b70 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80004b42:	8526                	mv	a0,s1
    80004b44:	a2efe0ef          	jal	80002d72 <iunlock>
  iput(p->cwd);
    80004b48:	15893503          	ld	a0,344(s2)
    80004b4c:	b00fe0ef          	jal	80002e4c <iput>
  end_op();
    80004b50:	aa3fe0ef          	jal	800035f2 <end_op>
  p->cwd = ip;
    80004b54:	14993c23          	sd	s1,344(s2)
  return 0;
    80004b58:	4501                	li	a0,0
    80004b5a:	64aa                	ld	s1,136(sp)
}
    80004b5c:	60ea                	ld	ra,152(sp)
    80004b5e:	644a                	ld	s0,144(sp)
    80004b60:	690a                	ld	s2,128(sp)
    80004b62:	610d                	addi	sp,sp,160
    80004b64:	8082                	ret
    80004b66:	64aa                	ld	s1,136(sp)
    end_op();
    80004b68:	a8bfe0ef          	jal	800035f2 <end_op>
    return -1;
    80004b6c:	557d                	li	a0,-1
    80004b6e:	b7fd                	j	80004b5c <sys_chdir+0x5c>
    iunlockput(ip);
    80004b70:	8526                	mv	a0,s1
    80004b72:	b64fe0ef          	jal	80002ed6 <iunlockput>
    end_op();
    80004b76:	a7dfe0ef          	jal	800035f2 <end_op>
    return -1;
    80004b7a:	557d                	li	a0,-1
    80004b7c:	64aa                	ld	s1,136(sp)
    80004b7e:	bff9                	j	80004b5c <sys_chdir+0x5c>

0000000080004b80 <sys_exec>:

uint64
sys_exec(void)
{
    80004b80:	7105                	addi	sp,sp,-480
    80004b82:	ef86                	sd	ra,472(sp)
    80004b84:	eba2                	sd	s0,464(sp)
    80004b86:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004b88:	e2840593          	addi	a1,s0,-472
    80004b8c:	4505                	li	a0,1
    80004b8e:	c52fd0ef          	jal	80001fe0 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80004b92:	08000613          	li	a2,128
    80004b96:	f3040593          	addi	a1,s0,-208
    80004b9a:	4501                	li	a0,0
    80004b9c:	c60fd0ef          	jal	80001ffc <argstr>
    80004ba0:	87aa                	mv	a5,a0
    return -1;
    80004ba2:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80004ba4:	0e07c063          	bltz	a5,80004c84 <sys_exec+0x104>
    80004ba8:	e7a6                	sd	s1,456(sp)
    80004baa:	e3ca                	sd	s2,448(sp)
    80004bac:	ff4e                	sd	s3,440(sp)
    80004bae:	fb52                	sd	s4,432(sp)
    80004bb0:	f756                	sd	s5,424(sp)
    80004bb2:	f35a                	sd	s6,416(sp)
    80004bb4:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    80004bb6:	e3040a13          	addi	s4,s0,-464
    80004bba:	10000613          	li	a2,256
    80004bbe:	4581                	li	a1,0
    80004bc0:	8552                	mv	a0,s4
    80004bc2:	917fb0ef          	jal	800004d8 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80004bc6:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    80004bc8:	89d2                	mv	s3,s4
    80004bca:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004bcc:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80004bd0:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    80004bd2:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004bd6:	00391513          	slli	a0,s2,0x3
    80004bda:	85d6                	mv	a1,s5
    80004bdc:	e2843783          	ld	a5,-472(s0)
    80004be0:	953e                	add	a0,a0,a5
    80004be2:	b58fd0ef          	jal	80001f3a <fetchaddr>
    80004be6:	02054663          	bltz	a0,80004c12 <sys_exec+0x92>
    if(uarg == 0){
    80004bea:	e2043783          	ld	a5,-480(s0)
    80004bee:	c7a1                	beqz	a5,80004c36 <sys_exec+0xb6>
    argv[i] = kalloc();
    80004bf0:	f22fb0ef          	jal	80000312 <kalloc>
    80004bf4:	85aa                	mv	a1,a0
    80004bf6:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80004bfa:	cd01                	beqz	a0,80004c12 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80004bfc:	865a                	mv	a2,s6
    80004bfe:	e2043503          	ld	a0,-480(s0)
    80004c02:	b82fd0ef          	jal	80001f84 <fetchstr>
    80004c06:	00054663          	bltz	a0,80004c12 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    80004c0a:	0905                	addi	s2,s2,1
    80004c0c:	09a1                	addi	s3,s3,8
    80004c0e:	fd7914e3          	bne	s2,s7,80004bd6 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004c12:	100a0a13          	addi	s4,s4,256
    80004c16:	6088                	ld	a0,0(s1)
    80004c18:	cd31                	beqz	a0,80004c74 <sys_exec+0xf4>
    kfree(argv[i]);
    80004c1a:	e68fb0ef          	jal	80000282 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004c1e:	04a1                	addi	s1,s1,8
    80004c20:	ff449be3          	bne	s1,s4,80004c16 <sys_exec+0x96>
  return -1;
    80004c24:	557d                	li	a0,-1
    80004c26:	64be                	ld	s1,456(sp)
    80004c28:	691e                	ld	s2,448(sp)
    80004c2a:	79fa                	ld	s3,440(sp)
    80004c2c:	7a5a                	ld	s4,432(sp)
    80004c2e:	7aba                	ld	s5,424(sp)
    80004c30:	7b1a                	ld	s6,416(sp)
    80004c32:	6bfa                	ld	s7,408(sp)
    80004c34:	a881                	j	80004c84 <sys_exec+0x104>
      argv[i] = 0;
    80004c36:	0009079b          	sext.w	a5,s2
    80004c3a:	e3040593          	addi	a1,s0,-464
    80004c3e:	078e                	slli	a5,a5,0x3
    80004c40:	97ae                	add	a5,a5,a1
    80004c42:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    80004c46:	f3040513          	addi	a0,s0,-208
    80004c4a:	bb2ff0ef          	jal	80003ffc <exec>
    80004c4e:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004c50:	100a0a13          	addi	s4,s4,256
    80004c54:	6088                	ld	a0,0(s1)
    80004c56:	c511                	beqz	a0,80004c62 <sys_exec+0xe2>
    kfree(argv[i]);
    80004c58:	e2afb0ef          	jal	80000282 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004c5c:	04a1                	addi	s1,s1,8
    80004c5e:	ff449be3          	bne	s1,s4,80004c54 <sys_exec+0xd4>
  return ret;
    80004c62:	854a                	mv	a0,s2
    80004c64:	64be                	ld	s1,456(sp)
    80004c66:	691e                	ld	s2,448(sp)
    80004c68:	79fa                	ld	s3,440(sp)
    80004c6a:	7a5a                	ld	s4,432(sp)
    80004c6c:	7aba                	ld	s5,424(sp)
    80004c6e:	7b1a                	ld	s6,416(sp)
    80004c70:	6bfa                	ld	s7,408(sp)
    80004c72:	a809                	j	80004c84 <sys_exec+0x104>
  return -1;
    80004c74:	557d                	li	a0,-1
    80004c76:	64be                	ld	s1,456(sp)
    80004c78:	691e                	ld	s2,448(sp)
    80004c7a:	79fa                	ld	s3,440(sp)
    80004c7c:	7a5a                	ld	s4,432(sp)
    80004c7e:	7aba                	ld	s5,424(sp)
    80004c80:	7b1a                	ld	s6,416(sp)
    80004c82:	6bfa                	ld	s7,408(sp)
}
    80004c84:	60fe                	ld	ra,472(sp)
    80004c86:	645e                	ld	s0,464(sp)
    80004c88:	613d                	addi	sp,sp,480
    80004c8a:	8082                	ret

0000000080004c8c <sys_pipe>:

uint64
sys_pipe(void)
{
    80004c8c:	7139                	addi	sp,sp,-64
    80004c8e:	fc06                	sd	ra,56(sp)
    80004c90:	f822                	sd	s0,48(sp)
    80004c92:	f426                	sd	s1,40(sp)
    80004c94:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80004c96:	c6efc0ef          	jal	80001104 <myproc>
    80004c9a:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80004c9c:	fd840593          	addi	a1,s0,-40
    80004ca0:	4501                	li	a0,0
    80004ca2:	b3efd0ef          	jal	80001fe0 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80004ca6:	fc840593          	addi	a1,s0,-56
    80004caa:	fd040513          	addi	a0,s0,-48
    80004cae:	822ff0ef          	jal	80003cd0 <pipealloc>
    return -1;
    80004cb2:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80004cb4:	0a054763          	bltz	a0,80004d62 <sys_pipe+0xd6>
  fd0 = -1;
    80004cb8:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80004cbc:	fd043503          	ld	a0,-48(s0)
    80004cc0:	ef2ff0ef          	jal	800043b2 <fdalloc>
    80004cc4:	fca42223          	sw	a0,-60(s0)
    80004cc8:	08054463          	bltz	a0,80004d50 <sys_pipe+0xc4>
    80004ccc:	fc843503          	ld	a0,-56(s0)
    80004cd0:	ee2ff0ef          	jal	800043b2 <fdalloc>
    80004cd4:	fca42023          	sw	a0,-64(s0)
    80004cd8:	06054263          	bltz	a0,80004d3c <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004cdc:	4691                	li	a3,4
    80004cde:	fc440613          	addi	a2,s0,-60
    80004ce2:	fd843583          	ld	a1,-40(s0)
    80004ce6:	6ca8                	ld	a0,88(s1)
    80004ce8:	89cfc0ef          	jal	80000d84 <copyout>
    80004cec:	00054e63          	bltz	a0,80004d08 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80004cf0:	4691                	li	a3,4
    80004cf2:	fc040613          	addi	a2,s0,-64
    80004cf6:	fd843583          	ld	a1,-40(s0)
    80004cfa:	95b6                	add	a1,a1,a3
    80004cfc:	6ca8                	ld	a0,88(s1)
    80004cfe:	886fc0ef          	jal	80000d84 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80004d02:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004d04:	04055f63          	bgez	a0,80004d62 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    80004d08:	fc442783          	lw	a5,-60(s0)
    80004d0c:	078e                	slli	a5,a5,0x3
    80004d0e:	0d078793          	addi	a5,a5,208
    80004d12:	97a6                	add	a5,a5,s1
    80004d14:	0007b423          	sd	zero,8(a5)
    p->ofile[fd1] = 0;
    80004d18:	fc042783          	lw	a5,-64(s0)
    80004d1c:	078e                	slli	a5,a5,0x3
    80004d1e:	0d078793          	addi	a5,a5,208
    80004d22:	97a6                	add	a5,a5,s1
    80004d24:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    80004d28:	fd043503          	ld	a0,-48(s0)
    80004d2c:	c89fe0ef          	jal	800039b4 <fileclose>
    fileclose(wf);
    80004d30:	fc843503          	ld	a0,-56(s0)
    80004d34:	c81fe0ef          	jal	800039b4 <fileclose>
    return -1;
    80004d38:	57fd                	li	a5,-1
    80004d3a:	a025                	j	80004d62 <sys_pipe+0xd6>
    if(fd0 >= 0)
    80004d3c:	fc442783          	lw	a5,-60(s0)
    80004d40:	0007c863          	bltz	a5,80004d50 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    80004d44:	078e                	slli	a5,a5,0x3
    80004d46:	0d078793          	addi	a5,a5,208
    80004d4a:	97a6                	add	a5,a5,s1
    80004d4c:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    80004d50:	fd043503          	ld	a0,-48(s0)
    80004d54:	c61fe0ef          	jal	800039b4 <fileclose>
    fileclose(wf);
    80004d58:	fc843503          	ld	a0,-56(s0)
    80004d5c:	c59fe0ef          	jal	800039b4 <fileclose>
    return -1;
    80004d60:	57fd                	li	a5,-1
}
    80004d62:	853e                	mv	a0,a5
    80004d64:	70e2                	ld	ra,56(sp)
    80004d66:	7442                	ld	s0,48(sp)
    80004d68:	74a2                	ld	s1,40(sp)
    80004d6a:	6121                	addi	sp,sp,64
    80004d6c:	8082                	ret
	...

0000000080004d70 <kernelvec>:
    80004d70:	7111                	addi	sp,sp,-256
    80004d72:	e006                	sd	ra,0(sp)
    80004d74:	e40a                	sd	sp,8(sp)
    80004d76:	e80e                	sd	gp,16(sp)
    80004d78:	ec12                	sd	tp,24(sp)
    80004d7a:	f016                	sd	t0,32(sp)
    80004d7c:	f41a                	sd	t1,40(sp)
    80004d7e:	f81e                	sd	t2,48(sp)
    80004d80:	e4aa                	sd	a0,72(sp)
    80004d82:	e8ae                	sd	a1,80(sp)
    80004d84:	ecb2                	sd	a2,88(sp)
    80004d86:	f0b6                	sd	a3,96(sp)
    80004d88:	f4ba                	sd	a4,104(sp)
    80004d8a:	f8be                	sd	a5,112(sp)
    80004d8c:	fcc2                	sd	a6,120(sp)
    80004d8e:	e146                	sd	a7,128(sp)
    80004d90:	edf2                	sd	t3,216(sp)
    80004d92:	f1f6                	sd	t4,224(sp)
    80004d94:	f5fa                	sd	t5,232(sp)
    80004d96:	f9fe                	sd	t6,240(sp)
    80004d98:	8b0fd0ef          	jal	80001e48 <kerneltrap>
    80004d9c:	6082                	ld	ra,0(sp)
    80004d9e:	6122                	ld	sp,8(sp)
    80004da0:	61c2                	ld	gp,16(sp)
    80004da2:	7282                	ld	t0,32(sp)
    80004da4:	7322                	ld	t1,40(sp)
    80004da6:	73c2                	ld	t2,48(sp)
    80004da8:	6526                	ld	a0,72(sp)
    80004daa:	65c6                	ld	a1,80(sp)
    80004dac:	6666                	ld	a2,88(sp)
    80004dae:	7686                	ld	a3,96(sp)
    80004db0:	7726                	ld	a4,104(sp)
    80004db2:	77c6                	ld	a5,112(sp)
    80004db4:	7866                	ld	a6,120(sp)
    80004db6:	688a                	ld	a7,128(sp)
    80004db8:	6e6e                	ld	t3,216(sp)
    80004dba:	7e8e                	ld	t4,224(sp)
    80004dbc:	7f2e                	ld	t5,232(sp)
    80004dbe:	7fce                	ld	t6,240(sp)
    80004dc0:	6111                	addi	sp,sp,256
    80004dc2:	10200073          	sret
    80004dc6:	00000013          	nop
    80004dca:	00000013          	nop

0000000080004dce <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80004dce:	1141                	addi	sp,sp,-16
    80004dd0:	e406                	sd	ra,8(sp)
    80004dd2:	e022                	sd	s0,0(sp)
    80004dd4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004dd6:	0c000737          	lui	a4,0xc000
    80004dda:	4785                	li	a5,1
    80004ddc:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    80004dde:	c35c                	sw	a5,4(a4)
}
    80004de0:	60a2                	ld	ra,8(sp)
    80004de2:	6402                	ld	s0,0(sp)
    80004de4:	0141                	addi	sp,sp,16
    80004de6:	8082                	ret

0000000080004de8 <plicinithart>:

void
plicinithart(void)
{
    80004de8:	1141                	addi	sp,sp,-16
    80004dea:	e406                	sd	ra,8(sp)
    80004dec:	e022                	sd	s0,0(sp)
    80004dee:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004df0:	ae0fc0ef          	jal	800010d0 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80004df4:	0085171b          	slliw	a4,a0,0x8
    80004df8:	0c0027b7          	lui	a5,0xc002
    80004dfc:	97ba                	add	a5,a5,a4
    80004dfe:	40200713          	li	a4,1026
    80004e02:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80004e06:	00d5151b          	slliw	a0,a0,0xd
    80004e0a:	0c2017b7          	lui	a5,0xc201
    80004e0e:	97aa                	add	a5,a5,a0
    80004e10:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80004e14:	60a2                	ld	ra,8(sp)
    80004e16:	6402                	ld	s0,0(sp)
    80004e18:	0141                	addi	sp,sp,16
    80004e1a:	8082                	ret

0000000080004e1c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80004e1c:	1141                	addi	sp,sp,-16
    80004e1e:	e406                	sd	ra,8(sp)
    80004e20:	e022                	sd	s0,0(sp)
    80004e22:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80004e24:	aacfc0ef          	jal	800010d0 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80004e28:	00d5151b          	slliw	a0,a0,0xd
    80004e2c:	0c2017b7          	lui	a5,0xc201
    80004e30:	97aa                	add	a5,a5,a0
  return irq;
}
    80004e32:	43c8                	lw	a0,4(a5)
    80004e34:	60a2                	ld	ra,8(sp)
    80004e36:	6402                	ld	s0,0(sp)
    80004e38:	0141                	addi	sp,sp,16
    80004e3a:	8082                	ret

0000000080004e3c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80004e3c:	1101                	addi	sp,sp,-32
    80004e3e:	ec06                	sd	ra,24(sp)
    80004e40:	e822                	sd	s0,16(sp)
    80004e42:	e426                	sd	s1,8(sp)
    80004e44:	1000                	addi	s0,sp,32
    80004e46:	84aa                	mv	s1,a0
  int hart = cpuid();
    80004e48:	a88fc0ef          	jal	800010d0 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80004e4c:	00d5179b          	slliw	a5,a0,0xd
    80004e50:	0c201737          	lui	a4,0xc201
    80004e54:	97ba                	add	a5,a5,a4
    80004e56:	c3c4                	sw	s1,4(a5)
}
    80004e58:	60e2                	ld	ra,24(sp)
    80004e5a:	6442                	ld	s0,16(sp)
    80004e5c:	64a2                	ld	s1,8(sp)
    80004e5e:	6105                	addi	sp,sp,32
    80004e60:	8082                	ret

0000000080004e62 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80004e62:	1141                	addi	sp,sp,-16
    80004e64:	e406                	sd	ra,8(sp)
    80004e66:	e022                	sd	s0,0(sp)
    80004e68:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80004e6a:	479d                	li	a5,7
    80004e6c:	04a7ca63          	blt	a5,a0,80004ec0 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80004e70:	00016797          	auipc	a5,0x16
    80004e74:	4d878793          	addi	a5,a5,1240 # 8001b348 <disk>
    80004e78:	97aa                	add	a5,a5,a0
    80004e7a:	0187c783          	lbu	a5,24(a5)
    80004e7e:	e7b9                	bnez	a5,80004ecc <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80004e80:	00451693          	slli	a3,a0,0x4
    80004e84:	00016797          	auipc	a5,0x16
    80004e88:	4c478793          	addi	a5,a5,1220 # 8001b348 <disk>
    80004e8c:	6398                	ld	a4,0(a5)
    80004e8e:	9736                	add	a4,a4,a3
    80004e90:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80004e94:	6398                	ld	a4,0(a5)
    80004e96:	9736                	add	a4,a4,a3
    80004e98:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80004e9c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80004ea0:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004ea4:	97aa                	add	a5,a5,a0
    80004ea6:	4705                	li	a4,1
    80004ea8:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80004eac:	00016517          	auipc	a0,0x16
    80004eb0:	4b450513          	addi	a0,a0,1204 # 8001b360 <disk+0x18>
    80004eb4:	86ffc0ef          	jal	80001722 <wakeup>
}
    80004eb8:	60a2                	ld	ra,8(sp)
    80004eba:	6402                	ld	s0,0(sp)
    80004ebc:	0141                	addi	sp,sp,16
    80004ebe:	8082                	ret
    panic("free_desc 1");
    80004ec0:	00003517          	auipc	a0,0x3
    80004ec4:	79050513          	addi	a0,a0,1936 # 80008650 <etext+0x650>
    80004ec8:	7bb000ef          	jal	80005e82 <panic>
    panic("free_desc 2");
    80004ecc:	00003517          	auipc	a0,0x3
    80004ed0:	79450513          	addi	a0,a0,1940 # 80008660 <etext+0x660>
    80004ed4:	7af000ef          	jal	80005e82 <panic>

0000000080004ed8 <virtio_disk_init>:
{
    80004ed8:	1101                	addi	sp,sp,-32
    80004eda:	ec06                	sd	ra,24(sp)
    80004edc:	e822                	sd	s0,16(sp)
    80004ede:	e426                	sd	s1,8(sp)
    80004ee0:	e04a                	sd	s2,0(sp)
    80004ee2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004ee4:	00003597          	auipc	a1,0x3
    80004ee8:	78c58593          	addi	a1,a1,1932 # 80008670 <etext+0x670>
    80004eec:	00016517          	auipc	a0,0x16
    80004ef0:	58450513          	addi	a0,a0,1412 # 8001b470 <disk+0x128>
    80004ef4:	3f2010ef          	jal	800062e6 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004ef8:	100017b7          	lui	a5,0x10001
    80004efc:	4398                	lw	a4,0(a5)
    80004efe:	2701                	sext.w	a4,a4
    80004f00:	747277b7          	lui	a5,0x74727
    80004f04:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80004f08:	14f71863          	bne	a4,a5,80005058 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004f0c:	100017b7          	lui	a5,0x10001
    80004f10:	43dc                	lw	a5,4(a5)
    80004f12:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004f14:	4709                	li	a4,2
    80004f16:	14e79163          	bne	a5,a4,80005058 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004f1a:	100017b7          	lui	a5,0x10001
    80004f1e:	479c                	lw	a5,8(a5)
    80004f20:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004f22:	12e79b63          	bne	a5,a4,80005058 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80004f26:	100017b7          	lui	a5,0x10001
    80004f2a:	47d8                	lw	a4,12(a5)
    80004f2c:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80004f2e:	554d47b7          	lui	a5,0x554d4
    80004f32:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80004f36:	12f71163          	bne	a4,a5,80005058 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004f3a:	100017b7          	lui	a5,0x10001
    80004f3e:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80004f42:	4705                	li	a4,1
    80004f44:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004f46:	470d                	li	a4,3
    80004f48:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80004f4a:	10001737          	lui	a4,0x10001
    80004f4e:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80004f50:	c7ffe6b7          	lui	a3,0xc7ffe
    80004f54:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fd90d7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80004f58:	8f75                	and	a4,a4,a3
    80004f5a:	100016b7          	lui	a3,0x10001
    80004f5e:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004f60:	472d                	li	a4,11
    80004f62:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80004f64:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80004f68:	439c                	lw	a5,0(a5)
    80004f6a:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80004f6e:	8ba1                	andi	a5,a5,8
    80004f70:	0e078a63          	beqz	a5,80005064 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80004f74:	100017b7          	lui	a5,0x10001
    80004f78:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80004f7c:	43fc                	lw	a5,68(a5)
    80004f7e:	2781                	sext.w	a5,a5
    80004f80:	0e079863          	bnez	a5,80005070 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80004f84:	100017b7          	lui	a5,0x10001
    80004f88:	5bdc                	lw	a5,52(a5)
    80004f8a:	2781                	sext.w	a5,a5
  if(max == 0)
    80004f8c:	0e078863          	beqz	a5,8000507c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80004f90:	471d                	li	a4,7
    80004f92:	0ef77b63          	bgeu	a4,a5,80005088 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80004f96:	b7cfb0ef          	jal	80000312 <kalloc>
    80004f9a:	00016497          	auipc	s1,0x16
    80004f9e:	3ae48493          	addi	s1,s1,942 # 8001b348 <disk>
    80004fa2:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004fa4:	b6efb0ef          	jal	80000312 <kalloc>
    80004fa8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004faa:	b68fb0ef          	jal	80000312 <kalloc>
    80004fae:	87aa                	mv	a5,a0
    80004fb0:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004fb2:	6088                	ld	a0,0(s1)
    80004fb4:	0e050063          	beqz	a0,80005094 <virtio_disk_init+0x1bc>
    80004fb8:	00016717          	auipc	a4,0x16
    80004fbc:	39873703          	ld	a4,920(a4) # 8001b350 <disk+0x8>
    80004fc0:	cb71                	beqz	a4,80005094 <virtio_disk_init+0x1bc>
    80004fc2:	cbe9                	beqz	a5,80005094 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80004fc4:	6605                	lui	a2,0x1
    80004fc6:	4581                	li	a1,0
    80004fc8:	d10fb0ef          	jal	800004d8 <memset>
  memset(disk.avail, 0, PGSIZE);
    80004fcc:	00016497          	auipc	s1,0x16
    80004fd0:	37c48493          	addi	s1,s1,892 # 8001b348 <disk>
    80004fd4:	6605                	lui	a2,0x1
    80004fd6:	4581                	li	a1,0
    80004fd8:	6488                	ld	a0,8(s1)
    80004fda:	cfefb0ef          	jal	800004d8 <memset>
  memset(disk.used, 0, PGSIZE);
    80004fde:	6605                	lui	a2,0x1
    80004fe0:	4581                	li	a1,0
    80004fe2:	6888                	ld	a0,16(s1)
    80004fe4:	cf4fb0ef          	jal	800004d8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004fe8:	100017b7          	lui	a5,0x10001
    80004fec:	4721                	li	a4,8
    80004fee:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004ff0:	4098                	lw	a4,0(s1)
    80004ff2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004ff6:	40d8                	lw	a4,4(s1)
    80004ff8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80004ffc:	649c                	ld	a5,8(s1)
    80004ffe:	0007869b          	sext.w	a3,a5
    80005002:	10001737          	lui	a4,0x10001
    80005006:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    8000500a:	9781                	srai	a5,a5,0x20
    8000500c:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005010:	689c                	ld	a5,16(s1)
    80005012:	0007869b          	sext.w	a3,a5
    80005016:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000501a:	9781                	srai	a5,a5,0x20
    8000501c:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005020:	4785                	li	a5,1
    80005022:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005024:	00f48c23          	sb	a5,24(s1)
    80005028:	00f48ca3          	sb	a5,25(s1)
    8000502c:	00f48d23          	sb	a5,26(s1)
    80005030:	00f48da3          	sb	a5,27(s1)
    80005034:	00f48e23          	sb	a5,28(s1)
    80005038:	00f48ea3          	sb	a5,29(s1)
    8000503c:	00f48f23          	sb	a5,30(s1)
    80005040:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005044:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005048:	07272823          	sw	s2,112(a4)
}
    8000504c:	60e2                	ld	ra,24(sp)
    8000504e:	6442                	ld	s0,16(sp)
    80005050:	64a2                	ld	s1,8(sp)
    80005052:	6902                	ld	s2,0(sp)
    80005054:	6105                	addi	sp,sp,32
    80005056:	8082                	ret
    panic("could not find virtio disk");
    80005058:	00003517          	auipc	a0,0x3
    8000505c:	62850513          	addi	a0,a0,1576 # 80008680 <etext+0x680>
    80005060:	623000ef          	jal	80005e82 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005064:	00003517          	auipc	a0,0x3
    80005068:	63c50513          	addi	a0,a0,1596 # 800086a0 <etext+0x6a0>
    8000506c:	617000ef          	jal	80005e82 <panic>
    panic("virtio disk should not be ready");
    80005070:	00003517          	auipc	a0,0x3
    80005074:	65050513          	addi	a0,a0,1616 # 800086c0 <etext+0x6c0>
    80005078:	60b000ef          	jal	80005e82 <panic>
    panic("virtio disk has no queue 0");
    8000507c:	00003517          	auipc	a0,0x3
    80005080:	66450513          	addi	a0,a0,1636 # 800086e0 <etext+0x6e0>
    80005084:	5ff000ef          	jal	80005e82 <panic>
    panic("virtio disk max queue too short");
    80005088:	00003517          	auipc	a0,0x3
    8000508c:	67850513          	addi	a0,a0,1656 # 80008700 <etext+0x700>
    80005090:	5f3000ef          	jal	80005e82 <panic>
    panic("virtio disk kalloc");
    80005094:	00003517          	auipc	a0,0x3
    80005098:	68c50513          	addi	a0,a0,1676 # 80008720 <etext+0x720>
    8000509c:	5e7000ef          	jal	80005e82 <panic>

00000000800050a0 <virtio_disk_rw>:
}
#endif

void
virtio_disk_rw(struct buf *b, int write)
{
    800050a0:	711d                	addi	sp,sp,-96
    800050a2:	ec86                	sd	ra,88(sp)
    800050a4:	e8a2                	sd	s0,80(sp)
    800050a6:	e4a6                	sd	s1,72(sp)
    800050a8:	e0ca                	sd	s2,64(sp)
    800050aa:	fc4e                	sd	s3,56(sp)
    800050ac:	f852                	sd	s4,48(sp)
    800050ae:	f456                	sd	s5,40(sp)
    800050b0:	f05a                	sd	s6,32(sp)
    800050b2:	ec5e                	sd	s7,24(sp)
    800050b4:	e862                	sd	s8,16(sp)
    800050b6:	1080                	addi	s0,sp,96
    800050b8:	89aa                	mv	s3,a0
    800050ba:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800050bc:	4544                	lw	s1,12(a0)

  acquire(&disk.vdisk_lock);
    800050be:	00016517          	auipc	a0,0x16
    800050c2:	3b250513          	addi	a0,a0,946 # 8001b470 <disk+0x128>
    800050c6:	0e0010ef          	jal	800061a6 <acquire>
  for(int i = 0; i < NBUF; i++){
    800050ca:	00016697          	auipc	a3,0x16
    800050ce:	3c668693          	addi	a3,a3,966 # 8001b490 <xbufs>
    800050d2:	4781                	li	a5,0
    800050d4:	4679                	li	a2,30
    if(xbufs[i] == b){
    800050d6:	6298                	ld	a4,0(a3)
    800050d8:	02e98563          	beq	s3,a4,80005102 <virtio_disk_rw+0x62>
    if(xbufs[i] == 0){
    800050dc:	cb19                	beqz	a4,800050f2 <virtio_disk_rw+0x52>
  for(int i = 0; i < NBUF; i++){
    800050de:	2785                	addiw	a5,a5,1
    800050e0:	06a1                	addi	a3,a3,8
    800050e2:	fec79ae3          	bne	a5,a2,800050d6 <virtio_disk_rw+0x36>
  panic("more than NBUF bufs");
    800050e6:	00003517          	auipc	a0,0x3
    800050ea:	65250513          	addi	a0,a0,1618 # 80008738 <etext+0x738>
    800050ee:	595000ef          	jal	80005e82 <panic>
      xbufs[i] = b;
    800050f2:	078e                	slli	a5,a5,0x3
    800050f4:	00016717          	auipc	a4,0x16
    800050f8:	25470713          	addi	a4,a4,596 # 8001b348 <disk>
    800050fc:	97ba                	add	a5,a5,a4
    800050fe:	1537b423          	sd	s3,328(a5)
  uint64 sector = b->blockno * (BSIZE / 512);
    80005102:	0014949b          	slliw	s1,s1,0x1
    80005106:	02049793          	slli	a5,s1,0x20
    8000510a:	9381                	srli	a5,a5,0x20
    8000510c:	8c3e                	mv	s8,a5
  for(int i = 0; i < NUM; i++){
    8000510e:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005110:	00016a97          	auipc	s5,0x16
    80005114:	238a8a93          	addi	s5,s5,568 # 8001b348 <disk>
  for(int i = 0; i < 3; i++){
    80005118:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    8000511a:	5bfd                	li	s7,-1
    8000511c:	a095                	j	80005180 <virtio_disk_rw+0xe0>
      disk.free[i] = 0;
    8000511e:	00fa8733          	add	a4,s5,a5
    80005122:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80005126:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005128:	0207c563          	bltz	a5,80005152 <virtio_disk_rw+0xb2>
  for(int i = 0; i < 3; i++){
    8000512c:	2905                	addiw	s2,s2,1
    8000512e:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005130:	05490c63          	beq	s2,s4,80005188 <virtio_disk_rw+0xe8>
    idx[i] = alloc_desc();
    80005134:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005136:	00016717          	auipc	a4,0x16
    8000513a:	21270713          	addi	a4,a4,530 # 8001b348 <disk>
    8000513e:	4781                	li	a5,0
    if(disk.free[i]){
    80005140:	01874683          	lbu	a3,24(a4)
    80005144:	fee9                	bnez	a3,8000511e <virtio_disk_rw+0x7e>
  for(int i = 0; i < NUM; i++){
    80005146:	2785                	addiw	a5,a5,1
    80005148:	0705                	addi	a4,a4,1
    8000514a:	fe979be3          	bne	a5,s1,80005140 <virtio_disk_rw+0xa0>
    idx[i] = alloc_desc();
    8000514e:	0175a023          	sw	s7,0(a1)
      for(int j = 0; j < i; j++)
    80005152:	01205d63          	blez	s2,8000516c <virtio_disk_rw+0xcc>
        free_desc(idx[j]);
    80005156:	fa042503          	lw	a0,-96(s0)
    8000515a:	d09ff0ef          	jal	80004e62 <free_desc>
      for(int j = 0; j < i; j++)
    8000515e:	4785                	li	a5,1
    80005160:	0127d663          	bge	a5,s2,8000516c <virtio_disk_rw+0xcc>
        free_desc(idx[j]);
    80005164:	fa442503          	lw	a0,-92(s0)
    80005168:	cfbff0ef          	jal	80004e62 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    8000516c:	00016597          	auipc	a1,0x16
    80005170:	30458593          	addi	a1,a1,772 # 8001b470 <disk+0x128>
    80005174:	00016517          	auipc	a0,0x16
    80005178:	1ec50513          	addi	a0,a0,492 # 8001b360 <disk+0x18>
    8000517c:	d5afc0ef          	jal	800016d6 <sleep>
  for(int i = 0; i < 3; i++){
    80005180:	fa040613          	addi	a2,s0,-96
    80005184:	4901                	li	s2,0
    80005186:	b77d                	j	80005134 <virtio_disk_rw+0x94>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005188:	fa042503          	lw	a0,-96(s0)
    8000518c:	00451613          	slli	a2,a0,0x4

  if(write)
    80005190:	00016797          	auipc	a5,0x16
    80005194:	1b878793          	addi	a5,a5,440 # 8001b348 <disk>
    80005198:	00451713          	slli	a4,a0,0x4
    8000519c:	0a070713          	addi	a4,a4,160
    800051a0:	973e                	add	a4,a4,a5
    800051a2:	016036b3          	snez	a3,s6
    800051a6:	c714                	sw	a3,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    800051a8:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    800051ac:	01873823          	sd	s8,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    800051b0:	6398                	ld	a4,0(a5)
    800051b2:	9732                	add	a4,a4,a2
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800051b4:	0a860693          	addi	a3,a2,168
    800051b8:	96be                	add	a3,a3,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    800051ba:	e314                	sd	a3,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800051bc:	6394                	ld	a3,0(a5)
    800051be:	00c68833          	add	a6,a3,a2
    800051c2:	4741                	li	a4,16
    800051c4:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800051c8:	4585                	li	a1,1
    800051ca:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    800051ce:	fa442703          	lw	a4,-92(s0)
    800051d2:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    800051d6:	0712                	slli	a4,a4,0x4
    800051d8:	96ba                	add	a3,a3,a4
    800051da:	06098813          	addi	a6,s3,96
    800051de:	0106b023          	sd	a6,0(a3)
  disk.desc[idx[1]].len = BSIZE;
    800051e2:	0007b883          	ld	a7,0(a5)
    800051e6:	9746                	add	a4,a4,a7
    800051e8:	40000693          	li	a3,1024
    800051ec:	c714                	sw	a3,8(a4)
  if(write)
    800051ee:	001b3693          	seqz	a3,s6
    800051f2:	0016969b          	slliw	a3,a3,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800051f6:	8ecd                	or	a3,a3,a1
    800051f8:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800051fc:	fa842683          	lw	a3,-88(s0)
    80005200:	00d71723          	sh	a3,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005204:	00451813          	slli	a6,a0,0x4
    80005208:	02080813          	addi	a6,a6,32
    8000520c:	983e                	add	a6,a6,a5
    8000520e:	577d                	li	a4,-1
    80005210:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80005214:	0692                	slli	a3,a3,0x4
    80005216:	98b6                	add	a7,a7,a3
    80005218:	03060713          	addi	a4,a2,48
    8000521c:	973e                	add	a4,a4,a5
    8000521e:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005222:	6398                	ld	a4,0(a5)
    80005224:	9736                	add	a4,a4,a3
    80005226:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005228:	4689                	li	a3,2
    8000522a:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    8000522e:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005232:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80005236:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    8000523a:	6794                	ld	a3,8(a5)
    8000523c:	0026d703          	lhu	a4,2(a3)
    80005240:	8b1d                	andi	a4,a4,7
    80005242:	0706                	slli	a4,a4,0x1
    80005244:	96ba                	add	a3,a3,a4
    80005246:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    8000524a:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    8000524e:	6798                	ld	a4,8(a5)
    80005250:	00275783          	lhu	a5,2(a4)
    80005254:	2785                	addiw	a5,a5,1
    80005256:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    8000525a:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    8000525e:	100017b7          	lui	a5,0x10001
    80005262:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005266:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    8000526a:	00016917          	auipc	s2,0x16
    8000526e:	20690913          	addi	s2,s2,518 # 8001b470 <disk+0x128>
  while(b->disk == 1) {
    80005272:	84ae                	mv	s1,a1
    80005274:	00b79a63          	bne	a5,a1,80005288 <virtio_disk_rw+0x1e8>
    sleep(b, &disk.vdisk_lock);
    80005278:	85ca                	mv	a1,s2
    8000527a:	854e                	mv	a0,s3
    8000527c:	c5afc0ef          	jal	800016d6 <sleep>
  while(b->disk == 1) {
    80005280:	0049a783          	lw	a5,4(s3)
    80005284:	fe978ae3          	beq	a5,s1,80005278 <virtio_disk_rw+0x1d8>
  }

  disk.info[idx[0]].b = 0;
    80005288:	fa042903          	lw	s2,-96(s0)
    8000528c:	00491713          	slli	a4,s2,0x4
    80005290:	02070713          	addi	a4,a4,32
    80005294:	00016797          	auipc	a5,0x16
    80005298:	0b478793          	addi	a5,a5,180 # 8001b348 <disk>
    8000529c:	97ba                	add	a5,a5,a4
    8000529e:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800052a2:	00016997          	auipc	s3,0x16
    800052a6:	0a698993          	addi	s3,s3,166 # 8001b348 <disk>
    800052aa:	00491713          	slli	a4,s2,0x4
    800052ae:	0009b783          	ld	a5,0(s3)
    800052b2:	97ba                	add	a5,a5,a4
    800052b4:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800052b8:	854a                	mv	a0,s2
    800052ba:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800052be:	ba5ff0ef          	jal	80004e62 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    800052c2:	8885                	andi	s1,s1,1
    800052c4:	f0fd                	bnez	s1,800052aa <virtio_disk_rw+0x20a>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    800052c6:	00016517          	auipc	a0,0x16
    800052ca:	1aa50513          	addi	a0,a0,426 # 8001b470 <disk+0x128>
    800052ce:	781000ef          	jal	8000624e <release>
}
    800052d2:	60e6                	ld	ra,88(sp)
    800052d4:	6446                	ld	s0,80(sp)
    800052d6:	64a6                	ld	s1,72(sp)
    800052d8:	6906                	ld	s2,64(sp)
    800052da:	79e2                	ld	s3,56(sp)
    800052dc:	7a42                	ld	s4,48(sp)
    800052de:	7aa2                	ld	s5,40(sp)
    800052e0:	7b02                	ld	s6,32(sp)
    800052e2:	6be2                	ld	s7,24(sp)
    800052e4:	6c42                	ld	s8,16(sp)
    800052e6:	6125                	addi	sp,sp,96
    800052e8:	8082                	ret

00000000800052ea <virtio_disk_intr>:

void
virtio_disk_intr()
{
    800052ea:	1101                	addi	sp,sp,-32
    800052ec:	ec06                	sd	ra,24(sp)
    800052ee:	e822                	sd	s0,16(sp)
    800052f0:	e426                	sd	s1,8(sp)
    800052f2:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800052f4:	00016497          	auipc	s1,0x16
    800052f8:	05448493          	addi	s1,s1,84 # 8001b348 <disk>
    800052fc:	00016517          	auipc	a0,0x16
    80005300:	17450513          	addi	a0,a0,372 # 8001b470 <disk+0x128>
    80005304:	6a3000ef          	jal	800061a6 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005308:	100017b7          	lui	a5,0x10001
    8000530c:	53bc                	lw	a5,96(a5)
    8000530e:	8b8d                	andi	a5,a5,3
    80005310:	10001737          	lui	a4,0x10001
    80005314:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80005316:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    8000531a:	689c                	ld	a5,16(s1)
    8000531c:	0204d703          	lhu	a4,32(s1)
    80005320:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005324:	04f70863          	beq	a4,a5,80005374 <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80005328:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    8000532c:	6898                	ld	a4,16(s1)
    8000532e:	0204d783          	lhu	a5,32(s1)
    80005332:	8b9d                	andi	a5,a5,7
    80005334:	078e                	slli	a5,a5,0x3
    80005336:	97ba                	add	a5,a5,a4
    80005338:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    8000533a:	00479713          	slli	a4,a5,0x4
    8000533e:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80005342:	9726                	add	a4,a4,s1
    80005344:	01074703          	lbu	a4,16(a4)
    80005348:	e329                	bnez	a4,8000538a <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    8000534a:	0792                	slli	a5,a5,0x4
    8000534c:	02078793          	addi	a5,a5,32
    80005350:	97a6                	add	a5,a5,s1
    80005352:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005354:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005358:	bcafc0ef          	jal	80001722 <wakeup>

    disk.used_idx += 1;
    8000535c:	0204d783          	lhu	a5,32(s1)
    80005360:	2785                	addiw	a5,a5,1
    80005362:	17c2                	slli	a5,a5,0x30
    80005364:	93c1                	srli	a5,a5,0x30
    80005366:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    8000536a:	6898                	ld	a4,16(s1)
    8000536c:	00275703          	lhu	a4,2(a4)
    80005370:	faf71ce3          	bne	a4,a5,80005328 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005374:	00016517          	auipc	a0,0x16
    80005378:	0fc50513          	addi	a0,a0,252 # 8001b470 <disk+0x128>
    8000537c:	6d3000ef          	jal	8000624e <release>
}
    80005380:	60e2                	ld	ra,24(sp)
    80005382:	6442                	ld	s0,16(sp)
    80005384:	64a2                	ld	s1,8(sp)
    80005386:	6105                	addi	sp,sp,32
    80005388:	8082                	ret
      panic("virtio_disk_intr status");
    8000538a:	00003517          	auipc	a0,0x3
    8000538e:	3c650513          	addi	a0,a0,966 # 80008750 <etext+0x750>
    80005392:	2f1000ef          	jal	80005e82 <panic>

0000000080005396 <statswrite>:
int statscopyin(char*, int);
int statslock(char*, int);
  
int
statswrite(int user_src, uint64 src, int n)
{
    80005396:	1141                	addi	sp,sp,-16
    80005398:	e406                	sd	ra,8(sp)
    8000539a:	e022                	sd	s0,0(sp)
    8000539c:	0800                	addi	s0,sp,16
  return -1;
}
    8000539e:	557d                	li	a0,-1
    800053a0:	60a2                	ld	ra,8(sp)
    800053a2:	6402                	ld	s0,0(sp)
    800053a4:	0141                	addi	sp,sp,16
    800053a6:	8082                	ret

00000000800053a8 <statsread>:

int
statsread(int user_dst, uint64 dst, int n)
{
    800053a8:	7179                	addi	sp,sp,-48
    800053aa:	f406                	sd	ra,40(sp)
    800053ac:	f022                	sd	s0,32(sp)
    800053ae:	ec26                	sd	s1,24(sp)
    800053b0:	e44e                	sd	s3,8(sp)
    800053b2:	e052                	sd	s4,0(sp)
    800053b4:	1800                	addi	s0,sp,48
    800053b6:	89aa                	mv	s3,a0
    800053b8:	8a2e                	mv	s4,a1
    800053ba:	84b2                	mv	s1,a2
  int m;

  acquire(&stats.lock);
    800053bc:	00016517          	auipc	a0,0x16
    800053c0:	1c450513          	addi	a0,a0,452 # 8001b580 <stats>
    800053c4:	5e3000ef          	jal	800061a6 <acquire>

  if(stats.sz == 0) {
    800053c8:	00017797          	auipc	a5,0x17
    800053cc:	1d87a783          	lw	a5,472(a5) # 8001c5a0 <stats+0x1020>
    800053d0:	c7b5                	beqz	a5,8000543c <statsread+0x94>
#endif
#ifdef LAB_LOCK
    stats.sz = statslock(stats.buf, BUFSZ);
#endif
  }
  m = stats.sz - stats.off;
    800053d2:	00017797          	auipc	a5,0x17
    800053d6:	1ae78793          	addi	a5,a5,430 # 8001c580 <stats+0x1000>
    800053da:	53d8                	lw	a4,36(a5)
    800053dc:	539c                	lw	a5,32(a5)
    800053de:	9f99                	subw	a5,a5,a4

  if (m > 0) {
    800053e0:	06f05a63          	blez	a5,80005454 <statsread+0xac>
    800053e4:	e84a                	sd	s2,16(sp)
    if(m > n)
    800053e6:	86be                	mv	a3,a5
    800053e8:	00f4d363          	bge	s1,a5,800053ee <statsread+0x46>
    800053ec:	86a6                	mv	a3,s1
    800053ee:	8936                	mv	s2,a3
    800053f0:	0006849b          	sext.w	s1,a3
      m  = n;
    if(either_copyout(user_dst, dst, stats.buf+stats.off, m) != -1) {
    800053f4:	86a6                	mv	a3,s1
    800053f6:	00016617          	auipc	a2,0x16
    800053fa:	1aa60613          	addi	a2,a2,426 # 8001b5a0 <stats+0x20>
    800053fe:	963a                	add	a2,a2,a4
    80005400:	85d2                	mv	a1,s4
    80005402:	854e                	mv	a0,s3
    80005404:	e2cfc0ef          	jal	80001a30 <either_copyout>
    80005408:	57fd                	li	a5,-1
    8000540a:	04f50f63          	beq	a0,a5,80005468 <statsread+0xc0>
      stats.off += m;
    8000540e:	00017717          	auipc	a4,0x17
    80005412:	17270713          	addi	a4,a4,370 # 8001c580 <stats+0x1000>
    80005416:	535c                	lw	a5,36(a4)
    80005418:	00f907bb          	addw	a5,s2,a5
    8000541c:	d35c                	sw	a5,36(a4)
    8000541e:	6942                	ld	s2,16(sp)
  } else {
    m = -1;
    stats.sz = 0;
    stats.off = 0;
  }
  release(&stats.lock);
    80005420:	00016517          	auipc	a0,0x16
    80005424:	16050513          	addi	a0,a0,352 # 8001b580 <stats>
    80005428:	627000ef          	jal	8000624e <release>
  return m;
}
    8000542c:	8526                	mv	a0,s1
    8000542e:	70a2                	ld	ra,40(sp)
    80005430:	7402                	ld	s0,32(sp)
    80005432:	64e2                	ld	s1,24(sp)
    80005434:	69a2                	ld	s3,8(sp)
    80005436:	6a02                	ld	s4,0(sp)
    80005438:	6145                	addi	sp,sp,48
    8000543a:	8082                	ret
    stats.sz = statslock(stats.buf, BUFSZ);
    8000543c:	6585                	lui	a1,0x1
    8000543e:	00016517          	auipc	a0,0x16
    80005442:	16250513          	addi	a0,a0,354 # 8001b5a0 <stats+0x20>
    80005446:	75b000ef          	jal	800063a0 <statslock>
    8000544a:	00017797          	auipc	a5,0x17
    8000544e:	14a7ab23          	sw	a0,342(a5) # 8001c5a0 <stats+0x1020>
    80005452:	b741                	j	800053d2 <statsread+0x2a>
    stats.sz = 0;
    80005454:	00017797          	auipc	a5,0x17
    80005458:	12c78793          	addi	a5,a5,300 # 8001c580 <stats+0x1000>
    8000545c:	0207a023          	sw	zero,32(a5)
    stats.off = 0;
    80005460:	0207a223          	sw	zero,36(a5)
    m = -1;
    80005464:	54fd                	li	s1,-1
    80005466:	bf6d                	j	80005420 <statsread+0x78>
    80005468:	6942                	ld	s2,16(sp)
    8000546a:	bf5d                	j	80005420 <statsread+0x78>

000000008000546c <statsinit>:

void
statsinit(void)
{
    8000546c:	1141                	addi	sp,sp,-16
    8000546e:	e406                	sd	ra,8(sp)
    80005470:	e022                	sd	s0,0(sp)
    80005472:	0800                	addi	s0,sp,16
  initlock(&stats.lock, "stats");
    80005474:	00003597          	auipc	a1,0x3
    80005478:	2f458593          	addi	a1,a1,756 # 80008768 <etext+0x768>
    8000547c:	00016517          	auipc	a0,0x16
    80005480:	10450513          	addi	a0,a0,260 # 8001b580 <stats>
    80005484:	663000ef          	jal	800062e6 <initlock>

  devsw[STATS].read = statsread;
    80005488:	00015797          	auipc	a5,0x15
    8000548c:	e6078793          	addi	a5,a5,-416 # 8001a2e8 <devsw>
    80005490:	00000717          	auipc	a4,0x0
    80005494:	f1870713          	addi	a4,a4,-232 # 800053a8 <statsread>
    80005498:	f398                	sd	a4,32(a5)
  devsw[STATS].write = statswrite;
    8000549a:	00000717          	auipc	a4,0x0
    8000549e:	efc70713          	addi	a4,a4,-260 # 80005396 <statswrite>
    800054a2:	f798                	sd	a4,40(a5)
}
    800054a4:	60a2                	ld	ra,8(sp)
    800054a6:	6402                	ld	s0,0(sp)
    800054a8:	0141                	addi	sp,sp,16
    800054aa:	8082                	ret

00000000800054ac <sprintint>:
  return 1;
}

static int
sprintint(char *s, int xx, int base, int sign)
{
    800054ac:	1101                	addi	sp,sp,-32
    800054ae:	ec06                	sd	ra,24(sp)
    800054b0:	e822                	sd	s0,16(sp)
    800054b2:	1000                	addi	s0,sp,32
    800054b4:	88aa                	mv	a7,a0
  char buf[16];
  int i, n;
  uint x;

  if(sign && (sign = xx < 0))
    800054b6:	c299                	beqz	a3,800054bc <sprintint+0x10>
    800054b8:	0805c263          	bltz	a1,8000553c <sprintint+0x90>
    x = -xx;
  else
    x = xx;
    800054bc:	4e81                	li	t4,0

  i = 0;
    800054be:	fe040693          	addi	a3,s0,-32
    x = xx;
    800054c2:	8736                	mv	a4,a3
  i = 0;
    800054c4:	4501                	li	a0,0
  do {
    buf[i++] = digits[x % base];
    800054c6:	00003317          	auipc	t1,0x3
    800054ca:	49a30313          	addi	t1,t1,1178 # 80008960 <digits>
    800054ce:	8e2a                	mv	t3,a0
    800054d0:	0015081b          	addiw	a6,a0,1
    800054d4:	8542                	mv	a0,a6
    800054d6:	02c5f7bb          	remuw	a5,a1,a2
    800054da:	1782                	slli	a5,a5,0x20
    800054dc:	9381                	srli	a5,a5,0x20
    800054de:	979a                	add	a5,a5,t1
    800054e0:	0007c783          	lbu	a5,0(a5)
    800054e4:	00f70023          	sb	a5,0(a4)
  } while((x /= base) != 0);
    800054e8:	87ae                	mv	a5,a1
    800054ea:	02c5d5bb          	divuw	a1,a1,a2
    800054ee:	0705                	addi	a4,a4,1
    800054f0:	fcc7ffe3          	bgeu	a5,a2,800054ce <sprintint+0x22>

  if(sign)
    800054f4:	000e8c63          	beqz	t4,8000550c <sprintint+0x60>
    buf[i++] = '-';
    800054f8:	ff080793          	addi	a5,a6,-16
    800054fc:	00878833          	add	a6,a5,s0
    80005500:	02d00793          	li	a5,45
    80005504:	fef80823          	sb	a5,-16(a6)
    80005508:	002e051b          	addiw	a0,t3,2

  n = 0;
  while(--i >= 0)
    8000550c:	02a05c63          	blez	a0,80005544 <sprintint+0x98>
    80005510:	fff5059b          	addiw	a1,a0,-1
    80005514:	00b68733          	add	a4,a3,a1
    80005518:	87c6                	mv	a5,a7
    8000551a:	00188613          	addi	a2,a7,1
    8000551e:	1582                	slli	a1,a1,0x20
    80005520:	9181                	srli	a1,a1,0x20
    80005522:	962e                	add	a2,a2,a1
  *s = c;
    80005524:	00074683          	lbu	a3,0(a4)
    80005528:	00d78023          	sb	a3,0(a5)
  while(--i >= 0)
    8000552c:	177d                	addi	a4,a4,-1
    8000552e:	0785                	addi	a5,a5,1
    80005530:	fec79ae3          	bne	a5,a2,80005524 <sprintint+0x78>
    n += sputc(s+n, buf[i]);
  return n;
}
    80005534:	60e2                	ld	ra,24(sp)
    80005536:	6442                	ld	s0,16(sp)
    80005538:	6105                	addi	sp,sp,32
    8000553a:	8082                	ret
    x = -xx;
    8000553c:	40b005bb          	negw	a1,a1
  if(sign && (sign = xx < 0))
    80005540:	4e85                	li	t4,1
    x = -xx;
    80005542:	bfb5                	j	800054be <sprintint+0x12>
  while(--i >= 0)
    80005544:	4501                	li	a0,0
    80005546:	b7fd                	j	80005534 <sprintint+0x88>

0000000080005548 <snprintf>:

int
snprintf(char *buf, unsigned long sz, const char *fmt, ...)
{
    80005548:	7135                	addi	sp,sp,-160
    8000554a:	f486                	sd	ra,104(sp)
    8000554c:	f0a2                	sd	s0,96(sp)
    8000554e:	eca6                	sd	s1,88(sp)
    80005550:	1880                	addi	s0,sp,112
    80005552:	e414                	sd	a3,8(s0)
    80005554:	e818                	sd	a4,16(s0)
    80005556:	ec1c                	sd	a5,24(s0)
    80005558:	03043023          	sd	a6,32(s0)
    8000555c:	03143423          	sd	a7,40(s0)
  va_list ap;
  int i, c;
  int off = 0;
  char *s;

  va_start(ap, fmt);
    80005560:	00840793          	addi	a5,s0,8
    80005564:	f8f43c23          	sd	a5,-104(s0)
  for(i = 0; off < sz && (c = fmt[i] & 0xff) != 0; i++){
    80005568:	c995                	beqz	a1,8000559c <snprintf+0x54>
    8000556a:	e8ca                	sd	s2,80(sp)
    8000556c:	e4ce                	sd	s3,72(sp)
    8000556e:	e0d2                	sd	s4,64(sp)
    80005570:	fc56                	sd	s5,56(sp)
    80005572:	f85a                	sd	s6,48(sp)
    80005574:	f45e                	sd	s7,40(sp)
    80005576:	f062                	sd	s8,32(sp)
    80005578:	ec66                	sd	s9,24(sp)
    8000557a:	e86a                	sd	s10,16(sp)
    8000557c:	8a2a                	mv	s4,a0
    8000557e:	89ae                	mv	s3,a1
    80005580:	8ab2                	mv	s5,a2
    80005582:	4481                	li	s1,0
    80005584:	4901                	li	s2,0
    80005586:	4501                	li	a0,0
    if(c != '%'){
    80005588:	02500b13          	li	s6,37
      continue;
    }
    c = fmt[++i] & 0xff;
    if(c == 0)
      break;
    switch(c){
    8000558c:	07300b93          	li	s7,115
    80005590:	07800d13          	li	s10,120
    case 'd':
      off += sprintint(buf+off, va_arg(ap, int), 10, 1);
      break;
    case 'x':
      off += sprintint(buf+off, va_arg(ap, int), 16, 1);
    80005594:	4c05                	li	s8,1
    switch(c){
    80005596:	06400c93          	li	s9,100
    8000559a:	a819                	j	800055b0 <snprintf+0x68>
  int off = 0;
    8000559c:	4481                	li	s1,0
    8000559e:	a8c5                	j	8000568e <snprintf+0x146>
  *s = c;
    800055a0:	9552                	add	a0,a0,s4
    800055a2:	00f50023          	sb	a5,0(a0)
      off += sputc(buf+off, c);
    800055a6:	2485                	addiw	s1,s1,1
  for(i = 0; off < sz && (c = fmt[i] & 0xff) != 0; i++){
    800055a8:	2905                	addiw	s2,s2,1
    800055aa:	8526                	mv	a0,s1
    800055ac:	1134f163          	bgeu	s1,s3,800056ae <snprintf+0x166>
    800055b0:	012a87b3          	add	a5,s5,s2
    800055b4:	0007c783          	lbu	a5,0(a5)
    800055b8:	0007871b          	sext.w	a4,a5
    800055bc:	c3e1                	beqz	a5,8000567c <snprintf+0x134>
    if(c != '%'){
    800055be:	ff6711e3          	bne	a4,s6,800055a0 <snprintf+0x58>
    c = fmt[++i] & 0xff;
    800055c2:	0019079b          	addiw	a5,s2,1
    800055c6:	893e                	mv	s2,a5
    800055c8:	97d6                	add	a5,a5,s5
    800055ca:	0007c783          	lbu	a5,0(a5)
    if(c == 0)
    800055ce:	c7f1                	beqz	a5,8000569a <snprintf+0x152>
    switch(c){
    800055d0:	05778663          	beq	a5,s7,8000561c <snprintf+0xd4>
    800055d4:	02fbe463          	bltu	s7,a5,800055fc <snprintf+0xb4>
    800055d8:	09678363          	beq	a5,s6,8000565e <snprintf+0x116>
    800055dc:	09979663          	bne	a5,s9,80005668 <snprintf+0x120>
      off += sprintint(buf+off, va_arg(ap, int), 10, 1);
    800055e0:	f9843783          	ld	a5,-104(s0)
    800055e4:	00878713          	addi	a4,a5,8
    800055e8:	f8e43c23          	sd	a4,-104(s0)
    800055ec:	86e2                	mv	a3,s8
    800055ee:	4629                	li	a2,10
    800055f0:	438c                	lw	a1,0(a5)
    800055f2:	9552                	add	a0,a0,s4
    800055f4:	eb9ff0ef          	jal	800054ac <sprintint>
    800055f8:	9ca9                	addw	s1,s1,a0
      break;
    800055fa:	b77d                	j	800055a8 <snprintf+0x60>
    switch(c){
    800055fc:	07a79663          	bne	a5,s10,80005668 <snprintf+0x120>
      off += sprintint(buf+off, va_arg(ap, int), 16, 1);
    80005600:	f9843783          	ld	a5,-104(s0)
    80005604:	00878713          	addi	a4,a5,8
    80005608:	f8e43c23          	sd	a4,-104(s0)
    8000560c:	86e2                	mv	a3,s8
    8000560e:	4641                	li	a2,16
    80005610:	438c                	lw	a1,0(a5)
    80005612:	9552                	add	a0,a0,s4
    80005614:	e99ff0ef          	jal	800054ac <sprintint>
    80005618:	9ca9                	addw	s1,s1,a0
      break;
    8000561a:	b779                	j	800055a8 <snprintf+0x60>
    case 's':
      if((s = va_arg(ap, char*)) == 0)
    8000561c:	f9843783          	ld	a5,-104(s0)
    80005620:	00878713          	addi	a4,a5,8
    80005624:	f8e43c23          	sd	a4,-104(s0)
    80005628:	6398                	ld	a4,0(a5)
    8000562a:	c70d                	beqz	a4,80005654 <snprintf+0x10c>
        s = "(null)";
      for(; *s && off < sz; s++)
    8000562c:	00074683          	lbu	a3,0(a4)
    80005630:	87a6                	mv	a5,s1
    80005632:	f734fbe3          	bgeu	s1,s3,800055a8 <snprintf+0x60>
    80005636:	daad                	beqz	a3,800055a8 <snprintf+0x60>
  *s = c;
    80005638:	00fa0633          	add	a2,s4,a5
    8000563c:	00d60023          	sb	a3,0(a2)
      for(; *s && off < sz; s++)
    80005640:	0705                	addi	a4,a4,1
    80005642:	00074683          	lbu	a3,0(a4)
    80005646:	84be                	mv	s1,a5
    80005648:	0785                	addi	a5,a5,1
    8000564a:	0137f363          	bgeu	a5,s3,80005650 <snprintf+0x108>
    8000564e:	f6ed                	bnez	a3,80005638 <snprintf+0xf0>
        off += sputc(buf+off, *s);
    80005650:	2485                	addiw	s1,s1,1
    80005652:	bf99                	j	800055a8 <snprintf+0x60>
        s = "(null)";
    80005654:	00003717          	auipc	a4,0x3
    80005658:	11c70713          	addi	a4,a4,284 # 80008770 <etext+0x770>
    8000565c:	bfc1                	j	8000562c <snprintf+0xe4>
  *s = c;
    8000565e:	9552                	add	a0,a0,s4
    80005660:	01650023          	sb	s6,0(a0)
      break;
    case '%':
      off += sputc(buf+off, '%');
    80005664:	2485                	addiw	s1,s1,1
      break;
    80005666:	b789                	j	800055a8 <snprintf+0x60>
  *s = c;
    80005668:	9552                	add	a0,a0,s4
    8000566a:	01650023          	sb	s6,0(a0)
    default:
      // Print unknown % sequence to draw attention.
      off += sputc(buf+off, '%');
    8000566e:	0014871b          	addiw	a4,s1,1
  *s = c;
    80005672:	9752                	add	a4,a4,s4
    80005674:	00f70023          	sb	a5,0(a4)
      off += sputc(buf+off, c);
    80005678:	2489                	addiw	s1,s1,2
      break;
    8000567a:	b73d                	j	800055a8 <snprintf+0x60>
    8000567c:	6946                	ld	s2,80(sp)
    8000567e:	69a6                	ld	s3,72(sp)
    80005680:	6a06                	ld	s4,64(sp)
    80005682:	7ae2                	ld	s5,56(sp)
    80005684:	7b42                	ld	s6,48(sp)
    80005686:	7ba2                	ld	s7,40(sp)
    80005688:	7c02                	ld	s8,32(sp)
    8000568a:	6ce2                	ld	s9,24(sp)
    8000568c:	6d42                	ld	s10,16(sp)
    }
  }
  return off;
}
    8000568e:	8526                	mv	a0,s1
    80005690:	70a6                	ld	ra,104(sp)
    80005692:	7406                	ld	s0,96(sp)
    80005694:	64e6                	ld	s1,88(sp)
    80005696:	610d                	addi	sp,sp,160
    80005698:	8082                	ret
    8000569a:	6946                	ld	s2,80(sp)
    8000569c:	69a6                	ld	s3,72(sp)
    8000569e:	6a06                	ld	s4,64(sp)
    800056a0:	7ae2                	ld	s5,56(sp)
    800056a2:	7b42                	ld	s6,48(sp)
    800056a4:	7ba2                	ld	s7,40(sp)
    800056a6:	7c02                	ld	s8,32(sp)
    800056a8:	6ce2                	ld	s9,24(sp)
    800056aa:	6d42                	ld	s10,16(sp)
    800056ac:	b7cd                	j	8000568e <snprintf+0x146>
    800056ae:	6946                	ld	s2,80(sp)
    800056b0:	69a6                	ld	s3,72(sp)
    800056b2:	6a06                	ld	s4,64(sp)
    800056b4:	7ae2                	ld	s5,56(sp)
    800056b6:	7b42                	ld	s6,48(sp)
    800056b8:	7ba2                	ld	s7,40(sp)
    800056ba:	7c02                	ld	s8,32(sp)
    800056bc:	6ce2                	ld	s9,24(sp)
    800056be:	6d42                	ld	s10,16(sp)
    800056c0:	b7f9                	j	8000568e <snprintf+0x146>

00000000800056c2 <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    800056c2:	1141                	addi	sp,sp,-16
    800056c4:	e406                	sd	ra,8(sp)
    800056c6:	e022                	sd	s0,0(sp)
    800056c8:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    800056ca:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    800056ce:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    800056d2:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    800056d6:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    800056da:	577d                	li	a4,-1
    800056dc:	177e                	slli	a4,a4,0x3f
    800056de:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    800056e0:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    800056e4:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    800056e8:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    800056ec:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    800056f0:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    800056f4:	000f4737          	lui	a4,0xf4
    800056f8:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800056fc:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800056fe:	14d79073          	csrw	stimecmp,a5
}
    80005702:	60a2                	ld	ra,8(sp)
    80005704:	6402                	ld	s0,0(sp)
    80005706:	0141                	addi	sp,sp,16
    80005708:	8082                	ret

000000008000570a <start>:
{
    8000570a:	1141                	addi	sp,sp,-16
    8000570c:	e406                	sd	ra,8(sp)
    8000570e:	e022                	sd	s0,0(sp)
    80005710:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80005712:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80005716:	7779                	lui	a4,0xffffe
    80005718:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffd9177>
    8000571c:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000571e:	6705                	lui	a4,0x1
    80005720:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80005724:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80005726:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    8000572a:	ffffb797          	auipc	a5,0xffffb
    8000572e:	f6478793          	addi	a5,a5,-156 # 8000068e <main>
    80005732:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80005736:	4781                	li	a5,0
    80005738:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    8000573c:	67c1                	lui	a5,0x10
    8000573e:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80005740:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80005744:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80005748:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    8000574c:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80005750:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80005754:	57fd                	li	a5,-1
    80005756:	83a9                	srli	a5,a5,0xa
    80005758:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    8000575c:	47bd                	li	a5,15
    8000575e:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80005762:	f61ff0ef          	jal	800056c2 <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80005766:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    8000576a:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    8000576c:	823e                	mv	tp,a5
  asm volatile("mret");
    8000576e:	30200073          	mret
}
    80005772:	60a2                	ld	ra,8(sp)
    80005774:	6402                	ld	s0,0(sp)
    80005776:	0141                	addi	sp,sp,16
    80005778:	8082                	ret

000000008000577a <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    8000577a:	711d                	addi	sp,sp,-96
    8000577c:	ec86                	sd	ra,88(sp)
    8000577e:	e8a2                	sd	s0,80(sp)
    80005780:	e0ca                	sd	s2,64(sp)
    80005782:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    80005784:	04c05763          	blez	a2,800057d2 <consolewrite+0x58>
    80005788:	e4a6                	sd	s1,72(sp)
    8000578a:	fc4e                	sd	s3,56(sp)
    8000578c:	f852                	sd	s4,48(sp)
    8000578e:	f456                	sd	s5,40(sp)
    80005790:	f05a                	sd	s6,32(sp)
    80005792:	ec5e                	sd	s7,24(sp)
    80005794:	8a2a                	mv	s4,a0
    80005796:	84ae                	mv	s1,a1
    80005798:	89b2                	mv	s3,a2
    8000579a:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    8000579c:	faf40b93          	addi	s7,s0,-81
    800057a0:	4b05                	li	s6,1
    800057a2:	5afd                	li	s5,-1
    800057a4:	86da                	mv	a3,s6
    800057a6:	8626                	mv	a2,s1
    800057a8:	85d2                	mv	a1,s4
    800057aa:	855e                	mv	a0,s7
    800057ac:	acefc0ef          	jal	80001a7a <either_copyin>
    800057b0:	03550363          	beq	a0,s5,800057d6 <consolewrite+0x5c>
      break;
    uartputc(c);
    800057b4:	faf44503          	lbu	a0,-81(s0)
    800057b8:	06b000ef          	jal	80006022 <uartputc>
  for(i = 0; i < n; i++){
    800057bc:	2905                	addiw	s2,s2,1
    800057be:	0485                	addi	s1,s1,1
    800057c0:	ff2992e3          	bne	s3,s2,800057a4 <consolewrite+0x2a>
    800057c4:	64a6                	ld	s1,72(sp)
    800057c6:	79e2                	ld	s3,56(sp)
    800057c8:	7a42                	ld	s4,48(sp)
    800057ca:	7aa2                	ld	s5,40(sp)
    800057cc:	7b02                	ld	s6,32(sp)
    800057ce:	6be2                	ld	s7,24(sp)
    800057d0:	a809                	j	800057e2 <consolewrite+0x68>
    800057d2:	4901                	li	s2,0
    800057d4:	a039                	j	800057e2 <consolewrite+0x68>
    800057d6:	64a6                	ld	s1,72(sp)
    800057d8:	79e2                	ld	s3,56(sp)
    800057da:	7a42                	ld	s4,48(sp)
    800057dc:	7aa2                	ld	s5,40(sp)
    800057de:	7b02                	ld	s6,32(sp)
    800057e0:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    800057e2:	854a                	mv	a0,s2
    800057e4:	60e6                	ld	ra,88(sp)
    800057e6:	6446                	ld	s0,80(sp)
    800057e8:	6906                	ld	s2,64(sp)
    800057ea:	6125                	addi	sp,sp,96
    800057ec:	8082                	ret

00000000800057ee <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    800057ee:	711d                	addi	sp,sp,-96
    800057f0:	ec86                	sd	ra,88(sp)
    800057f2:	e8a2                	sd	s0,80(sp)
    800057f4:	e4a6                	sd	s1,72(sp)
    800057f6:	e0ca                	sd	s2,64(sp)
    800057f8:	fc4e                	sd	s3,56(sp)
    800057fa:	f852                	sd	s4,48(sp)
    800057fc:	f05a                	sd	s6,32(sp)
    800057fe:	ec5e                	sd	s7,24(sp)
    80005800:	1080                	addi	s0,sp,96
    80005802:	8b2a                	mv	s6,a0
    80005804:	8a2e                	mv	s4,a1
    80005806:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80005808:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    8000580a:	0001f517          	auipc	a0,0x1f
    8000580e:	da650513          	addi	a0,a0,-602 # 800245b0 <cons>
    80005812:	195000ef          	jal	800061a6 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80005816:	0001f497          	auipc	s1,0x1f
    8000581a:	d9a48493          	addi	s1,s1,-614 # 800245b0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    8000581e:	0001f917          	auipc	s2,0x1f
    80005822:	e3290913          	addi	s2,s2,-462 # 80024650 <cons+0xa0>
  while(n > 0){
    80005826:	0b305b63          	blez	s3,800058dc <consoleread+0xee>
    while(cons.r == cons.w){
    8000582a:	0a04a783          	lw	a5,160(s1)
    8000582e:	0a44a703          	lw	a4,164(s1)
    80005832:	0af71063          	bne	a4,a5,800058d2 <consoleread+0xe4>
      if(killed(myproc())){
    80005836:	8cffb0ef          	jal	80001104 <myproc>
    8000583a:	8d8fc0ef          	jal	80001912 <killed>
    8000583e:	e12d                	bnez	a0,800058a0 <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    80005840:	85a6                	mv	a1,s1
    80005842:	854a                	mv	a0,s2
    80005844:	e93fb0ef          	jal	800016d6 <sleep>
    while(cons.r == cons.w){
    80005848:	0a04a783          	lw	a5,160(s1)
    8000584c:	0a44a703          	lw	a4,164(s1)
    80005850:	fef703e3          	beq	a4,a5,80005836 <consoleread+0x48>
    80005854:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80005856:	0001f717          	auipc	a4,0x1f
    8000585a:	d5a70713          	addi	a4,a4,-678 # 800245b0 <cons>
    8000585e:	0017869b          	addiw	a3,a5,1
    80005862:	0ad72023          	sw	a3,160(a4)
    80005866:	07f7f693          	andi	a3,a5,127
    8000586a:	9736                	add	a4,a4,a3
    8000586c:	02074703          	lbu	a4,32(a4)
    80005870:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    80005874:	4691                	li	a3,4
    80005876:	04da8663          	beq	s5,a3,800058c2 <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    8000587a:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    8000587e:	4685                	li	a3,1
    80005880:	faf40613          	addi	a2,s0,-81
    80005884:	85d2                	mv	a1,s4
    80005886:	855a                	mv	a0,s6
    80005888:	9a8fc0ef          	jal	80001a30 <either_copyout>
    8000588c:	57fd                	li	a5,-1
    8000588e:	04f50663          	beq	a0,a5,800058da <consoleread+0xec>
      break;

    dst++;
    80005892:	0a05                	addi	s4,s4,1
    --n;
    80005894:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80005896:	47a9                	li	a5,10
    80005898:	04fa8b63          	beq	s5,a5,800058ee <consoleread+0x100>
    8000589c:	7aa2                	ld	s5,40(sp)
    8000589e:	b761                	j	80005826 <consoleread+0x38>
        release(&cons.lock);
    800058a0:	0001f517          	auipc	a0,0x1f
    800058a4:	d1050513          	addi	a0,a0,-752 # 800245b0 <cons>
    800058a8:	1a7000ef          	jal	8000624e <release>
        return -1;
    800058ac:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    800058ae:	60e6                	ld	ra,88(sp)
    800058b0:	6446                	ld	s0,80(sp)
    800058b2:	64a6                	ld	s1,72(sp)
    800058b4:	6906                	ld	s2,64(sp)
    800058b6:	79e2                	ld	s3,56(sp)
    800058b8:	7a42                	ld	s4,48(sp)
    800058ba:	7b02                	ld	s6,32(sp)
    800058bc:	6be2                	ld	s7,24(sp)
    800058be:	6125                	addi	sp,sp,96
    800058c0:	8082                	ret
      if(n < target){
    800058c2:	0179fa63          	bgeu	s3,s7,800058d6 <consoleread+0xe8>
        cons.r--;
    800058c6:	0001f717          	auipc	a4,0x1f
    800058ca:	d8f72523          	sw	a5,-630(a4) # 80024650 <cons+0xa0>
    800058ce:	7aa2                	ld	s5,40(sp)
    800058d0:	a031                	j	800058dc <consoleread+0xee>
    800058d2:	f456                	sd	s5,40(sp)
    800058d4:	b749                	j	80005856 <consoleread+0x68>
    800058d6:	7aa2                	ld	s5,40(sp)
    800058d8:	a011                	j	800058dc <consoleread+0xee>
    800058da:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    800058dc:	0001f517          	auipc	a0,0x1f
    800058e0:	cd450513          	addi	a0,a0,-812 # 800245b0 <cons>
    800058e4:	16b000ef          	jal	8000624e <release>
  return target - n;
    800058e8:	413b853b          	subw	a0,s7,s3
    800058ec:	b7c9                	j	800058ae <consoleread+0xc0>
    800058ee:	7aa2                	ld	s5,40(sp)
    800058f0:	b7f5                	j	800058dc <consoleread+0xee>

00000000800058f2 <consputc>:
{
    800058f2:	1141                	addi	sp,sp,-16
    800058f4:	e406                	sd	ra,8(sp)
    800058f6:	e022                	sd	s0,0(sp)
    800058f8:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    800058fa:	10000793          	li	a5,256
    800058fe:	00f50863          	beq	a0,a5,8000590e <consputc+0x1c>
    uartputc_sync(c);
    80005902:	63e000ef          	jal	80005f40 <uartputc_sync>
}
    80005906:	60a2                	ld	ra,8(sp)
    80005908:	6402                	ld	s0,0(sp)
    8000590a:	0141                	addi	sp,sp,16
    8000590c:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000590e:	4521                	li	a0,8
    80005910:	630000ef          	jal	80005f40 <uartputc_sync>
    80005914:	02000513          	li	a0,32
    80005918:	628000ef          	jal	80005f40 <uartputc_sync>
    8000591c:	4521                	li	a0,8
    8000591e:	622000ef          	jal	80005f40 <uartputc_sync>
    80005922:	b7d5                	j	80005906 <consputc+0x14>

0000000080005924 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80005924:	1101                	addi	sp,sp,-32
    80005926:	ec06                	sd	ra,24(sp)
    80005928:	e822                	sd	s0,16(sp)
    8000592a:	e426                	sd	s1,8(sp)
    8000592c:	1000                	addi	s0,sp,32
    8000592e:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80005930:	0001f517          	auipc	a0,0x1f
    80005934:	c8050513          	addi	a0,a0,-896 # 800245b0 <cons>
    80005938:	06f000ef          	jal	800061a6 <acquire>

  switch(c){
    8000593c:	47d5                	li	a5,21
    8000593e:	08f48d63          	beq	s1,a5,800059d8 <consoleintr+0xb4>
    80005942:	0297c563          	blt	a5,s1,8000596c <consoleintr+0x48>
    80005946:	47a1                	li	a5,8
    80005948:	0ef48263          	beq	s1,a5,80005a2c <consoleintr+0x108>
    8000594c:	47c1                	li	a5,16
    8000594e:	10f49363          	bne	s1,a5,80005a54 <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    80005952:	972fc0ef          	jal	80001ac4 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    80005956:	0001f517          	auipc	a0,0x1f
    8000595a:	c5a50513          	addi	a0,a0,-934 # 800245b0 <cons>
    8000595e:	0f1000ef          	jal	8000624e <release>
}
    80005962:	60e2                	ld	ra,24(sp)
    80005964:	6442                	ld	s0,16(sp)
    80005966:	64a2                	ld	s1,8(sp)
    80005968:	6105                	addi	sp,sp,32
    8000596a:	8082                	ret
  switch(c){
    8000596c:	07f00793          	li	a5,127
    80005970:	0af48e63          	beq	s1,a5,80005a2c <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005974:	0001f717          	auipc	a4,0x1f
    80005978:	c3c70713          	addi	a4,a4,-964 # 800245b0 <cons>
    8000597c:	0a872783          	lw	a5,168(a4)
    80005980:	0a072703          	lw	a4,160(a4)
    80005984:	9f99                	subw	a5,a5,a4
    80005986:	07f00713          	li	a4,127
    8000598a:	fcf766e3          	bltu	a4,a5,80005956 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    8000598e:	47b5                	li	a5,13
    80005990:	0cf48563          	beq	s1,a5,80005a5a <consoleintr+0x136>
      consputc(c);
    80005994:	8526                	mv	a0,s1
    80005996:	f5dff0ef          	jal	800058f2 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    8000599a:	0001f717          	auipc	a4,0x1f
    8000599e:	c1670713          	addi	a4,a4,-1002 # 800245b0 <cons>
    800059a2:	0a872683          	lw	a3,168(a4)
    800059a6:	0016879b          	addiw	a5,a3,1
    800059aa:	863e                	mv	a2,a5
    800059ac:	0af72423          	sw	a5,168(a4)
    800059b0:	07f6f693          	andi	a3,a3,127
    800059b4:	9736                	add	a4,a4,a3
    800059b6:	02970023          	sb	s1,32(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    800059ba:	ff648713          	addi	a4,s1,-10
    800059be:	c371                	beqz	a4,80005a82 <consoleintr+0x15e>
    800059c0:	14f1                	addi	s1,s1,-4
    800059c2:	c0e1                	beqz	s1,80005a82 <consoleintr+0x15e>
    800059c4:	0001f717          	auipc	a4,0x1f
    800059c8:	c8c72703          	lw	a4,-884(a4) # 80024650 <cons+0xa0>
    800059cc:	9f99                	subw	a5,a5,a4
    800059ce:	08000713          	li	a4,128
    800059d2:	f8e792e3          	bne	a5,a4,80005956 <consoleintr+0x32>
    800059d6:	a075                	j	80005a82 <consoleintr+0x15e>
    800059d8:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    800059da:	0001f717          	auipc	a4,0x1f
    800059de:	bd670713          	addi	a4,a4,-1066 # 800245b0 <cons>
    800059e2:	0a872783          	lw	a5,168(a4)
    800059e6:	0a472703          	lw	a4,164(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800059ea:	0001f497          	auipc	s1,0x1f
    800059ee:	bc648493          	addi	s1,s1,-1082 # 800245b0 <cons>
    while(cons.e != cons.w &&
    800059f2:	4929                	li	s2,10
    800059f4:	02f70863          	beq	a4,a5,80005a24 <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800059f8:	37fd                	addiw	a5,a5,-1
    800059fa:	07f7f713          	andi	a4,a5,127
    800059fe:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80005a00:	02074703          	lbu	a4,32(a4)
    80005a04:	03270263          	beq	a4,s2,80005a28 <consoleintr+0x104>
      cons.e--;
    80005a08:	0af4a423          	sw	a5,168(s1)
      consputc(BACKSPACE);
    80005a0c:	10000513          	li	a0,256
    80005a10:	ee3ff0ef          	jal	800058f2 <consputc>
    while(cons.e != cons.w &&
    80005a14:	0a84a783          	lw	a5,168(s1)
    80005a18:	0a44a703          	lw	a4,164(s1)
    80005a1c:	fcf71ee3          	bne	a4,a5,800059f8 <consoleintr+0xd4>
    80005a20:	6902                	ld	s2,0(sp)
    80005a22:	bf15                	j	80005956 <consoleintr+0x32>
    80005a24:	6902                	ld	s2,0(sp)
    80005a26:	bf05                	j	80005956 <consoleintr+0x32>
    80005a28:	6902                	ld	s2,0(sp)
    80005a2a:	b735                	j	80005956 <consoleintr+0x32>
    if(cons.e != cons.w){
    80005a2c:	0001f717          	auipc	a4,0x1f
    80005a30:	b8470713          	addi	a4,a4,-1148 # 800245b0 <cons>
    80005a34:	0a872783          	lw	a5,168(a4)
    80005a38:	0a472703          	lw	a4,164(a4)
    80005a3c:	f0f70de3          	beq	a4,a5,80005956 <consoleintr+0x32>
      cons.e--;
    80005a40:	37fd                	addiw	a5,a5,-1
    80005a42:	0001f717          	auipc	a4,0x1f
    80005a46:	c0f72b23          	sw	a5,-1002(a4) # 80024658 <cons+0xa8>
      consputc(BACKSPACE);
    80005a4a:	10000513          	li	a0,256
    80005a4e:	ea5ff0ef          	jal	800058f2 <consputc>
    80005a52:	b711                	j	80005956 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005a54:	f00481e3          	beqz	s1,80005956 <consoleintr+0x32>
    80005a58:	bf31                	j	80005974 <consoleintr+0x50>
      consputc(c);
    80005a5a:	4529                	li	a0,10
    80005a5c:	e97ff0ef          	jal	800058f2 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005a60:	0001f797          	auipc	a5,0x1f
    80005a64:	b5078793          	addi	a5,a5,-1200 # 800245b0 <cons>
    80005a68:	0a87a703          	lw	a4,168(a5)
    80005a6c:	0017069b          	addiw	a3,a4,1
    80005a70:	8636                	mv	a2,a3
    80005a72:	0ad7a423          	sw	a3,168(a5)
    80005a76:	07f77713          	andi	a4,a4,127
    80005a7a:	97ba                	add	a5,a5,a4
    80005a7c:	4729                	li	a4,10
    80005a7e:	02e78023          	sb	a4,32(a5)
        cons.w = cons.e;
    80005a82:	0001f797          	auipc	a5,0x1f
    80005a86:	bcc7a923          	sw	a2,-1070(a5) # 80024654 <cons+0xa4>
        wakeup(&cons.r);
    80005a8a:	0001f517          	auipc	a0,0x1f
    80005a8e:	bc650513          	addi	a0,a0,-1082 # 80024650 <cons+0xa0>
    80005a92:	c91fb0ef          	jal	80001722 <wakeup>
    80005a96:	b5c1                	j	80005956 <consoleintr+0x32>

0000000080005a98 <consoleinit>:

void
consoleinit(void)
{
    80005a98:	1141                	addi	sp,sp,-16
    80005a9a:	e406                	sd	ra,8(sp)
    80005a9c:	e022                	sd	s0,0(sp)
    80005a9e:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80005aa0:	00003597          	auipc	a1,0x3
    80005aa4:	cd858593          	addi	a1,a1,-808 # 80008778 <etext+0x778>
    80005aa8:	0001f517          	auipc	a0,0x1f
    80005aac:	b0850513          	addi	a0,a0,-1272 # 800245b0 <cons>
    80005ab0:	037000ef          	jal	800062e6 <initlock>

  uartinit();
    80005ab4:	436000ef          	jal	80005eea <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80005ab8:	00015797          	auipc	a5,0x15
    80005abc:	83078793          	addi	a5,a5,-2000 # 8001a2e8 <devsw>
    80005ac0:	00000717          	auipc	a4,0x0
    80005ac4:	d2e70713          	addi	a4,a4,-722 # 800057ee <consoleread>
    80005ac8:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80005aca:	00000717          	auipc	a4,0x0
    80005ace:	cb070713          	addi	a4,a4,-848 # 8000577a <consolewrite>
    80005ad2:	ef98                	sd	a4,24(a5)
}
    80005ad4:	60a2                	ld	ra,8(sp)
    80005ad6:	6402                	ld	s0,0(sp)
    80005ad8:	0141                	addi	sp,sp,16
    80005ada:	8082                	ret

0000000080005adc <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80005adc:	7179                	addi	sp,sp,-48
    80005ade:	f406                	sd	ra,40(sp)
    80005ae0:	f022                	sd	s0,32(sp)
    80005ae2:	e84a                	sd	s2,16(sp)
    80005ae4:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80005ae6:	c219                	beqz	a2,80005aec <printint+0x10>
    80005ae8:	08054163          	bltz	a0,80005b6a <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80005aec:	4301                	li	t1,0

  i = 0;
    80005aee:	fd040913          	addi	s2,s0,-48
    x = xx;
    80005af2:	86ca                	mv	a3,s2
  i = 0;
    80005af4:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005af6:	00003817          	auipc	a6,0x3
    80005afa:	e8280813          	addi	a6,a6,-382 # 80008978 <digits>
    80005afe:	88ba                	mv	a7,a4
    80005b00:	0017061b          	addiw	a2,a4,1
    80005b04:	8732                	mv	a4,a2
    80005b06:	02b577b3          	remu	a5,a0,a1
    80005b0a:	97c2                	add	a5,a5,a6
    80005b0c:	0007c783          	lbu	a5,0(a5)
    80005b10:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005b14:	87aa                	mv	a5,a0
    80005b16:	02b55533          	divu	a0,a0,a1
    80005b1a:	0685                	addi	a3,a3,1
    80005b1c:	feb7f1e3          	bgeu	a5,a1,80005afe <printint+0x22>

  if(sign)
    80005b20:	00030c63          	beqz	t1,80005b38 <printint+0x5c>
    buf[i++] = '-';
    80005b24:	fe060793          	addi	a5,a2,-32
    80005b28:	00878633          	add	a2,a5,s0
    80005b2c:	02d00793          	li	a5,45
    80005b30:	fef60823          	sb	a5,-16(a2)
    80005b34:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80005b38:	02e05463          	blez	a4,80005b60 <printint+0x84>
    80005b3c:	ec26                	sd	s1,24(sp)
    80005b3e:	377d                	addiw	a4,a4,-1
    80005b40:	00e904b3          	add	s1,s2,a4
    80005b44:	197d                	addi	s2,s2,-1
    80005b46:	993a                	add	s2,s2,a4
    80005b48:	1702                	slli	a4,a4,0x20
    80005b4a:	9301                	srli	a4,a4,0x20
    80005b4c:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    80005b50:	0004c503          	lbu	a0,0(s1)
    80005b54:	d9fff0ef          	jal	800058f2 <consputc>
  while(--i >= 0)
    80005b58:	14fd                	addi	s1,s1,-1
    80005b5a:	ff249be3          	bne	s1,s2,80005b50 <printint+0x74>
    80005b5e:	64e2                	ld	s1,24(sp)
}
    80005b60:	70a2                	ld	ra,40(sp)
    80005b62:	7402                	ld	s0,32(sp)
    80005b64:	6942                	ld	s2,16(sp)
    80005b66:	6145                	addi	sp,sp,48
    80005b68:	8082                	ret
    x = -xx;
    80005b6a:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    80005b6e:	4305                	li	t1,1
    x = -xx;
    80005b70:	bfbd                	j	80005aee <printint+0x12>

0000000080005b72 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    80005b72:	7131                	addi	sp,sp,-192
    80005b74:	fc86                	sd	ra,120(sp)
    80005b76:	f8a2                	sd	s0,112(sp)
    80005b78:	f0ca                	sd	s2,96(sp)
    80005b7a:	ec6e                	sd	s11,24(sp)
    80005b7c:	0100                	addi	s0,sp,128
    80005b7e:	892a                	mv	s2,a0
    80005b80:	e40c                	sd	a1,8(s0)
    80005b82:	e810                	sd	a2,16(s0)
    80005b84:	ec14                	sd	a3,24(s0)
    80005b86:	f018                	sd	a4,32(s0)
    80005b88:	f41c                	sd	a5,40(s0)
    80005b8a:	03043823          	sd	a6,48(s0)
    80005b8e:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    80005b92:	0001fd97          	auipc	s11,0x1f
    80005b96:	aeedad83          	lw	s11,-1298(s11) # 80024680 <pr+0x20>
  if(locking)
    80005b9a:	020d9d63          	bnez	s11,80005bd4 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80005b9e:	00840793          	addi	a5,s0,8
    80005ba2:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005ba6:	00054503          	lbu	a0,0(a0)
    80005baa:	20050f63          	beqz	a0,80005dc8 <printf+0x256>
    80005bae:	f4a6                	sd	s1,104(sp)
    80005bb0:	ecce                	sd	s3,88(sp)
    80005bb2:	e8d2                	sd	s4,80(sp)
    80005bb4:	e4d6                	sd	s5,72(sp)
    80005bb6:	e0da                	sd	s6,64(sp)
    80005bb8:	fc5e                	sd	s7,56(sp)
    80005bba:	f862                	sd	s8,48(sp)
    80005bbc:	f06a                	sd	s10,32(sp)
    80005bbe:	4a81                	li	s5,0
    if(cx != '%'){
    80005bc0:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80005bc4:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80005bc8:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    80005bcc:	4b29                	li	s6,10
    if(c0 == 'd'){
    80005bce:	06400b93          	li	s7,100
    80005bd2:	a80d                	j	80005c04 <printf+0x92>
    acquire(&pr.lock);
    80005bd4:	0001f517          	auipc	a0,0x1f
    80005bd8:	a8c50513          	addi	a0,a0,-1396 # 80024660 <pr>
    80005bdc:	5ca000ef          	jal	800061a6 <acquire>
  va_start(ap, fmt);
    80005be0:	00840793          	addi	a5,s0,8
    80005be4:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005be8:	00094503          	lbu	a0,0(s2)
    80005bec:	f169                	bnez	a0,80005bae <printf+0x3c>
    80005bee:	aae5                	j	80005de6 <printf+0x274>
      consputc(cx);
    80005bf0:	d03ff0ef          	jal	800058f2 <consputc>
      continue;
    80005bf4:	84d6                	mv	s1,s5
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005bf6:	2485                	addiw	s1,s1,1
    80005bf8:	8aa6                	mv	s5,s1
    80005bfa:	94ca                	add	s1,s1,s2
    80005bfc:	0004c503          	lbu	a0,0(s1)
    80005c00:	1a050a63          	beqz	a0,80005db4 <printf+0x242>
    if(cx != '%'){
    80005c04:	ff3516e3          	bne	a0,s3,80005bf0 <printf+0x7e>
    i++;
    80005c08:	001a879b          	addiw	a5,s5,1
    80005c0c:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    80005c0e:	00f90733          	add	a4,s2,a5
    80005c12:	00074a03          	lbu	s4,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005c16:	1e0a0863          	beqz	s4,80005e06 <printf+0x294>
    80005c1a:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    80005c1e:	1c068b63          	beqz	a3,80005df4 <printf+0x282>
    if(c0 == 'd'){
    80005c22:	037a0863          	beq	s4,s7,80005c52 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005c26:	f94a0713          	addi	a4,s4,-108
    80005c2a:	00173713          	seqz	a4,a4
    80005c2e:	f9c68613          	addi	a2,a3,-100
    80005c32:	ee05                	bnez	a2,80005c6a <printf+0xf8>
    80005c34:	cb1d                	beqz	a4,80005c6a <printf+0xf8>
      printint(va_arg(ap, uint64), 10, 1);
    80005c36:	f8843783          	ld	a5,-120(s0)
    80005c3a:	00878713          	addi	a4,a5,8
    80005c3e:	f8e43423          	sd	a4,-120(s0)
    80005c42:	4605                	li	a2,1
    80005c44:	85da                	mv	a1,s6
    80005c46:	6388                	ld	a0,0(a5)
    80005c48:	e95ff0ef          	jal	80005adc <printint>
      i += 1;
    80005c4c:	002a849b          	addiw	s1,s5,2
    80005c50:	b75d                	j	80005bf6 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    80005c52:	f8843783          	ld	a5,-120(s0)
    80005c56:	00878713          	addi	a4,a5,8
    80005c5a:	f8e43423          	sd	a4,-120(s0)
    80005c5e:	4605                	li	a2,1
    80005c60:	85da                	mv	a1,s6
    80005c62:	4388                	lw	a0,0(a5)
    80005c64:	e79ff0ef          	jal	80005adc <printint>
    80005c68:	b779                	j	80005bf6 <printf+0x84>
    if(c1) c2 = fmt[i+2] & 0xff;
    80005c6a:	97ca                	add	a5,a5,s2
    80005c6c:	8636                	mv	a2,a3
    80005c6e:	0027c683          	lbu	a3,2(a5)
    80005c72:	a245                	j	80005e12 <printf+0x2a0>
      printint(va_arg(ap, uint64), 10, 1);
    80005c74:	f8843783          	ld	a5,-120(s0)
    80005c78:	00878713          	addi	a4,a5,8
    80005c7c:	f8e43423          	sd	a4,-120(s0)
    80005c80:	4605                	li	a2,1
    80005c82:	45a9                	li	a1,10
    80005c84:	6388                	ld	a0,0(a5)
    80005c86:	e57ff0ef          	jal	80005adc <printint>
      i += 2;
    80005c8a:	003a849b          	addiw	s1,s5,3
    80005c8e:	b7a5                	j	80005bf6 <printf+0x84>
      printint(va_arg(ap, int), 10, 0);
    80005c90:	f8843783          	ld	a5,-120(s0)
    80005c94:	00878713          	addi	a4,a5,8
    80005c98:	f8e43423          	sd	a4,-120(s0)
    80005c9c:	4601                	li	a2,0
    80005c9e:	85da                	mv	a1,s6
    80005ca0:	4388                	lw	a0,0(a5)
    80005ca2:	e3bff0ef          	jal	80005adc <printint>
    80005ca6:	bf81                	j	80005bf6 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    80005ca8:	f8843783          	ld	a5,-120(s0)
    80005cac:	00878713          	addi	a4,a5,8
    80005cb0:	f8e43423          	sd	a4,-120(s0)
    80005cb4:	4601                	li	a2,0
    80005cb6:	85da                	mv	a1,s6
    80005cb8:	6388                	ld	a0,0(a5)
    80005cba:	e23ff0ef          	jal	80005adc <printint>
      i += 1;
    80005cbe:	002a849b          	addiw	s1,s5,2
    80005cc2:	bf15                	j	80005bf6 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    80005cc4:	f8843783          	ld	a5,-120(s0)
    80005cc8:	00878713          	addi	a4,a5,8
    80005ccc:	f8e43423          	sd	a4,-120(s0)
    80005cd0:	4601                	li	a2,0
    80005cd2:	45a9                	li	a1,10
    80005cd4:	6388                	ld	a0,0(a5)
    80005cd6:	e07ff0ef          	jal	80005adc <printint>
      i += 2;
    80005cda:	003a849b          	addiw	s1,s5,3
    80005cde:	bf21                	j	80005bf6 <printf+0x84>
      printint(va_arg(ap, int), 16, 0);
    80005ce0:	f8843783          	ld	a5,-120(s0)
    80005ce4:	00878713          	addi	a4,a5,8
    80005ce8:	f8e43423          	sd	a4,-120(s0)
    80005cec:	4601                	li	a2,0
    80005cee:	45c1                	li	a1,16
    80005cf0:	4388                	lw	a0,0(a5)
    80005cf2:	debff0ef          	jal	80005adc <printint>
    80005cf6:	b701                	j	80005bf6 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80005cf8:	f8843783          	ld	a5,-120(s0)
    80005cfc:	00878713          	addi	a4,a5,8
    80005d00:	f8e43423          	sd	a4,-120(s0)
    80005d04:	45c1                	li	a1,16
    80005d06:	6388                	ld	a0,0(a5)
    80005d08:	dd5ff0ef          	jal	80005adc <printint>
      i += 1;
    80005d0c:	002a849b          	addiw	s1,s5,2
    80005d10:	b5dd                	j	80005bf6 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80005d12:	f8843783          	ld	a5,-120(s0)
    80005d16:	00878713          	addi	a4,a5,8
    80005d1a:	f8e43423          	sd	a4,-120(s0)
    80005d1e:	4601                	li	a2,0
    80005d20:	45c1                	li	a1,16
    80005d22:	6388                	ld	a0,0(a5)
    80005d24:	db9ff0ef          	jal	80005adc <printint>
      i += 2;
    80005d28:	003a849b          	addiw	s1,s5,3
    80005d2c:	b5e9                	j	80005bf6 <printf+0x84>
    80005d2e:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    80005d30:	f8843783          	ld	a5,-120(s0)
    80005d34:	00878713          	addi	a4,a5,8
    80005d38:	f8e43423          	sd	a4,-120(s0)
    80005d3c:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    80005d40:	03000513          	li	a0,48
    80005d44:	bafff0ef          	jal	800058f2 <consputc>
  consputc('x');
    80005d48:	07800513          	li	a0,120
    80005d4c:	ba7ff0ef          	jal	800058f2 <consputc>
    80005d50:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80005d52:	00003c97          	auipc	s9,0x3
    80005d56:	c26c8c93          	addi	s9,s9,-986 # 80008978 <digits>
    80005d5a:	03cad793          	srli	a5,s5,0x3c
    80005d5e:	97e6                	add	a5,a5,s9
    80005d60:	0007c503          	lbu	a0,0(a5)
    80005d64:	b8fff0ef          	jal	800058f2 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    80005d68:	0a92                	slli	s5,s5,0x4
    80005d6a:	3a7d                	addiw	s4,s4,-1
    80005d6c:	fe0a17e3          	bnez	s4,80005d5a <printf+0x1e8>
    80005d70:	7ca2                	ld	s9,40(sp)
    80005d72:	b551                	j	80005bf6 <printf+0x84>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80005d74:	f8843783          	ld	a5,-120(s0)
    80005d78:	00878713          	addi	a4,a5,8
    80005d7c:	f8e43423          	sd	a4,-120(s0)
    80005d80:	0007ba03          	ld	s4,0(a5)
    80005d84:	000a0d63          	beqz	s4,80005d9e <printf+0x22c>
        s = "(null)";
      for(; *s; s++)
    80005d88:	000a4503          	lbu	a0,0(s4)
    80005d8c:	e60505e3          	beqz	a0,80005bf6 <printf+0x84>
        consputc(*s);
    80005d90:	b63ff0ef          	jal	800058f2 <consputc>
      for(; *s; s++)
    80005d94:	0a05                	addi	s4,s4,1
    80005d96:	000a4503          	lbu	a0,0(s4)
    80005d9a:	f97d                	bnez	a0,80005d90 <printf+0x21e>
    80005d9c:	bda9                	j	80005bf6 <printf+0x84>
        s = "(null)";
    80005d9e:	00003a17          	auipc	s4,0x3
    80005da2:	9d2a0a13          	addi	s4,s4,-1582 # 80008770 <etext+0x770>
      for(; *s; s++)
    80005da6:	02800513          	li	a0,40
    80005daa:	b7dd                	j	80005d90 <printf+0x21e>
    } else if(c0 == '%'){
      consputc('%');
    80005dac:	8552                	mv	a0,s4
    80005dae:	b45ff0ef          	jal	800058f2 <consputc>
    80005db2:	b591                	j	80005bf6 <printf+0x84>
    }
#endif
  }
  va_end(ap);

  if(locking)
    80005db4:	020d9163          	bnez	s11,80005dd6 <printf+0x264>
    80005db8:	74a6                	ld	s1,104(sp)
    80005dba:	69e6                	ld	s3,88(sp)
    80005dbc:	6a46                	ld	s4,80(sp)
    80005dbe:	6aa6                	ld	s5,72(sp)
    80005dc0:	6b06                	ld	s6,64(sp)
    80005dc2:	7be2                	ld	s7,56(sp)
    80005dc4:	7c42                	ld	s8,48(sp)
    80005dc6:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    80005dc8:	4501                	li	a0,0
    80005dca:	70e6                	ld	ra,120(sp)
    80005dcc:	7446                	ld	s0,112(sp)
    80005dce:	7906                	ld	s2,96(sp)
    80005dd0:	6de2                	ld	s11,24(sp)
    80005dd2:	6129                	addi	sp,sp,192
    80005dd4:	8082                	ret
    80005dd6:	74a6                	ld	s1,104(sp)
    80005dd8:	69e6                	ld	s3,88(sp)
    80005dda:	6a46                	ld	s4,80(sp)
    80005ddc:	6aa6                	ld	s5,72(sp)
    80005dde:	6b06                	ld	s6,64(sp)
    80005de0:	7be2                	ld	s7,56(sp)
    80005de2:	7c42                	ld	s8,48(sp)
    80005de4:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80005de6:	0001f517          	auipc	a0,0x1f
    80005dea:	87a50513          	addi	a0,a0,-1926 # 80024660 <pr>
    80005dee:	460000ef          	jal	8000624e <release>
    80005df2:	bfd9                	j	80005dc8 <printf+0x256>
    if(c0 == 'd'){
    80005df4:	e57a0fe3          	beq	s4,s7,80005c52 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80005df8:	f94a0713          	addi	a4,s4,-108
    80005dfc:	00173713          	seqz	a4,a4
    80005e00:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    80005e02:	4781                	li	a5,0
    80005e04:	a00d                	j	80005e26 <printf+0x2b4>
    } else if(c0 == 'l' && c1 == 'd'){
    80005e06:	f94a0713          	addi	a4,s4,-108
    80005e0a:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    80005e0e:	8652                	mv	a2,s4
    80005e10:	86d2                	mv	a3,s4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    80005e12:	f9460793          	addi	a5,a2,-108
    80005e16:	0017b793          	seqz	a5,a5
    80005e1a:	8ff9                	and	a5,a5,a4
    80005e1c:	f9c68593          	addi	a1,a3,-100
    80005e20:	e199                	bnez	a1,80005e26 <printf+0x2b4>
    80005e22:	e40799e3          	bnez	a5,80005c74 <printf+0x102>
    } else if(c0 == 'u'){
    80005e26:	e78a05e3          	beq	s4,s8,80005c90 <printf+0x11e>
    } else if(c0 == 'l' && c1 == 'u'){
    80005e2a:	f8b60593          	addi	a1,a2,-117
    80005e2e:	e199                	bnez	a1,80005e34 <printf+0x2c2>
    80005e30:	e6071ce3          	bnez	a4,80005ca8 <printf+0x136>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005e34:	f8b68593          	addi	a1,a3,-117
    80005e38:	e199                	bnez	a1,80005e3e <printf+0x2cc>
    80005e3a:	e80795e3          	bnez	a5,80005cc4 <printf+0x152>
    } else if(c0 == 'x'){
    80005e3e:	ebaa01e3          	beq	s4,s10,80005ce0 <printf+0x16e>
    } else if(c0 == 'l' && c1 == 'x'){
    80005e42:	f8860613          	addi	a2,a2,-120
    80005e46:	e219                	bnez	a2,80005e4c <printf+0x2da>
    80005e48:	ea0718e3          	bnez	a4,80005cf8 <printf+0x186>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    80005e4c:	f8868693          	addi	a3,a3,-120
    80005e50:	e299                	bnez	a3,80005e56 <printf+0x2e4>
    80005e52:	ec0790e3          	bnez	a5,80005d12 <printf+0x1a0>
    } else if(c0 == 'p'){
    80005e56:	07000793          	li	a5,112
    80005e5a:	ecfa0ae3          	beq	s4,a5,80005d2e <printf+0x1bc>
    } else if(c0 == 's'){
    80005e5e:	07300793          	li	a5,115
    80005e62:	f0fa09e3          	beq	s4,a5,80005d74 <printf+0x202>
    } else if(c0 == '%'){
    80005e66:	02500793          	li	a5,37
    80005e6a:	f4fa01e3          	beq	s4,a5,80005dac <printf+0x23a>
    } else if(c0 == 0){
    80005e6e:	f40a03e3          	beqz	s4,80005db4 <printf+0x242>
      consputc('%');
    80005e72:	02500513          	li	a0,37
    80005e76:	a7dff0ef          	jal	800058f2 <consputc>
      consputc(c0);
    80005e7a:	8552                	mv	a0,s4
    80005e7c:	a77ff0ef          	jal	800058f2 <consputc>
    80005e80:	bb9d                	j	80005bf6 <printf+0x84>

0000000080005e82 <panic>:

void
panic(char *s)
{
    80005e82:	1101                	addi	sp,sp,-32
    80005e84:	ec06                	sd	ra,24(sp)
    80005e86:	e822                	sd	s0,16(sp)
    80005e88:	e426                	sd	s1,8(sp)
    80005e8a:	1000                	addi	s0,sp,32
    80005e8c:	84aa                	mv	s1,a0
  pr.locking = 0;
    80005e8e:	0001e797          	auipc	a5,0x1e
    80005e92:	7e07a923          	sw	zero,2034(a5) # 80024680 <pr+0x20>
  printf("panic: ");
    80005e96:	00003517          	auipc	a0,0x3
    80005e9a:	8ea50513          	addi	a0,a0,-1814 # 80008780 <etext+0x780>
    80005e9e:	cd5ff0ef          	jal	80005b72 <printf>
  printf("%s\n", s);
    80005ea2:	85a6                	mv	a1,s1
    80005ea4:	00003517          	auipc	a0,0x3
    80005ea8:	8e450513          	addi	a0,a0,-1820 # 80008788 <etext+0x788>
    80005eac:	cc7ff0ef          	jal	80005b72 <printf>
  panicked = 1; // freeze uart output from other CPUs
    80005eb0:	4785                	li	a5,1
    80005eb2:	00003717          	auipc	a4,0x3
    80005eb6:	b4f72523          	sw	a5,-1206(a4) # 800089fc <panicked>
  for(;;)
    80005eba:	a001                	j	80005eba <panic+0x38>

0000000080005ebc <printfinit>:
    ;
}

void
printfinit(void)
{
    80005ebc:	1141                	addi	sp,sp,-16
    80005ebe:	e406                	sd	ra,8(sp)
    80005ec0:	e022                	sd	s0,0(sp)
    80005ec2:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80005ec4:	00003597          	auipc	a1,0x3
    80005ec8:	8cc58593          	addi	a1,a1,-1844 # 80008790 <etext+0x790>
    80005ecc:	0001e517          	auipc	a0,0x1e
    80005ed0:	79450513          	addi	a0,a0,1940 # 80024660 <pr>
    80005ed4:	412000ef          	jal	800062e6 <initlock>
  pr.locking = 1;
    80005ed8:	4785                	li	a5,1
    80005eda:	0001e717          	auipc	a4,0x1e
    80005ede:	7af72323          	sw	a5,1958(a4) # 80024680 <pr+0x20>
}
    80005ee2:	60a2                	ld	ra,8(sp)
    80005ee4:	6402                	ld	s0,0(sp)
    80005ee6:	0141                	addi	sp,sp,16
    80005ee8:	8082                	ret

0000000080005eea <uartinit>:

void uartstart();

void
uartinit(void)
{
    80005eea:	1141                	addi	sp,sp,-16
    80005eec:	e406                	sd	ra,8(sp)
    80005eee:	e022                	sd	s0,0(sp)
    80005ef0:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80005ef2:	100007b7          	lui	a5,0x10000
    80005ef6:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80005efa:	10000737          	lui	a4,0x10000
    80005efe:	f8000693          	li	a3,-128
    80005f02:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005f06:	468d                	li	a3,3
    80005f08:	10000637          	lui	a2,0x10000
    80005f0c:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80005f10:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80005f14:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80005f18:	8732                	mv	a4,a2
    80005f1a:	461d                	li	a2,7
    80005f1c:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80005f20:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80005f24:	00003597          	auipc	a1,0x3
    80005f28:	87458593          	addi	a1,a1,-1932 # 80008798 <etext+0x798>
    80005f2c:	0001e517          	auipc	a0,0x1e
    80005f30:	75c50513          	addi	a0,a0,1884 # 80024688 <uart_tx_lock>
    80005f34:	3b2000ef          	jal	800062e6 <initlock>
}
    80005f38:	60a2                	ld	ra,8(sp)
    80005f3a:	6402                	ld	s0,0(sp)
    80005f3c:	0141                	addi	sp,sp,16
    80005f3e:	8082                	ret

0000000080005f40 <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80005f40:	1101                	addi	sp,sp,-32
    80005f42:	ec06                	sd	ra,24(sp)
    80005f44:	e822                	sd	s0,16(sp)
    80005f46:	e426                	sd	s1,8(sp)
    80005f48:	1000                	addi	s0,sp,32
    80005f4a:	84aa                	mv	s1,a0
  push_off();
    80005f4c:	216000ef          	jal	80006162 <push_off>

  if(panicked){
    80005f50:	00003797          	auipc	a5,0x3
    80005f54:	aac7a783          	lw	a5,-1364(a5) # 800089fc <panicked>
    80005f58:	e795                	bnez	a5,80005f84 <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80005f5a:	10000737          	lui	a4,0x10000
    80005f5e:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80005f60:	00074783          	lbu	a5,0(a4)
    80005f64:	0207f793          	andi	a5,a5,32
    80005f68:	dfe5                	beqz	a5,80005f60 <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    80005f6a:	0ff4f513          	zext.b	a0,s1
    80005f6e:	100007b7          	lui	a5,0x10000
    80005f72:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80005f76:	288000ef          	jal	800061fe <pop_off>
}
    80005f7a:	60e2                	ld	ra,24(sp)
    80005f7c:	6442                	ld	s0,16(sp)
    80005f7e:	64a2                	ld	s1,8(sp)
    80005f80:	6105                	addi	sp,sp,32
    80005f82:	8082                	ret
    for(;;)
    80005f84:	a001                	j	80005f84 <uartputc_sync+0x44>

0000000080005f86 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80005f86:	00003797          	auipc	a5,0x3
    80005f8a:	a7a7b783          	ld	a5,-1414(a5) # 80008a00 <uart_tx_r>
    80005f8e:	00003717          	auipc	a4,0x3
    80005f92:	a7a73703          	ld	a4,-1414(a4) # 80008a08 <uart_tx_w>
    80005f96:	08f70163          	beq	a4,a5,80006018 <uartstart+0x92>
{
    80005f9a:	7139                	addi	sp,sp,-64
    80005f9c:	fc06                	sd	ra,56(sp)
    80005f9e:	f822                	sd	s0,48(sp)
    80005fa0:	f426                	sd	s1,40(sp)
    80005fa2:	f04a                	sd	s2,32(sp)
    80005fa4:	ec4e                	sd	s3,24(sp)
    80005fa6:	e852                	sd	s4,16(sp)
    80005fa8:	e456                	sd	s5,8(sp)
    80005faa:	e05a                	sd	s6,0(sp)
    80005fac:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005fae:	10000937          	lui	s2,0x10000
    80005fb2:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005fb4:	0001ea97          	auipc	s5,0x1e
    80005fb8:	6d4a8a93          	addi	s5,s5,1748 # 80024688 <uart_tx_lock>
    uart_tx_r += 1;
    80005fbc:	00003497          	auipc	s1,0x3
    80005fc0:	a4448493          	addi	s1,s1,-1468 # 80008a00 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    80005fc4:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80005fc8:	00003997          	auipc	s3,0x3
    80005fcc:	a4098993          	addi	s3,s3,-1472 # 80008a08 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005fd0:	00094703          	lbu	a4,0(s2)
    80005fd4:	02077713          	andi	a4,a4,32
    80005fd8:	c715                	beqz	a4,80006004 <uartstart+0x7e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005fda:	01f7f713          	andi	a4,a5,31
    80005fde:	9756                	add	a4,a4,s5
    80005fe0:	02074b03          	lbu	s6,32(a4)
    uart_tx_r += 1;
    80005fe4:	0785                	addi	a5,a5,1
    80005fe6:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80005fe8:	8526                	mv	a0,s1
    80005fea:	f38fb0ef          	jal	80001722 <wakeup>
    WriteReg(THR, c);
    80005fee:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    80005ff2:	609c                	ld	a5,0(s1)
    80005ff4:	0009b703          	ld	a4,0(s3)
    80005ff8:	fcf71ce3          	bne	a4,a5,80005fd0 <uartstart+0x4a>
      ReadReg(ISR);
    80005ffc:	100007b7          	lui	a5,0x10000
    80006000:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80006004:	70e2                	ld	ra,56(sp)
    80006006:	7442                	ld	s0,48(sp)
    80006008:	74a2                	ld	s1,40(sp)
    8000600a:	7902                	ld	s2,32(sp)
    8000600c:	69e2                	ld	s3,24(sp)
    8000600e:	6a42                	ld	s4,16(sp)
    80006010:	6aa2                	ld	s5,8(sp)
    80006012:	6b02                	ld	s6,0(sp)
    80006014:	6121                	addi	sp,sp,64
    80006016:	8082                	ret
      ReadReg(ISR);
    80006018:	100007b7          	lui	a5,0x10000
    8000601c:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    80006020:	8082                	ret

0000000080006022 <uartputc>:
{
    80006022:	7179                	addi	sp,sp,-48
    80006024:	f406                	sd	ra,40(sp)
    80006026:	f022                	sd	s0,32(sp)
    80006028:	ec26                	sd	s1,24(sp)
    8000602a:	e84a                	sd	s2,16(sp)
    8000602c:	e44e                	sd	s3,8(sp)
    8000602e:	e052                	sd	s4,0(sp)
    80006030:	1800                	addi	s0,sp,48
    80006032:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    80006034:	0001e517          	auipc	a0,0x1e
    80006038:	65450513          	addi	a0,a0,1620 # 80024688 <uart_tx_lock>
    8000603c:	16a000ef          	jal	800061a6 <acquire>
  if(panicked){
    80006040:	00003797          	auipc	a5,0x3
    80006044:	9bc7a783          	lw	a5,-1604(a5) # 800089fc <panicked>
    80006048:	e3d1                	bnez	a5,800060cc <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000604a:	00003717          	auipc	a4,0x3
    8000604e:	9be73703          	ld	a4,-1602(a4) # 80008a08 <uart_tx_w>
    80006052:	00003797          	auipc	a5,0x3
    80006056:	9ae7b783          	ld	a5,-1618(a5) # 80008a00 <uart_tx_r>
    8000605a:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    8000605e:	0001e997          	auipc	s3,0x1e
    80006062:	62a98993          	addi	s3,s3,1578 # 80024688 <uart_tx_lock>
    80006066:	00003497          	auipc	s1,0x3
    8000606a:	99a48493          	addi	s1,s1,-1638 # 80008a00 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000606e:	00003917          	auipc	s2,0x3
    80006072:	99a90913          	addi	s2,s2,-1638 # 80008a08 <uart_tx_w>
    80006076:	00e79d63          	bne	a5,a4,80006090 <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    8000607a:	85ce                	mv	a1,s3
    8000607c:	8526                	mv	a0,s1
    8000607e:	e58fb0ef          	jal	800016d6 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80006082:	00093703          	ld	a4,0(s2)
    80006086:	609c                	ld	a5,0(s1)
    80006088:	02078793          	addi	a5,a5,32
    8000608c:	fee787e3          	beq	a5,a4,8000607a <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    80006090:	01f77693          	andi	a3,a4,31
    80006094:	0001e797          	auipc	a5,0x1e
    80006098:	5f478793          	addi	a5,a5,1524 # 80024688 <uart_tx_lock>
    8000609c:	97b6                	add	a5,a5,a3
    8000609e:	03478023          	sb	s4,32(a5)
  uart_tx_w += 1;
    800060a2:	0705                	addi	a4,a4,1
    800060a4:	00003797          	auipc	a5,0x3
    800060a8:	96e7b223          	sd	a4,-1692(a5) # 80008a08 <uart_tx_w>
  uartstart();
    800060ac:	edbff0ef          	jal	80005f86 <uartstart>
  release(&uart_tx_lock);
    800060b0:	0001e517          	auipc	a0,0x1e
    800060b4:	5d850513          	addi	a0,a0,1496 # 80024688 <uart_tx_lock>
    800060b8:	196000ef          	jal	8000624e <release>
}
    800060bc:	70a2                	ld	ra,40(sp)
    800060be:	7402                	ld	s0,32(sp)
    800060c0:	64e2                	ld	s1,24(sp)
    800060c2:	6942                	ld	s2,16(sp)
    800060c4:	69a2                	ld	s3,8(sp)
    800060c6:	6a02                	ld	s4,0(sp)
    800060c8:	6145                	addi	sp,sp,48
    800060ca:	8082                	ret
    for(;;)
    800060cc:	a001                	j	800060cc <uartputc+0xaa>

00000000800060ce <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800060ce:	1141                	addi	sp,sp,-16
    800060d0:	e406                	sd	ra,8(sp)
    800060d2:	e022                	sd	s0,0(sp)
    800060d4:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    800060d6:	100007b7          	lui	a5,0x10000
    800060da:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800060de:	8b85                	andi	a5,a5,1
    800060e0:	cb89                	beqz	a5,800060f2 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800060e2:	100007b7          	lui	a5,0x10000
    800060e6:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800060ea:	60a2                	ld	ra,8(sp)
    800060ec:	6402                	ld	s0,0(sp)
    800060ee:	0141                	addi	sp,sp,16
    800060f0:	8082                	ret
    return -1;
    800060f2:	557d                	li	a0,-1
    800060f4:	bfdd                	j	800060ea <uartgetc+0x1c>

00000000800060f6 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800060f6:	1101                	addi	sp,sp,-32
    800060f8:	ec06                	sd	ra,24(sp)
    800060fa:	e822                	sd	s0,16(sp)
    800060fc:	e426                	sd	s1,8(sp)
    800060fe:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80006100:	54fd                	li	s1,-1
    int c = uartgetc();
    80006102:	fcdff0ef          	jal	800060ce <uartgetc>
    if(c == -1)
    80006106:	00950563          	beq	a0,s1,80006110 <uartintr+0x1a>
      break;
    consoleintr(c);
    8000610a:	81bff0ef          	jal	80005924 <consoleintr>
  while(1){
    8000610e:	bfd5                	j	80006102 <uartintr+0xc>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80006110:	0001e517          	auipc	a0,0x1e
    80006114:	57850513          	addi	a0,a0,1400 # 80024688 <uart_tx_lock>
    80006118:	08e000ef          	jal	800061a6 <acquire>
  uartstart();
    8000611c:	e6bff0ef          	jal	80005f86 <uartstart>
  release(&uart_tx_lock);
    80006120:	0001e517          	auipc	a0,0x1e
    80006124:	56850513          	addi	a0,a0,1384 # 80024688 <uart_tx_lock>
    80006128:	126000ef          	jal	8000624e <release>
}
    8000612c:	60e2                	ld	ra,24(sp)
    8000612e:	6442                	ld	s0,16(sp)
    80006130:	64a2                	ld	s1,8(sp)
    80006132:	6105                	addi	sp,sp,32
    80006134:	8082                	ret

0000000080006136 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80006136:	411c                	lw	a5,0(a0)
    80006138:	e399                	bnez	a5,8000613e <holding+0x8>
    8000613a:	4501                	li	a0,0
  return r;
}
    8000613c:	8082                	ret
{
    8000613e:	1101                	addi	sp,sp,-32
    80006140:	ec06                	sd	ra,24(sp)
    80006142:	e822                	sd	s0,16(sp)
    80006144:	e426                	sd	s1,8(sp)
    80006146:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80006148:	691c                	ld	a5,16(a0)
    8000614a:	84be                	mv	s1,a5
    8000614c:	f99fa0ef          	jal	800010e4 <mycpu>
    80006150:	40a48533          	sub	a0,s1,a0
    80006154:	00153513          	seqz	a0,a0
}
    80006158:	60e2                	ld	ra,24(sp)
    8000615a:	6442                	ld	s0,16(sp)
    8000615c:	64a2                	ld	s1,8(sp)
    8000615e:	6105                	addi	sp,sp,32
    80006160:	8082                	ret

0000000080006162 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80006162:	1101                	addi	sp,sp,-32
    80006164:	ec06                	sd	ra,24(sp)
    80006166:	e822                	sd	s0,16(sp)
    80006168:	e426                	sd	s1,8(sp)
    8000616a:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000616c:	100027f3          	csrr	a5,sstatus
    80006170:	84be                	mv	s1,a5
    80006172:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80006176:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80006178:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    8000617c:	f69fa0ef          	jal	800010e4 <mycpu>
    80006180:	5d3c                	lw	a5,120(a0)
    80006182:	cb99                	beqz	a5,80006198 <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80006184:	f61fa0ef          	jal	800010e4 <mycpu>
    80006188:	5d3c                	lw	a5,120(a0)
    8000618a:	2785                	addiw	a5,a5,1
    8000618c:	dd3c                	sw	a5,120(a0)
}
    8000618e:	60e2                	ld	ra,24(sp)
    80006190:	6442                	ld	s0,16(sp)
    80006192:	64a2                	ld	s1,8(sp)
    80006194:	6105                	addi	sp,sp,32
    80006196:	8082                	ret
    mycpu()->intena = old;
    80006198:	f4dfa0ef          	jal	800010e4 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    8000619c:	0014d793          	srli	a5,s1,0x1
    800061a0:	8b85                	andi	a5,a5,1
    800061a2:	dd7c                	sw	a5,124(a0)
    800061a4:	b7c5                	j	80006184 <push_off+0x22>

00000000800061a6 <acquire>:
{
    800061a6:	1101                	addi	sp,sp,-32
    800061a8:	ec06                	sd	ra,24(sp)
    800061aa:	e822                	sd	s0,16(sp)
    800061ac:	e426                	sd	s1,8(sp)
    800061ae:	1000                	addi	s0,sp,32
    800061b0:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    800061b2:	fb1ff0ef          	jal	80006162 <push_off>
  if(holding(lk))
    800061b6:	8526                	mv	a0,s1
    800061b8:	f7fff0ef          	jal	80006136 <holding>
    800061bc:	e901                	bnez	a0,800061cc <acquire+0x26>
    __sync_fetch_and_add(&(lk->n), 1);
    800061be:	4785                	li	a5,1
    800061c0:	01c48713          	addi	a4,s1,28
    800061c4:	06f7202f          	amoadd.w.aqrl	zero,a5,(a4)
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0) {
    800061c8:	873e                	mv	a4,a5
    800061ca:	a819                	j	800061e0 <acquire+0x3a>
    panic("acquire");
    800061cc:	00002517          	auipc	a0,0x2
    800061d0:	5d450513          	addi	a0,a0,1492 # 800087a0 <etext+0x7a0>
    800061d4:	cafff0ef          	jal	80005e82 <panic>
    __sync_fetch_and_add(&(lk->nts), 1);
    800061d8:	01848793          	addi	a5,s1,24
    800061dc:	06e7a02f          	amoadd.w.aqrl	zero,a4,(a5)
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0) {
    800061e0:	87ba                	mv	a5,a4
    800061e2:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    800061e6:	2781                	sext.w	a5,a5
    800061e8:	fbe5                	bnez	a5,800061d8 <acquire+0x32>
  __sync_synchronize();
    800061ea:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    800061ee:	ef7fa0ef          	jal	800010e4 <mycpu>
    800061f2:	e888                	sd	a0,16(s1)
}
    800061f4:	60e2                	ld	ra,24(sp)
    800061f6:	6442                	ld	s0,16(sp)
    800061f8:	64a2                	ld	s1,8(sp)
    800061fa:	6105                	addi	sp,sp,32
    800061fc:	8082                	ret

00000000800061fe <pop_off>:

void
pop_off(void)
{
    800061fe:	1141                	addi	sp,sp,-16
    80006200:	e406                	sd	ra,8(sp)
    80006202:	e022                	sd	s0,0(sp)
    80006204:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80006206:	edffa0ef          	jal	800010e4 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000620a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000620e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80006210:	e39d                	bnez	a5,80006236 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80006212:	5d3c                	lw	a5,120(a0)
    80006214:	02f05763          	blez	a5,80006242 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80006218:	37fd                	addiw	a5,a5,-1
    8000621a:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    8000621c:	eb89                	bnez	a5,8000622e <pop_off+0x30>
    8000621e:	5d7c                	lw	a5,124(a0)
    80006220:	c799                	beqz	a5,8000622e <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80006222:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80006226:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000622a:	10079073          	csrw	sstatus,a5
    intr_on();
}
    8000622e:	60a2                	ld	ra,8(sp)
    80006230:	6402                	ld	s0,0(sp)
    80006232:	0141                	addi	sp,sp,16
    80006234:	8082                	ret
    panic("pop_off - interruptible");
    80006236:	00002517          	auipc	a0,0x2
    8000623a:	57250513          	addi	a0,a0,1394 # 800087a8 <etext+0x7a8>
    8000623e:	c45ff0ef          	jal	80005e82 <panic>
    panic("pop_off");
    80006242:	00002517          	auipc	a0,0x2
    80006246:	57e50513          	addi	a0,a0,1406 # 800087c0 <etext+0x7c0>
    8000624a:	c39ff0ef          	jal	80005e82 <panic>

000000008000624e <release>:
{
    8000624e:	1101                	addi	sp,sp,-32
    80006250:	ec06                	sd	ra,24(sp)
    80006252:	e822                	sd	s0,16(sp)
    80006254:	e426                	sd	s1,8(sp)
    80006256:	1000                	addi	s0,sp,32
    80006258:	84aa                	mv	s1,a0
  if(!holding(lk))
    8000625a:	eddff0ef          	jal	80006136 <holding>
    8000625e:	c105                	beqz	a0,8000627e <release+0x30>
  lk->cpu = 0;
    80006260:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80006264:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80006268:	0310000f          	fence	rw,w
    8000626c:	0004a023          	sw	zero,0(s1)
  pop_off();
    80006270:	f8fff0ef          	jal	800061fe <pop_off>
}
    80006274:	60e2                	ld	ra,24(sp)
    80006276:	6442                	ld	s0,16(sp)
    80006278:	64a2                	ld	s1,8(sp)
    8000627a:	6105                	addi	sp,sp,32
    8000627c:	8082                	ret
    panic("release");
    8000627e:	00002517          	auipc	a0,0x2
    80006282:	54a50513          	addi	a0,a0,1354 # 800087c8 <etext+0x7c8>
    80006286:	bfdff0ef          	jal	80005e82 <panic>

000000008000628a <freelock>:
{
    8000628a:	1101                	addi	sp,sp,-32
    8000628c:	ec06                	sd	ra,24(sp)
    8000628e:	e822                	sd	s0,16(sp)
    80006290:	e426                	sd	s1,8(sp)
    80006292:	1000                	addi	s0,sp,32
    80006294:	84aa                	mv	s1,a0
  acquire(&lock_locks);
    80006296:	0001e517          	auipc	a0,0x1e
    8000629a:	43250513          	addi	a0,a0,1074 # 800246c8 <lock_locks>
    8000629e:	f09ff0ef          	jal	800061a6 <acquire>
  for (i = 0; i < NLOCK; i++) {
    800062a2:	0001e717          	auipc	a4,0x1e
    800062a6:	44670713          	addi	a4,a4,1094 # 800246e8 <locks>
    800062aa:	4781                	li	a5,0
    800062ac:	1f400613          	li	a2,500
    if(locks[i] == lk) {
    800062b0:	6314                	ld	a3,0(a4)
    800062b2:	00968763          	beq	a3,s1,800062c0 <freelock+0x36>
  for (i = 0; i < NLOCK; i++) {
    800062b6:	2785                	addiw	a5,a5,1
    800062b8:	0721                	addi	a4,a4,8
    800062ba:	fec79be3          	bne	a5,a2,800062b0 <freelock+0x26>
    800062be:	a809                	j	800062d0 <freelock+0x46>
      locks[i] = 0;
    800062c0:	078e                	slli	a5,a5,0x3
    800062c2:	0001e717          	auipc	a4,0x1e
    800062c6:	42670713          	addi	a4,a4,1062 # 800246e8 <locks>
    800062ca:	97ba                	add	a5,a5,a4
    800062cc:	0007b023          	sd	zero,0(a5)
  release(&lock_locks);
    800062d0:	0001e517          	auipc	a0,0x1e
    800062d4:	3f850513          	addi	a0,a0,1016 # 800246c8 <lock_locks>
    800062d8:	f77ff0ef          	jal	8000624e <release>
}
    800062dc:	60e2                	ld	ra,24(sp)
    800062de:	6442                	ld	s0,16(sp)
    800062e0:	64a2                	ld	s1,8(sp)
    800062e2:	6105                	addi	sp,sp,32
    800062e4:	8082                	ret

00000000800062e6 <initlock>:
{
    800062e6:	1101                	addi	sp,sp,-32
    800062e8:	ec06                	sd	ra,24(sp)
    800062ea:	e822                	sd	s0,16(sp)
    800062ec:	e426                	sd	s1,8(sp)
    800062ee:	1000                	addi	s0,sp,32
    800062f0:	84aa                	mv	s1,a0
  lk->name = name;
    800062f2:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    800062f4:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    800062f8:	00053823          	sd	zero,16(a0)
  lk->nts = 0;
    800062fc:	00052c23          	sw	zero,24(a0)
  lk->n = 0;
    80006300:	00052e23          	sw	zero,28(a0)
  acquire(&lock_locks);
    80006304:	0001e517          	auipc	a0,0x1e
    80006308:	3c450513          	addi	a0,a0,964 # 800246c8 <lock_locks>
    8000630c:	e9bff0ef          	jal	800061a6 <acquire>
  for (i = 0; i < NLOCK; i++) {
    80006310:	0001e717          	auipc	a4,0x1e
    80006314:	3d870713          	addi	a4,a4,984 # 800246e8 <locks>
    80006318:	4781                	li	a5,0
    8000631a:	1f400613          	li	a2,500
    if(locks[i] == 0) {
    8000631e:	6314                	ld	a3,0(a4)
    80006320:	ca99                	beqz	a3,80006336 <initlock+0x50>
  for (i = 0; i < NLOCK; i++) {
    80006322:	2785                	addiw	a5,a5,1
    80006324:	0721                	addi	a4,a4,8
    80006326:	fec79ce3          	bne	a5,a2,8000631e <initlock+0x38>
  panic("findslot");
    8000632a:	00002517          	auipc	a0,0x2
    8000632e:	4a650513          	addi	a0,a0,1190 # 800087d0 <etext+0x7d0>
    80006332:	b51ff0ef          	jal	80005e82 <panic>
      locks[i] = lk;
    80006336:	078e                	slli	a5,a5,0x3
    80006338:	0001e717          	auipc	a4,0x1e
    8000633c:	3b070713          	addi	a4,a4,944 # 800246e8 <locks>
    80006340:	97ba                	add	a5,a5,a4
    80006342:	e384                	sd	s1,0(a5)
      release(&lock_locks);
    80006344:	0001e517          	auipc	a0,0x1e
    80006348:	38450513          	addi	a0,a0,900 # 800246c8 <lock_locks>
    8000634c:	f03ff0ef          	jal	8000624e <release>
}
    80006350:	60e2                	ld	ra,24(sp)
    80006352:	6442                	ld	s0,16(sp)
    80006354:	64a2                	ld	s1,8(sp)
    80006356:	6105                	addi	sp,sp,32
    80006358:	8082                	ret

000000008000635a <atomic_read4>:

// Read a shared 32-bit value without holding a lock
int
atomic_read4(int *addr) {
    8000635a:	1141                	addi	sp,sp,-16
    8000635c:	e406                	sd	ra,8(sp)
    8000635e:	e022                	sd	s0,0(sp)
    80006360:	0800                	addi	s0,sp,16
  uint32 val;
  __atomic_load(addr, &val, __ATOMIC_SEQ_CST);
    80006362:	0330000f          	fence	rw,rw
    80006366:	4108                	lw	a0,0(a0)
    80006368:	0230000f          	fence	r,rw
  return val;
}
    8000636c:	2501                	sext.w	a0,a0
    8000636e:	60a2                	ld	ra,8(sp)
    80006370:	6402                	ld	s0,0(sp)
    80006372:	0141                	addi	sp,sp,16
    80006374:	8082                	ret

0000000080006376 <snprint_lock>:
#ifdef LAB_LOCK
int
snprint_lock(char *buf, int sz, struct spinlock *lk)
{
  int n = 0;
  if(lk->n > 0) {
    80006376:	4e5c                	lw	a5,28(a2)
    80006378:	00f04463          	bgtz	a5,80006380 <snprint_lock+0xa>
  int n = 0;
    8000637c:	4501                	li	a0,0
    n = snprintf(buf, sz, "lock: %s: #test-and-set %d #acquire() %d\n",
                 lk->name, lk->nts, lk->n);
  }
  return n;
}
    8000637e:	8082                	ret
{
    80006380:	1141                	addi	sp,sp,-16
    80006382:	e406                	sd	ra,8(sp)
    80006384:	e022                	sd	s0,0(sp)
    80006386:	0800                	addi	s0,sp,16
    n = snprintf(buf, sz, "lock: %s: #test-and-set %d #acquire() %d\n",
    80006388:	4e18                	lw	a4,24(a2)
    8000638a:	6614                	ld	a3,8(a2)
    8000638c:	00002617          	auipc	a2,0x2
    80006390:	45460613          	addi	a2,a2,1108 # 800087e0 <etext+0x7e0>
    80006394:	9b4ff0ef          	jal	80005548 <snprintf>
}
    80006398:	60a2                	ld	ra,8(sp)
    8000639a:	6402                	ld	s0,0(sp)
    8000639c:	0141                	addi	sp,sp,16
    8000639e:	8082                	ret

00000000800063a0 <statslock>:

int
statslock(char *buf, int sz) {
    800063a0:	7159                	addi	sp,sp,-112
    800063a2:	f486                	sd	ra,104(sp)
    800063a4:	f0a2                	sd	s0,96(sp)
    800063a6:	eca6                	sd	s1,88(sp)
    800063a8:	e8ca                	sd	s2,80(sp)
    800063aa:	e4ce                	sd	s3,72(sp)
    800063ac:	e0d2                	sd	s4,64(sp)
    800063ae:	fc56                	sd	s5,56(sp)
    800063b0:	f85a                	sd	s6,48(sp)
    800063b2:	f45e                	sd	s7,40(sp)
    800063b4:	f062                	sd	s8,32(sp)
    800063b6:	ec66                	sd	s9,24(sp)
    800063b8:	e86a                	sd	s10,16(sp)
    800063ba:	e46e                	sd	s11,8(sp)
    800063bc:	1880                	addi	s0,sp,112
    800063be:	8aaa                	mv	s5,a0
    800063c0:	8b2e                	mv	s6,a1
  int n;
  int tot = 0;

  acquire(&lock_locks);
    800063c2:	0001e517          	auipc	a0,0x1e
    800063c6:	30650513          	addi	a0,a0,774 # 800246c8 <lock_locks>
    800063ca:	dddff0ef          	jal	800061a6 <acquire>
  n = snprintf(buf, sz, "--- lock kmem/bcache stats\n");
    800063ce:	00002617          	auipc	a2,0x2
    800063d2:	44260613          	addi	a2,a2,1090 # 80008810 <etext+0x810>
    800063d6:	85da                	mv	a1,s6
    800063d8:	8556                	mv	a0,s5
    800063da:	96eff0ef          	jal	80005548 <snprintf>
    800063de:	892a                	mv	s2,a0
  for(int i = 0; i < NLOCK; i++) {
    800063e0:	0001ec17          	auipc	s8,0x1e
    800063e4:	308c0c13          	addi	s8,s8,776 # 800246e8 <locks>
    800063e8:	0001fb97          	auipc	s7,0x1f
    800063ec:	2a0b8b93          	addi	s7,s7,672 # 80025688 <end>
  n = snprintf(buf, sz, "--- lock kmem/bcache stats\n");
    800063f0:	84e2                	mv	s1,s8
  int tot = 0;
    800063f2:	4981                	li	s3,0
    if(locks[i] == 0)
      break;
    if(strncmp(locks[i]->name, "bcache", strlen("bcache")) == 0 ||
    800063f4:	00002a17          	auipc	s4,0x2
    800063f8:	fd4a0a13          	addi	s4,s4,-44 # 800083c8 <etext+0x3c8>
       strncmp(locks[i]->name, "kmem", strlen("kmem")) == 0) {
    800063fc:	00002c97          	auipc	s9,0x2
    80006400:	434c8c93          	addi	s9,s9,1076 # 80008830 <etext+0x830>
    80006404:	a00d                	j	80006426 <statslock+0x86>
      tot += locks[i]->nts;
    80006406:	000d3603          	ld	a2,0(s10)
    8000640a:	4e1c                	lw	a5,24(a2)
    8000640c:	013789bb          	addw	s3,a5,s3
      n += snprint_lock(buf +n, sz-n, locks[i]);
    80006410:	412b05bb          	subw	a1,s6,s2
    80006414:	012a8533          	add	a0,s5,s2
    80006418:	f5fff0ef          	jal	80006376 <snprint_lock>
    8000641c:	0125093b          	addw	s2,a0,s2
  for(int i = 0; i < NLOCK; i++) {
    80006420:	04a1                	addi	s1,s1,8
    80006422:	03748d63          	beq	s1,s7,8000645c <statslock+0xbc>
    if(locks[i] == 0)
    80006426:	8d26                	mv	s10,s1
    80006428:	609c                	ld	a5,0(s1)
    8000642a:	cb8d                	beqz	a5,8000645c <statslock+0xbc>
    if(strncmp(locks[i]->name, "bcache", strlen("bcache")) == 0 ||
    8000642c:	0087bd83          	ld	s11,8(a5)
    80006430:	8552                	mv	a0,s4
    80006432:	a30fa0ef          	jal	80000662 <strlen>
    80006436:	862a                	mv	a2,a0
    80006438:	85d2                	mv	a1,s4
    8000643a:	856e                	mv	a0,s11
    8000643c:	970fa0ef          	jal	800005ac <strncmp>
    80006440:	d179                	beqz	a0,80006406 <statslock+0x66>
       strncmp(locks[i]->name, "kmem", strlen("kmem")) == 0) {
    80006442:	609c                	ld	a5,0(s1)
    80006444:	0087bd83          	ld	s11,8(a5)
    80006448:	8566                	mv	a0,s9
    8000644a:	a18fa0ef          	jal	80000662 <strlen>
    8000644e:	862a                	mv	a2,a0
    80006450:	85e6                	mv	a1,s9
    80006452:	856e                	mv	a0,s11
    80006454:	958fa0ef          	jal	800005ac <strncmp>
    if(strncmp(locks[i]->name, "bcache", strlen("bcache")) == 0 ||
    80006458:	f561                	bnez	a0,80006420 <statslock+0x80>
    8000645a:	b775                	j	80006406 <statslock+0x66>
    }
  }
  
  n += snprintf(buf+n, sz-n, "--- top 5 contended locks:\n");
    8000645c:	00002617          	auipc	a2,0x2
    80006460:	3dc60613          	addi	a2,a2,988 # 80008838 <etext+0x838>
    80006464:	412b05bb          	subw	a1,s6,s2
    80006468:	012a8533          	add	a0,s5,s2
    8000646c:	8dcff0ef          	jal	80005548 <snprintf>
    80006470:	01250a3b          	addw	s4,a0,s2
    80006474:	4b95                	li	s7,5
  int last = 100000000;
    80006476:	05f5e837          	lui	a6,0x5f5e
    8000647a:	10080813          	addi	a6,a6,256 # 5f5e100 <_entry-0x7a0a1f00>
  for(int t = 0; t < 5; t++) {
    int top = 0;
    for(int i = 0; i < NLOCK; i++) {
      if(locks[i] == 0)
        break;
      if(locks[i]->nts > locks[top]->nts && locks[i]->nts < last) {
    8000647e:	0001e497          	auipc	s1,0x1e
    80006482:	26a48493          	addi	s1,s1,618 # 800246e8 <locks>
    for(int i = 0; i < NLOCK; i++) {
    80006486:	1f400913          	li	s2,500
    8000648a:	a881                	j	800064da <statslock+0x13a>
        top = i;
    8000648c:	85ba                	mv	a1,a4
    for(int i = 0; i < NLOCK; i++) {
    8000648e:	2705                	addiw	a4,a4,1
    80006490:	06a1                	addi	a3,a3,8
    80006492:	01270f63          	beq	a4,s2,800064b0 <statslock+0x110>
      if(locks[i] == 0)
    80006496:	629c                	ld	a5,0(a3)
    80006498:	cf81                	beqz	a5,800064b0 <statslock+0x110>
      if(locks[i]->nts > locks[top]->nts && locks[i]->nts < last) {
    8000649a:	4f90                	lw	a2,24(a5)
    8000649c:	00359793          	slli	a5,a1,0x3
    800064a0:	97a6                	add	a5,a5,s1
    800064a2:	639c                	ld	a5,0(a5)
    800064a4:	4f9c                	lw	a5,24(a5)
    800064a6:	fec7d4e3          	bge	a5,a2,8000648e <statslock+0xee>
    800064aa:	ff0652e3          	bge	a2,a6,8000648e <statslock+0xee>
    800064ae:	bff9                	j	8000648c <statslock+0xec>
      }
    }
    n += snprint_lock(buf+n, sz-n, locks[top]);
    800064b0:	058e                	slli	a1,a1,0x3
    800064b2:	00b48cb3          	add	s9,s1,a1
    800064b6:	000cb603          	ld	a2,0(s9)
    800064ba:	414b05bb          	subw	a1,s6,s4
    800064be:	014a8533          	add	a0,s5,s4
    800064c2:	eb5ff0ef          	jal	80006376 <snprint_lock>
    800064c6:	01450d3b          	addw	s10,a0,s4
    800064ca:	8a6a                	mv	s4,s10
    last = locks[top]->nts;
    800064cc:	000cb783          	ld	a5,0(s9)
    800064d0:	0187a803          	lw	a6,24(a5)
  for(int t = 0; t < 5; t++) {
    800064d4:	3bfd                	addiw	s7,s7,-1
    800064d6:	000b8663          	beqz	s7,800064e2 <statslock+0x142>
  int tot = 0;
    800064da:	86e2                	mv	a3,s8
    for(int i = 0; i < NLOCK; i++) {
    800064dc:	4701                	li	a4,0
    int top = 0;
    800064de:	4581                	li	a1,0
    800064e0:	bf5d                	j	80006496 <statslock+0xf6>
  }
  n += snprintf(buf+n, sz-n, "tot= %d\n", tot);
    800064e2:	86ce                	mv	a3,s3
    800064e4:	00002617          	auipc	a2,0x2
    800064e8:	37460613          	addi	a2,a2,884 # 80008858 <etext+0x858>
    800064ec:	41ab05bb          	subw	a1,s6,s10
    800064f0:	01aa8533          	add	a0,s5,s10
    800064f4:	854ff0ef          	jal	80005548 <snprintf>
    800064f8:	01a50d3b          	addw	s10,a0,s10
  release(&lock_locks);  
    800064fc:	0001e517          	auipc	a0,0x1e
    80006500:	1cc50513          	addi	a0,a0,460 # 800246c8 <lock_locks>
    80006504:	d4bff0ef          	jal	8000624e <release>
  return n;
}
    80006508:	856a                	mv	a0,s10
    8000650a:	70a6                	ld	ra,104(sp)
    8000650c:	7406                	ld	s0,96(sp)
    8000650e:	64e6                	ld	s1,88(sp)
    80006510:	6946                	ld	s2,80(sp)
    80006512:	69a6                	ld	s3,72(sp)
    80006514:	6a06                	ld	s4,64(sp)
    80006516:	7ae2                	ld	s5,56(sp)
    80006518:	7b42                	ld	s6,48(sp)
    8000651a:	7ba2                	ld	s7,40(sp)
    8000651c:	7c02                	ld	s8,32(sp)
    8000651e:	6ce2                	ld	s9,24(sp)
    80006520:	6d42                	ld	s10,16(sp)
    80006522:	6da2                	ld	s11,8(sp)
    80006524:	6165                	addi	sp,sp,112
    80006526:	8082                	ret
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	8282                	jr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0)
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
