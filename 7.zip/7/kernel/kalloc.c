// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
// defined by kernel.ld.

struct run {
    struct run *next;
};

struct {
    struct spinlock lock;
    struct run *freelist;
} kmem[NCPU];

/*
 * stealing helpers:
 * - STEAL_MIN: try to steal at least this many pages in one go (reduces freq).
 * - steal_cursor: per-hart start offset to spread victims across CPUs.
 */
#define STEAL_MIN 32
static int steal_cursor[NCPU];

void
kinit()
{
    int i;
    char lockname[12];
    for(i = 0; i < NCPU; i++){
        // lock names must start with "kmem"
        snprintf(lockname, sizeof(lockname), "kmem_%d", i);
        initlock(&kmem[i].lock, lockname);
        kmem[i].freelist = 0;
        steal_cursor[i] = (i + 1) % NCPU; // start search at a different offset
    }
    freerange(end, (void*)PHYSTOP);
}

/*
 * freerange: distribute initial free pages across CPUs round-robin.
 * This avoids putting all initial pages on the kinit() hart and creating
 * a huge one-sided freelist hotspot.
 */
void
freerange(void *pa_start, void *pa_end)
{
    char *p;
    int cid = 0;
    p = (char*)PGROUNDUP((uint64)pa_start);
    for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
        struct run *r = (struct run*)p;
        r->next = 0;
        acquire(&kmem[cid].lock);
        r->next = kmem[cid].freelist;
        kmem[cid].freelist = r;
        release(&kmem[cid].lock);
        cid = (cid + 1) % NCPU;
    }
}

// Free the page of physical memory pointed at by pa.
void
kfree(void *pa)
{
    struct run *r;

    if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
        panic("kfree");

    // Fill with junk to catch dangling refs.
    memset(pa, 1, PGSIZE);

    r = (struct run*)pa;

    push_off();
    int c = cpuid();
    acquire(&kmem[c].lock);
    r->next = kmem[c].freelist;
    kmem[c].freelist = r;
    release(&kmem[c].lock);
    pop_off();
}

/*
 * try_take_batch_from: under src lock, remove up to 'want' pages from head,
 * return head of stolen list and set *stolen to number taken. Caller must not
 * hold dst lock. We hold src lock only long enough to split the list.
 */
static struct run*
try_take_batch_from(int src, int want, int *stolen)
{
    struct run *head;

    acquire(&kmem[src].lock);
    head = kmem[src].freelist;
    if(!head){
        release(&kmem[src].lock);
        *stolen = 0;
        return 0;
    }

    // count available (cheap linear scan)
    int avail = 0;
    struct run *p = head;
    while(p){
        avail++;
        p = p->next;
        if(avail >= want) break; // no need to traverse full list if we already have enough
    }

    int take = want;
    if(avail < want){
        // if not enough, prefer to take about half (so victim keeps some)
        // but at least 1
        // better than taking nothing when avail small
        // count full list to get true avail if we broke early
        if(avail < want){
            // finish counting full list
            p = head;
            avail = 0;
            while(p){ avail++; p = p->next; }
        }
        if(avail <= 1){
            // don't steal if only 0 or 1 (leave small lists alone)
            release(&kmem[src].lock);
            *stolen = 0;
            return 0;
        }
        take = avail / 2;
        if(take == 0) take = 1;
    }

    // now split the first 'take' nodes
    struct run *prev = 0;
    p = head;
    for(int i = 0; i < take && p; i++){
        prev = p;
        p = p->next;
    }
    // prev is tail of taken chunk, p is remainder
    if(prev)
        prev->next = 0;
    kmem[src].freelist = p;
    release(&kmem[src].lock);

    *stolen = take;
    return head;
}

/*
 * attach_batch_to_cpu: attach a stolen list (head) to dst freelist.
 * Caller must ensure head != 0 and nodes terminated with next==0 at tail.
 */
static void
attach_batch_to_cpu(int dst, struct run *head)
{
    if(!head) return;
    acquire(&kmem[dst].lock);
    // find tail of head
    struct run *t = head;
    while(t->next) t = t->next;
    t->next = kmem[dst].freelist;
    kmem[dst].freelist = head;
    release(&kmem[dst].lock);
}

// Allocate one 4096-byte page of physical memory.
void *
kalloc(void)
{
    struct run *r = 0;

    // only disable interrupts to read cpuid
    push_off();
    int c = cpuid();
    pop_off();

    // fast path: local freelist
    acquire(&kmem[c].lock);
    r = kmem[c].freelist;
    if(r)
        kmem[c].freelist = r->next;
    release(&kmem[c].lock);

    if(r) {
        memset((char*)r, 5, PGSIZE);
        return (void*)r;
    }

    // slow path: need to steal a batch from others. start from steal_cursor[c]
    int start = steal_cursor[c];
    for(int i = 0; i < NCPU; i++){
        int other = (start + i) % NCPU;
        if(other == c) continue;
        int stolen = 0;
        struct run *batch = try_take_batch_from(other, STEAL_MIN, &stolen);
        if(stolen > 0 && batch){
            // attach batch to our freelist
            attach_batch_to_cpu(c, batch);
            // move cursor forward to spread future attempts
            steal_cursor[c] = (other + 1) % NCPU;
            // take one now
            acquire(&kmem[c].lock);
            r = kmem[c].freelist;
            if(r)
                kmem[c].freelist = r->next;
            release(&kmem[c].lock);
            if(r) break;
        }
    }

    // as a fallback, try again with a larger request to any cpu
    if(!r){
        for(int other = 0; other < NCPU; other++){
            if(other == c) continue;
            int stolen = 0;
            // try a larger steal to move more pages at once
            struct run *batch = try_take_batch_from(other, STEAL_MIN * 8, &stolen);
            if(stolen > 0 && batch){
                attach_batch_to_cpu(c, batch);
                acquire(&kmem[c].lock);
                r = kmem[c].freelist;
                if(r)
                    kmem[c].freelist = r->next;
                release(&kmem[c].lock);
                if(r) break;
            }
        }
    }

    if(r)
        memset((char*)r, 5, PGSIZE);
    return (void*)r;
}

