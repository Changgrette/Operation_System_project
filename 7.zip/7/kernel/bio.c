// Buffer Cache Implementation
//
// The buffer cache maintains a collection of buffers representing
// disk blocks in memory. This reduces disk I/O and ensures proper
// synchronization when multiple processes access the same block.
//
// Interface:
// * Use bread() to fetch a buffer for a given disk block.
// * Use bwrite() to write a buffer's contents back to disk.
// * Use brelse() to release a buffer after use.
// * Do not access a buffer after calling brelse().
// * Buffers are exclusive: only one process can hold a buffer at a time.

#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define NBUCKET 5              // Number of hash buckets (prime number for better distribution)
#define NBUF_PER_BUCKET (NBUF / NBUCKET)  // Buffers per bucket

struct {
    struct spinlock lock;  // Used during initialization
    struct buf buf[NBUF];
} bcache;

struct {
    struct spinlock lock;  // Protects bucket operations
    struct buf head;       // Dummy head for doubly-linked list
    int nbuf;              // Number of buffers in this bucket
} bcache_bucket[NBUCKET];

// Hash function: map block number to bucket index
static uint
hash(uint dev, uint blockno) {
    return blockno % NBUCKET;
}

// Initialize buffer cache and distribute buffers among buckets
void
binit(void) {
    struct buf *b;
    char lockname[32];

    initlock(&bcache.lock, "bcache");

    // Initialize each bucket
    for(int i = 0; i < NBUCKET; i++) {
        snprintf(lockname, sizeof(lockname), "bcache%d", i);
        initlock(&bcache_bucket[i].lock, lockname);
        bcache_bucket[i].head.prev = &bcache_bucket[i].head;
        bcache_bucket[i].head.next = &bcache_bucket[i].head;
        bcache_bucket[i].nbuf = 0;
    }

    // Distribute all buffers evenly among buckets
    for(b = bcache.buf; b < bcache.buf + NBUF; b++) {
        uint bucket_id = (b - bcache.buf) / NBUF_PER_BUCKET;
        if(bucket_id >= NBUCKET) bucket_id = NBUCKET - 1;

        b->next = bcache_bucket[bucket_id].head.next;
        b->prev = &bcache_bucket[bucket_id].head;
        initsleeplock(&b->lock, "buffer");
        bcache_bucket[bucket_id].head.next->prev = b;
        bcache_bucket[bucket_id].head.next = b;
        bcache_bucket[bucket_id].nbuf++;
    }
}

// Acquire a buffer for a given block, locking it before returning
static struct buf*
bget(uint dev, uint blockno) {
    struct buf *b;
    uint bucket_id = hash(dev, blockno);

    acquire(&bcache_bucket[bucket_id].lock);

    // Check if the block is already cached in the bucket
    for(b = bcache_bucket[bucket_id].head.next; b != &bcache_bucket[bucket_id].head; b = b->next) {
        if(b->dev == dev && b->blockno == blockno) {
            b->refcnt++;
            release(&bcache_bucket[bucket_id].lock);
            acquiresleep(&b->lock);
            return b;
        }
    }

    // Search for a free buffer within this bucket
    for(b = bcache_bucket[bucket_id].head.prev; b != &bcache_bucket[bucket_id].head; b = b->prev) {
        if(b->refcnt == 0) {
            b->dev = dev;
            b->blockno = blockno;
            b->valid = 0;
            b->refcnt = 1;
            release(&bcache_bucket[bucket_id].lock);
            acquiresleep(&b->lock);
            return b;
        }
    }

    // No free buffer in this bucket, attempt to steal from other buckets
    release(&bcache_bucket[bucket_id].lock);
    struct buf *victim = 0;

    for(int i = 0; i < NBUCKET; i++) {
        if(i == bucket_id) continue;
        acquire(&bcache_bucket[i].lock);
        if(bcache_bucket[i].nbuf > NBUF_PER_BUCKET) {
            for(b = bcache_bucket[i].head.prev; b != &bcache_bucket[i].head; b = b->prev) {
                if(b->refcnt == 0) {
                    victim = b;
                    break;
                }
            }
        }
        if(victim) {
            victim->next->prev = victim->prev;
            victim->prev->next = victim->next;
            bcache_bucket[i].nbuf--;
            release(&bcache_bucket[i].lock);
            break;
        }
        release(&bcache_bucket[i].lock);
    }

    // If still no buffer found, try any unused buffer in other buckets
    if(!victim) {
        for(int i = 0; i < NBUCKET; i++) {
            if(i == bucket_id) continue;
            acquire(&bcache_bucket[i].lock);
            for(b = bcache_bucket[i].head.prev; b != &bcache_bucket[i].head; b = b->prev) {
                if(b->refcnt == 0) {
                    victim = b;
                    victim->next->prev = victim->prev;
                    victim->prev->next = victim->next;
                    bcache_bucket[i].nbuf--;
                    release(&bcache_bucket[i].lock);
                    goto found_victim;
                }
            }
            release(&bcache_bucket[i].lock);
        }
    }

    found_victim:
    if(victim) {
        acquire(&bcache_bucket[bucket_id].lock);
        victim->dev = dev;
        victim->blockno = blockno;
        victim->valid = 0;
        victim->refcnt = 1;
        victim->next = bcache_bucket[bucket_id].head.next;
        victim->prev = &bcache_bucket[bucket_id].head;
        bcache_bucket[bucket_id].head.next->prev = victim;
        bcache_bucket[bucket_id].head.next = victim;
        bcache_bucket[bucket_id].nbuf++;
        release(&bcache_bucket[bucket_id].lock);

        acquiresleep(&victim->lock);
        return victim;
    }

    panic("bget: no buffers available");
}

// Return a locked buffer containing the data of the specified block
struct buf*
bread(uint dev, uint blockno) {
    struct buf *b = bget(dev, blockno);
    if(!b->valid) {
        virtio_disk_rw(b, 0);
        b->valid = 1;
    }
    return b;
}

// Write buffer contents to disk (buffer must be locked)
void
bwrite(struct buf *b) {
    if(!holdingsleep(&b->lock)) panic("bwrite: buffer not locked");
    virtio_disk_rw(b, 1);
}

// Release a locked buffer and move it to the MRU position in its bucket
void
brelse(struct buf *b) {
    if(!holdingsleep(&b->lock)) panic("brelse: buffer not locked");

    releasesleep(&b->lock);

    uint bucket_id = hash(b->dev, b->blockno);
    acquire(&bcache_bucket[bucket_id].lock);
    b->refcnt--;
    if(b->refcnt == 0) {
        // Move to the head of MRU list
        b->next->prev = b->prev;
        b->prev->next = b->next;
        b->next = bcache_bucket[bucket_id].head.next;
        b->prev = &bcache_bucket[bucket_id].head;
        bcache_bucket[bucket_id].head.next->prev = b;
        bcache_bucket[bucket_id].head.next = b;
    }
    release(&bcache_bucket[bucket_id].lock);
}

// Increment reference count to prevent eviction
void
bpin(struct buf *b) {
    uint bucket_id = hash(b->dev, b->blockno);
    acquire(&bcache_bucket[bucket_id].lock);
    b->refcnt++;
    release(&bcache_bucket[bucket_id].lock);
}

// Decrement reference count to allow eviction
void
bunpin(struct buf *b) {
    uint bucket_id = hash(b->dev, b->blockno);
    acquire(&bcache_bucket[bucket_id].lock);
    b->refcnt--;
    release(&bcache_bucket[bucket_id].lock);
}
